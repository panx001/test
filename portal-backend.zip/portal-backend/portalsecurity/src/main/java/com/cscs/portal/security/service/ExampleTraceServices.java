package com.cscs.portal.security.service;

import java.util.List;

public interface ExampleTraceServices {

    void addUserTrace(String userId, String path, String ip);
}
