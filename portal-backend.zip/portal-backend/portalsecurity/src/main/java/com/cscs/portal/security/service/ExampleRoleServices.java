package com.cscs.portal.security.service;

public interface ExampleRoleServices {

    /**
     * 根据用户ID获取角色信息
     */
    int findAccountRoleById(Long accountId);
}
