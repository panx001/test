package com.cscs.portal.security.service.impl;

import com.cscs.portal.security.service.ExampleTraceServices;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@SuppressWarnings("JpaQlInspection")
@Configurable
@Service
public class ExampleTraceServicesImpl implements ExampleTraceServices {
    private static ExecutorService cachedThreadPool = Executors.newCachedThreadPool();

    @Override
    public void addUserTrace(final String userId, final String path, final String ip) {
        cachedThreadPool.execute(new Runnable() {
            public void run() {
                addUserTrace_i(userId, path, ip);
            }
        });
        return;
    }

    /**
     * 新增用户跟踪信息
     */
    @Transactional
    public void addUserTrace_i(String userId, String path, String ip) {
        //跟踪信息入库
    }
}
