package com.cscs.portal.security.service.impl;


import com.cscs.portal.security.service.ExampleRoleServices;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@SuppressWarnings("JpaQlInspection")
@Service
public class ExampleRoleServicesImpl implements ExampleRoleServices {

    @PersistenceContext
    EntityManager em;

    /**
     * 根据用户ID获取角色信息
     */
    @Override
    public int findAccountRoleById(Long accountId) {
        String sql = "SELECT COUNT(1) FROM ACCOUNT_ROLE_XW A \n" +
                "INNER JOIN ROLE B ON A.ROLE_ID =B.ROLE_ID\n" +
                "WHERE B.ROLE_NM = '管理员' AND A.ACCOUNT_ID =" + accountId;
        return Integer.valueOf(em.createNativeQuery(sql).getSingleResult().toString());
    }
}