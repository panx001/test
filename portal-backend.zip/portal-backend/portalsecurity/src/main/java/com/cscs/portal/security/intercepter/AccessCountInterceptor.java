package com.cscs.portal.security.intercepter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.web.servlet.ShiroHttpServletRequest;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * 这个拦截器可能会用来检验次数
 */
public class AccessCountInterceptor extends HandlerInterceptorAdapter {
    protected final Log logger = LogFactory.getLog(this.getClass());

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
    	 try {
             if (handler.getClass().isAssignableFrom(HandlerMethod.class)) {
//                 if( request instanceof ShiroHttpServletRequest) {
//                	 System.out.println(request.getRequestURI());
//                 }
            	 //标识null userid 有值说明登录校验通过，访问次数暂时增加
            	 
            	 //标识false userid 有值说明登录通过授权无效，访问次数递减，402时才会第二次进来
                 System.out.println(request.getAttribute("authoriFlag")+(String)request.getAttribute("userId"));
            	 // 实现方法级权限控制
                 HandlerMethod method = (HandlerMethod) handler;
                 RequiresRoles premission = method.getMethodAnnotation(RequiresRoles.class);
                 System.out.println(premission!=null?premission.value()[0]:"");
                 // 没有声明需要权限,或者声明不验证权限
                 }
         } catch (Exception e) {
             logger.error("", e);
             return false;
         }
         return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
    }
}
