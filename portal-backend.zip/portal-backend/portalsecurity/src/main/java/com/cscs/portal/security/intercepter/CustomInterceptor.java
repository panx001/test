package com.cscs.portal.security.intercepter;

import com.cscs.portal.security.service.ExampleTraceServices;
import com.cscs.portal.security.util.SpringContextAware;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.InetAddress;
import java.util.concurrent.TimeUnit;

/**
 * 这个拦截器实现了重复登陆和用户跟踪的功能
 */
//@Component
public class CustomInterceptor extends HandlerInterceptorAdapter {
    protected final Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    private StringRedisTemplate rt;

    @Value("${userTrack.flag}")
    String flag;

    @Autowired
    @Qualifier("exampleTraceServicesImpl")
    ExampleTraceServices exampleTraceServicesImpl;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        //目前通过header - smallapp来区分是否从微信小程序过来的接口
        String smallApp = request.getHeader("smallapp");
        Object userId = request.getAttribute("userId");

        //处理重复登陆 - 目前只针对web 做重复登陆限制
        if (StringUtils.isEmpty(smallApp) && !StringUtils.isEmpty(userId)) {//web端
            String curBrowser = request.getHeader("browser");
            if(curBrowser != null) {
                String browser = rt.opsForValue().get("brower_" + userId);
                if (browser != null && !curBrowser.equals(browser)) {
                    // 返回到登录界面
                    response.setHeader("Access-Control-Allow-Origin", "*");
                    response.setStatus(406);
                    response.sendError(406);
                    return false;
                }
                rt.opsForValue().set("brower_" + userId, curBrowser);
                rt.expire("brower_" + userId, 2, TimeUnit.HOURS);
            }
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        String smallApp = request.getHeader("smallapp");
        String path = request.getRequestURI();
        if(request.getQueryString() != null){
            path += "?" + request.getQueryString();
        }
        Object userId = request.getAttribute("userId");
        if (!StringUtils.isEmpty(userId) && "open".equals(flag)) {
            if (exampleTraceServicesImpl == null) {
//                BeanFactory factory = WebApplicationContextUtils.getRequiredWebApplicationContext(request.getServletContext());
                exampleTraceServicesImpl = (ExampleTraceServices) SpringContextAware.getBean("exampleTraceServicesImpl");
            }

            String ip = request.getHeader("x-forwarded-for");
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader("Proxy-Client-IP");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader("WL-Proxy-Client-IP");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getRemoteAddr();
            }
            if (ip.equals("0:0:0:0:0:0:0:1")) {
                ip = InetAddress.getLocalHost().getHostAddress().toString();
            }
            this.exampleTraceServicesImpl.addUserTrace(userId.toString(), path, ip);
        }
    }
}
