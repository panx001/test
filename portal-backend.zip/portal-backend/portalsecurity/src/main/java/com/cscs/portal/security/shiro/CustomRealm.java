package com.cscs.portal.security.shiro;

import com.cscs.portal.security.service.ExampleRoleServices;
import com.cscs.portal.security.util.JWTUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.CredentialsException;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.HashSet;
import java.util.Set;

@Service
public class CustomRealm extends AuthorizingRealm {

    protected final Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    @Qualifier("exampleRoleServicesImpl")
    ExampleRoleServices exampleRoleServices;

    /**
     * 大坑！，必须重写此方法，不然Shiro会报错
     */
    @Override
    public boolean supports(AuthenticationToken token) {
        return token instanceof JWTToken;
    }

    /**
     * 只有当需要检测用户权限的时候才会调用此方法，例如checkRole,checkPermission之类的
     */
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
        SimpleAuthorizationInfo simpleAuthorizationInfo = new SimpleAuthorizationInfo();

        //通过下面的方法可以获取上下文request
        HttpServletRequest request =((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
        //获取用户的角色和权限
        if(request.getAttribute("accountId")!=null) {
        	 int role = exampleRoleServices.findAccountRoleById(Long.valueOf((String)request.getAttribute("accountId")));
             logger.info("realm:" + String.valueOf(role));
             //temp
             if(role>0) {
             	request.setAttribute("role", role);
             	simpleAuthorizationInfo.addRole("admin");
             }
        }else {
        	//未登录
        	logger.info("Authenticated failed");
        	return null;
        }
        return simpleAuthorizationInfo;
    }

    /**
     * 默认使用此方法进行token正确与否验证，错误抛出异常即可。
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken auth) throws AuthenticationException {
        String token = (String) auth.getCredentials();

        //通过下面的方法可以获取上下文request
        HttpServletRequest request =((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
        //token验证
        String[] claims = JWTUtil.getClaims(token);
        if (null == claims || !JWTUtil.verify(token, claims[0], claims[1])) {
            //可以自定义异常
            throw new AuthenticationException("token invalid");
        }

        request.setAttribute("accountId", claims[0]);
        request.setAttribute("userId", claims[1]);
        return new SimpleAuthenticationInfo(token, token, "my_realm");
    }
}
