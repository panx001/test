package com.cscs;

import com.cscs.mq.TestProducer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import javax.annotation.Resource;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = PortalApplication.class)
@WebAppConfiguration
public class MQTests {
	@Resource
	private TestProducer testProducer;

	@Test
	public void testProducer() {
		for (int i = 0; i < 10; i++) {
            testProducer.sendMessage("Hello RocketMQ " + i, "testTopic",
					"TagTest"+ i, "Key" + i);
		}

		try {
			Thread.sleep(10 * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
