package com.cscs.portal.dto.base;

/**
 * Created by dch on 2016/8/10.
 */
public class Token {
    private static ThreadLocal<String> threadSession = new ThreadLocal<String>();

    public static void set(String token){
        threadSession.set(token);
    }

    public static String get(){
        return threadSession.get();
    }
}
