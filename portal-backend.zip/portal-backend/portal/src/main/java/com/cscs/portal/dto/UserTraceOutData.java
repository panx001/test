package com.cscs.portal.dto;

/**
 * Created by dch on 2016/11/14.
 * 用户跟踪信息出参
 */
public class UserTraceOutData{
    private String accountNm;//用户名字
    private String visitUrl;//访问Url
    private String visitDt;//访问时间
    private String visitStopDt;//访问结束时间

    public String getAccountNm() {
        return accountNm;
    }

    public void setAccountNm(String accountNm) {
        this.accountNm = accountNm;
    }

    public String getVisitUrl() {
        return visitUrl;
    }

    public void setVisitUrl(String visitUrl) {
        this.visitUrl = visitUrl;
    }

    public String getVisitDt() {
        return visitDt;
    }

    public void setVisitDt(String visitDt) {
        this.visitDt = visitDt;
    }

    public String getVisitStopDt() {
        return visitStopDt;
    }

    public void setVisitStopDt(String visitStopDt) {
        this.visitStopDt = visitStopDt;
    }
}
