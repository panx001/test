package com.cscs.mq;

import com.cscs.mq.base.BaseConsumer;
import org.apache.rocketmq.client.exception.MQClientException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

/**
 * 需要测试单元测试类MQTests， 要放开Component注释
 */
//@Component
public class TestConsumer extends BaseConsumer {
    private static final Logger LOGGER = LoggerFactory.getLogger(TestConsumer.class);

    /**
     * 初始化
     *
     * @throws MQClientException
     */
    @PostConstruct
    public void start() {
        init("TestRocketMQPushConsumer","testTopic","*");
    }

    @Override
    protected void processMessage(String topic, String tags, String keys, String messageBody) {
        LOGGER.info("MQ：消费者定制处理消息: {} {} {} {}", topic, tags, keys, messageBody);
    }

    @PreDestroy
    public void stop() {
        destroy();
    }
}
