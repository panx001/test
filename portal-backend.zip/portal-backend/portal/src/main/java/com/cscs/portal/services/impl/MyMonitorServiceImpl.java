package com.cscs.portal.services.impl;

import com.cscs.portal.dto.UserMonitorInData;
import com.cscs.portal.dto.UserMonitorXWInfoData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.UserFollow;
import com.cscs.portal.entity.UserMonitor;
import com.cscs.portal.entity.UserMonitorInfoMp;
import com.cscs.portal.entity.UserMonitorXw;
import com.cscs.portal.services.MyMonitorService;
import com.cscs.repository.UserMonitorInfoMpRepository;
import com.cscs.repository.UserMonitorRepository;
import com.cscs.repository.UserMonitorXwRepository;
import com.cscs.util.HttpUtil;
import com.cscs.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@SuppressWarnings("JpaQlInspection")
public class MyMonitorServiceImpl implements MyMonitorService {

    @Autowired
    private UserMonitorRepository userMonitorRepository;

    @Autowired
    private UserMonitorXwRepository userMonitorXwRepository;
    
    
    @Autowired
    private UserMonitorInfoMpRepository userMonitorMpRepository;
    
    private final static String UNREAD="0";
    
    private final static String READ="1";
    
    private final static Map<Integer,Integer> dateTypeToDaysMap;
    
    static{
    	dateTypeToDaysMap = new HashMap<Integer,Integer>();
    	dateTypeToDaysMap.put(1,1);
    	dateTypeToDaysMap.put(2,3);
    	dateTypeToDaysMap.put(3,7);
    	dateTypeToDaysMap.put(4,30);
    	dateTypeToDaysMap.put(5,90);
    };
    

    @PersistenceContext
    EntityManager em;

    public List<UserMonitor> listCompanys(Long userId) {
        String sql = "SELECT u FROM UserMonitor u WHERE userid =?1 and isdel=0";
        Query query = em.createQuery(sql, UserMonitor.class);
        query.setParameter(1, userId);
        return query.getResultList();
    }

    public int findCount(Long userId) {
        String sql = "SELECT COUNT(1) FROM USER_MONITOR WHERE ISDEL = 0 AND USERID = ?1";
        Query query = em.createNativeQuery(sql);
        query.setParameter(1, userId);
        return Integer.valueOf(query.getSingleResult().toString());
    }

    public void save(UserMonitor info) {
        userMonitorRepository.save(info);
    }

    @Transactional
    public void delete(Long id,Long userId) {
        String sql = "UPDATE USER_MONITOR SET ISDEL = 1 WHERE id=?1 and USERID = ?2";
        Query query = em.createNativeQuery(sql);
        query.setParameter(1, id);
        query.setParameter(2, userId);
        query.executeUpdate();
    }

    public List<Object> findMonitorCompy() {
        String sql = "SELECT DISTINCT COMPANYID FROM USER_MONITOR WHERE ISDEL = 0";
        Query query = em.createNativeQuery(sql);
        return query.getResultList();
    }

    public List<Object> findMonitorList(UserMonitorInData inData,Long userId,BaseOutData outData) {
        //String sql = "SELECT ID,COMPANY_ID,TYPE,DT,CONTENT,IS_READ FROM USER_MONITOR_XW WHERE 1 = 1\n";
    	int page = inData.getPage() == 0 ? 0 : inData.getPage() - 1;
        int pageSize = inData.getPageSize() == 0 ? 10 : inData.getPageSize();
    	String sql = "SELECT umx.ID as id,umx.COMPANY_ID as companyId,umx.TYPE AS type,umx.DT as dt,umx.CONTENT as content,umx.risk_id as riskId,umx.company_name AS companyName,nvl(ump.IS_READ,0) as isRead FROM USER_MONITOR_XW umx \r\n" + 
        		"inner join USER_MONITOR um on umx.company_id = um.companyid and um.isdel = 0";
        String nextSql = "";
    	if (!StringUtil.isEmpty(inData.getIsRead()) && READ.equals(inData.getIsRead())) {
        	//需要关联中间表
    		nextSql+=" inner join user_monitorinfo_mp ump on ump.userid = um.userid and ump.monitor_info_id = umx.id ";
        }else if(!StringUtil.isEmpty(inData.getIsRead()) && UNREAD.equals(inData.getIsRead())) {
        	//未读
        	nextSql+=" left join user_monitorinfo_mp ump on ump.userid = um.userid and ump.monitor_info_id = umx.id";
        }else {
        	nextSql+=" left join user_monitorinfo_mp ump on ump.userid = um.userid and ump.monitor_info_id = umx.id";
        }
        
    	nextSql+=" where  um.userid = ?1 and umx.dt >= um.dt";// umx.dt >= um.dt and 
        
        if (!StringUtil.isEmpty(inData.getRiskTypes())) {
        	nextSql += " AND umx.TYPE in (?2)";
        }
        if (inData.getDateType() != 0 && inData.getDateType()<6 ) {
        	nextSql += " AND umx.dt >= sysdate - ?3";
        }else if(inData.getDateType()==6) {
        	//自定义时间
        	nextSql += " AND umx.dt >= to_date(?3,'yyyy-mm-dd hh24:mi:ss') and umx.dt<=to_date(?4,'yyyy-mm-dd hh24:mi:ss') ";
        }
        
        if (!StringUtil.isEmpty(inData.getIsRead()) && READ.equals(inData.getIsRead())) {
        	nextSql += " AND ump.IS_READ = ?5";
        }else if(!StringUtil.isEmpty(inData.getIsRead()) && UNREAD.equals(inData.getIsRead())) {
        	nextSql += " and ump.is_read is null ";
        }
//     
        nextSql+=" ORDER BY UMX.DT DESC ";
        sql += nextSql;
        Query query = em.createNativeQuery(sql);
        
        String countSql = "SELECT Count(1) FROM USER_MONITOR_XW umx \r\n" + 
        		"inner join USER_MONITOR um on umx.company_id = um.companyid and um.isdel = 0";
        countSql+=nextSql;
        Query countQuery = em.createNativeQuery(countSql);
        countQuery.setParameter(1, userId);
       
        query.setParameter(1, userId);
        if (!StringUtil.isEmpty(inData.getRiskTypes())) {
            List<String> typeList = Arrays.asList(inData.getRiskTypes().split(","));
            query.setParameter(2, typeList);
            countQuery.setParameter(2, typeList);
        }
        
        if (inData.getDateType() != 0 && inData.getDateType()<6 ) {
            query.setParameter(3, dateTypeToDaysMap.get(inData.getDateType()));
            countQuery.setParameter(3, dateTypeToDaysMap.get(inData.getDateType()));
        }else if(inData.getDateType()==6) {
        	query.setParameter(3, String.format("%s 00:00:01",inData.getStartDt()));
        	query.setParameter(4, String.format("%s 23:59:59",inData.getEndDt()));
            countQuery.setParameter(3, String.format("%s 00:00:01",inData.getStartDt()));
            countQuery.setParameter(4, String.format("%s 23:59:59",inData.getEndDt()));
        }
        
        if (!StringUtil.isEmpty(inData.getIsRead()) && READ.equals(inData.getIsRead())) {
            query.setParameter(5, Integer.valueOf(inData.getIsRead()));
            countQuery.setParameter(5, Integer.valueOf(inData.getIsRead()));
        }
        Integer total = Integer.valueOf(countQuery.getSingleResult().toString());
        outData.setCount(total);
        query.setFirstResult(page * pageSize);
        query.setMaxResults(pageSize);
        return query.getResultList();
    }

    @Transactional
    public void saveCompy(Long id) {
        UserMonitorXw info = new UserMonitorXw();
//                    userMonitorXw.setCompanyId(Long.valueOf(itemList.get(i).toString()));
//                    userMonitorXw.setDt(new Date());
//                    userMonitorXw.setContent();
//                    userMonitorXw.setIsRead(0L);
//                    HttpUtil.getHBaseResponse()
////                    myMonitorService.save();
        String uri = "http://10.100.48.32:20550/portal:company_base/513847/data:basicinfo";
        Map result = HttpUtil.getHBaseResponse(uri);
        userMonitorXwRepository.save(info);
    }
    
    @Transactional
    public void batchSaveCompanies(List<UserMonitorXw> companiesList) {
        userMonitorXwRepository.save(companiesList);
    }


	@Override
	@Transactional
	public void markRead(UserMonitorXWInfoData infoData) {
		UserMonitorInfoMp infoMp = new UserMonitorInfoMp();
		infoMp.setIsRead(1L);
		infoMp.setMonitorInfoId(infoData.getId());
		infoMp.setUserId(infoData.getUserId());
		if(userMonitorMpRepository.findOneByConditions(infoData.getUserId(), infoData.getId())==null) {
			
			userMonitorMpRepository.save(infoMp);
		};
		
	}

	@Override
	public List<UserMonitor> queryUserMonitorByCondition(UserMonitor info) {
		 String sql = "SELECT u FROM UserMonitor u WHERE userid =?1 and companyId = ?2";
         Query query = em.createQuery(sql, UserMonitor.class);
         query.setParameter(1, info.getUserId());
         query.setParameter(2, info.getCompanyId());
         return query.getResultList();
	}

	@Override
	public Map<String,String> companyFocusMonitorStatus(Long companyId, Long userId) {
		 Map<String,String> foucusMonitorMap = new HashMap<>();
		 String monitorSql = "SELECT u FROM UserMonitor u WHERE userId = ?1 AND companyId = ?2 AND ROWNUM = 1";
	     Query query = em.createQuery(monitorSql,UserMonitor.class);
	     query.setParameter(1, userId);
         query.setParameter(2, companyId);
         List<UserMonitor>  monitorList= query.getResultList();
         foucusMonitorMap.put("isMonitored",  (monitorList.size()>0 && monitorList.get(0).getIsdel()==0)?"1":"0");
         foucusMonitorMap.put("monitorId",  monitorList.size()>0? String.valueOf(monitorList.get(0).getId()):null);
         
         String sql = "SELECT u FROM UserFollow u WHERE USERID = ?1 AND COMPANYID = ?2 AND ROWNUM = 1";
	     Query queryFollow = em.createQuery(sql,UserFollow.class);
	     queryFollow.setParameter(1, userId);
	     queryFollow.setParameter(2, companyId);
	     List<UserFollow>  list= queryFollow.getResultList();
	     foucusMonitorMap.put("isFocused", (list.size()>0&&list.get(0).getIsdel()==0)?"1":"0");
	     foucusMonitorMap.put("focusId", list.size()>0?String.valueOf(list.get(0).getId()):null);
	     return foucusMonitorMap;
	}

	@Override
	public int findUnreadCount(Long userId) {
        String countSql = "SELECT Count(1) FROM USER_MONITOR_XW umx \r\n" + 
        		"inner join USER_MONITOR um on umx.company_id = um.companyid and um.isdel = 0 \r\n"+
        		"left join user_monitorinfo_mp ump on ump.userid = um.userid and ump.monitor_info_id = umx.id  where  um.userid = ?1 AND umx.dt >= um.dt and ump.is_read is null ";
        Query countQuery = em.createNativeQuery(countSql);
        countQuery.setParameter(1, userId);
        return Integer.valueOf(countQuery.getSingleResult().toString());
	}
	
	 public int findMonitorXWByRiskId(String riskId) {
	        String countSql = "SELECT Count(1) FROM USER_MONITOR_XW  where risk_id=?1 ";
	        Query countQuery = em.createNativeQuery(countSql);
	        countQuery.setParameter(1, riskId);
	        return Integer.valueOf(countQuery.getSingleResult().toString());
	    }
}
