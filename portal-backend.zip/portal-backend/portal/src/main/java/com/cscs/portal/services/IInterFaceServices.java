package com.cscs.portal.services;

import com.cscs.portal.dto.InterFaceQueryInfoData;
import com.cscs.portal.entity.Interface;

import java.util.List;

/**
 * Created by levy on 2017/12/2.
 * 接口界面
 */
public interface IInterFaceServices {
    /**
     * 查询接口界面
     */
    List<Object> findInterFaceList(InterFaceQueryInfoData interFaceQueryInfoData);


    /**
     * 数据条数
     */
    int findInterFaceCount(InterFaceQueryInfoData interFaceQueryInfoData);

    /**
     * 更新或者保存
     */
    void saveOrUpdate(Interface interFaceQueryInfoData);

    /**
     * 接口类型返回
     */
    List<Object> findInterFaceTypeList();

    /**
     * 接口类型名称
     */
    String getCtlNameByCtlType(String CtlType);

    void delete(Long interfaceId);
}
