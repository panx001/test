package com.cscs.portal.services;

import java.util.List;

import com.cscs.portal.dto.base.BaseInData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.HotCompanies;

public interface HotItemsServices {

   List<HotCompanies> search();
   
   List<HotCompanies> listByPaging(BaseInData inData,BaseOutData outData);

   //HotCompanies searchById(Long id);

   void save(HotCompanies hotCompany);

   int delete(Long id);
}
