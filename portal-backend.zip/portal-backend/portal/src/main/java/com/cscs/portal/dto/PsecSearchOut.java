package com.cscs.portal.dto;

import java.util.List;

/**
 *  私募机构高级搜索查询返回数据

 * @ClassName: PsecSearchOut

 * @Description: TODO

 * @author: liunn

 * @date: 2018年9月13日 上午11:33:31
 */
public class PsecSearchOut{
	//企业id
	private String companyId;
	//企业名称
	private String companyName;
    //机构类型
    private String orgType;
    //企业状态
    private String companySt;
    //法定代表人
    private String legalPersonName;
    //成立时间
    private String foundDt;
    //登记时间
  	private String regDt;
    //注册资本
    private Object regCapital;
    //注册地
    private String officeAddr;
    //登记编号
    private String regNum;
    //备案产品数
    private String productNum;
    //基金备案阶段
    private List regPhase;
    //管理类型
    private List manageType;
    //运作状态
    private List state;
    //诚信信息
    private String integrityInfo;
    //提示事项
    private String tipInfo;
    //社会信用代码
    private String creditCd;
    //曾用名
    private String oldCompanyNm;
    //证券简称
    private List securitySnm;
    //证券代码
    private List securityCd;
    //是否新三板
	private String islist3;
	//是否发债
	private String isbond;
    //高亮字段
    private List highlightColumns;


	public String getCompanySt() {
		return companySt;
	}

	public void setCompanySt(String companySt) {
		this.companySt = companySt;
	}

	public String getIslist3() {
		return islist3;
	}

	public void setIslist3(String islist3) {
		this.islist3 = islist3;
	}

	public String getIsbond() {
		return isbond;
	}

	public void setIsbond(String isbond) {
		this.isbond = isbond;
	}

	public String getCreditCd() {
		return creditCd;
	}
	public void setCreditCd(String creditCd) {
		this.creditCd = creditCd;
	}
	public String getOldCompanyNm() {
		return oldCompanyNm;
	}
	public void setOldCompanyNm(String oldCompanyNm) {
		this.oldCompanyNm = oldCompanyNm;
	}
	public List getSecuritySnm() {
		return securitySnm;
	}
	public void setSecuritySnm(List securitySnm) {
		this.securitySnm = securitySnm;
	}
	public List getSecurityCd() {
		return securityCd;
	}
	public void setSecurityCd(List securityCd) {
		this.securityCd = securityCd;
	}
	public List getHighlightColumns() {
		return highlightColumns;
	}
	public void setHighlightColumns(List highlightColumns) {
		this.highlightColumns = highlightColumns;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public List getRegPhase() {
		return regPhase;
	}
	public void setRegPhase(List regPhase) {
		this.regPhase = regPhase;
	}
	public String getOrgType() {
		return orgType;
	}
	public void setOrgType(String orgType) {
		this.orgType = orgType;
	}
	public List getManageType() {
		return manageType;
	}
	public void setManageType(List manageType) {
		this.manageType = manageType;
	}
	
	public List getState() {
		return state;
	}
	public void setState(List state) {
		this.state = state;
	}
	public String getIntegrityInfo() {
		return integrityInfo;
	}
	public void setIntegrityInfo(String integrityInfo) {
		this.integrityInfo = integrityInfo;
	}
	public String getTipInfo() {
		return tipInfo;
	}
	public void setTipInfo(String tipInfo) {
		this.tipInfo = tipInfo;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getLegalPersonName() {
		return legalPersonName;
	}
	public void setLegalPersonName(String legalPersonName) {
		this.legalPersonName = legalPersonName;
	}
	public String getFoundDt() {
		return foundDt;
	}
	public void setFoundDt(String foundDt) {
		this.foundDt = foundDt;
	}
	public Object getRegCapital() {
		return regCapital;
	}
	public void setRegCapital(Object regCapital) {
		this.regCapital = regCapital;
	}
	public String getOfficeAddr() {
		return officeAddr;
	}
	public void setOfficeAddr(String officeAddr) {
		this.officeAddr = officeAddr;
	}
	public String getRegNum() {
		return regNum;
	}
	public void setRegNum(String regNum) {
		this.regNum = regNum;
	}
	public String getProductNum() {
		return productNum;
	}
	public void setProductNum(String productNum) {
		this.productNum = productNum;
	}
	
}
