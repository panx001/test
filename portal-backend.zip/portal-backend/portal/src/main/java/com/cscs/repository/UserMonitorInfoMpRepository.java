package com.cscs.repository;

import com.cscs.portal.entity.UserMonitorInfoMp;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * 用户监控信息表
 */
@SuppressWarnings("JpaQlInspection")
public interface UserMonitorInfoMpRepository extends JpaRepository<UserMonitorInfoMp, Long> {

	
	@Query(value="select mp from UserMonitorInfoMp mp where mp.userId=:userId and mp.monitorInfoId=:monitorInfoId")
	UserMonitorInfoMp findOneByConditions(@Param("userId")long userId,@Param("monitorInfoId")long monitorInfoId);
}
