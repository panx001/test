package com.cscs.portal.services;

import com.cscs.portal.dto.UserMonitorInData;
import com.cscs.portal.dto.UserMonitorXWInfoData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.UserFollow;
import com.cscs.portal.entity.UserMonitor;
import com.cscs.portal.entity.UserMonitorXw;

import java.util.List;
import java.util.Map;

public interface MyMonitorService {
    List<UserMonitor> listCompanys(Long userId);

    int findCount(Long userId);

    void save(UserMonitor info);

    void delete(Long id,Long userId);

    List<Object> findMonitorList(UserMonitorInData inData,Long userId,BaseOutData outData);

    List<Object> findMonitorCompy();

    void saveCompy(Long id);
    
   void markRead(UserMonitorXWInfoData infoData);
   
   List<UserMonitor> queryUserMonitorByCondition(UserMonitor info);
   
   void batchSaveCompanies(List<UserMonitorXw> companiesList);
   
   Map<String,String> companyFocusMonitorStatus(Long companyId,Long userId);
   
   int findUnreadCount(Long userId);

   public int findMonitorXWByRiskId(String riskId);
   
   
}
