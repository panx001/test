package com.cscs.portal.dto;

import java.util.List;

/**
 * Created by Dwyane-Wade on 2016/11/25.
 */
public class AssessInfoData {

    private Long assessId;  // 定制Id
    private String assessName;  //名字
    private String company; // 公司
    private String email;   // 邮箱
    private String cellPhone;   // 手机号
    private String needDesc;    // 需求内容
    private List<MailImage> images; //图片信息
    private String imageDir; //上传图片目录

    public Long getAssessId() {
        return assessId;
    }

    public void setAssessId(Long assessId) {
        this.assessId = assessId;
    }

    public String getAssessName() {
        return assessName;
    }

    public void setAssessName(String assessName) {
        this.assessName = assessName;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCellPhone() {
        return cellPhone;
    }

    public void setCellPhone(String cellPhone) {
        this.cellPhone = cellPhone;
    }

    public String getNeedDesc() {
        return needDesc;
    }

    public void setNeedDesc(String needDesc) {
        this.needDesc = needDesc;
    }

    public List<MailImage> getImages() {
        return images;
    }

    public void setImages(List<MailImage> images) {
        this.images = images;
    }

    public String getImageDir() {
        return imageDir;
    }

    public void setImageDir(String imageDir) {
        this.imageDir = imageDir;
    }
}
