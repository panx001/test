package com.cscs.portal.dto;

import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.CompyBasicinfo;

import java.util.List;

/**
 * Created by sh on 2016/8/7.
 * 搜索返回的Dto
 */
public class SearchOutObj extends  BaseOutData{


    List<?> list;

    //搜索输出
    private   List<CompanySearch> companySearcheslist;
    //总条数
    private Integer totalNum;

    public List<?> getList() {
        return list;
    }

    public void seList(List<?> list) {
        this.list = list;
    }

    public List<CompanySearch> getCompanySearcheslist() {
        return companySearcheslist;
    }

    public void setCompanySearcheslist(List<CompanySearch> companySearcheslist) {
        this.companySearcheslist = companySearcheslist;
    }

    public Integer getTotalNum() {
        return totalNum;
    }

    public void setTotalNum(Integer totalNum) {
        this.totalNum = totalNum;
    }
}
