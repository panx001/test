package com.cscs.portal.services.impl;

import com.cscs.portal.dto.UserTraceInfoData;
import com.cscs.portal.entity.Account;
import com.cscs.portal.services.AccountServices;
import com.cscs.repository.AccountRepository;
import com.cscs.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

/**
 * Created by dch on 2016/8/10.
 */
@SuppressWarnings("JpaQlInspection")
@Service
public class AccountServicesImpl implements AccountServices {

    //账号
    @Autowired
    private AccountRepository accountRepository;

    @PersistenceContext
    EntityManager em;

    /**
     * 新规/更新
     */
    @Override
    public Account save(Account account) throws Exception {
        return accountRepository.save(account);
    }

    /**
     * 删除
     */
    @Override
    @Transactional
    public void delete(Account account) throws Exception {
        accountRepository.delete(account);
    }

    /**
     * 查找账号是否存在
     */
    public Account findByAccountNm(String accountNm) {
        List<Account> accountList = accountRepository.findByAccountNm(accountNm);
        if (accountList.size() > 0) {
            return accountList.get(0);
        }
        return null;
    }

    /**
     * 查找账号是否存在加上名字
     */
    public Account findByAccountNmAndName(String accountNm, String userName) {
        List<Account> accountList = accountRepository.findByAccountNmAndName(accountNm, userName);
        if (accountList.size() > 0) {
            return accountList.get(0);
        }
        return null;
    }

    /**
     * 密码是否正确
     */
    public Account findByAccount(String accountNm, String accountPw) {
        List<Account> accountList = accountRepository.findByAccount(accountNm, accountPw);
        if (accountList.size() > 0) {
            return accountList.get(0);
        }
        return null;
    }

    /**
     * 修改密码
     */
    @Transactional
    public Integer updateUserPwd(String accountNm, String accountPw) {
        //找回密码不成功
        int num = 1;
        Query query = em.createQuery("update Account as p set p.accountPw =?1 where p.accountNm=?2");
        query.setParameter(1, accountPw);
        query.setParameter(2, accountNm);
        int result = query.executeUpdate(); //影响的记录数
        if (result > 0) {
            //找回密码成功
            num = 0;
        }
        return num;
    }

    /**
     * 查询账号是否存在
     */
    public Account findByUserId(Long userId) {
        return accountRepository.findByUserId(userId);
    }

    /**
     * 用户数据导出
     */
    @Override
    public List<Object> findAccountList(String startDtString, String endDtString) {
        String sql = "SELECT  a.ACCOUNT_NM,u.USER_NM,NVL(u.COMPANY_NM,'NULL'),TO_CHAR(a.REGEDIT_DT,'YYYY-MM-DD HH:MM:SS'),c.AUTHORIZE_NM,TO_CHAR(c.END_DT,'YYYY-MM-DD HH:MM:SS') FROM ACCOUNT  a\n" +
                "INNER JOIN ACCOUNT_AUTHO_XW b ON a.ACCOUNT_ID = b.ACCOUNT_ID\n" +
                "INNER JOIN AUTHORIZE c ON b.AUTHO_ID = c.AUTHORIZE_ID\n" +
                "INNER JOIN USER_BASICINFO  u ON a.USER_ID=u.USER_ID  \n" +
                "WHERE (COMPANY_NM <> '中证征信' OR  COMPANY_NM IS NULL)\n";

        if (!StringUtils.isEmpty(startDtString)) {
            sql += " and to_char(a.REGEDIT_DT, 'yyyy-MM-dd') >= ?1\n";
        }

        if (!StringUtils.isEmpty(endDtString)) {
            sql += " and to_char(a.REGEDIT_DT, 'yyyy-MM-dd') <= ?2\n";
        }

        sql += "ORDER BY a.REGEDIT_DT desc";

        Query query = em.createNativeQuery(sql);

        if (!StringUtils.isEmpty(startDtString)) {
            query.setParameter(1, startDtString);
            query.setParameter(1, startDtString);
        }

        if (!StringUtils.isEmpty(endDtString)) {
            query.setParameter(2, endDtString);
            query.setParameter(2, endDtString);
        }

        return query.getResultList();
    }

    /**
     * 访问数据导出
     */
    @Override
    public List<Object> visitRecord(UserTraceInfoData userTraceInfoData) {
        String sqlWhere = "";
        if (!StringUtil.isEmpty(userTraceInfoData.getStartDtString())) {
            sqlWhere += " a.VISIT_DT  >= TO_DATE(" + "'" + userTraceInfoData.getStartDtString() + "'" + ",'YYYY-MM-DD') and ";
        }
        if (!StringUtil.isEmpty(userTraceInfoData.getEndDtString())) {
            sqlWhere += "   TO_DATE(" + "'" + userTraceInfoData.getEndDtString() + "'" + ",'YYYY-MM-DD') >= a.VISIT_DT  and  ";
        }
        String sql = "select  pathStr,interface_nm,sum(B.CN)sumCount from\n" +
                "  (select path,nvl(substr(path,1,instr(path,'/',1,4)),path) pathStr,count(path) CN,interface_nm from(\n" +
                "    select substr(visit_Url,0,instr(visit_Url,'/',-1)) path,b.INTERFACE_NM interface_nm from user_trace a\n" +
                "      inner join INTERFACE b on instr(a.VISIT_URL,b.INTERFACE_URL)>0\n" +
                "    where\n" + sqlWhere +
                "      substr(a.visit_Url,0,7) ='/portal'\n" +
                "      and\n" +
                "      user_id in(\n" +
                "        select  a.user_id from account  a\n" +
                "          inner join user_basicinfo  u\n" +
                "            on a.user_id=u.USER_ID where  company_NM <>'中证征信' or company_NM is NULL \n" +
                "      )\n" +
                "  )group by path,interface_nm) B  GROUP BY pathStr,interface_nm order by sumCount desc";

        return em.createNativeQuery(sql).getResultList();
    }

    @Override
    public Object findAccountName(Long userId) {
        String sql = "SELECT ACCOUNT_NM FROM ACCOUNT WHERE USER_ID = '" + userId + "'";
        Query query = em.createNativeQuery(sql);
        return query.getSingleResult();
    }

    @Override
    public List<Object> getAccount(String accountNm, String accountPw) {
    	/*String sql = "SELECT A.ACTIVITY_TYPE,B.ROLE_ID,D.DEFAULT_FLG,A.REGEDIT_DT,A.ACCOUNT_ID,A.USER_ID,D.END_DT FROM ACCOUNT A\n" +
    			"LEFT JOIN ACCOUNT_ROLE_XW B ON A.ACCOUNT_ID = B.ACCOUNT_ID\n" +
    			"INNER JOIN ACCOUNT_AUTHO_XW C ON A.ACCOUNT_ID = C.ACCOUNT_ID\n" +
    			"INNER JOIN AUTHORIZE D ON C.AUTHO_ID  = D.AUTHORIZE_ID\n" +
    			"WHERE ACCOUNT_NM = ?1\n AND ACCOUNT_PW = ?2";*/
    	String sql = "SELECT A.ACTIVITY_TYPE,B.ROLE_ID,D.DEFAULT_FLG,A.REGEDIT_DT,A.ACCOUNT_ID,A.USER_ID,D.END_DT FROM ACCOUNT A\n" +
    			"LEFT JOIN ACCOUNT_ROLE_XW B ON A.ACCOUNT_ID = B.ACCOUNT_ID\n" +
    			"LEFT JOIN ACCOUNT_AUTHO_XW C ON A.ACCOUNT_ID = C.ACCOUNT_ID\n" +
    			"LEFT JOIN AUTHORIZE D ON C.AUTHO_ID  = D.AUTHORIZE_ID\n" +
    			"WHERE A.ACCOUNT_NM = ?1\n AND A.ACCOUNT_PW = ?2";
        Query query = em.createNativeQuery(sql);
        query.setParameter(1, accountNm);
        query.setParameter(2, accountPw);
        return query.getResultList();
    }
}
