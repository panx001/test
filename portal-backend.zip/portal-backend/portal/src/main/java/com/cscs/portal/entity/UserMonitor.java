package com.cscs.portal.entity;

import javax.persistence.*;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "USER_MONITOR", schema = "CS_PORTAL", catalog = "")
public class UserMonitor {
    private long id;
    private long userId;
    private long companyId;
    private Date dt;
    private Long isdel;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_USER_MONITOR")
    @SequenceGenerator(sequenceName = "SEQ_USER_MONITOR", name = "SEQ_USER_MONITOR")
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "USERID")
    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    @Basic
    @Column(name = "COMPANYID")
    public long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(long companyId) {
        this.companyId = companyId;
    }

    @Basic
    @Column(name = "DT")
    public Date getDt() {
        return dt;
    }

    public void setDt(Date dt) {
        this.dt = dt;
    }

    @Basic
    @Column(name = "ISDEL")
    public Long getIsdel() {
        return isdel;
    }

    public void setIsdel(Long isdel) {
        this.isdel = isdel;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UserMonitor that = (UserMonitor) o;
        return id == that.id &&
                userId == that.userId &&
                companyId == that.companyId &&
                Objects.equals(dt, that.dt) &&
                Objects.equals(isdel, that.isdel);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, userId, companyId, dt, isdel);
    }
}
