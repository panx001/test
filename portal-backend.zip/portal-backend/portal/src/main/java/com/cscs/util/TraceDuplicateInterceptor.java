package com.cscs.util;

import java.net.InetAddress;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.cscs.portal.security.util.SpringContextAware;
import com.cscs.portal.services.CacheServices;
import com.cscs.portal.services.UserTraceServices;

/**
 * 这个拦截器实现了重复登陆和用户跟踪的功能
 */
@Component
public class TraceDuplicateInterceptor extends HandlerInterceptorAdapter {
    protected final Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    private StringRedisTemplate rt;

    @Value("${userTrack.flag}")
    String flag;

//    @Autowired
//    @Qualifier("exampleTraceServicesImpl")
//    ExampleTraceServices exampleTraceServicesImpl;
    
    @Autowired
    @Qualifier("userTraceServicesImpl")
    UserTraceServices userTraceServices;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        //目前通过header - smallapp来区分是否从微信小程序过来的接口
        String smallApp = request.getHeader("smallapp");
        Object userId = request.getAttribute("userId");

        //处理重复登陆 - 目前只针对web 做重复登陆限制
        if (StringUtils.isEmpty(smallApp) && !StringUtils.isEmpty(userId)) {//web端
            String curBrowser = request.getHeader("browser");
            if(curBrowser != null) {
                String browser = rt.opsForValue().get("login_" + userId);
                if (browser != null && !curBrowser.equals(browser)) {
                    // 返回到登录界面
                    response.setHeader("Access-Control-Allow-Origin", "*");
                    response.setStatus(406);
                    response.sendError(406);
                    return false;
                }
                rt.opsForValue().set("login_" + userId, curBrowser);
                rt.expire("login_" + userId, 2, TimeUnit.HOURS);
            }
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
       try {
    	String smallApp = request.getHeader("smallapp");
        String path = request.getRequestURI();
        if(request.getQueryString() != null){
            path += "?" + request.getQueryString();
        }
        Object userId = request.getAttribute("userId");
        if (!StringUtils.isEmpty(userId) && "open".equals(flag)) {
            if (userTraceServices == null) {
//                BeanFactory factory = WebApplicationContextUtils.getRequiredWebApplicationContext(request.getServletContext());
            	userTraceServices = (UserTraceServices) SpringContextAware.getBean("userTraceServicesImpl");
            }

            //区分企业图谱调用还是关联关系图谱调用
            if(path.indexOf("/pfcompany/company/company_id")>0 &&!StringUtil.isEmpty(request.getHeader("Referer"))&&request.getHeader("Referer").indexOf("/maps/related-risk/")>0 ){
                //关联关系进行调用，不记录
                return;
            }

            if (userTraceServices.tracePath(path)) {
	            String ip = request.getHeader("x-forwarded-for");
	            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
	                ip = request.getHeader("Proxy-Client-IP");
	            }
	            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
	                ip = request.getHeader("WL-Proxy-Client-IP");
	            }
	            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
	                ip = request.getRemoteAddr();
	            }
	            if (ip.equals("0:0:0:0:0:0:0:1")) {
	                ip = InetAddress.getLocalHost().getHostAddress().toString();
	            }
	            this.userTraceServices.addUserTrace(Long.valueOf(String.valueOf(userId)), path, ip);
	        }
        }
    }catch (Exception e) {
        logger.error("", e);
    }
   }
}
