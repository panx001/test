package com.cscs.portal.controller;

import com.cscs.portal.dto.AccountQueryInData;
import com.cscs.portal.dto.AccountQueryInfoData;
import com.cscs.portal.dto.AccountQueryOutData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.UserBasicinfo;
import com.cscs.portal.services.AccountQueryServices;
import com.cscs.portal.services.AccountRoleXwServices;
import com.cscs.portal.services.UserBasicInfoServices;
import com.cscs.util.DateUtils;
import com.cscs.util.Md5Util;
import org.apache.poi.hssf.usermodel.*;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.sql.Timestamp;
import java.util.*;

/**
 * Created by dch on 2016/11/14.
 */

@CrossOrigin
@RestController
@RequestMapping(value = "/accountQuery")
public class AccountQueryController {

    @Autowired
    AccountQueryServices queryServices;

    @Autowired
    AccountRoleXwServices accountRoleXwServices;
    
    @Autowired
    private UserBasicInfoServices userBasicInfoServices; 

    //账户查询信息
    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/findAccountCount", method = RequestMethod.POST)
    public BaseOutData getAccountQueryCount(@RequestBody AccountQueryInfoData infoData) {
        BaseOutData out = new BaseOutData();
        int count = queryServices.findAccountCount(infoData);
        out.setCount(count);
        out.setCode("0");
        out.setMessage("返回成功!");
        return out;
    }

    //账户查询信息
    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/findAccountQuery", method = RequestMethod.POST)
    public BaseOutData getAccountQueryOutData(@RequestBody AccountQueryInfoData infoData) {
        List<AccountQueryOutData> accountList = new ArrayList<>();
        BaseOutData out = new BaseOutData();
        int count = queryServices.findAccountCount(infoData);
        out.setCount(count);
        List<Object> itemList = queryServices.findAccountAll(infoData);
        for (int i = 0; i < itemList.size(); i++) {
            AccountQueryOutData outData = new AccountQueryOutData();
            Object[] item = (Object[]) itemList.get(i);
            outData.setAccountNm(item[0] == null ? null : item[0].toString());
            outData.setRegeditDt(item[1] == null ? null : item[1].toString());
            outData.setRoleNm(item[2] == null ? null : item[2].toString());
            outData.setUserId(item[3] == null ? 0 : Long.valueOf(String.valueOf(item[3])));
            accountList.add(outData);
        }
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("result",accountList);
        out.setData(map);
        out.setCode("0");
        return out;
    }

    //新建账户
    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public BaseOutData save(@RequestBody AccountQueryInData inData) {
        BaseOutData outData = new BaseOutData();
        try {
        	 
            int count = queryServices.findByAccountNm(inData.getAccountNm());
            if (count == 1) {
                outData.setCode("1");
                outData.setMessage("该用户已注册！");
                return outData;
            }
            queryServices.saveAccount(inData);
            outData.setCode("0");
        } catch (Exception e) {
            outData.setCode("1");
        }
        return outData;
    }

    
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public BaseOutData update(@RequestBody AccountQueryInData inData) {
        BaseOutData outData = new BaseOutData();
        try {
            queryServices.updateAccount(inData);
            outData.setCode("0");
        } catch (Exception e) {
            outData.setCode("1");
        }
        return outData;
    }

    
    
    /**
     * 账户导入
     *
     * @return
     */
    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/uploadAccount", method = RequestMethod.POST)
    public BaseOutData uploadAccount(@RequestBody Map upLoadMap,HttpServletRequest request) {
        BaseOutData outData = new BaseOutData();
        try {
        	Long userId = Long.valueOf((String)request.getAttribute("userId"));
            Map sheetMap = (Map) upLoadMap.get("upload");
            List accountList = (List) sheetMap.get("Sheet1");
            for (int i = 0; i < accountList.size(); i++) {
                Map accountMap = (Map) accountList.get(i);
                //账户名
                String accountNm = (String) accountMap.get("账户名");
                //姓名
                String userName = (String) accountMap.get("姓名");
                //公司名称
                String compayName = (String) accountMap.get("公司名称");
                //邮箱
                String email = (String) accountMap.get("邮箱");
                //密码(默认12345678)
                String pwd = Md5Util.MD5("12345678");

                int count = queryServices.findByAccountNm(accountNm);
                if (count != 0) {
                    queryServices.updateUserPwd(accountNm, pwd);
                } else {
                    //新增
                    //用户信息
//                    UserBasicinfo userInfo = new UserBasicinfo();
//                    userInfo.setUserNm(userName);
//                    userInfo.setUpdtDt(new Timestamp(new Date().getTime()));
//                    userInfo.setEmail(email);
//                    userInfo.setCompanyNm(compayName);
//                    userInfo = queryServices.saveBasic(userInfo);
//                	Long userId = userBasicInfoServices.generatedValue();
                    UserBasicinfo userInfo = new UserBasicinfo();
                    userInfo.setUserNm(userName);
                    Date date = new Date();
                    userInfo.setUpdtDt(new Timestamp(date.getTime()));
                    userInfo.setEmail(email);
                    userInfo.setCompanyNm(compayName);
                    userInfo.setAccountPw(pwd);
                    userInfo.setAccountNm(accountNm);
                    userInfo.setRegeditDt(date);
                    userInfo.setCreateDt(date);
                    //导入
                    userInfo.setRegeditType(1L);
//                    userInfo.setUserId(userId);
                    userInfo.setCreateBy(userId);
                    userInfo.setUpdtBy(userId);
                    userInfo.setActivityType(2L);
                    
                    userInfo = queryServices.saveBasic(userInfo);
                    
                    //账户信息
//                    Account account = new Account();
//                    account.setUserId(userInfo.getUserId());
//                    account.setAccountNm(accountNm);
//                    account.setAccountPw(pwd);
//                    account.setRegeditDt(new Date());
//                    account.setCreateDt(new Timestamp(new Date().getTime()));
//                    account.setCreateBy(userInfo.getUserId());
//                    account.setActivityType(2L);
//
//                    queryServices.saveAccount(account);

                    accountRoleXwServices.setAccountRoleXw(userInfo.getUserId(), "一般用户");

                }
            }
            outData.setCode("0");
            outData.setMessage("导入成功");
        } catch (Exception e) {
            outData.setCode("1");
            outData.setMessage(e.getMessage());
        }
        return outData;
    }

    /**
     * 账户维护excel生成
     *
     * @return
     */
    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/exportAccount", method = RequestMethod.POST)
    public BaseOutData exportAccount(@RequestBody AccountQueryInfoData infoData) {
        BaseOutData outData = new BaseOutData();
        try {
            List<Object> accountList = queryServices.findAccountAllNoPaging(infoData);
            HSSFWorkbook wb = new HSSFWorkbook();
            HSSFSheet sheet = wb.createSheet(DateUtils.getCurrentDate());
            // 3.在sheet中添加表头第0行，老版本poi对excel行数列数有限制short
            HSSFRow row = sheet.createRow((int) 0);
            //设置宽度
            sheet.setColumnWidth(0, 30 * 256);
            sheet.setColumnWidth(1, 30 * 256);
            sheet.setColumnWidth(2, 30 * 256);
            sheet.setColumnWidth(3, 30 * 256);
            // 4.创建单元格，设置值表头，设置表头居中
            HSSFCellStyle style = wb.createCellStyle();
            // 居中格式
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            // 设置表头
            HSSFCell cell = row.createCell(0);
            cell.setCellValue("用户ID");
            cell.setCellStyle(style);

            cell = row.createCell(1);
            cell.setCellValue("用户名称");
            cell.setCellStyle(style);

            cell = row.createCell(2);
            cell.setCellValue("公司名称");
            cell.setCellStyle(style);

            cell = row.createCell(3);
            cell.setCellValue("注册日期");
            cell.setCellStyle(style);

            // 循环将数据写入Excel
            Object[] item = null;
            for (int i = 0; i < accountList.size(); i++) {
                row = sheet.createRow((int) i + 1);
                // 创建单元格，设置值
                item = (Object[]) accountList.get(i);
                row.createCell(0).setCellValue((String)item[0]);
                row.createCell(1).setCellValue((String)item[1]);
                row.createCell(2).setCellValue((String)item[2]);
                row.createCell(3).setCellValue(item[3]==null?null:item[3].toString());
            }

            String filepath = getClass().getClassLoader().getResource("").getPath() + "templates";
            File path = new File(filepath);
            if (!path.exists()) {
                path.mkdirs();
            }
            File file = new File(filepath +  File.separator + "中证客户信息统计表.xls");
            OutputStream ouputStream = new FileOutputStream(file);
            wb.write(ouputStream);
            ouputStream.flush();
            ouputStream.close();
            //判断文件是否存在
            if (file.exists() && file.isFile()) {
                outData.setCode("0");
                outData.setMessage("exportAccountDownload");
            }
        } catch (Exception ex) {
            outData.setCode("1");
            outData.setMessage("导出失败！！"+ex.getMessage());
        }
        return outData;
    }

    /**
     * 帐号维护excel下载
     */
    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/exportAccountDownload", method = RequestMethod.GET)
    public void exportAccountDownload(HttpServletResponse response) throws Exception {
        File file = null;
        InputStream fis = null;
        ServletOutputStream out = null;

        try {
            String filepath = getClass().getClassLoader().getResource("").getPath() + "/templates/";
            String fileName = "中证客户信息统计表.xls".toString(); // 文件的默认保存名
            file = new File(filepath + fileName);

            // 读到流中
            fis = new FileInputStream(file);// 文件的存放路径

            // 设置输出的格式
            response.reset();
            response.setContentType("application/vnd.ms-excel");
            response.setHeader("Content-disposition", "attachment;filename=" + URLEncoder.encode("中证客户信息统计表", "UTF-8") + ".xls");
            response.setHeader("Access-Control-Allow-Origin", "*");

            out = response.getOutputStream();
            // 循环取出流中的数据
            int len;
            byte[] buffer = new byte[512];

            while ((len = fis.read(buffer)) > 0) out.write(buffer, 0, len);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) fis.close();
            if (out != null) out.close();
            if (file != null) file.delete();
        }
    }
}