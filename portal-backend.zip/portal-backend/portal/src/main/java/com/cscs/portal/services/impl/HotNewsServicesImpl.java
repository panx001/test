package com.cscs.portal.services.impl;

import com.cscs.portal.dto.HotNewsInData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.HotNews;
import com.cscs.repository.HotNewsRepository;
import com.cscs.portal.services.HotNewsServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;
import java.util.List;

/**
 * Created by dch on 2016/8/10.
 */
@SuppressWarnings("JpaQlInspection")
@Service
public class HotNewsServicesImpl implements HotNewsServices {

    @Autowired
    private HotNewsRepository repository;

    @Autowired
    EntityManager em;

    public List<HotNews> search(HotNewsInData inData,BaseOutData outData) {
        int page = inData.getPage() == 0 ? 0 : inData.getPage() - 1;
        int pageSize = inData.getPageSize() == 0 ? 10 : inData.getPageSize();
        String sql = "SELECT h FROM HotNews h WHERE isdel = 0";
        String countSql = "SELECT count(1) FROM hot_news  WHERE isdel = 0";
        if (inData.getStatus() == 1) {
            sql += " AND status = 1";
            countSql+=" AND status = 1";
        }
        sql += " ORDER BY POSTDT DESC";
        Query query = em.createQuery(sql);
        Query countQuery = em.createNativeQuery(countSql);
        Integer total = Integer.valueOf(countQuery.getSingleResult().toString());
        //int total = query.getResultList().size();
        outData.setCount(total);
        query.setFirstResult(page * pageSize);
        query.setMaxResults(pageSize);
        return query.getResultList();
    }

    public HotNews searchById(Long id) {
        String sql = "SELECT h FROM HotNews h WHERE isdel = 0 and id = ?1";
        Query query = em.createQuery(sql);
        query.setParameter(1, id);
        return (HotNews) query.getSingleResult();
    }

    @Transactional
    public void save(HotNews hotNews) {
        repository.save(hotNews);
    }

    @Transactional
    public int delete(Long id) {
        // repository.deleteById(id);
        String sql = "UPDATE HOT_NEWS SET ISDEL = 1 WHERE ID = " + id;
        return em.createNativeQuery(sql).executeUpdate();
    }
}
