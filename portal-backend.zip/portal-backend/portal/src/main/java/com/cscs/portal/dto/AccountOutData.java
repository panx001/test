package com.cscs.portal.dto;

import com.cscs.portal.dto.base.BaseOutData;

import java.util.Date;

/**
 * Created by sh on 2016/8/7.
 */
public class AccountOutData extends BaseOutData {

    private long accountId;
    private long userId;
    private String accountNm;
//    private String loginIp;
//    private Date loginDt;
//    private Date regeditDt;
//    private String regeditIp;
//    private Long regeditType;
//    private long activityType;
    private String token;

    private String flag; //验证是否为管理员

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public long getAccountId() {
        return accountId;
    }

    public void setAccountId(long accountId) {
        this.accountId = accountId;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getAccountNm() {
        return accountNm;
    }

    public void setAccountNm(String accountNm) {
        this.accountNm = accountNm;
    }

//    public String getLoginIp() {
//        return loginIp;
//    }
//
//    public void setLoginIp(String loginIp) {
//        this.loginIp = loginIp;
//    }
//
//    public Date getLoginDt() {
//        return loginDt;
//    }
//
//    public void setLoginDt(Date loginDt) {
//        this.loginDt = loginDt;
//    }
//
//    public Date getRegeditDt() {
//        return regeditDt;
//    }
//
//    public void setRegeditDt(Date regeditDt) {
//        this.regeditDt = regeditDt;
//    }
//
//    public String getRegeditIp() {
//        return regeditIp;
//    }
//
//    public void setRegeditIp(String regeditIp) {
//        this.regeditIp = regeditIp;
//    }
//
//    public Long getRegeditType() {
//        return regeditType;
//    }
//
//    public void setRegeditType(Long regeditType) {
//        this.regeditType = regeditType;
//    }
//
//    public long getActivityType() {
//        return activityType;
//    }
//
//    public void setActivityType(long activityType) {
//        this.activityType = activityType;
//    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
