package com.cscs.portal.dto;

/**
 * Created by dch on 2016/11/7.
 * 角色
 */
public class RoleInfoData {
    private Long roleId;
    private String roleNm; //角色名称
    private Long accountId; //当前账户ID
    private String roleIdArray; //角色ID数组

    public String getRoleIdArray() {
        return roleIdArray;
    }

    public void setRoleIdArray(String roleIdArray) {
        this.roleIdArray = roleIdArray;
    }

    public Long getRoleId() {
        return roleId;
    }

    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }


    public String getRoleNm() {
        return roleNm;
    }

    public void setRoleNm(String roleNm) {
        this.roleNm = roleNm;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }
}
