package com.cscs.repository;

import com.cscs.portal.entity.UserMonitor;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * 用户监控信息表
 */
@SuppressWarnings("JpaQlInspection")
public interface UserMonitorRepository extends JpaRepository<UserMonitor, Long> {

}
