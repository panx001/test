package com.cscs.repository;

import com.cscs.portal.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by dch on 2016/11/2.
 */
@SuppressWarnings("JpaQlInspection")
public interface AccountRepository extends JpaRepository<Account, Long> {

    //判断账户是否存在
    @Query(value = "select pu from Account pu where pu.accountNm=:accountNm")
    List<Account> findByAccountNm(@Param("accountNm") String accountNm);

    //判断账户是否存在加上名字一起判断
    @Query(value = "select pu from Account pu where pu.accountNm in (:accountNm,:userName)")
    List<Account> findByAccountNmAndName(@Param("accountNm") String accountNm,@Param("userName") String userName);

    //判断账户密码是否正确
    @Query(value = "select pu from Account pu where pu.accountNm=:accountNm and pu.accountPw=:accountPw")
    List<Account> findByAccount(@Param("accountNm") String accountNm, @Param("accountPw") String accountPw);

    //判断账户密码是否正确
    @Query(value = "select pu from Account pu where pu.userId=:userId")
    Account findByUserId(@Param("userId") Long userId);
}
