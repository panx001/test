package com.cscs.portal.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cscs.portal.dto.PFCompySearchIn;
import com.cscs.portal.dto.PsecSearchConditon;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.services.PFCompyScoreServices;
import com.cscs.portal.services.PFundSearchServices;
import com.cscs.util.Contants;
import com.cscs.util.DateUtils;
import com.cscs.util.HttpUtil;
import com.cscs.util.JsonArrayIntergerComparator;
import com.cscs.util.SolrUtil;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

@CrossOrigin
@RestController
@RequestMapping(value = "/pfcompy")
public class PFCompyController {

    //私募总风险
    public static String PFCOMPY_TOTAL = "pf_total";
    //风险机构统计
    public static String PFCOMPY_RISK = "pf_risk";
    //风险分类统计
    public static String PFCOMPY_RISKTYPE = "pf_riskType";
    //特别提示-中基协提示事项
    public static String PFCOMPY_PFTIPINFO = "pf_pftipinfo";
    //特别提示-诚信信息
    public static String PFCOMPY_PFWARNINGS = "pf_pfwarnings";
    //特别提示-取消备案机构
    public static String PFCOMPY_REVOKELIST = "pf_revokelist";
    //风险区域区域top10
//    public static String PFCOMPY_REGION_TOP10 = "pf_r_top10";
    //风险区域全国维度统计
    public static String PFCOMPY_COUNTRY_COUNT = "pf_c_cn";
    //风险区域省市统计
    public static String PFCOMPY_REGION_COUNT = "pf_r_cn";

    @Autowired
    PFCompyScoreServices scoreServices;

    @Autowired
    private StringRedisTemplate rt;
    @Autowired
    private PFundSearchServices pFundSearchServices;

    /**
     * 私募总风险
     *
     * @return
     */
    @RequestMapping(value = "/total", method = RequestMethod.GET)
    public BaseOutData getTotal() {
        BaseOutData outData = new BaseOutData();
        try {
            Map data = new HashMap();
            Calendar calendar = Calendar.getInstance();
            Object out = rt.opsForValue().get(PFCOMPY_TOTAL + calendar.get(Calendar.DATE));
            if (out == null) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("pfCompyCount", scoreServices.searchSum());
                jsonObject.put("riskCount", scoreServices.highRisk());
                jsonObject.put("riskIndex", scoreServices.searchWeigh());
                jsonObject.put("date", DateUtils.getCurrentDate());
                data.put("result", jsonObject);

                rt.opsForValue().set(PFCOMPY_TOTAL + calendar.get(Calendar.DATE), jsonObject.toString());
                rt.expire(PFCOMPY_TOTAL + calendar.get(Calendar.DATE), Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
            } else {
                data.put("result", JSON.parse(String.valueOf(out)));
            }
            outData.setData(data);
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        outData.setCode("0");
        outData.setMessage("返回成功!");
        return outData;
    }

    /**
     * 风险机构统计
     *
     * @return
     */
    @RequestMapping(value = "/riskCount/{type}", method = RequestMethod.GET)
    public BaseOutData getRiskCount(@PathVariable int type) {
        BaseOutData outData = new BaseOutData();
        try {
            Map data = new HashMap();
            Calendar calendar = Calendar.getInstance();
            Object out = rt.opsForValue().get(PFCOMPY_RISK + type + calendar.get(Calendar.DATE));
            if (out == null) {
                TreeMap<String, Map<String, String>> d = new TreeMap<>();
                List<Object> itemList = scoreServices.searchByTime(type);
                for (int i = 0; i < itemList.size(); i++) {
                    Object[] item = (Object[]) itemList.get(i);
                    Map content = null;
                    if (!d.containsKey(item[2].toString())) {
                        content = new HashMap<String, String>();
                        d.put(item[2].toString(), content);
                    } else {
                        content = d.get(item[2].toString());
                    }
                    content.put(checkLevel(item[1].toString()), item[0]);
                }
//                JSONObject jsonObject = new JSONObject();
//                List<Object> itemList = scoreServices.searchByTime(type);
//                for (int i = 0; i < itemList.size(); i++) {
//                    Object[] item = (Object[]) itemList.get(i);
//                    JSONObject content = null;
//                    if (!jsonObject.containsKey(item[2].toString())) {
//                        content = new JSONObject();
//                        jsonObject.put(item[2].toString(), content);
//                    } else {
//                        content = jsonObject.getJSONObject(item[2].toString());
//                    }
//                    content.put(checkLevel(item[1].toString()), item[0]);
//                }
//                List<Object> weightList = scoreServices.searchWeightByTime(type);
//                for (int i = 0; i < weightList.size(); i++) {
//                    Object[] weigh = (Object[]) weightList.get(i);
//                    JSONObject content = jsonObject.getJSONObject(weigh[1].toString());
//                    if (content != null) content.put("风险指数", weigh[0]);
//                }
                data.put("result", d);

                rt.opsForValue().set(PFCOMPY_RISK + type + calendar.get(Calendar.DATE), JSON.toJSONString(d));
                rt.expire(PFCOMPY_RISK + type + calendar.get(Calendar.DATE), Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
            } else {
                data.put("result", JSON.parse(String.valueOf(out)));
            }
            outData.setData(data);
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        outData.setCode("0");
        outData.setMessage("返回成功!");
        return outData;
    }

    /**
     * 风险分类
     *
     * @return
     */
    @RequestMapping(value = "/riskType/{type}", method = RequestMethod.GET)
    public BaseOutData getRiskType(@PathVariable int type) {
        BaseOutData outData = new BaseOutData();
        try {
            Map data = new HashMap();
            Calendar calendar = Calendar.getInstance();
            Object out = rt.opsForValue().get(PFCOMPY_RISKTYPE + type + calendar.get(Calendar.DATE));
            if (out == null) {
                JSONArray jsonArray = new JSONArray();
                List<Object> itemList = scoreServices.searchByType(type);
                for (int i = 0; i < itemList.size(); i++) {
                    Object[] item = (Object[]) itemList.get(i);
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("compyId", item[0]);
                    jsonObject.put("compyNm", item[1]);
                    jsonObject.put("score", item[2]);
                    jsonArray.add(jsonObject);
                }
                data.put("result", jsonArray);

                rt.opsForValue().set(PFCOMPY_RISKTYPE + type + calendar.get(Calendar.DATE), jsonArray.toString());
                rt.expire(PFCOMPY_RISKTYPE + type + calendar.get(Calendar.DATE), Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
            } else {
                data.put("result", JSON.parse(String.valueOf(out)));
            }
            outData.setData(data);
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        outData.setCode("0");
        outData.setMessage("返回成功!");
        return outData;
    }

    /**
     * 中基协提示事项
     *
     * @return
     */
    @RequestMapping(value = "/AMACHints", method = RequestMethod.GET)
    public BaseOutData getAMACHints() {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            Calendar calendar = Calendar.getInstance();
            out = rt.opsForValue().get(PFCOMPY_PFTIPINFO + calendar.get(Calendar.DATE));
            if (out == null) {
                out = HttpUtil.getHBaseResponse(Contants.HBASE_PFCOMPY_PFWARNINGS_URL);
                out = JsonArrayIntergerComparator.sortJSONArray((JSONArray) out,"val");
                if(out!=null) {
                    rt.opsForValue().set(PFCOMPY_PFTIPINFO + calendar.get(Calendar.DATE), out.toString());
                    rt.expire(PFCOMPY_PFTIPINFO + calendar.get(Calendar.DATE), Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 诚信信息
     *
     * @return
     */
    @RequestMapping(value = "/faithInfo", method = RequestMethod.GET)
    public BaseOutData getFaithInfo() {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            Calendar calendar = Calendar.getInstance();
            out = rt.opsForValue().get(PFCOMPY_PFWARNINGS + calendar.get(Calendar.DATE));
            if (out == null) {
                out = HttpUtil.getHBaseResponse(Contants.HBASE_PFCOMPY_PFTIPINFO_URL);
                out = JsonArrayIntergerComparator.sortJSONArray((JSONArray) out,"val");
                if(out!=null) {
                    rt.opsForValue().set(PFCOMPY_PFWARNINGS + calendar.get(Calendar.DATE), out.toString());
                    rt.expire(PFCOMPY_PFWARNINGS + calendar.get(Calendar.DATE), Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 取消备案机构
     *
     * @return
     */
    @RequestMapping(value = "/cancelRecord", method = RequestMethod.GET)
    public BaseOutData getCancelRecord() {
    	BaseOutData outData = new BaseOutData();
        List<Map> returnList = new ArrayList<Map>();
        long numFound = 0L;
        try {
            //创建Solr服务对象，通过此对象向solr服务发起请求
            SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_PFUND_METHOD);
            //创建查询对象
            SolrQuery query = new SolrQuery();
            //设置公共查询参数
            query = pFundSearchServices.setSolrQuery(new PsecSearchConditon(), query);
            
            /*****************************过滤条件start*****************************************/
            //是否取消备案
            query.addFilterQuery("is_revoke:1");
            /*****************************过滤条件end*****************************************/
            //执行查询
            QueryResponse response = solrServer.query(query);
            //返回结果数量
            numFound = response.getResults().getNumFound();
            //获取返回数据
    		returnList = pFundSearchServices.cancelRecord(response);
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", returnList);
        outData.setCode("0");
        outData.setCount((int) numFound);
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

//    /**
//     * 区域风险指数TOP10
//     *
//     * @return
//     */
////
//    @RequestMapping(value = "/regionTop10/{region}", method = RequestMethod.GET)
//    public BaseOutData getRegionTop10(@PathVariable String region) {
//        BaseOutData outData = new BaseOutData();
//        try {
//            Map data = new HashMap();
//            Calendar calendar = Calendar.getInstance();
//            Object out = rt.opsForValue().get(PFCOMPY_REGION_TOP10 + region + calendar.get(Calendar.DATE));
//            if (out == null) {
//
//                List<Object> itemList = scoreServices.searchTop10(region);
//                JSONArray jsonArray = new JSONArray();
//                for (int i = 0; i < itemList.size(); i++) {
//                    Object[] item = (Object[]) itemList.get(i);
//                    JSONObject jsonObject = new JSONObject();
//                    jsonObject.put("region", item[1] == null ? region : item[1]);
//                    jsonObject.put("count", item[0]);
//                    jsonArray.add(jsonObject);
//                }
//                data.put("result", jsonArray);
//
//                if (data.size() != 0) {
//                    rt.opsForValue().set(PFCOMPY_REGION_TOP10 + region + calendar.get(Calendar.DATE), jsonArray.toString());
//                    rt.expire(PFCOMPY_REGION_TOP10 + region + calendar.get(Calendar.DATE), Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
//                }
//            } else {
//                data.put("result", JSON.parse(String.valueOf(out)));
//            }
//            outData.setData(data);
//        } catch (Exception e) {
//            e.printStackTrace();
//            outData.setCode("1");
//            outData.setMessage("系统报错!");
//            return outData;
//        }
//        outData.setCode("0");
//        outData.setMessage("返回成功!");
//        return outData;
//    }

    /**
     * 全国维度的汇总
     *
     * @return
     */

    @RequestMapping(value = "/countryCount", method = RequestMethod.GET)
    public BaseOutData getWholeRiskCount() {
        BaseOutData outData = new BaseOutData();
        try {
            Map data = new HashMap();
            Calendar calendar = Calendar.getInstance();
            Object out = rt.opsForValue().get(PFCOMPY_COUNTRY_COUNT + calendar.get(Calendar.DATE));
            if (out == null) {
                JSONObject jsonObject = new JSONObject();
                List<Object> itemList = scoreServices.wholeCount();
                for (int i = 0; i < itemList.size(); i++) {
                    Object[] item = (Object[]) itemList.get(i);
                    String level = checkLevel(item[1].toString());
                    jsonObject.put(level, item[0]);
                }
                data.put("result", jsonObject);

                rt.opsForValue().set(PFCOMPY_COUNTRY_COUNT + calendar.get(Calendar.DATE), jsonObject.toString());
                rt.expire(PFCOMPY_COUNTRY_COUNT + calendar.get(Calendar.DATE), Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
            } else {
                data.put("result", JSON.parse(String.valueOf(out)));
            }
            outData.setData(data);
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        outData.setCode("0");
        outData.setMessage("返回成功!");
        return outData;
    }

    /**
     * 注册地的汇总
     *
     * @return
     */

    @RequestMapping(value = "/regionCount/{region}", method = RequestMethod.GET)
    public BaseOutData getCount(@PathVariable String region) {
        BaseOutData outData = new BaseOutData();
        try {
            Map data = new HashMap();
            Calendar calendar = Calendar.getInstance();
            Object out = rt.opsForValue().get(PFCOMPY_REGION_COUNT + region + calendar.get(Calendar.DATE));
            if (out == null) {
                List<Object> itemList = scoreServices.searchCount(region);

                JSONArray jsonArray = new JSONArray();
                for (int i = 0; i < itemList.size(); i++) {
                    Object[] item = (Object[]) itemList.get(i);
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("region", item[1] == null ? region : item[1]);
                    jsonObject.put("count", item[0]);
                    jsonArray.add(jsonObject);
                }
                data.put("result", jsonArray);

                rt.opsForValue().set(PFCOMPY_REGION_COUNT + region + calendar.get(Calendar.DATE), jsonArray.toString());
                rt.expire(PFCOMPY_REGION_COUNT + region + calendar.get(Calendar.DATE), Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
            } else {
                data.put("result", JSON.parse(String.valueOf(out)));
            }
            outData.setData(data);
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        outData.setCode("0");
        outData.setMessage("返回成功!");
        return outData;
    }

    private String checkLevel(String result) {
        String level = "";
        if ("1".equals(result)) {
            level = "highRisk";
        } else if ("2".equals(result)) {
            level = "midRisk";
        } else {
            level = "lowRisk";
        }
        return level;
    }

    /**
     * 风险指数查找
     *
     * @return
     */

    @RequestMapping(value = "/search", method = RequestMethod.POST)
    public BaseOutData getSearch(@RequestBody PFCompySearchIn inData) {
        BaseOutData outData = new BaseOutData();
        try {
            Map data = new HashMap();
            int count = scoreServices.searchSum();

            JSONArray jsonArray = new JSONArray();
            List<Object> itemList = scoreServices.searchByTypeCount(inData);
            for (int i = 0; i < itemList.size(); i++) {
                Object[] item = (Object[]) itemList.get(i);
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("compyId", item[0]);
                jsonObject.put("compyNm", item[1]);
                jsonObject.put("score", item[2]);
                jsonArray.add(jsonObject);
            }
            data.put("result", jsonArray);
            outData.setData(data);
            outData.setCount(count);
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        outData.setCode("0");
        outData.setMessage("返回成功!");
        return outData;
    }
}
