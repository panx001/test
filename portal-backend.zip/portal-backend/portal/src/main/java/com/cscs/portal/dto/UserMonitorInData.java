package com.cscs.portal.dto;

import com.cscs.portal.dto.base.BaseInData;

/**
 * Created by sh on 2016/8/7.
 */
public class UserMonitorInData extends BaseInData{
    private String riskTypes;
    private int dateType;
    //0：未读，1：已读
    private String isRead;
    
    //监控动态需要用户过滤
    private String startDt;
    
    private String endDt;

	public String getRiskTypes() {
		return riskTypes;
	}

	public void setRiskTypes(String riskTypes) {
		this.riskTypes = riskTypes;
	}

	public int getDateType() {
		return dateType;
	}

	public void setDateType(int dateType) {
		this.dateType = dateType;
	}

	public String getIsRead() {
		return isRead;
	}

	public void setIsRead(String isRead) {
		this.isRead = isRead;
	}

	public String getStartDt() {
		return startDt;
	}

	public void setStartDt(String startDt) {
		this.startDt = startDt;
	}

	public String getEndDt() {
		return endDt;
	}

	public void setEndDt(String endDt) {
		this.endDt = endDt;
	}

   
	
    
    
}
