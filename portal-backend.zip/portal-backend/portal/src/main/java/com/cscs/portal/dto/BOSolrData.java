package com.cscs.portal.dto;

import java.util.Set;

public class BOSolrData {
    private String id;
    private String leg_represent;
    private String security_cd;
    private String security_snm;
    private String companyst;
    private String regcapital;
    private String founddt;
    private String company_nm;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLeg_represent() {
        return leg_represent;
    }

    public void setLeg_represent(String leg_represent) {
        this.leg_represent = leg_represent;
    }

    public String getSecurity_cd() {
        return security_cd;
    }

    public void setSecurity_cd(String security_cd) {
        this.security_cd = security_cd;
    }

    public String getSecurity_snm() {
        return security_snm;
    }

    public void setSecurity_snm(String security_snm) {
        this.security_snm = security_snm;
    }

    public String getCompanyst() {
        return companyst;
    }

    public void setCompanyst(String companyst) {
        this.companyst = companyst;
    }

    public String getRegcapital() {
        return regcapital;
    }

    public void setRegcapital(String regcapital) {
        this.regcapital = regcapital;
    }

    public String getFounddt() {
        return founddt;
    }

    public void setFounddt(String founddt) {
        this.founddt = founddt;
    }

    public String getCompany_nm() {
        return company_nm;
    }

    public void setCompany_nm(String company_nm) {
        this.company_nm = company_nm;
    }
}
