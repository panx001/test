package com.cscs.portal.dto;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.Map;

public class CommonComparator implements Comparator<Map> {

	private String attrName;
	
	
	public String getAttrName() {
		return attrName;
	}

	public void setAttrName(String attrName) {
		this.attrName = attrName;
	}

	public CommonComparator() {
		super();
	}
	public CommonComparator(String attrName) {
		this.attrName = attrName;
	}
	
	@Override
	public int compare(Map o1, Map o2) {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date dt1;
		Date dt2;
		try {
			dt1 = df.parse((String) o1.get(this.getAttrName()));
			dt2 = df.parse((String)o2.get(this.getAttrName()));
			//降序
			if (dt1.getTime() > dt2.getTime()) {	
				return -1;
			} else if (dt1.getTime() < dt2.getTime()) {
				return 1;
			} else {
				return 0;
			}
		} catch (ParseException e) {
			return 0;
		}catch(Exception e){
			return 0;
		}
	}
}
