package com.cscs.portal.dto;

import com.cscs.portal.dto.base.BaseInData;

/**
 * Created by dch on 2016/11/14.
 * 用户跟踪信息入参
 */
public class UserTraceInfoData extends BaseInData {
    private String accountNm; // 用户名
    private String startDtString; // 开始时间
    private String endDtString; // 结束时间

    public String getAccountNm() {
        return accountNm;
    }

    public void setAccountNm(String accountNm) {
        this.accountNm = accountNm;
    }

    public String getStartDtString() {
        return startDtString;
    }

    public void setStartDtString(String startDtString) {
        this.startDtString = startDtString;
    }

    public String getEndDtString() {
        return endDtString;
    }

    public void setEndDtString(String endDtString) {
        this.endDtString = endDtString;
    }
}
