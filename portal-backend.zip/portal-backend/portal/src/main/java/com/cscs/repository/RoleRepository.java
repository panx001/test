package com.cscs.repository;

import com.cscs.portal.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * Created by dch on 2016/11/7.
 * 角色
 */
@SuppressWarnings("JpaQlInspection")
public interface RoleRepository extends JpaRepository<Role,Long> {

    //查找角色
    @Query(value = "select ro from Role ro where ro.roleNm=:roleNm")
    Role findByRoleNm(@Param("roleNm") String roleNm);
}
