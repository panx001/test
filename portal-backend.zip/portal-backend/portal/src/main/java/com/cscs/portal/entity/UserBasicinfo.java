package com.cscs.portal.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Created by sh on 2016/11/2.
 */
@Entity
@Table(name = "USER_BASICINFO", schema = "CS_PORTAL", catalog = "")
public class UserBasicinfo {
    private Long userId;
    private String userNm;
    private String headUrl;
//    private Time birth;
//    private Long userGender;
//    private String idCardNo;
//    private String cellphone;
    private String phone;
    private String email;
    private String address;
//    private String major;
//    private Long educational;
//    private Long politicalStatus;
//    private String introduction;
//    private Long userType;
//    private Long companyId;
    private String companyNm;
    private String position;
//    private String goodType;
//    private Long industrySid;
    private long updtBy;
    private Timestamp updtDt;
    
    //新增
    private String accountNm;
    private String accountPw;
    private Date loginDt;
    private Date regeditDt;
    private Long createBy;
    private Date createDt;
    private Long regeditType;
    private long activityType;

    @Id
    @Column(name = "USER_ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_USER_BASICINFO")
    @SequenceGenerator(sequenceName = "SEQ_USER_BASICINFO", name = "SEQ_USER_BASICINFO")
    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    @Basic
    @Column(name = "USER_NM")
    public String getUserNm() {
        return userNm;
    }

    public void setUserNm(String userNm) {
        this.userNm = userNm;
    }

    @Basic
    @Column(name = "HEAD_URL")
    public String getHeadUrl() {
        return headUrl;
    }

    public void setHeadUrl(String headUrl) {
        this.headUrl = headUrl;
    }

//    @Basic
//    @Column(name = "BIRTH")
//    public Time getBirth() {
//        return birth;
//    }
//
//    public void setBirth(Time birth) {
//        this.birth = birth;
//    }

//    @Basic
//    @Column(name = "USER_GENDER")
//    public Long getUserGender() {
//        return userGender;
//    }
//
//    public void setUserGender(Long userGender) {
//        this.userGender = userGender;
//    }

//    @Basic
//    @Column(name = "ID_CARD_NO")
//    public String getIdCardNo() {
//        return idCardNo;
//    }

//    public void setIdCardNo(String idCardNo) {
//        this.idCardNo = idCardNo;
//    }
//
//    @Basic
//    @Column(name = "CELLPHONE")
//    public String getCellphone() {
//        return cellphone;
//    }

//    public void setCellphone(String cellphone) {
//        this.cellphone = cellphone;
//    }

    @Basic
    @Column(name = "ACTIVITY_TYPE")
    public long getActivityType() {
        return activityType;
    }

    public void setActivityType(long activityType) {
        this.activityType = activityType;
    }
    
    @Basic
    @Column(name = "PHONE")
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Basic
    @Column(name = "EMAIL")
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Basic
    @Column(name = "ADDRESS")
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

//    @Basic
//    @Column(name = "MAJOR")
//    public String getMajor() {
//        return major;
//    }
//
//    public void setMajor(String major) {
//        this.major = major;
//    }
//
//    @Basic
//    @Column(name = "EDUCATIONAL")
//    public Long getEducational() {
//        return educational;
//    }
//
//    public void setEducational(Long educational) {
//        this.educational = educational;
//    }
//
//    @Basic
//    @Column(name = "POLITICAL_STATUS")
//    public Long getPoliticalStatus() {
//        return politicalStatus;
//    }
//
//    public void setPoliticalStatus(Long politicalStatus) {
//        this.politicalStatus = politicalStatus;
//    }
//
//    @Basic
//    @Column(name = "INTRODUCTION")
//    public String getIntroduction() {
//        return introduction;
//    }
//
//    public void setIntroduction(String introduction) {
//        this.introduction = introduction;
//    }
//
//    @Basic
//    @Column(name = "USER_TYPE")
//    public Long getUserType() {
//        return userType;
//    }
//
//    public void setUserType(Long userType) {
//        this.userType = userType;
//    }
//
//    @Basic
//    @Column(name = "COMPANY_ID")
//    public Long getCompanyId() {
//        return companyId;
//    }
//
//    public void setCompanyId(Long companyId) {
//        this.companyId = companyId;
//    }

    @Basic
    @Column(name = "COMPANY_NM")
    public String getCompanyNm() {
        return companyNm;
    }

    public void setCompanyNm(String companyNm) {
        this.companyNm = companyNm;
    }

    @Basic
    @Column(name = "POSITION")
    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }
//
//    @Basic
//    @Column(name = "GOOD_TYPE")
//    public String getGoodType() {
//        return goodType;
//    }
//
//    public void setGoodType(String goodType) {
//        this.goodType = goodType;
//    }
//
//    @Basic
//    @Column(name = "INDUSTRY_SID")
//    public Long getIndustrySid() {
//        return industrySid;
//    }
//
//    public void setIndustrySid(Long industrySid) {
//        this.industrySid = industrySid;
//    }

    @Basic
    @Column(name = "UPDT_BY")
    public long getUpdtBy() {
        return updtBy;
    }

    public void setUpdtBy(long updtBy) {
        this.updtBy = updtBy;
    }

    @Basic
    @Column(name = "UPDT_DT")
    public Timestamp getUpdtDt() {
        return updtDt;
    }

    public void setUpdtDt(Timestamp updtDt) {
        this.updtDt = updtDt;
    }

    @Basic
    @Column(name = "ACCOUNT_NM")
    public String getAccountNm() {
        return accountNm;
    }

    public void setAccountNm(String accountNm) {
        this.accountNm = accountNm;
    }

    @Basic
    @Column(name = "ACCOUNT_PW")
    public String getAccountPw() {
        return accountPw;
    }

    public void setAccountPw(String accountPw) {
        this.accountPw = accountPw;
    }
    
    @Basic
    @Column(name = "REGEDIT_DT")
    public Date getRegeditDt() {
        return regeditDt;
    }

    public void setRegeditDt(Date regeditDt) {
        this.regeditDt = regeditDt;
    }
    
    @Basic
    @Column(name = "REGEDIT_TYPE")
    public Long getRegeditType() {
        return regeditType;
    }
    
    public void setRegeditType(Long regeditType) {
        this.regeditType = regeditType;
    }


    @Basic
    @Column(name = "CREATE_BY")
    public Long getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }

    @Basic
    @Column(name = "CREATE_DT")
    public Date getCreateDt() {
        return createDt;
    }

    public void setCreateDt(Date createDt) {
        this.createDt = createDt;
    }

    @Basic
    @Column(name = "LOGIN_DT")
    public Date getLoginDt() {
        return loginDt;
    }

    public void setLoginDt(Date loginDt) {
        this.loginDt = loginDt;
    }
    
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UserBasicinfo that = (UserBasicinfo) o;

        if (userId != that.userId) return false;
        if (updtBy != that.updtBy) return false;
        if (position != null ? !position.equals(that.position) : that.position != null) return false;
        if (userNm != null ? !userNm.equals(that.userNm) : that.userNm != null) return false;
        if (headUrl != null ? !headUrl.equals(that.headUrl) : that.headUrl != null) return false;
//        if (birth != null ? !birth.equals(that.birth) : that.birth != null) return false;
//        if (userGender != null ? !userGender.equals(that.userGender) : that.userGender != null) return false;
//        if (idCardNo != null ? !idCardNo.equals(that.idCardNo) : that.idCardNo != null) return false;
//        if (cellphone != null ? !cellphone.equals(that.cellphone) : that.cellphone != null) return false;
        if (phone != null ? !phone.equals(that.phone) : that.phone != null) return false;
        if (email != null ? !email.equals(that.email) : that.email != null) return false;
        if (address != null ? !address.equals(that.address) : that.address != null) return false;
//        if (major != null ? !major.equals(that.major) : that.major != null) return false;
//        if (educational != null ? !educational.equals(that.educational) : that.educational != null) return false;
//        if (politicalStatus != null ? !politicalStatus.equals(that.politicalStatus) : that.politicalStatus != null)
//            return false;
//        if (introduction != null ? !introduction.equals(that.introduction) : that.introduction != null) return false;
//        if (userType != null ? !userType.equals(that.userType) : that.userType != null) return false;
//        if (companyId != null ? !companyId.equals(that.companyId) : that.companyId != null) return false;
        if (companyNm != null ? !companyNm.equals(that.companyNm) : that.companyNm != null) return false;
//        if (goodType != null ? !goodType.equals(that.goodType) : that.goodType != null) return false;
//        if (industrySid != null ? !industrySid.equals(that.industrySid) : that.industrySid != null) return false;
        if (accountNm != null ? !accountNm.equals(that.accountNm) : that.accountNm != null) return false;
        if (accountPw != null ? !accountPw.equals(that.accountPw) : that.accountPw != null) return false;
        if (loginDt != null ? !loginDt.equals(that.loginDt) : that.loginDt != null) return false;
        if (regeditDt != null ? !regeditDt.equals(that.regeditDt) : that.regeditDt != null) return false;
        if (regeditType != null ? !regeditType.equals(that.regeditType) : that.regeditType != null) return false;
        if (createBy != null ? !createBy.equals(that.createBy) : that.createBy != null) return false;
        if (createDt != null ? !createDt.equals(that.createDt) : that.createDt != null) return false;
        if (activityType != that.activityType) return false;
        return updtDt != null ? updtDt.equals(that.updtDt) : that.updtDt == null;

    }

    @Override
    public int hashCode() {
        int result = (int) (userId ^ (userId >>> 32));
        result = 31 * result + (userNm != null ? userNm.hashCode() : 0);
        result = 31 * result + (headUrl != null ? headUrl.hashCode() : 0);
//        result = 31 * result + (birth != null ? birth.hashCode() : 0);
//        result = 31 * result + (userGender != null ? userGender.hashCode() : 0);
//        result = 31 * result + (idCardNo != null ? idCardNo.hashCode() : 0);
//        result = 31 * result + (cellphone != null ? cellphone.hashCode() : 0);
        result = 31 * result + (phone != null ? phone.hashCode() : 0);
        result = 31 * result + (email != null ? email.hashCode() : 0);
        result = 31 * result + (address != null ? address.hashCode() : 0);
//        result = 31 * result + (major != null ? major.hashCode() : 0);
//        result = 31 * result + (educational != null ? educational.hashCode() : 0);
//        result = 31 * result + (politicalStatus != null ? politicalStatus.hashCode() : 0);
//        result = 31 * result + (introduction != null ? introduction.hashCode() : 0);
//        result = 31 * result + (userType != null ? userType.hashCode() : 0);
//        result = 31 * result + (companyId != null ?result = 3 companyId.hashCode() : 0);
        result = 31 * result + (companyNm != null ? companyNm.hashCode() : 0);
        result = 31 * result + (position != null ? position.hashCode() : 0);
//        result = 31 * result + (goodType != null ? goodType.hashCode() : 0);
//        result = 31 * result + (industrySid != null ? industrySid.hashCode() : 0);
        result = 31 * result + (int) (updtBy ^ (updtBy >>> 32));
        result = 31 * result + (updtDt != null ? updtDt.hashCode() : 0);
        result = 31 * result + (accountNm != null ? accountNm.hashCode() : 0);
        result = 31 * result + (accountPw != null ? accountPw.hashCode() : 0);
        result = 31 * result + (loginDt != null ? loginDt.hashCode() : 0);
        result = 31 * result + (regeditDt != null ? regeditDt.hashCode() : 0);
        result = 31 * result + (regeditType != null ? regeditType.hashCode() : 0);
        result = 31 * result + (createBy != null ? createBy.hashCode() : 0);
        result = 31 * result + (createDt != null ? createDt.hashCode() : 0);
        result = 31 * result + (int) (activityType ^ (activityType >>> 32));
        return result;
    }
}
