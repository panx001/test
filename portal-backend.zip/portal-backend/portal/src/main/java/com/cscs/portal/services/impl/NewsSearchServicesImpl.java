package com.cscs.portal.services.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cscs.util.Contants;
import com.cscs.util.DateUtils;
import com.cscs.util.SolrUtil;
import com.cscs.util.StringUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cscs.portal.dto.NewsSearchConditon;
import com.cscs.portal.dto.NewsSearchOut;
import com.cscs.portal.services.NewsSearchServices;

/***
 * 
 * @ClassName: RiskSearchServicesImpl
 * @Description: 发债企业高级搜索服务实现类
 * @author: liunn
 * @date: 2018年10月20日 下午4:36:59
 */
@Service
public class NewsSearchServicesImpl implements NewsSearchServices {
	protected final Log logger = LogFactory.getLog(this.getClass());

	@Override
	public SolrQuery setSolrQuery(NewsSearchConditon condition,SolrQuery query) {
		//查询关键字，q不能省略
		if(StringUtils.isNotEmpty(condition.getKeyword())) {
			query.set("q","data_title:"+condition.getKeyword());
		}else {
			query.set("q","*:*");
		}
		//query fields，指定solr从哪些field中搜索 设置查询权重值
		query.set("qf", "data_title^100");
		//只查询存活的分片
		query.set("shards.tolerant", "true");
		query.set("defType", "edismax");
		query.set("mm", "100%");
		//排序
		//参数：field域，排序类型（asc,desc）
//		query.addSort("score", SolrQuery.ORDER.desc);
		query.addSort("post_dt", SolrQuery.ORDER.desc);
		query.addSort("relevancy", SolrQuery.ORDER.desc);
		//分组
		query.set("group.main", "true");
		query.set("group.sort", "relevancy desc");
		query.set("group.field", "info_cd");
		query.set("group", "true");
		//分页
		//实际开发时，知道当前页码和每页显示的个数最后求出开始下标
		int curPage = condition.getCurPage()==null?1:condition.getCurPage();
		int rows = condition.getRowNum()==null?10:condition.getRowNum();
		//计算出开始记录下标
		int start = rows * (curPage - 1);
		//向query中设置分页参数
		query.setStart(start);
		query.setRows(rows);
		//开启高亮
		query.setHighlight(true);
		//设置高亮 参数
		query.addHighlightField("data_title");
		//设置高亮前缀和后缀
		query.setHighlightSimplePre("<span class=\"highlight\">");
		query.setHighlightSimplePost("</span>");
		return query;
	}
	
	@Override
	public List<NewsSearchOut> getResponseDate(QueryResponse response) throws ParseException{
		List<NewsSearchOut> returnList = new ArrayList<NewsSearchOut>();
		//从响应中得到结果
		SolrDocumentList documents = response.getResults();
		
		//从响应中获得高亮信息
		Map<String, Map<String, List<String>>> highlighting = response.getHighlighting();
		
		for (SolrDocument document:documents){
			NewsSearchOut data = new NewsSearchOut();
			if(null != document.get("company_id")) {
				data.setCompanyId(String.valueOf(document.get("company_id")));
			}
			if(null != document.get("data_src")) {
				data.setMediaType(String.valueOf(document.get("data_src")));
			}
			if(null != document.get("data_title")) {
				data.setTitle(String.valueOf(document.get("data_title")));
			}
			if(null != document.get("media_nm")) {
				data.setSource(String.valueOf(document.get("media_nm")));
			}
			if(null != document.get("post_dt")) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				data.setPublishTime(sdf.format((Date)document.get("post_dt")));
			}
			if(null != document.get("company_nm")) {
				data.setCompanyName(String.valueOf(document.get("company_nm")));
			}
			if(null != document.get("negtive")) {
				data.setNegative(String.valueOf(document.get("negtive")));
			}
			if(null != document.get("relevancy")) {
				data.setRelevancy(String.valueOf(document.get("relevancy")));
			}
			if(null != document.get("info_cd")) {
				data.setInfoCd(String.valueOf(document.get("info_cd")));
			}
			if(null != document.get("info_sid")) {
				data.setNewsId(String.valueOf(document.get("info_sid")));
			}
			if(null != document.get("data_score")) {
				data.setDataScore(String.valueOf(document.get("data_score")));
			}
			if(null != document.get("relevance")) {
				data.setRelevance(String.valueOf(document.get("relevance")));
			}
			if(null != document.get("importance")) {
				data.setImportance(String.valueOf(document.get("importance")));
			}
			if(null != document.get("sheet_l1")) {
				List list = (List)document.get("sheet_l1");
				data.setSheetL1(list);
			}
			if(null != document.get("sheet_l2")) {
				List list = (List)document.get("sheet_l2");
				data.setSheetL2(list);
			}
			
			//获得高亮的信息
			if(highlighting!=null){
				//根据主键获取高亮信息
				Map<String, List<String>> map = highlighting.get(document.get("id"));
				if(map!=null){
					List highlightColumns = new ArrayList();
					List<String> relevancyList = map.get("relevancy");
					List<String> postDtNmList = map.get("post_dt");
					List<String> dataTitleList = map.get("data_title");
					if(relevancyList!=null){
						data.setRelevancy(relevancyList.get(0));
						highlightColumns.add("relevancy");
					}
					if(postDtNmList!=null){
						data.setPublishTime(postDtNmList.get(0));
						highlightColumns.add("publishTime");
					}
					if(dataTitleList!=null){
						data.setTitle(dataTitleList.get(0));
						highlightColumns.add("title");
					}
					data.setHighlightColumns(highlightColumns);
				}
			}
			returnList.add(data);
		}
		return returnList;
	}
	@Override
	public List<Object> getNegativeNewsCompany(QueryResponse response) throws Exception{
		List<Object> returnList = new ArrayList<Object>();
		//从响应中得到结果
		SolrDocumentList documents = response.getResults();
		
		for (SolrDocument document:documents) {
            //关联度最高的企业信息
            List<Map<String, String>> highestRelatedCompyList = new ArrayList<Map<String, String>>();
            List<Map> relatedCompyList = this.getRelateCompanyList(document.get("info_sid").toString());
            if (null != relatedCompyList && relatedCompyList.size() > 0) {
                //去除本企业
                for (int i = 0; i < relatedCompyList.size(); i++) {
                    Map map = relatedCompyList.get(i);
                    if (document.get("company_nm").equals(map.get("companyNm"))) {
                        relatedCompyList.remove(i);
                    }
                }
                //排序
                Collections.sort(relatedCompyList, new Comparator<Map>() {
                    public int compare(Map arg0, Map arg1) {
                        if (arg0.get("relevance") != null && arg1.get("relevance") != null) {
                            return arg1.get("relevance").toString().compareTo(arg0.get("relevance").toString());
                        }
                        return 0;
                    }
                });
                if (relatedCompyList != null && relatedCompyList.size() > 0) {
                    highestRelatedCompyList.add(relatedCompyList.get(0));
                }
            }
			if(null != document.get("newsinfo")) {
				List<Map> newsinfo = (List<Map>) JSON.parse(document.get("newsinfo").toString());
				Map newsinfoMap = newsinfo.get(0);
				newsinfoMap.put("relatedCompyList",highestRelatedCompyList);
				List<Map> list = new ArrayList<Map>();
				list.add(newsinfoMap);
				returnList.add(list);
			}else {
				List list = new ArrayList();
				Map<String, Object> map = new HashMap();
				if (null != document.get("post_dt")) {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					map.put("publishTime", sdf.format((Date) document.get("post_dt")));
				} else {
					map.put("publishTime", null);
				}
				map.put("warningType", document.get("sheet_l1") != null ? String.join(",", (List) document.get("sheet_l1")) : null);
				map.put("newsId", document.get("info_sid"));
				map.put("newsSource", document.get("media_nm"));
				map.put("newsTitle", document.get("data_title"));
				map.put("newsCode", document.get("info_cd"));
				map.put("relatedCompyList", highestRelatedCompyList);
				list.add(map);
				returnList.add(list);
			}
        }
		return returnList;
	}
	
	@Override
	public List<Object> getAnnounce(QueryResponse response) throws ParseException{
		List<Object> returnList = new ArrayList<Object>();
		//从响应中得到结果
		SolrDocumentList documents = response.getResults();
		
		for (SolrDocument document:documents){
			/*if(null != document.get("annbasicinfo")) {
				returnList.add(JSON.parse(document.get("annbasicinfo").toString()));
			}*/
            Map map = new HashMap();
            map.put("announceTitle", document.get("data_title"));
            map.put("riskLabel", document.get("sheet_l1")!=null?String.join(",",(List)document.get("sheet_l1")):null);
            map.put("score", document.get("negtive"));
            map.put("announceCode", document.get("info_cd"));
            map.put("newsId", document.get("info_sid"));
            map.put("announceDt", DateUtils.formatDate((Date) document.get("post_dt"),"yyyy-MM-dd HH:mm:ss"));
            returnList.add(map);
		}
		return returnList;
	}
	
	@Override
	public List<Object> getTrendNewsList(QueryResponse response) throws ParseException{
		List<Object> returnList = new ArrayList<Object>();
		//从响应中得到结果
		SolrDocumentList documents = response.getResults();
		
		for (SolrDocument document:documents){
			if(null != document.get("newsbasicinfo")) {
				returnList.add(JSON.parse(document.get("newsbasicinfo").toString()));
			}else{
				Map map = new HashMap();
				map.put("newsTitle", document.get("data_title"));
				map.put("warningType", document.get("sheet_l1")!=null?String.join(",",(List)document.get("sheet_l1")):null);
				map.put("score", document.get("data_score"));
				map.put("publishTime", document.get("post_dt")!=null?DateUtils.formatDate((Date) document.get("post_dt"), "yyyy-MM-dd HH:mm:ss"):null);
				map.put("newsSource", document.get("media_nm"));
				map.put("relevance", document.get("relevance"));
				map.put("importance", document.get("importance"));
				map.put("type", document.get("data_src"));
				map.put("newsCode", document.get("info_cd"));
				map.put("newsId", document.get("info_sid"));
				List list = new ArrayList();
				list.add(map);
				returnList.add(list);
			}
        }
		return returnList;
	}
	
	@Override
	public List<Object> getRelatedNewsList(QueryResponse response) throws ParseException{
		List<Object> returnList = new ArrayList<Object>();
		//从响应中得到结果
		SolrDocumentList documents = response.getResults();
		
		for (SolrDocument document:documents){
			if(null != document.get("relanewsinfo")) {
				returnList.add(JSON.parse(document.get("relanewsinfo").toString()));
			}
		}
		return returnList;
	}
	@Override
	public List<Map<String,Object>> getNegativeNews24h(QueryResponse response) throws ParseException{
		List<Map<String,Object>> returnList = new ArrayList<Map<String,Object>>();
		//从响应中得到结果
		SolrDocumentList documents = response.getResults();
		
		for (SolrDocument document:documents){
			if(null != document.get("sentirankinglist")) {
				Map<String,Object> map = (Map)JSON.parse(document.get("sentirankinglist").toString());
				returnList.add(map);
			}else{
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("importance", document.get("importance"));
				map.put("newsLabels", document.get("sheet_l1")!=null?String.join(",",(List)document.get("sheet_l1")):null);
				map.put("companyId", document.get("company_id"));
				map.put("publishTime", document.get("post_dt")!=null?DateUtils.formatDate((Date)document.get("post_dt"),"yyyy-MM-dd HH:mm:ss"):null);
				map.put("companyNm", document.get("company_nm"));
				map.put("relevance", document.get("relevance"));
				map.put("newsId", document.get("info_sid"));
				map.put("newscode", document.get("info_cd"));
				map.put("newsSource", document.get("media_nm"));
				map.put("newsTitle", document.get("data_title"));
				map.put("type", document.get("data_src"));
				returnList.add(map);
			}
		}
		//排序
		Collections.sort(returnList,new Comparator<Map<String,Object>>(){
            public int compare(Map<String,Object> arg0, Map<String,Object> arg1) {
                if (arg0.get("publishTime") != null && arg1.get("publishTime") != null) {
                    return arg1.get("publishTime").toString().compareTo(arg0.get("publishTime").toString());
                }
                return 0;
            }
        });
		return returnList;
	}
	
	@Override
	public String getQueryTime(String foundDt) throws ParseException {
    	String queryStr = "";
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    	SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
    	Date startTime = null;
    	Date endTime = null;
    	String[] foundDtArr = foundDt.split("-");
    	if(foundDtArr!=null && foundDtArr.length>1) {
    		String startDateStr = foundDtArr[0];
    		String endDateStr = foundDtArr[1];
    		startTime = formatter.parse(startDateStr);
			endTime = formatter.parse(endDateStr);
			queryStr = "found_dt:["+sdf.format(startTime)+" TO "+sdf.format(endTime)+"]";
    	}
    	return queryStr;
    }
	@Override
	public List negativeNewsRankSort(List<Map> list) {
		if(list==null) {
			return null;
		}
		Collections.sort(list,new Comparator<Map>(){
            public int compare(Map arg0, Map arg1) {
            	Integer intArg0 = Integer.valueOf(arg0.get("negativeNewsCount").toString());
            	Integer intArg1 = Integer.valueOf(arg1.get("negativeNewsCount").toString());
            	return intArg1.compareTo(intArg0);
            }
        });
		//负面舆情按时间倒叙
		for(Map map : list) {
			List<Map<String,String>> negativeNewsList = (List)map.get("negativeNewsList");
			Collections.sort(negativeNewsList,new Comparator<Map<String,String>>(){
	            public int compare(Map<String,String> arg0, Map<String,String> arg1) {
	            	return arg1.get("publishTime").compareTo(arg0.get("publishTime"));
	            }
	        });
			if(negativeNewsList.size()>10) {
				negativeNewsList = negativeNewsList.subList(0, 10);
			}
			map.put("negativeNewsList", negativeNewsList);
		}
		//负面舆情按时间倒叙
		for(Map map : list) {
			List<Map<String,String>> negativeNewsList = (List)map.get("warningLabels");
			Collections.sort(negativeNewsList,new Comparator<Map<String,String>>(){
				public int compare(Map<String,String> arg0, Map<String,String> arg1) {
					return Integer.valueOf(arg1.get("count")).compareTo( Integer.valueOf(arg0.get("count")));
				}
			});
		}
		return list;
	}

	@Override
    public List<Map> getRelateCompanyList(String newsId) throws SolrServerException {
		List<Map> returnList = new ArrayList<Map>();
        //创建Solr服务对象，通过此对象向solr服务发起请求
        SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_SENTIMENT_METHOD);
        //创建查询对象
        SolrQuery query = new SolrQuery();
        query.set("q","info_sid:" + newsId);
        query.addSort("relevancy", SolrQuery.ORDER.desc);
        QueryResponse response = solrServer.query(query);
		for (SolrDocument solrDocument : response.getResults()) {
			Map map = new HashMap();
			map.put("companyId", solrDocument.get("company_id"));
			map.put("companyNm", solrDocument.get("company_nm"));
			map.put("importance", solrDocument.get("importance"));
			map.put("relevance", solrDocument.get("relevance"));
			map.put("newsTitle", solrDocument.get("data_title"));
            returnList.add(map);
		}
	    return returnList;
    }

    @Override
	public List<Map> getNewsByCompanyId(String companyId,String queryTime) throws SolrServerException {
		List<Map> returnList = new ArrayList<Map>();
		//创建Solr服务对象，通过此对象向solr服务发起请求
		SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_SENTIMENT_METHOD);
		//创建查询对象
		SolrQuery query = new SolrQuery();
		//设置公共参数
		query = this.setSolrQuery(new NewsSearchConditon(), query);
		//时间过滤
		query.addFilterQuery(queryTime);
		//过滤负面
		query.addFilterQuery("negtive:1");
		//新闻
		query.addFilterQuery("data_src:新闻");
		//三星以上
		query.addFilterQuery("relevancy:[3 TO *]");
		//企业id
		query.addFilterQuery("company_id:"+companyId);
		//按照时间排序
		query.addSort("post_dt", SolrQuery.ORDER.desc);
		QueryResponse response = solrServer.query(query);
		for (SolrDocument solrDocument : response.getResults()) {
			Map map = new HashMap();
			map.put("newstitle", solrDocument.get("data_title"));
			map.put("publishTime", solrDocument.get("post_dt")!=null?DateUtils.formatDate((Date)solrDocument.get("post_dt"),"yyyy-MM-dd HH:mm:ss"):null);
			map.put("newsId", solrDocument.get("info_sid"));
			map.put("newssource", solrDocument.get("media_nm"));
			map.put("newscode", solrDocument.get("info_cd"));
			returnList.add(map);
		}
		return returnList;
	}

	public SolrQuery setFacetQuery(String keyword){
		//创建查询对象
		SolrQuery query = new SolrQuery();
		if (StringUtil.isEmpty(keyword)) {
			query.set("q","*:*");
		} else {
			query.set("q","data_title:"+keyword);
		}
		query.set("shards.tolerant", true);
		query.setFacet(true);
		return query;
	}

}
