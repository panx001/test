package com.cscs.portal.dto;

public class SharehdInvestnbDetail implements Comparable<SharehdInvestnbDetail>{

	private String sharehdId;
	private String sharehdName;
	private String islist;
	private String isbond;
	private String islist3;
	private String ispfund;
	private String subscribeRatio;
	private String subscribeAmount;
	private String paidAmount;
	private String paidTime;
	public String getSharehdId() {
		return sharehdId;
	}

	public void setSharehdId(String sharehdId) {
		this.sharehdId = sharehdId;
	}


	public String getSharehdName() {
		return sharehdName;
	}


	public void setSharehdName(String sharehdName) {
		this.sharehdName = sharehdName;
	}


	public String getIslist() {
		return islist;
	}


	public void setIslist(String islist) {
		this.islist = islist;
	}


	public String getIsbond() {
		return isbond;
	}


	public void setIsbond(String isbond) {
		this.isbond = isbond;
	}


	public String getIslist3() {
		return islist3;
	}


	public void setIslist3(String islist3) {
		this.islist3 = islist3;
	}


	public String getIspfund() {
		return ispfund;
	}


	public void setIspfund(String ispfund) {
		this.ispfund = ispfund;
	}


	
	public String getSubscribeRatio() {
		return subscribeRatio;
	}

	public void setSubscribeRatio(String subscribeRatio) {
		this.subscribeRatio = subscribeRatio;
	}

	public String getSubscribeAmount() {
		return subscribeAmount;
	}

	public void setSubscribeAmount(String subscribeAmount) {
		this.subscribeAmount = subscribeAmount;
	}

	public String getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(String paidAmount) {
		this.paidAmount = paidAmount;
	}

	public String getPaidTime() {
		return paidTime;
	}

	public void setPaidTime(String paidTime) {
		this.paidTime = paidTime;
	}

	@Override
	public int compareTo(SharehdInvestnbDetail o) {
		double o1 = Double.parseDouble(subscribeRatio.split("%")[0]);
		double o2 = Double.parseDouble(o.subscribeRatio.split("%")[0]);
		if(o1>o2)
			return -1;
		else if(o1<o2)
			return 1;
		else
			return 0;
	}

}
