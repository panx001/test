package com.cscs.portal.dto;

public class SharehdInvest implements Comparable<SharehdInvest> {

	private String paidTime;
	private String isCompany;
	private String islist;
	private String subscribeAmount;
	private String subscribeTime;
	private String subscribeRatio;
	private String investorName;
	private String islist3;
	private String isbond;
	private String investorId;
	private String paidAmount;
	private String ispfund;

	public String getPaidTime() {
		return paidTime;
	}

	public void setPaidTime(String paidTime) {
		this.paidTime = paidTime;
	}

	public String getIsCompany() {
		return isCompany;
	}

	public void setIsCompany(String isCompany) {
		this.isCompany = isCompany;
	}

	public String getIslist() {
		return islist;
	}

	public void setIslist(String islist) {
		this.islist = islist;
	}

	public String getSubscribeAmount() {
		return subscribeAmount;
	}

	public void setSubscribeAmount(String subscribeAmount) {
		this.subscribeAmount = subscribeAmount;
	}

	public String getSubscribeTime() {
		return subscribeTime;
	}

	public void setSubscribeTime(String subscribeTime) {
		this.subscribeTime = subscribeTime;
	}

	public String getSubscribeRatio() {
		return subscribeRatio;
	}

	public void setSubscribeRatio(String subscribeRatio) {
		this.subscribeRatio = subscribeRatio;
	}

	public String getInvestorName() {
		return investorName;
	}

	public void setInvestorName(String investorName) {
		this.investorName = investorName;
	}

	public String getIslist3() {
		return islist3;
	}

	public void setIslist3(String islist3) {
		this.islist3 = islist3;
	}

	public String getIsbond() {
		return isbond;
	}

	public void setIsbond(String isbond) {
		this.isbond = isbond;
	}

	public String getInvestorId() {
		return investorId;
	}

	public void setInvestorId(String investorId) {
		this.investorId = investorId;
	}

	public String getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(String paidAmount) {
		this.paidAmount = paidAmount;
	}

	public String getIspfund() {
		return ispfund;
	}

	public void setIspfund(String ispfund) {
		this.ispfund = ispfund;
	}

	@Override
	public int compareTo(SharehdInvest o) {
		double o1 = Double.parseDouble(subscribeRatio.split("%")[0]);
		double o2 = Double.parseDouble(o.subscribeRatio.split("%")[0]);
		if (o1 > o2)
			return -1;
		else if (o1 < o2)
			return 1;
		else
			return 0;
	}
}
