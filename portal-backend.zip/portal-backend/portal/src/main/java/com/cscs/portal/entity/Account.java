package com.cscs.portal.entity;

import javax.persistence.*;
import java.util.Date;
import java.sql.Time;
import java.sql.Timestamp;

/**
 * Created by sh on 2016/11/2.
 */
@Entity
public class Account {
    private long accountId;
    private long userId;
    private String accountNm;
    private String accountPw;
    private String loginIp;
    private Time loginDt;
    private Date regeditDt;
    private String regeditIp;
    private Long regeditType;
    private long activityType;
    private Long createBy;
    private Timestamp createDt;
    private Long updtBy;
    private Timestamp updtDt;

    @Id
    @Column(name = "ACCOUNT_ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "SEQ_ACCOUNT")
    @SequenceGenerator(sequenceName = "SEQ_ACCOUNT",name="SEQ_ACCOUNT")
    public long getAccountId() {
        return accountId;
    }

    public void setAccountId(long accountId) {
        this.accountId = accountId;
    }

    @Basic
    @Column(name = "USER_ID")
    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    @Basic
    @Column(name = "ACCOUNT_NM")
    public String getAccountNm() {
        return accountNm;
    }

    public void setAccountNm(String accountNm) {
        this.accountNm = accountNm;
    }

    @Basic
    @Column(name = "ACCOUNT_PW")
    public String getAccountPw() {
        return accountPw;
    }

    public void setAccountPw(String accountPw) {
        this.accountPw = accountPw;
    }

    @Basic
    @Column(name = "LOGIN_IP")
    public String getLoginIp() {
        return loginIp;
    }

    public void setLoginIp(String loginIp) {
        this.loginIp = loginIp;
    }

    @Basic
    @Column(name = "LOGIN_DT")
    public Time getLoginDt() {
        return loginDt;
    }

    public void setLoginDt(Time loginDt) {
        this.loginDt = loginDt;
    }

    @Basic
    @Column(name = "REGEDIT_DT")
    public Date getRegeditDt() {
        return regeditDt;
    }

    public void setRegeditDt(Date regeditDt) {
        this.regeditDt = regeditDt;
    }

    @Basic
    @Column(name = "REGEDIT_IP")
    public String getRegeditIp() {
        return regeditIp;
    }

    public void setRegeditIp(String regeditIp) {
        this.regeditIp = regeditIp;
    }

    @Basic
    @Column(name = "REGEDIT_TYPE")
    public Long getRegeditType() {
        return regeditType;
    }

    public void setRegeditType(Long regeditType) {
        this.regeditType = regeditType;
    }

    @Basic
    @Column(name = "ACTIVITY_TYPE")
    public long getActivityType() {
        return activityType;
    }

    public void setActivityType(long activityType) {
        this.activityType = activityType;
    }

    @Basic
    @Column(name = "CREATE_BY")
    public Long getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }

    @Basic
    @Column(name = "CREATE_DT")
    public Timestamp getCreateDt() {
        return createDt;
    }

    public void setCreateDt(Timestamp createDt) {
        this.createDt = createDt;
    }

    @Basic
    @Column(name = "UPDT_BY")
    public Long getUpdtBy() {
        return updtBy;
    }

    public void setUpdtBy(Long updtBy) {
        this.updtBy = updtBy;
    }

    @Basic
    @Column(name = "UPDT_DT")
    public Timestamp getUpdtDt() {
        return updtDt;
    }

    public void setUpdtDt(Timestamp updtDt) {
        this.updtDt = updtDt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Account account = (Account) o;

        if (accountId != account.accountId) return false;
        if (activityType != account.activityType) return false;
        if (accountNm != null ? !accountNm.equals(account.accountNm) : account.accountNm != null) return false;
        if (accountPw != null ? !accountPw.equals(account.accountPw) : account.accountPw != null) return false;
        if (loginIp != null ? !loginIp.equals(account.loginIp) : account.loginIp != null) return false;
        if (loginDt != null ? !loginDt.equals(account.loginDt) : account.loginDt != null) return false;
        if (regeditDt != null ? !regeditDt.equals(account.regeditDt) : account.regeditDt != null) return false;
        if (regeditIp != null ? !regeditIp.equals(account.regeditIp) : account.regeditIp != null) return false;
        if (regeditType != null ? !regeditType.equals(account.regeditType) : account.regeditType != null) return false;
        if (createBy != null ? !createBy.equals(account.createBy) : account.createBy != null) return false;
        if (createDt != null ? !createDt.equals(account.createDt) : account.createDt != null) return false;
        if (updtBy != null ? !updtBy.equals(account.updtBy) : account.updtBy != null) return false;
        return updtDt != null ? updtDt.equals(account.updtDt) : account.updtDt == null;

    }

    @Override
    public int hashCode() {
        int result = (int) (accountId ^ (accountId >>> 32));
        result = 31 * result + (accountNm != null ? accountNm.hashCode() : 0);
        result = 31 * result + (accountPw != null ? accountPw.hashCode() : 0);
        result = 31 * result + (loginIp != null ? loginIp.hashCode() : 0);
        result = 31 * result + (loginDt != null ? loginDt.hashCode() : 0);
        result = 31 * result + (regeditDt != null ? regeditDt.hashCode() : 0);
        result = 31 * result + (regeditIp != null ? regeditIp.hashCode() : 0);
        result = 31 * result + (regeditType != null ? regeditType.hashCode() : 0);
        result = 31 * result + (int) (activityType ^ (activityType >>> 32));
        result = 31 * result + (createBy != null ? createBy.hashCode() : 0);
        result = 31 * result + (createDt != null ? createDt.hashCode() : 0);
        result = 31 * result + (updtBy != null ? updtBy.hashCode() : 0);
        result = 31 * result + (updtDt != null ? updtDt.hashCode() : 0);
        return result;
    }
}
