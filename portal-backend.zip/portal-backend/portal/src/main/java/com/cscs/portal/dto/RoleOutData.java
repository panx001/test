package com.cscs.portal.dto;


import com.cscs.portal.dto.base.BaseOutData;

/**
 * Created by dch on 2016/11/7.
 * 角色信息
 */
public class RoleOutData{
    private long roleId; //角色ID
    private String roleNm; //角色名称

    public long getRoleId() {
        return roleId;
    }

    public void setRoleId(long roleId) {
        this.roleId = roleId;
    }

    public String getRoleNm() {
        return roleNm;
    }

    public void setRoleNm(String roleNm) {
        this.roleNm = roleNm;
    }
}
