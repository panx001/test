package com.cscs.portal.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;

/**
 * Created by sh on 2017/5/19.
 */
@Entity
@Table(name = "USER_TRACE", schema = "CS_PORTAL", catalog = "")
public class UserTrace {
    private long userTraceId;
    private Long userId;
    private String visitNm;
    private String visitUrl;
    private Date visitDt;
    private Date visitStopDt;
    private long updtBy;
    private Timestamp updtDt;
    private String userIp;
    private String authorizeCd;

    @Id
    @Column(name = "USER_TRACE_ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "SEQ_USER_TRACE")
    @SequenceGenerator(sequenceName = "SEQ_USER_TRACE",name="SEQ_USER_TRACE")
    public long getUserTraceId() {
        return userTraceId;
    }

    public void setUserTraceId(long userTraceId) {
        this.userTraceId = userTraceId;
    }

    @Basic
    @Column(name = "USER_ID")
    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    @Basic
    @Column(name = "VISIT_NM")
    public String getVisitNm() {
        return visitNm;
    }

    public void setVisitNm(String visitNm) {
        this.visitNm = visitNm;
    }

    @Basic
    @Column(name = "VISIT_URL")
    public String getVisitUrl() {
        return visitUrl;
    }

    public void setVisitUrl(String visitUrl) {
        this.visitUrl = visitUrl;
    }

    @Basic
    @Column(name = "VISIT_DT")
    public Date getVisitDt() {
        return visitDt;
    }

    public void setVisitDt(Date visitDt) {
        this.visitDt = visitDt;
    }

    @Basic
    @Column(name = "VISIT_STOP_DT")
    public Date getVisitStopDt() {
        return visitStopDt;
    }

    public void setVisitStopDt(Date visitStopDt) {
        this.visitStopDt = visitStopDt;
    }

    @Basic
    @Column(name = "UPDT_BY")
    public long getUpdtBy() {
        return updtBy;
    }

    public void setUpdtBy(long updtBy) {
        this.updtBy = updtBy;
    }

    @Basic
    @Column(name = "UPDT_DT")
    public Timestamp getUpdtDt() {
        return updtDt;
    }

    public void setUpdtDt(Timestamp updtDt) {
        this.updtDt = updtDt;
    }

    @Basic
    @Column(name = "USER_IP")
    public String getUserIp() {
        return userIp;
    }

    public void setUserIp(String userIp) {
        this.userIp = userIp;
    }

    @Basic
    @Column(name = "AUTHORIZE_CD")
    public String getAuthorizeCd() {
        return authorizeCd;
    }

    public void setAuthorizeCd(String authorizeCd) {
        this.authorizeCd = authorizeCd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UserTrace userTrace = (UserTrace) o;

        if (userTraceId != userTrace.userTraceId) return false;
        if (updtBy != userTrace.updtBy) return false;
        if (userId != null ? !userId.equals(userTrace.userId) : userTrace.userId != null) return false;
        if (visitNm != null ? !visitNm.equals(userTrace.visitNm) : userTrace.visitNm != null) return false;
        if (visitUrl != null ? !visitUrl.equals(userTrace.visitUrl) : userTrace.visitUrl != null) return false;
        if (visitDt != null ? !visitDt.equals(userTrace.visitDt) : userTrace.visitDt != null) return false;
        if (visitStopDt != null ? !visitStopDt.equals(userTrace.visitStopDt) : userTrace.visitStopDt != null)
            return false;
        if (updtDt != null ? !updtDt.equals(userTrace.updtDt) : userTrace.updtDt != null) return false;
        if (userIp != null ? !userIp.equals(userTrace.userIp) : userTrace.userIp != null) return false;
        if (authorizeCd != null ? !authorizeCd.equals(userTrace.authorizeCd) : userTrace.authorizeCd != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (int) (userTraceId ^ (userTraceId >>> 32));
        result = 31 * result + (userId != null ? userId.hashCode() : 0);
        result = 31 * result + (visitNm != null ? visitNm.hashCode() : 0);
        result = 31 * result + (visitUrl != null ? visitUrl.hashCode() : 0);
        result = 31 * result + (visitDt != null ? visitDt.hashCode() : 0);
        result = 31 * result + (visitStopDt != null ? visitStopDt.hashCode() : 0);
        result = 31 * result + (int) (updtBy ^ (updtBy >>> 32));
        result = 31 * result + (updtDt != null ? updtDt.hashCode() : 0);
        result = 31 * result + (userIp != null ? userIp.hashCode() : 0);
        result = 31 * result + (authorizeCd != null ? authorizeCd.hashCode() : 0);
        return result;
    }
}
