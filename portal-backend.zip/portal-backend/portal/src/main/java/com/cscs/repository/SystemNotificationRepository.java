package com.cscs.repository;

import com.cscs.portal.entity.SystemNotification;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * 用户监控信息表
 */
@SuppressWarnings("JpaQlInspection")
public interface SystemNotificationRepository extends JpaRepository<SystemNotification, Long> {

}
