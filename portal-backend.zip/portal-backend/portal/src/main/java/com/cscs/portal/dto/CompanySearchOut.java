package com.cscs.portal.dto;

import java.util.List;

/**
 *  高级企业查询接口返回数据

 * @ClassName: CompanySearchOut

 * @Description: TODO

 * @author: liunn

 * @date: 2018年9月13日 上午11:33:31
 */
public class CompanySearchOut{
	//企业id
	private String companyId;
	//企业名称
	private String companyName;
	//企业类型
    private String companyType;
    //企业状态
    private String companySt;
    //法定代表人
    private String legalPersonName;
    //成立时间
    private String foundDt;
    //注册资本
    private Object regCapital;
    //注册地
    private String officeAddr;
    //所属行业
    private String industry;
    //证券简称
    private List securitySnm;
    //证券代码
    private List securityCd;
    //董事长
    private String chairman;
    //总经理
    private String gmanager;
    //社会信用代码
    private String creditCd;
    //曾用名
    private String oldCompanyNm;
    //高亮字段
    private List highlightColumns;
	
	
	public List getHighlightColumns() {
		return highlightColumns;
	}
	public void setHighlightColumns(List highlightColumns) {
		this.highlightColumns = highlightColumns;
	}
	public String getOldCompanyNm() {
		return oldCompanyNm;
	}
	public void setOldCompanyNm(String oldCompanyNm) {
		this.oldCompanyNm = oldCompanyNm;
	}
	public String getChairman() {
		return chairman;
	}
	public void setChairman(String chairman) {
		this.chairman = chairman;
	}
	public String getGmanager() {
		return gmanager;
	}
	public void setGmanager(String gmanager) {
		this.gmanager = gmanager;
	}
	public String getCreditCd() {
		return creditCd;
	}
	public void setCreditCd(String creditCd) {
		this.creditCd = creditCd;
	}
	public List getSecuritySnm() {
		return securitySnm;
	}
	public void setSecuritySnm(List securitySnm) {
		this.securitySnm = securitySnm;
	}
	public List getSecurityCd() {
		return securityCd;
	}
	public void setSecurityCd(List securityCd) {
		this.securityCd = securityCd;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyType() {
		return companyType;
	}
	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}
	public String getCompanySt() {
		return companySt;
	}
	public void setCompanySt(String companySt) {
		this.companySt = companySt;
	}
	public String getLegalPersonName() {
		return legalPersonName;
	}
	public void setLegalPersonName(String legalPersonName) {
		this.legalPersonName = legalPersonName;
	}
	public String getFoundDt() {
		return foundDt;
	}
	public void setFoundDt(String foundDt) {
		this.foundDt = foundDt;
	}
	
	public Object getRegCapital() {
		return regCapital;
	}
	public void setRegCapital(Object regCapital) {
		this.regCapital = regCapital;
	}
	public String getOfficeAddr() {
		return officeAddr;
	}
	public void setOfficeAddr(String officeAddr) {
		this.officeAddr = officeAddr;
	}
    
}
