package com.cscs.portal.controller;

import com.alibaba.fastjson.JSON;
import com.cscs.portal.dto.UserMonitorInData;
import com.cscs.portal.dto.UserMonitorInfoData;
import com.cscs.portal.dto.UserMonitorXWInfoData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.UserMonitor;
import com.cscs.portal.services.MyMonitorService;
import com.cscs.util.DateUtils;
import org.apache.commons.collections.CollectionUtils;
import org.hibernate.engine.jdbc.SerializableClobProxy;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.io.Reader;
import java.lang.reflect.Proxy;
import java.sql.Clob;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping(value = "/myMonitor")
public class MyMonitor {

    @Autowired
    private MyMonitorService myMonitorService;

    @Autowired
    private CompanyBasicInfoController companyBasicInfoController;
    /**
     * 我的监控企业列表
     *
     * @return
     * @throws ParseException 
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public List<Map<String,Object>> list(HttpServletRequest request) throws ParseException {
        List<Map<String,Object>> outData = new ArrayList<>();
        Long userId = Long.valueOf((String)request.getAttribute("userId"));
        List<UserMonitor> itemList = myMonitorService.listCompanys(userId);
        //UserMonitorInfoData info = null;
        BaseOutData companyBasicResp = null;
        Map<String,Object> companyBasicInfo = null;
        for (UserMonitor item : itemList) {
            //info = new UserMonitorInfoData();
            //BeanUtils.copyProperties(item, info);
            //outData.add(info);
            companyBasicResp = (BaseOutData) companyBasicInfoController.getBasicInfo(String.valueOf(item.getCompanyId()));
        	if("0".equals(companyBasicResp.getCode())&&companyBasicResp.getData()!=null&&companyBasicResp.getData().get("result")!=null) {
        		companyBasicInfo =  (Map<String,Object>)companyBasicResp.getData().get("result");
        		companyBasicInfo.put("companyId", String.valueOf(item.getCompanyId()));
        		companyBasicInfo.put("monitorId", String.valueOf(item.getId()));
        		companyBasicInfo.put("monitorDt", DateUtils.dateToString(item.getDt()));
        		outData.add(companyBasicInfo);
        	}
        }
        return outData;
    }

    /**
     * 监控企业
     *
     * @return
     */
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public BaseOutData save(HttpServletRequest request,@RequestBody UserMonitorInfoData infoData) {
        BaseOutData outData = new BaseOutData();
        Long userId = Long.valueOf((String)request.getAttribute("userId"));
        infoData.setUserId(userId);
        try {
            int count = myMonitorService.findCount(userId);
            if (count >= 10) {
                outData.setCode("1");
                outData.setMessage("普通会员的企业监控数量不超过10家！");
                return outData;
            }
            UserMonitor info = new UserMonitor();
            BeanUtils.copyProperties(infoData, info);
            info.setDt(new Date());
            info.setIsdel(0L);
            
            List<UserMonitor> monitorList = myMonitorService.queryUserMonitorByCondition(info);
            if(!CollectionUtils.isEmpty(monitorList)) {
            	info.setId(monitorList.get(0).getId());
            }
            myMonitorService.save(info);
            outData.setCode("0");
        } catch (Exception ex) {
            outData.setCode("1");
        }
        return outData;
    }

    /**
     * 取消监控企业
     *
     * @return
     */
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
    public BaseOutData unMonitor(HttpServletRequest request,@PathVariable Long id) {
        BaseOutData outData = new BaseOutData();
        Long userId = Long.valueOf((String)request.getAttribute("userId"));
        try {
            myMonitorService.delete(id,userId);
            outData.setCode("0");
        } catch (Exception ex) {
            outData.setCode("1");
        }
        return outData;
    }

	public String blobToString(Object clobProxy) {
		String clobToStr = null;
		try {
			if (clobProxy != null) {
				SerializableClobProxy proxy = (SerializableClobProxy) Proxy.getInvocationHandler(clobProxy);
				Clob realClob = (Clob) proxy.getWrappedClob();
				StringBuffer sb = new StringBuffer(65535);// 64K
				Reader clobStream = null;
				clobStream = realClob.getCharacterStream();
				char[] b = new char[60000];// 每次获取60K
				int i = 0;
				while ((i = clobStream.read(b)) != -1) {
					sb.append(b, 0, i);
				}
				clobToStr = sb.toString();
			}
		} catch (Exception e) {
			clobToStr = "{\"msg\":\"transfer failed\"}";
		}
		return clobToStr;
	}

    
    /**
     * 监控动态
     *
     * @return
     */
    @RequestMapping(value = "/findList", method = RequestMethod.POST)
    public BaseOutData findList(HttpServletRequest request,@RequestBody UserMonitorInData inData) {
    	BaseOutData outData = new BaseOutData();
    	List<UserMonitorXWInfoData> monitorXWInfoList = new ArrayList<UserMonitorXWInfoData>();
        List<Object> userMonitorXwList = null;
        UserMonitorXWInfoData monitorXW = null;
        Long userId = Long.valueOf((String)request.getAttribute("userId"));
        Map<String,List<UserMonitorXWInfoData>> monitorWxListMap = new HashMap<String,List<UserMonitorXWInfoData>>();
        try {
        	userMonitorXwList = myMonitorService.findMonitorList(inData,userId,outData);
        	Object[] tmp = null;
        	for (Object userMonitorXw : userMonitorXwList) {
        		   tmp = (Object[]) userMonitorXw;
        		   monitorXW = new UserMonitorXWInfoData();
        		   //BeanUtils.copyProperties(userMonitorXw, monitorXW);
        		   monitorXW.setId( Long.parseLong(String.valueOf(tmp[0])));
        		   monitorXW.setCompanyId(Long.parseLong(String.valueOf(tmp[1])));
        		   monitorXW.setType((String) tmp[2]);
        		   monitorXW.setDt(DateUtils.dateToString((Date) tmp[3]));
        		   monitorXW.setContent(JSON.parse(blobToString(tmp[4])));
        		   monitorXW.setRiskId((String) tmp[5]);
        		   monitorXW.setCompanyName((String) tmp[6]);
        		   monitorXW.setIsRead(Long.parseLong(String.valueOf(tmp[7])));
        		   monitorXWInfoList.add(monitorXW);
			}
        	monitorWxListMap.put("result", monitorXWInfoList);
        	outData.setCode("0");
        	outData.setData(monitorWxListMap);
        } catch (Exception ex) {
           return outData;
        }
        return outData;
    }
    
    /**
     * 监控状态已读
     */
    @RequestMapping(value = "/markRead", method = RequestMethod.POST)
    public BaseOutData markRead(HttpServletRequest request,@RequestBody UserMonitorXWInfoData inData) {
		 BaseOutData outData = new BaseOutData();
		 Long userId = Long.valueOf((String)request.getAttribute("userId"));
		 inData.setUserId(userId);
	     try {
	    	 myMonitorService.markRead(inData);
	         outData.setCode("0");
	     } catch (Exception ex) {
	         outData.setCode("1");
	     }
         return outData;
    }
    
    /**
     * 监控企业数量
     * @param inData
     * @return
     */
    @RequestMapping(value = "/monitoredCount", method = RequestMethod.GET)
    public BaseOutData monitoredCount(HttpServletRequest request) {
		 BaseOutData outData = new BaseOutData();
		 Long userId = Long.valueOf((String)request.getAttribute("userId"));
         outData.setCount(myMonitorService.findCount(userId));
         outData.setCode("0");
         return outData;
    }
    
    /**
     * 未读监控动态数量
     * @param inData
     * @return
     */
    @RequestMapping(value = "/unreadCount", method = RequestMethod.GET)
    public BaseOutData unreadCount(HttpServletRequest request) {
		 BaseOutData outData = new BaseOutData();
		 Long userId = Long.valueOf((String)request.getAttribute("userId"));
         outData.setCount(myMonitorService.findUnreadCount(userId));
         outData.setCode("0");
         return outData;
    }

    @RequestMapping(value = "/companyFocusMonitorStatus/{companyId}", method = RequestMethod.GET)
    public BaseOutData companyFocusMonitorStatus(HttpServletRequest request,@PathVariable Long companyId) {
		 BaseOutData outData = new BaseOutData();
		 Long userId = Long.valueOf((String)request.getAttribute("userId"));
         outData.setCode("0");
         outData.setData(myMonitorService.companyFocusMonitorStatus(companyId,userId));
         return outData;
    }
    
    
}
