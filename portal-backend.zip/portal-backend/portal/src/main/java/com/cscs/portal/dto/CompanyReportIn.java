package com.cscs.portal.dto;

/**
 * Created by sh on 2016/8/29.
 */
public class CompanyReportIn {

    //企业标识符
    private long companyId;

    //科目类型  1：资产负债表 2: 利润表 3: 现金流量表
    private int subjectType;

    //报表时间类型  1,2,3,4,5：全部 1：年报 2：中报 3：一季报 4：三季报 5：最新
    private String rptTimetypeCd;

    //报表日期  0：全部 1：今年 2：去年 3: 3年 5: 5年 10: 10年
    private String rptDt;

    //是否上市后报表 0,1：全部 0:否 1：是
    private String isPublicRpt;

    //报表合并类型  1:母公司 2:合并 3:母公司（调整）4:合并（调整）
    private String combineTypeCd;

    //合并：0 单季：1
    private String quarterly;

    public long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(long companyId) {
        this.companyId = companyId;
    }

    public int getSubjectType() {
        return subjectType;
    }

    public void setSubjectType(int subjectType) {
        this.subjectType = subjectType;
    }

    public String getRptTimetypeCd() {
        return rptTimetypeCd;
    }

    public void setRptTimetypeCd(String rptTimetypeCd) {
        this.rptTimetypeCd = rptTimetypeCd;
    }

    public String getRptDt() {
        return rptDt;
    }

    public void setRptDt(String rptDt) {
        this.rptDt = rptDt;
    }

    public String getIsPublicRpt() {
        return isPublicRpt;
    }

    public void setIsPublicRpt(String isPublicRpt) {
        this.isPublicRpt = isPublicRpt;
    }

    public String getCombineTypeCd() {
        return combineTypeCd;
    }

    public void setCombineTypeCd(String combineTypeCd) {
        this.combineTypeCd = combineTypeCd;
    }

    public String getQuarterly() {
        return quarterly;
    }

    public void setQuarterly(String quarterly) {
        this.quarterly = quarterly;
    }
}
