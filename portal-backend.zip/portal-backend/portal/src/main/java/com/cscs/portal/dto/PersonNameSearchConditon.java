package com.cscs.portal.dto;

/**
 * 
 * @ClassName: PersonNameSearchConditon
 * @Description: 人名搜索查询条件
 * @author: liunn
 * @date: 2018年9月15日 下午10:42:00
 */
public class PersonNameSearchConditon{
	//搜索框关键字
    private String keyword;
    //当前页
    private Integer curPage;
    //每页显示的条数
    private Integer rowNum;
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public Integer getCurPage() {
		return curPage;
	}
	public void setCurPage(Integer curPage) {
		this.curPage = curPage;
	}
	public Integer getRowNum() {
		return rowNum;
	}
	public void setRowNum(Integer rowNum) {
		this.rowNum = rowNum;
	}
	
}
