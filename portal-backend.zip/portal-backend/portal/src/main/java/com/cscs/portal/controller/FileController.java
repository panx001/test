package com.cscs.portal.controller;

import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.util.Contants;
import com.cscs.util.SFTPUtil;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping(value = "/file")
public class FileController {

    @RequestMapping(value = "/upload", method = RequestMethod.POST)
    public BaseOutData uploadOneFile(HttpServletRequest request, @RequestParam("file") MultipartFile[] file) throws Exception {
        BaseOutData out = new BaseOutData();
        if (null == file || file.length > 1) {
            out.setMessage("文件参数不对");
            out.setCode("1");
            return out;
        }
        MultipartFile f = file[0];
        SFTPUtil sftp = new SFTPUtil();
        try {
            sftp.login();
//            sftp.upload(Contants.FTP_PATH, f.getOriginalFilename(), f.getInputStream());
        }
        catch (Exception e) {

        } finally {
            sftp.logout();
        }

        out.setCode("0");
        out.setMessage(f.getOriginalFilename());
        return  out;
    }

    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public BaseOutData deleteOneFile(@RequestBody Map<String,String> inData) throws Exception {
        BaseOutData out = new BaseOutData();
        String fileName = inData.get("path");
        SFTPUtil sftp = new SFTPUtil();
        try {
            sftp.login();
//            sftp.delete(Contants.FTP_PATH, fileName);
        }
        catch (Exception e) {

        } finally {
            sftp.logout();
        }
        out.setCode("0");
        return  out;
    }
}
