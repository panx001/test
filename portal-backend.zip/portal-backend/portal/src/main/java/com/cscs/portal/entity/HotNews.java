package com.cscs.portal.entity;

import javax.persistence.*;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "HOT_NEWS", schema = "CS_PORTAL", catalog = "")
public class HotNews {
    private long id;
    private String link;
    private String title;
    private String source;
    private String companyIdList;
    private String companyNmList;
    private Date postdt;
    private Long status;
    private Long isdel;
    
    //相关性
    private String relevance;
    
    private String warningType;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_HOT_NEWS")
    @SequenceGenerator(sequenceName = "SEQ_HOT_NEWS", name = "SEQ_HOT_NEWS")
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "LINK")
    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    @Basic
    @Column(name = "TITLE")
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Basic
    @Column(name = "SOURCE")
    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    @Basic
    @Column(name = "COMPANYID")
    public String getCompanyIdList() {
        return companyIdList;
    }

    public void setCompanyIdList(String companyIdList) {
        this.companyIdList = companyIdList;
    }

    @Basic
    @Column(name = "COMPANYNM")
    public String getCompanyNmList() {
        return companyNmList;
    }

    public void setCompanyNmList(String companyNmList) {
        this.companyNmList = companyNmList;
    }

    @Basic
    @Column(name = "POSTDT")
    public Date getPostdt() {
        return postdt;
    }

    public void setPostdt(Date postdt) {
        this.postdt = postdt;
    }

    @Basic
    @Column(name = "STATUS")
    public Long getStatus() {
        return status;
    }

    public void setStatus(Long status) {
        this.status = status;
    }

    @Basic
    @Column(name = "ISDEL")
    public Long getIsdel() {
        return isdel;
    }

    public void setIsdel(Long isdel) {
        this.isdel = isdel;
    }

    @Basic
    @Column(name = "RELEVANCE")
    public String getRelevance() {
		return relevance;
	}

	public void setRelevance(String relevance) {
		this.relevance = relevance;
	}

	@Basic
	@Column(name = "WARNINGTYPE")
	public String getWarningType() {
		return warningType;
	}

	public void setWarningType(String warningType) {
		this.warningType = warningType;
	}

	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        HotNews hotNews = (HotNews) o;
        return id == hotNews.id &&
                Objects.equals(link, hotNews.link) &&
                Objects.equals(title, hotNews.title) &&
                Objects.equals(source, hotNews.source) &&
                Objects.equals(companyIdList, hotNews.companyIdList) &&
                Objects.equals(companyNmList, hotNews.companyNmList) &&
                Objects.equals(postdt, hotNews.postdt) &&
                Objects.equals(status, hotNews.status) &&
                Objects.equals(isdel, hotNews.isdel) &&
		        Objects.equals(relevance, hotNews.relevance) &&
		        Objects.equals(warningType, hotNews.warningType);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, link, title, source, companyIdList, companyNmList, postdt, status, isdel);
    }
}
