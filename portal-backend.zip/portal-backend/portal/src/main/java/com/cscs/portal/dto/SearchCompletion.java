package com.cscs.portal.dto;

import java.util.Set;
/**
 * Created by qin on 2016/8/9.
 */
public class SearchCompletion {

    //公司Id
    private String companyId;

    private String companyCd;
    //名称
    private String companyNm;
    //类型
    private String type;

    private String blnumb;

    private Set<String> oldname;

    private String regCapital;
    private String foundDt;
    private String companyst;
    private String securityCd;
    private String securitySnm;
    private String legRepresent;

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getCompanyCd() {
        return companyCd;
    }

    public void setCompanyCd(String companyCd) {
        this.companyCd = companyCd;
    }

    public String getCompanyNm() {
        return companyNm;
    }

    public void setCompanyNm(String companyNm) {
        this.companyNm = companyNm;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Set<String> getOldname() {
        return oldname;
    }

    public void setOldname(Set<String> oldname) {
        this.oldname = oldname;
    }

    public String getBlnumb() {
        return blnumb;
    }

    public void setBlnumb(String blnumb) {
        this.blnumb = blnumb;
    }

    public String getRegCapital() {
        return regCapital;
    }

    public void setRegCapital(String regCapital) {
        this.regCapital = regCapital;
    }

    public String getFoundDt() {
        return foundDt;
    }

    public void setFoundDt(String foundDt) {
        this.foundDt = foundDt;
    }

    public String getCompanyst() {
        return companyst;
    }

    public void setCompanyst(String companyst) {
        this.companyst = companyst;
    }

    public String getSecurityCd() {
        return securityCd;
    }

    public void setSecurityCd(String securityCd) {
        this.securityCd = securityCd;
    }

    public String getSecuritySnm() {
        return securitySnm;
    }

    public void setSecuritySnm(String securitySnm) {
        this.securitySnm = securitySnm;
    }

    public String getLegRepresent() {
        return legRepresent;
    }

    public void setLegRepresent(String legRepresent) {
        this.legRepresent = legRepresent;
    }
}
