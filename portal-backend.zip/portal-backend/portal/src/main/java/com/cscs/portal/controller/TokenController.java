package com.cscs.portal.controller;

import com.cscs.portal.security.util.JWTUtil;
import com.cscs.portal.services.CacheServices;
import com.cscs.util.Jwt;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by huchangchun on 2017/2/15.
 */

@CrossOrigin
@RestController
@RequestMapping(value = "/token")
public class TokenController {

    @Autowired
    CacheServices cacheServices;

    @RequestMapping(value = "/refreshToken", method = RequestMethod.POST)
    public Map refreshToken(@RequestBody Map map){
        Map<String,String> out = new HashMap<>();
//        JSONObject item = new JSONObject(token);
//        out.put("token",Jwt.setToken(item.getString("token")));
        String[] claimsArr = JWTUtil.getClaims((String)map.get("token"));
        out.put("token",JWTUtil.sign(claimsArr[0],claimsArr[1]));
        return out;
    }

    @RequestMapping(value = "/verifyToken", method = RequestMethod.POST)
    public int verifyToken(@RequestBody String token){
        JSONObject item = new JSONObject(token);
        return Jwt.findToken(item.getString("token"));
    }
}