package com.cscs.portal.services.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cscs.portal.dto.CompanyTopicsCInfoData;
import com.cscs.portal.dto.CompanyTopicsInData;
import com.cscs.portal.dto.CompanyTopicsInfoData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.CompanyTopics;
import com.cscs.portal.entity.CompanyTopicsC;
import com.cscs.portal.services.CompanyTopicsServices;
import com.cscs.repository.CompanyTopicsCRepository;
import com.cscs.repository.CompanyTopicsRepository;

/**
 * Created by dch on 2016/8/10.
 */
@SuppressWarnings("JpaQlInspection")
@Service
public class CompanyTopicsServicesImpl implements CompanyTopicsServices {

    @Autowired
    private CompanyTopicsRepository repository;

    @Autowired
    private CompanyTopicsCRepository Crepository;

    @Autowired
    EntityManager em;

    @SuppressWarnings("unchecked")
	public List<CompanyTopics> search(CompanyTopicsInData inData,BaseOutData outData) {
        int page = inData.getPage() == 0 ? 0 :inData.getPage() - 1;
        int pageSize =inData.getPageSize() == 0 ? 10 :inData.getPageSize();

        String sql = "SELECT h FROM CompanyTopics h WHERE isdel = 0";
        String countSql = "SELECT count(1) FROM CompanyTopics  WHERE isdel = 0";
        if (null != inData.getStatus()){
            sql += " AND status = "+inData.getStatus();
            countSql += " AND status = " +inData.getStatus();
        }
        
        //按优先级展示
        sql+=" ORDER BY PRIORITY";
        
        Query countQuery = em.createQuery(countSql);
        Integer total = Integer.valueOf(countQuery.getSingleResult().toString());
        outData.setCount(total);
        Query query = em.createQuery(sql);
        query.setFirstResult(page * pageSize);
        query.setMaxResults(pageSize);

//        List<CompanyTopics> itemList = (List<CompanyTopics>)query.getResultList();
//        for(CompanyTopics item :itemList){
//            CompanyTopicsInfoData info = new CompanyTopicsInfoData();
//            BeanUtils.copyProperties(item,info);
//
//            List<CompanyTopicsC> cItemList = searchTopicsC(item.getId());
//            List<CompanyTopicsCInfoData> cInfoList = new ArrayList<>();
//            for(CompanyTopicsC cItem : cItemList) {
//                CompanyTopicsCInfoData cInfo = new CompanyTopicsCInfoData();
//                BeanUtils.copyProperties(cItem,cInfo);
//                cInfoList.add(cInfo);
//            }
//            info.setcInfo(cInfoList);
//            out.add(info);
//        }
        return query.getResultList();
    }

    public CompanyTopicsInfoData searchById(Long id) {
        CompanyTopicsInfoData out = new CompanyTopicsInfoData();
        CompanyTopics topics = searchTopics(id);
        BeanUtils.copyProperties(topics,out);

        //查询相关企业
        List<CompanyTopicsC> topicsC = searchTopicsC(id);
        List<CompanyTopicsCInfoData> cInfo = new ArrayList<>();
        CompanyTopicsCInfoData infoData = null;
        for(CompanyTopicsC item : topicsC) {
            infoData = new CompanyTopicsCInfoData();
            BeanUtils.copyProperties(item,infoData);
            cInfo.add(infoData);
        }
        out.setcInfo(cInfo);
        return out;
    }

    public CompanyTopics searchTopics(Long id){
        String sql = "SELECT h FROM CompanyTopics h WHERE isdel = 0 and Id = ?1";
        Query query = em.createQuery(sql).setParameter(1,id);
        return (CompanyTopics)query.getSingleResult();
    }

    private List<CompanyTopicsC> searchTopicsC(Long id){
        String sql = "SELECT h FROM CompanyTopicsC h WHERE companyTopicsId = ?1";
        Query query = em.createQuery(sql).setParameter(1,id);
        return query.getResultList();
    }

    @Transactional
    public CompanyTopics save(CompanyTopicsInfoData inData) {
        CompanyTopics companyTopics = new CompanyTopics();
        BeanUtils.copyProperties(inData,companyTopics);
        companyTopics.setIsdel(0L);
        companyTopics = repository.save(companyTopics);
        //删除企业专题与相关企业的关联关系
        //String sql = "DELETE FROM COMPANY_TOPICS_C WHERE ID = "+ companyTopics.getId();
        String sql = "DELETE FROM COMPANY_TOPICS_C WHERE COMPANY_TOPICS_ID = "+ companyTopics.getId();
        em.createNativeQuery(sql).executeUpdate();

        CompanyTopicsC companyTopicsC = null;
        for(CompanyTopicsCInfoData info : inData.getcInfo()){
            companyTopicsC = new CompanyTopicsC();
            BeanUtils.copyProperties(info,companyTopicsC);
            companyTopicsC.setCompanyTopicsId(companyTopics.getId());
            Crepository.save(companyTopicsC);
        }
        return companyTopics;
    }

    @Transactional
    public int delete(Long id) {
        String sql = "UPDATE COMPANY_TOPICS SET ISDEL = 1 WHERE ID = "+ id;
        return em.createNativeQuery(sql).executeUpdate();
    }
}
