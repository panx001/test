package com.cscs;

import com.cscs.util.CountTimeInterceptor;
import com.cscs.util.TraceDuplicateInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import java.util.concurrent.Executor;

@SpringBootApplication
@EnableTransactionManagement
@Configuration
@EnableCaching
@EnableAsync
public class PortalApplication extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(PortalApplication.class);
    }

    public static void main(String[] args) throws Exception {
        SpringApplication.run(PortalApplication.class, args);
    }

    @Bean(name = "threadPoolTaskExecutor")
    public Executor threadPoolTaskExecutor() {
        return new ThreadPoolTaskExecutor();
    }
  
    @Configuration
    static class WebMvcConfigurer extends WebMvcConfigurerAdapter {

//        @Autowired
//        private LoginInterceptor loginInterceptor;

//        @Autowired
//        private DuplicateLoginInterceptor duplicateLoginInterceptor;

//        @Autowired
//        private AuthorizeInterceptor authorizeInterceptor;
        
        @Autowired
        private TraceDuplicateInterceptor traceDuplicateInterceptor;

//        @Value("${authorize.flag}")
//        String authorizeFlag;

        @Override
        public void addInterceptors(InterceptorRegistry registry) {
//            registry.addInterceptor(loginInterceptor).addPathPatterns("/**");
//            registry.addInterceptor(duplicateLoginInterceptor).addPathPatterns("/**");
            registry.addInterceptor(traceDuplicateInterceptor).addPathPatterns("/**");
//            if ("open".equals(authorizeFlag)) {
//                registry.addInterceptor(authorizeInterceptor).addPathPatterns("/**");
//            }
            //registry.addInterceptor(new CustomInterceptor()).addPathPatterns("/**");
            registry.addInterceptor(new CountTimeInterceptor()).addPathPatterns("/**");
            super.addInterceptors(registry);
        }

        @Override
        public void addCorsMappings(CorsRegistry registry) {
            registry.addMapping("/**").allowedOrigins("*");
        }
    }
}
