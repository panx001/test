package com.cscs.portal.entity;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * Created by sh on 2016/11/2.
 */
@Entity
public class Role {
    private Long roleId;
    private String roleNm;
    private Long createBy;
    private Timestamp createDt;
    private Long updtBy;
    private Timestamp updtDt;

    @Id
    @Column(name = "ROLE_ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "SEQ_ROLE")
    @SequenceGenerator(sequenceName = "SEQ_ROLE",name="SEQ_ROLE")
    public Long getRoleId() {
        return roleId;
    }

    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

    @Basic
    @Column(name = "ROLE_NM")
    public String getRoleNm() {
        return roleNm;
    }

    public void setRoleNm(String roleNm) {
        this.roleNm = roleNm;
    }

    @Basic
    @Column(name = "CREATE_BY")
    public Long getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }

    @Basic
    @Column(name = "CREATE_DT")
    public Timestamp getCreateDt() {
        return createDt;
    }

    public void setCreateDt(Timestamp createDt) {
        this.createDt = createDt;
    }

    @Basic
    @Column(name = "UPDT_BY")
    public Long getUpdtBy() {
        return updtBy;
    }

    public void setUpdtBy(Long updtBy) {
        this.updtBy = updtBy;
    }

    @Basic
    @Column(name = "UPDT_DT")
    public Timestamp getUpdtDt() {
        return updtDt;
    }

    public void setUpdtDt(Timestamp updtDt) {
        this.updtDt = updtDt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Role role = (Role) o;

        if (roleId != role.roleId) return false;
        if (roleNm != null ? !roleNm.equals(role.roleNm) : role.roleNm != null) return false;
        if (createBy != null ? !createBy.equals(role.createBy) : role.createBy != null) return false;
        if (createDt != null ? !createDt.equals(role.createDt) : role.createDt != null) return false;
        if (updtBy != null ? !updtBy.equals(role.updtBy) : role.updtBy != null) return false;
        return updtDt != null ? updtDt.equals(role.updtDt) : role.updtDt == null;

    }

    @Override
    public int hashCode() {
        int result = (int) (roleId ^ (roleId >>> 32));
        result = 31 * result + (roleNm != null ? roleNm.hashCode() : 0);
        result = 31 * result + (createBy != null ? createBy.hashCode() : 0);
        result = 31 * result + (createDt != null ? createDt.hashCode() : 0);
        result = 31 * result + (updtBy != null ? updtBy.hashCode() : 0);
        result = 31 * result + (updtDt != null ? updtDt.hashCode() : 0);
        return result;
    }
}
