package com.cscs.portal.services.impl;

import com.cscs.portal.dto.RoleInfoData;
import com.cscs.portal.entity.Role;
import com.cscs.portal.services.RoleServices;
import com.cscs.repository.RoleRepository;
import com.cscs.util.DateUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * Created by dch on 2016/11/7.
 * 角色接口实现类
 */
@SuppressWarnings("JpaQlInspection")
@Service
public class RoleServicesImpl implements RoleServices {

    @Autowired
    private RoleRepository roleRepository;

    @PersistenceContext
    EntityManager em;

    /**
     * 新增或更新角色信息
     *
     * @param roleInfoData
     */
    @Override
    public void save(RoleInfoData roleInfoData) {
        Role rr = new Role();
        BeanUtils.copyProperties(roleInfoData, rr);
        Date nowDate = new Date();
        Timestamp timestamp = DateUtils.dateChangeTimestamp(nowDate);
        if (StringUtils.isEmpty(roleInfoData.getRoleId())) {
            rr.setCreateDt(timestamp);
            rr.setCreateBy(roleInfoData.getAccountId());
        }
        rr.setUpdtDt(timestamp);
        rr.setUpdtBy(roleInfoData.getAccountId());
        roleRepository.save(rr);
    }

    /**
     * 删除角色信息
     *
     * @param roleIdString
     */
    @Transactional
    @Override
    public void deleteRole(String roleIdString) {
        //1.删除用户角色关联信息
        String sql1 = "delete from ACCOUNT_ROLE_XW where role_id in ?1";
        Query query1 = em.createNativeQuery(sql1);
        query1.setParameter(1,Arrays.asList(roleIdString.split(",")));
        query1.executeUpdate();

        //2.删除角色信息
        String sql2 = "delete from ROLE where role_id in ?1";
        Query query2 = em.createNativeQuery(sql2);
        query2.setParameter(1,Arrays.asList(roleIdString.split(",")));
        query2.executeUpdate();
    }

    /**
     * 获取角色信息
     *
     * @return
     */
    @Override
    public List<Role> findAll() {
        return roleRepository.findAll();
    }

    /**
     * 获取角色信息
     *
     * @param roleNm
     * @return
     */
    @Override
    public Role findOne(String roleNm) {
        return roleRepository.findByRoleNm(roleNm);
    }
}
