package com.cscs.portal.dto;

import com.cscs.portal.dto.base.BaseInData;

/**
 * Created by sh on 2016/8/7.
 */
public class CompanyTopicsInData extends BaseInData{
    private Long status;

    public Long getStatus() {
        return status;
    }

    public void setStatus(Long status) {
        this.status = status;
    }
}
