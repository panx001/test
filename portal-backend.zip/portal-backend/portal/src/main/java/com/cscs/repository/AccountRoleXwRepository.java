package com.cscs.repository;

import com.cscs.portal.entity.AccountRoleXw;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by dch on 2016/11/7.
 * 账户角色关系
 */
public interface AccountRoleXwRepository extends JpaRepository<AccountRoleXw,Long> {

}
