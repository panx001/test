package com.cscs.portal.controller;

import java.sql.Clob;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cscs.portal.dto.UserBasicinfoInfoData;
import com.cscs.portal.dto.UserBasicinfoOutData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.UserBasicinfo;
import com.cscs.portal.services.UserBasicInfoServices;
import com.cscs.util.ConstantWebUtils;
import com.cscs.util.StringUtil;


/**
 * Created by dch on 2016/11/7.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/userbasicinfo")
public class UserBasicInfoController {

    @Autowired
    UserBasicInfoServices userBasicInfoServices;//用户的个人信息服务接口

    //查询用户个人信息

    @RequestMapping(value = "/getUserBasicinfo", method = RequestMethod.GET)
    public UserBasicinfoOutData getUserBasicinfo(HttpServletRequest request) {
        UserBasicinfoOutData out = new UserBasicinfoOutData();
        //Long accountId = Long.valueOf((String)request.getAttribute("accountId"));
        Long userId = Long.valueOf((String)request.getAttribute("userId"));
        try {
            UserBasicinfo item = userBasicInfoServices.getUserBasicinfoOutData(userId);
            BeanUtils.copyProperties(item, out);
            out.setCellphone(item.getAccountNm());
            out.setCode("0");
        } catch (Exception e) {
            out.setCode("1");
            out.setMessage(e.getMessage());
        }
        return out;
    }

    //查询用户个人信息

    @RequestMapping(value = "/getImage", method = RequestMethod.GET)
    public Map getImage(HttpServletRequest request) {
        Map<String, String> out = new HashMap<>();
        Long accountId = Long.valueOf((String)request.getAttribute("userId"));
        Object item = userBasicInfoServices.getImage(accountId);
        if (item != null) {
            out.put("image", ConstantWebUtils.oracleClob2Str((Clob) item));
        } else {
            out.put("image", "");
        }
        return out;
    }

    /**
     * 更新/保存 用户个人信息
     *
     * @param infoData
     * @return
     */

    @RequestMapping(value = "/updateUserBasicinfo", method = RequestMethod.POST)
    public BaseOutData save(HttpServletRequest request,@RequestBody UserBasicinfoInfoData infoData) {
        BaseOutData outData = new BaseOutData();
//        Long accountId = Long.valueOf((String)request.getAttribute("accountId"));
        Long userId = Long.valueOf((String)request.getAttribute("userId"));
        try {
            userBasicInfoServices.setUserBasicinfo(infoData,userId);
            outData.setCode("0");
        } catch (Exception e) {
            outData.setCode("1");
            outData.setMessage(e.getMessage());
        }
        return outData;
    }

//    /**
//     * 更新用户图像
//     *
//     * @param accountId
//     * @param file
//     * @return
//     */
//
//    @RequestMapping(value = "/updateHeadUrl", method = RequestMethod.POST)
//    public BaseOutData updateHeadUrl(@RequestParam("accountId") Long accountId, @RequestParam("upload") MultipartFile file) {
//        BaseOutData out = new BaseOutData();
//        try {
//            if (file.isEmpty()) {
//                out.setCode("1");
//                out.setMessage("未选择上传文件！");
//                return out;
//            }
//
//            String filename = file.getOriginalFilename();
//            String fileType = filename.substring(filename.lastIndexOf(".") + 1, filename.length());
//            //jpg,jpeg,bmp,gif,png
//            if (!"jpg".equals(fileType) && !"jpeg".equals(fileType)
//                    && !"bmp".equals(fileType) && !"png".equals(fileType)) {
//                out.setCode("1");
//                out.setMessage("上传文件类型错误！");
//                return out;
//            }
//            if (file.getSize() < 2 * 1024 * 1024) {
//                //获取图片的字节流
//                byte[] bytePhoto = ConstantWebUtils.file2Byte(file);
//                //压缩图片并转码为Base64
//                String base64photo = ConstantWebUtils.resize(bytePhoto, 300, 0.7f);
//                userBasicInfoServices.updateUserBasicinfo(accountId, base64photo);
//                out.setCode("0");
//            } else {
//                out.setCode("1");
//                out.setMessage("图片过大！");
//            }
//        } catch (Exception e) {
//            out.setCode("1");
//            out.setMessage(e.getMessage());
//        }
//        return out;
//    }

    /**
     * 更新用户图像
     * @param userBasicinfoInfoData
     * @param userBasicinfoInfoData
     * @return
     */

    @RequestMapping(value = "/updateHeadUrl",method = RequestMethod.POST)
    public BaseOutData updateHeadUrlBase(HttpServletRequest request,@RequestBody UserBasicinfoInfoData userBasicinfoInfoData){
        BaseOutData out = new BaseOutData();
       // Long accountId = Long.valueOf((String)request.getAttribute("accountId"));
        Long userId = Long.valueOf((String)request.getAttribute("userId"));
//        userBasicinfoInfoData.setAccountId(userId);
        try {
            if(StringUtil.isEmpty(userBasicinfoInfoData.getHeadUrl())|| StringUtil.isEmpty(userId.toString()))
            {
                out.setCode("1");
                out.setMessage("未获取数据!");
                return  out;
            }
            userBasicInfoServices.updateUserBasicinfo(userId,userBasicinfoInfoData.getHeadUrl());
            out.setCode("0");
        } catch (Exception e) {
            out.setCode("1");
            out.setMessage(e.getMessage());
        }
        return out;
    }
}
