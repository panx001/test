package com.cscs.portal.services;

import java.util.List;

/**
 * Created by sh on 2016/8/5.
 */
public interface CompanyInfoServices {

    String getCompyCreditRating(String companyName);

    List<String> getCompyTipInfo(String companyId);

    //财务指标 根据指标取得城投公司指标值(城投)
    List<Object> findExposureCodeDetail(Long id, String code);

    //财务指标 根据指标取得行业公司指标值(行业)
    List<Object> findIndustryCodeDetail(Long id, String code);
}
