package com.cscs.portal.dto;

/**
 * 
 * @ClassName: BondIssuerConditon
 * @Description: 债券发行人查询条件
 * @author: liunn
 * @date: 2018年9月15日 下午9:34:11
 */
public class BondIssuerConditon{
	//企业性质
    private String companyType;
	//行业分类
	private String industry;
	//是否上市（上市包括沪深+新三板+老三板）
	private String islist;
	public String getCompanyType() {
		return companyType;
	}
	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getIslist() {
		return islist;
	}
	public void setIslist(String islist) {
		this.islist = islist;
	}
	
}
