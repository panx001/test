package com.cscs;

import com.cscs.portal.security.shiro.JWTFilter;
import com.cscs.portal.security.shiro.CustomRealm;

import org.apache.commons.collections.map.LinkedMap;
import org.apache.shiro.mgt.DefaultSessionStorageEvaluator;
import org.apache.shiro.mgt.DefaultSubjectDAO;
import org.apache.shiro.spring.LifecycleBeanPostProcessor;
import org.apache.shiro.spring.security.interceptor.AuthorizationAttributeSourceAdvisor;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.aop.framework.autoproxy.DefaultAdvisorAutoProxyCreator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

import javax.servlet.Filter;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

@Configuration
public class ShiroConfig {

    @Bean(name="securityManager")
    public DefaultWebSecurityManager getManager(CustomRealm realm) {
        DefaultWebSecurityManager manager = new DefaultWebSecurityManager();
        // 使用自己的realm
        manager.setRealm(realm);

        /*
         * 关闭shiro自带的session，详情见文档
         * http://shiro.apache.org/session-management.html#SessionManagement-StatelessApplications%28Sessionless%29
         */
        DefaultSubjectDAO subjectDAO = new DefaultSubjectDAO();
        DefaultSessionStorageEvaluator defaultSessionStorageEvaluator = new DefaultSessionStorageEvaluator();
        defaultSessionStorageEvaluator.setSessionStorageEnabled(false);
        subjectDAO.setSessionStorageEvaluator(defaultSessionStorageEvaluator);
        manager.setSubjectDAO(subjectDAO);

        return manager;
    }

    @Bean(name="shiroFilter")
    public ShiroFilterFactoryBean factory(DefaultWebSecurityManager securityManager) {
        ShiroFilterFactoryBean factoryBean = new ShiroFilterFactoryBean();

        // 添加自己的过滤器并且取名为jwt
        Map<String, Filter> filterMap = new HashMap<>();
        filterMap.put("jwt", new JWTFilter());
        factoryBean.setFilters(filterMap);

        factoryBean.setSecurityManager(securityManager);
        factoryBean.setUnauthorizedUrl("/401");
        /*
         * 自定义url规则
         * http://shiro.apache.org/web.html#urls-
         */
        Map<String, String> filterRuleMap = new LinkedHashMap<String, String>();
       
        
        //---登录注册------AccountController
        filterRuleMap.put("/account/save", "anon");
        filterRuleMap.put("/account/verify/**", "anon");
        filterRuleMap.put("/account/updateUserPwd", "anon");
        filterRuleMap.put("/account/login", "anon");
        
        //---BondSearchController
        filterRuleMap.put("/bond/search/bondTypeSta", "anon");
        filterRuleMap.put("/bond/search/industrySta", "anon");
        filterRuleMap.put("/bond/search/bondDefaultsStaList", "anon");
        filterRuleMap.put("/bond/search/regionSta", "anon");
        filterRuleMap.put("/bond/search/companyTypeSta", "anon");
        filterRuleMap.put("/bond/search/ratingDownStaList", "anon");
        filterRuleMap.put("/bond/search/adviceIndustrySta", "anon");
        filterRuleMap.put("/bond/search/auditadviceSta", "anon");
        filterRuleMap.put("/bond/search/financialRiskStaList", "anon");
        filterRuleMap.put("/bond/search/bondMarketPublishSta", "anon");
        filterRuleMap.put("/bond/search/provinceSta/**", "anon");
        filterRuleMap.put("/bond/search/provinceTotalSta/**", "anon");
        filterRuleMap.put("/bond/search/maxProvince/**", "anon");
        filterRuleMap.put("/bond/search/citySta/**", "anon");
        filterRuleMap.put("/bond/search/regAddr", "anon");
        
        //--CodeController
        filterRuleMap.put("/code/**", "anon");
        
        ///CompanyCreditController
        filterRuleMap.put("/company/credit/compyCredit/*", "anon");
        filterRuleMap.put("/company/credit/exposure/*", "anon");
        filterRuleMap.put("/company/credit/yearReport/*", "anon");
        filterRuleMap.put("/company/credit/quanFactorHistory/**", "anon");
        filterRuleMap.put("/company/credit/quanFactorIndustry/**", "anon");
        filterRuleMap.put("/company/credit/pledge/**", "anon");
        filterRuleMap.put("/company/credit/expect/**", "anon");
        filterRuleMap.put("/company/credit/expectHistory/**", "anon");
        filterRuleMap.put("/company/credit/expectScatter/**", "anon");
        filterRuleMap.put("/company/credit/credit/**", "anon");
        filterRuleMap.put("/company/credit/guarantee/**", "anon");
        //filterRuleMap.put("/company/credit/guaranteeReport/**", "anon");
        //filterRuleMap.put("/company/credit/compyAnnounce/**", "anon");
       
        //CompanyNewsController
        filterRuleMap.put("/company/news/negativenewswarningcode/**", "anon");
        //filterRuleMap.put("/company/news/negativenewscompany/**", "anon");
        //filterRuleMap.put("/company/news/negativenews", "anon");
        filterRuleMap.put("/company/news/announcestatistics/**", "anon");
        filterRuleMap.put("/company/news/announce/**", "anon");
        filterRuleMap.put("/company/news/treadnewslist", "anon");
        filterRuleMap.put("/company/news/relatednewslist", "anon");
        filterRuleMap.put("/company/news/detail/**", "anon");
        filterRuleMap.put("/company/news/recommend/**", "anon");

        //CompanyRelatedRiskController
        filterRuleMap.put("/company/relatedRisk/sharehdrelation/*", "anon");
        
        //CompanySearchController
        filterRuleMap.put("/company/search/company/*", "anon"); 
        
        //FileController
        filterRuleMap.put("/file/**", "anon"); 
        
        //GuessController
        filterRuleMap.put("/guess/hotNews/search", "anon");
        filterRuleMap.put("/guess/hotNews/search/*", "anon");
        filterRuleMap.put("/guess/compyTopic/search/*", "anon");
        filterRuleMap.put("/guess/compyTopic/search", "anon");
        
        //HotItemsController
        filterRuleMap.put("/hotItems/hotCompanies/search", "anon");
        filterRuleMap.put("/hotItems/hotCompanies/list", "anon");
        
        //NewsSearchController
        //filterRuleMap.put("/news/search/**", "anon");
        
        //NotificationController
        filterRuleMap.put("/notification/save", "anon");
        
        //PersonNameSearchController
        filterRuleMap.put("/person/search/getResult", "anon");
        
        //PFundSearchController
       // filterRuleMap.put("/private/equity/search/getResult", "anon");
        
        //RiskSearchController
        filterRuleMap.put("/risk/search/**", "anon");
        
        //TokenController
        filterRuleMap.put("/token/verifyToken", "anon");
        
        // 所有请求通过我们自己的JWT Filter
        filterRuleMap.put("/**", "jwt");
        
        factoryBean.setFilterChainDefinitionMap(filterRuleMap);
        return factoryBean;
    }

    /**
     * 下面的代码是添加注解支持
     */
    @Bean
    @DependsOn("lifecycleBeanPostProcessor")
    public DefaultAdvisorAutoProxyCreator defaultAdvisorAutoProxyCreator() {
        DefaultAdvisorAutoProxyCreator defaultAdvisorAutoProxyCreator = new DefaultAdvisorAutoProxyCreator();
        // 强制使用cglib，防止重复代理和可能引起代理出错的问题
        // https://zhuanlan.zhihu.com/p/29161098
        defaultAdvisorAutoProxyCreator.setProxyTargetClass(true);
        return defaultAdvisorAutoProxyCreator;
    }

    @Bean
    public LifecycleBeanPostProcessor lifecycleBeanPostProcessor() {
        return new LifecycleBeanPostProcessor();
    }

    @Bean
    public AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor(DefaultWebSecurityManager securityManager) {
        AuthorizationAttributeSourceAdvisor advisor = new AuthorizationAttributeSourceAdvisor();
        advisor.setSecurityManager(securityManager);
        return advisor;
    }
}
