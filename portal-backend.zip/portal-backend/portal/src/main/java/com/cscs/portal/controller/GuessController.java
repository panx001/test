package com.cscs.portal.controller;

import com.cscs.portal.dto.CompanySearchResultOut;
import com.cscs.portal.dto.CompanyTopicsCInfoData;
import com.cscs.portal.dto.CompanyTopicsInData;
import com.cscs.portal.dto.CompanyTopicsInfoData;
import com.cscs.portal.dto.HotNewsInData;
import com.cscs.portal.dto.HotNewsInfoData;
import com.cscs.portal.dto.NewsDetailOut;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.CompanyTopics;
import com.cscs.portal.entity.HotNews;
import com.cscs.portal.services.CompanyTopicsServices;
import com.cscs.portal.services.HotNewsServices;
import com.cscs.util.Contants;
import com.cscs.util.DateUtils;
import com.cscs.util.SFTPUtil;
import com.cscs.util.StringUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.solr.client.solrj.SolrServerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.persistence.NoResultException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created by dch on 2016/11/1
 * 猜你喜欢
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/guess")
public class GuessController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(GuessController.class);
	
    @Autowired
    private HotNewsServices hotNewsServices;

    @Autowired
    private CompanyTopicsServices companyTopicsServices;

    @Autowired
    private CompanyBasicInfoController companyBasicInfoController;
    
    @Autowired
    private SolrController solrController;
    
    @Autowired
    private CompanyNewsController companyNewController;
   
    
    //查找新闻热点列表 首页需要调用
    @RequestMapping(value = "/hotNews/search", method = RequestMethod.POST)
    public BaseOutData searchHotNews(@RequestBody HotNewsInData inData) {
        List<HotNewsInfoData> out = new ArrayList<>();
        BaseOutData outData = new BaseOutData();
        inData.setStatus(1);
        List<HotNews> infoList = hotNewsServices.search(inData,outData);
        Map<String,List<HotNewsInfoData>> hotNewsListMap = new HashMap<String,List<HotNewsInfoData>>();
        HotNewsInfoData item = null;
        for (HotNews info : infoList) {
            item = new HotNewsInfoData();
            BeanUtils.copyProperties(info, item);
            out.add(item);
        }
        hotNewsListMap.put("data", out);
        outData.setCode("0");
        outData.setData(hotNewsListMap);
        return outData;
    }
    
    //查找新闻热点列表 后台管理员调用
    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/hotNews/searchAll", method = RequestMethod.POST)
    public BaseOutData searchAll(@RequestBody HotNewsInData inData) {
        List<HotNewsInfoData> out = new ArrayList<>();
        BaseOutData outData = new BaseOutData();
        List<HotNews> infoList = hotNewsServices.search(inData,outData);
        Map<String,List<HotNewsInfoData>> hotNewsListMap = new HashMap<String,List<HotNewsInfoData>>();
        HotNewsInfoData item = null;
        for (HotNews info : infoList) {
            item = new HotNewsInfoData();
            BeanUtils.copyProperties(info, item);
            out.add(item);
        }
        hotNewsListMap.put("data", out);
        outData.setCode("0");
        outData.setData(hotNewsListMap);
        return outData;
    }

    //查找新闻热点 首页需要调用
    @RequestMapping(value = "/hotNews/search/{id}", method = RequestMethod.GET)
    public HotNewsInfoData searchHotNewsById(@PathVariable Long id) {
        HotNewsInfoData out = new HotNewsInfoData();
        HotNews info = null;
        try {
        	info = hotNewsServices.searchById(id);
        
        }catch(NoResultException e) {
        	return null;
        }
        BeanUtils.copyProperties(info, out);
        return out;
    }

    //追加新闻热点
    //todo:增加热点新闻的接口入参不对，原型是只传一个新闻链接 优先级待定
    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/hotNews/save", method = RequestMethod.POST)
    public BaseOutData saveHotNews(HttpServletRequest request, @RequestBody HotNewsInfoData inData) {
        BaseOutData outData = new BaseOutData();
        HotNews hotNews = new HotNews();
        if(StringUtil.isEmpty(inData.getLink())) {
        	outData.setCode("1");
        	outData.setMessage("新闻链接必填");
        	return outData;
        }
        String[] singleUrls = inData.getLink().split("/");
	    if(singleUrls==null||singleUrls.length<5) {
	    	outData.setCode("1");
        	outData.setMessage("新闻链接路径错误");
        	return outData;
	    }
       
	    BaseOutData baseData = null;
	    Map<String,Object> newsDetail = null;
        List<Map<String,Object>> relatedCompyList = null;
        String relatedCompyNmList = "";
        String relatedCompyIdList = "";
        try {
            baseData = companyNewController.getDetail(singleUrls[singleUrls.length-2], singleUrls[singleUrls.length-1]);
            if("1".equals(baseData.getCode())||baseData.getData().get("result")==null) {
            	outData.setCode("1");
            	outData.setMessage("没有此新闻或新闻链接无效");
            	return outData;
            }
            newsDetail = (Map<String,Object>)((NewsDetailOut)baseData.getData().get("result")).getNewsdetail();
            hotNews.setId(inData.getId());
            hotNews.setStatus(inData.getStatus());
            hotNews.setLink(inData.getLink());
            hotNews.setPostdt(  DateUtils.stringToDate((String) newsDetail.get("publishTime")));
            hotNews.setTitle((String) newsDetail.get("newsTitle"));
            hotNews.setWarningType((String) newsDetail.get("warningType"));
            hotNews.setSource((String) newsDetail.get("newsSource"));
            hotNews.setRelevance((String) newsDetail.get("relevance"));
            hotNews.setIsdel(0L);
            relatedCompyList = ((List<Map<String,Object>>)((NewsDetailOut)baseData.getData().get("result")).getRelatedcompylist());
            if(!CollectionUtils.isEmpty(relatedCompyList)) {
            	for (Map<String, Object> map : relatedCompyList) {
            		relatedCompyIdList += (String) map.get("companyId")+',';
            		relatedCompyNmList +=(String)map.get("companyNm")+',';
				}
            	hotNews.setCompanyIdList(relatedCompyIdList.substring(0,relatedCompyIdList.length()-1));
            	hotNews.setCompanyNmList(relatedCompyNmList.substring(0,relatedCompyNmList.length()-1));
            }
            hotNewsServices.save(hotNews);
            outData.setCode("0");
            outData.setCount(1);
        } catch (Exception ex) {
            outData.setCode("1");
            outData.setMessage(ex.getMessage());
        }
        return outData;
    }

    //删除新闻热点
    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/hotNews/delete/{id}", method = RequestMethod.GET)
    public BaseOutData deleteHotNews(HttpServletRequest request, @PathVariable Long id) {
        BaseOutData outData = new BaseOutData();

        try {
            hotNewsServices.delete(id);
            outData.setCode("0");
            outData.setCount(1);
        } catch (Exception ex) {
            outData.setCode("1");
        }
        return outData;
    }

    //查找企业专题列表
    @RequestMapping(value = "/compyTopic/search", method = RequestMethod.POST)
    public BaseOutData searchCompyTopic(@RequestBody CompanyTopicsInData inData) {
    	 BaseOutData outData = new BaseOutData();
    	 inData.setStatus(1L);
		 List<CompanyTopics> companyTopicsList = companyTopicsServices.search(inData,outData);
		 Map<String,List<CompanyTopics>> companyMap = new HashMap<String,List<CompanyTopics>>();
		 companyMap.put("data", companyTopicsList);
	     outData.setCode("0");
	     outData.setData(companyMap);
	     return outData;
    }

    //管理员后台查询所有
    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/compyTopic/searchAll", method = RequestMethod.POST)
    public BaseOutData searchCompyTopicAll(@RequestBody CompanyTopicsInData inData) {
    	 BaseOutData outData = new BaseOutData();
		 List<CompanyTopics> companyTopicsList = companyTopicsServices.search(inData,outData);
		 Map<String,List<CompanyTopics>> companyMap = new HashMap<String,List<CompanyTopics>>();
		 companyMap.put("data", companyTopicsList);
	     outData.setCode("0");
	     outData.setData(companyMap);
	     return outData;
    }
    
    //查找企业专题
    @RequestMapping(value = "/compyTopic/search/{id}", method = RequestMethod.GET)
    public CompanyTopicsInfoData searchById(@PathVariable Long id) {
         CompanyTopicsInfoData outData = companyTopicsServices.searchById(id);
         BaseOutData companyBasicResp = null;
         Map<String,Object> companyBasicInfo = null;
         List<Map<String,Object>> companyList = new ArrayList<>();
         for (CompanyTopicsCInfoData info : outData.getcInfo()) {
        	 companyBasicResp = (BaseOutData) companyBasicInfoController.getBasicInfo(String.valueOf(info.getCompanyId()));
         	if("0".equals(companyBasicResp.getCode())&&companyBasicResp.getData()!=null&&companyBasicResp.getData().get("result")!=null) {
         		companyBasicInfo =  (Map<String,Object>)companyBasicResp.getData().get("result");
         		companyBasicInfo.put("companyId", String.valueOf(info.getCompanyId()));
         		companyList.add(companyBasicInfo);
         	}
		}
         outData.setCompanyDetailInfos(companyList);
         return outData;
    }

    //追加企业专题
    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/compyTopic/save", method = RequestMethod.POST)
    public BaseOutData save(HttpServletRequest request) {
        BaseOutData outData = new BaseOutData();
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        CompanyTopicsInfoData info = new CompanyTopicsInfoData();

        MultipartFile snapshot = multipartRequest.getFile("snapshot");
        MultipartFile pic = multipartRequest.getFile("pic");
        CompanyTopics companyTopic = null;
        if (!StringUtil.isEmpty(multipartRequest.getParameter("id"))) {
            info.setId(Long.valueOf(multipartRequest.getParameter("id")));
            //更新操作
            companyTopic=companyTopicsServices.searchTopics(Long.valueOf(multipartRequest.getParameter("id")));
        }
        info.setName(multipartRequest.getParameter("name"));
        info.setPriority(Long.valueOf(multipartRequest.getParameter("priority")));
        info.setSummary(multipartRequest.getParameter("summary"));
        info.setStatus(Long.valueOf(multipartRequest.getParameter("status")));
        if (pic!=null && !pic.isEmpty()) {
            String oName = pic.getOriginalFilename();
            String pictureName = Contants.FTP_PICTURE_PATH + "/" +UUID.randomUUID().toString() + String.valueOf(new Date().getTime()) + oName.substring(oName.lastIndexOf("."));
            info.setPic(pictureName);
        }else{
        	 info.setPic(companyTopic!=null?companyTopic.getPic():null);
        }
        if (snapshot!=null &&!snapshot.isEmpty()) {
            String oName = snapshot.getOriginalFilename();
            String snapShotName = Contants.FTP_SNAPSHOT_PATH + "/" + UUID.randomUUID().toString() + String.valueOf(new Date().getTime()) + oName.substring(oName.lastIndexOf("."));
            info.setSnapshot(snapShotName);
        }else{
        	info.setSnapshot(companyTopic!=null?companyTopic.getSnapshot():null);
       }
        
        String companyIdList = multipartRequest.getParameter("companyIdList");
        String companyNmList = multipartRequest.getParameter("companyNmList");
        List<CompanyTopicsCInfoData> cInfoList = new ArrayList<>();
        if (!StringUtil.isEmpty(companyNmList)) {
            String[] compyIdList = companyIdList.split(",");
            String[] compyNmList = companyNmList.split(",");
            CompanyTopicsCInfoData cInfo  = null;
            //String companyId = null;
            for (int i = 0; i < compyNmList.length; i++) {
                cInfo = new CompanyTopicsCInfoData();
                //设置关联表的companyTopicId
                if (!StringUtil.isEmpty(multipartRequest.getParameter("id"))) {
                	//cInfo.setId(Long.valueOf(multipartRequest.getParameter("id")));
                	cInfo.setCompanyTopicsId(Long.valueOf(multipartRequest.getParameter("id")));
                }
//                try {
//					companyId = solrController.searchcompany(compyNmList[i].toString());
//					cInfo.setCompanyId(companyId==null?0L:Long.parseLong(companyId));
//                } catch (SolrServerException e) {
//                	LOGGER.info(e.getMessage());
//				}
                cInfo.setCompanyId(Long.parseLong(compyIdList[i]));
                cInfo.setCompanyNm(compyNmList[i].toString());
                cInfoList.add(cInfo);
            }
        }
        info.setcInfo(cInfoList);

        try {
            CompanyTopics companyTopics = companyTopicsServices.save(info);
            outData.setCode("0");
            outData.setCount(1);
            SFTPUtil sftp = new SFTPUtil();
            sftp.login();
            if (snapshot!=null&&!snapshot.isEmpty()) {
                sftp.upload(Contants.FTP_SNAPSHOT_PATH, companyTopics.getSnapshot(), snapshot.getInputStream());
            }
            if (pic!=null && !pic.isEmpty()) {
                sftp.upload(Contants.FTP_PICTURE_PATH, companyTopics.getPic(), pic.getInputStream());
            }
            sftp.logout();
        } catch (Exception ex) {
            outData.setCode("1");
        }
        return outData;
    }
    
    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/compyTopic/searchCompany", method = RequestMethod.POST)
    public BaseOutData searchCompany(HttpServletRequest request) {
    	BaseOutData outData = new BaseOutData();
    	MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
    	String companyNmListStr = multipartRequest.getParameter("companyNmList");
    	String[] compyNmList = companyNmListStr.split(",");
    	List<CompanySearchResultOut> outList = new ArrayList<>();
    	CompanySearchResultOut compangSeachBean = null;
    	String companyId = null;
    	 for (int i = 0; i < compyNmList.length; i++) {
    		 compangSeachBean = new CompanySearchResultOut();
    		 compangSeachBean.setCompanyNm(compyNmList[i].toString());
    		 
    		 try {
				companyId = solrController.searchcompany(compyNmList[i].toString());
			} catch (SolrServerException e) {
				outData.setMessage(e.getMessage());
			}
    		 
    		 compangSeachBean.setCompanyId(companyId);
    		 compangSeachBean.setIsFoundFlag(companyId!=null);
    		 outList.add(compangSeachBean);
    	 }
    	 
    	 Map<String,List<CompanySearchResultOut>> map = new HashMap<>();
    	 map.put("result", outList);
    	 outData.setCode("0");
    	 outData.setData(map);
    	 return outData;
    	
    	
    }

    @RequestMapping(value = "/compyTopic/download/{fileName:.+}", method = RequestMethod.GET)
    public BaseOutData downloadFile(@PathVariable String fileName, HttpServletResponse response) {
        BaseOutData outData = new BaseOutData();
        try (ServletOutputStream out = response.getOutputStream();) {
            SFTPUtil sftp = new SFTPUtil();
            sftp.login();
            byte[] file = null;
            if (fileName.indexOf("snapshot") > -1) {
                file = sftp.download(Contants.FTP_SNAPSHOT_PATH, fileName);
            } else if (fileName.indexOf("picture") > -1) {
                file = sftp.download(Contants.FTP_PICTURE_PATH, fileName);
            }
            response.setContentType("image/png");
            response.addHeader("Content-Disposition", "attachment;fileName=" + fileName);// 设置文件名
            out.write(file);
            sftp.logout();
            outData.setCode("0");
        } catch (Exception ex){
            outData.setCode("1");
        }
        return outData;
    }

    //删除企业专题
    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/compyTopic/delete/{id}", method = RequestMethod.GET)
    public BaseOutData deleteCompyTopic(HttpServletRequest request, @PathVariable Long id) {
        BaseOutData outData = new BaseOutData();
        try {
            companyTopicsServices.delete(id);
            outData.setCode("0");
            outData.setCount(1);
        } catch (Exception ex) {
            outData.setCode("1");
        }
        return outData;
    }
}