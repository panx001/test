package com.cscs.portal.dto;

import com.cscs.portal.dto.base.BaseOutData;

import java.util.List;
import java.util.Set;

/**
 * Created by lp on 2018/7/12.
 */
public class BOCompanyBasicData {

    private String companyId;
    private String securityCd;
    private String securitySnm;
    private List<String> tips;
    private String companyName;
    private Set<String> oldName;
    private String legRepresent;
    private String foundDt;
    private String regCapital;
    private String blnumb;
    private String addr;
    private String companySt;
    private String creditRating;

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getSecurityCd() {
        return securityCd;
    }

    public void setSecurityCd(String securityCd) {
        this.securityCd = securityCd;
    }

    public String getSecuritySnm() {
        return securitySnm;
    }

    public void setSecuritySnm(String securitySnm) {
        this.securitySnm = securitySnm;
    }

    public List<String> getTips() {
        return tips;
    }

    public void setTips(List<String> tips) {
        this.tips = tips;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Set<String> getOldName() {
        return oldName;
    }

    public void setOldName(Set<String> oldName) {
        this.oldName = oldName;
    }

    public String getLegRepresent() {
        return legRepresent;
    }

    public void setLegRepresent(String legRepresent) {
        this.legRepresent = legRepresent;
    }

    public String getFoundDt() {
        return foundDt;
    }

    public void setFoundDt(String foundDt) {
        this.foundDt = foundDt;
    }

    public String getRegCapital() {
        return regCapital;
    }

    public void setRegCapital(String regCapital) {
        this.regCapital = regCapital;
    }

    public String getBlnumb() {
        return blnumb;
    }

    public void setBlnumb(String blnumb) {
        this.blnumb = blnumb;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getCompanySt() {
        return companySt;
    }

    public void setCompanySt(String companySt) {
        this.companySt = companySt;
    }

    public String getCreditRating() {
        return creditRating;
    }

    public void setCreditRating(String creditRating) {
        this.creditRating = creditRating;
    }
}
