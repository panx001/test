package com.cscs.portal.dto;

import java.util.List;

/**
 *  风险信息高级搜索返回数据

 * @ClassName: CompanySearchOut

 * @Description: TODO

 * @author: liunn

 * @date: 2018年9月13日 上午11:33:31
 */
public class RiskSearchOut{
	//企业id
	private String companyId;
	//企业名称
	private String companyName;
	//风险类型
	private String riskType;
	//债券类型
	private String bondtype;
	//企业类型
    private String companyType;
    //企业状态
    private String companySt;
    //法定代表人
    private String legalPersonName;
    //总经理
    private String gmanager;
    //成立时间
    private String foundDt;
    //风险时间
    private String dt;
    //注册资本
    private String regCapital;
    //注册地
    private String officeAddr;
    //所属行业
    private String industry;
    //曾用名
    private String oldCompanyNm;
    //证券简称
    private List securitySnm;
    //上市代码
    private List securityCd;
    //统一社会信用代码
    private String creditCd;
    //董事长
    private String chairman;
    //审计意见
    private String auditadvice;
	//返回的风险内容json
    private Object riskJson;
    //高亮字段
    private List highlightColumns;

	public String getBondtype() {
		return bondtype;
	}

	public void setBondtype(String bondtype) {
		this.bondtype = bondtype;
	}

	public String getAuditadvice() {
		return auditadvice;
	}
	public void setAuditadvice(String auditadvice) {
		this.auditadvice = auditadvice;
	}
	public String getDt() {
		return dt;
	}
	public void setDt(String dt) {
		this.dt = dt;
	}
	public List getHighlightColumns() {
		return highlightColumns;
	}
	public void setHighlightColumns(List highlightColumns) {
		this.highlightColumns = highlightColumns;
	}
	public String getOldCompanyNm() {
		return oldCompanyNm;
	}
	public void setOldCompanyNm(String oldCompanyNm) {
		this.oldCompanyNm = oldCompanyNm;
	}
	
	public List getSecuritySnm() {
		return securitySnm;
	}
	public void setSecuritySnm(List securitySnm) {
		this.securitySnm = securitySnm;
	}
	public List getSecurityCd() {
		return securityCd;
	}
	public void setSecurityCd(List securityCd) {
		this.securityCd = securityCd;
	}
	public String getCreditCd() {
		return creditCd;
	}
	public void setCreditCd(String creditCd) {
		this.creditCd = creditCd;
	}
	public String getChairman() {
		return chairman;
	}
	public void setChairman(String chairman) {
		this.chairman = chairman;
	}
	public String getGmanager() {
		return gmanager;
	}
	public void setGmanager(String gmanager) {
		this.gmanager = gmanager;
	}
	public String getCompanyType() {
		return companyType;
	}
	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}
	public String getCompanySt() {
		return companySt;
	}
	public void setCompanySt(String companySt) {
		this.companySt = companySt;
	}
	public String getLegalPersonName() {
		return legalPersonName;
	}
	public void setLegalPersonName(String legalPersonName) {
		this.legalPersonName = legalPersonName;
	}
	public String getFoundDt() {
		return foundDt;
	}
	public void setFoundDt(String foundDt) {
		this.foundDt = foundDt;
	}
	public String getRegCapital() {
		return regCapital;
	}
	public void setRegCapital(String regCapital) {
		this.regCapital = regCapital;
	}
	public String getOfficeAddr() {
		return officeAddr;
	}
	public void setOfficeAddr(String officeAddr) {
		this.officeAddr = officeAddr;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getRiskType() {
		return riskType;
	}
	public void setRiskType(String riskType) {
		this.riskType = riskType;
	}
	public Object getRiskJson() {
		return riskJson;
	}
	public void setRiskJson(Object riskJson) {
		this.riskJson = riskJson;
	}
	
}
