package com.cscs.portal.entity;

import javax.persistence.*;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "SYSTEM_NOTIFICATION", schema = "CS_PORTAL", catalog = "")
public class SystemNotification {
    private long id;
    private String title;
    private String content;
    private Date dt;
    private Long createId;
    private Long status;
    private Long isdel;
    private Long isRelation;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_SYSTEM_NOTIFICATION")
    @SequenceGenerator(sequenceName = "SEQ_SYSTEM_NOTIFICATION", name = "SEQ_SYSTEM_NOTIFICATION")
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "TITLE")
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Basic
    @Column(name = "CONTENT")
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Basic
    @Column(name = "DT")
    public Date getDt() {
        return dt;
    }

    public void setDt(Date dt) {
        this.dt = dt;
    }

    @Basic
    @Column(name = "CREATE_ID")
    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    @Basic
    @Column(name = "STATUS")
    public Long getStatus() {
        return status;
    }

    public void setStatus(Long status) {
        this.status = status;
    }

    @Basic
    @Column(name = "ISDEL")
    public Long getIsdel() {
        return isdel;
    }

    public void setIsdel(Long isdel) {
        this.isdel = isdel;
    }

    @Basic
    @Column(name = "IS_RELATION")
    public Long getIsRelation() {
        return isRelation;
    }

    public void setIsRelation(Long isRelation) {
        this.isRelation = isRelation;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SystemNotification that = (SystemNotification) o;
        return id == that.id &&
                Objects.equals(title, that.title) &&
                Objects.equals(content, that.content) &&
                Objects.equals(dt, that.dt) &&
                Objects.equals(createId, that.createId) &&
                Objects.equals(status, that.status) &&
                Objects.equals(isdel, that.isdel) &&
                Objects.equals(isRelation, that.isRelation);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, title, content, dt, createId, status, isdel, isRelation);
    }
}
