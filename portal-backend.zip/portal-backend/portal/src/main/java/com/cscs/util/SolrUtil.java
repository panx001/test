package com.cscs.util;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.impl.HttpSolrServer;

public class SolrUtil {
	protected final Log logger = LogFactory.getLog(SolrUtil.class);
    public static final String KEY = "key";
    public static final String VALUE = "value";
    public static final String EXACT = "exact";//是否精确匹配--value外面是否需要wrap双引号

    public static String getQueryUrl(List<Map<String, String>> qMapList, List<List<Map<String, String>>> fqMapList, int rows, int startRow, boolean edismax, String sort) {
        StringBuilder sb = new StringBuilder();

        StringBuilder qSb = new StringBuilder();
        for (int i = 0; i < qMapList.size(); i++) {
            Map<String, String> q = qMapList.get(i);
            String key = q.get(SolrUtil.KEY);
            String value = q.get(SolrUtil.VALUE);
            String exact = q.get(SolrUtil.EXACT);
//            String encode = q.get(SolrUtil.ENCODE);

            qSb.append("+OR+").append(key).append(":");
            if (exact.equals("true")) {
                qSb.append(encode("\"" + value + "\""));
            } else {
                qSb.append(value);
            }
        }
        sb.append("q=").append(qSb.substring(4));
        if (null != fqMapList && fqMapList.size() > 0) {
            for (List<Map<String, String>> group : fqMapList) {
                StringBuilder fqGroupSb = new StringBuilder();
                for (Map<String, String> inner : group) {
//                    for (Map.Entry<String, String> kv : inner.entrySet()) {
//                        if (!StringUtil.isEmpty(kv.getKey()) && !StringUtil.isEmpty(kv.getValue())) {
//                            fqGroupSb.append("+").append(kv.getKey()).append(":").append(encode(kv.getValue()));
//                        }
//                    }

                    fqGroupSb.append("+").append(inner.get(SolrUtil.KEY)).append(":").append(encode(inner.get(SolrUtil.VALUE)));
                }
                if (fqGroupSb.length() > 0) {
                    sb.append("&fq=").append(fqGroupSb);
                }
            }
        }
        sb.append("&rows=" + rows + "&start=" + startRow);
        if (edismax) {
            sb.append("&defType=edismax&mm=95" + encode("%"));
        }
        if (!StringUtil.isEmpty(sort)) {
            sb.append(sort);
        }
        return sb.toString();
    }
    /**
     * 
     * @Title: getSolrServer
     * @Description: 获取solr服务对象
     * @param url
     * @return
     * @return: SolrServer
     */
    public static SolrServer getSolrServer(String method) {
    	//获取路由url
    	String url = SolrUtil.urlRoute()+method;
    	System.out.println("调用的服务路由的URL:"+url);
    	//创建Solr服务对象，通过此对象向solr服务发起请求
        SolrServer solrServer = new HttpSolrServer(url);
        return solrServer;
    }
    
    public static String urlRoute() {
    	String url = "";
    	Random r = new Random();
    	int[] arr = r.ints(1,1,4).toArray();
    	switch (arr[0]) {
		case 1:
			url = Contants.SOLR_SERVICE_URL35;
			break;
		case 2:
			url = Contants.SOLR_SERVICE_URL36;
			break;
		case 3:
			url = Contants.SOLR_SERVICE_URL37;
			break;
		default:
			url = Contants.SOLR_SERVICE_URL36;
			break;
		}
    	return url;
    }

    private static String encode(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            //never happen
            return s;
        }
    }
}
