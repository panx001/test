package com.cscs.portal.services.impl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.cscs.portal.dto.UserBasicinfoInfoData;
import com.cscs.portal.entity.Account;
import com.cscs.portal.entity.UserBasicinfo;
import com.cscs.portal.services.UserBasicInfoServices;
import com.cscs.repository.AccountRepository;
import com.cscs.repository.UserBasicinfoRepository;
import com.cscs.util.DateUtils;

/**
 * Created by dch on 2016/8/10.
 */
@SuppressWarnings("JpaQlInspection")
@Service
public class UserBasicinfoServicesImpl implements UserBasicInfoServices {

    //用户
    @Autowired
    private AccountRepository accountRepository;

    //用户
    @Autowired
    private UserBasicinfoRepository userBasicinfoRepository;

    @PersistenceContext
    EntityManager em;

    /**
     * 新规/更新
     */
    @Override
    public UserBasicinfo save(UserBasicinfo userBasicinfo) throws Exception {

        return userBasicinfoRepository.save(userBasicinfo);
    }

    @SuppressWarnings("unchecked")
	@Override
    public boolean getUserExistByEmail(String email) {
        String sql = "SELECT 1 FROM USER_BASICINFO WHERE email = '" + email + "'";
        List<Object> item = em.createNativeQuery(sql).getResultList();
        if (item.size() > 0) {
            return true;
        }
        return false;
    }

    /**
     * 查询用户信息
     *
     * @param accountId
     * @return
     */
    @Override
    public UserBasicinfo getUserBasicinfoOutData(Long userId) {
        //Account account = getAccountData(accountId);
        String sql = "SELECT h FROM UserBasicinfo h WHERE userId = ?1";
        UserBasicinfo userInfo = em.createQuery(sql, UserBasicinfo.class).setParameter(1, userId).getSingleResult();
        //兼容老数据（原先没有将注册手机号写入userbase表）
       // userInfo.setCellphone(account.getAccountNm());
        return userInfo;
    }

    /**
     * 查询用户头像
     *
     * @param accountId
     * @return
     */
    @SuppressWarnings("unchecked")
	@Override
    public Object getImage(Long userId) {
        //Account account = getAccountData(accountId);
        String sql = "SELECT HEAD_URL FROM USER_BASICINFO WHERE USER_ID = " + userId;
        List<Object> item = em.createNativeQuery(sql).getResultList();
        if (item.size() > 0) {
            return item.get(0);
        }
        return "";
    }

    /**
     * 更新个人信息
     *
     * @param infoData
     * @return
     */
    @Override
    public void setUserBasicinfo(UserBasicinfoInfoData infoData,Long userId) {
        if (!StringUtils.isEmpty(infoData)) {
            //Account account = getAccountData(accountId);
            UserBasicinfo uu = this.userBasicinfoRepository.findOne(userId);
            //infoData.setHeadUrl(uu.getHeadUrl());
            //BeanUtils.copyProperties(infoData, uu);
            //
            uu.setUserNm(infoData.getUserNm());
            uu.setCompanyNm(infoData.getCompanyNm());
            uu.setEmail(infoData.getEmail());
            uu.setPhone(infoData.getPhone());
            uu.setAddress(infoData.getAddress());
            uu.setPosition(infoData.getPosition());
            uu.setUpdtBy(userId);
            Timestamp timestamp = DateUtils.dateChangeTimestamp(new Date());
            uu.setUpdtDt(timestamp);
            userBasicinfoRepository.save(uu);
        }
    }

//    /**
//     * 删除用户个人信息
//     *
//     * @param userId
//     */
//    @Override
//    public void deleteUserBasicinfo(Long userId) {
//        this.userBasicinfoRepository.delete(userId);
//    }

    /**
     * 修改个人信息的头像
     *
     * @param accountId
     * @param photo
     */
    @Override
    @Transactional
    public void updateUserBasicinfo(Long userId, String photo) {
        if (!StringUtils.isEmpty(userId) && !StringUtils.isEmpty(photo)) {
            //Account account = getAccountData(accountId);
            //UserBasicinfo uu = this.userBasicinfoRepository.findOne(account.getUserId());
            //uu.setHeadUrl(photo);
            //this.userBasicinfoRepository.save(uu);
        	
        	  Query query = em.createQuery("update UserBasicinfo as p set p.headUrl =?1 where p.userId=?2");
              query.setParameter(1, photo);
              query.setParameter(2, userId);
              query.executeUpdate();
        }
    }

    public Account getAccountData(Long accountId) {
        return accountRepository.findOne(accountId);
    }
    
    
    /**
     * 查找账号是否存在
     */
    public UserBasicinfo findByAccountNm(String accountNm) {
        List<UserBasicinfo> accountList = userBasicinfoRepository.findByAccountNm(accountNm);
        if (accountList.size() > 0) {
            return accountList.get(0);
        }
        return null;
    }
    
//    public Long generatedValue() {
//        Query query = em.createNativeQuery("select CS_PORTAL.SEQ_USER_BASICINFO.nextval from dual");
//        return  Long.parseLong(String.valueOf(query.getSingleResult()));
//    	//return userBasicinfoRepository.generatedValue();
//    }
    
    /**
     * 修改密码
     */
    @Transactional
    public Integer updateUserPwd(String accountNm, String accountPw) {
        //找回密码不成功
        int num = 1;
        Query query = em.createQuery("update UserBasicinfo as p set p.accountPw =?1 where p.accountNm=?2");
        query.setParameter(1, accountPw);
        query.setParameter(2, accountNm);
        int result = query.executeUpdate(); //影响的记录数
        if (result > 0) {
            //找回密码成功
            num = 0;
        }
        return num;
    }
    	
    /**
     * 密码是否正确
     */
    public UserBasicinfo findByAccount(String accountNm, String accountPw) {
        List<UserBasicinfo> accountList = userBasicinfoRepository.findByAccount(accountNm, accountPw);
        if (accountList.size() > 0) {
            return accountList.get(0);
        }
        return null;
    }
    
    @Override
    public List<Object> getAccount(String accountNm, String accountPw) {
    	String sql = "SELECT A.ACTIVITY_TYPE,B.ROLE_ID,D.DEFAULT_FLG,A.REGEDIT_DT,A.USER_ID as accountId,A.USER_ID,D.END_DT FROM user_basicinfo A\n" +
    			"LEFT JOIN ACCOUNT_ROLE_XW B ON A.USER_ID = B.ACCOUNT_ID\n" +
    			"LEFT JOIN ACCOUNT_AUTHO_XW C ON A.USER_ID = C.ACCOUNT_ID\n" +
    			"LEFT JOIN AUTHORIZE D ON C.AUTHO_ID  = D.AUTHORIZE_ID\n" +
    			"WHERE A.ACCOUNT_NM = ?1\n AND A.ACCOUNT_PW = ?2";
        Query query = em.createNativeQuery(sql);
        query.setParameter(1, accountNm);
        query.setParameter(2, accountPw);
        return query.getResultList();
    }
}
