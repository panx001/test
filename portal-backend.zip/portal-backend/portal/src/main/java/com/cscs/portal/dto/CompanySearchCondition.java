package com.cscs.portal.dto;

/***
 *  企业高级搜索查询条件

 * @ClassName: CompanySearchCondition

 * @Description: TODO

 * @author: liunn

 * @date: 2018年9月12日 下午4:12:45
 */
public class CompanySearchCondition {

	//搜索框关键字
    private String keyword;
    //当前页
    private Integer curPage;
    //每页显示的条数
    private Integer rowNum;
    //企业类型
    private String companyType;
    //注册地
    private String officeAddr;
    //所属行业
    private String industry;
    //注册资本
    private String regCapital;
    //成立时间
    private String foundDt;
    //企业状态
    private String companySt;
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public Integer getCurPage() {
		return curPage;
	}
	public void setCurPage(Integer curPage) {
		this.curPage = curPage;
	}
	public Integer getRowNum() {
		return rowNum;
	}
	public void setRowNum(Integer rowNum) {
		this.rowNum = rowNum;
	}
	public String getCompanyType() {
		return companyType;
	}
	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}
	public String getOfficeAddr() {
		return officeAddr;
	}
	public void setOfficeAddr(String officeAddr) {
		this.officeAddr = officeAddr;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getRegCapital() {
		return regCapital;
	}
	public void setRegCapital(String regCapital) {
		this.regCapital = regCapital;
	}
	public String getFoundDt() {
		return foundDt;
	}
	public void setFoundDt(String foundDt) {
		this.foundDt = foundDt;
	}
	public String getCompanySt() {
		return companySt;
	}
	public void setCompanySt(String companySt) {
		this.companySt = companySt;
	}

}
