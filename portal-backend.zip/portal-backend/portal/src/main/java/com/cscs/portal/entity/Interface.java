package com.cscs.portal.entity;

import javax.persistence.*;

/**
 * Created by sh on 2018/1/9.
 */
@Entity
public class Interface {
    private long interfaceId;
    private String interfaceNm;
    private String interfaceUrl;
    private String ctlType;
    private String ctlName;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "SEQ_INTERFACE")
    @SequenceGenerator(sequenceName = "SEQ_INTERFACE",name="SEQ_INTERFACE")
    @Column(name = "INTERFACE_ID", nullable = false, precision = 0)
    public long getInterfaceId() {
        return interfaceId;
    }

    public void setInterfaceId(long interfaceId) {
        this.interfaceId = interfaceId;
    }

    @Basic
    @Column(name = "INTERFACE_NM", nullable = true, length = 300)
    public String getInterfaceNm() {
        return interfaceNm;
    }

    public void setInterfaceNm(String interfaceNm) {
        this.interfaceNm = interfaceNm;
    }

    @Basic
    @Column(name = "INTERFACE_URL", nullable = true, length = 300)
    public String getInterfaceUrl() {
        return interfaceUrl;
    }

    public void setInterfaceUrl(String interfaceUrl) {
        this.interfaceUrl = interfaceUrl;
    }

    @Basic
    @Column(name = "CTL_TYPE", nullable = true, length = 20)
    public String getCtlType() {
        return ctlType;
    }

    public void setCtlType(String ctlType) {
        this.ctlType = ctlType;
    }

    @Basic
    @Column(name = "CTL_NAME", nullable = true, length = 20)
    public String getCtlName() {
        return ctlName;
    }

    public void setCtlName(String ctlName) {
        this.ctlName = ctlName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Interface that = (Interface) o;

        if (interfaceId != that.interfaceId) return false;
        if (interfaceNm != null ? !interfaceNm.equals(that.interfaceNm) : that.interfaceNm != null) return false;
        if (interfaceUrl != null ? !interfaceUrl.equals(that.interfaceUrl) : that.interfaceUrl != null) return false;
        if (ctlType != null ? !ctlType.equals(that.ctlType) : that.ctlType != null) return false;
        if (ctlName != null ? !ctlName.equals(that.ctlName) : that.ctlName != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (int) (interfaceId ^ (interfaceId >>> 32));
        result = 31 * result + (interfaceNm != null ? interfaceNm.hashCode() : 0);
        result = 31 * result + (interfaceUrl != null ? interfaceUrl.hashCode() : 0);
        result = 31 * result + (ctlType != null ? ctlType.hashCode() : 0);
        result = 31 * result + (ctlName != null ? ctlName.hashCode() : 0);
        return result;
    }
}
