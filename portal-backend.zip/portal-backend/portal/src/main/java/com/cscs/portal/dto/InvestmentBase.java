package com.cscs.portal.dto;

public class InvestmentBase implements Comparable<InvestmentBase> {
	private String compyId;
	private String compyNm;
	private String islist;
	private String isbond;
	private String islist3;
	private String ispfund;
	private String regCapital;
	private String foundDt;
	private String sharehdRatio;
	private String compySt;
	
	public String getCompyId() {
		return compyId;
	}

	public void setCompyId(String compyId) {
		this.compyId = compyId;
	}

	public String getCompyNm() {
		return compyNm;
	}

	public void setCompyNm(String compyNm) {
		this.compyNm = compyNm;
	}

	public String getIslist() {
		return islist;
	}

	public void setIslist(String islist) {
		this.islist = islist;
	}

	public String getIsbond() {
		return isbond;
	}

	public void setIsbond(String isbond) {
		this.isbond = isbond;
	}

	public String getIslist3() {
		return islist3;
	}

	public void setIslist3(String islist3) {
		this.islist3 = islist3;
	}

	public String getIspfund() {
		return ispfund;
	}

	public void setIspfund(String ispfund) {
		this.ispfund = ispfund;
	}


	public String getRegCapital() {
		return regCapital;
	}

	public void setRegCapital(String regCapital) {
		this.regCapital = regCapital;
	}

	public String getFoundDt() {
		return foundDt;
	}

	public void setFoundDt(String foundDt) {
		this.foundDt = foundDt;
	}

	public String getSharehdRatio() {
		return sharehdRatio;
	}

	public void setSharehdRatio(String sharehdRatio) {
		this.sharehdRatio = sharehdRatio;
	}

	public String getCompySt() {
		return compySt;
	}

	public void setCompySt(String compySt) {
		this.compySt = compySt;
	}

	@Override
	public int compareTo(InvestmentBase o) {
		double o1 = Double.parseDouble(sharehdRatio.split("%")[0]);
		double o2 = Double.parseDouble(o.sharehdRatio.split("%")[0]);
		if (o1 > o2)
			return -1;
		else if (o1 < o2)
			return 1;
		else
			return 0;
	}

}
