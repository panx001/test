package com.cscs.portal.services;

import com.cscs.portal.dto.SystemNotificationInData;
import com.cscs.portal.dto.base.BaseInData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.SystemNotification;

import java.util.List;

public interface NotificationService {

    int getUnreadCount(Long userId);

    int getAllCount(Long userId);

    List<Object> getAll(BaseInData inData,Long userId);

    Object getContent(Long id);

    void markRead(String idList,Long userId);

    void deleteUser(String idList,Long userId);

    void delete(Long id);

    SystemNotification findOne(Long id);

    void save(SystemNotification info);

    List<Object> getUnLinkCount();

    void saveUser(Long Id);

    List<Object> getAllAdmin(BaseInData inData,BaseOutData outData);

    int getAdminCount();
}
