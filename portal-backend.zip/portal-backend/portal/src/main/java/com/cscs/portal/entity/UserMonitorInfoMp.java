package com.cscs.portal.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "USER_MONITORINFO_MP", schema = "CS_PORTAL", catalog = "")
public class UserMonitorInfoMp {
    private long id;
    private long userId;
    private long monitorInfoId;
    private Long isRead;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_USER_MONITORINFO_MP")
    @SequenceGenerator(sequenceName = "SEQ_USER_MONITORINFO_MP", name = "SEQ_USER_MONITORINFO_MP")
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "USERID")
    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }


    @Basic
    @Column(name = "IS_READ")
    public Long getIsRead() {
		return isRead;
	}

	public void setIsRead(Long isRead) {
		this.isRead = isRead;
	}

	public void setMonitorInfoId(long monitorInfoId) {
		this.monitorInfoId = monitorInfoId;
	}


	@Basic
	@Column(name = "monitor_info_id")
    public long getMonitorInfoId() {
		return monitorInfoId;
	}

	

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UserMonitorInfoMp that = (UserMonitorInfoMp) o;
        return id == that.id &&
                userId == that.userId &&
                		monitorInfoId == that.monitorInfoId &&
                Objects.equals(isRead, that.isRead);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, userId, monitorInfoId, isRead);
    }
}
