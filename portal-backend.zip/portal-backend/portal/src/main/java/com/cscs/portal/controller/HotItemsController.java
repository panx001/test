package com.cscs.portal.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.shiro.authz.annotation.RequiresRoles;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cscs.portal.dto.base.BaseInData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.HotCompanies;
import com.cscs.portal.services.HotItemsServices;

/**
 * Created by lsl on 2018/10
 * 热点
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/hotItems")
public class HotItemsController {

    @Autowired
    private HotItemsServices hotItemsServices;
    
    //查找热点企业，最多10条
    @RequestMapping(value = "/hotCompanies/search", method = RequestMethod.GET)
    public List<HotCompanies> searchHotCompanies() {
        List<HotCompanies> infoList = hotItemsServices.search();
        return infoList;
    }
    
    
    /**
     * 管理页面分页查询
     * @param inData
     * @return
     */
    @RequestMapping(value = "/hotCompanies/list", method = RequestMethod.POST)
    public BaseOutData searchHotCompanies(@RequestBody BaseInData inData) {
        BaseOutData outData = new BaseOutData();
        List<HotCompanies> infoList = hotItemsServices.listByPaging(inData,outData);
        Map<String,List<HotCompanies>> hotCompaniesListMap = new HashMap<>();
        hotCompaniesListMap.put("data", infoList);
        outData.setCode("0");
        outData.setData(hotCompaniesListMap);
        return outData;
    }

    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/hotCompanies/save", method = RequestMethod.POST)
    public BaseOutData saveHotCompanies(HttpServletRequest request, @RequestBody HotCompanies hotCompanies) {
    	BaseOutData outData = new BaseOutData();
    	try {
            hotCompanies.setDt(new Date());
            hotCompanies.setIsDel(0L);
            hotItemsServices.save(hotCompanies);
            outData.setCode("0");
            outData.setCount(1);
        } catch (Exception ex) {
            outData.setCode("1");
        }
        return outData;
    }

    //删除新闻热点
    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/hotCompanies/delete/{id}", method = RequestMethod.GET)
    public BaseOutData deleteHotCompanies(HttpServletRequest request, @PathVariable Long id) {
        BaseOutData outData = new BaseOutData();

        try {
        	hotItemsServices.delete(id);
            outData.setCode("0");
            outData.setCount(1);
        } catch (Exception ex) {
            outData.setCode("1");
        }
        return outData;
    }

    
}