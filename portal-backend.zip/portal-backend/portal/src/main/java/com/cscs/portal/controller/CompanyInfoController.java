package com.cscs.portal.controller;

import com.cscs.portal.services.CacheServices;
import com.cscs.portal.services.CompanyInfoServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Sai on 4/27/2016.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/companyInfo")
public class CompanyInfoController {

    @Autowired
    CompanyInfoServices companyInfoServices;

    @Autowired
    CacheServices cacheServices;

    @Autowired
    private StringRedisTemplate rt;

    //查询所有定量参数企业
    @RequestMapping(value = "/findQuanFactorDetail/{id}/{code}", method = RequestMethod.GET)
    public ArrayList findQuanFactorDetail(@PathVariable Long id, @PathVariable String code) {
//        LinkedHashMap<Object, Object> outData = new LinkedHashMap<>();
//        //是否城投企业
//        List<Object> itemlist = new ArrayList<>();
//        if (cacheServices.getPlatformCompanyIds().contains(id)) {
//            itemlist = companyInfoServices.findExposureCodeDetail(id, code);
//        } else {
//            itemlist = companyInfoServices.findIndustryCodeDetail(id, code);
//        }
//        for (int i = 0; i < itemlist.size(); i++) {
//            Object[] item = (Object[]) itemlist.get(i);
//            outData.put(item[0], item[1]);
//        }

        ArrayList<Map<String, String>> result = new ArrayList<>();
        //是否城投企业
        List<Object> itemList = new ArrayList<>();
        if (cacheServices.getPlatformCompanyIds().contains(id)) {
            itemList = companyInfoServices.findExposureCodeDetail(id, code);
        } else {
            itemList = companyInfoServices.findIndustryCodeDetail(id, code);
        }
        for (int i = 0; i < itemList.size(); i++) {
            Object[] item = (Object[]) itemList.get(i);
            Map<String, String> d = new HashMap<>();
            d.put("compyName", item[0].toString());
            d.put("value", item[1].toString());
            result.add(d);
        }
        result.sort((m, n)->{
            Double v1 = Double.valueOf(m.get("value"));
            Double v2 = Double.valueOf(n.get("value"));
            return v1.doubleValue() - v2.doubleValue() > 0 ? -1: (v1.doubleValue() - v2.doubleValue() < 0 ? 1 : 0);
        });
        return result;



    }
}