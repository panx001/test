package com.cscs.portal.entity;

import com.cscs.portal.dto.CompanyTopicsCInfoData;

import javax.persistence.*;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "COMPANY_TOPICS", schema = "CS_PORTAL", catalog = "")
public class CompanyTopics {
    private long id;
    private String name;
    private String snapshot;
    private Long priority;
    private String summary;
    private String pic;
    private Long status;
    private Long isdel;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_HOT_COMPANY_TOPICS")
    @SequenceGenerator(sequenceName = "SEQ_HOT_COMPANY_TOPICS", name = "SEQ_HOT_COMPANY_TOPICS")
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "NAME")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "SNAPSHOT")
    public String getSnapshot() {
        return snapshot;
    }

    public void setSnapshot(String snapshot) {
        this.snapshot = snapshot;
    }

    @Basic
    @Column(name = "PRIORITY")
    public Long getPriority() {
        return priority;
    }

    public void setPriority(Long priority) {
        this.priority = priority;
    }

    @Basic
    @Column(name = "SUMMARY")
    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    @Basic
    @Column(name = "PIC")
    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    @Basic
    @Column(name = "STATUS")
    public Long getStatus() {
        return status;
    }

    public void setStatus(Long status) {
        this.status = status;
    }

    @Basic
    @Column(name = "ISDEL")
    public Long getIsdel() {
        return isdel;
    }

    public void setIsdel(Long isdel) {
        this.isdel = isdel;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CompanyTopics that = (CompanyTopics) o;
        return id == that.id &&
                Objects.equals(name, that.name) &&
                Objects.equals(snapshot, that.snapshot) &&
                Objects.equals(priority, that.priority) &&
                Objects.equals(summary, that.summary) &&
                Objects.equals(pic, that.pic) &&
                Objects.equals(status, that.status) &&
                Objects.equals(isdel, that.isdel);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, name, snapshot, priority, summary, pic, status, isdel);
    }
}
