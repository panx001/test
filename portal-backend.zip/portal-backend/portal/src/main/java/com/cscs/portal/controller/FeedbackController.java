package com.cscs.portal.controller;

import com.cscs.portal.dto.AssessInfoData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.util.Contants;
import com.cscs.util.MailUtil;
import com.cscs.util.StringUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Date;
import java.util.UUID;

@CrossOrigin
@RestController
@RequestMapping(value = "/feedback")
public class FeedbackController {
    protected final Log logger = LogFactory.getLog(this.getClass());

    @RequestMapping(value="/uploadImg", method = RequestMethod.POST)
    @ResponseBody
    public String uploadImg(HttpServletRequest request, @RequestParam("file") MultipartFile file[]) throws Exception {
        String imagePath = getClass().getClassLoader().getResource("").getPath() + "images";
        String tempDirName = new Date().getTime() + UUID.randomUUID().toString();
        File imgFiledir = new File(imagePath + File.separator + tempDirName);
        if (!imgFiledir.exists()) {
            imgFiledir.mkdirs();
        }

        for (MultipartFile f : file) {
            String imgName = UUID.randomUUID().toString() + f.getOriginalFilename();
            //上传文件
            uploadFileUtil(f.getBytes(), imgFiledir, imgName);
        }
        return tempDirName;
    }

    @RequestMapping(value="/uploadImg/{dir}", method = RequestMethod.POST)
    @ResponseBody
    public String uploadImgToDir(HttpServletRequest request, @PathVariable String dir, @RequestParam("file") MultipartFile file[]) throws Exception {
        if (StringUtil.isEmpty(dir)) {
            return "";
        }
        String imagePath = getClass().getClassLoader().getResource("").getPath() + "images";
        File imgFiledir = new File(imagePath + File.separator + dir);
        if (!imgFiledir.exists()) {
            return "目录不存在";
        }

        for (MultipartFile f : file) {
            String imgName = UUID.randomUUID().toString() + f.getOriginalFilename();
            //上传文件
            uploadFileUtil(f.getBytes(), imgFiledir, imgName);
        }
        return dir;
    }

    /**
     * 上传文件
     */
    public void uploadFileUtil(byte[] file, File imgPath, String imgName) throws Exception {
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(imgPath.getPath() + File.separator + imgName);
            out.write(file);
        }
        finally {
            if (null != out) {
                out.flush();
                out.close();
            }
        }

    }

    @RequestMapping(value = "/sendMail", method = RequestMethod.POST)
    public BaseOutData sendMail(HttpServletRequest request, @RequestBody AssessInfoData assessInfoData) {

        BaseOutData outData = new BaseOutData();
        try {
            // 设置邮件的内容体
            StringBuilder emailContent = new StringBuilder();

            if (!StringUtil.isEmpty(assessInfoData.getAssessName())) {
                emailContent.append("姓名:");
                emailContent.append(assessInfoData.getAssessName() + "<br>");
            }
            if (!StringUtil.isEmpty(assessInfoData.getCompany())) {
                emailContent.append("公司:");
                emailContent.append(assessInfoData.getCompany() + "<br>");
            }
            if (!StringUtil.isEmpty(assessInfoData.getEmail())) {
                emailContent.append("邮箱:");
                emailContent.append(assessInfoData.getEmail() + "<br>");
            }
            if (!StringUtil.isEmpty(assessInfoData.getCellPhone())) {
                emailContent.append("手机号码:");
                emailContent.append(assessInfoData.getCellPhone() + "<br>");
            }
            if (!StringUtil.isEmpty(assessInfoData.getNeedDesc())) {
                emailContent.append("反馈内容:");
                emailContent.append(assessInfoData.getNeedDesc() + "<br>");
            }

            //发送邮件
            if (StringUtil.isEmpty(assessInfoData.getImageDir())) {
                String path = getClass().getClassLoader().getResource("").getPath() + "images";
                MailUtil.sendmail(Contants.MAIL_USER,"问题反馈",emailContent.toString(), assessInfoData.getImages(), path);
            }
            else {
                String imageDir = getClass().getClassLoader().getResource("").getPath() + "images" + File.separator + assessInfoData.getImageDir();
                MailUtil.sendmail(Contants.MAIL_USER,"问题反馈", emailContent.toString(), imageDir);
            }
            outData.setCode("0");
        } catch (Exception ex) {
            logger.error("", ex);
            outData.setCode("-1");
        }
        return outData;
    }
}
