package com.cscs.portal.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

public class CompanyTopicsCPK implements Serializable {
    private long id;
    private long companyTopicsId;

    @Column(name = "ID")
    @Id
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Column(name = "COMPANY_TOPICS_ID")
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_HOT_COMPANY_TOPICS_C")
    @SequenceGenerator(sequenceName = "SEQ_HOT_COMPANY_TOPICS_C", name = "SEQ_HOT_COMPANY_TOPICS_C")
    public long getCompanyTopicsId() {
        return companyTopicsId;
    }

    public void setCompanyTopicsId(long companyTopicsId) {
        this.companyTopicsId = companyTopicsId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CompanyTopicsCPK that = (CompanyTopicsCPK) o;
        return id == that.id &&
                companyTopicsId == that.companyTopicsId;
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, companyTopicsId);
    }
}
