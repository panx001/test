package com.cscs.portal.services;

import com.cscs.portal.dto.LkpRegionObj;
import java.util.List;
import java.util.Map;

/**
 * Created by qin on 2016/8/10.
 * 地区
 */
public interface RegionServices {
    public List<Object> findProvinceCity();
}
