package com.cscs.portal.services;

import com.cscs.portal.dto.CompanyTopicsInData;
import com.cscs.portal.dto.CompanyTopicsInfoData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.CompanyTopics;

import java.util.List;

public interface CompanyTopicsServices {

   List<CompanyTopics> search(CompanyTopicsInData inData,BaseOutData outData);

   CompanyTopicsInfoData searchById(Long id);
   
   CompanyTopics searchTopics(Long id);

   CompanyTopics save(CompanyTopicsInfoData inData);

   int delete(Long id);
}
