package com.cscs.portal.services.impl;

import com.cscs.portal.dto.UserTraceInfoData;
import com.cscs.portal.entity.Account;
import com.cscs.portal.entity.UserBasicinfo;
import com.cscs.portal.entity.UserTrace;
import com.cscs.portal.services.UserTraceServices;
import com.cscs.repository.AccountRepository;
import com.cscs.repository.UserBasicinfoRepository;
import com.cscs.repository.UserTraceRepository;
import com.cscs.util.Contants;
import com.cscs.util.DateUtils;
import com.cscs.util.StringUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by dch on 2016/11/14.
 * 用户跟踪的实现类
 */
@SuppressWarnings("JpaQlInspection")
@Configurable
@Service
public class UserTraceServicesImpl implements UserTraceServices {
    private static ExecutorService cachedThreadPool = Executors.newCachedThreadPool();

    @Autowired
    private UserTraceRepository userTraceRepository;

    @Autowired
    private AccountRepository accountRepository;
    
    @Autowired
    private UserBasicinfoRepository userBasicRepository;

    @PersistenceContext
    EntityManager em;

    /**
     * url过滤
     */
    @Override
    public boolean tracePath(String path) {
        List<Object> urlList = getTraceUrl();
      //  List<Object> urlList = Arrays.asList(Contants.USER_TRACE_LIST.split(","));
        for (int i = 0; i < urlList.size(); i++) {
            String str = urlList.get(i).toString();
            if (path.indexOf(str) >= 0) {
                return true;
            }
        }
        return false;
    }

    /**
     * 查询用户跟踪信息
     */
    @Override
    public int findUserTraceCount(String accountNm, String startDtString, String endDtString) {
        String sql = "SELECT COUNT(1) FROM USER_TRACE A\n" +
                "INNER JOIN user_basicinfo B ON A.USER_ID = B.USER_ID\n" +
                "WHERE 1= 1 ";
        if (!StringUtils.isEmpty(accountNm)) sql += " AND B.ACCOUNT_NM  = ?1\n";
        if (!StringUtils.isEmpty(startDtString)) sql += " AND TO_CHAR(A.VISIT_DT, 'YYYY-MM-DD') >= ?2\n";
        if (!StringUtils.isEmpty(endDtString)) sql += " AND TO_CHAR(A.VISIT_DT, 'YYYY-MM-DD') <= ?3\n";

        Query query = em.createNativeQuery(sql);

        if (!StringUtils.isEmpty(accountNm)) query.setParameter(1, accountNm);
        if (!StringUtils.isEmpty(startDtString)) query.setParameter(2, startDtString);
        if (!StringUtils.isEmpty(endDtString)) query.setParameter(3, endDtString);
        return Integer.valueOf(query.getSingleResult().toString());
    }

    /**
     * 查询用户跟踪信息
     */
    @Override
    public List<Object> findUserTrace(String accountNm, String startDtString, String endDtString, int page, int pageSize) {
        page = page == 0 ? 0 : page - 1;
        pageSize = pageSize == 0 ? 10 : pageSize;

        String sql = "SELECT A.VISIT_NM,A.VISIT_URL,A.VISIT_DT,A.VISIT_STOP_DT FROM USER_TRACE A\n" +
                "INNER JOIN user_basicinfo B ON A.USER_ID = B.USER_ID\n" +
                "WHERE 1= 1 ";
        if (!StringUtils.isEmpty(accountNm)) sql += " AND B.ACCOUNT_NM  = ?1\n";
        if (!StringUtils.isEmpty(startDtString)) sql += " AND TO_CHAR(A.VISIT_DT, 'YYYY-MM-DD') >= ?2\n";
        if (!StringUtils.isEmpty(endDtString)) sql += " AND TO_CHAR(A.VISIT_DT, 'YYYY-MM-DD') <= ?3\n";
        sql += "ORDER BY VISIT_DT DESC";

        Query query = em.createNativeQuery(sql);
        query.setFirstResult(page * pageSize);
        query.setMaxResults(pageSize);

        if (!StringUtils.isEmpty(accountNm)) query.setParameter(1, accountNm);
        if (!StringUtils.isEmpty(startDtString)) query.setParameter(2, startDtString);
        if (!StringUtils.isEmpty(endDtString)) query.setParameter(3, endDtString);
        return query.getResultList();
    }


    @Override
    public void addUserTrace(final Long userId, final String path, final String ip) {
        cachedThreadPool.execute(new Runnable() {
            public void run() {
                addUserTrace_i(userId, path, ip);
            }
        });
        return;
    }

    /**
     * 新增用户跟踪信息
     */
    @Transactional
    public UserTrace addUserTrace_i(Long accountId, String path, String ip) {
        UserTrace uu = new UserTrace();
        if (!StringUtils.isEmpty(accountId) && !StringUtils.isEmpty(path)) {
            //获取当前时间
            Date nowDate = new Date();
            uu.setVisitDt(nowDate);
           // Account account = this.accountRepository.findOne(accountId);
            UserBasicinfo account = this.userBasicRepository.findOne(accountId);
            uu.setUpdtBy(accountId);
            uu.setUserId(accountId);
            uu.setVisitNm(account.getAccountNm());
            uu.setVisitUrl(path);
            Timestamp timestamp = DateUtils.dateChangeTimestamp(nowDate);
            uu.setUpdtDt(timestamp);
            uu.setUserIp(ip);
            uu = this.userTraceRepository.save(uu);
        }
        return uu;
    }
    /**
     * 访问数据导出
     */
    @Override
    public List<Object> visitRecord(UserTraceInfoData userTraceInfoData) {
        String sqlWhere = "";
        if (!StringUtil.isEmpty(userTraceInfoData.getStartDtString())) {
            sqlWhere += " a.VISIT_DT  >= TO_DATE(" + "'" + userTraceInfoData.getStartDtString() + "'" + ",'YYYY-MM-DD') and ";
        }
        if (!StringUtil.isEmpty(userTraceInfoData.getEndDtString())) {
            sqlWhere += "   TO_DATE(" + "'" + userTraceInfoData.getEndDtString() + "'" + ",'YYYY-MM-DD') >= a.VISIT_DT  and  ";
        }
        
	    String sql = "select  path, interface_nm, sum(B.CN) sumCount\r\n" + 
	    		"  from (select path,\r\n" + 
	    		"               count(path) CN,\r\n" + 
	    		"               interface_nm\r\n" + 
	    		"          from (select b.INTERFACE_URL path,\r\n" + 
	    		"                       b.INTERFACE_NM interface_nm\r\n" + 
	    		"                  from user_trace a\r\n" + 
	    		"                 inner join INTERFACE b on instr(a.VISIT_URL, b.INTERFACE_URL) > 0\r\n" + 
	    		"                 where \n" + sqlWhere +
	    		" a.user_id not in (select a.user_id\r\n" + 
	    		"                                     from user_basicinfo a\r\n" + 
	    		"                                    where a.company_NM = '中证征信'\r\n" + 
	    		"                                      ))\r\n" + 
	    		"         group by path, interface_nm) B\r\n" + 
	    		" GROUP BY path, interface_nm\r\n" + 
	    		" order by sumCount desc"  ;  
//        String sql = "select  pathStr,interface_nm,sum(B.CN)sumCount from\n" +
//                "  (select path,nvl(substr(path,1,instr(path,'/',1,4)),path) pathStr,count(path) CN,interface_nm from(\n" +
//                "    select substr(visit_Url,0,instr(visit_Url,'/',-1)) path,b.INTERFACE_NM interface_nm from user_trace a\n" +
//                "      inner join INTERFACE b on instr(a.VISIT_URL,b.INTERFACE_URL)>0\n" +
//                "    where\n" + sqlWhere +
//                "      substr(a.visit_Url,0,7) ='/portal'\n" +
//                "      and\n" +
//                "      user_id in(\n" +
//                "        select user_id from user_basicinfo \n" +
//                "           where  company_NM <>'中证征信' or company_NM is NULL \n" +
//                "      )\n" +
//                "  )group by path,interface_nm) B  GROUP BY pathStr,interface_nm order by sumCount desc";

        return em.createNativeQuery(sql).getResultList();
    }

   

    private List<Object> getTraceUrl() {
        String sql = "SELECT INTERFACE_URL FROM INTERFACE WHERE CTL_TYPE = '2'";
        return em.createNativeQuery(sql).getResultList();
    }
}
