package com.cscs.portal.services;


import java.util.List;

import com.cscs.portal.dto.UserBasicinfoInfoData;
import com.cscs.portal.entity.UserBasicinfo;

/**
 * Created by dch on 2016/8/10.
 * 用户信息的服务接口
 */
public interface UserBasicInfoServices {

    /**
     * 新规
     */
    UserBasicinfo save(UserBasicinfo userBasicinfo) throws Exception;

    boolean getUserExistByEmail(String email);

    /**
     * 查询用户信息
     *
     * @return
     */
    UserBasicinfo getUserBasicinfoOutData(Long accountId);

    /**
     * 新规
     */
    Object getImage(Long userId);

    /**
     * 更新或保存个人信息
     *
     * @param infoData
     */
    void setUserBasicinfo(UserBasicinfoInfoData infoData,Long accountId);

//    /**
//     * 删除个人信息
//     */
//    void deleteUserBasicinfo(Long userId);

    /**
     * 更新个人图像
     *
     * @param accountId
     * @param photo
     */
    void updateUserBasicinfo(Long accountId, String photo);

    public UserBasicinfo findByAccountNm(String accountNm);
    
//    public Long generatedValue();
    
    public Integer updateUserPwd(String accountNm, String accountPw);
    
    UserBasicinfo findByAccount(String accountNm, String accountPw);

    /**
     * 查询账号信息
     */
    List<Object> getAccount(String accountNm, String accountPw);
}