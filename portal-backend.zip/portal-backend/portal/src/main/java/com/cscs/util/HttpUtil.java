package com.cscs.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;

/**
 * Created by huchangchun on 2017/4/12.
 */
public class HttpUtil {
    public static String getResponse(String url) throws IOException {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpGet fuzzyGet = new HttpGet(url);
        int CONNECTION_TIMEOUT_MS = 6 * 1000; // Timeout in millis.
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectionRequestTimeout(CONNECTION_TIMEOUT_MS)
                .setConnectTimeout(CONNECTION_TIMEOUT_MS)
                .setSocketTimeout(CONNECTION_TIMEOUT_MS)
                .build();
//    fuzzyGet.setConfig(requestConfig);
        CloseableHttpResponse fuzzyResponse = httpClient.execute(fuzzyGet);
        String fuzzyList = EntityUtils.toString(fuzzyResponse.getEntity(), Contants.UTF_8);
        if ("".equals(fuzzyList)) {
            return null;
        } else {
            return fuzzyList;
        }
    }

    /**
     * 数据组HBase接口通用方法
     * @param url
     * @return
     */
    public static <T> T getHBaseResponse(String url){
        T result = null;
        String data = null;

        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpGet get = new HttpGet(url);
        get.setHeader("Accept","application/octet-stream");

        try {
            CloseableHttpResponse fuzzyResponse = httpClient.execute(get);
            data = EntityUtils.toString(fuzzyResponse.getEntity(), Contants.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (!StringUtil.isEmpty(data) &&  !"Not found\r\n".equals(data)) {
        	try {
        		result = (T)JSON.parse(data);
        	} catch (Exception e) {
        		//不是json格式数据,暂时直接返回
    			return (T) data;
    		}
        }
        return result;
    }
    
   
}
