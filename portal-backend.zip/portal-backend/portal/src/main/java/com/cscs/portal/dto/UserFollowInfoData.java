package com.cscs.portal.dto;

/**
 * Created by sh on 2016/8/7.
 */
public class UserFollowInfoData {
    private long id;
    private long userId;
    private long companyId;
    private Long isMonitor;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(long companyId) {
		this.companyId = companyId;
	}

	public Long getIsMonitor() {
        return isMonitor;
    }

    public void setIsMonitor(Long isMonitor) {
        this.isMonitor = isMonitor;
    }
}
