package com.cscs.portal.dto;

public class LikeRiskCompany {

	private String compyId;
	private String warningType;
	private String industry;
	private String compyName;

	public String getCompyId() {
		return compyId;
	}

	public void setCompyId(String compyId) {
		this.compyId = compyId;
	}

	public String getWarningType() {
		return warningType;
	}

	public void setWarningType(String warningType) {
		this.warningType = warningType;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public String getCompyName() {
		return compyName;
	}

	public void setCompyName(String compyName) {
		this.compyName = compyName;
	}

}
