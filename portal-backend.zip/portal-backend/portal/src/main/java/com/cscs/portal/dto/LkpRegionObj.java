package com.cscs.portal.dto;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

/**
 * Created by qin on 2016/8/10.
 * 地区
 */
public class LkpRegionObj {
    private Long regionCd;
    private String regionNm;
    private Long parentCd;
    private Long regionType;
    private Timestamp updtDt;
    private List<LkpRegionObj> cityList;
    private Long regionCdCity;
    private String regionNmCity;
    private Long parentCdCity;

    public Long getRegionCd() {
        return regionCd;
    }

    public void setRegionCd(Long regionCd) {
        this.regionCd = regionCd;
    }

    public String getRegionNm() {
        return regionNm;
    }

    public void setRegionNm(String regionNm) {
        this.regionNm = regionNm;
    }

    public Long getParentCd() {
        return parentCd;
    }

    public void setParentCd(Long parentCd) {
        this.parentCd = parentCd;
    }

    public Long getRegionType() {
        return regionType;
    }

    public void setRegionType(Long regionType) {
        this.regionType = regionType;
    }

    public Timestamp getUpdtDt() {
        return updtDt;
    }

    public void setUpdtDt(Timestamp updtDt) {
        this.updtDt = updtDt;
    }

    public List<LkpRegionObj> getCityList() {
        return cityList;
    }

    public void setCityList(List<LkpRegionObj> cityList) {
        this.cityList = cityList;
    }

    public Long getRegionCdCity() {
        return regionCdCity;
    }

    public void setRegionCdCity(Long regionCdCity) {
        this.regionCdCity = regionCdCity;
    }

    public String getRegionNmCity() {
        return regionNmCity;
    }

    public void setRegionNmCity(String regionNmCity) {
        this.regionNmCity = regionNmCity;
    }

    public Long getParentCdCity() {
        return parentCdCity;
    }

    public void setParentCdCity(Long parentCdCity) {
        this.parentCdCity = parentCdCity;
    }
}
