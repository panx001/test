package com.cscs.portal.services.impl;

import com.cscs.portal.entity.AccountRoleXw;
import com.cscs.portal.entity.Role;
import com.cscs.portal.services.AccountRoleXwServices;
import com.cscs.portal.services.RoleServices;
import com.cscs.repository.AccountRoleXwRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 * Created by dch on 2016/11/7.
 * 账户角色关系
 */
@SuppressWarnings("JpaQlInspection")
@Service
public class AccountRoleXwServicesImpl implements AccountRoleXwServices {

    @Autowired
    private AccountRoleXwRepository accountRoleXwRepository;

    @Autowired
    private RoleServices roleServices;

    @PersistenceContext
    EntityManager em;

    /**
     * 新增账户角色关系
     *
     * @param accountId 账户ID
     */
    @Override
    @Transactional
    public void setAccountRoleXw(Long accountId,String roleNm){
        Role role =  roleServices.findOne(roleNm);

        AccountRoleXw xw = new AccountRoleXw();
        xw.setAccountId(accountId);
        xw.setRoleId(role.getRoleId());
        this.accountRoleXwRepository.save(xw);
    }
    
    /**
     * 更新账户角色关系
     *
     * @param 
     */
    @Override
    @Transactional
    public void updateAccountRoleXw(Long accountId,String roleNm){
        Role role =  roleServices.findOne(roleNm);
        Query query = em.createQuery("update AccountRoleXw as p set p.roleId =?1,p.updtDt=sysdate where p.accountId=?2");
        query.setParameter(1, role.getRoleId());
        query.setParameter(2, accountId);
        query.executeUpdate();
    }


    /**
     * 根据用户ID获取角色信息
     */
    @Override
    public int findAccountRoleById(Long accountId) {
        String sql = "SELECT COUNT(1) FROM ACCOUNT_ROLE_XW A \n" +
                "INNER JOIN ROLE B ON A.ROLE_ID =B.ROLE_ID\n" +
                "WHERE B.ROLE_NM = '管理员' AND A.ACCOUNT_ID =" + accountId;
        return Integer.valueOf(em.createNativeQuery(sql).getSingleResult().toString());
    }
}