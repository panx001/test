package com.cscs.portal.services;

import com.cscs.portal.dto.PFCompySearchIn;
import com.cscs.portal.entity.PFCompyScore;

import java.util.List;

/**
 * Created by dch on 2016/11/7.
 */
public interface PFCompyScoreServices {

    void save(PFCompyScore flg);

    String searchWeigh();

    int searchSum();

    int highRisk();

    List<Object> searchByTime(int type);

//    List<Object> searchWeightByTime(int type);

    List<Object> searchByType(int type);

    List<Object> wholeCount();

//    List<Object> searchTop10(String region);

    List<Object> searchCount(String region);

    List<Object> searchByTypeCount(PFCompySearchIn inData);
}
