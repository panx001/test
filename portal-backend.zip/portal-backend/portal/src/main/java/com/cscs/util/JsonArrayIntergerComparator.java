package com.cscs.util;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class JsonArrayIntergerComparator implements Comparator<JSONObject> {
    private String keyName;

    public JsonArrayIntergerComparator(String keyName) {
        this.keyName = keyName;
    }

    /**
     * 降序排列
     *
     * @return
     */
    @Override
    public int compare(JSONObject o1, JSONObject o2) {
        Integer key1 = o1.getInteger(keyName);
        Integer key2 = o2.getInteger(keyName);
        return -key1.compareTo(key2);
    }

    public static JSONArray sortJSONArray(JSONArray array, String keyName) {
        JSONArray sortedJsonArray = new JSONArray();
        List<JSONObject> jsonValues = new ArrayList<JSONObject>();
        for (int i = 0; i < array.size(); i++) {
            jsonValues.add(array.getJSONObject(i));
        }
        Collections.sort(jsonValues, new JsonArrayIntergerComparator(keyName));
        for (int i = 0; i < jsonValues.size(); i++) {
            sortedJsonArray.add(jsonValues.get(i));
        }
        return sortedJsonArray;
    }
}

