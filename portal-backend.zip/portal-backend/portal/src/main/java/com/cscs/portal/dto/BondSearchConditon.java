package com.cscs.portal.dto;

/**
 * 
 * @ClassName: BondCompanyConditon
 * @Description: 发债企业查询条件
 * @author: liunn
 * @date: 2018年9月15日 下午10:42:00
 */
public class BondSearchConditon{
	//搜索框关键字
    private String keyword;
    //当前页
    private Integer curPage;
    //每页显示的条数
    private Integer rowNum;
	//投资等级
    private String bondLevel;
    //主体评级
    private String creditChg;
    //评级展望
    private String ratingFwd;
	//发债类型
	private String bondType;
    //审计意见
    private String financeAudit;
    //注册地
    private String regRegion;
    //行业
    private String industry;
    //重要财务指标不利变化
    private String financeFactor;
    //企业属性
    private String companyType;
    //成立时间
    private String foundDt;
    
	public String getFoundDt() {
		return foundDt;
	}
	public void setFoundDt(String foundDt) {
		this.foundDt = foundDt;
	}
	public String getCompanyType() {
		return companyType;
	}
	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public Integer getCurPage() {
		return curPage;
	}
	public void setCurPage(Integer curPage) {
		this.curPage = curPage;
	}
	public Integer getRowNum() {
		return rowNum;
	}
	public void setRowNum(Integer rowNum) {
		this.rowNum = rowNum;
	}
	public String getBondLevel() {
		return bondLevel;
	}
	public void setBondLevel(String bondLevel) {
		this.bondLevel = bondLevel;
	}
	public String getCreditChg() {
		return creditChg;
	}
	public void setCreditChg(String creditChg) {
		this.creditChg = creditChg;
	}
	public String getRatingFwd() {
		return ratingFwd;
	}
	public void setRatingFwd(String ratingFwd) {
		this.ratingFwd = ratingFwd;
	}
	public String getBondType() {
		return bondType;
	}
	public void setBondType(String bondType) {
		this.bondType = bondType;
	}
	public String getFinanceAudit() {
		return financeAudit;
	}
	public void setFinanceAudit(String financeAudit) {
		this.financeAudit = financeAudit;
	}
	
	public String getRegRegion() {
		return regRegion;
	}
	public void setRegRegion(String regRegion) {
		this.regRegion = regRegion;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getFinanceFactor() {
		return financeFactor;
	}
	public void setFinanceFactor(String financeFactor) {
		this.financeFactor = financeFactor;
	}
	
}
