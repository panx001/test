package com.cscs.portal.controller;

import com.alibaba.fastjson.JSON;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.services.CompanyInfoServices;
import com.cscs.util.Contants;
import com.cscs.util.HttpUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/chart")
public class ChartController {
    protected final Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    private StringRedisTemplate rt;

    @Autowired
    CompanyInfoServices services;

    private String getUrl(HttpServletRequest request) {
        String context = request.getContextPath();
        String uri = request.getRequestURI();
        uri = uri.substring(context.length());
        uri = uri.replace("//", "/");
        return Contants.CHART_URL + uri;
    }

    //找关系 - 关系图谱

    @RequestMapping(value = "/FindRelation/GetAllNodesAndRels{.+}")
    public BaseOutData sendPrivate(HttpServletRequest request){
    	BaseOutData outData = new BaseOutData();
    	String result = "";
        try {
        	result = HttpUtil.getResponse(getUrl(request) + "?" + request.getQueryString());
		} catch (IOException e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        Map data = new HashMap();
    	data.put("result", JSON.parse(result));
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 企业图谱
     * @param request
     * @return
     * @throws IOException
     */

    @RequestMapping(value = "/pfcompany/company/company_id{.+}")
    public BaseOutData sendAtlas(HttpServletRequest request) {
    	BaseOutData outData = new BaseOutData();
        String context = rt.opsForValue().get("companychart_" + request.getParameter("link_id"));
        if (context == null) {
            try {
				context = HttpUtil.getResponse(getUrl(request) + "?" + request.getQueryString());
				if (context.contains("BasicInfo")) {
					rt.opsForValue().set("companychart_" + request.getParameter("link_id"), context);
					rt.expire("companychart_" + request.getParameter("link_id"), Contants.REDIS_TIMEOUT, TimeUnit.MINUTES);
				}
			} catch (IOException e) {
				e.printStackTrace();
				outData.setCode("1");
	            outData.setMessage("系统报错!");
	            return outData;
			}
        }
        Map data = new HashMap();
    	data.put("result", context != null ? JSON.parse(String.valueOf(context)) : null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     *  疑似实际控制人
     * @param request
     * @return
     * @throws IOException
     */

    @RequestMapping(value = "/suspectactualcontroller/actcontroller/company_id{.+}")
    public BaseOutData getSuspectControllers(HttpServletRequest request) {
    	BaseOutData outData = new BaseOutData();
        String context = rt.opsForValue().get("suspectController" + request.getParameter("link_id"));
        if (context == null) {
            try {
				context = HttpUtil.getResponse(getUrl(request) + "?" + request.getQueryString());
				if(null != context) {
					rt.opsForValue().set("suspectController" + request.getParameter("link_id"), context);
					rt.expire("suspectController" + request.getParameter("link_id"), Contants.REDIS_TIMEOUT, TimeUnit.MINUTES);
				}
			} catch (IOException e) {
				e.printStackTrace();
				outData.setCode("1");
	            outData.setMessage("系统报错!");
	            return outData;
			}
        }
        Map data = new HashMap();
    	data.put("result", context != null ? JSON.parse(String.valueOf(context)) : null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     *  疑似实际控制人名称
     * @param request
     * @return
     * @throws IOException
     */

    @RequestMapping(value = "/suspectactualcontroller/actcontrollername/company_id{.+}")
    public BaseOutData getSuspectControllerName(HttpServletRequest request) {
    	BaseOutData outData = new BaseOutData();
        String context = rt.opsForValue().get("suspectControllerName" + request.getParameter("link_id"));
        if (context == null) {
            try {
				context = HttpUtil.getResponse(getUrl(request) + "?" + request.getQueryString());
				if(null != context) {
					rt.opsForValue().set("suspectControllerName" + request.getParameter("link_id"), context);
					rt.expire("suspectControllerName" + request.getParameter("link_id"), Contants.REDIS_TIMEOUT, TimeUnit.MINUTES);
				}
			} catch (IOException e) {
				e.printStackTrace();
				outData.setCode("1");
	            outData.setMessage("系统报错!");
	            return outData;
			}
        }
        Map data = new HashMap();
    	data.put("result", context != null ? JSON.parse(String.valueOf(context)) : null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     *  关联风险二层
     * @param request
     * @return
     * @throws IOException
     */

    @RequestMapping(value = "/pfcompany/companytwolayer/company_id{.+}")
    public BaseOutData getRelatedRisks(HttpServletRequest request){
    	BaseOutData outData = new BaseOutData();
//        String link_id = request.getParameter("link_id");
//        String label = request.getParameter("label");
//        return "";

        String context = rt.opsForValue().get("companytwolayer" + request.getParameter("link_id"));
        if (context == null) {
            try {
				context = HttpUtil.getResponse(getUrl(request) + "?" + request.getQueryString());
				if(null != context) {
					rt.opsForValue().set("companytwolayer" + request.getParameter("link_id"), context);
					rt.expire("companytwolayer" + request.getParameter("link_id"), Contants.REDIS_TIMEOUT, TimeUnit.MINUTES);
				}
			} catch (IOException e) {
				e.printStackTrace();
				outData.setCode("1");
	            outData.setMessage("系统报错!");
	            return outData;
			}
        }
        Map data = new HashMap();
    	data.put("result",context != null ? JSON.parse(String.valueOf(context)) : null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

	//私募图谱

	@RequestMapping(value = "/pfcompany/affiliatedparty/company_id{.+}")
	public BaseOutData sendPrivateNew(HttpServletRequest request) throws IOException {
//		return HttpUtil.getResponse(getUrl(request) + "?" + request.getQueryString());

        BaseOutData outData = new BaseOutData();
        String context = rt.opsForValue().get("pfcompanytp" + request.getParameter("link_id"));
        if (context == null) {
            try {
                context = HttpUtil.getResponse(getUrl(request) + "?" + request.getQueryString());
                if(null != context) {
                    rt.opsForValue().set("pfcompanytp" + request.getParameter("link_id"), context);
                    rt.expire("pfcompanytp" + request.getParameter("link_id"), Contants.REDIS_TIMEOUT, TimeUnit.MINUTES);
                }
            } catch (IOException e) {
                e.printStackTrace();
                outData.setCode("1");
                outData.setMessage("系统报错!");
                return outData;
            }
        }
        Map data = new HashMap();
        data.put("result",context != null ? JSON.parse(String.valueOf(context)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
	}
}
