package com.cscs.repository;

import com.cscs.portal.entity.UserMonitorXw;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * 用户监控信息表
 */
@SuppressWarnings("JpaQlInspection")
public interface UserMonitorXwRepository extends JpaRepository<UserMonitorXw, Long> {

}
