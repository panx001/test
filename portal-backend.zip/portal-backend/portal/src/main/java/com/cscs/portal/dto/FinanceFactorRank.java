package com.cscs.portal.dto;

public class FinanceFactorRank implements Comparable<FinanceFactorRank> {

	private String compyName;

	private String value;

	public String getCompyName() {
		return compyName;
	}

	public void setCompyName(String compyName) {
		this.compyName = compyName;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public int compareTo(FinanceFactorRank o) {
		double o1 = Double.parseDouble(value);
		double o2 = Double.parseDouble(o.getValue());
		if (o1 > o2)
			return -1;
		else if (o1 < o2)
			return 1;
		else
			return 0;
	}
}
