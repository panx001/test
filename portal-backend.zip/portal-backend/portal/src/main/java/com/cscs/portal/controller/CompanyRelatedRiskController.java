package com.cscs.portal.controller;

import com.alibaba.fastjson.JSON;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.util.Contants;
import com.cscs.util.HttpUtil;
import com.cscs.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.text.MessageFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 关联风险
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/company/relatedRisk")
public class CompanyRelatedRiskController {

    //股东关系
    public static String COMPANY_RR_SHARERELATION = "crr_sharerelation";
    //担保关系 - 为当前公司担保的企业
    public static String COMPANY_RR_GUATANTEETO = "crr_guaranteeto";
    //担保关系 - 当前公司对外担保的企业
    public static String COMPANY_RR_GUARANTEEOUT = "crr_guaranteeout";
    //担保关系 - 当前公司子公司对外担保的企业
    public static String COMPANY_RR_CHILDGUARANTEE = "crr_childguarantee";
    //投资关系
    public static String COMPANY_RR_INVESTMENT = "crr_investment";
    //主要客户
    public static String COMPANY_RR_TOPCUST = "crr_topcust";
    //主要供应商
    public static String COMPANY_RR_TOPSUPP = "crr_topsupp";
    //重要关联人 - 同一法定代表人
    public static String COMPANY_RR_8 = "crr8_";
    //重要关联人 - 同一实际控制人
    public static String COMPANY_RR_9 = "crr9_";
    //重要关联人 - 同一董事长
    public static String COMPANY_RR_10 = "crr10_";
    //重要关联人 - 同一执行董事
    public static String COMPANY_RR_11 = "crr11_";

    @Autowired
    private StringRedisTemplate rt;

    /**
     * 股东关系
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/sharehdrelation/{companyId}", method = RequestMethod.GET)
    public BaseOutData getSharehdrelation(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        List<Map> list = null;
        try {
            out = rt.opsForValue().get(COMPANY_RR_SHARERELATION + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RELATEDRISK_SHAREHDRELATION_URL, companyId));
                if (null != out) {
                    rt.opsForValue().set(COMPANY_RR_SHARERELATION + companyId, out.toString());
                    rt.expire(COMPANY_RR_SHARERELATION + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
            if(out!=null) {
    			//排序
    			list = JSON.parseArray(String.valueOf(out), Map.class);
    			Collections.sort(list,new Comparator<Map>(){
    	            public int compare(Map arg0, Map arg1) {
    	            	String sharehdRatioStr0 = arg0.get("sharehdRatio")!=null?arg0.get("sharehdRatio").toString():"";
    	            	String sharehdRatioStr1 = arg1.get("sharehdRatio")!=null?arg1.get("sharehdRatio").toString():"";
    	            	if(sharehdRatioStr0.indexOf("%")!=-1) {
    	            		sharehdRatioStr0=sharehdRatioStr0.substring(0, sharehdRatioStr0.indexOf("%"));
    	            	}
    	            	if(sharehdRatioStr1.indexOf("%")!=-1) {
    	            		sharehdRatioStr1=sharehdRatioStr1.substring(0, sharehdRatioStr1.indexOf("%"));
    	            	}
    	                return Double.valueOf(sharehdRatioStr1).compareTo(Double.valueOf(sharehdRatioStr0));
    	            }
    	        });
    		}
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", list);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }
    
    /**
     * 担保关系 - 为当前公司担保的企业
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/guaranteeTo/{companyId}", method = RequestMethod.GET)
    public BaseOutData getGuaranteeToList(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_RR_GUATANTEETO + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RELATEDRISK_GUARANTEETO_URL, companyId));
                if (null != out) {
                    rt.opsForValue().set(COMPANY_RR_GUATANTEETO + companyId, out.toString());
                    rt.expire(COMPANY_RR_GUATANTEETO + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 担保关系 - 当前公司对外担保的企业
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/guaranteeOut/{companyId}", method = RequestMethod.GET)
    public BaseOutData getGuaranteeOutList(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_RR_GUARANTEEOUT + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RELATEDRISK_GUARANTEEOUT_URL, companyId));
                if (null != out) {
                    rt.opsForValue().set(COMPANY_RR_GUARANTEEOUT + companyId, out.toString());
                    rt.expire(COMPANY_RR_GUARANTEEOUT + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 担保关系 - 当前公司子公司对外担保的企业
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/guaranteeOutOfChild/{companyId}", method = RequestMethod.GET)
    public BaseOutData getGuaranteeOutOfChildList(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_RR_CHILDGUARANTEE + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RELATEDRISK_GUARANTEEOUTOFCHILD_URL, companyId));
                if (null != out) {
                    rt.opsForValue().set(COMPANY_RR_CHILDGUARANTEE + companyId, out.toString());
                    rt.expire(COMPANY_RR_CHILDGUARANTEE + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 投资关系
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/investrelation/{companyId}", method = RequestMethod.GET)
    public BaseOutData getInvestRelationList(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_RR_INVESTMENT + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RELATEDRISK_INVESTRELATION_URL, companyId));
                if (null != out) {
                    rt.opsForValue().set(COMPANY_RR_INVESTMENT + companyId, out.toString());
                    rt.expire(COMPANY_RR_INVESTMENT + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 主要客户
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/topcustomer/{companyId}", method = RequestMethod.GET)
    public BaseOutData getTopCustomerList(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_RR_TOPCUST + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RELATEDRISK_TOPCUSTOMER_URL, companyId));
                if (null != out) {
                    rt.opsForValue().set(COMPANY_RR_TOPCUST + companyId, out.toString());
                    rt.expire(COMPANY_RR_TOPCUST + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 主要供应商
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/topsupplier/{companyId}", method = RequestMethod.GET)
    public BaseOutData getTopSupplierList(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_RR_TOPSUPP + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RELATEDRISK_TOPSUPPLIER_URL, companyId));
                if (null != out) {
                    rt.opsForValue().set(COMPANY_RR_TOPSUPP + companyId, out.toString());
                    rt.expire(COMPANY_RR_TOPSUPP + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 重要关联人 - 同一法定代表人
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/samelegperson/{companyId}", method = RequestMethod.GET)
    public BaseOutData getSameLegPersonList(@PathVariable String companyId) {
        BaseOutData out = new BaseOutData();
        if (StringUtil.isEmpty(companyId)) {
            out.setCode("1");
            return out;
        }
        Map<String, Object> re = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RELATEDRISK_SAMELEGPERSON_URL, companyId));
        out.setData(re);
        out.setCode("0");
        return out;
    }

    /**
     * 重要关联人 - 同一实际控制人
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/sameactualmanager/{companyId}", method = RequestMethod.GET)
    public BaseOutData getSameActualManagerList(@PathVariable String companyId) {
        BaseOutData out = new BaseOutData();
        if (StringUtil.isEmpty(companyId)) {
            out.setCode("1");
            return out;
        }
        Map<String, Object> re = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RELATEDRISK_SAMEACTUALMANAGER_URL, companyId));
        out.setData(re);
        out.setCode("0");
        return out;
    }

    /**
     * 重要关联人 - 同一董事长
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/samechairman/{companyId}", method = RequestMethod.GET)
    public BaseOutData getSameChairmanList(@PathVariable String companyId) {
        BaseOutData out = new BaseOutData();
        if (StringUtil.isEmpty(companyId)) {
            out.setCode("1");
            return out;
        }
        Map<String, Object> re = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RELATEDRISK_SAMECHAIRMAN_URL, companyId));
        out.setData(re);
        out.setCode("0");
        return out;
    }

    /**
     * 重要关联人 - 同一执行董事
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/sameexecutivechairman/{companyId}", method = RequestMethod.GET)
    public BaseOutData getSameExecutiveChairmanList(@PathVariable String companyId) {
        BaseOutData out = new BaseOutData();
        if (StringUtil.isEmpty(companyId)) {
            out.setCode("1");
            return out;
        }
        Map<String, Object> re = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RELATEDRISK_SAMEEXECUTIVECHAIRMAN_URL, companyId));
        out.setData(re);
        out.setCode("0");
        return out;
    }


    /**
     * 图谱专用接口
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/getRelatedRiskTopo/{companyId}", method = RequestMethod.GET)
    public BaseOutData getRelatedRiskForTopo(@PathVariable String companyId) {
        BaseOutData out = new BaseOutData();

        BaseOutData sharehdRelation = this.getSharehdrelation(companyId);
        BaseOutData guaranteeOut = this.getGuaranteeOutList(companyId);
        BaseOutData investRelation = this.getInvestRelationList(companyId);
        BaseOutData topCustomer = this.getTopCustomerList(companyId);
        BaseOutData topSupplier = this.getTopSupplierList(companyId);

        Map data = new HashMap();
        data.put("sharehdRelation", sharehdRelation.getData().get("result"));
        data.put("guaranteeOut", guaranteeOut.getData().get("result"));
        data.put("investRelation", investRelation.getData().get("result"));
        data.put("topCustomer", topCustomer.getData().get("result"));
        data.put("topSupplier", topSupplier.getData().get("result"));

        out.setCode("0");
        out.setMessage("返回成功!");
        out.setData(data);
        return out;
    }
}
