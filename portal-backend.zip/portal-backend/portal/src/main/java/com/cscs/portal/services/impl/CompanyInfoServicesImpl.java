package com.cscs.portal.services.impl;

import com.cscs.portal.services.CompanyInfoServices;
import com.cscs.repository.CompanyBasicInfoRepository;
import com.cscs.util.StringUtil;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by sh on 2016/8/5.
 */
@Service
public class CompanyInfoServicesImpl implements CompanyInfoServices {

    @Autowired
    CompanyBasicInfoRepository companyBasicInfoRepository;

    @PersistenceContext
    EntityManager em;

    @Autowired
    private StringRedisTemplate rt;


    @Override
    public String getCompyCreditRating(String companyId) {
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT RATING from ( \n")
                .append(" SELECT RATING FROM COMPY_CREDITRATING \n")
                .append(" WHERE COMPANY_ID=").append(companyId).append(" ORDER BY RATING_DT desc \n")
                .append(") WHERE rownum =1");
        List result =  em.createNativeQuery(sb.toString()).getResultList();
        return result.size() == 0 ? "" : result.get(0).toString();
    }

    @Override
    public List<String> getCompyTipInfo(String companyId) {
        List<String> result = new ArrayList<>();
        Gson gson = new Gson();
        String info = rt.opsForValue().get("companytips_" + companyId);
        if (StringUtil.isEmpty(info)) {
            StringBuilder sb = new StringBuilder();
            sb.append("SELECT DISTINCT LKP1.SECURITY_TYPE AS COMPANY_TYPE FROM CS_PORTAL.SECURITY A \n")
                    .append(" INNER JOIN  CS_PORTAL.COMPY_BASICINFO B \n")
                    .append(" ON   A.COMPANY_ID = B.COMPANY_ID AND B.IS_DEL=0 AND B.COMPANY_ID=").append(companyId)
                    .append("\n INNER JOIN (SELECT CONSTANT_ID AS SECURITY_TYPE_ID, CONSTANT_NM AS SECURITY_TYPE FROM CS_PORTAL.LKP_CHARCODE WHERE CONSTANT_TYPE = 401 AND ISDEL = 0) LKP1 \n")
                    .append(" ON A.SECURITY_TYPE_ID = LKP1.SECURITY_TYPE_ID \n")
                    .append(" WHERE A.ISDEL=0 AND  LKP1.SECURITY_TYPE IN ('A股', 'B股', 'H股', '三板股') AND A.LIST_ST IN (0,3) AND B.IS_DEL = 0 AND B.COMPANY_ST = 1 \n")
                    .append(" UNION \n")
                    .append(" SELECT DISTINCT '发债企业' COMPANY_TYPE FROM CS_PORTAL.SECURITY A \n")
                    .append(" INNER JOIN CS_PORTAL.COMPY_BASICINFO B \n")
                    .append(" ON A.COMPANY_ID= B.COMPANY_ID AND B.IS_DEL=0 AND B.COMPANY_ID=").append(companyId)
                    .append("\n INNER JOIN CS_PORTAL.BOND_BASICINFO C \n")
                    .append(" ON A.SECINNER_ID = C.SECINNER_ID AND C.ISDEL=0 \n")
                    .append(" WHERE   A.ISDEL = 0 AND B.COMPANY_ST = 1 AND B.COUNTRY = 'CN' \n")
                    .append(" UNION \n")
                    .append(" SELECT DISTINCT '私募企业' COMPANY_TYPE \n")
                    .append(" FROM CS_PORTAL.PFCOMPY_BASICINFO A \n")
                    .append(" INNER JOIN CS_PORTAL.COMPY_BASICINFO B \n")
                    .append(" ON A.COMPANY_ID = B.COMPANY_ID AND A.ISDEL=0 AND B.COMPANY_ID=").append(companyId)
//                    .append("\n UNION \n")
//                    .append(" SELECT '非公开' FROM VW_COMPY_TYPE WHERE COMPANY_TYPE=0 AND COMPANY_ID=").append(companyId)
                    .append(" \n UNION \n")
                    .append(" SELECT DISTINCT '新三板' FROM CS_PORTAL.SECURITY A \n")
                    .append(" INNER JOIN    CS_PORTAL.COMPY_BASICINFO B \n")
                    .append(" ON    A.COMPANY_ID = B.COMPANY_ID AND B.IS_DEL=0 AND B.COMPANY_ID=").append(companyId)
                    .append("\n INNER JOIN (SELECT CONSTANT_ID AS SECURITY_TYPE_ID, CONSTANT_NM AS SECURITY_TYPE FROM CS_PORTAL.LKP_CHARCODE WHERE CONSTANT_TYPE = 401 AND ISDEL = 0) LKP1 \n")
                    .append(" ON A.SECURITY_TYPE_ID = LKP1.SECURITY_TYPE_ID \n")
                    .append(" WHERE A.ISDEL=0 AND  LKP1.SECURITY_TYPE = '三板股' AND A.TRD_MARKET_ID = 5702 AND A.LIST_ST IN (0,3) AND B.IS_DEL = 0 AND B.COMPANY_ST = 1");

            result = (List<String>)em.createNativeQuery(sb.toString()).getResultList();

            rt.opsForValue().set("companytips_" + companyId, gson.toJson(result));
            rt.expire("companytips_" + companyId, 18, TimeUnit.HOURS);
        }
        else {
            result = gson.fromJson(info, List.class);
        }

        return result;
    }

    @Override
    public List<Object> findExposureCodeDetail(Long id, String code) {
        String sql = "SELECT B.COMPANY_NM,FACTOR_VALUE FROM VW_COMPY_FACTOR_FINANCE A\n" +
                "INNER JOIN COMPY_BASICINFO B ON A.COMPANY_ID = B.COMPANY_ID\n" +
                "INNER JOIN FACTOR C ON A.FACTOR_CD = C.FACTOR_CD\n" +
                "INNER JOIN (SELECT COMPANY_ID FROM COMPY_EXPOSURE WHERE EXPOSURE_SID = 6355 AND IS_NEW = 1 AND ISDEL = 0)C ON A.COMPANY_ID = C.COMPANY_ID\n" +
                "WHERE A.FACTOR_CD = ?1\n" +
                "AND A.FACTOR_VALUE IS NOT NULL\n" +
//                "AND A.COMPANY_ID IN(SELECT COMPANY_ID FROM COMPY_EXPOSURE WHERE EXPOSURE_SID = 6355 AND IS_NEW = 1 AND ISDEL = 0)\n" +
                "ORDER BY A.FACTOR_VALUE * C.DIRECTION";
        Query query = em.createNativeQuery(sql);
        query.setParameter(1, code);
        return query.getResultList();
    }

    @Override
    public List<Object> findIndustryCodeDetail(Long id, String code) {
        String sql = "SELECT B.COMPANY_NM,FACTOR_VALUE FROM VW_COMPY_FACTOR_FINANCE A\n" +
                "INNER JOIN COMPY_BASICINFO B ON A.COMPANY_ID = B.COMPANY_ID\n" +
                "INNER JOIN FACTOR C ON A.FACTOR_CD = C.FACTOR_CD\n" +
                "INNER JOIN (" + getSQLforIndustry(id) + ")C ON A.COMPANY_ID = C.COMPANY_ID\n" +
                "WHERE A.FACTOR_CD = ?1 \n" +
                "AND A.FACTOR_VALUE IS NOT NULL\n" +
//                "AND A.COMPANY_ID IN (" + getSQLforIndustry(id) + ")\n" +
                "ORDER BY A.FACTOR_VALUE * C.DIRECTION";
        Query query = em.createNativeQuery(sql);
        query.setParameter(1, code);
        return query.getResultList();
    }

    //按照申万行业分类的 二级 行业，新三板按照证监会三级行业分类，探索根据万得行业分类匹配申万行业分类
    private String getSQLforIndustry(Long id) {
//        //判断是否新三板
//        String sql1 = "SELECT DISTINCT b.COMPANY_ID\n" +
//                "  FROM compy_basicinfo b\n" +
//                " INNER join COMPY_SECURITY_XW xw on b.company_id = xw.company_id\n" +
//                " INNER join SECURITY a on xw.SECINNER_ID = a.SECINNER_ID\n" +
//                " INNER JOIN (select constant_id as SECURITY_TYPE_ID,\n" +
//                "                    constant_nm as SECURITY_TYPE\n" +
//                "               from LKP_CHARCODE\n" +
//                "              where constant_type = 401\n" +
//                "                and isdel = 0) lkp2 on a.SECURITY_TYPE_ID =\n" +
//                "                                       lkp2.SECURITY_TYPE_ID\n" +
//                " WHERE lkp2.SECURITY_TYPE = '三板股'\n" +
//                "   AND b.is_del = 0\n" +
//                "   and a.isdel = 0\n" +
//                "   and b.COMPANY_ST = 1\n" +
//                "   and b.country = 'CN'\n" +
//                "   AND a.LIST_ST != 2 \n" +
//                "   and b.company_id = " + id + "";
//
//        List<Object> retList = em.createNativeQuery(sql1).getResultList();
        // 新三板
        String sql = "";
        if (rt.opsForValue().get("industry1008_" + id) != null) {
            //新三板
            sql = "SELECT COMPANY_ID FROM SECURITY WHERE SECURITY_TYPE_ID = 5496 AND LIST_ST != 2 AND ISDEL = 0";
        } else {
            //申万行业
            sql = "SELECT VM.COMPANY_ID FROM VW_COMPY_INDUSTRY VM " +
                    "INNER JOIN (SELECT V.INDUSTRY_LEVEL1 FROM VW_COMPY_INDUSTRY V WHERE V.SYSTEM_CD = 1011 AND V.COMPANY_ID = " + id + ") VM2" +
                    " ON VM2.INDUSTRY_LEVEL1 = VM.INDUSTRY_LEVEL1 AND VM.SYSTEM_CD = 1011";
        }
        return sql;
    }
}

