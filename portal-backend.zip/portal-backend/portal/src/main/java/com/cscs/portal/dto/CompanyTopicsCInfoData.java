package com.cscs.portal.dto;

/**
 * Created by sh on 2016/8/7.
 */
public class CompanyTopicsCInfoData {
    private long id;
    private long companyId;
    private String companyNm;
    private long companyTopicsId;
    

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }


    public long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(long companyId) {
        this.companyId = companyId;
    }

    public String getCompanyNm() {
        return companyNm;
    }

    public void setCompanyNm(String companyNm) {
        this.companyNm = companyNm;
    }

	public long getCompanyTopicsId() {
		return companyTopicsId;
	}

	public void setCompanyTopicsId(long companyTopicsId) {
		this.companyTopicsId = companyTopicsId;
	}

}
