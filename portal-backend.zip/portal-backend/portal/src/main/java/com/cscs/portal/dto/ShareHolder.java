package com.cscs.portal.dto;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class ShareHolder implements Comparable<ShareHolder> {

	private String noticeDt;
	private List<ShareHolderDetail> sharehdList;

	public String getNoticeDt() {
		return noticeDt;
	}

	public void setNoticeDt(String noticeDt) {
		this.noticeDt = noticeDt;
	}

	public List<ShareHolderDetail> getSharehdList() {
		return sharehdList;
	}

	public void setSharehdList(List<ShareHolderDetail> sharehdList) {
		this.sharehdList = sharehdList;
	}

	@Override
	public int compareTo(ShareHolder o) {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date dt1;
		Date dt2;
		try {
			dt1 = df.parse(noticeDt);
			dt2 = df.parse(o.getNoticeDt());
			//降序
			if (dt1.getTime() > dt2.getTime()) {
				return -1;
			} else if (dt1.getTime() < dt2.getTime()) {
				return 1;
			} else {
				return 0;
			}
		} catch (ParseException e) {
			return 0;
		}

	}

}
