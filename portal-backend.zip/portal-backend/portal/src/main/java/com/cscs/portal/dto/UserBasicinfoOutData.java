package com.cscs.portal.dto;

import com.cscs.portal.dto.base.BaseOutData;

import java.sql.Clob;
import java.sql.Time;
import java.sql.Timestamp;

/**
 * Created by dch on 2016/11/7.
 * 用户信息表的出参
 */
public class UserBasicinfoOutData extends BaseOutData {
    private String userNm;//用户名
    private String headUrl;//用户头像URL
    private Time birth;//用户出生年月日
    private Long userGender;//用户性别
    private String idCardNo;//用户身份证
    private String cellphone;//用户手机号
    private String phone;//用户电话号

    /**
     * 用户邮箱
     */
    private String email;
    /**
     * 用户地址
     */
    private String address;
    /**
     * 用户专业
     */
    private String major;
    /**
     * 用户学历
     */
    private Long educational;
    /**
     * 用户政治面貌
     */
    private Long politicalStatus;
    /**
     * 用户一句话的简介
     */
    private String introduction;
    /**
     * 用户的用户类型
     */
    private Long userType;
    /**
     * 用户的机构Id
     */
    private Long companyId;
    /**
     * 用户的机构名称
     */
    private String companyNm;
    /**
     * 用户的擅长类型
     */
    private String goodType;
    /**
     * 用户的行业Id
     */
    private Long industrySid;

    /**
     * 职务名称
     */
    private String position;


    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getUserNm() {
        return userNm;
    }

    public void setUserNm(String userNm) {
        this.userNm = userNm;
    }

    public String getHeadUrl() {
        return headUrl;
    }

    public void setHeadUrl(String headUrl) {
        this.headUrl = headUrl;
    }

    public Time getBirth() {
        return birth;
    }

    public void setBirth(Time birth) {
        this.birth = birth;
    }

    public Long getUserGender() {
        return userGender;
    }

    public void setUserGender(Long userGender) {
        this.userGender = userGender;
    }

    public String getIdCardNo() {
        return idCardNo;
    }

    public void setIdCardNo(String idCardNo) {
        this.idCardNo = idCardNo;
    }

    public String getCellphone() {
        return cellphone;
    }

    public void setCellphone(String cellphone) {
        this.cellphone = cellphone;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public Long getEducational() {
        return educational;
    }

    public void setEducational(Long educational) {
        this.educational = educational;
    }

    public Long getPoliticalStatus() {
        return politicalStatus;
    }

    public void setPoliticalStatus(Long politicalStatus) {
        this.politicalStatus = politicalStatus;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public Long getUserType() {
        return userType;
    }

    public void setUserType(Long userType) {
        this.userType = userType;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public String getCompanyNm() {
        return companyNm;
    }

    public void setCompanyNm(String companyNm) {
        this.companyNm = companyNm;
    }

    public String getGoodType() {
        return goodType;
    }

    public void setGoodType(String goodType) {
        this.goodType = goodType;
    }

    public Long getIndustrySid() {
        return industrySid;
    }

    public void setIndustrySid(Long industrySid) {
        this.industrySid = industrySid;
    }


}
