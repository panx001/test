package com.cscs.portal.controller;

import com.cscs.portal.dto.InterFaceOutData;
import com.cscs.portal.dto.InterFaceQueryInfoData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.Interface;
import com.cscs.portal.services.IInterFaceServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by levy on 2017/12.2
 * 接口界面
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/interface")
public class InterFaceController {
    @Autowired
    IInterFaceServices interFaceServices;

    /**
     * 查询界面接口
     *
     * @param
     * @return
     */
    @RequestMapping(value = "/findInterface", method = RequestMethod.POST)
    public BaseOutData FindInterFace(@RequestBody InterFaceQueryInfoData interFaceQueryInfoData) {
        BaseOutData out = new BaseOutData();
        int count = interFaceServices.findInterFaceCount(interFaceQueryInfoData);
        out.setCount(count);
        List<Object> itemList = interFaceServices.findInterFaceList(interFaceQueryInfoData);
        List<InterFaceOutData> outDataList = new ArrayList<>();
        for (int i = 0; i < itemList.size(); i++) {
            InterFaceOutData outData = new InterFaceOutData();
            Object[] item = (Object[]) itemList.get(i);
            outData.setInterfaceId(item[0] == null ? null : Long.valueOf(item[0].toString()));
            outData.setInterfaceNm(item[1] == null ? null : item[1].toString());
            outData.setInterfaceUrl(item[2] == null ? null : item[2].toString());
            outData.setCtlType(item[3] == null ? null : item[3].toString());
            outData.setCtlNm(item[4] == null ? null : item[4].toString());
            outDataList.add(outData);
        }
        Map<String, Object> map = new HashMap<String, Object>();
        out.setCode("0");
        map.put("outDataList", outDataList);
        out.setData(map);
        return out;
    }

    /**
     * 新增界面接口
     *
     * @param
     * @return
     */
//    @Transactional
    @RequestMapping(value = "/saveOrUpdate", method = RequestMethod.POST)
    public BaseOutData saveOrUpdate(@RequestBody InterFaceQueryInfoData infoData) {
        BaseOutData out = new BaseOutData();
        try {
            Interface info = new Interface();
            if(infoData.getInterfaceId() != null) {
                info.setInterfaceId(infoData.getInterfaceId());
            }
            info.setInterfaceNm(infoData.getInterfaceNm());
            info.setInterfaceUrl(infoData.getInterfaceUrl());
            String ctlName = interFaceServices.getCtlNameByCtlType(infoData.getInterfaceCtlType());
            info.setCtlType(infoData.getInterfaceCtlType());
            info.setCtlName(ctlName);
            interFaceServices.saveOrUpdate(info);
            out.setCode("0");
        } catch (Exception ex) {
            out.setCode("1");
        }
        return out;
    }

    @RequestMapping(value = "/delete/{interfaceId}", method = RequestMethod.GET)
    public BaseOutData saveOrUpdate(@PathVariable String  interfaceId) {
        BaseOutData out = new BaseOutData();
        try {
            interFaceServices.delete(Long.valueOf(interfaceId));
            out.setCode("0");
        } catch (Exception ex) {
            out.setCode("1");
        }
        return out;
    }

    /**
     * 返回接口类型
     *
     * @param
     * @return
     */
    @RequestMapping(value = "/interfaceType", method = RequestMethod.GET)
    public BaseOutData interfaceType() {
        BaseOutData out = new BaseOutData();
        List<Object> itemList = interFaceServices.findInterFaceTypeList();
        List<InterFaceOutData> outDataList = new ArrayList<>();
        for (int i = 0; i < itemList.size(); i++) {
            InterFaceOutData outData = new InterFaceOutData();
            Object[] item = (Object[]) itemList.get(i);
            outData.setCtlType(item[0] == null ? null : item[0].toString());
            outData.setCtlNm(item[1] == null ? null : item[1].toString());
            outDataList.add(outData);
        }
        Map<String, Object> map = new HashMap<String, Object>();
        out.setCode("0");
        map.put("outDataList", outDataList);
        out.setData(map);
        return out;
    }
}
