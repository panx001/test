package com.cscs.portal.entity;

import javax.persistence.*;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "HOT_COMPANIES", schema = "CS_PORTAL", catalog = "")
public class HotCompanies {
    private long id;
    private String link;
    private String name;
    private long priority;
    private Date dt;
    private long isDel;
    
    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_HOT_COMPANIES")
    @SequenceGenerator(sequenceName = "SEQ_HOT_COMPANIES", name = "SEQ_HOT_COMPANIES")
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "LINK")
    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
    

    @Basic
    @Column(name = "ISDEL")
    public long getIsDel() {
		return isDel;
	}

	public void setIsDel(long isDel) {
		this.isDel = isDel;
	}

	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        HotCompanies hotCompanies = (HotCompanies) o;
        return id == hotCompanies.id &&
                Objects.equals(link, hotCompanies.link) &&
                Objects.equals(name, hotCompanies.name) &&
                Objects.equals(dt, hotCompanies.dt) &&
                Objects.equals(isDel, hotCompanies.isDel) &&
                Objects.equals(priority, hotCompanies.priority);
    }

    @Basic
    @Column(name = "NAME")
    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Basic
    @Column(name = "PRIORITY")
	public long getPriority() {
		return priority;
	}

	public void setPriority(long priority) {
		this.priority = priority;
	}

	@Basic
	@Column(name = "DT")
	public Date getDt() {
		return dt;
	}

	public void setDt(Date dt) {
		this.dt = dt;
	}

	@Override
    public int hashCode() {

        return Objects.hash(id, link, name, dt, priority,isDel);
    }
}
