package com.cscs.portal.dto;

import com.cscs.portal.dto.base.BaseInData;

/**
 * Created by sh on 2016/8/7.
 */
public class PFCompySearchIn extends BaseInData{

    private int type ;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
