package com.cscs.portal.services;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.response.QueryResponse;

import com.cscs.portal.dto.PsecSearchConditon;
import com.cscs.portal.dto.PsecSearchOut;

/**
 * 
 * @ClassName: RiskSearchServices
 * @Description: 发债企业高级搜索服务接口
 * @author: liunn
 * @date: 2018年10月20日 下午4:37:27
 */
public interface PFundSearchServices {
    /**
     * 
     * @Title: setSolrQuery
     * @Description: 组装SolrQuery参数
     * @param solrQuery
     * @return
     * @return: SolrQuery
     */
	SolrQuery setSolrQuery(PsecSearchConditon condition,SolrQuery query);
	
	/**
	 * 
	 * @Title: getResponseDate
	 * @Description: 组装返回参数
	 * @param response
	 * @return
	 * @return: List<RiskSearchOut>
	 */
	List<PsecSearchOut> getResponseDate(QueryResponse response);
	/**
	 * 
	 * @Title: cancelRecord
	 * @Description: 取消备案机构
	 * @param response
	 * @return
	 * @return: List<Map>
	 */
	public List<Map> cancelRecord(QueryResponse response);
	
	public String getQueryTime(String foundDt) throws ParseException;
}
