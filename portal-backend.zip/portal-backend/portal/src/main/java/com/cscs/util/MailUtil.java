package com.cscs.util;

import com.cscs.portal.dto.MailImage;
import sun.misc.BASE64Decoder;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.UUID;


public class MailUtil {
    public final static void sendmail(String tostr, String subject, String content, String imageDirPath) {
        try {
            Properties props = new Properties();
            props.setProperty("mail.transport.protocol", Contants.PROTOCOL);    // 使用的协议（JavaMail规范要求）
            props.setProperty("mail.host", Contants.MAIL_HOST);           // 发件人的邮箱的 SMTP 服务器地址
            props.setProperty("mail.smtp.auth", "true");

            Session mailSession = Session.getInstance(props);
            MimeMessage message = new MimeMessage(mailSession);
            InternetAddress from = new InternetAddress(Contants.MAIL_USER);
            message.setFrom(from);
            InternetAddress to = new InternetAddress(tostr);
            message.setRecipient(MimeMessage.RecipientType.TO, to);
            message.setSubject(subject);

            List<String> imagePaths = new ArrayList();
            File imageDir = null;

            if (!StringUtil.isEmpty(imageDirPath)) {
                BodyPart mbp=new MimeBodyPart();
                mbp.setContent(content,"text/html;charset=UTF-8");
                Multipart mm = new MimeMultipart("related");
                mm.addBodyPart(mbp);

                imageDir = new File(imageDirPath);
                File[] files = imageDir.listFiles();


                for(File image : files) {
                    FileDataSource fds=new FileDataSource(image);
                    mbp = new MimeBodyPart();
                    DataHandler dh=new DataHandler(fds);
                    mbp.setDataHandler(dh);
                    //设置对应的资源文件的唯一标识符，即 MIME 协议对于邮件的结构组织格式中的 Content-ID 头字段；
                    mbp.setHeader("Content-ID", image.getName());
                    mbp.setFileName(MimeUtility.encodeText(fds.getName()));
                    mm.addBodyPart(mbp);
                }
                message.setContent(mm);//把mm作为消息对象的内容
                message.saveChanges();
            }
            else {
                message.setContent(content, "text/html;charset=UTF-8");
            }


            Transport transport = mailSession.getTransport();
            transport.connect(Contants.MAIL_USER, Contants.MAIL_PSW);
            transport.sendMessage(message, message.getAllRecipients());//发送邮件,其中第二个参数是所有已设好的收件人地址
            transport.close();

            if (null != imageDir && imageDir.exists()) {
                deleteDir(imageDir);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            for (int i=0; i<children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }
        // 目录此时为空，可以删除
        return dir.delete();
    }

	public final static void sendmail(String tostr, String subject, String content, List<MailImage> images, String contextPath) {
		try {
	        Properties props = new Properties();
	        props.setProperty("mail.transport.protocol", Contants.PROTOCOL);    // 使用的协议（JavaMail规范要求）
            props.setProperty("mail.host", Contants.MAIL_HOST);           // 发件人的邮箱的 SMTP 服务器地址
            props.setProperty("mail.smtp.auth", "true");

            Session mailSession = Session.getInstance(props);
            MimeMessage message = new MimeMessage(mailSession);
            InternetAddress from = new InternetAddress(Contants.MAIL_USER);
            message.setFrom(from);
            InternetAddress to = new InternetAddress(tostr);
            message.setRecipient(MimeMessage.RecipientType.TO, to);
            message.setSubject(subject);

            List<String> imagePaths = new ArrayList();
            File imgFiledir = null;

            if (null != images && images.size() >0) {
                BodyPart mbp=new MimeBodyPart();
                mbp.setContent(content,"text/html;charset=UTF-8");
                Multipart mm = new MimeMultipart("related");
                mm.addBodyPart(mbp);

                File tempFile = new File(contextPath + File.separator + "imagetemp");
                if (!tempFile.exists()) {
                    tempFile.mkdirs();
                }
                imgFiledir = new File(tempFile.getPath() + File.separator + new Date().getTime() + UUID.randomUUID().toString());
                if (!imgFiledir.exists()) {
                    imgFiledir.mkdirs();
                }

                for(MailImage image : images) {
                    if (!StringUtil.isEmpty(image.getImage()) && !StringUtil.isEmpty(image.getName())) {
                        String imgFilePath = imgFiledir.getPath() + File.separator + image.getName();
                        mm.addBodyPart(createImageMimeBodyPart(contextPath, image, imgFilePath));
                        imagePaths.add(imgFilePath);
                    }
                }
                message.setContent(mm);//把mm作为消息对象的内容
                message.saveChanges();
            }
            else {
                message.setContent(content, "text/html;charset=UTF-8");
            }


            Transport transport = mailSession.getTransport();
            transport.connect(Contants.MAIL_USER, Contants.MAIL_PSW);
            transport.sendMessage(message, message.getAllRecipients());//发送邮件,其中第二个参数是所有已设好的收件人地址
            transport.close();
	        
            for(String path : imagePaths) {
                File file = new File(path);
                file.delete();
            }
            if (null != imgFiledir && imgFiledir.exists()) {
                imgFiledir.delete();
            }
	    } catch (Exception e) {
            e.printStackTrace();
        }
	}

    private static MimeBodyPart createImageMimeBodyPart(String contextPath, MailImage image, String imgFilePath) throws MessagingException, UnsupportedEncodingException {
        GenerateImage(contextPath, image, imgFilePath);
        FileDataSource fds=new FileDataSource(imgFilePath);
        MimeBodyPart mbp=new MimeBodyPart();
        DataHandler dh=new DataHandler(fds);
        mbp.setDataHandler(dh);
        //设置对应的资源文件的唯一标识符，即 MIME 协议对于邮件的结构组织格式中的 Content-ID 头字段；
        mbp.setHeader("Content-ID", image.getName());
        mbp.setFileName(MimeUtility.encodeText(fds.getName()));
        return mbp;
    }

    //base64字符串转化成图片
    public static String GenerateImage(String contextPath, MailImage image, String imgFilePath)
    {
        String imgStr = image.getImage();
        if (imgStr.startsWith("data:image")) {
            int index = imgStr.indexOf(";base64,");
            imgStr = imgStr.substring(index+8);
        }

        BASE64Decoder decoder = new BASE64Decoder();
        try
        {
            //Base64解码
            byte[] b = decoder.decodeBuffer(imgStr);
            for(int i=0;i<b.length;++i)
            {
                if(b[i]<0)
                {//调整异常数据
                    b[i]+=256;
                }
            }
            OutputStream out = new FileOutputStream(imgFilePath);
            out.write(b);
            out.flush();
            out.close();
            return imgFilePath;
        }
        catch (Exception e)
        {
            return "";
        }
    }
}