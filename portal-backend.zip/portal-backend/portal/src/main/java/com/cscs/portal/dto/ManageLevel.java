package com.cscs.portal.dto;

import java.text.Collator;
import java.util.Comparator;

public class ManageLevel implements Comparable<ManageLevel> {

	private String pstnNm;
	private String degree;
	private String sex;
	private String personNm;
	private String country;
	private String age;

	public String getPstnNm() {
		return pstnNm;
	}

	public void setPstnNm(String pstnNm) {
		this.pstnNm = pstnNm;
	}

	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getPersonNm() {
		return personNm;
	}

	public void setPersonNm(String personNm) {
		this.personNm = personNm;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	@Override
	public int compareTo(ManageLevel o) {
		Comparator<Object> com = Collator.getInstance(java.util.Locale.CHINA);
        return com.compare(pstnNm, o.pstnNm);

		//return pstnNm.compareTo(o.pstnNm);
	}
}
