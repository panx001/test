package com.cscs.portal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.cscs.portal.services.NotificationService;

@Component
public class AsyncTask {
	
	 @Autowired
	 private NotificationService notificationService;
	 
	 @Async
	 public void linkUser() {
        List<Object> itemList = notificationService.getUnLinkCount();
        for (int i = 0; i < itemList.size(); i++)
            notificationService.saveUser(Long.valueOf(itemList.get(i).toString()));
	 }
	 
	 @Async
	 public void linkUserCurNotify(Long id) {
            notificationService.saveUser(id);
	 }
	 
	 
}

