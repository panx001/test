package com.cscs.portal.services;

import java.text.ParseException;
import java.util.List;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.response.QueryResponse;

import com.cscs.portal.dto.BondSearchConditon;
import com.cscs.portal.dto.BondSearchOut;

/**
 * 
 * @ClassName: RiskSearchServices
 * @Description: 发债企业高级搜索服务接口
 * @author: liunn
 * @date: 2018年10月20日 下午4:37:27
 */
public interface BondSearchServices {
    /**
     * 
     * @Title: setSolrQuery
     * @Description: 组装SolrQuery参数
     * @param solrQuery
     * @return
     * @return: SolrQuery
     */
	SolrQuery setSolrQuery(BondSearchConditon condition,SolrQuery query);
	/**
	 * 
	 * @Title: bondIssuerCondition
	 * @Description: 债券发行人统计-查询条件设置
	 * @param condition
	 * @param query
	 * @return
	 * @return: SolrQuery
	 */
	public SolrQuery bondIssuerCondition(BondSearchConditon condition,SolrQuery query);
	
	/**
	 * 
	 * @Title: getResponseDate
	 * @Description: 组装返回参数
	 * @param response
	 * @return
	 * @return: List<RiskSearchOut>
	 */
	List<BondSearchOut> getResponseDate(QueryResponse response);
	/**
	 * 
	 * @Title: getBondIssuerCurrent
	 * @Description: 债券发行人统计-现债券融资额统计
	 * @param response
	 * @return
	 * @return: List<Object>
	 */
	public List getBondIssuerCurrent(QueryResponse response);
	/**
	 * 
	 * @Title: getBondIssuerCurrent
	 * @Description: 债券发行人统计-现债券融资额统计
	 * @param response
	 * @return
	 * @return: List<Object>
	 */
	public List getBondIssuerWithinYear(QueryResponse response);
	/**
	 * 
	 * @Title: getBondIssuerCurrent
	 * @Description: 债券发行人统计-现债券融资额统计
	 * @param response
	 * @return
	 * @return: List<Object>
	 */
	public List getBondIssuerDuration(QueryResponse response);
	
	public String getQueryTime(String foundDt) throws ParseException;
}
