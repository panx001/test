package com.cscs.portal.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.cscs.portal.dto.CommonForCreditReportComparator;
import com.cscs.portal.dto.CompanyReport;
import com.cscs.portal.dto.CompanyReportIn;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.util.Contants;
import com.cscs.util.DateUtils;
import com.cscs.util.HttpUtil;
import com.cscs.util.StringUtil;

import freemarker.template.Configuration;
import freemarker.template.Template;

/**
 * Created by Sai on 4/27/2016.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/companyCreditReport")
public class CompanyCreditReportController {

	private final Log logger = LogFactory.getLog(CompanyCreditReportController.class);

	@Autowired
	private StringRedisTemplate rt;

	@Autowired
	private CompanyBasicInfoController companyBasicInfoController;

	@Autowired
	private CompanyCreditController companyCreditController;

	@Autowired
	private CompanyRiskController companyRiskController;

	@Autowired
	private CompanyPrivateFundController companyPrivateFundController;

	@Autowired
	private CompanyReportController companyReportController;


	private static final String Jggg = "iVBORw0KGgoAAAANSUhEUgAABG8AAAFMCAYAAAECVKFYAAAACXBIWXMAAC4jAAAuIwF4pT92AAAg\n"
			+ "AElEQVR42uy9W2wcV5rn+T9JSrKllDJpu+5VzZSrZ8YuW0rqbYF9YGqBGezDAqKAeYjcF6aABTgz\n"
			+ "DZRIqrqrqme7mVpXdV1skVRjZ7AEFmDqKQP7IgqYp3lYJjH7LqYvXa6pcilZrq52tSxlpk1bliUx\n"
			+ "9iFOksFkXiIi43Ii4v8DZJPMS0ScOPGd//nOd75PGIYBQpySYhMQdhzCjkPYcUgMGR/04ocLOQMp\n"
			+ "ASEERAoQKQEIAQjs/w2d14T5mpCvAwIidfC5zutA539i/zjZa3XBW0GL45jWjbzRWs5zeseO47ID\n"
			+ "LbMDxWKoCrMDZRedDV9aUbPd4fSqLtx+1gY7elXPqdKWnWvrvubYiuPWcn7GyfudNIxW1AxrZ/G4\n"
			+ "USc97oi2rqHPe8qJsjiS24cUtEedx9rYWlGb16v66rDPakVtA8Al+etNvarPB2ElPOjUS0nsOGgt\n"
			+ "5yvZxXpJgRtyyfK5eUQAHy2q+h0HwCyAkhcN5ndDqtppRtV/rjrOd1Yanjbw7pownnx6zu92uwJg\n"
			+ "vdNgelUXSeo0djqCVtQKfd5eUNLipOcMITtQ4+nu+UmfGqoCoNLpLHY7jd2nctD7VOiUw65XK2qr\n"
			+ "A4bbmtKzqvSckfPbWxzGTZQznbKKlkYrajXZqa56MesbuuQgxlIQY53lAwMilTJ/HhP46t/+eqSb\n"
			+ "M55+G093z/vaeG4ayU2nsxynoFKHsfy9IIeoTeswHklxnJ4zROvG6J5it8OMU9+PyjpJK2pZAM1B\n"
			+ "16dX9RoA0T2Mu7meWKyOyws/63Jo8dpZNx2SrmnavT7ZXm03sy7fLE7zrfPGodVvAThdPnDZeRro\n"
			+ "chhaTbPPywyB67POMNzLivaZjm/pVb1geV9WGT9O881zRid0woqbtSefn9CZoIcdL9eMBliRQz9r\n"
			+ "RW0bQL5jCb08B886zsNfvG6IVGRcJLcD7qgFy89TelXfdtnZbzuxTnpVn+q2vF51Ypsdx8CgZaOP\n"
			+ "f/aakUpF0q+2E9DQU9OK2g6AlpNOoxW1KQB3R535dURxt7XqslyX9aq+EZjFuf+T7xliLFqdpqMD\n"
			+ "XIY/7Lg8Zs5mZxmkva7oVb0yqqjv46a4rRW1I8fypePcf+PVnpomQjMxu09+y2kH8NKl4LUO6/bh\n"
			+ "9Dn2OoCKbxbHDioJY5dkgrKCNrWLGNb5HA5lvTpRPdDpeNw6jVbUAgujUMGx6Mnq+MidJkK7FwY0\n"
			+ "2EqPp/pIeKgfw0nAn2878e2k2Gn6Nnx2gOmflAK1gviQ0Yqabf020OJMvLKD1m/Ouug0b0e90/Rc\n"
			+ "05I6xOpPmdWK2iyAs9Jz7ZsFtON7cRJCMqqFHGhxOvEzTpj4gVKdpuK0wwxbCNWr+kaPRr8X1BKG\n"
			+ "V0PYqBbT06Fq4i/fESFZiFZ3HIx0t0+67TAwg9IHzmx6WQW/OpCN6bPTTlfXq3rJ7fkIO/lx/vGH\n"
			+ "LxtmHM7heBxh7v2FGBN46cfvueo0+2EVwv2szE5DOljkdLUvqsf3XZQeW7ufr3nQv6wr81tD3rM1\n"
			+ "oK0KnsyqMi/fwyeN7yo/Ixq2+NdtIGEJRRh1zO/hh6mNcNPhcSdy9Hq/maNjiwOYgeaf/v7lvhYn\n"
			+ "lRJ44YfvijAsDgke2xonPWeIb/z0g4Ob2KO/Nd88x33f7Di9+fobvxGnvvmbhbHn2ujViZpvnTda\n"
			+ "N84brRv5KTZvfBFMHklCn44TdhxC2HEIOw6hOCa0OIQdhxB2HMKOQ9RicJqTxbNGJ5v6QWZ1QAhD\n"
			+ "/u0gY7r5MyDfYCZgT4n9bOxC4CArO+T7JMysTovjCibGZscZuQPxlsRgqAqr8/iZVR09toF4Ge6p\n"
			+ "WtKlRGVWd2p5HDZKxs/M6l50wmFhpJ3zt5FZ3TcLrmye49Zy/pPsYv2Ml51HRvXPOv18CGncpnsl\n"
			+ "Q3LbgZOWIPu0HyZb1SGlXwfy4DsWFLE46upXO1nVnXYa696jEDrblgcPyYpW1FZsftT2Do/BmdWX\n"
			+ "73naUO3Vs8beM/uGxKlQtu406De+u7j5s1Ga7dhIkN1v6CsAaCk5VGXmzY7YunHeN7M1ILfxrUEb\n"
			+ "0OwIyWHvCXv4G2Ydh2z9rSk/q/J7b7lsnImuP88H+bSHxOywc5OzsZE3Egxecrh21hCpFFJjAPYL\n"
			+ "s6Y6+6gufuVv3q+57zx1T5JjD+g8LViSQfvpi1El9e2wLcuW87yrFTVENrP62Mn38ezzV4J60ptd\n"
			+ "Oe5sN5z0q0yrPBuzs4tVdp79om2jZK0I1QF4+t8/Fn4/aVGwFAOo2biGXL/r6NOZZrpnnLIzhWdx\n"
			+ "mm+dN8zV7+BXvvuJQTvTc9UY9iB07ZW/Z52+y2IfR1LS9rI+AftxevPwl+d6JshWLau6ilNkh9/V\n"
			+ "K/fxIf9LryQMXq9ZedJxHvz8NUOkUp75YwLEbrqxaZU6n4WBhWUHdaBRO9HIHefjn0YrQXZXwzWC\n"
			+ "GnrcCFGvnJj90sCM0oncdRx5uPtvvBql+g3Wm2gtjqGEbpE3sme9hu4O6IFGW0DvbKq2z3cUi7Np\n"
			+ "22ej2DDVKY6h8lTaOpz6kJhyFcDqoGMPs5CuO45hhh0PN2mn3m5HXNhag752fOrI3Y7KC/2KhXgd\n"
			+ "/tE129y3xH5anOGdJv32rfScUYr4pMia7i0X5lCmkiUeZ6ex5wfy0yficOjy5TucXkOKncZ5w/uZ\n"
			+ "llZRneW/xTmWfifSnUampb83QAf45lTr9/TLQiQrXmkc3zOrO+40pyPfabpd+O1ew1KQibElK14N\n"
			+ "Y8MC3TzpON+5YT8C8Hjm3dA6jVbUat2RbU5qkfdLxT+omorsPBd6fFdNVeHs5dLH0Pw4//S3XzeM\n"
			+ "L08djsdJHWz/FSmB5176letO07qRNwaU+/Qks3oPC1GBi90OTo7vwktsp8N9HcBHA163m1l9UCxz\n"
			+ "w06qfluJlf74o+8agzrOS//xH1z3Xi86jsXf0l20/Y5e1Wfs3Gwvyzp71flUm2U67jgA8Me//nOj\n"
			+ "X8cRYwIv/miEWg4edBwSLLbF8Tf/7rfi9Hc+6Pv6w1+eM5pvnd9gkyYDVzkAd9eE8fmf/tUhi9Ox\n"
			+ "RJ1ALrsBXLQ4Ceo4hDAjF2HHIew4hB2HUBwTQghHKkIIDQ4hhNDgEELCwHWg+ocLufJ+QY/Orjwh\n"
			+ "DoqDdAp+APu1PoQwTBsnDFk4xHzRfK/1Z9H5us4LBRz8vP+ezueOfBdweKegsJYbES0Aley1OsM/\n"
			+ "CAkY107jDxdyRoAGBx4anAGtAQC4kl2sV9g1CKHBCcLgWGlnF+tZdhNCvIE+nMFkWLaPEO8YZxPY\n"
			+ "o2N0/NxtEcRmvH4b7KKeujcKeF07zMMCN5xSKTKl6klQW7z8NgJ2M6XQ6HizU9yL1AJD7s+On8ni\n"
			+ "qHBCVDtBGJ1RHjCtqDUATPZ5eULW1PHs2FEcbb0wQEFfX7/7GpV2psFR2OhoRa0EYN3yp/qwdKCD\n"
			+ "lElcH/4Q2QryYMOSUXp4KN+UkmuDM/HKznVFbnoBMvvU3tM0nn0enKJsLecL2cV6zcdDrHf9nrd0\n"
			+ "rEOJosI0NElTNyGoqV5Vgvxk0q9a9a4NTnrOKEfhZu2uiflnj7++Yjz5ih9fvwnbnp/RplQ9HupL\n"
			+ "Q0a19qB8l0GMlEGUQE2AsYmVMY/9lCo9Z+zXRtldE9mnn73ehBG9aABLlakKBhSGxoCSIVF8wJJs\n"
			+ "gPoYmy29qheGfC6HAWndI2lwPlzImTlrhTBXjFIHq0fmylFntUocrCilzP8LMVqR8hGMTwuA2F0T\n"
			+ "2ae755tR7IQy6XBpQIe8K+ti983NO6raCvIB04pabdgDFle66085uAf3BrVtmMYnkU7jjuFp3VAn\n"
			+ "oE+OSiWHH+v40ZZ6/A1aUSv36MRlH6+hhh6FbjlN8sz42loZG1Ya3fI3V9NuGhyXZK/VlTI6XYbD\n"
			+ "l+/QitpSxIzBdFL6o5M6NfLHoeVZhxifTL9FiMQanOZb58sQWJIhf90v38peq5fi0Nlkx+muaTNo\n"
			+ "KjGFroLPkosDPlNCl//HixJnSZneePA112GuqnZojOikvyenz7bUisUPeKQ8ThDGRmmD03zznGGj\n"
			+ "GPVsazk/C8SzwINe1WsDRjk3n+lVGH4hripBNUOqV/Vyl4Hpp976xsEMMFCZrtf6focM+gylbZQz\n"
			+ "OA9/8bqx72R2QFDRv3GT63pVX43J9ZXQFbckr/niICPs8zk10D/a28qWXcd4j8qO5T7T6Mke9/yy\n"
			+ "XtVDzQPlocExRjKaH//sNUNY92W5gEanb8dv+ThNUMLfolf1ilbU1p0oPg/bN4ceK0MD8MwIykWA\n"
			+ "suVcelUT7XC7lzIOUgkGq3B62KT7P/me0VkyJ76NspkwO1nE/CyD2rKCwTFQdtnsNyX2gTsALrlR\n"
			+ "v5Kh++4iMaW6/8ar5kUK7/rI+Km3L9DEHHkIcyGfwtkIGWenSsWW0Qt55/2lXucmVW/GxuebA/yF\n"
			+ "jh/esAzOpudS7dTbF9NzxjZIWA9rPx9RI0LGueFAeVzRq3rFL+Xl95aGfitaNo2j62j2UAyOYXgn\n"
			+ "bMZPvX0rPWeU+MgraWwiN22zLB0bCCg2JQrTUq2ozcjXR3I6RzbwbzxNQ6OysbG8pnxSqIhMjXw/\n"
			+ "h0EDhFerW5EzODQ04YxwI3T87uXZvkvADEBUx5j5dS8iY3DG0+/Q0ITfIQc6Gruckv2WZ6e7DJBt\n"
			+ "X0iEjHEWQHPEjI2xzDE0SgKuy83/nrvt9wkeO01Do7qE7/UQdEez9tvYCWDdGj8T1QdqlM2WYZxb\n"
			+ "WOc0SgKuDawJtH7jz6rnsTPv0tAMZtOHjlnC0SyDI432lvcX7BiyqObD6XI2K2F4BgwW9cgpHGl0\n"
			+ "BNaE0frty56d0PHse4kzNB46AtteTY96fbeXqQy6pl8N9NkC0NU2yicX62d4FDE2gaej6MZ1mRgr\n"
			+ "u2tipv27s7c7ybb6JuCSibrMci7W0jLAcy/9KhRDcyg9hYsu4fVWCrfGx06H1oraNoC8za+87mfu\n"
			+ "nAHnODB/b1j5mYk3be+JwbEYHuOTxnddGRyZDbD94o/eyybZ4IQ0AirruJXnGdjITIPjr+Hx1OBY\n"
			+ "DM/27h8m84Yx7tTg7L//hb96R9DgEBIvfFkWT88ZU+kD41Mz9lLTn3/0XfMP/TaVd/39UD4cgesT\n"
			+ "194u83YREm18UTg2FFABo62yeObv2V0TIzVAes6gwiFEZYNDCEkmKTYBIYQGhxBCg0MIIW6hD4cQ\n"
			+ "QoVDCKHBIYQQGhxCCA0OIYTQ4BBCaHAIITQ4hBBCg0MIiRCu0lN8uJDLASgdZPfr/F++wZL/BuIg\n"
			+ "74SQvx/kwsHRvDiHfhYAUMD+j9bvxUGOHVj+1vnZwuFfRQ1AJXut3uDtJyRYXEUaN1dOGLu//wYC\n"
			+ "Mjjw2OD0uqSb2Wv1eXYHQmhwgjA4+y8xgx8h/kEfThet5bzRWs5zgxkhNDjBGh62AiE0OEGrnRJb\n"
			+ "ghAanKBYby3nK2wGQkaHTmObLwG4kF2s+1b1UStqBfhQvlcyIWt99zu2stPHqNYaD4JehQ1Vby8q\n"
			+ "HPvc9fnBqvn49U2tqBnSqPXiosIPlaEVtfkYGAfD8q/g0dfmo9YONDgO8NuRLEenKz4eYlN2+FK3\n"
			+ "sQvg2KOwErYK04raqoeGYnPU64lqhVAaHOdGZ9vP79ereiWAh3+918MT0LHdcjnk41+1GOyKV6rH\n"
			+ "y89FYfo5ThOipoyVtb4rfnXoQVM4N8eO8kPgglmtqM2GcW1aUZvq89JZKpz4qpxPouAzGDJ1I9Hk\n"
			+ "bp972qDBiS+naWwOHa+fGrrIruL/fY3SAMIplXuVk80u1ltBdrBhHUsralkAzT4v1/WqPuXXFMPp\n"
			+ "tI047gurbgYYl9N53wwYFY57mj53sHKvjqUVtVqf95cGnNMVH40NCYarQSopv1bBXCmcYye/vD7x\n"
			+ "yo4KN6EAYApABgCePvo2jCfZWPQuvaqXtaK21OOlaa2oGdZRSE5pZvt81dmQ5vd12gj/p8h+H9dr\n"
			+ "tePK4KTnjLLKN2h3TVQAzD759FzUjY7o19nk3xcAlDsGN4y5fT+pT0XlWfu2Rrm3LmKHpgB0Ru1V\n"
			+ "JRSO6qTnjBKAkjQ+xtPd6BoeaXSOhLBLVryeh3s1mrr8ni29qhdArPQaTBYc9J+aw+PV/LyY2Ptw\n"
			+ "0nOGyF57W4w9dy/KRmcKwIQTIxXRS532MrAurlMpvaqv2vjslIrRyIlxGp/+i0/FePodT7+ztZwP\n"
			+ "bDTWq3rLjiGJSYzNbNINzyhL4PKzdzs/d29locEJUO2Mp9/2rvHGHwTup7CxNB6nxGGz1DmHGKpy\n"
			+ "+9z/dVX6hduqDYaZDkJApCxpIlIH6SiEfO0gfcVBaomv/u37oY3C6TlDfPqfThvPvng5ylOsQX4d\n"
			+ "z1cXAnI+1wBM06YcusfzOPDTXR6UYqTLKDUHGKMJm99DhePl9CoGHXIKfTZZcutCbIzOql7Vhfy3\n"
			+ "4dHUuxmm2klspPF4+u2dp7vnJxWas5ddfvQmDoLCbgJoDfiump/Rv3068kVGHDtux77qFcB1vaoP\n"
			+ "7Ss9FJKvKpgGZ/jUKte6oUaidA9HnGHRqEtaUQO4/KyysTFs3MNVO9MiuZq1OiSWqx5kzFSytzaI\n"
			+ "PWXm6wEfcnrQNgkSiqHJOhh4HE2LZP/qtzUgH+QUK9EGZ/zkr6sKzddFWIaHj7sSqqbp5nN2p+J6\n"
			+ "Vc8N6l9B9QPlp1TNt84bB0nQD7dX9tpoVTLT/+7L/7V1I19U6Xo7ncJGSHq/hOsXHX6mzUfefxUq\n"
			+ "fSplmPv/OjQ8eNCX5J67CZvTrF7bZRbsBBPG2uA03zy3CiEG+iRkjuE72cX6TAw7eG3I6Ob4c70+\n"
			+ "o1f1LM1JYPe0LO9DBWaM0bTNwacMYMnGNAuqB4cqaXAevnluVdjfjn+ptZyvZRfrBXbpgQaqlYBr\n"
			+ "7DzIgM3VnIDPbwPAJacGQV5HWStqOQD3bEzPgJDjbSJjcB7+8vXSMGXTyxdBkzKUTMyNTQPAZNdU\n"
			+ "o6DCapzdadMw5SHTjAib39mUivaKzFFNg9PNg1+8XhIC624+21rOG9nFOgPeAvRLKMakSgORHTUy\n"
			+ "yn2wTLeGGZ51raitq3K/lTE4D372WgkpsU4zEN4IS4Jtay8MgAPDY33PLb2qlxJrcD7+u9dcKxvi\n"
			+ "musBHacV4PV0O1YDqa81JDI4EGVpMTyNPmrPyqxW1Dq+rpt6VQ+ssmnoBuf+T75XElQ2fvs2enXQ\n"
			+ "ckDTtu2AjlOW2Qc78Sy+Ok1tPthWAonu1qt6Tp5fBfZ221/VilrHZ7rT+XwsDc79n7xaAmhsQvBt\n"
			+ "+OWzCBVpYISP1zdKFrewgiyvALZnD5Nd5+i5+gnN4Nx/49USOI0K4iHsSO0ZALf9kvQANuLWdk6n\n"
			+ "Sn3aPWz/2TqAO3pVn3FxLlb144lKC8Xg3H/jFSqb4A3Phl+jvyQf9TYaxcB01IRKS9AWLll3h8so\n"
			+ "9s1RVJrbQSssheO5sRk/9fZNmhUygrFxq0R893t4xAXL4FPDQTzPKgKseRWT9BR7SM8Z83xsQntY\n"
			+ "Z4Z18ihMPf1Y0najBIIs6St9NPNOjM8o5xEDg7OH7OI7DPgLl9t9OuZ2lC5iSOrWetxrbXUZn57T\n"
			+ "rlGNXqQNjhCPkVl4n8YmXHWTjdlDN2V52C5EzWh62A770y55n8tehFJE1uCIFI2NIjSDkv9hPWzE\n"
			+ "u7itSBocGhtl1I0x7LVRDY/cgFlT4Fp7TjFUaW8PCCQw0ZXBGTv5OZ49OhWStdmjsfHZj2Gz8287\n"
			+ "eUhs7IQusPVDZTqIxOquUoweTz8KzdjQQayEsnEcryLTYXITaQRUq5/3yZXBee6FXRqbZE+jBhmb\n"
			+ "LRoe4umUCsBl9FkK9c/YvEtjo4axsTUdkxkGM6NOtRSaatZg05EsN3bO2y1eZ7ed45C/yJXBSc8Z\n"
			+ "G83FszQ2NDR9H4ZOruRhn42a4XHQTre1onZREYd36HlwRppSAcD4yc8DMTYT12hsQuyoNRvG5uYg\n"
			+ "Y2G3/I2cajViZpQ3w45T6jqv2bDb2fWy+Onv/HO7+d/P+pcnV+xh4tp7NDYhGRrYSM/pRJXIKN4c\n"
			+ "Bqd46KRHUC4Bug0m0DsmqYmQYnoGDBahlbh2rXDSc4Z/llvsYeIHNDZDfAS+dFDZSYcZm7bLPLwN\n"
			+ "+bmtIW9dkueSi8o9kbl4LrqdkvpwL1teDBTKKBwAmPiX99D6rce+HLGHF37wDyJhBmQeQBnAKoBa\n"
			+ "v3m/jeCzBZfHXnGiVDx4OAs2H8R7dmstKWJ0alpRu4UemfaCiHHpMjYZ1YwNAAjDGM34/uEvXzYr\n"
			+ "YwoBkRKAMAAICCEgUqaYFEKYr3feJyBfMP8vUvJvYwZe/KtgjU3rRv6gARweOTX+YOHM9/+wOmLn\n"
			+ "GGZE4LUxsCbjCtLQuJD+Sj0sDq6nO07JkfN41FWqfvdXhfYb2eDsrolW+4OzmZENTmoPL/7oV4E3\n"
			+ "yCgGR6S+uJWZ/3XJoynSqPPqoekgXUr7QAqq2awu6bfhq3n4dWkAbgPW+k1ptxx+T87Sr7bcXoiX\n"
			+ "UeAjGxxpdIz27152b3DGDLz041+FYn1VMDgeGJ7LdmI+gi5h4rXa8fucGJA4EE8SjXlicADgwS8y\n"
			+ "xuPWV1wrnJf++r3EGxw7c/AuzspqjF49VKHHafQ7zyAMIA2O/wORZwYHAO7/5CvGk8/PuPbhvPjj\n"
			+ "9wQNTiAPcwmWNK+q+kY6hjdAZysNznDu6FV9RgmDAwDNG6eNRw++5s5pnBJ48YfvChocQuJJyusv\n"
			+ "nLj2qTgz+YHrzz/85evGwzfPrfLWEEKDY4v0nCFO/9lvkRp/4vYrrjbfPEd5S0jM8C3jX3rOEGmY\n"
			+ "K1iff/QyDMP5oZpvnTcAYOIHbzPqmBAaHGeGx9hL4dH9f+H4O1o3zku1I7ay1+oF3jZCoonnTmM7\n"
			+ "7K6JCuwVWu/HxfScUfPoXAwVzoMQGhxCCPGQFJuAEEKDQwihwSGEEBocQggNDiGE0OAQQmhwCCE0\n"
			+ "OIQQMjIM/COEEEIIZ1SEEEIIIRQ4hBBCCCEUOIQQQgghFDiEEEIIIRQ4hBBCCKHAIYQQQgihwCGE\n"
			+ "EEIIocAhhBBCCPGQ8SAP1lw5Yez+/hvmL0LI/3d+FQdvFOZ/hLXat3x9/22H3m8cfNH+y8aBfpPf\n"
			+ "c/QYnePgyLG7D2H9RYgjX9Lze4+833LNwvoWIbo+1vW+HufQ67ii3wv92QJQzl6r1/goEEIIiROB\n"
			+ "ZjKmwFFO4Az6vovZRQofQggh0WScTUD6sNlazlt/p+AhhBBCgUNiLXiuZxfrZTYJIYQQVeESFZeo\n"
			+ "MOLHJrKL9RYfJUIIISrBXVRkZN3aWs4breV8iU1BCCFEFejBoQcHXn4MwJXsYr0S9QdDK2o5ABUA\n"
			+ "04qf6k29qs97dM0FAJs0i7ZZ0Kv6KpuBjPDMlQEsdf25DaCkV/UNthAFDgWOWgKnQ2SXrrSiVouA\n"
			+ "sBnEWb2qN1xctwHiur/rVZ1LtWo8vyUA65Y/XdSrek2xc5wBcNvOe/WqLnhXKXAocNQSOACwk12s\n"
			+ "52JkKKOKIwMfo+sOgx29qufYDKE+t4aXz4MP59cCkLH59rZe1bO8qxQ4FDjqCRwAQHaxHosZSFwG\n"
			+ "fqczQgoe/9s45uIi0KU8J57IIO+TVtSyAJoOPnKZy1QUOBQ4igscCXdbqSO4lF1O0YraFIC7FBOx\n"
			+ "9Z4APnu5VBQ4Tpe92ae9gXlwSGD6trWcp8jxxlhuA8i7+Kir2JyAobiJP5NaUTOScu8cxrbd0av6\n"
			+ "DLsIBQ6JoMiBH76h5AgbJ2v3kRMBcueaE+rsFUTh/mw7kFjCQHUKHBJlWst5Iy4xOdKIrQK4ap2B\n"
			+ "wdzi2fLwGG7WkaMYnHjPoXCb4hNFFLULbp7ZplbUVLuULb2qFyhwCLEtcs791+ziO/8mpgbsUpeh\n"
			+ "uqBX9W0X3+84FkVyS6/qpQi2Z87hR27ySYo0WzEVNk4DiVVnusvWRWqXoJICZ+z5XQCprpja/kHG\n"
			+ "/WNvBwQyW95zNMi4x8/oE2Qseh+y10rMoRhn+YuxdxyGcSxhti31ryNuxJzMaO5axM7QGBitqM0D\n"
			+ "WHFxWq6ElEI49d7MgxC17ILb2LgoMdkleK7oVb1CgQNgYuGxmOBzYIvdNTEFoITO8oeRwrPH38Te\n"
			+ "k3i0YHvl1f83s/Cr/ymK5y5zaAitqDUATDoZxDtipzsuZgTjGPl1eznrdcJFWgiiWB9OapLMMsyM\n"
			+ "7xQ4xD7pOWMbwLz810sAbQC4tPflC3j2+FuRuz7DOB75QarjqnXjlh7VIMZsB0rT4bXXaCGIIsLG\n"
			+ "kceVu/4ocIg9ATTTJXjKAJaeff4vYeydYAMFK3RakGuSPifFqwcdWKvizDSEc4p0oCVRoh8yIzEF\n"
			+ "DhlB8JRhuguxuyZmANx+unuODRO82KlAumzdbuvugdLr3AmgO9AykoHcxDNhk4OzmDHP4uP6LWXT\n"
			+ "M0SBkySxs9HxKOyuCePpZ68DRkq58/zk7789f+b7f4htNebOjG3EKt1tihvlmNWK2qz8mRXFk8c9\n"
			+ "BzZgZOFhJwuyRYDTU0SBkyixcyB0ds+zQcIROjUcLGE5XV7JWD6jem2a6zG5ZSXYDx7nYJI8LmB4\n"
			+ "CoebXuz0k3m2ph18xGov6knPFRWowPlwIdcpCmWpN4XDtaesNaf2azcd1JrarzEljINt39bvsny/\n"
			+ "OPzaxa/8zfu1JAud3TUx//SzV1eQuG3pSomdjtCpAJh1MfBuKHxt5TjcI+lxsytwCuzViXuGtxFQ\n"
			+ "RnYpkuZlv3S60zJvETs3k5hagR6cZImc1d01UXn2+Xebxt4pNki4RrIEoGQjod9N5nwhhFi9MS7i\n"
			+ "+65qRa2TcT0xy6oUOMkTOS0AorX8PYOenCMz9xqcuYODwGqY3BK5XUAO78VFbh0nPvfHUZP4eTpR\n"
			+ "scbZuFj2XtGK2koSnh0KnIQyfupXV57unl9nSxwirvEU3buAuO3Zw7ZlE8RW1HTXmfNiouJ5tXDL\n"
			+ "sncODjOCA9h0kmmdAodEgvScUfnk77++vvfka2yMA0NhdQG7MRZRFTxcBiPEe3z/pb8AACAASURB\n"
			+ "VFHTi0uWZ8/Tuk5SnHTEjtNK5oAl0zpiUtmcAscjmjfO54SZ/0TO6HrGoG0BmM9eqytRMyh14k8X\n"
			+ "9558bZN3b7CxSIDguYo+GbMJccgETDs4yBu6rYigrstnuwFnJVe8oruuk2ceFLnbsiN2ygCWHHy8\n"
			+ "HQdxQ4EziqB56/zhAc9eTP00gLutG3nrZy5mF+u1MK4hPWfU9s+FOBI8I8wQC3CQE8dtHg2H6/JX\n"
			+ "eIeJR89JC8BMyOcghjwbFZg7GPMeZMW+Jf8/68GpWz0onnl35O7Gsrz22sEkHHUApYgX6aXA8VTY\n"
			+ "vHnOfDiEZ7sEN1vLeQCoZxfrU2xh4oGIcjTAMJEgifnzUPFIgAD949dKXc/f7RGPM+lH3FzSYu8o\n"
			+ "cGzy8JfnShBY9zH5Qb61nDcAXM4u1jfY4mQEbBtXpnhXdlAe5llgxtr+bdeAd0tOjj0p1uUheT5Z\n"
			+ "AA2MVralO26uDWAqbkHBFDhBC5tfvF6CwHpAeZ0A4HZrOb+VXawX2PrEhXF3snbOpaloihtAZqxN\n"
			+ "ukB1EV8yDM+z/8plu2zXeVcwmlcpg8NLWgB3R1Lg2OXBz18rQYj1kKzHdGs5X8ou1iu8E8Shsbc7\n"
			+ "S9xRfGkqm+B76OT9paQsMfq0wymUwqmdRJ/W+whg1LQd0z3EcR1AIS5BwxQ4I/Lxz14rCWAd4c+L\n"
			+ "1iGrUhNiw/jnnMxkvdye6hOJjH7Xq3pZK2pO7mMlpn25Bn92Nl1Rsc3kOVW62mAboy1rdZ6jZpen\n"
			+ "BwCux6W0SsQEzkHdqUCFzU+/V4IQKggbQtwQaIVjxQaHWsyuR9hYwgjF8+CDkNnwUcxGNk5FnnP3\n"
			+ "slYN3iWWXOojpG8BmOc28Zhw/yffKwFYFxQ2JLoDhZOtrhNssUgMcCVYljAi3j9LGH35xS5bXb9X\n"
			+ "engvooz1+rbh/ZLdLIDZPm12C0A5SoIxvgJniCPo/huvBh08TIhfXIGZ52KYS/9iFGZmTuNQiBL3\n"
			+ "bF72wUxAh9wPqO0S+EkqnTHdY+JSg38esUHiR0kBlDgPzv03Xg1yNuGa1PifPqDZJDZn+xUMiNeS\n"
			+ "M+hshJZynOyKuc4eEIiAKUgBE4aASHSgrE2aVrHTaSu5RX0joPs2TAAFvjyeJIFTuv/GK5uR8NiI\n"
			+ "Jzjz/Y/+nM8s8VAARWUgdZqksMw77Pk98Lse0yAiH1ukiNgR8vloASj0uMfzAFZC6FvbXm/Dp8A5\n"
			+ "UJfKkxr/E858/yOum5Gk4iQD7BabyxfKAQicNswyASMnNQ3KK+C0rIPKwfx6VV8FsBqkuA2jPbhN\n"
			+ "XCHGT729lZ4zCmwJklDPgdMBhM+KPwNRCweFGlsYLa6mDXNXToUtG4l7P48ehXdH9PiEtiU9MQLH\n"
			+ "MAAVd0oJ8RhjJ39dT88ZrENFkixunMZXXGCrBTLgZeX9qWCwF/ymIhXCiT/9oKfHR/aNvl6fsL1Y\n"
			+ "9OCEJWxSjzF28te30nNGia1BEi5unFZ0vhnnCsiKDnAlxGTbOvG8b/T0+qhAircneGEznn77Vmbh\n"
			+ "fUFxQyhuHIsbALgqCyqqcg0sekmIgtCDE6CwoceGkH1RMGpsx2SXONoJsfzEFMz8IwT7W8o32Q6u\n"
			+ "xLtKXIx6lvBABc6xzCd40j6TMGWzh/FT71LYkEji9Rq6VtS24U8ism7B47qyMoOXCQEAbFpy2tzR\n"
			+ "q/pM1C4gUIHz/IufJkfgUNgQYhU2o3psnNJdWZn5VQhxzyX5PO1EoFBvOAJn7PjTOwAuxV/YvEdh\n"
			+ "QyhqzJILS24/3+09knE3bitMz2pFzboL6DqTBPpGC/HMUeQ0G3CvNqhF9Z7KnVTRGo4NI9hlwvs/\n"
			+ "zRhfPHhBZlkQ5tbt/Z+Nrr+Lzll23mS+BylAGBD7r1s+g4PPWb/74M8Wm9n9mhCAsPxZCMtbLK9Z\n"
			+ "jmEVNsfS0RM2rRv53h0ggM19qfEHC2e+/4dVJAin8QlRq/w9qqixe82yEvU9D0/9Ytyqksf8ebkS\n"
			+ "dG6dKCT6k+0F9mWTwIOMn3/pk50vHrwwGZsWjKiwIcRDo9qAe89KB0eub1nQT3gorKzxBm0AOdY+\n"
			+ "CqUvlWCvVuC6VtTWAVxgyoCj4qurHtRWUuPKAhc46TkjZ/znlNH6IOIah8KGuCPyCR21olaDd8X7\n"
			+ "znpRfVguN5Ut5zhKzE8GQNMySGwx8DgwNuCsGPJdeZ8mkihIbXqVDsWjRc0rHCmBAwBizLhw8isP\n"
			+ "7n5+/6VoCpvT/0BhQ9yyEqWTlUtB2/A2QPiyFzWIhgierOUaRi0s2B2wfIWlB3y7by0AQitqUwDu\n"
			+ "OvhoUytqiRm8XQr4epCFLpUYroOOwemwuybKn330wtKTTzPRiMERBo6fiZ+wYQxOYAapAefLOIHu\n"
			+ "WJAJ6zbgnXfGijIxLh7v6GpbxRTx/F6V4Myj49s9USEGh8LGGaEl+kvPGWWsCXxx7NnSF80XFJaA\n"
			+ "ezie+RU9NvE3pMol5fJT3GhFbQbOKnc7RdntpF3enTJGi93JdPUd7s7y9l5VAFRs1MKyEsuaWC5s\n"
			+ "VOLFd2genA67a6Kw92R885OdP1PLg5Paw4ns+7EXNvTgKCtwPIkpkDPgVfifgybygbk+7MxKVLxD\n"
			+ "QPeo24OxA2AqiH6nyi4qGzsx6VVUReBYhI7R/uBs6AJHpPZwYuL9xHhswhQ4IvXFrcz8r5VrZ492\n"
			+ "BbnFk4R0AQi22AfeerGUFWWBE4NSAyR4lEq3oIzAkSJn+9nj4/ndf/x2aALnpb9+L1EzLgqcoUY+\n"
			+ "C6DhswfElyy7LuMXImG4QugHG3CQpDQOnhsKHBJ1m6GUwLEIHePR/Zfw5LNM4AJHLlG1X/zxe4lw\n"
			+ "8VHgeDIQDPNkbIe9dOOgBlQbQIG5RQa2Zd9dWXFakqLAIR4RWpCzkgLniND5/AxC2kXVfvGH78Za\n"
			+ "6FDgJHKArsHcKXVTr+rzbBFCgUN8ItQacEoLHKvQMfZS+PTDs2GWajj7wl+906DAocAhhBCiPuNR\n"
			+ "OMn0nGFKjDUxD2Dl6aNTePTx1+192PBssL738M1zEAAm/vId7owghBBCKHA8EzqrMLe8YlyKHWMv\n"
			+ "hc//NAljL7hLab55zrAU21yY+MHbq+xKhBBCiDpEYonKDrtrogaZgfVx82t4+kWm95LVsCUqWJa2\n"
			+ "HFUT33+tDqCQvfZ2JPKBcImKEEJIHBmPy4Wk54zC/s8HomcVwNXO3/eenMDTL7J49kUGMFJ+nUoe\n"
			+ "QLN1o+eGlS2YqfA3stfqDXY/QgghxKdJdFw8OKOwuyY64igHM+dJGBRsvq8m/99IzxkUSYQQQggF\n"
			+ "DiGEEEKSQIpNQAghhBAKHEIIIYQQChxCCCGEEAocQgghhBAKHEIIIYQQChxCCCGEUOAQQgghhFDg\n"
			+ "EEIIIYSECBP9EUIIISRW0HtDCCGEEIobQgghhBCKG0IIIYQQihtCCCGEEIobQgghhFDcEEIIIYRQ\n"
			+ "3BBCCCGEUNwQQgghhFDcEEIIIYRQ3BBCCCGE4oYQQgghhOKGEEIIIYTihhBCCCGE4oYQQgghhOKG\n"
			+ "EEIIIRQ3hBBCCCEUN4QQQgghCjAe5ME+XMiVAQBi/z8H/xOHfwcEhDBgfb8Qli/bf7+Brg8CwoDo\n"
			+ "6Lb91/sdw/qdBy/2PFb338335uS/Q9975P2WY1svv/N30f15ceSqug9+6DREvxeAmvyllr1Wr7HL\n"
			+ "E0IIiTvCMIwgxY0RQ3HT41elxM0grmev1ct8DAghhFDcUNzERdxYqQOYyV6rN/hYEEIIiTKMuSEd\n"
			+ "8gDutW7kjdaNfIXNQQghhOKGxInZ1nLeaC3nG2wKQgghFDckTkxKkbPNpiCEEEJxQ+JEXoqcMpuC\n"
			+ "EEIIxQ2JE0ut5bzBZiCEEEJxQ2KF9OKU2BKEEEIobkicWGcsDiGEEIobEjfyreV8i81ACCGE4obE\n"
			+ "iQzjcAghhFDckNhBgUMIIUQVxtkExEuBk12sizhci1bU5gGsKH6abQAlvapveHTNDQCT7Mn22l6v\n"
			+ "6lk2AxnhecsCaADIdL10S6/qJbbQaLC2FGtLweuPRl3gaEUtil6o63pVL49wzdswS3AQZ1zQqzoD\n"
			+ "64kbYdMc8jaKnBHgshTxHO6iCoUlragZWlGruNWkbEJX3NWK2gabQSnh0JLPgqEVtZqip9m08Z5Z\n"
			+ "rahN8Y5S3BB1yLeW8/MRPv+tCJ/7rBuRo1f1HIAddl1XXIqoty+OwqaEw8s806qJHIdieIZ31R1c\n"
			+ "luKyFLz+qIWJ7GI9slvFYxKDsqVX9UICrzssLupVvcZmCO2ZLQNY8vJ58Pj8cgDuObGhelVnug0X\n"
			+ "0HND/KQZ5ZPXq3pOr+oi4h6Nzsy1kbDrDotNGYyeVHExoxW1mlbUVhV/HiohHd+JsLlDYTPC/Jye\n"
			+ "m25vBT03o360i1vZxXopJoY7Dh6NK3pVryTwuoMkVO9AiM9HCcB61593AEwFNUjb8NxYRbwIuH0c\n"
			+ "PUdBn1/coOeG+M1sXC7E4tFoR/gy1ke4bnpyhrOTRGEj6TWJmQTQlN4SpdolyPPRitqMwwnCBB+l\n"
			+ "0WCeG+I7reV8O7tYz8RI5CixsyjoIFYZdKzaNZ3Vq3qDT1kk2NSKGgBc9io3U4S47eC917kcNTr0\n"
			+ "3JAgONNaznOrcfjCph03VzeFTewH+jg8qy2Hz2iZXWR06LkJAQMCAonbOfp7AGd490c2lHaSf/Wi\n"
			+ "rlf1KcWvzen5tdkjiOJ9ehVHMxAPEuucBHpEpDw3TCQRaU7Te+PJ4O9G2NxRXdhInM5Y59kriOIT\n"
			+ "kasOPnKRrZZQcUMiz9tsAteGsgDgrouP3tSrelQSgV1y8manu74ICRgnE5E68yNR3JDo8h02gSth\n"
			+ "UwKw6eKjV/SqTu8GIcE/s46ESkQ8q5GCMTckUFrL+VJ2sR6LGbdcJqrgoOBkG8C8lx4FmWzMzXb6\n"
			+ "SBV0lJlbnXCHTxNR2C5MO/yMilEXntuzIImn58Zg7iOFWY/DRcgdEHdxuJJ2BsC6zOkx5cExtl0K\n"
			+ "m4kIVqouO3w/PVJEVe7G5Dqs9qxEcUNI/GdmDQzfAXFXipNRxFPe6ef0qi4imiNj1uF1NtgTiaKT\n"
			+ "nlhOSqMmcihuSOC0lvOFiF+C3UyjeWkQci4MpOOkhwlK184t4MQLPPVu9qhITpETIsrF3IjUHlIn\n"
			+ "PgeQOlrHyVpDSfSoAYWu91v+Z75XHHnP0dpSPX7GgNpSPT9z9KS6P9f5fe/ZqQTalKf/J4DXE3TB\n"
			+ "97SiZqve0AjJ+SK7zV5umXUCl6TIyPjg4VxPUPOta0VtXeUJVaDiZuKVnet8pPbJyX9Ad/CZkcKz\n"
			+ "L1/A3pMJYO9EDC99/LWIX8AFOF9Xn5bCZaKfUXUpbOox2GlRdjgoVWg+iGIC3UjodZdVzagcqLhJ\n"
			+ "zxllPgb22F0TpbETH5c6wmfvyRk8e/wdwOBKogIzvm2tqF2Eu+3ZTa2o3bRu0R4h6/CdCOWwGcRV\n"
			+ "9ioS4QF+NcGXr+y1cyu4oqTnjArMbcYdsTOTOvbeKoDJvSdn8OyLSTZSuAKnBkC4jI+5qhW1kl7V\n"
			+ "s3JXldvkfElcnuEWcKKSsHGahdjToqHy+H57bgs9/lZTPekgxU10xM4GgI0DofPObQB4uvsKDByL\n"
			+ "3PW0V179XzILv/ovMRA5WTlzc+p9yIzgyr4Sl6UZxtuQiOM0C7Gn1dDlErffIqMWxRtDcRNdoSN2\n"
			+ "10R2PP3+NoDJp5+9Fq0lq9SX/xuA/xKH+6FX9XkpcO4FcLjAkvPJkg+bijX3Pa2oBXWsi0yJTwY8\n"
			+ "H9sO7QSzEAc5xLAJIi1yWuk5IwdgYvzUe+2x5+5F5+T3jv0PcboXelVvyJ0Dfm5TjmJyviizKbe9\n"
			+ "FtgUpIfwd5KHaoKtFiz03MRE5ADI7q6Jwnj6nc0oeHEM48TX4ngv5DLVBhwWgbTxvUy7Ha7IAYCz\n"
			+ "TB5IOn3CwXtverntXHqM8rQLg6HnJl4ip5aeM8T4qffaqWMP2CDhCZwZABcpbGLHPTdJGUm8cJqF\n"
			+ "2KvAf62oTck4vbzlb4ZW1BiHRnGTGJGTTZ34463UiT+wMcITODWM7opuU9goLXKybIrECZsSHOyO\n"
			+ "9Or5lVXG++2qXIlx2QeKG3JE4JRSxx5eGXv+N2yM8AROa8Q4nAzjPZSmySZIHE6yEF/xQNRkpbdm\n"
			+ "WJXxDOPDKG6SJHAqYuzRFXpwQhc5WbjPz7KpFbUKW5EQJbCbZX/Ho3QNTgX05igFe+MEA4oTIHB2\n"
			+ "10TBeDIxa+ydYoOEJ3BmpEvbTf2ZWa2ozSheP2oLEc2H0YMl9ljS5zkuyxiXzJD35UI8zbz09iQ6\n"
			+ "AD4wcfPhQq4AYHO/YqSwFLIUAkIYlp+x/zOEgYMimAYEUvJv1s8f/vlQQUz5w1f/9v3Exi6k54zS\n"
			+ "7pooPN09z7TG4RrGilw7d7NnP6MVNUPhGJyaqjVmnKIVNYobMug5zsp4qxqObgff8VLY6FVdjLD7\n"
			+ "8p5W1OJSokVdcZP+s3/a3P39N/hkhCdwcrv/17jx9LPX2BjhGsYGzLINbrITn2ULEqLEc9yC/2UP\n"
			+ "OseaGaFMy6VhBXvjCmNukoR4dlakPmM7qGEcnQQa39GrumCOFUISay+2pc3YcfkVTa2olSluSCxJ\n"
			+ "zxmNsZMf7LAllDFYWRvGaiKpbmVCyBGbkQNw2eXHl5K0ZZwBxckTOLn2yp8bDC7ujQz6zQV4yAp6\n"
			+ "B7C2AawCmHdZS6kBMw6mEdH7YHvZjrmASAD90e2yUBtAzsslIVl80+3Sdqdg72Wvi3hS3JDQGTv5\n"
			+ "wQ6Di0cbUAMgAw927UhhxAKQhAQvbDrPcRP7u2K8QwYbrwK46uLjt7WithPyri5f4bJUMmF12qMG\n"
			+ "rBzjy2MBSELc2YWNEYRN9/d4jizt4DYT+qS0C7EcD6Ilbgx6n70gPWe0Usf+xIY4bCTKCbhMihxC\n"
			+ "7ImRTmZgrwrgXvKrZIclE/qWy6+4K1NUUNy44djJL/nEqHTjT/zpDlvhiJEQAG5R5BCSaGGzCv9K\n"
			+ "azT9EhJ6VS8AuODy49Nxq5fGZankwkqyvQ1EKWkih3edkEPemqs+H2rar8mFZcu423p2TSnuKG5I\n"
			+ "NEnPGQ22AkWONOpl3nHiAdsRfgZqCL4Q6qZfW7NlmokFlx+/GofOyN1SHtG6cX4ewIr5W9/YoOvZ\n"
			+ "a3VlBhKR+gzcEj5c5AAoyeKVs3HtvrzTxINnZV4rag0Aw/Iy+Zm3yZHAGqHem1d0tmZvyWUlL+/H\n"
			+ "KoBVF97ZK3HojxQ3I9B863wWQAMCGZuhzkutG/klAG0I5LKL9VAHFTG2S3HjXORMARhlXXrTwXsX\n"
			+ "RpgNbzq4tlXeYeLlgBri8Te0onYRQEH+68f/rtiS7LQ8n+teb26QW8aHTc62AMzrVT02FcUpbtwL\n"
			+ "mxqAabdqHUCztZzfyS7Wc+GJm0d1PDlS+I0MNhQjPfwOE/Jtu8lPE6egQEJcPKM19KlQrxW1HMzC\n"
			+ "tf/No8NddDhhGToBloVbr+hVveLl5ExWM7cuvV2P8y5Riht3wsYrxT/ZWs4bACbC8OIYe8e2AYqb\n"
			+ "GOJk5sxdc6OJ1ak4zXZjfJ86osYrrIkxhZxQbAPwKjnqulbU1uFhAk6ZJTkx+VQobpwKmzfPGRCe\n"
			+ "949mazkfvMAxxj7iHY0lTmKDuGtuNOglS66o6RYOOXnMGtx79bvZlN5eTz05FDfkqLDx8euDV9XH\n"
			+ "KG4SDiuNKzsoZ9F7947ntYpi2n4FeLtcZFtcdAKDPd6E0PHkUOTYhFvBbfLQX2EDAJBLVISMYtSd\n"
			+ "GL46W0zJe1hC/23JGZi5SFhCpU/bycBcr4TNFb2qCzeCwpJO4rqHl7guc+RQ4AyBnhs7wuaX54yg\n"
			+ "fCqt5Xwlu1gvsdWJS5zMFAtsLiWxszX5LhIUP2FT1HuZqsEzD4kM2i17vO18VitqswB2AEzRk0dx\n"
			+ "40LYvG4EbENmAVDcEDcG3lH8Bw2ikvew4eC9Na9zo0SsrXIwg3gzKoqaHs9bBUDF4yWzSZiePAC4\n"
			+ "rFf1DT5FFDdDefCL1w0RwtyI3hviEieG7RabS0mc7LaZTmIDyYzaSx5/rWe7kmyInBoOdlg1PBRn\n"
			+ "t6XIuaNX9ZmkP0gUN/2Ezc9f82NXlF3ovSFusD3YyaSEZHS4WyoYQZODmbtm0uOvvhDWVn7pOc3K\n"
			+ "62t4eG2XLAkKExuATHHTT9gkgNSJf9zee/Iib3g8jP8MWyEUpuDMY0ac9esKvC970oYZp9JQ5Tr1\n"
			+ "qp6T11uDtx65zi6rNoBCknIyUdx08fHPXjOEAmF6reX8fHaxzrT4xC63Hbz3MptLWW45GMyvx7EB\n"
			+ "fFp2AiIQfOvTNnLAXPq6K5etdqTQacT5QaK4sQqbv3vNUGf/gfFvEWKNFhKpwcBpIPGG4tdTSOq9\n"
			+ "lGnyZ22+txyjPmwpPOw5W1ELvLbUsivB+8KekwDuWYTOTBw9OhQ3HWHz0++FGWPTA/E/8q4Qmzgx\n"
			+ "TFEot5DoOBZZ6NAY9h4KmqFEvnaSTzusuoVOx6PThlk8s0JxEydhQ0h0sR2IGJFdFE4S1MUyEaEU\n"
			+ "OGUcXZ5ZiHIVd62orQK46vNhYrcl2rLDKgdvy0lYyeAgRgcAbupVPbLlWRIvbu7/5HuGYCosEt3B\n"
			+ "oubg7e2IXFbBwXsbcb23neRvEe+fOZjL65cCOFwdQAvAvPQKxZUtmDvHSvB+95iVq1pR6wjRHQDl\n"
			+ "KHl1Ei1u7v/kVUPVJJ9CPP6YQzexgZOdFVMxvCZW5FZP0JSkoMkEcDhrAHY+gc/9BMzden7nPJrE\n"
			+ "Ya9OXYodZT1kiRU3prBRmNTj92gmiQ3Oytn90CDUmO6OCNu4FihmAvXOdNjP32I3ADumNGEm7RM+\n"
			+ "BR/3I4+DpIEdsbOqkmcnkeLm/huvGqpXZUkde/A3HLeJTcFSkv86O6fKOBrXcCWm10/PTfBipl8f\n"
			+ "85s6zC3MLBtymE7Svgm9qlfk/akhWE9WHoc9OwBwUwqeUCZViRM39994NRLBw6f/wyf/jc8scTHY\n"
			+ "twDMy3+dWXVk1sqTvA1c8ftShj+5Z+yQ2Cy7DmlqRa1TemFK3rcSgvPmdHMVZtxO5/dAd68lStzc\n"
			+ "f+MVIwqFdEXqMz6mxCux00C0SnmUedcSL2YAM2h2hl4ax1zSitpqZ5dTZyu5vKcVeJ/t2QlLQT7f\n"
			+ "iRE3prCJBmPPf7DAZ5QkFCeBkVtsLl+ETZi2kpWtRyfbZ6JTgpkYMAczVi3WAdjMc6MYIvUZ0nMG\n"
			+ "MxMTMpwym8BzYZML4bDX45RtOWS2hhXFld7czrJVpzbaZADnFmjZF4obxRh7/oPrbAWS0IG14uT9\n"
			+ "MrEZ8RC9qje0olYPYFZ/y6vK9EFka3ZR0DISJR9kQH4uAKFzJ2iPHMWNUsLmfaTnDM5gSFKJ4pbe\n"
			+ "6bjdBL2qT/kUn3EHQIlxNIkTOu0wMqNT3KgibE7s4PS/f8xcySSRuFgOuclW83WgK2lFbQPOqs33\n"
			+ "4hbMekUUNNEVOjmMkMdIr+qh1IqjuFFB2Dz/G4jUo7NsCZJgHOWriXLNmwgNcBtaUZuAmSjOkfDk\n"
			+ "/YlVP2gAmLFMRJzUB5sI67wpbkJm/OR7gHg2kZ4zOLMhiUQmHcuwJZQc2FowCzYO2kGlfCp+4mmf\n"
			+ "sObRmoHp1em1fHU5TI8dxU3Iwib9755yKYoknYbD919hkwU+oAm5THUJZhHF1ShXJyee9YsNyBIo\n"
			+ "cpLSya9TDn185e2hsCEkLGTgoiOvDbPVhjaQzbAVyID+0YJC6RlSvCUhCJtTFDaESO46fD8T9xFC\n"
			+ "KG4obAhRE62ouSl6Oa0VNUPWzCGEkN5jLZuAwoaQEIRNCaMliutUIGZRRfXurcFWMEV4RM/9bFiV\n"
			+ "vL0kSM9NtN3JI3ZTChtC9ge/LLyrVLxOTw4hnnJPK2qRFzf03ATA2PO/obAhkUOWN/C030ph0/Th\n"
			+ "dD3z5ASRzp8QxZmUnqfI1v1izE0Awub0f/icxpIkHh+FTbfIMbSiVmCLEzIyS/J5ykbtxIMUNzUK\n"
			+ "G0ISK2xyAQgbK5sUOYR4RlMWD6W4Sbq4obAhZF/YlADcC+nwHZGT450gZCQiVSQ2MHGTnjNqYyc/\n"
			+ "p7AhJFnCpgb3wcNXAFz06FTuUeQQMhLtKJ1soAHFx9OP8OjRqQQIm0cUNoTCZrStsAuWwGAhvT9e\n"
			+ "7LC6pxW1NoAcK1X7RhwTLTrNpN3G0WKw2wCi2ucqUdseHqi4ee6FXTy6/xKFDSHxFjXzAFZG+Ipb\n"
			+ "3XWLpNCpaEWtDGBpxFPMwIwh2NGreo53zFv0ql7woU917ntdr+pTIfTpGpwty2z70Q7EPkHvltqh\n"
			+ "sCEk1sKm5YGwKQ0YOMtyq/YdD053Ui5VbfPOKdufNqQHsCNo80wS2LetsgygPyDoPDerIxo+NRuR\n"
			+ "wobQsFYAzI74NbZz1HSKOMpkY5MjHrczYN5hcUg1BmmYSziTA95jMB9R7+dPK2qAuSw2FYdMw24J\n"
			+ "1HOTnjNWT339n+MlbE5S2JBEG9WSFAajCpsLbpLvyWWlCY8u55L05JR5Z0PrTwbMlAGTNt7LmKn+\n"
			+ "E4sMDoLoCxQ3AXA8E58dUxQ2JMEGtSAHopGDfPWqLvSqvj3C51tyFu/VzqollnSIBJmkLynKPjps\n"
			+ "YrGZxP4cRobiW9FrJoPChpDDombTg6+re7m0oFf1mvy+BY++spPteIp3PjDqDt+fT6rAcbGDcD1J\n"
			+ "fTlwcZOeM0rpb/1JRb1iGwobkkBDOuOhqAGAy37tetGr+qoUOV5tSb4b1RT0UUP2CTcCp0JhY6t9\n"
			+ "EyMEQ6ktdSz9KLINNn7qtxQ2xK1BqkTwnMtS1Nz26CvbchlqI4CBsiBFjlfJx5pxqJYcEYHj9J7N\n"
			+ "JiVWSnpf3AibRI1bYRXOvHIi24xcY1HYkBEMUhbOg25bYZ2rVtS2u7bgesFlvaoH7v2Qxzzr0dd1\n"
			+ "to9vsFf7fs+cshT3uBIpbO66+OhE0vpQKOImPWdUTn41UpmccSxNYUNcG6QCXBSNDNqFbNn51ASQ\n"
			+ "9/Cr60F5awa0ZcPjeJzOzqp59nDf7pkbexvbuJJRhE0Ss3GPh3js68dPeG6sFwAAIABJREFUt5e+\n"
			+ "/DSjfCMdS39AYRN/AZIDUIGZhXQLptdkGwcp07edGggPMvUGdd01jJ4rJhKGVWY+XnWRcbYfK1pR\n"
			+ "W4G5lZ3JAH0QOC6S9tUAxCo+Snp+KWyiIG7Sc0YZa0J5cUNhkwhhU8bh5ZfOoHep631BntaOz9dc\n"
			+ "wei5aQZxUa/qNYUHzYIcMLxaH7+rFbV2GMtuFDiHn5uYltRw4/W8kOT6aeMhH3/h1Dc+Wvnso28o\n"
			+ "2TjHT1PYJIQlBc/Jc9d6AIIGMAterkZk0GzBLMo5A28CpjNyEN5iXSHPmRgiRAeW7YiBwCs4zMad\n"
			+ "eE9iqOImPWes7q6JFZHaAwy1NMTx07+jsEkOW/BmicIr2l7MuKRnYjUAQQMA1/WqXo7owLEhRU7N\n"
			+ "o34wLUXOFTdZl0lvIaoVtV4CJ7L9zkUb5ORzPayfcokUgDCMcGuQ7a6JLIBm+wO5mUEIiI6kEAIQ\n"
			+ "BoADjSH2/yZ/hvmy9Weg6zsO/nfou3q+VwAnzvwOp/8i/sJmd00Unu6e7523JICrzy7WlWljt3kj\n"
			+ "fDJiwoPrCerBjoynxoEgbKp0L0NqhykpjFXk6wB25b+gmIJZ0sD2BAVmvJ6fTId03F6UVVuGDl3c\n"
			+ "yEG29uSzk9Off/S10MXN8czvcOYvkuGxobhRT+R4JGw20BUv5AOXw9z9FEA/8GKpKrKeG7nDbxOE\n"
			+ "2EepeKeUCieRnjMKx059jtTxL0I9jyQJG9JXXFSkwLgS8KHbHs7yS36dI4CzYW/rDqgfbIyY5ZhL\n"
			+ "UiRpTKpUqDOlSquk5wxx+jv/FOo5fNl++Tr7J+kSOUH0ibNe7rKxFJL0KpnULSlosnpVbySsHxTg\n"
			+ "PAEahQ1JMpsqZPJWYlmqw+6amAJw95N7L8uzCyXm5sJLP34vEcFYXJayT4/t4qPQhrlGvRrAeVfg\n"
			+ "PqBY6e3civaBWAgbLksRjwjNhiglbuSAWwaw9Mm9l0MLKBYCF178UfwFDsWNZ4PAsNl/LeRzdJLZ\n"
			+ "9KZe1Zl1d3B7ttA7uDQ2HhuKG+IVYQXVKydu5KBbATD7SeO7YYkbAPEXOBQ3HJQlWwBmkpzwy0Vb\n"
			+ "dgccx2opiuKGRF3cjKvYGOk5o7S7JnAm98HsJzsvh3Uadx/84vULL/7wXaZUJ3ExMllLSYgdAIWk\n"
			+ "xdB42JYbwUwBCIk0Z8M6sJKeG4tnoQJg9tPf52AYY+YJB+e56WxLX3jhr95djWOvo+eGEEJIHEmp\n"
			+ "fHLpOaME4MrpP2tgLLxt4isPf/k6vTeEEEIIxY1nAqcC4MKpb/wjnv9KaFvF8w9/ec5ovnmORfEI\n"
			+ "IYQQihtPBM52es4Qx05+3j79Z7+FSD0L61SazTfPldltCCGEEIobr0ROFsD19LcaeP4rfwzrNJaa\n"
			+ "b503mm+dz7H7EEIIIRQ3XgiccnrOEOPPPWqnv/1bHD/9MKxTudd86zy3zhJCCCEUN56JnCyAC8cz\n"
			+ "D5H+1m9xLP0gjNPINN86bzRvnG+1bpxnPA4hhBBCcTOywNlOzxkCwMXjZx7i1Dd/g+df+j1Eai9w\n"
			+ "kQOg2bpx3mjdOM/sroQQQkiIKJ3nxim7ayILYBvAJAA8+yKNLz/5BgwjNUqem/03d+fOsX6P6P6D\n"
			+ "yUL2Wn1V4fZinhtCCCEUNxESOjMAVjtCBwCePjqDZ4+z2PvyZFDippubADay1+o1ihuKG0IIIRQ3\n"
			+ "ow7k8wBKAPIhHH5HCq1Kes5oKdQmBYRYP0YuKRJCCCEUNx4P8FMAOsHAUzCXtYLGeg6D2AbQksKg\n"
			+ "xu5LCCGEUNwQQgghJOak2ASEEEIIobghhBBCCKG4IYQQQgihuCGEEEIIobghhBBCCMUNIYQQQgjF\n"
			+ "DSGEEEIIxQ0hhBBCCMUNIYQQQgjFDSGEEEIobgghhBBCKG4IIYQQQihuCCGEEEIobgghhBBCKG4I\n"
			+ "IYQQQnFDCCGEEEJxQwghhBASPsIwDLYCIYQQQgghhBBCiKJwZYoQQgghhBBCCCFEYei8IYQQQggh\n"
			+ "hBBCCFEYOm8IIYQQQgghhBBCFIbOG0IIIYQQQgghhBCFofOGEEIIIYQQQgghRGHovCGEEEIIIYQQ\n"
			+ "QghRGDpvCCGEEEIIIYQQQhSGzhtCCCGEEEIIIYQQhaHzhhBCCCGEEEIIIURh6LwhhBBCCCGEEEII\n"
			+ "URg6bwghhBBCCCGEEEIUhs4bQgghhBBCCCGEEIWh84YQQgghhBBCCCFEYei8IYQQQgghhBBCCFEY\n"
			+ "Om8IIYQQQgghhBBCFIbOG0IIIYQQQgghhBCFofOGEEIIIYQQQgghRGHG43phHy7kCgA2D/1R7P+n\n"
			+ "62+WX4U4+mXi6C9CGH3eJyzf1ePEen6/0f+Eut5nvpoa8Hm712G9ln7H6/3B/u8XDv4sht9EYe8z\n"
			+ "R75f9L7Hot/XWN4vhtz3AT/CXiMNv17h9AODqQNoAagBaADYzl6rb9P0EUIIIYQQQkh0EIZhxPLC\n"
			+ "misnjN3ff6PHXJfOm6PXMsw3QOdNhJ03dtkCsAFgI3ut3qBpJIQQQgghhBB1oPOGzhs6b+i8GUQd\n"
			+ "QAVAJXut3qLJJIQQQgghhJDgofOGzhs6b+i8cXqOWwAq2cV6hSaUEEIIIYQQQgKYitF50z3npvPm\n"
			+ "6PvpvKHzZuAhdwCU6cwhhBBCCCGEEJ+mYnTedM+56bw5+n46b+i8cXTIOwDms4vMnUMIIYQQQggh\n"
			+ "nkzF6LzpnnPTeXP0/XTe0Hnj+pB1mI6cGs0tIYQQQgghhLicitF50z3npvPm6PvpvKHzxpND1gGU\n"
			+ "sossVU4IIYQQQgghjqZidN50z7npvDn6fjpv6Lzx/JC3YEbksIIVIYQQQgghhAwhxSYghITALIBm\n"
			+ "aznfai3np9gchBBCCCGEENIfOm8IIWGSAXC3tZw3Wsv5EpuDEEIIIYQQQo5C5w0hRBXWpROnwqYg\n"
			+ "hBBCCCGEkAOY84Y5b5jzhjlvoOghF7KL9VWaaULCQStqUwBm2BLEIxoANvSqzlxnhBBVxrkZAAUA\n"
			+ "3Vv4twHU9Kq+wVYiKkHnDZ03dN7QeQOVDwngSnaxXqG5Dl3glACswtzqRrylLdt2NeyJrVbUCgA2\n"
			+ "eUuIz9wBUKIjhxAS8BiXBVADkHfx8R0AZb2qU5OS0KDzhs4bOm/ovIHKh7RMbgssMx6a2NkAcIkt\n"
			+ "EWh/r8B05jQCvtcGm58EzIJe1RllSchgh0MJQE7+60SF1Ng6jtpxFcBVj77ull7VS2xVEvhUjM6b\n"
			+ "7jk3nTdH30/nDZ034R2yizvZxTq3cQQveMoAltgSoXIL5opfw+d7PQPgNpubhMAOgBm9qtNJT8iB\n"
			+ "TW5heMTrlhwfamyxnm2Yhblt0+vI4et6VS+zhUmgUzE6b7rn3HTeHH0/nTd03oR3yD5cYBROKAKo\n"
			+ "BKAMYJKtETq+i3XebxIi3FZFOOa6XzihM+egDecBrPj09YwaJMFPxei86Z5z03lz9P103tB5E94h\n"
			+ "B4l7RuGELoo4uVeHOsxtVhXebxIzuLpNkjrGluFN1GsinTlaUduGu9w2dqDjhoQCnTd03tB5Q+cN\n"
			+ "VD7kENoActnFOldn1RBKnNyrww7MyIUa7zeJAVt6VS+wGRI1ntQATPd52XdntSJtUIb3W5Zjn6vF\n"
			+ "58T7bQA5RgWSsKDzhs4bOm/ovIHKh7TJxexivQaimoDi5D58AhOavN/ER66wwkuixo4a+jtu+tm5\n"
			+ "CkJI8u5zO5ThT765i3GNwtGKWgXArE9ff1Ov6vN8QkmYjLMJCCExYLO1nF/ILtYZwqoQcrJVkYIq\n"
			+ "C2AGQAHAFPwLZe7FloLNM4Vgyq5n5LFqQd5vyz2firpt8fn7rwdxbyJGC0AWQIvJi4kDO3cVwFWt\n"
			+ "qFntfoVOv2TgY1LiDhdoj4gK0HlDCIkLK63lfDa7WC+zKdRDRn4cmtwnVGCWEWzlrpthrbDKe16L\n"
			+ "8L3ye4W1zlwuhPjGNIBpraity98ZvRXfcdXPpMTcskmUgs4bQkicWGot50EHDlFQXFbgXyh3N20A\n"
			+ "Ba4SjozfdoTh94QExzoSvngQ07HVz6TEdPgR5aDzxkcMqJwiJIn3Q0DAYEPEHzpwiCqiMgsz8iSo\n"
			+ "LWJ1mE4bJlIc/d7Nw99tbXdYxpcQQlzb6AKYlJgkEDpvCCFxZKm1nG9kF+sVNgUJQVR2csxkAjpk\n"
			+ "7KuHhMB8xL+fEELiOsZuALjk09czKTFRGjpvCCFxZV06cGpsChKQoCzBDM0PCoZ0+3cf/ayYdTNO\n"
			+ "FXEIISQg25wDsA0mJSYJhs4bQkic2Wwt5yeyi3WGvkZDlOUAIGrbSZjPJnaU/bx/XNUlhBDH42wZ\n"
			+ "/iX73wFQApCV27HIALjlN1zovCGExJy9/wfAv2E7KCPApgCswqwE0u89Rya8AMp6VV9V6DqyMJNf\n"
			+ "XgrokHUAM4zY8P2+luBv1A0dN4SEwxabIJI2OYjccZPwL39OHO+J9dcdqc8qbJlgoPMmShgCEEy4\n"
			+ "S4gzUv+6tZwvMf9N6IN9YQRxlAGwohW1TinQ62GVWJYRQhsILgnxHQAlJk4MDD/7VZ0ClxBCAtEN\n"
			+ "JBgmAaxrRa2zZZzOHJ+h84YQkgRYIjRcATYD4LaHX7mkFbVO+PRCEBE5ISQhZtLE4PtpCYy6IYQQ\n"
			+ "Feyxn0mJiX/QmeMzdN4oBwuME+IHreVzP88uvvMjtkQoTPn43Z2IHF+2VjEJcaIo+/jdLA1OCFEC\n"
			+ "lW1RAEmJSbD0cubM61V9g03jjtg6b46d/BITr+zwDhNH7D05JX84DsM4BmPvGIy94zD2ngeMFBso\n"
			+ "0qR+CIDOm3CEYjmAqAbr1qo2zK1GrsUBkxAnCxkdxqgbQggJzw6X4V9SYqIGkwBuy7w5l+nEcU5s\n"
			+ "nTfpOYPhK8QVu2uiAHwGmNECWQAF+f+jOS6MFIxnJ7H39CSMZ2kYz06yARWmtfz6j7OL7/6MLRE8\n"
			+ "elXPBRjFkrGIgx2YjpyaDeEYRGJEK3WYThvmswmfso/fzdLghBAyeOzdhr8OdKIeWTaBc7htipAu\n"
			+ "0nNGZ5JXs/P+3TVRGBvfLQD/XEBXBR3j2XPYe/IS9p5mGLmjBMZVAHTehITcDlQJuFLTJIBN6cip\n"
			+ "w3TkbHcJxyl5PkE5bW7pVb3EHqHMxGHGx3vP0uCEEDLY/t5mSySKWzC3TnHhygV03hAyItLZU+v1\n"
			+ "2u6amBob+0NpDH8oQe7fNfaOY+/LF7D39EU6dII3eV9rLeensot1bk8JETlgz0jhFqTjJA/grnTk\n"
			+ "3JHHrSC4vfXMZ6MmZR+/m44bQgjpgc9JiUOrSkmIrzMZNgEh/pGeM7aleN8X8LtrIjf23EelMXw0\n"
			+ "35k07n35AvaefBWGcYyN5jMi9cU8gBJbQg1kFMyUFHIzCM6ZcgnBRP7EMp8NS7jaxpqoMaq0YW5p\n"
			+ "2AZQYW4mQsiI44ef1RvbAKa4VZXEFTpvCAmY9JzRgLnSW+78bXdNlFLHH64CyMBI4dnjb8J4OsHG\n"
			+ "8gMjVWAjqIlMXJeV4q6C4BIG+0EdwAwFJIkBGZhbgqcBXJWRawCwBbPCW41NRAixg89Jie/oVX2G\n"
			+ "rUziDJ03hChAes6owIw4kJE5f1gF/nAJAPYefw17T77KRvKOF9kE6iNzwpRCyEczsniEmVeHe7lJ\n"
			+ "3JnGQT4pwHTmlOiwJIR0E0BS4ouKl0AvwCyAAgA1Or2JW+i8IUQxZGTODADsrols6sSfVlMn/jQL\n"
			+ "I4Vnj3Iw9k6xkUbAMI6n2QrRoWtb1TyAFUVP9SYT05KEMw3gnsWZcwtmZE6DTUNIcvE5KbGyVRsH\n"
			+ "RBktDSqiQMgg6LwhRGHSc0YLZn6W0u6ayI2d/N0GgPzekxew9/jbbCCXtJbz2exinZEREUOv6qsA\n"
			+ "VrWilgOwATWicZiEmJDezAKYpTOHkOSiFbUauiqxeohySYnlIlMZ9vL5WIsoMHKR2ILOG0IigozI\n"
			+ "mQKA3TWxmjr28Krx7Hk8++K7rFrlEDHe/rcA/m+2RDSR4ibsaBzmtCHEGVZnjrKr5YQQb/DRcaNU\n"
			+ "UmKHDpt+WCMXuf2a9IXOG0IiSHrOmAcwv7smSuOn3l1nJI4zBJ5y61RMCDEaJ28RWgvyPAgh9p+f\n"
			+ "zoSHEBJPsj58pxJJiaXm2IY/FbMuAWhKfXETZsQiHTkEAMDlekIiTHrOqKTnDJE69vDKePptpI49\n"
			+ "YKOQRKJX9YZe1af0qi6k2AmSFa2oGVpR25YJlgkhhJCkU4AZJeMVFxVx3BQA3IM/jptursJ05Bgy\n"
			+ "hw5JOIy88YE//vWf5wDkIAwIAPs+MmHsv0cIcfhD4uCH7pfM18T+z6LfawCEwPZX/uZ9emcTRqda\n"
			+ "1e6a2Egd/+jS089f5VYqklhk4uB56UipBSSwgMP715Xbix8R2G6K4ePWhwJbl5BYj8UtAFlZaWoV\n"
			+ "5tZJN9ySFShVua4aACETMVcC1BhLWlFbgukQKzPiN5nE0nnzz/9Hdv5xM3uQA8HqDennJLE4QYTF\n"
			+ "yWJ90+H3W7/T6P7yMLkoJyskgaTnjJndNTE1furdu3uPv4W9J6yKTRItHLctwnED/iVN7MW8VtRa\n"
			+ "FFeEEEISPhbvF9/o/E1uO5qBmb8uZ3l7C+Z2pA3VqzDpVX0DcmuYR3lv7JKBGfG7AtORU5LnQhJA\n"
			+ "LJ03x04/WnnczPLukkSSnjO2AYjdNVETY7vTz76YZKMQCke5yu9zgmOKKEIIIWT4uNyAGY0Tl+tZ\n"
			+ "7VzPgBLhfpABcFtG/O5IDVJjD4sv3DZFSExJzxmF3TVRHnvud0vPvniZDUIIDiU49mpL1Q6AeTps\n"
			+ "CCGEECK3/pY92C7mlEkAm5aKfiXVo5eIc+i8ISTGpOeM8u6aaIw997t1OnAIOSSurFuqanBWpYqr\n"
			+ "WwlEK2olHA7v94oKS84TQmJkK6dgbokahc72qb6vR2Bb1f52MblNrILgtm9bc/BtAZhhxap4QOcN\n"
			+ "ITEnPWdUdtcExp7bWecWKmJTeGVh7t2+ytboiXV1K0y2YCYtrPGWBELJJ+FdA9Bg8xJCIqwbgi4Q\n"
			+ "AMsYrFRC415IB33B0lYVOFs0GoVpHJQevwNz8YmOnIhC5w0hCUA6cHKpYw+WmMSYDBFDMwBusyUi\n"
			+ "wTQOO5HozCGEEBKkZggyUW8/ZrWiNqtXdRGFNpMRQ1Oy/QowCyoE1X6XcODIuSmrc5IIQecNIQlB\n"
			+ "bqGaMp6lLxl7J9ggpB/M9h5d6MwhUSLHJiAkeoTgcLB7XgYiVjhAjs+dilUlmDlygmrXq1pR60RY\n"
			+ "L7A6ZjSIpfMmNb6nxokYwlJGnJDwSc8ZM5/+55PGs0f/go1B+gmJilbUNsBtU3GAzhyiMtzHS0hE\n"
			+ "kA6bSgSeW2v1pTbMggKVqOgv2cZBV6wCDpcej0ybJZFYOm/Gjj/lnSWkD2Ls0RUx9um68ew0G4P0\n"
			+ "ExAtAPPyH2SivTKCq5hA/IHOHEIIIbaIkMOmHxkA61pRW4fplFiVlaCioMPKOKhYVUZwi2ndbTZD\n"
			+ "jaAW3DZFSMJIzxmVT//TmZ8/e3b6a2wNYlNENCArJkhBlwOdOXHA6sy5zHLnhBCSbGTeuwoU2xLl\n"
			+ "ARkAS1pR60Sz3IEZYdJQXH/tL6ZJR04FZt6aoNqsoxGuR8XxFXfovCFK07pxfgpmUq8cIHLovUe+\n"
			+ "Yf2XvVavseUGI8Y//TnE3gqMFBuDuBETDdCZEzemYOYwIISQsJmBWbnIq2o87c54RQ4jHQLzCHaL\n"
			+ "jgpcAnBJOiZ2YObJUXr+IB05M/K+BV2xinMrRaDzhihB863zJQjMA8i7SBV/qHRr68YRO7YDMwFY\n"
			+ "JXutztJ4JhUx1l4xnk6wJYgXgqIBOnOiDh03hBCVJqlTbAe9LMdTL8fSy3I7VLlbPyeYSRzeUnwL\n"
			+ "ZlROS+G+0V2xqgJvt7ftSF2wqnp0UtKg84aEQvOt8yU5cASxj3YSwAqAldaNPCDMfa/ZxXo5qe2f\n"
			+ "njNan/z91z8wgO+yNxIfREUDFmdOWEhBs+nT118MepVOK2o1n8T2LSkECSGEqDWejjyWdi2o3Gar\n"
			+ "DmUWZvlxIAIJfKUWycl77WTb2w7MiJoNADWVnVXkADpvSGA03zqvyj7aDICl1nK+EyJ6PZGOHPH0\n"
			+ "/wOdN4REAllC1K9V0nm2MCGExGa8yEHd6NctmFuUGpbz7Wzdmod6uXasCXwB0+Exr2qOOHlendLj\n"
			+ "MziIYGsA2KCDJvrQeUN8p/nmuQqAWQih6il2HDl1AIXsIrdWEUKUY9Wn712gmCMhTjILrGRCyMjP\n"
			+ "UQ5qO2sGVjWUY1BZ/utcUwnBReg7YRIHpchtXV9YSEcOt0THDDpviG/sO22iQx5As7WcT4YTx3hu\n"
			+ "G8xJQkgUhHkF/qxG1vWqvsoWJsTVZHlG/pvqej7bONiKwJVu4lf/Kyuq4TyJTJHblCqWay5AzTw9\n"
			+ "1qqNnesvq7zNikQbOm+I5zx881wJwLqI7iV0nDg3s4t1bicghIQp0md8FOgzbGFCbD+LBZgOmWGO\n"
			+ "1AxkJRuY2y06E7oZ5pYiI4wD81AzwXAgzgoZ2VKwtElOtkkJam21msThbVZtmJGzq3TkEi+g84Z4\n"
			+ "xsNfmk4biNhc0tXWcr4EIMetVISQkPBLEC+wggQhtibOUwDuejChu6sVtTaAKT57ZEB/y8F0SKiY\n"
			+ "/wVQJLJEPkOdPDmdvDkzUG+rVQZmGfYlS3TOHZjOnBp7PHEKnTdkZB7+8vUSgHXEyGvTZXSbreX8\n"
			+ "hexinStmhJAgRXzFJ/F+h9ulCLH1DM7DrFbppaa4pxW1K9xWQWQfK8F01qhatjsS24BkVEsF0dhq\n"
			+ "dQnAJYszpy3Pm2W5yVDovCGuefCL10siXpE2g7hLBw4hJGBB78d2qTZCLuFOSESewSl467ixsq4V\n"
			+ "NebDSV6fmpH295LCp6lsAl6n9NlqVYZ6uYIyAK4CuNqVO6cCoEKHDrFC5w1xzIOfv1aCEOsJvPS7\n"
			+ "reX8BLdQEUJ8Fvg5AH7Z2BlOGAmx96z4/P1TMBMbk3ja8Sg4aoAYOWuGIZ0gJfnPWqK8BDWrWnVv\n"
			+ "t2KEDqHzhtjnwc9fK/k4oYgKFcQkyadIPfqIvZoQJfFLRF/nHvuRmGYTeE4B6jow6OQkQ7HkWpmH\n"
			+ "WfBCdW7BdNYkfvI/oER5SVF73ytCp3NPN0at8EWiAZ03ZCgf/+y1JG2PGsal1nK+kF2sR34CJI49\n"
			+ "/AiPv807SohaE4EN+LMCeEev6mW2MCG2J3arWlErw5+8Uzt0pEbSPk/hIHIjE4FTZqUj5899BYfz\n"
			+ "5uSgbln2DrMAZrscOjswq+NVWOUuXtB5Q/ry8d+9VoJIfKRNL0pgqDMhxPuJwSr8CbHf0as6y4KP\n"
			+ "dm+ybIVEMgXgng8T6ik2rdLPew5mNE0J0Yim6VCH6aip8C56w4CtVqpWA+swid5ROnWYTp0NOnWi\n"
			+ "CZ03QzGAhIWcfPzT7yU1p43dPvE/sw0IIR5PFual0PKDAlvYk0m8X5ODGptX6YmbkJXfvFh5v6VX\n"
			+ "9RJbVhm7m0M0nTT7/QncAhW0Tei31aoM9fLm9CIv/y31idSpcfuV2tB5Q/b5+KffK4E5bWwgvsY2\n"
			+ "IIR4OIEowb+qNpcp7D2hwCZI9IStBKAknaxlOFtxbwMocUIUqo2dks9wCdF00nQm12WYERPcAqWW\n"
			+ "fajgaInyEtTeatVNv0gdwExq3YnWoZ4IGTpvCO7/xHTaCOa0IYSQoCcVM/DPab7ACaNnFHz63i02\n"
			+ "baQmaaswc4h0nt8czKgsa2RWDUCDk5zQ7GnnXybil3ML5hYobm2Jnp2oSTtQstiJEtTfatWPaflv\n"
			+ "ZYBjp8a+Ggx03kQND3dx3f/JqyWA26MIISSkiUYBwG2/hL+caBLvxKsf1Ni0kZ6kNQA05OSFBGc3\n"
			+ "Z2A6VPMxvtReSWhJ9GnDdORkEZ2tVsPGxmn5bHa/VpdjXA2mc4cRYx5A500CMZ023B7lFiEe/5qt\n"
			+ "QAgZcQIy5eOEb4t5NTyfLPpFLeHNm2MPI32eubg6aHZgbrFZ1at6SytqBu94osjgYNGmDXNr84al\n"
			+ "qlUcosY6dPLrXJXPdffrdO64gM6bBHH/Dem04faokRBjn91mKxBCRkGGF2d7TFpycsIy5XLisqNX\n"
			+ "9QJb2FNKPvaDWsLbNsfulTxkxZ6Oc6aA6Ecf9KMN00nPpMKkFxkAt6VTo5Mbq2R5TgqIXu4cJwxz\n"
			+ "7rRx4NzZ5nhpQudNAth32pCREeIxznz/wx+zJQghPk3mG7AkPuwz6elMeGa6Jj1tvapzMuz9JNMv\n"
			+ "4cx8NyTOz07BYqumE3DJHUcN89QQN/Ry5GzAkjtHPldTMHPnxClCZ1CbXJL/0GcLYRvAtmynbZhO\n"
			+ "nkacG4XOmxhz/41XSsxp4y2p/7+9++lu47rPOP4MSIoSBRGQLTdJexSi3dtiX4HQV0B6N1gRXvGc\n"
			+ "LiyoTptmkQo+ySppj6AlV4JWmJ3BVyDqFZh0nUXauAYj26eOawkwYVEiRUwXc0GCEECRIga4M/P9\n"
			+ "nEP/oSgSvHPnz33wu/fOfv0bWgHApJiy4rr5KNEioQuzjVmTCJFkQs1udWBeyQhn+geMBDUIS2+Q\n"
			+ "sy1psTulyPS3Yt/5mDOfKyq+VWwntdXN3muQabd7Xs2L5TMS4U0MBaENlTajlpr55vGVf9z5N1oC\n"
			+ "ABIzQL0T1uCPncAQofOgLDO1IYG2dRTUNOgRGLMFBYuiZ4d9gemXZfPRe952d15bSmC73VJM3+Ai\n"
			+ "vImfhzTB6KUufL2bmvn+PVoCABKjEtHvDYyEGQA+TdCvvGXOzTqLp8ISLQXVbWdi+m9VfdOwE1Kl\n"
			+ "80ZtFhWEN8BrTF3877YztXs9vepzIweAZAxaFxXiIpFezSvTyrCd2Q1pS/Hb8cmmaU8fx6hdww4E\n"
			+ "ujt1xd2mpEYYfXNQlU7PPa+oV9fSi5qP435/JbwBhnCcF5qa++O2pEWCGwBIlI0Qv/dtmhdR4dW8\n"
			+ "RVOBU1U0p1+sy6wTZmM1TZwGmmaR6jAH/g2C79D64aaCaUalvmMalVBnS1I+CRVzhDfAKzqauvSF\n"
			+ "nNTuvfSqz4KgAJAgbsGtK7xdPLa9mseUqSM3aYJIDOyaZvAmt+AX1AErAAAPKElEQVQWZee6ilaH\n"
			+ "NEBEz/2TQp28gmBn0pV57ydpDTnCG+BQR1Ozj+VMt7Yk5am2AYBkcQtuReFWFyzTyoj4YK4qqWoG\n"
			+ "bxsa73bF3elOdRb8BiZ6HdhUML2r0ncP7S6UnFf425mvezUvcfdUwpuY8X3JcWiHs3CcF0pd/FJO\n"
			+ "am9b0nJ61WfbRwBIGLfglhXujjr32FYYMRu8ZUOaUtWtotlghycgUteFgQslm3tsTkfBznmuFy0F\n"
			+ "U6QSeT8lvEFiOc4LTV36k+QcrEsqUmkDAMlkgps7If6ILa/mMQ0XcR2sdadUlSTdPcVf21ZQtbMh\n"
			+ "AhogKdeKhoJKncqAe3BOR8FOXoMrdlqSikmvuiO8QeL0hDYP0qt+kRYBgORyC25VIe4spZhvWwr0\n"
			+ "DM4GDswA4DXXjoaGBDs4jvAGieGkCG0AAEfcgrup8BdbXGQBVQAAcF6EN4g9QhsAQK8xL7a64Rbc\n"
			+ "slnoFQAA4I0Q3iC2CG0AAP3MjlK3xvgjFyTddwtud3vlbUmEOUfHI+/VvA1aAsP6h6SHtAQk3XQL\n"
			+ "rk8zhKqlYBepTQW7unFttkxcw5tt87CEBCK0AQAMGAROYmvjQQhzAAA2yki6aT5uuQW3+/mPvZpX\n"
			+ "pnkmL67hTcOZ2V/w92c4wpPgS5rEduVOR1OX/ktOao/QBgAgSTJbGW8o/LVt3hRhDgDAZnfcgtvd\n"
			+ "kXFdUold4iYjttOmUjP7OiC8SQano6mLX8iZ2iW0AYAxMKXUjs2vMQKhzTCDwpzipMrXvZqXp8cD\n"
			+ "AIwlSUumKmei96ckimt4szEz9+LmwbM5jnCcEdoAAPpEOLQZZkHSw57y9UcKKnN4WAYA2HJ/apl7\n"
			+ "E9t9hyiu4U1zeu45RzeuCG0AAH0sWtMmbDdFmAMAsEtG0l234N6VdJsQJxwxrrzZ4+jGDaENAKDP\n"
			+ "BHaPkoJ3GOuSVixogv4w54GCMKdB7wAATECOJghHLMOb9Kq/2V5ztmYyP9zYb81zlKPuMLR5TmgD\n"
			+ "AOhuH1zXZKpsPuhZTLjY83rKCoKUSVuRtNK7S4ikilfzmvQcAECIePMgZNMx/t3qs5kfCW+ijNAG\n"
			+ "AGC4BTenILCZ1Fo2D7yaN/BeZKYs5Xtea1FSRXZM4bqjYKcQKagYqogwBxERhcXRcXjd21C4AfYj\n"
			+ "FlBH0sU5vKnOzO3dmZp7poPdyxzpKCG0AQDoMLCparIVLUNDmxMGnFXzursLKFdkxxSrjI6HOWxL\n"
			+ "Dpz/GlWWtKzhYe0HnGMARiG24U161W+015z1S9daS+3HhDfR0NH0JUIbAEj4YCivIOyY9G5R97ya\n"
			+ "VzrvNzEVLkXZOcWqf1tyFj8GTr4+FSWVznh96p5jhDh4Xf8atIYbFZM4NB3z3680M7e3NJPe0X77\n"
			+ "CkfbVg6hDQAk/IG1bAZEk55m1JJU9GpePawfMGCKVUlBmGPDFCsWPwaOzs2cuS4VR3R+3jeD87xX\n"
			+ "8zZpYfT0taqGV2f2V0xybU6wWIc3pvrmweWfPllp/onwxjqENgCQ1AfVvOyorul6JGl5Eu9qmu1U\n"
			+ "Kz2DxbLsmGIlHV/8uKXgnd8yPRgJuEY1FU6gmpH0qVtwWyLEoZ8F4f3dc16bu/ewSphvPMAOca+8\n"
			+ "UXrVL7bXnOXLP/1L5sf//SuOuA0IbQAgaQ+oedkzVagr9CqbszLvohZ1NMVqWUGws2DBy8soeOf3\n"
			+ "jvn/LUklplghpjYkLYV8Pn3qFtwtBSEO02GSdU8sSro/wm95U9LN3sqcs67VhmiYTsjvWbyQefbJ\n"
			+ "/rMftLfD7lPyFdK6/a/5xoQ2AMZ87acJJvZgmpd9YU3XSNayGQcTLNVNm2ZNm96y5OXdEFOsEFNe\n"
			+ "zVs259yGwq0QvCHpqVtw172at0zLx/7eWNRoQ5thVtyCW6GyK34SEd6kV/16e815cPlnT1ZePr+k\n"
			+ "zv4MR36cnI6m5/6H0AbAuMODFVpirA+kZdlRITLIuoIqm8i+u21ee8l8dPt41aI2Z4oVYsWcc4tm\n"
			+ "OuOmwl2XasktuL6omIjzPfL+mH4cfSjGklJ5050+tTj/829utL68Lr8zxdEPG6ENgMk8JOUlPaQl\n"
			+ "Qm3fouwPxyIf2LxmYLkhKWeOiW1VOf1TrNjFClE+1xqSsm7BXVRQiRNmiLPiFtwVsTNVXO6X4+gz\n"
			+ "XUzBS8Lw2vf9RP3C7TWn2dmfzrS+vC6nd4aPc/gPOY4/5PO9X+/0tmLvFx9vYMeXlOr7Oslx+r7W\n"
			+ "OfqP/j/qfQ2vvo5Xf+7xvz9kGpPz6p8P/P2cIT/G/PmrP96RnI5mLhPaROBcyL9sv3e2Aa4Tj989\n"
			+ "Nf397fkPv6rQC2L3kDSOEvfuw7yTkDbNabS7rYTtngkJmgk/F/KyqyqH44Q4nV9Fja+KIjIhjltw\n"
			+ "NxTuVNlHXs3LR6QtCG0QiukE/s651MzLRuZvH2d+aFynB4yS09HM5S8JbQCMO1woa7xVIOsxbctF\n"
			+ "BUHNsqIR1EjB9Jyy2bEJxoCqnIrsqpS6JemWmWK1rWDhY3ZJQVTOr6qk6phCnPtuwS17NS9Hy0fm\n"
			+ "ProhQhuEJHHhTXrVb7bXnCDA+btG5ofGz+V3UvSE8yC0AeLy0FGWdCekB4yTHi6aCtYTGCZv/p2V\n"
			+ "HVtLlyN+nLMKApqi7FxQ+HUeKZgO1eCsPdVAs6njO1gVFYQ5tgR0C5I+6Vv4uMSABBE4t6oKQpyq\n"
			+ "wg1HCTajcW8Nux90sc18giWx8uYwwHGm/MZ87s+Zncd/rc7LC/SGs3I6mkkT2gAxeODISmqEOJg7\n"
			+ "TeCyFJHmuh2lByaz1XT3IxPRLrqtoLqmytk6ugGn6R858982hXi9Cx9TlYMonFNFSUW34G5qNG8w\n"
			+ "PJJU5ZoXOXWFG94Q2iCZ4Y0UBDiSsu01pzGf+3ph5+t3dLB7hR5xGk5HF640CG2A+MhFeGA/Th/b\n"
			+ "Oj0nJiFN7wNqRcFuRVRfhDvobMhUtpkQt6Rwqu/e1KCqHLYjh63n0+IbrL3WMoN++nX0j39dZnVI\n"
			+ "U+FY1GiCcUIbHA3Dk7Zg8SDtNacuaenF03ntfn+NBYt7/6f3X6mOLqQbcqYJbWLS7xO7YLEz3fp1\n"
			+ "5sPGb+kFxwb/Y1vsN6Let+Hdf7MQbUnRqVQ67YMpYY1914Rlc1wWLO0zOfoLLD5/FhVUtfXfU2Nb\n"
			+ "SciCxa/tDyWdvTLnH9ilD8fGMIQ3hwPZkqS7nf1ptb/6m6N1cAhv5HQrbQht4tbnkxvepJ4/yJT+\n"
			+ "SF8++UGjqGBtl4WEN8UDUxI/6eNRknQ3Jm3KNKjoXQ9ysmt6FeHNZPpBXtJDWgJASNiJ8HVjGMKb\n"
			+ "Y4PZw3Ufdv/vLe21MskOb5yOLsw3lCK0iWt/J7zBWR7ai0pWmHPPq3kli9o/yuHNAwVVNZR8x+Na\n"
			+ "kDXXglsTegkfEPxN7NjnRXgDYEzPYSLIeXUMQ3gzcFBbkXTL76S08+fr8jtTQWMlKLyZutjSTPob\n"
			+ "Qpt493PCG5xn8FYyH3FaK8fqBwVLt3zut6UgqGFwnZzrQUlBmBP2tYDQZvLHOi/CGwA8n01uDEN4\n"
			+ "M3Rgm1OwdW1mb+eydr/7SVKnTX1w7Vd/4GEpnn2c8AajDBWiFuZsKZgGUo3iw8AJ6ymM07aCMKnK\n"
			+ "AxV6BvdVjbZCj9DGruNLeANgkhId5BDevH6AW5R0X5J2v7um/fa8ablELVjccqT827/6AyXv8erb\n"
			+ "hDcI6wE/q2CXheIEwoVtBdNfux+bkjbjvIuHmdJWUbjB2Zb5GXWCGpyyX+Z0vnVyCG3sO6Z5Ed4A\n"
			+ "sMffJ21KNuHN6Qe6VZlS9d3vrmn/x0xvKw4d2cZqtykn2Kru7X8lxIlJnya8AeI1sBrVtKp1BdU0\n"
			+ "dVoVI+ybVZ1ulzRCG3uPY16ENwDscjVJbyoR3px9wFtVf4iTnPCmqyXHyb/9y88JcaLdlwlvgPgO\n"
			+ "sk4zrao7dawe58okWNc3uwseL/Z8ekNBYEg/tPvY5UV4A8AOLUl5Km9w2oFvVSbE2fthXs+fXlOC\n"
			+ "wpvun7ccqfTWLz+v0iMi2YcJbwAAwKmY4G2RlgAwIc2k71xJeHP+AXBVJsQ5eHFBz/7yM/md6aMG\n"
			+ "jnd40/v5B5JKb/3L56yFEJ2+S3gDAAAAABGQognOJ73qF9OrviPp/anZvdaV69uaX/hCs/NPk9YU\n"
			+ "K5KePvndu80nv3t3mZ4BAAAAAMBoTNMEo5Fe9euSsu01JyupOnv1ydLs1SfyOyk9//4dvdy9kpSm\n"
			+ "yEj65Mnv35UTrKdQvPrP/8naOAAAAAAAvCHCmxFLr/pNScuS1F5zFp1Up3rpnW9vSN8GQc6Td/Ry\n"
			+ "Nz26H+jL5qksNyR9+vT370rSthynePUXn23QSwAAAAAAOD3CmxClV/1NmYXdDoOca0GQI0l7O1nt\n"
			+ "71yV35lKQnMsSHr49N/fk4LVwSuSKld/8Rlr5AAAAAAAcAIWLJ4AM7WqIrPQsST5nZT221nt/3hV\n"
			+ "8vuWIjppweIBnxjpgsXmS06xYPHx7+cM+MnO0BKhbUllOapf/YgwZ4z9kAWLAQAAACAKYxjCGzsG\n"
			+ "0ZLKkm52P+d3Unr5/LJetrPqHFxUzMOb/r8qBbtXVbIffcZ6OSH2O8IbAAAAALAf06YskF71NyTl\n"
			+ "ewbVOSfVKc/M7azMzO0c+9r9Zxl1Xszp4EXsF0BekbTS/I/3eofc65LqkurZj7ao0AEAAAAAJAKV\n"
			+ "NxHRXnMWJRXNR6b/zzv7szrYn1Nnb06d/UuS311HJ7KVNye96H4tBaHOpqSN7EdbVOucrk9ReQMA\n"
			+ "AAAAURjDEN5EfgC+qKBqZ1k9066GOdibkzopMxVL8g9m5ftHBVj+/pzpGZEKb85iS46akpoKwp6u\n"
			+ "hvkIWzP7T3aES+01J9958ZOHyTxzpm/Pf/hVhSsIAAAAgEiMYGiCaDM7Wm0qWAB56CBdUk5SburC\n"
			+ "s0VJ2Sm1cwp2gIq7lmmfTR0FNk1JTdN2iZaa/TapvzrVWQAAAAAig8obAAAAAAAAi6VoAgAAAAAA\n"
			+ "AHsR3gAAAAAAAFiM8AYAAAAAAMBihDcAAAAAAAAWI7wBAAAAAACwGOENAAAAAACAxQhvAAAAAAAA\n"
			+ "LEZ4AwAAAAAAYDHCGwAAAAAAAIsR3gAAAAAAAFiM8AYAAAAAAMBihDcAAAAAAAAWI7wBAAAAAACw\n"
			+ "GOENAAAAAACAxQhvAAAAAAAALEZ4AwAAAAAAYDHCGwAAAAAAAIsR3gAAAAAAAFjs/wHn6vZpPBiH\n" + "VgAAAABJRU5ErkJggg==";

	private static final String QmCC = "iVBORw0KGgoAAAANSUhEUgAAAXsAAABvCAYAAAF6CVCkAAAAAXNSR0IArs4c6QAAAARnQU1BAACx\n"
			+ "jwv8YQUAAAAJcEhZcwAAIdUAACHVAQSctJ0AACLkSURBVHhe7Z0LlBxVmceLIAgERUXektdMMpOZ\n"
			+ "CajRswHXnV2XwKh59EzXo3mcfbnLqutBQiAkITAJjyTzSiAhM8Cq6FkV3HXX9exZUVfZXfGFrLou\n"
			+ "+FoMukkmIfPo9ExCBiHS+93q73ZuV3/1ruqumrm/c/5nuu797q1bt7766lZN1S1FkiT2r51fHF6/\n"
			+ "oHhoU2Px8OZFxZF7motj21qK+b4lxSP9l5lC02TiZQOODFRvhJEziqI6OzvbNE3rsaZzYbEKdF2/\n"
			+ "GX+a9eHPit+ueN0Au42ARp9NrdBLI6hGq5r6S/ZbFKzj7aaRXyb7lbc6bQCDr5hhXXFZhjGEJhWw\n"
			+ "PPxZ/m3968qBdaXex0VlfFvTEvxpYrcBZsMIYTbZOCtWG1EsTVXV94k2JOIGjG9vBZcB1xEa63UP\n"
			+ "iCtmUL/FNBFrWQaVRnJg3XxzA0bubi6G2QCGl98cllZhYxhPm2Lp+NtMR7uMkVlsGlqhNgCzTPxs\n"
			+ "AIevFBdt4XZuQnMa6wZgchm/GyAuQ5h8yrUBgGhj99uWiUHlFb4BmFSB3Qbohv6y15VReSzNj7CY\n"
			+ "PUFdSCJJI/vWzCuyE9jBjQ3FF+9aCAdwU3H03sXF8Z62Yp6dB9Dv0TxZeG08tQFUZLCmcWUymQaz\n"
			+ "kA3MBn+aWJdJwjZe/CviaeUAnBf2sr+iPfttFWb5wy1csoqhAetwkVwxE2ZXYW28aOtUzmTfLfOK\n"
			+ "wxug12G8j0nKob4LZuNPE6eeF8XTzL+G8VX2l8HTKDRDe4j9ZTawIR8V62I4la1qfPlCpbe1fDXk\n"
			+ "1vPUXzgTv8T+Mtwaw9Ks6WyPULYVlBvfvcj0dd54zDbx0ngOXxbTqUawNC5zmRhpMom27HcFZON3\n"
			+ "KfMx28RP4zm2K7TA7ZwEFyxvQfNK9t0yt6Lxxx9U5mJWGb89L6ZZlyms9vizqm4SsfGYVIFd41nl\n"
			+ "4JtbcNHbygSYvR9hsWpgiPwad5tiUTkFk02cel4iSTn7Pj6nsH/N3MKBWxcUhteDNoLuaCgcvLOx\n"
			+ "cKh7YQHOZYWRe5qmRu9tnhrbtnhqvKd1Kt/XNpXvb5uCC7HJQncLHdUk7rBxJrvLycaa7E4nG2+y\n"
			+ "S3U25jTveMK4k931ZLGJ3fk0x58Qo8pjUK4YYpSmaR/2IyyWHqLu/DA7wPUMBXix8QpVl139dul1\n"
			+ "YeLBs2073+MOmMU3yG7DrPlOwiK+YOX4RRKHqi/MOhxho2XT62HcZnq8cLHlBb+dr+naM1axDeO/\n"
			+ "4frGHN4zyI6AizeqI3gduOgJVsat8/ly1sj+MSaZ8HRY5+8wyT9unV+67sIQY9OpAT3fhG8ELlYs\n"
			+ "W/MYTp1fZQvLnXrnu3HRE7AzruJ1ifWJadDhr2ByOEqdP/9k58NVC0tnMZ7dWrZ2fr5/8ZhZUCCq\n"
			+ "zgevH+G/GWIeh0pj2KU7wctwqYb6RWuaneAEf6s1Ddr/CFbtDarz2T19qvMLO5QFWKyCKD1fhMqz\n"
			+ "s7dLpwDv7sWfrvipl5HL5T6IP93x1PmWOyZW4up8EW7X3t7+uqUrlp7Fl72U9QL7tzH+rCDKdZDY\n"
			+ "dX6euNtD4afzxU4ThdkmEFOPiXkQDsp3SClEWz138vawX1h5/FmG14uLJlk9+wRlG5iJIeUQ5fmY\n"
			+ "7UgYz5dIJBKJRCKJj303vW3vvpvnFA6snVsYvn1BAYab5r384U0NhYN3LSwc6l5UGLm7aWrknuap\n"
			+ "0a2Lp8a3t0zle0v384+w+/l9l+3HqiR+2b/2bUXzIus2GOffXrq/c/AOGO/fWRpyHt7SZA47R+5Z\n"
			+ "XBzd2lK66Oot3VIu33LAYSZWKfFKlJ1fUtvnserQWP9R4kVYNDZ0Xf8E/gxP9J3vfgQYhnEpv2q0\n"
			+ "E5raXg07CYu6Ah35G/xZAasD8r6Oi2X81u9KHJ3vZQdQ8I2DnfMYJpFE1Ql29Tilw045iIvhqVfn\n"
			+ "WzeQL0PouBCTSKzlwmBXF5XO09yE5vFS7FZmhfV8Lw232tjKMMaxiGd4WVwsY023s6s7dp2ff+DC\n"
			+ "djRxBDbqe04bx/O8Cot5wq6MNZ397tK7srhY0SZMCsa+m+cW998KIWc9hBt8RJmFGsz2hJ/OX22s\n"
			+ "nsf+zypKN/TnIdz8hC+jqQm1kV7T3LArI6ZDjP8mZbd8+fLZVLovvHY+XFR9DH9W4dfzYYMGecOd\n"
			+ "xGzF3xyvaW7YleHplNCkjF26J9w6f7SnpVA6uUKngvL9bd2YVSZM2GGYG2AYz+NixQZRG+c1jUGl\n"
			+ "ucHrYurs7HwbS2P/PRPTTcOwOHX+2NbFI+PlkU2p81nHmgUFoux868ZRG+s1DULY76xpdmRz2ct4\n"
			+ "HUyqqp6JWVWIdrCOPCb7x67zR7Y0jYyxoWWKO98NCH9rebmohFV7w7bz2Rvpdeh8K9RGeU2zg9ty\n"
			+ "6Tl9N2adfEeDK2ccN20M/YA1D3be9axMxsgsEutjMitzw2/nY7EKatn5dhtnl26Hep1a8bK9HdDB\n"
			+ "P2f1wt+qc11o9q251HPnY5Eq4ux8EfC+F3gnY4eUx95BgLjeKNYXVlitd44OKqNeOh/NSWrR+daN\n"
			+ "FJe7urrIB7n8Atca/4I/y8Tq+Qy3zkczW8J0PmzwqWYn2oUdw3hW7GhMLuOU5wdeB7Tndkwyset8\n"
			+ "WH48ivVC58+z7Xw0ccRP5/MGW4XZHNdHx634sbWDlYVQlMNFE7vOD7uuCqjO7+5WZmG2I1Tnjw80\n"
			+ "XofZJLzxoAImldFy2j6WBzH+NUzyBJQ5wcrhoi243tiU1bI34Kq8Q3l+vq9pJWbbEqTzJQSH+pTZ\n"
			+ "h+9uqDrh5ntazbfEKWTnSyQSiUQikUgkEokkgZiPsK2ZZz7GZs6GcRvOiMEeZ1uPj7RtBLHH2jY1\n"
			+ "lh5tu2th6fG2zfwRNyb2mBs+6nZv6XE3c9aM7a2lmTP4pTOT+fSV8O8yQRM9TU3YNIkkPpLm+OL9\n"
			+ "osKO1o3YTIkkWpLs+FzjfW3epzYgoG7B+5GqqudhVSbt7e1nUHZxqKOj4/W42rrBHofSAzwpL25H\n"
			+ "p9rZicnJIA2OzzQ+sCT49EIBEXccky5MOesHaz2YXFfE9oBTb8dkEtGWCZNtMQxjq2jf2dl5PmYl\n"
			+ "h7Q4vqm+tuew2YGBnfww2xl6Tn8Yk6ycIu40pqyRXY15voGD5bdiXUmI4AyxTW7RXLRlwmQSq20Q\n"
			+ "ZbPZK7G6dHPsQeXCwqDy1JGdl4RzfBBWGRhVV2+2djSbqyeby/6eNZ09Io7FAmOtE5PrjtgmcPyK\n"
			+ "yf6siLZMmFxBJpM512oXVtCuf8Lqpw/HBpVrgjh+8WHlNKwiNFRnM2G2K1TZqAQ7PdYZFizrCuX4\n"
			+ "cFZ71SmfA+sx37bSNO1rmFQ/2MPi5jDnVhzirG8oD2/Y0MYc1uCQBotEyuSQ0u/H8f08iusVuHhV\n"
			+ "xR0HO/IAZjkilmHC5FCI9VlfE4wScT1RRHwvgMN/x1oXnIE3YHZtqbfjMwoPzP5UXI6vGdqd1s4O\n"
			+ "I6zWxClPBC72zKlw3ewYop2bbRjEdQR1fGu6KOj3W9GMhCoD8cfTmyuREIXj53vafsDG7tZxe2HH\n"
			+ "khvRxJW4HN8LFTuAeF+gIh+EybbpVpLo+EGAA+Rya/u4IK+NSmeCM5fj/NNwJvgK/qwdYRx/bHtL\n"
			+ "+XVdyvG5s6K5I0l1fHYXRszPZrPvwKy6Oj5zJi92YYCo/Zi4DlH8HXEnqHJccKD4muA9ciodv/SG\n"
			+ "lpvjj9zdXHpNmt2q9OD4TFjUlqQ6fkWe5V0aS57tNsI1g/nxVzc7hmjn1RYi5k2YFAjqbWJRcJBN\n"
			+ "oWkowNm/TNXPBf10BLblbDSPF0+Oz+7Zg+ODRtm9enaf3pfjP3DOH+HqbEmq43Ooe8sV5UCYXIVX\n"
			+ "O4YfWz/A+LnDWredurq6ytPHU/lRSMuZd3ZOgYOqYsp4J8GB8w+lVkWAH8fn/6Ty4/iTQ0oLrsqR\n"
			+ "pDs+RUU5ECZX4PcfWKItEyaHBuoy39YUBUOZz2B2YMAZzddluWA59AvjuVzuYqirot+gH3+M2dEQ\n"
			+ "m+O7fOnDynR0fNhZr1ltVEPVMJvEao/JkbNq1ao3wLDihtDStWGxvZD2j1U2HgVnJfLLKbGwf+0l\n"
			+ "0Tq+T4fnpNHx7fBz+oadfQUWqymw3kjnXIla2Mx4icLxjwwp87C6QKTd8eEUf7iiHhRmVwC2WcqW\n"
			+ "aenSpZH9Z9ovsO1Xi22BKPzPmGVLkKEO1Gt+j5EJDsD6fc+3MKSMBHX8QzvDOTynTo5f9UAa7Igv\n"
			+ "Yp4tHdd3vNFaTlRnZ+flaOoJGBJV/MufC9IDPQ0aFms7OvXOd2JWFX4cP6tnt4m2TJhVPyYGla1+\n"
			+ "HD9/vzIHi0aCV8cPMpmJ9Z63nWCn/SUWqYCyFQXlHkDT0MAF599T68DswFB1pkW4CfECB8AJrxG/\n"
			+ "2K2EfnqRE6fjRwWcDc6Ei1PbGaWTDBvCpVk1faZ/vP9sz2P84sPhxqZpcHzJDGdit3KFZ+1RbikL\n"
			+ "lrEKiUQikUgkEolEIpFIJBKJRCKRSCQSiUQimYHsu+nSwr6PzynsXzO3sP+WuYUDa+cWhm9fUBhe\n"
			+ "31AY3gB/N8DfjaA7QJsaCgfvbCwcvKuxcKh7IWhR4cXNTE2FkbubpkbuaZ4avRd03+KpsW2g7S1T\n"
			+ "4z2g3tapPFNfm6kj/SWN9y4Zz/e29WJTJJLaYL5ltWaeOTem+fjxbfNxbkz2JCb8NR9KayzNj1me\n"
			+ "G3Nh9dyY5rM6ODfmfaW5McfY8zo9+MxO1dtYTJdVCOxGsVkSSXwkyelNsQfN+lp/iM2TSKIniU7P\n"
			+ "hU2USKIlyU6fYMefpWnah2PWhbiu1NKld2VgO/4KF5ND0p0+rOOrqtpCvanjVbDTXsSqylB2cUg3\n"
			+ "9ElcZV1hbfEyG5qIrut7xW3B5GSQBqfP9y85hM0NDDjQuLgT/IrNhIBVcarev41LuL5IMQxjBH86\n"
			+ "As77Hr9tgUBxjlgG6vgmZiWDNDg9Eza3ZsCOWivuOCbM8gUcbBVTAa5cufICzKob4JQ3iW3CZJIg\n"
			+ "Ti/aey1TUyinP5BApx/vr923rFRD/V5UOy6qeqIkTqeHg7xiJjNMThZpcXombHIo2LQboOO4WAXs\n"
			+ "5Ko5bjArEFHWFRVxOX1GzbSLtkHE+h+ri480OX2+pznUnDhVHWzoj2CWCSxXzU+DWYER64L6v4vJ\n"
			+ "dSUupxftwgr6qmJm6dRReEjpmNxzeminH+9fnMcqA0N1MJUOjmG9cPUN1GM91Z9SyqkvcTi9aBOV\n"
			+ "sOr0MzmkrAvq9ExYTSg0XfsR1clcMKb/AZo6QpUNK3CyZVh9bETt9Fk9OyDadHZ2XoRZEpHCrnPr\n"
			+ "5vSMTCazWNxRXLCT70YTV6jykckwGnA1kRO104v5Wk7bh8lVONUxYyjsOq9uTo+Q99oxzxWqbJTC\n"
			+ "1UROlE7foXac55TPWL58+WzRhknP6Z/A7NrDL2LL9+fZxevGBScvXPGiFc0jp85Ob2LdIStWrDgL\n"
			+ "sxwRy4BzbMLkwMDF20tinZgcOXGM6d1gH7YW6wlbXyjq7fQwxu+M0+nhdPstGMM/4ya+E6g8zdA+\n"
			+ "hdVVIO48J6cX7ZgwuYo0Or2YhzqBWSRQX9UtYWiPjtm1gXR6UK2cnhGn01s7OIzYl/qwWhMxb6Y5\n"
			+ "vaqqHxTTrUIzErheubSqjGH8FrPjJ0qnH+9ZcmO+r3UlLnqm4k4O4eiisIgvYCefWtXJIYTVptbp\n"
			+ "u7q6mr2uh3J6cdlJ0O+OH36gymBWvETh9CfvvYNjCs6L2a7k++fvjdPpnfDS6WK+qqnlt7vE9DQ5\n"
			+ "fVBgqFfxLSouGEJ+A9r+YyqPSTXUD2EVVcCBcSPkG7hYG8I6Pf9PK+X0Xp10vK/5yaQ6vZpTl9vl\n"
			+ "i+m1dnpVVz+KdrEPC6BdI2K7uMBhn0OTMtAPn6RsmSBvLZrVlzBOP95z8vECO6fP97W5PsKaZKd3\n"
			+ "yhfTa+30oh1E4Kpn/sOSyWTOFddRIcP4NprZAgfEX5BlQbCd/4Nm9SGo07Nna7w4vRdHzQ80Pp4G\n"
			+ "p4ed9RQmm1Tk1dfpQz8ywQFn/ZpYtyjYxs+hmWegvqVUXVyQX/s3q4I4PX+gbLo7PThhwS6PIebV\n"
			+ "2unB9tNe7LwAkftT4nqtymrZD6NpYJYtW3YmVXeFDGM9mseLX6c3n6ScIU4vpoOTvYrJZSryPTo9\n"
			+ "RLabMLkKP04fhtWrV78J2rtfXFetBNv/Dfhb8SAeJdbfWSP7XmxytPhx+vLjwzPE6d0Qy9k5PUQv\n"
			+ "Q7Rrb28/A7OqiMvpwdFOhfY9LtZtJ7Arv9pH5UclVj+sax2VZyezUVHg1enLz837dPqJ3WfvxlXZ\n"
			+ "Mp2dHhy54rP6mEwSh9NTz71YxaIqdTDC4fq0q6z1UTYWqYZadSEMaV+qqssiNA1PrE6/Y6Gnhk7r\n"
			+ "SC/YMGEySVyRfrWxuuo/oMzR4QwQ+jvB1noxORSaoX02jnrLxOb0O+d6buh0dXpIr7gQBhvH/1bH\n"
			+ "5fQccKZd+DMyxPbG0eZcLvcu/BkdcTh9wYfDM6ax01fUzYRZJFanb9FaTsesyIEof0MUEtvLRNl4\n"
			+ "FTYtfiJ3+h0Nvh0zrU7vhLVeq9CsblBtSoLi+EdbFZE6/YB/h2dMN6e31gk78hVrGhcWqTlUW5Ik\n"
			+ "bGY8ROb0AR2eMV2cHoYn5HMnmM1u0VVMdccFB0WipiiH7TiKP12xbgsmJ5v9a98W3ulDODwj7U5v\n"
			+ "95wKOM84mlQAeSestkwwrnV8FDdurO3BZEfClFEN9UlMqi1Hh5RvBXf61mK+P5zDM9Lq9GxSU2t5\n"
			+ "rqyRvRLNbKHKMam6ej2a1JQutaviH2lMmGVLWHs4+9VlWyHaB3T6vvAOz6iX00OH91l3AmY5AuUq\n"
			+ "prwQxcbvaOYJODjeT9XDpKrqJWhWM2DbdljbgVkkYWwh0t+FWbVn4iHlgG+n743G4RlxOb21k90E\n"
			+ "DjuFRasAB3Scsg6GMq+haSBUTf0lVS8TZNd0kihwxh+w9cI2uU4VTrTVFost+d5xTTl4x8XenX77\n"
			+ "gsgcnhFnpAdn/Yils22FRaqgbLngQIl0YllqHWwbMDsQVJ1pkWZof4abEQ/Dt0O09xjpsUgk1GJ4\n"
			+ "AxeJm8lOzWm/RBMnqubHgSj4NOZFDji5ytfD3pDC5MCI7U6rcFPiYXhDyfHdx/TNL2GR0NTzQtYP\n"
			+ "hmH8N/5MFdDu59MsuM74OW5KfBzecr63C9me1kicMC1OL5nmFPYoo4fubHB1enaffqyn5e+wWCCk\n"
			+ "00sSxdEhZe9Y75vB4Znj004vPntz9P4235+XkU4vSTRwBnj31CPK+yZ2K1e4CQ6Yj03sUW4pa1Bp\n"
			+ "wmokEolEIpFIJBKJRCKRSCQSiUQikUgkEolEIpFIJBKJRCKRSCQSiUQikUgkEolEIpHUGzbt676b\n"
			+ "5xbZnMembinNfWzq1tIkgabWLShNIcW0vgFUmlVneAP8Bh3cyNRozr1gzr+wqdGcg8Gch+GuhSV1\n"
			+ "My0yX083taXJVOlVdXxdneue0lu85pu896LuaymObi291Wtqe2txnKmHqa04zt7y5epbUinzzV9R\n"
			+ "l9HqXTIBtkPYPRKJRDI9kMHeRWz6hr4lE6M9TRdjl0kkEkn6kMHeRZY5e8b7214dvW9RM3afRCKR\n"
			+ "pAMZ7F1kCfai8v2tj2A3SiQSSbKRwd5FRJC3Curejt1ZF6666qpzDJvPv8UpXdd/s+LGFWdhMxy5\n"
			+ "/vrr30jVkVaphvqfuGmS2vM63dBfrtovhvFtzJdQyGDvIiK426nYrcT2bXw32OcS2XdAqw6AGkrT\n"
			+ "tHw2m23FJlGcktWzvVTZNCtrZFfg9s1I4KT/HmufgC8MM59Ek8iAdWWt6xK1KrdK/m/NDhnsXUQE\n"
			+ "dSflB1r/BLu2rsDBNgeC/3HqgKiFYN1evto4LYI/+3J8e3v763CbEgv4xE2Wtp+A4PkoZgeGCvai\n"
			+ "0Cw04FMFqn4m2Acvo5nEDhnsXUQEdDflB9o2YPdOOzRDe4w62ETBQflfaF4T2ImFagcXmNT0k75J\n"
			+ "hQj2FUIz38Qd7A3DaKDq5QKf3IWmEif8BPsDMth71kTfkvdjF08LIKA+Tx1oouCg34TmNQPW6Xhl\n"
			+ "EPunnFNEGoM9tPkrVJ1ccEV1BppK3JDB3kVEIPcq7OK6AQH6u9QBAunHO6/vvAjNbIED7XSwP2ot\n"
			+ "b1U253ifPlY8jOoliFOwh4C9F818E0uw15RTqbrqKfC1wrXXXnsFtjB9TD6kfD512qM8MzGkPDs5\n"
			+ "OKs4uef04sTu2cUjOy+CYL84UcH+SF/bZ7Cb6wKMandSTisKHPiIdXTU0dFxHmUrCsr9tl1rPxuL\n"
			+ "1AVVVzdQbeNauXKl7+8kT2fSEuxhv/45VU/ShM2V1JvCoLLg6JDypYkHZ0Owb6lPsAdhc+pKV1fX\n"
			+ "XMpZrdJy2q+pdFEQ5Mex2rojR/X+SEOw13QtT9XBpGrqMTSTSOx5rls5Ha4Gnjwy0ABBfGYFexEI\n"
			+ "6I73be0EB/QXsIpIoNaRZMGJZSyTyTRg81NJkoM9DEiaqbJccJW6GU09kzWyV0LZZ7v0rmswSTLT\n"
			+ "OL5HuXRi9xvo4G4VEcD9KH//Rb+Pq00Uy9RlZ8Ioasp6UFkFQe5VVVXnY7HIoNaVJsFJ829wU1JD\n"
			+ "UoM9tEunynF1dHS8Hk1dyRiZxcxnqXog/WV2lYumM499N895dN/N805q7bxH99/GNP/R4XWg9VwL\n"
			+ "vnBgw/wnTG2c/8ShTag7G0vavBDV9ARWnXgmh5SWIwONdJDnIgK4H+UfuLAdV5dYDMPYSh0cVqmG\n"
			+ "+iQWCQ1VPxcEj5o/1UMBweElqn1McKJ8Bs1SQ5JH9uyBAajn62I5WF6L2Z6BbXy7WIed2O2ixo5G\n"
			+ "zyeRaUH5SRz+FA5/Aoc/V8+evOFP3WxcUHrqRnjapvyUjfCEDVadGgr3n3+cDPRMRAD3ozQEew6M\n"
			+ "4JuoAwOCvIYmkUGth0sG+3hIcrCPAzWnqlR7rFI19VdYZHojg32JIzvnpjLYU85bdxnGY9g8W8hy\n"
			+ "qCDBHtb5VaouLjTzhQz23ggU7DXlVOjfX1D2dlp649LTsLRvsnr2XqpOq2C//gcWmX74Cvbwd9oG\n"
			+ "+yFlXhqDPQMO4lMh2O2hnDcJ0gzts9jUMpQdVxqCPROapYZ6B3vmpxBMv0/Z+BGs73Bnp/t7Ijac\n"
			+ "AleqX6LqtQrW8wksMz1IUrAv9LS9a7y37XmnxyPzvW1/W+xWZmGRSCHv3xMB3I/qcRuHzdMCjrrB\n"
			+ "PAF4EeHoggpkGYvgIP4JUdYU5P0Om1aGsuOCtstgnzJgn30Ogvn3Qb+qkKH1wP63fZwyCsG612Ez\n"
			+ "fLF06dLTYB//tKo+Q38Z6rzvhhtumI2m04MkBPt8b+uk+AKU67PwGEgLA0s+iVVEQqF/4Q/t1hVU\n"
			+ "qfgHrcXZK2QYz6OZLeygIcuiuvSuP0DTMpQdlwz26QX23eUQ3Iep/rIT9PNTqqq+BaswgRPFOTAC\n"
			+ "/1fK3lGGcRzakMNqJCL1DPZj21tGylMcBAj25YDatziSx6nG+5qfdFuXX82EYM9GQmRZkKqpo2hW\n"
			+ "AWXLNZ2DPQSxG6m6mOJ4xDVuoN8/DsH9FWp77AT2zwWY/ngW9N1mqj43gT8NtmgtdZt+PDHUI9iP\n"
			+ "bls8UprTRpjPJkSwZ5rY2nwuVh8YGewJuQR7OJD+miwHom7fcCh7riDBHgLBv1N1caGZL+II9lQ9\n"
			+ "otAskcBI+zrokxGq3U6Ccl+1jtyjAOpcBT52jFqnk2Ab2NTO97ErUqxqZmAf7OdHHuxH71k8MoYT\n"
			+ "mUUd7Mf7Wn+IqwlMfqDxcS/r8qPpHOzZSJQsg0IzEsqeK0iwjyMwxxLsDWMXVRcTjHaXoVldgTY2\n"
			+ "wLZ/mmqjF8H+68WqasoHtA9cCO1+imqTF0HZF+DE9CGsbvpRi2B/+O7mUT5rZVzBnglXFxgZ7AnZ\n"
			+ "BPtMJnMuaY/q0rveg6YkVBmuIMEeytl+lhHq+yaa+SKOYC8CffteaFsbLtacrJH9Q1j/E9S2+RKc\n"
			+ "wKCeXNIEV3s3aDnnKz6vgpPAF2Fwsxy7Lp1EFuz51MVCsIffo3yq4riDfX6gIfQ/a2WwJ+R+G2eZ\n"
			+ "ZmgPQWAc42UgbTdm21KxDougfJBgT9bFdLV6daBbCHEH+9hpV9hTWRkIVP9Gtd+v2C0TVVfLb7VS\n"
			+ "NkkV7MsT2WyWnVzZP5BDP/4pit2uZCcDOFa64ART15lgHYkj2I9saRy1zksfb7Bvi+TAk8GekId/\n"
			+ "0AaBXBfKb7CHMo6fX0Qz36Qp2EOfHaTaGFSw7SMQwD6C1ZNQ5dIgbH4ZNhiA7f08ZRtCJ7D65BBL\n"
			+ "sBc/RBJ3sN85j33oO5Ln7mWwJ5TwYO82fTObGx1NfZOyYH8V1UYvYqNSGJHOwapqCrT751SbuCC/\n"
			+ "G01rTsbILIL1f5lql5OyenYLVpEsUhvsd84pHh1UrsLNiAQZ7AklONi7Pd/PhKaBSFOw5+CLQlUf\n"
			+ "5oY+3csCp58ZJGsBtCmxwd6BWVpOW2NtO/MXzE8maQv2BQjyU7uUWJ5HlsGeUEKDfde1zvOfM4FZ\n"
			+ "qA+NpzHYp42UBvt0kpZgX2ATlT0ST5DnyGBPKIHBHoLwJFXOSVBnFot7xi3YJ/qfcTaoqtpIbYsU\n"
			+ "rdQ/gSOy75ZLkx3sdzQUj8Q0krcigz2hmIJ9ECD4vkC2MYgM42qsdkYhg31w6Tn9fuzGdHJ4yxte\n"
			+ "TmSwH2goTg0p87CZNUEGe0J1DvZun6sTBebmP+phxO370bpsNnsZKzvdYS/Cabo2mhTBCZz8qhQX\n"
			+ "2Bwr2+r6QS2n/aweguPgp+BXf4rdmE4mh5T+RAX7OgR5jgz2hOoQ7CHwvoNsi42gyKmlktVkMuZn\n"
			+ "6nzd9gH7X8CBfQ5WMZOZBSeHjxD98zTmh6aW9+yh3aW3aw1jV9L+UV0zxvtOe6U+wR7Eg31/Q5HN\n"
			+ "KY9Nqgsy2BOqQbBnb+OqhvosuX4bwWjrK1jcFxA8BuGgf42q006aoW2ForFMq51U1Jz6PqovRGX1\n"
			+ "7CCaB6YWwR7qeJyqm4v5BJrODIY3nl+fYA9B/viDSiI+AjwTgz0csL3UAcAFB8L/omlkwMidffWf\n"
			+ "XJ+T4FL+J1hFJCxdsfQs2L7D1LqcBKPdK7CKaQ/0z1qqD0RBfwT+bCXUH1uw13P6NqpOUTDIuAvN\n"
			+ "Zw7DDytnHbzjgtoF+94FxeMPK3V5kcOOtAX7rq6uaygHLsswfsykadozcNA8ymSmUbY2Wr169aW4\n"
			+ "uiCc0qV3Zah6vcgcgRvGTqwrdmB9X6Da4SjD+HZLy/SfPheCou3XnaDfXs0a2SvR1BdxBPvOzs42\n"
			+ "qi5R0OZIv4WRSsZ6z3wt1mDfk7wgz4kj2E/snPt+rD5y2AEGo91XKGeOQp165ztxVa7ASWEJVYcf\n"
			+ "seAOJ6avYZV1Ba4+3uW3b6H9dX2pBtrcGrdgG1+AfjkGJ7kuKt+vIJjvpfqSC/IfpMp5FbSzYl4g\n"
			+ "8K+fUXZBBfWl7vHbCib2KAcOrJsXebAvPPj6RlxFIokj2I8PNF6H1ccOGwWBQ9vO/uhFcCAPw2X5\n"
			+ "mVilZ1blVl0MgcDXusF+BNp8DVaRaKCdznPPGIbjPDK1gGyXVK10dPny5en9jOHEoHJieD0L9BGO\n"
			+ "7Lc2vxTXN2TDkvZgnxQgMPZZDwYYAf3abdrjtAAnxB/x7YIT40cxue6I/S1VH4Fv2H6wJxVMDiqv\n"
			+ "DG+EkX4kwR7v2W9vLf66e+6bcBWJQAZ7iUQiAWCk/wgE/uLBTfMjCfb80cux7a2jh9ZeUPdLIBns\n"
			+ "JRKJxMLR3cqSySHlaP7+M4ovbl4QKthb36CF5e9E8U1Zv8hgL5FIJB5gE5UdG1KeOzqoTB59SCkW\n"
			+ "dp9ezO94c3Gs95Li6NbG4ui2hTCKL2m8B9QL6lsEAR7U31TWkQGu5pPqbykc6Vvyf2OgwsBlj8Lf\n"
			+ "NWPblyxzUn6g9XJsmicmHjjn8YkH3lqMUpO7zpsW96klEolEIpFIJBKJRCKRSCQSiUQikUgkEolE\n"
			+ "IpFIJBKJRCJJM4ry/355vq3e6c4HAAAAAElFTkSuQmCC";

	private static final String CYII = "iVBORw0KGgoAAAANSUhEUgAAAYgAAABuCAMAAAF98ESpAAAAAXNSR0IArs4c6QAAAARnQU1BAACx\n"
			+ "jwv8YQUAAAJtUExURQAAAD4+Pjw8PD4+Pj4+Pj09PT09PTk5OTw8PD09PTw8PD09PTY2NjIyMj4+\n"
			+ "Pjk5OT4+Pj09PTw8PDs7Ozw8PD4+Pj4+Pjg4OC4uLj09PT09PTw8PD8/Pzg4OD4+Pj09PT4+Pjs7\n"
			+ "Ozw8PD09PTw8PCcnJz4+Pj09PTw8PDw8PD4+PjY2Njk5OTw8PD4+Pj8/Pzw8PD4+Pj09PQAAADs7\n"
			+ "Ozw8PD4+PnwABT09PTw8PDw8PD09PTc3Nzw8PD09PTo6Oi8vLzw8PD4+PjU1NSQkJD4+Pj09PT8/\n"
			+ "Pzw8PD09PT09PTU1NT09PT09PTw8PD09PT4+Pjk5OT09PRwcHEBAQH4ABj4+Pj09PT09PTw8PD09\n"
			+ "PT4+Pj09PX0AB30ABD4+Pjs7Oz09PT09PTo6Ojw8PD09PT4+Pjw8PDMzMz8/Pz4+Pjs7Oz4+Pj09\n"
			+ "PTg4OD8/Pz8/Pz4+Pj09PTo6OjU1NT4+Pjw8PDw8PD4+Pj09PTs7Oz09PTw8PDs7Ozw8PD09PT09\n"
			+ "PTo6Oj8/Pzs7Oz4+Pjk5OT4+Pj09PT4+Pj09PQAAADs7OzMzMz4+PjQ0ND4+Pj09PTs7OyoqKjEx\n"
			+ "MX0ABj4+Pj8/Pz4+Pj4+Pj09PT4+Pjo6Oj09PTk5OT09PT4+Pjw8PD4+Pj09PTw8PD09PT4+Pj09\n"
			+ "PT8/Pz4+Pj09PTMzMz09PTw8PD4+PnsABjg4ODw8PD4+Pjw8PD4+Pjs7Oz4+Pjg4OD4+Pj09PTs7\n"
			+ "Oz4+PioqKjw8PD09PQAAAD09PTw8PD09PTw8PDo6Oj09PT09PT4+Pjc3Nz09PTMzMzw8PD09PT8/\n"
			+ "Pzw8PD09PSONTwIAAADPdFJOUwAt+Jzdt/gf0mN+kRwZpDrlv9q0hqztCQv1oXsEJPU64i/XaIMN\n"
			+ "/dexXeoOLN+DFDfEngJSZfLFzBHneCmTpjQQbfomB9SuZYgZ7xPcR/eIWjF1CT+qyaPkvk9iff+r\n"
			+ "0R6r7DnGVylyBZBqjauFGzz/2bNBGHIm/LONb/zWsILplSONiqg+6cNBnQFRCrAd8TYrDBpRdwi4\n"
			+ "+T7mDcAobH8zwNu1Ru7IGMiiD+Np9sISl49D0J+9Lf6EOJcGjPMD4LpLZlt5+80X6BRu1ThIrzv6\n"
			+ "lkAAAAAJcEhZcwAAIdUAACHVAQSctJ0AAA+ZSURBVHhe7Z2Jo6bVHMcfKluWDKZsZQ2VJGuKNMoa\n"
			+ "ZZ9Khoiy5ESyL02EESqkDI0UKkYqDN3Kmhrkb/L7fn/f8zzn2c997nvnfafeT/c957ee8/ud8977\n"
			+ "3mXurTiTxCkHhWrKQaGaSIhTMKLwIArFPnRFPANhDKSSPOSiJJQBN97KSNdhYYbKiRXBqQgISLOH\n"
			+ "L/2Uvgy3K4MWJlIArYzo4MKNDJvk9B5iVszgdhBIFLAHQtOMEZKMTFoZqplQZD2SAfpmBifg/bJL\n"
			+ "9SxLcbINl3VkjKFQTTkoVFMOCtVEvMfyOn7n1yBjimfQTYcNcZZQuoQy8MYgSsaFUeCuSVWw0QyP\n"
			+ "S5dxRahR6MwglCzD53IJ0sww5OnLEExSlnvCFdqMxZQCQz28yhihysilJyOp2QuqYOMsCZP8NtiD\n"
			+ "/3l8NGBUqKYcPNRpajNC65H+LdjNAG03LQNZI1vg0ERpiBa8AshiI+VO0i2USmQSpa47qwxIktRH\n"
			+ "fYvawHQT7INWtQwNcSPq1EjXXSgsokhSmuyRbEGPPUK4887SBCvI2qI2ACQOdiGNyFCiLTDVtqpH\n"
			+ "hnBczhYucEzI2+LfMDhuqLsBtogRcTWfEqW2xZqIq/kkZbZg0UhTI6HYjm7ROZRipwt+BuFgHfYu\n"
			+ "m90GPRQ/9ukb0LUe6dwCuRi1sgtci7qPRfEFGU1jSZSuCuH8nC3WjNYj67PDA2oLe1+uwGWO8U0M\n"
			+ "1z6cshYkeVucHp9KwE14Kgk38EnmQw+DW1jmWfUVMUkvt7iRI+VO0i2UCmRRZrVceJxmTsBE5STG\n"
			+ "GiNbOJX+IZeTgL6FK2pbbMSAg1Ja3Ku1YmVgCKtKguqMb2GP+oqnNQ0YgK8WcUVhkdYWxS7mcwnq\n"
			+ "FLhFaUEs1bwtKmQpt5BOF7e4s3rtnu0W1GoHxS1KuKro3qLroLaNb3FWWRdXFZ1bkNq73i5PHd2C\n"
			+ "c2IjcYvWTrUttH6SbeKst7A3ES0lbqgdVI3MLZI1ZWku1LoLM2Gq7kLTjEgW3aNbzBYt6ov7OGu0\n"
			+ "qC/uYx1eZbzO5F5NKq2ai/3tUYaUVq4q6krFF/AMirkmMJvPFor4fBHzwcV51GA9CuHya0HSt4V2\n"
			+ "sGgu/A7k4WHyqVwRS8GNLSQjsLjahoeNb4FU5VCx/3aFL/lKGM6mCHfwLky+ihbZ87pYG1qQ7IEt\n"
			+ "UoZdC4YKazHsWjBUWIth14KhwloMu7qxd730dSvhXnv3G4XvuiNYyH8oPC0NVmEthl3d9DeB+rAn\n"
			+ "5wT3OtJpr9D3tsQrzSIRTomrQC20mrikxJbdKPGSS+SN+J5nO1AoyFkUb4XpcEgQEupNmKEZYMiZ\n"
			+ "g1poNaGVmshbcrxm0Pab4UfFrZWxawVZMdSRNwe10NUEPqV2SU+nkZW7d06tXRG3wriaijtQCxOa\n"
			+ "wN6y2GQhUash42mcOiJgcqsk4d5M1MKEJlZWVvClCEQPsZHQ65SGqgniXvBVU2qGChXWInV5ZB+2\n"
			+ "8PjTaaSJj1eG3ibs8ySt656IGVRni9SFFfrRWk3kFe0maC4xXcbepxPoti5KE4aM403EL+uEmVVn\n"
			+ "i9TF/F5sndbTacuWLS5E/MtzHvc6NDGAWohNSBnoyVZUEy18v/8qBLIcFTJmNSFVhiFU88ya+BXH\n"
			+ "GvIS6rTWkNehPq8mzPNUn+q416FOaw15HepzezrNCNbcvgkV1lWppPwm5oYKy2higVGdyybmjuo8\n"
			+ "88x3Ein1JtxV4okl9q6FN4i7aSgJ57i5we7dMNdjfZGEUOw+yLPNvm9jmcY+VaUNhl0pvkEobkAn\n"
			+ "KOYVmGnjxw5TLocZNhvCkVTs7Z9u/DViGc9sBnE4r7RSf5GZwnnhh/RrwbCZggprYcmSWnDlinBv\n"
			+ "sjmk8ASqMJhyMUTt+WE6ymgGFYcy4Bn2mYmbodGtJsJt1GRnlqmbow2aCmthTkktPHWRUGEthl0L\n"
			+ "hgprMuBaNrE+qLAmA65lE+uDCmsy4Fo2sT6osCYDrt4m/AV6OjnJYaeE+FJJVFiTAdeUJrK6yzmE\n"
			+ "MsSEF7pkqLAmA64JTUQP5hQ6I26gPUFOUVkOSH0qrMmAa0ITd8mFKcW9DnR8ltRAXpEYTDxQYj4/\n"
			+ "UAuTnk4/cx/GFHlB1DknuFfgMCQiUNIq6G1CP1Thz1iCRENecTD35A9WDFM4y2kgl0VRSKA3IlsT\n"
			+ "eTPobUIrNZE3EsJHJBktdyujvQCAlaF15M1gjU3UPoC23bSE26V1RRhcFkMDuTNYaxMpbTcMb0zM\n"
			+ "nQuMLTvOUBOl0JK66XanWV0R8A8uO84amoDaNEhKqMV0RMBPqwsl7s1jNk34HLUUhGz3uRxrICD6\n"
			+ "Utybxzo3UYb0RbyKEfKluDuPNTSxsrISDT7DD2gile6T62lEEtJChTWpuRjYS7lytUd7t2jwGX5A\n"
			+ "E0h0n1xPImBq+IRZVGcTZElclCYMN7inxCyqswlSJGY00YW8Ihp8brk3IcONPtl4J4ClovSlmEV1\n"
			+ "NkGKxD3RhFmukbEvAnRbF6eJYm9pAm+9JeY3YWOKWVRnE6RIzGiiFFpSBAbY3NFyGwvXxJbWD+Ph\n"
			+ "g9dDfKwz3yZKtGIn3M7ceHSXuKomXDW64xLUgprofcUusQV7V4QPXg/xsc7e0oTP5Vhn8ZuAKxT3\n"
			+ "cUqRG7CJN7s5RW7iampsBLRRzbNqophhEynu6kM1z6gJG/fyJvzbBONNjOAhzKxwVx+qeSZNzAbf\n"
			+ "IN3GZRWm0iS7JjG7ifmhwpZNzB0VNt7EIqM6l03MHdW5bGLuqM41NHFxCEf7byVvaLzW7ep+8XNj\n"
			+ "3fX6EN4vkVhmGdB6DW0tqzr1z8skN5qgq4J5Fbai7Ygmjqn/i7C/hPR3Uyp2F1eaufEvz/hWYXXu\n"
			+ "VrFNF//pWh3V2WTA1bgY7LT9nLDR5nOtmcfgRLW7783JhrAfmoWgkZ4QDlXM9hNhvDvsgoqAR/gV\n"
			+ "4IFbvVuJh2B4Nlx47MSgwpogT2ILLlqCRTh6E9uwlXZmEXyz/45gExvCbTbiJmD8Mz3JIkdCvwL/\n"
			+ "Bo0eWW2+wnX6D3TnXeFCTPbfzJrYaIuhCROL21k9zWaBAlVNIEBN0MNQjw87aAvhXTDAByscZAN0\n"
			+ "2T0JAowqrAlSJbaAr+ICXzltIhQX+SauQCzC2/BvBetNwAPBBzPsKD4IjbVBL11focgFS+f36TXL\n"
			+ "yWtvAsvakrUmeDz0/LV4CN32+AkGb0JlhPA/espFdlCIWvE6+qjQ7urNmKGe4DYzqrAmWFhiC/gW\n"
			+ "CxXWZMC1bGJ9UGFNBlx7TxN9TMtawL4XDp1ULtOylhcxjk4ql2lZy4sYRyeVy7Ss5UWMo5PKZVrW\n"
			+ "8iLG0UnlMi1r9Rdhn1yDdf4F0Dnxdnw10UQnlcu0rD11ET3fHZoANv+c5DXAJvhNkEj8vfoWOqlc\n"
			+ "pmXtmYs42nOklWv0orAOFBAeLH0qx/ky0hw3tTfXSeUyLWvPXIRyyial9aKwFufI7wGS+6j/oaAG\n"
			+ "HrKvNOHG1u7vXR05WS/T6ScoLR9Vu8oPTcrKO8K+i5A3+qX0MXQRCpFW0mOePdUPJkvkyUfFrvbF\n"
			+ "+pPKCz81RWIvnlKHv2lDZFjDRShitA6inJmy6otQLZkoqQeP6foVI/cMpuuV1HimLA3klTZM+bLs\n"
			+ "8whKmilzvQispr8J1CAj/R7F/NLkN7ipjvzSBnlLGSthGGXNlDlfRB856dsQ8XhIjG191kRrVgmK\n"
			+ "ROwtOShtpuzFF2FRHHkhxoupVcgsbQAFGjLMg4kXUfuA4qb6i7Vs0hrI6chWZ8jXQKHt2D57E8WB\n"
			+ "lqGNh8yeBboIV30Vl3O6VqRCbz2VUK45euFfJ424SUo3HjJ79vKLUFwZib9+FzUXR9ZQkOiyNfCQ\n"
			+ "2bPYF1FCYws5gSyrvghFxSkTnVQuvVlyTMIrXttFOM1vqbmafxFyObJ1XEQFrS3cw4CeiDY6x1x6\n"
			+ "s+SYhFc8/4uQIyLrhIsowlUYkgiXe2CEzjEX5txv3yPkETJOuQiSRrjcAyN0jrkwZ30uIhcldZJx\n"
			+ "EZT7YAR+8QTItvrXCJHGutwDI3SOuTDn/nsRK/Cvx0WMo3PMpTdLjkl4xbkoqZO1XgR5oF/EbF8j\n"
			+ "PM7V+V9E4687N2CIzjEX5iz+RfgYU5YXMR2VWLuIDHQRzmHLi1g7KnFNF3HIol0ExRo0Zy7XiU4/\n"
			+ "QQ6w6m9xdOAVrvoilAYur/TlRZTIk49XuNqLeK7SQrjZDa5MvoiOX8Vvo6w2ifsBdhFblMUfWbf/\n"
			+ "WEALz2qxbhfRB0OmofNNkAPM6yKUo/eG5UXM8UMTUr4reXkR83yxvuOJEtZC48V6MskqGa8Rv21B\n"
			+ "syNLghw63wQ5wCwu4hPOQVL3SpJTzkAnlSAHkCVhzAFmcREPPHRSCXIAWRLGHGB5EVPQSSXIAWRJ\n"
			+ "GHMsmYrOMUEOIEvCmGPJVHSOCXIAWRLGHEumonNMkAPIkjDmWDIVnWOCHECWhDHHkqnoHBPkALIk\n"
			+ "jDmWTEXnmCAHkCVhzDGJ7/iXPuE5+CIo/qCOf9yoH6Vkfr2kwJe4jLGbr/mizV97qzAfhv0hb6IF\n"
			+ "eNJowZK60TnmMi1r+JreHcJNNv0phEdZubWfmPaitkJ4LNUsrhw5iqJ4bQiX2vTREA53Q4vqOJOD\n"
			+ "LYuhNhGdVC7TsoYvIn2umEyK4lwM0uC38ekugV/Aeo3LEI1SwrwfNb5fwaIHJpqlUAM/xzpUXDBC\n"
			+ "2FX5kxTazsOfiaPsocbfEtmDXhPCUSfFVD7iL6wWxW1R8NkEnVQuvtu6XgTH6iJKY/G+ff7ggmNW\n"
			+ "Os4oY1w94+smJBeh2PI9AiN1G++BdB2sxM2Oy9cpUIv7aBdRjy0eappcHnVK9GO6qfSEcAsq3G6C\n"
			+ "fPYIFyJQJ5ULUlaflXURjwzhepPxoQmG5kWE8Gl3kBBO94mt7EtM0v9CKucimPKeojjGZHfwR96c\n"
			+ "QzjBHjsoVYt/0XUM9Ysos+rFRKu9G9iHXmW+gMary7CiuME85tJJ5cJlZnwRqHGf4qWqtOciHl2p\n"
			+ "wKR7i1uj++8Y3P2PMo5DehF3+Q+yId6B4Vobvg1hEwZicd8qvqd0XIRNxxcXQLdLOrw4TK7mRYQn\n"
			+ "8Zvn+COH4cTiNx7k/t+bAIkjho+5cAmGZ9njAAhPXoiLKIqLQjjpSghbt36ZY1GcjmErBo0nhRtN\n"
			+ "ehOiwAesqftcXPkMj8b4fAgXYN4Wwqu5yrFM1Qp2E+f74kVxfQgvx1x8KoRjKThWyYYVCFu3Xk/D\n"
			+ "pbvCTryC4+cUm32hrVvxWn5KCJ+l3XheCJv/6OIRITwfs29ZCZpOCZvYaLE5hKsp/AtFLcZ7xBJD\n"
			+ "J5XLtKzlRYyjk8plWtbyIsbRSeUyLWt5ESMUxf8B2dIK35FIyYkAAAAASUVORK5CYII=";

	// 导出功能
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/download/{compyId}", method = RequestMethod.GET)
	public BaseOutData getDownload(HttpServletResponse response, @PathVariable String compyId) throws Exception {
		BaseOutData outData = new BaseOutData();
		String templateFlg = "0";
		Map<String, Object> out = new HashMap();
		Calendar calendar = Calendar.getInstance();
		// 报告时间
		String reportDt = DateUtils.ISO_DATE_FORMAT.format(calendar.getTime());
		reportDt = handleTime(reportDt) + "日";
		out.put("reportCreateTD", reportDt);
		out.put("createTime", DateUtils.dateToString(new Date()));

		// 常亮图片设置
		out.put("Jggg", Jggg);
		out.put("CYII", CYII);
		out.put("QmCC", QmCC);

		// 关系图谱 TODO

		// 工商信息
		BaseOutData baseInfo = companyBasicInfoController.getBasicInfo(compyId);
		Map base = null;
		if (baseInfo.getData() != null) {
			base = (Map) JSON.parse(baseInfo.getData().get("result").toString());

		}

		out.put("base", base);
		// 管理层
		BaseOutData manageLevelInfo = companyBasicInfoController.getManageLevel(compyId);
		List<Map> manageLevelList = null;
		if (manageLevelInfo.getData() != null && manageLevelInfo.getData().get("result") != null) {
			manageLevelList = (List<Map>) JSON.parseArray(manageLevelInfo.getData().get("result").toString(),
					Map.class);
		}

		out.put("manageLevelList", CollectionUtils.isEmpty(manageLevelList) ? null : manageLevelList);
		// 报告编号
		/*
		 * String reportCd = "CSCS" + String.format("%08d", Integer.parseInt(compyId)) +
		 * "RP"; itemBase.put("reportCd", reportCd);
		 */

		// 分支机构
		BaseOutData branchInfo = companyBasicInfoController.getBranch(compyId);
		List<Map> branchList = null;
		if (branchInfo.getData() != null && branchInfo.getData().get("result") != null) {
			branchList = (List<Map>) JSON.parseArray(branchInfo.getData().get("result").toString(), Map.class);
		}

		out.put("branchList", CollectionUtils.isEmpty(branchList) ? null : branchList);

		// 变更记录

		BaseOutData compyChangeInfo = companyBasicInfoController.getCompyChange(compyId);
		List<Map> compyChangeList = null;
		if (compyChangeInfo.getData() != null && compyChangeInfo.getData().get("result") != null) {
			compyChangeList = (List<Map>) JSON.parseArray(compyChangeInfo.getData().get("result").toString(),
					Map.class);
		}

		out.put("compyChangeList", CollectionUtils.isEmpty(compyChangeList) ? null : compyChangeList);

		// 股东信息-发起人股东

		BaseOutData sharehdInfo = companyBasicInfoController.getSharehd(compyId);
		List<Map> sharehdList = null;
		if (sharehdInfo.getData() != null && sharehdInfo.getData().get("result") != null) {
			sharehdList = (List<Map>) JSON.parseArray(sharehdInfo.getData().get("result").toString(), Map.class);
		}

		out.put("sharehdList", CollectionUtils.isEmpty(sharehdList) ? null : sharehdList);

		// 十大股东
		BaseOutData top10sharehdInfo = companyBasicInfoController.getTop10sharehd(compyId);
		List<Map> top10sharehdList = null;
		if (top10sharehdInfo.getData() != null && top10sharehdInfo.getData().get("result") != null) {
			top10sharehdList = (List<Map>) JSON.parseArray(top10sharehdInfo.getData().get("result").toString(),
					Map.class);
		}

//		String curYear = DateUtils.getYear();
		// String curYear = "2015";
//		String monthAndDay = getQuarterReportDate();
//		String quarterReportDate = curYear + "-" + monthAndDay;
//		String quarterReportTransShow = curYear + "年" + getQuarterReportTransShow(monthAndDay, false);
//		String earliestDateStr = curYear + "-" + getQuarterReportTransShow(monthAndDay, true);
//		out.put("quarterReportTransShow", quarterReportTransShow);
		if (!CollectionUtils.isEmpty(top10sharehdList)) {
			//取最新报告，是否是季度报
			String quarter = null;
			//找出最近一期季报
			int lastestIndex = 0;
			List<Map> quarterInfoList = new ArrayList<>();
			for (int i = 0;i<top10sharehdList.size();i++) {
				quarter = getQuarterReportTransShow(((String)top10sharehdList.get(i).get("noticeDt")).substring(5));
				if(!StringUtil.isEmpty(quarter)){
					//最近季报
					lastestIndex = i;
					quarterInfoList.addAll((List<Map>) top10sharehdList.get(i).get("sharehdList"));
					out.put("quarterReportTransShow", ((String)top10sharehdList.get(i).get("noticeDt")).substring(0,4) + "年" + quarter);
					out.put("top10sharehd_quarterInfoList", CollectionUtils.isEmpty(quarterInfoList) ? null : quarterInfoList);
					break;
				}
			}

			if(lastestIndex==0){
				//无临时公告
				out.put("top10sharehd_tempAnnInfoList",
						null);
			}else{
				List<Map> tempReportInfoList = new ArrayList<>();
				for(int j=0;j<lastestIndex;j++){
					top10sharehdList.get(j).put("tempAnnounceTime", handleTime((String) top10sharehdList.get(j).get("noticeDt")));
					tempReportInfoList.add(top10sharehdList.get(j));
				}
				out.put("top10sharehd_tempAnnInfoList",
						CollectionUtils.isEmpty(tempReportInfoList) ? null : tempReportInfoList);

			}


//			long quarterTime = getTime(quarterReportDate);
//			long earliestTime = getTime(earliestDateStr);
//			for (Map map : top10sharehdList) {
//				if (quarterReportDate.equals((String) map.get("noticeDt"))) {
//					quarterInfoList.addAll((List<Map>) map.get("sharehdList"));
//				} else if (getTime((String) map.get("noticeDt")) >= earliestTime
//						&& getTime((String) map.get("noticeDt")) < quarterTime) {
//					map.put("tempAnnounceTime", handleTime((String) map.get("noticeDt")));
//					tempReportInfoList.add(map);
//				}
//
//			}
//
//			out.put("top10sharehd_tempAnnInfoList",
//					CollectionUtils.isEmpty(tempReportInfoList) ? null : tempReportInfoList);
//			out.put("top10sharehd_quarterInfoList", CollectionUtils.isEmpty(quarterInfoList) ? null : quarterInfoList);
			// out.put("sharehdList",
			// CollectionUtils.isEmpty(sharehdList)?null:sharehdList);
		}

		// 疑似/实际控制人
		BaseOutData actualControllerInfo = getSuspectControllers(compyId);
		List<Map> actualControllerList = null;
		if (actualControllerInfo.getData() != null && actualControllerInfo.getData().get("result") != null) {
			try {
				actualControllerList = handleActualController(
						(Map) JSON.parse(actualControllerInfo.getData().get("result").toString()));
			} catch (Exception e) {
				actualControllerList = null;
			}
		}
		out.put("actualControllerList", CollectionUtils.isEmpty(actualControllerList) ? null : actualControllerList);

		// 对外投资-对外投资企业
		BaseOutData investmentInfo = companyBasicInfoController.getInvestment(compyId);
		List<Map> investmentList = null;
		if (investmentInfo.getData() != null && investmentInfo.getData().get("result") != null) {
			investmentList = (List<Map>) JSON.parseArray(investmentInfo.getData().get("result").toString(), Map.class);
		}

		out.put("investmentList", CollectionUtils.isEmpty(investmentList) ? null : investmentList);

		// 参控企业
		BaseOutData holdingInfo = companyBasicInfoController.getHolding(compyId);
		List<Map> holdingList = null;
		if (holdingInfo.getData() != null && holdingInfo.getData().get("result") != null) {
			holdingList = (List<Map>) JSON.parseArray(holdingInfo.getData().get("result").toString(), Map.class);
		}

		out.put("holdingList", CollectionUtils.isEmpty(holdingList) ? null : holdingList);

		String companyNm = (String) base.get("compyName");
		// 受益所有人
		JSONObject innerOut = getInfoFromUrl(companyNm, false);
		if (!innerOut.has("code") || innerOut.getInt("code") != 200) {
			out.put("beneficialownerList", null);
		} else {
			try {

				if (innerOut.getJSONObject("result") != null && innerOut.getJSONObject("result").get("nodes") != null) {
					List<Map> nodesList = (List<Map>) JSON
							.parseArray(innerOut.getJSONObject("result").get("nodes").toString(), Map.class);
					List<Map> linksList = (List<Map>) JSON
							.parseArray(innerOut.getJSONObject("result").get("links").toString(), Map.class);
					out.put("beneficialownerList", handleBeneficialowner(nodesList, linksList, companyNm));
				}
			} catch (Exception e) {
				out.put("beneficialownerList", null);
			}
		}

		// 主体评级
		BaseOutData compyCreditInfo = companyCreditController.getCompyCredit(compyId);
		List<Map> compyCreditList = null;
		if (compyCreditInfo.getData() != null && compyCreditInfo.getData().get("result") != null) {
			compyCreditList = (List<Map>) compyCreditInfo.getData().get("result");
		}

		out.put("compyCreditList", CollectionUtils.isEmpty(compyCreditList) ? null : compyCreditList);

		// 信用评估 TODO

		// 财务情况
		// 判断是否为新三板，发债，上市 公司
		boolean isListOrBond = ("1".equals((String) base.get("islist")) || "1".equals((String) base.get("islist3"))
				|| "1".equals((String) base.get("isbond")));
		if (isListOrBond) {
			// 调用报表接口
			CompanyReportIn inData = new CompanyReportIn();
			inData.setCompanyId(Long.parseLong(compyId));
			inData.setSubjectType(1);// 1：资产负债表 2: 利润表 3: 现金流量表
			inData.setRptTimetypeCd("1,2,3,4,5");// 报告期，1：年报 2：中报 3：一季报 4：三季报 5：最新
			inData.setRptDt("3");// 时间范围，0：全部，1：今年，2：去年，3：3年，5：5年，10：10年
			inData.setIsPublicRpt("0,1");// 上市前/上市后， 0：上市前， 1：上市后
			inData.setCombineTypeCd("2");// 报表类型， 1：母公司， 2：合并， 3：母公司调整， 4：合并调整
			inData.setQuarterly("0");// 合计/单季 0：合计，1：单季
			CompanyReport balanceSheet = null;
			CompanyReport incomeSheet = null;
			CompanyReport cashflowSheet = null;

			try {
				balanceSheet = companyReportController.getCompyCashflow(inData);
				// 资产负债表
				handleSheet(balanceSheet, out);

				// 利润表
				inData.setSubjectType(2);// 1：资产负债表 2: 利润表 3: 现金流量表
				incomeSheet = companyReportController.getCompyCashflow(inData);

				// 现金流量表
				inData.setSubjectType(3);// 1：资产负债表 2: 利润表 3: 现金流量表
				cashflowSheet = companyReportController.getCompyCashflow(inData);
			} catch (Exception e) {
				logger.error("报表接口调用报错" + e.getMessage());
			}

			if (out.get("balanceSheet") != null) {
				out.put("incomeSheet",
						(incomeSheet != null && !CollectionUtils.isEmpty(incomeSheet.getCompyReport()))
								? incomeSheet.getCompyReport()
								: null);
				out.put("cashflowSheet",
						(cashflowSheet != null && !CollectionUtils.isEmpty(cashflowSheet.getCompyReport()))
								? cashflowSheet.getCompyReport()
								: null);
			}

		} else {
			// 年报情况
			BaseOutData yearReportInfo = companyCreditController.getYearReport(compyId);
			List<Map> yearReportList = null;
			if (yearReportInfo.getData() != null && yearReportInfo.getData().get("result") != null) {
				yearReportList = (List<Map>) yearReportInfo.getData().get("result");
			}

			// 取最新年度报告
			out.put("yearReport", CollectionUtils.isEmpty(yearReportList) ? null : yearReportList.get(2));
		}

		// 经营情况
		BaseOutData operationInfo = companyCreditController.getOperation(compyId);
		List<Map> operationList = null;
		if (operationInfo.getData() != null && operationInfo.getData().get("result") != null) {
			operationList = (List<Map>) JSON.parseArray(operationInfo.getData().get("result").toString(), Map.class);
		}

		out.put("operationList", CollectionUtils.isEmpty(operationList) ? null : operationList);

		// 股权质押
		BaseOutData pledgeInfo = companyCreditController.getPledge(compyId);
		List<Map> pledgeList = null;
		if (pledgeInfo.getData() != null && pledgeInfo.getData().get("result") != null) {
			pledgeList = (List<Map>) pledgeInfo.getData().get("result");
		}

		out.put("pledgeList", CollectionUtils.isEmpty(pledgeList) ? null : pledgeList);

		// 债务及偿还情况-存续期债券
		BaseOutData expectInfo = companyCreditController.getExpect(compyId);
		List<Map> expectList = null;
		if (expectInfo.getData() != null && expectInfo.getData().get("result") != null) {
			expectList = (List<Map>) expectInfo.getData().get("result");
		}

		out.put("expectList", CollectionUtils.isEmpty(expectList) ? null : expectList);

		// 银行授信
		BaseOutData bankCreditInfo = companyCreditController.getCredit(compyId);
		List<Map> bankCreditList = null;
		if (bankCreditInfo.getData() != null && bankCreditInfo.getData().get("result") != null) {
			bankCreditList = (List<Map>) bankCreditInfo.getData().get("result");
		}

		out.put("bankCreditList", CollectionUtils.isEmpty(bankCreditList) ? null : bankCreditList);

		// 担保情况
		BaseOutData guaranteeInfo = companyCreditController.getGuarantee(compyId);
		List<Map> guaranteeList = null;
		if (guaranteeInfo.getData() != null && guaranteeInfo.getData().get("result") != null) {
			guaranteeList = (List<Map>) guaranteeInfo.getData().get("result");
		}

		out.put("guaranteeList", CollectionUtils.isEmpty(guaranteeList) ? null : guaranteeList);

		// 裁判文书
		BaseOutData documentInfo = companyRiskController.getDocument(compyId);
		List<Map> documentList = null;
		List<Map> documentTempList = null;
		if (documentInfo.getData() != null && documentInfo.getData().get("result") != null) {
			documentTempList = (List<Map>) documentInfo.getData().get("result");
			if (!CollectionUtils.isEmpty(documentTempList)) {
				documentList = new ArrayList<>();
				for (Map map : documentTempList) {
					documentList.addAll((List) map.get((String) map.get("case_type")));
				}
				Collections.sort(documentList, new CommonForCreditReportComparator("judgeDate", "desc"));
			}
		}

		out.put("documentList", CollectionUtils.isEmpty(documentList) ? null : documentList);

		// 法院公告
		BaseOutData announcementInfo = companyRiskController.getAnnouncement(compyId);
		List<Map> announcementList = null;
		if (announcementInfo.getData() != null && announcementInfo.getData().get("result") != null) {
			announcementList = (List<Map>) announcementInfo.getData().get("result");
		}

		out.put("announcementList", CollectionUtils.isEmpty(announcementList) ? null : announcementList);

		// 被执行人
		BaseOutData litigantInfo = companyRiskController.getLitigant(compyId);
		List<Map> litigantList = null;
		if (litigantInfo.getData() != null && litigantInfo.getData().get("result") != null) {
			litigantList = (List<Map>) litigantInfo.getData().get("result");
		}

		out.put("litigantList", CollectionUtils.isEmpty(litigantList) ? null : litigantList);

		// 失信人
		BaseOutData ishonestInfo = companyRiskController.getIshonest(compyId);
		List<Map> ishonestList = null;
		if (ishonestInfo.getData() != null && ishonestInfo.getData().get("result") != null) {
			ishonestList = (List<Map>) ishonestInfo.getData().get("result");
		}

		out.put("ishonestList", CollectionUtils.isEmpty(ishonestList) ? null : ishonestList);

		// 债券违约
		BaseOutData bondViolationInfo = companyRiskController.getBondViolation(compyId);
		List<Map> bondViolationList = null;
		if (bondViolationInfo.getData() != null && bondViolationInfo.getData().get("result") != null) {
			bondViolationList = (List<Map>) bondViolationInfo.getData().get("result");
		}

		out.put("bondViolationList", CollectionUtils.isEmpty(bondViolationList) ? null : bondViolationList);

		// 主体评级下调
		BaseOutData creditChangeInfo = companyRiskController.getCreditchange(compyId);
		List<Map> creditChangeList = null;
		if (creditChangeInfo.getData() != null && creditChangeInfo.getData().get("result") != null) {
			creditChangeList = (List<Map>) creditChangeInfo.getData().get("result");
		}

		out.put("creditChangeList", CollectionUtils.isEmpty(creditChangeList) ? null : creditChangeList);

		// 债券评级下调
		BaseOutData bondCreditChangeInfo = companyRiskController.getBondCreditchange(compyId);
		List<Map> bondCreditChangeList = null;
		if (bondCreditChangeInfo.getData() != null && bondCreditChangeInfo.getData().get("result") != null) {
			bondCreditChangeList = (List<Map>) bondCreditChangeInfo.getData().get("result");
		}

		out.put("bondCreditChangeList", CollectionUtils.isEmpty(bondCreditChangeList) ? null : bondCreditChangeList);

		// 股权冻结
		BaseOutData frozenInfo = companyRiskController.getFrozen(compyId);
		List<Map> frozenList = null;
		if (frozenInfo.getData() != null && frozenInfo.getData().get("result") != null) {
			frozenList = (List<Map>) frozenInfo.getData().get("result");
		}

		out.put("frozenList", CollectionUtils.isEmpty(frozenList) ? null : frozenList);

		// 监管处罚-违规处理 暂无接口
		BaseOutData punishInfo = companyRiskController.getPunish(compyId);
		List<Map> punishList = null;
		if (punishInfo.getData() != null && punishInfo.getData().get("result") != null) {
			punishList = (List<Map>) punishInfo.getData().get("result");
		}

		out.put("punishList", CollectionUtils.isEmpty(punishList) ? null : punishList);

		// 监管处罚-诉讼仲裁 暂无接口
		BaseOutData litigationInfo = companyRiskController.getLitigation(compyId);
		List<Map> litigationList = null;
		if (litigationInfo.getData() != null && litigationInfo.getData().get("result") != null) {
			litigationList = (List<Map>) litigationInfo.getData().get("result");
		}

		out.put("litigationList", CollectionUtils.isEmpty(litigationList) ? null : litigationList);

		// 经营异常
		BaseOutData operexceptInfo = companyRiskController.getOperexcept(compyId);
		List<Map> operexceptList = null;
		if (operexceptInfo.getData() != null && operexceptInfo.getData().get("result") != null) {
			operexceptList = (List<Map>) operexceptInfo.getData().get("result");
		}

		out.put("operexceptList", CollectionUtils.isEmpty(operexceptList) ? null : operexceptList);

		// 行政处罚
		BaseOutData penaltyInfo = companyRiskController.getAdminpenalty(compyId);
		List<Map> penaltyList = null;
		if (penaltyInfo.getData() != null && penaltyInfo.getData().get("result") != null) {
			penaltyList = (List<Map>) penaltyInfo.getData().get("result");
		}

		out.put("penaltyList", CollectionUtils.isEmpty(penaltyList) ? null : penaltyList);

		// 严重违法
		BaseOutData seriviolatInfo = companyRiskController.getSeriviolat(compyId);
		List<Map> seriviolatList = null;
		if (seriviolatInfo.getData() != null && seriviolatInfo.getData().get("result") != null) {
			seriviolatList = (List<Map>) seriviolatInfo.getData().get("result");
		}

		out.put("seriviolatList", CollectionUtils.isEmpty(seriviolatList) ? null : seriviolatList);

		// 股权出质
		BaseOutData pledgeRiskInfo = companyRiskController.getPledgeRisk(compyId);
		List<Map> PledgeRiskList = null;
		if (pledgeRiskInfo.getData() != null && pledgeRiskInfo.getData().get("result") != null) {
			PledgeRiskList = (List<Map>) pledgeRiskInfo.getData().get("result");
		}

		out.put("PledgeRiskList", CollectionUtils.isEmpty(PledgeRiskList) ? null : PledgeRiskList);

		// 动产抵押
		BaseOutData mortgageInfo = companyRiskController.getMortgage(compyId);
		List<Map> mortgageList = null;
		if (mortgageInfo.getData() != null && mortgageInfo.getData().get("result") != null) {
			mortgageList = (List<Map>) mortgageInfo.getData().get("result");
		}

		out.put("mortgageList", CollectionUtils.isEmpty(mortgageList) ? null : mortgageList);

		// 私募备案-管理人基本信息

		BaseOutData pfundBaseInfo = companyPrivateFundController.getBasicInfo(compyId);
		Map pfundBase = null;
		if (pfundBaseInfo.getData() != null && pfundBaseInfo.getData().get("result") != null) {
			pfundBase = (Map) JSON.parse(pfundBaseInfo.getData().get("result").toString());

		}
		out.put("pfundBase", pfundBase);

		// 执行事务合伙人委托代表
		BaseOutData legrepresentInfo = companyPrivateFundController.getLegrepresent(compyId);
		Map legrepresent = null;
		if (legrepresentInfo.getData() != null && legrepresentInfo.getData().get("result") != null) {
			legrepresent = (Map) JSON.parse(legrepresentInfo.getData().get("result").toString());

		}
		out.put("legrepresent", legrepresent);

		// 高管信息
		BaseOutData executivesInfo = companyPrivateFundController.getExecutivesList(compyId);
		List<Map> executivesList = null;
		if (executivesInfo.getData() != null && executivesInfo.getData().get("result") != null) {
			executivesList = (List<Map>) JSON.parseArray(executivesInfo.getData().get("result").toString(), Map.class);

		}
		out.put("executivesList", executivesList);

		// 高管信息
		BaseOutData pfundProductInfo = companyPrivateFundController.getProductList(compyId);
		List<Map> pfundProductList = null;
		if (pfundProductInfo.getData() != null && pfundProductInfo.getData().get("result") != null) {
			pfundProductList = (List<Map>) JSON.parseArray(pfundProductInfo.getData().get("result").toString(),
					Map.class);

		}
		out.put("pfundProductList", pfundProductList);

		exportMillCertificateWord(response, out, templateFlg);
		outData.setCode("0");
		return outData;
	}

	@SuppressWarnings("unchecked")
	private void handleSheet(CompanyReport balanceSheet, Map<String, Object> out) {

		if (!CollectionUtils.isEmpty(balanceSheet.getCompyReport())) {
			List<Object> reportArry = balanceSheet.getCompyReport();
			int quarters = ((List<Object>) reportArry.get(0)).size() - 8;
			if (quarters > 4) {
				quarters = 4;
			}

			if (quarters <= 0) {
				return;
			}

			List<String> reportDtList = new ArrayList<>();
			List<String> reportQuarterList = new ArrayList<>();
			List<String> listStateList = new ArrayList<>();
			List<String> companyTypeList = new ArrayList<>();
			List<String> dataSourceList = new ArrayList<>();
			for (int i = 0; i < quarters; i++) {
				reportDtList.add(reportDtHandle(((List<Object>) reportArry.get(0)).get(8 + i)));
				reportQuarterList.add(reportQuarterHandle(((List<Object>) reportArry.get(1)).get(8 + i)));
				listStateList.add(listStateHandle(((List<Object>) reportArry.get(2)).get(8 + i)));
				companyTypeList.add(companyTypeHandle(((List<Object>) reportArry.get(3)).get(8 + i)));
				dataSourceList.add(dataSourceHandle(((List<Object>) reportArry.get(reportArry.size() - 3)).get(8 + i)));
			}
			out.put("quarters", quarters);
			out.put("balanceSheet", balanceSheet.getCompyReport());
			out.put("reportDtList", reportDtList);
			out.put("reportQuarterList", reportQuarterList);
			out.put("listStateList", listStateList);
			out.put("companyTypeList", companyTypeList);
			out.put("dataSourceList", dataSourceList);
		}

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private List<Map> handleBeneficialowner(List<Map> nodesList, List<Map> linksList, String compyName) {
		List<Map> beneficialownerList = null;
		if (!CollectionUtils.isEmpty(nodesList) && !CollectionUtils.isEmpty(linksList)) {
			String currId = null;
			for (Map node : nodesList) {
				if (compyName.equals((String) node.get("name"))) {
					currId = (String) node.get("id");
				}
			}

			if (StringUtil.isEmpty(currId)) {
				return beneficialownerList;
			}

			List<String> pathList = new ArrayList<>();
			Set<String> controllerList = new HashSet<>();
			String controller = "";
			String shareRatio = "";
			List<String> shareRatioList = new ArrayList<>();
			recursionBeneficialowner(nodesList, linksList, currId, compyName, pathList, controllerList, controller,
					shareRatio, shareRatioList);
			beneficialownerList = new ArrayList<>();
			Map beneficialowner = null;
			List<String> singleControllerPathList = null;
			List<String> singleControllerRatioList = null;
			List<String> delIndexArr = null;
			String nodeId = null;
			// 任职类型
			DecimalFormat df = new DecimalFormat("#.00");
			for (String beneficialownerName : controllerList) {
				beneficialowner = new HashMap<>();
				String position_desc = "";
				// 是否同属于一个受益所有人
				singleControllerPathList = new ArrayList<>();
				singleControllerRatioList = new ArrayList<>();
				for (int i = 0; i < pathList.size(); i++) {
					if ((beneficialownerName.trim()).equals((pathList.get(i).split(" →")[0]).trim())) {
						singleControllerPathList.add(pathList.get(i));
						singleControllerRatioList.add(shareRatioList.get(i));
					}
				}

				delIndexArr = new ArrayList<>();
				double shareRat = 0;
				for (int i = 0; i < singleControllerPathList.size(); i++) {
					double singleRat = 1;
					if (singleControllerPathList.get(i).contains("→ noRatio")) {
						// 无效路径,不展示
						delIndexArr.add(singleControllerPathList.get(i));
					} else {
						String[] ratioArr = singleControllerRatioList.get(i).split("%");
						for (String rat : ratioArr) {
							singleRat = singleRat * (Double.parseDouble(rat) / 100);
						}
						shareRat += singleRat;

					}
				}

				if (!CollectionUtils.isEmpty(delIndexArr)) {
					singleControllerPathList.removeAll(delIndexArr);
				}

				beneficialowner.put("beneficialowner", beneficialownerName);
				for (Map node : nodesList) {
					if (beneficialownerName.equals(((String) node.get("name")))) {
						beneficialowner.put("syrPriority",
								((Map<String, Object>) node.get("properties")).get("syrPriority"));
						//兼容相同数据
						if(StringUtil.isEmpty((String)((Map<String, Object>) node.get("properties")).get("SYRtype"))) {
							continue;
						}
						beneficialowner.put("SYRtype", ((Map<String, Object>) node.get("properties")).get("SYRtype"));
						nodeId = (String) node.get("id");
						break;
					}
				}

				// 查询任职类型
				for (Map link : linksList) {
					if (nodeId.equals(((String) link.get("from"))) && !StringUtil
							.isEmpty((String) ((Map<String, Object>) link.get("properties")).get("position_desc"))) {

						position_desc += ((Map<String, Object>) link.get("properties")).get("position_desc") + " ";
					}
				}
				
				beneficialowner.put("positionDesc", position_desc);
				beneficialowner.put("singleBeneficialownerPathList", CollectionUtils.isEmpty(singleControllerPathList)?null:singleControllerPathList);
				beneficialowner.put("shareRatio",
						shareRat == 0 ? "" : (shareRat > 1 ? df.format((shareRat - 1) * 100)  : df.format(shareRat * 100)));
				beneficialownerList.add(beneficialowner);
			}
		}

		return beneficialownerList;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void recursionBeneficialowner(List<Map> nodesList, List<Map> linksList, String currId, String controlPath,
			List<String> pathList, Set<String> controllerList, String controller, String shareRatio,
			List<String> shareRatioList) {
		String compyName = "";
		boolean isNotLast = false;
		String sourceId = null;
		String partPath = null;
		String partRatio = null;
		Map<String, Object> propertiesMap = null;
		String ratio = "noRatio%";
		for (Map map : linksList) {
			if (currId.equals((String) map.get("to"))) {
				isNotLast = true;
				propertiesMap = (Map<String, Object>) map.get("properties");
				if (propertiesMap.get("conprop") != null) {
					ratio = Double.parseDouble(String.valueOf(propertiesMap.get("conprop"))) * 100 + "%";
				} else if (propertiesMap.get("holderrto") != null) {
					ratio = String.valueOf(propertiesMap.get("holderrto")) + "%";
				}
				partPath = ratio + " → " + controlPath;
				partRatio = shareRatio + ratio;
				sourceId = (String) map.get("from");
				for (Map node : nodesList) {
					if (((String) node.get("id")).equals(sourceId)) {
						compyName = (String) node.get("name");
						partPath = compyName + " → " + partPath;
						controller = compyName;
						break;
					}
				}
				// 重新初始化
				propertiesMap = null;
				ratio = "noRatio%";
				recursionBeneficialowner(nodesList, linksList, sourceId, partPath, pathList, controllerList, controller,
						partRatio, shareRatioList);

			}
		}

		if (!isNotLast) {
			// 找到顶层节点
			pathList.add(partPath == null ? controlPath : partPath);
			shareRatioList.add(partRatio == null ? shareRatio : partRatio);
			if (!StringUtil.isEmpty(controller)) {
				controllerList.add(controller);
			}

		}

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private List<Map> handleActualController(Map map) {
		List<Map> actualControllerList = null;
		Map basicInfo = (Map) map.get("BasicInfo");
		List<Map> entityList = (List<Map>) map.get("EntityList");
		List<Map> relationList = (List<Map>) map.get("RelationList");
		if (basicInfo != null && !CollectionUtils.isEmpty(entityList) && !CollectionUtils.isEmpty(relationList)) {
			String currId = (String) basicInfo.get("id");
			String controlPath = (String) basicInfo.get("name");
			List<String> pathList = new ArrayList<>();
			Set<String> controllerList = new HashSet<>();
			String controller = "";
			String shareRatio = "";
			List<String> shareRatioList = new ArrayList<>();
			recursionController(relationList, entityList, currId, controlPath, pathList, controllerList, controller,
					shareRatio, shareRatioList);
			actualControllerList = new ArrayList<>();
			Map actualController = null;
			List<String> singleControllerPathList = null;
			List<String> singleControllerRatioList = null;
			DecimalFormat df = new DecimalFormat("#.00");
			for (String controllerName : controllerList) {
				actualController = new HashMap<>();
				actualController.put("actualController", controllerName);
				// 是否同属于一个实际控制人
				singleControllerPathList = new ArrayList<>();
				singleControllerRatioList = new ArrayList<>();
				for (int i = 0; i < pathList.size(); i++) {
					if ((controllerName.trim()).equals((pathList.get(i).split(" →")[0]).trim())) {
						singleControllerPathList.add(pathList.get(i));
						singleControllerRatioList.add(shareRatioList.get(i));
					}
				}
				double shareRat = 0;
				for (int i = 0; i < singleControllerPathList.size(); i++) {
					double singleRat = 1;
					if (singleControllerPathList.get(i).contains("→ 0.0% →")) {
						shareRatio = "控股";
						break;
					} else {
						if (singleControllerRatioList.get(i).contains("控股")) {
							continue;
						} else {
							String[] ratioArr = singleControllerRatioList.get(i).split("%");
							for (String rat : ratioArr) {
								singleRat = singleRat * (Double.parseDouble(rat) / 100);
							}
							shareRat += singleRat;
						}

					}
				}

				actualController.put("singleControllerPathList", CollectionUtils.isEmpty(singleControllerPathList)?null:singleControllerPathList);
				actualController.put("shareRatio", shareRatio.equals("控股") ? shareRatio
						: (shareRat == 0 ? "控股" : (shareRat > 1 ? df.format((shareRat - 1) * 100) : df.format(shareRat * 100 ))));
				actualControllerList.add(actualController);
			}
		}

		return actualControllerList;
	}

	@SuppressWarnings("rawtypes")
	private void recursionController(List<Map> relationList, List<Map> entityList, String currId, String controlPath,
			List<String> pathList, Set<String> controllerList, String controller, String shareRatio,
			List<String> shareRatioList) {
		String compyName = "";
		boolean isNotLast = false;
		String sourceId = null;
		String partPath = null;
		String partRatio = null;
		for (Map map : relationList) {
			if (currId.equals((String) map.get("target_id"))) {
				isNotLast = true;
				if (map.get("nexus") instanceof String) {
					partPath = String.valueOf(map.get("nexus")) + " → " + controlPath;
				} else {
					partPath = String.valueOf(map.get("nexus")) + "% → " + controlPath;
				}
				partRatio = shareRatio + String.valueOf(map.get("nexus")) + "%";
				sourceId = (String) map.get("source_id");
				for (Map entity : entityList) {
					if (((String) entity.get("id")).equals((String) map.get("source_id"))) {
						compyName = (String) entity.get("name");
						partPath = compyName + " → " + partPath;
						controller = compyName;
						break;
					}
				}
				recursionController(relationList, entityList, sourceId, partPath, pathList, controllerList, controller,
						partRatio, shareRatioList);

			}
		}

		if (!isNotLast) {
			// 找到顶层节点
			pathList.add(partPath == null ? controlPath : partPath);
			shareRatioList.add(partRatio == null ? shareRatio : partRatio);
			if (!StringUtil.isEmpty(controller)) {
				controllerList.add(controller);
			}

		}

	}

//	private String monetaryHandle(Object obj) {
//		if(obj==null||StringUtil.isEmpty(String.valueOf(obj))) {
//			return "";
//		}
//		String value = String.valueOf(obj);
//		try {
//			Double companyType = Double.parseDouble(value)/10000;
//	        DecimalFormat df = new DecimalFormat("000,000.00");
//			return df.format(companyType);
//		}catch(Exception e) {
//			return "";
//		}
//	}

	private String dataSourceHandle(Object obj) {
		String value = String.valueOf(obj);
		String dataSource = null;
		switch (value) {
		case "2600":
			dataSource = "一季度报告";
			break;
		case "2601":
			dataSource = "半年度报告";
			break;
		case "2637":
			dataSource = "招股说明书";
			break;
		case "2638":
			dataSource = "上市公告书";
			break;
		case "2639":
			dataSource = "转让说明书";
			break;
		case "2691":
			dataSource = "定期报告";
			break;
		case "2837":
			dataSource = "三季度报告";
			break;
		case "2920":
			dataSource = "招股意向书";
			break;
		case "2973":
			dataSource = "招股说明书（申报稿）";
			break;
		case "2995":
			dataSource = "临时公告";
			break;
		case "3025":
			dataSource = "年度报告";
			break;
		case "3089":
			dataSource = "募集说明书";
			break;
		case "3257":
			dataSource = "一季度业绩公告";
			break;
		case "3258":
			dataSource = "半年度业绩公告";
			break;
		case "3259":
			dataSource = "三季度业绩公告";
			break;
		case "3260":
			dataSource = "年度业绩公告";
			break;
		case "3377":
			dataSource = "未知";
			break;
		}
		return dataSource;
	}

	private String companyTypeHandle(Object obj) {
		String value = String.valueOf(obj);
		String companyType = null;
		switch (value) {
		case "0":
			companyType = "通用";
			break;
		case "1":
			companyType = "银行";
			break;
		case "2":
			companyType = "证券";
			break;
		case "3":
			companyType = "保险";
			break;
		case "4":
			companyType = "未知";
			break;
		}
		return companyType;
	}

	private String listStateHandle(Object obj) {
		String value = String.valueOf(obj);
		String listState = null;
		switch (value) {
		case "0":
			listState = "上市前";
			break;
		case "1":
			listState = "上市后";
			break;
		}
		return listState;
	}

	private String reportQuarterHandle(Object quarter) {
		String quart = String.valueOf(quarter);
		String reportQuarter = null;
		switch (quart) {
		case "1":
			reportQuarter = "年度报告";
			break;
		case "2":
			reportQuarter = "半年度报告";
			break;
		case "3":
			reportQuarter = "一季度报告";
			break;
		case "4":
			reportQuarter = "三季度报告";
			break;
		}
		return reportQuarter;
	}

	private String reportDtHandle(Object dt) {
		try {
			String dtStr = String.valueOf(dt);
			String year = dtStr.substring(0, 4) + "年";
			String month = dtStr.substring(4, 6) + "月";
			String day = dtStr.substring(6, 8) + "日";

			return year + month + day;
		} catch (Exception e) {
			return "";
		}
	}

	// cp 小程序代码
	private JSONObject getInfoFromUrl(String compyNm, Boolean force) throws UnsupportedEncodingException {
		JSONObject jo_result = new JSONObject();
		compyNm = URLEncoder.encode(compyNm, "utf-8");
		// 调用数据组提供的受益人接口（内部包装中数智汇接口）
		String uri = Contants.BENEFICIALOWNER_URL + compyNm;
//	        String uri = "http://10.100.46.15:8088/product/beneficiary?entInfo=" + compyNm;

		HttpGet fuzzyGet = new HttpGet(uri);
		CloseableHttpClient httpClient = HttpClients.createDefault();
		// 执行请求
		CloseableHttpResponse fuzzyResponse = null;
		try {
			fuzzyResponse = httpClient.execute(fuzzyGet);
			String result = EntityUtils.toString(fuzzyResponse.getEntity(), Contants.UTF_8);
			jo_result = new JSONObject(result);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return jo_result;
	}

	@SuppressWarnings("rawtypes")
	public void exportMillCertificateWord(HttpServletResponse response, Map map, String templateFlg)
			throws IOException {
		Configuration configuration = new Configuration(Configuration.VERSION_2_3_22);
		configuration.setDefaultEncoding("utf-8");

		String filepath = getClass().getClassLoader().getResource("").getPath() + "/templates";
		configuration.setDirectoryForTemplateLoading(new File(filepath));
		Template freemarkerTemplate;
//        if ("0".equals(templateFlg)) {
//            freemarkerTemplate = configuration.getTemplate("/compyBasicInfoxygs.ftl");
//        } else {
		freemarkerTemplate = configuration.getTemplate("/companyCreditReport.ftl");
//        }

		File file = null;
		InputStream fin = null;
		ServletOutputStream out = null;
		try {
			// 调用工具类的createDoc方法生成Word文档
			file = createDoc(map, freemarkerTemplate);
			fin = new FileInputStream(file);

			response.setCharacterEncoding("utf-8");
			response.setContentType("application/msword");

			// 设置浏览器以下载的方式处理该文件名
			String fileName = "template_" + new Date().getTime() + ".doc";
			response.setHeader("Content-Disposition",
					"attachment;filename=".concat(String.valueOf(URLEncoder.encode(fileName, "UTF-8"))));

			out = response.getOutputStream();
			byte[] buffer = new byte[512]; // 缓冲区
			int bytesToRead = -1;
			// 通过循环将读入的Word文件的内容输出到浏览器中
			while ((bytesToRead = fin.read(buffer)) != -1) {
				out.write(buffer, 0, bytesToRead);
			}
		} finally {
			if (fin != null)
				fin.close();
			if (out != null)
				out.close();
			if (file != null)
				file.delete(); // 删除临时文件
		}
	}

	@SuppressWarnings("rawtypes")
	private File createDoc(Map dataMap, Template template) {
		String name = "template.doc";
		File f = new File(name);
		Template t = template;
		try {
			// 这个地方不能使用FileWriter因为需要指定编码类型否则生成的Word文档会因为有无法识别的编码而无法打开
			Writer w = new OutputStreamWriter(new FileOutputStream(f), "utf-8");
			t.process(dataMap, w);
			w.close();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException(ex);
		}
		return f;
	}

	private String handleTime(String noticeStr) {
		String year = noticeStr.substring(0, 4) + "年";
		String month = Integer.parseInt(noticeStr.substring(5, 7)) + "月";
		String day = Integer.parseInt(noticeStr.substring(8, 10)) + "";

		return year + month + day;

	}

	private Long getTime(String dateStr) {
		SimpleDateFormat sm = new SimpleDateFormat("yyyy-MM-dd");
		try {
			return sm.parse(dateStr).getTime();
		} catch (ParseException e) {
			return 0L;
		}
	}

	private String getQuarterReportTransShow(String quarterReportDate) {
		String quarterReportShow = null;
		switch (quarterReportDate) {
		case "03-31":
			quarterReportShow = "一季报";
			break;
		case "06-30":
			quarterReportShow = "半年报";
			break;
		case "09-30":
			quarterReportShow = "三季报";
			break;
		case "12-31":
			quarterReportShow = "年报";
			break;
		}
		return quarterReportShow;
	}

	private String getQuarterReportDate() {
		String curMonth = DateUtils.getMonth();
		// String curMonth = "07";
		String returnDate = null;
		switch (curMonth) {
		case "01":
			returnDate = "03-31";
			break;
		case "02":
			returnDate = "03-31";
			break;
		case "03":
			returnDate = "03-31";
			break;
		case "04":
			returnDate = "06-30";
			break;
		case "05":
			returnDate = "06-30";
			break;
		case "06":
			returnDate = "06-30";
			break;
		case "07":
			returnDate = "09-30";
			break;
		case "08":
			returnDate = "09-30";
			break;
		case "09":
			returnDate = "09-30";
			break;
		case "10":
			returnDate = "12-31";
			break;
		case "11":
			returnDate = "12-31";
			break;
		case "12":
			returnDate = "12-31";
			break;

		}
		return returnDate;
	}

	/**
	 * copy chartcontroller
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private BaseOutData getSuspectControllers(String link_id) {
		BaseOutData outData = new BaseOutData();
		String context = rt.opsForValue().get("suspectController" + link_id);
		if (context == null) {
			try {
				context = HttpUtil.getResponse(Contants.CHART_URL
						+ "/chart/suspectactualcontroller/actcontroller/company_id" + "?link_id=" + link_id);
				if (null != context) {
					rt.opsForValue().set("suspectController" + link_id, context);
					rt.expire("suspectController" + link_id, Contants.REDIS_TIMEOUT, TimeUnit.MINUTES);
				}
			} catch (IOException e) {
				e.printStackTrace();
				outData.setCode("1");
				outData.setMessage("系统报错!");
				return outData;
			}
		}
		Map data = new HashMap();
		data.put("result", context != null ? JSON.parse(String.valueOf(context)) : null);
		outData.setCode("0");
		outData.setMessage("返回成功!");
		outData.setData(data);
		return outData;
	}
}
