package com.cscs.portal.controller;

import com.alibaba.fastjson.JSON;
import com.cscs.portal.dto.CompanySearchCondition;
import com.cscs.portal.dto.CompanySearchOut;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.util.Contants;
import com.cscs.util.HttpUtil;
import com.cscs.util.SolrUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/***
 * 
 * @ClassName: CompanySearchController
 * @Description: 企业信息高级搜索相关接口
 * @author: liunn
 * @date: 2018年9月17日 下午2:48:20
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/company/search")
public class CompanySearchController {
	protected final Log logger = LogFactory.getLog(this.getClass());
	
	//企业类型
    public static String COMPANY_TYPE = "cs_companytype";
    //注册地
    public static String OFFICE_ADDR = "cs_officeaddr";
    //注册地
    public static String COMPANY_INDUSTRY = "cs_industry";
    //注册地
    public static String COMPANY_ST = "cs_companyst";
	
	@Autowired
    private StringRedisTemplate rt;

    /**
     * 
     * @Title: getResult
     * @Description: 高级搜索-企业信息查询
     * @param condition
     * @return
     * @throws SolrServerException
     * @throws ParseException
     * @return: Object
     */
    @RequestMapping(value = "/getResult", method = RequestMethod.POST)
    public Object getResult(@RequestBody CompanySearchCondition condition){
    	BaseOutData outData = new BaseOutData();
    	List<CompanySearchOut> returnList = new ArrayList<CompanySearchOut>();
    	long numFound = 0L;
    	try {
    		//创建Solr服务对象，通过此对象向solr服务发起请求
    		SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_COMPANY_METHOD);
    		//创建查询对象
    		SolrQuery query = new SolrQuery();
    		//查询关键字，q不能省略
    		if(StringUtils.isNotEmpty(condition.getKeyword())) {
    			query.set("q",condition.getKeyword());
    		}else {
    			query.set("q","*:*");
    		}
    		//Boost Functions。用函数的方式计算boost。 
    		query.set("bf", "log(max(regcapital,1))^8");
    		//此参数用于控制小写单词作为布尔运算符，如”and” and “or”。设置与lowercaseOperators= true来允许此。默认为true
    		query.set("lowercaseOperators", "true");
    		//返回字段
    		query.set("fl", "score,*");
    		//指定query parser，常用defType=lucene, defType=dismax, defType=edismax
    		query.set("defType", "edismax");
    		//query fields，指定solr从哪些field中搜索 设置查询权重值
    		query.set("qf", "lvl1_keyword^100 lvl2_keyword lvl3_keyword^0.1");
    		//boosting phrases over words。用于指定一组field，当query完全匹配pf指定的某一个field时，来进行boost
    		query.set("pf", "lvl2_keyword");
    		//单词停用，true 或false
    		query.set("stopwords", "true");
    		//只查询存活的分片
    		query.set("shards.tolerant", "true");
    		//排序
    		//参数：field域，排序类型（asc,desc）score desc,regcapital desc
    		query.addSort("score", SolrQuery.ORDER.desc);
    		query.addSort("regcapital", SolrQuery.ORDER.desc);
    		//分页
    		//实际开发时，知道当前页码和每页显示的个数最后求出开始下标
    		int curPage = condition.getCurPage()==null?1:condition.getCurPage();
    		int rows = condition.getRowNum()==null?10:condition.getRowNum();
    		//计算出开始记录下标
    		int start = rows * (curPage - 1);
    		//向query中设置分页参数
    		query.setStart(start);
    		query.setRows(rows);
    		//开启高亮
    		query.setHighlight(true);
    		//设置高亮 参数
    		query.addHighlightField("company_nm,legal_person_nm,old_company_nm,security_snm,credit_cd,security_cd,chairman,gmanager");
    		//设置高亮前缀和后缀
    		query.setHighlightSimplePre("<span class=\"highlight\">");
    		query.setHighlightSimplePost("</span>");
    		/*****************************过滤条件start*****************************************/
    		//过滤公司类型
    		if(StringUtils.isNotEmpty(condition.getCompanyType())) {
    			String[] companyTypeArr = condition.getCompanyType()!=null?condition.getCompanyType().split(","):null;
    			for(int i=0;companyTypeArr!=null&&i<companyTypeArr.length;i++) {
    				String companyType = companyTypeArr[i];
    				query.addFilterQuery("company_type:\""+companyType+"\"");
    			}
    		}
    		//过滤注册地
    		if(StringUtils.isNotEmpty(condition.getOfficeAddr())) {
    			query.addFilterQuery("reg_region:\""+condition.getOfficeAddr()+"\"");
    		}
    		//过滤所属行业
    		if(StringUtils.isNotEmpty(condition.getIndustry())) {
    			query.addFilterQuery("industry:\""+condition.getIndustry()+"\"");
    		}
    		//过滤注册资本
    		if(StringUtils.isNotEmpty(condition.getRegCapital())) {
    			String[] regCapital = condition.getRegCapital().split("-");
    			query.addFilterQuery("regcapital:["+Integer.valueOf(regCapital[0])+" TO "+Integer.valueOf(regCapital[1])+"]");
    		}
    		//过滤成立时间
    		if(StringUtils.isNotEmpty(condition.getFoundDt())) {
    			String queryString = this.getQueryTime(condition.getFoundDt());
    			query.addFilterQuery(queryString);
    		}
    		//过滤企业状态
    		if(StringUtils.isNotEmpty(condition.getCompanySt())) {
    			query.addFilterQuery("company_st:\""+condition.getCompanySt()+"\"");
    		}
    		/*****************************过滤条件end*****************************************/
    		
    		//执行查询
    		QueryResponse response = solrServer.query(query);
    		//从响应中得到结果
    		SolrDocumentList documents = response.getResults();
    		
    		//匹配到的总记录数
    		numFound = documents.getNumFound();
    		logger.info("匹配到的总记录数："+numFound);
    		
    		//从响应中获得高亮信息
    		Map<String, Map<String, List<String>>> highlighting = response.getHighlighting();
    		
    		for (SolrDocument document:documents){
    			CompanySearchOut data = new CompanySearchOut();
    			if(null != document.get("id")) {
    				data.setCompanyId(String.valueOf(document.get("id")));
    			}
    			if(null != document.get("company_nm")) {
    				data.setCompanyName(String.valueOf(document.get("company_nm")));
    			}
    			if(null != document.get("company_type")) {
    				data.setCompanyType(String.valueOf(document.get("company_type")));
    			}
    			if(null != document.get("company_st")) {
    				data.setCompanySt(String.valueOf(document.get("company_st")));
    			}
    			if(null != document.get("legal_person_nm")) {
    				data.setLegalPersonName(String.valueOf(document.get("legal_person_nm")));
    			}
    			if(null != document.get("regcapital")) {
    				data.setRegCapital(document.get("regcapital"));
    			}
    			if(null != document.get("reg_region")) {
    				data.setOfficeAddr(String.valueOf(document.get("reg_region")));
    			}
    			if(null != document.get("industry")) {
    				data.setIndustry(String.valueOf(document.get("industry")));
    			}
    			if(null != document.get("found_dt")) {
    				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    				data.setFoundDt(sdf.format((Date)document.get("found_dt")));
    			}
    			if(null != document.get("security_snm")) {
    				List list = (List)document.get("security_snm");
    				data.setSecuritySnm(list);
    			}
    			if(null != document.get("security_cd")) {
    				List list = (List)document.get("security_cd");
    				data.setSecurityCd(list);
    			}
    			if(null != document.get("chairman")) {
    				data.setChairman(String.valueOf(document.get("chairman")));
    			}
    			if(null != document.get("gmanager")) {
    				data.setGmanager(String.valueOf(document.get("gmanager")));
    			}
    			if(null != document.get("credit_cd")) {
    				data.setCreditCd(String.valueOf(document.get("credit_cd")));
    			}
    			if(null != document.get("old_company_nm")) {
    				data.setOldCompanyNm(String.valueOf(document.get("old_company_nm")));
    			}
    			
    			//获得高亮的信息
    			if(highlighting!=null){
    				//根据主键获取高亮信息
    				Map<String, List<String>> map = highlighting.get(document.get("id"));
    				if(map!=null){
    					List highlightColumns = new ArrayList();
    					List<String> companyNameList = map.get("company_nm");
    					List<String> legalPersonNmList = map.get("legal_person_nm");
    					List<String> securitySnmList = map.get("security_snm");
    					List<String> securityCdList = map.get("security_cd");
    					List<String> oldCompanyNmList = map.get("old_company_nm");
    					List<String> chairmanList = map.get("chairman");
    					List<String> gmanagerList = map.get("gmanager");
    					List<String> creditCdList = map.get("credit_cd");
    					if(companyNameList!=null){
    						data.setCompanyName(companyNameList.get(0));
    						highlightColumns.add("companyName");
    					}
    					if(legalPersonNmList!=null){
    						data.setLegalPersonName(legalPersonNmList.get(0));
    						highlightColumns.add("legalPersonName");
    					}
    					if(securitySnmList!=null){
    						data.setSecuritySnm(securitySnmList);
    						highlightColumns.add("securitySnm");
    					}
    					if(securityCdList!=null){
    						data.setSecurityCd(securityCdList);
    						highlightColumns.add("securityCd");
    					}
    					if(oldCompanyNmList!=null){
    						data.setOldCompanyNm(oldCompanyNmList.get(0));
    						highlightColumns.add("oldCompanyNm");
    					}
    					if(chairmanList!=null){
    						data.setChairman(chairmanList.get(0));
    						highlightColumns.add("chairman");
    					}
    					if(gmanagerList!=null){
    						data.setGmanager(gmanagerList.get(0));
    						highlightColumns.add("gmanager");
    					}
    					if(creditCdList!=null){
    						data.setCreditCd(creditCdList.get(0));
    						highlightColumns.add("creditCd");
    					}
    					data.setHighlightColumns(highlightColumns);
    				}
    			}
    			returnList.add(data);
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        Map data = new HashMap();
        data.put("result", returnList);
        outData.setCode("0");
        outData.setCount((int)numFound);
        outData.setMessage("返回成功!");
        outData.setData(data);
    	return outData;
    }
	/***
	 * 
	 * @Title: getCompany
	 * @Description: 获取企业信息-首页下拉查询
	 * @param keyword
	 * @return
	 * @return: Object
	 */
	@RequestMapping(value = "/company/{keyword}", method = RequestMethod.GET)
	public Object getCompany(@PathVariable String keyword){
		BaseOutData outData = new BaseOutData();
		List<CompanySearchOut> returnList = new ArrayList<CompanySearchOut>();
		long numFound = 0L;
		try {
			//创建Solr服务对象，通过此对象向solr服务发起请求
			SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_COMPANY_METHOD);
			//创建查询对象
			SolrQuery query = new SolrQuery();
			//查询关键字，q不能省略
    		if(StringUtils.isNotEmpty(keyword)) {
    			query.set("q",keyword);
    		}else {
    			query.set("q","*:*");
    		}
    		query.set("bf", "log(max(regcapital,1))^8");
    		query.set("lowercaseOperators", "true");
    		query.set("fl", "score,*");
    		//查询权重排序
    		query.set("defType", "edismax");
    		//设置查询权重值
    		query.set("qf", "lvl1_keyword^100 lvl2_keyword lvl3_keyword^0.1");
    		//只查询存活的分片
    		query.set("shards.tolerant", "true");
    		query.set("pf", "lvl2_keyword");
    		query.set("stopwords", "true");
			//排序
			//参数：field域，排序类型（asc,desc）score desc,regcapital desc
			query.addSort("score", SolrQuery.ORDER.desc);
			//分页
			//实际开发时，知道当前页码和每页显示的个数最后求出开始下标
			int curPage = 1;
			int rows = 10;
			//计算出开始记录下标
			int start = rows * (curPage - 1);
			//向query中设置分页参数
			query.setStart(start);
			query.setRows(rows);
			//开启高亮
			query.setHighlight(true);
			//设置高亮 参数
			query.addHighlightField("company_nm,legal_person_nm,old_company_nm,security_snm,credit_cd,security_cd,chairman,gmanager");
			//设置高亮前缀和后缀
			query.setHighlightSimplePre("<span class=\"highlight\">");
			query.setHighlightSimplePost("</span>");
			
			//执行查询
			QueryResponse response = solrServer.query(query);
			//从响应中得到结果
			SolrDocumentList documents = response.getResults();
			
			//匹配到的总记录数
			numFound = documents.getNumFound();
			logger.info("匹配到的总记录数："+numFound);
			
			//从响应中获得高亮信息
			Map<String, Map<String, List<String>>> highlighting = response.getHighlighting();
			
			for (SolrDocument document:documents){
				CompanySearchOut data = new CompanySearchOut();
				if(null != document.get("id")) {
					data.setCompanyId(String.valueOf(document.get("id")));
				}
				if(null != document.get("company_nm")) {
					data.setCompanyName(String.valueOf(document.get("company_nm")));
				}
				
				//获得高亮的信息
				if(highlighting!=null){
					//根据主键获取高亮信息
					Map<String, List<String>> map = highlighting.get(document.get("id"));
					if(map!=null){
						List<String> companyNameList = map.get("company_nm");
						if(companyNameList!=null){
							data.setCompanyName(companyNameList.get(0));
						}
					}
				}
				returnList.add(data);
			}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
		Map data = new HashMap();
		data.put("result", returnList);
		outData.setCode("0");
		outData.setCount((int)numFound);
		outData.setMessage("返回成功!");
		outData.setData(data);
		return outData;
	}
    
    /**
     * 
     * @Title: getCompanyType
     * @Description: 企业类型接口
     * @return
     * @return: Object
     */
    @RequestMapping(value = "/companyType", method = RequestMethod.GET)
    public BaseOutData getCompanyType(){
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_TYPE);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(Contants.HBASE_COMPANY_SEARCH_COMPANYTYPE_URL);
    			if(null!=out) {
    				rt.opsForValue().set(COMPANY_TYPE,out.toString());
    				rt.expire(COMPANY_TYPE, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
        Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }
    /**
     * 
     * @Title: getOfficeAddr
     * @Description:  获取注册地接口
     * @return
     * @return: Object
     */

    @RequestMapping(value = "/officeAddr", method = RequestMethod.GET)
    public BaseOutData getOfficeAddr(){
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	try {
    		out = rt.opsForValue().get(OFFICE_ADDR);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(Contants.HBASE_COMPANY_SEARCH_REGREGION_URL);
    			if(null!=out) {
    				rt.opsForValue().set(OFFICE_ADDR,  out.toString());
    				rt.expire(OFFICE_ADDR, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }
    /**
     * 
     * @Title: getIndustry
     * @Description: 获取行业接口
     * @return
     * @return: Object
     */

    @RequestMapping(value = "/industry", method = RequestMethod.GET)
    public BaseOutData getIndustry(){
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_INDUSTRY);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(Contants.HBASE_COMPANY_SEARCH_INDUSTRY_URL);
    			if(null!=out) {
    				rt.opsForValue().set(COMPANY_INDUSTRY, out.toString());
    				rt.expire(COMPANY_INDUSTRY, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }
    /**
     * 
     * @Title: 获取企业状态接口
     * @Description: TODO
     * @return
     * @return: Object
     */

    @RequestMapping(value = "/companySt", method = RequestMethod.GET)
    public BaseOutData getCompanySt(){
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_ST);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(Contants.HBASE_COMPANY_SEARCH_COMPANYST_URL);
    			if(null!=out) {
    				rt.opsForValue().set(COMPANY_ST,out.toString());
    				rt.expire(COMPANY_ST, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }
    
    private String getQueryTime(String foundDt) throws ParseException {
    	String queryStr = "";
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    	SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
    	Date startTime = null;
    	Date endTime = null;
    	String[] foundDtArr = foundDt.split("-");
    	if(foundDtArr!=null && foundDtArr.length>1) {
    		String startDateStr = foundDtArr[0];
    		String endDateStr = foundDtArr[1];
    		startTime = formatter.parse(startDateStr);
			endTime = formatter.parse(endDateStr);
			queryStr = "found_dt:["+sdf.format(startTime)+" TO "+sdf.format(endTime)+"]";
    	}
    	return queryStr;
    }
   
}
