package com.cscs.portal.controller;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cscs.portal.dto.AccountInfoData;
import com.cscs.portal.dto.AccountOutData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.UserBasicinfo;
import com.cscs.portal.security.util.JWTUtil;
import com.cscs.portal.services.AccountRoleXwServices;
import com.cscs.portal.services.CacheServices;
import com.cscs.portal.services.UserBasicInfoServices;
import com.cscs.util.AccountValidatorUtil;
import com.cscs.util.CheckSumBuilder;
import com.cscs.util.Contants;

@CrossOrigin
@RestController
@RequestMapping(value = "/account")
public class AccountController {

//    @Autowired
//    private AccountServices accountServices; //账户

    @Autowired
    private UserBasicInfoServices userBasicInfoServices; //用户


    @Autowired
    private CacheServices cacheServices;
    
    @Autowired
    AccountRoleXwServices accountRoleXwServices;

    /**
     * 注册提交
     * @param inData
     * @return
     */
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public AccountOutData save(@RequestBody AccountInfoData inData) {
        //Account infoData = new Account();
        AccountOutData outData = new AccountOutData();
        if (!AccountValidatorUtil.isEmail(inData.getEmail())) {
            outData.setCode("1");
            outData.setMessage("邮箱格式不正确");
            return outData;
        }

        try {
            //Account account = accountServices.findByAccountNm(inData.getAccountNm());
            UserBasicinfo account = userBasicInfoServices.findByAccountNm(inData.getAccountNm());
            if (account != null) {
                outData.setCode("1");
                outData.setMessage("该用户已注册！");
                return outData;
            }
            
            //获取userid 此id和最终数据库生成的id不一致
//            Long userId = userBasicInfoServices.generatedValue();

            //用户信息
            UserBasicinfo userInfo = new UserBasicinfo();
            userInfo.setUserNm(inData.getAccountNm());
            Date date = new Date();
            userInfo.setUpdtDt(new Timestamp(date.getTime()));
            userInfo.setEmail(inData.getEmail());
            userInfo.setCompanyNm(inData.getCompanyNm());
            userInfo.setAccountPw(inData.getAccountPw());
            userInfo.setAccountNm(inData.getAccountNm());
            userInfo.setRegeditDt(date);
            userInfo.setCreateDt(date);
            userInfo.setRegeditType(0L);
//            userInfo.setUserId(userId);
//            userInfo.setCreateBy(userId);
//            userInfo.setUpdtBy(userId);
            userInfo.setActivityType(2L);
            //不能修改
            //userInfo.setCellphone(inData.getAccountNm());
            userInfo = userBasicInfoServices.save(userInfo);

            //账户信息
//            BeanUtils.copyProperties(inData, infoData);
//            infoData.setUserId(userInfo.getUserId());
//            Date date2 = new Date();
//            infoData.setUpdtDt(new Timestamp(date2.getTime()));
//            infoData.setUpdtBy(userInfo.getUserId());
//            infoData.setRegeditDt(date2);
//            infoData.setCreateDt(new Timestamp(date2.getTime()));
//            infoData.setCreateBy(userInfo.getUserId());
//            infoData.setActivityType(2L);
//            infoData = accountServices.save(infoData);
//
//            BeanUtils.copyProperties(infoData, outData);
            
            //授予默認角色
            accountRoleXwServices.setAccountRoleXw(userInfo.getUserId(), "一般用户");
            outData.setCode("0");

            //水印值记录
            cacheServices.updateUser("login_" + userInfo.getUserId(), String.valueOf(inData.getBrowser()));

            //成功
            //outData.setToken(ConstantWebUtils.getToken(String.valueOf(infoData.getAccountId()),String.valueOf(infoData.getUserId())));
            outData.setToken(JWTUtil.sign(String.valueOf(userInfo.getUserId()),String.valueOf(userInfo.getUserId())));
        } catch (Exception e) {
            outData.setCode("1");
            outData.setMessage("用户注册失败!");
        }
        return outData;
    }

    /**
     * 验证手机号是否已注册
     * @param phone
     * @return
     */
    @RequestMapping(value = "/verify/phone/{phone}", method = RequestMethod.GET)
    public BaseOutData verifyPhoneExist(@PathVariable String phone) {

        BaseOutData outData = new BaseOutData();
        //Account infoData = accountServices.findByAccountNm(phone);
        UserBasicinfo infoData = userBasicInfoServices.findByAccountNm(phone);
        if (infoData != null) {
            outData.setCode("1");
            outData.setMessage("手机已注册");
        } else {
            outData.setCode("0");
            outData.setMessage("手机未注册");
        }
        return outData;
    }

    /**
     * 验证邮箱是否已注册
     * @return
     */
    @RequestMapping(value = "/verify/email", method = RequestMethod.POST)
    public BaseOutData verifyEmailExist(@RequestBody AccountInfoData inData) {

        BaseOutData outData = new BaseOutData();
        String mail = inData.getEmail();
        Boolean ex = userBasicInfoServices.getUserExistByEmail(mail);
        if (ex) {
            outData.setCode("1");
            outData.setMessage("邮箱已注册");
        } else {
            outData.setCode("0");
            outData.setMessage("邮箱未注册");
        }
        return outData;
    }

    /**
     * 忘记密码（验证码）
     */
    @RequestMapping(value = "/updateUserPwd", method = RequestMethod.POST)
    public BaseOutData UpdateUserPwd(@RequestBody AccountInfoData inData) throws Exception {
        BaseOutData outData = new BaseOutData();
        String accountNm = inData.getAccountNm();
        String accountPw = inData.getAccountPw();

//        if (accountServices.findByAccountNm(inData.getAccountNm()) == null) {
        if (userBasicInfoServices.findByAccountNm(inData.getAccountNm()) == null) {
            outData.setCode("1");
            return outData;
        }

        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost(Contants.SERVER_VERIFY_CODE);

        // 计算CheckSum的java代码t
        String curTime = String.valueOf((new Date()).getTime() / 1000L);
        String checkSum = CheckSumBuilder.getCheckSum(Contants.APP_SECRET, Contants.NONCE, curTime);

        // 设置请求的header
        httpPost.addHeader("AppKey", Contants.APP_KEY);
        httpPost.addHeader("Nonce", Contants.NONCE);
        httpPost.addHeader("CurTime", curTime);
        httpPost.addHeader("CheckSum", checkSum);
        httpPost.addHeader("Content-Type", Contants.CONTENT_TYPE);

        // 设置请求的参数
        List<NameValuePair> nvps = new ArrayList<NameValuePair>();
        nvps.add(new BasicNameValuePair("mobile", accountNm));
        nvps.add(new BasicNameValuePair("code", inData.getCode()));
        nvps.add(new BasicNameValuePair("templateid", Contants.MOULD_ID));
        httpPost.setEntity(new UrlEncodedFormEntity(nvps, Contants.UTF_8));

        // 执行请求
        CloseableHttpResponse response = httpClient.execute(httpPost);

        // 执行结果
        String responseEntity = EntityUtils.toString(response.getEntity(), Contants.UTF_8);
        JSONObject json = new JSONObject(responseEntity);
        if (json.getInt("code") != 200) {
            outData.setCode("2");
            return outData;
        }

        //修改密码
        //int num = accountServices.updateUserPwd(accountNm, accountPw);
        int num = userBasicInfoServices.updateUserPwd(accountNm, accountPw);
        outData.setCode(String.valueOf(num));
        return outData;
    }

    
    /**
     * 修改密码（无验证码）
     */
    @RequestMapping(value = "/updatePwd", method = RequestMethod.POST)
    public BaseOutData UpdatePwd(@RequestBody AccountInfoData inData) throws Exception {
        BaseOutData outData = new BaseOutData();
        String accountNm = inData.getAccountNm();
        String accountPw = inData.getAccountPw();
        String accountOldPw = inData.getAccountOldPw();

        if (!accountPw.equals(inData.getAccountPwConfirm())) {
            outData.setCode("1");
            return outData;
        }

        //Account infoData = accountServices.findByAccount(accountNm, accountOldPw);
        UserBasicinfo infoData = userBasicInfoServices.findByAccount(accountNm, accountOldPw);
        if (infoData == null) {
            outData.setCode("2");
            return outData;
        }

        //修改密码
        //accountServices.updateUserPwd(accountNm, accountPw);
        userBasicInfoServices.updateUserPwd(accountNm, accountPw);
        outData.setCode("0");
        return outData;
    }

    /**
     * 登陆
     * @param inData
     * @return
     */
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public AccountOutData login(@RequestBody AccountInfoData inData) {
        AccountOutData outData = new AccountOutData();
        //List<Object> infoData = accountServices.getAccount(inData.getAccountNm(), inData.getAccountPw());
        List<Object> infoData = userBasicInfoServices.getAccount(inData.getAccountNm(), inData.getAccountPw());
        if (infoData.size() > 0) {
            String flag = "";
            Object[] info = (Object[]) infoData.get(0);
            Long userId = Long.valueOf(info[5].toString());
            Long accountId = Long.valueOf(info[4].toString());
            //账户是否停用
            if ("3".equals(info[0].toString())) {
                outData.setCode("3");
                outData.setMessage("该用户已停用!");
                return outData;
            }
            //验证当前用户是否为管理员
            if (info[1] != null) {
                flag = "admin";
            }
            String curBrowser = String.valueOf(inData.getBrowser());
            String browser = cacheServices.getUser("login_" + accountId);
            if (browser != null) {
                //强制登陆
                if (!inData.isRegeditFlg()) {
                    //水印值不同
                    if (!curBrowser.equals(browser)) {
                        outData.setCode("-1");
                        outData.setMessage("用户已登陆!");
                        return outData;
                    }
                }
            }
            cacheServices.updateUser("login_" + accountId, curBrowser);
            outData.setFlag(flag);
            outData.setAccountId(accountId);
            outData.setUserId(userId);
            outData.setAccountNm(inData.getAccountNm());
            //outData.setToken(ConstantWebUtils.getToken(accountId.toString(),userId.toString()));
            outData.setToken(JWTUtil.sign(String.valueOf(accountId),String.valueOf(userId) ));
            outData.setCode("0");
        } else {
            outData.setCode("1");
            outData.setMessage("该用户不存在或密码错误!");
        }
        return outData;
    }
}