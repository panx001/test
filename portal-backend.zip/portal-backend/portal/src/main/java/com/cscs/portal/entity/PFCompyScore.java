package com.cscs.portal.entity;

import javax.persistence.*;
import java.sql.Time;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "PFCOMPY_SCORE", schema = "CS_PORTAL", catalog = "")
public class PFCompyScore {
    private long id;
    private Long companyId;
    private String companyName;
    private Date scoreDt;
    private Double weightScore;
    private int capitalScore;
    private int manageScore;
    private int sincerityScore;
    private int relationScore;
    private int complianceScore;
    private int cheatScore;
    private int riskResult;
    private String region;
    private String city;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_PFCOMPY_SCORE")
    @SequenceGenerator(sequenceName = "SEQ_PFCOMPY_SCORE", name = "SEQ_PFCOMPY_SCORE")
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "COMPANY_ID")
    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    @Basic
    @Column(name = "COMPANY_NAME")
    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    @Basic
    @Column(name = "SCORE_DT")
    public Date getScoreDt() {
        return scoreDt;
    }

    public void setScoreDt(Date scoreDt) {
        this.scoreDt = scoreDt;
    }

    @Basic
    @Column(name = "WEIGHT_SCORE")
    public Double getWeightScore() {
        return weightScore;
    }

    public void setWeightScore(Double weightScore) {
        this.weightScore = weightScore;
    }

    @Basic
    @Column(name = "CAPITAL_SCORE")
    public int getCapitalScore() {
        return capitalScore;
    }

    public void setCapitalScore(int capitalScore) {
        this.capitalScore = capitalScore;
    }

    @Basic
    @Column(name = "MANAGE_SCORE")
    public int getManageScore() {
        return manageScore;
    }

    public void setManageScore(int manageScore) {
        this.manageScore = manageScore;
    }

    @Basic
    @Column(name = "SINCERITY_SCORE")
    public int getSincerityScore() {
        return sincerityScore;
    }

    public void setSincerityScore(int sincerityScore) {
        this.sincerityScore = sincerityScore;
    }

    @Basic
    @Column(name = "RELATION_SCORE")
    public int getRelationScore() {
        return relationScore;
    }

    public void setRelationScore(int relationScore) {
        this.relationScore = relationScore;
    }

    @Basic
    @Column(name = "COMPLIANCE_SCORE")
    public int getComplianceScore() {
        return complianceScore;
    }

    public void setComplianceScore(int complianceScore) {
        this.complianceScore = complianceScore;
    }

    @Basic
    @Column(name = "CHEAT_SCORE")
    public int getCheatScore() {
        return cheatScore;
    }

    public void setCheatScore(int cheatScore) {
        this.cheatScore = cheatScore;
    }

    @Basic
    @Column(name = "RISK_RESULT")
    public int getRiskResult() {
        return riskResult;
    }

    public void setRiskResult(int riskResult) {
        this.riskResult = riskResult;
    }

    @Basic
    @Column(name = "REGION")
    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    @Basic
    @Column(name = "CITY")
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PFCompyScore that = (PFCompyScore) o;
        return id == that.id &&
                Objects.equals(companyId, that.companyId) &&
                Objects.equals(companyName, that.companyName) &&
                Objects.equals(scoreDt, that.scoreDt) &&
                Objects.equals(weightScore, that.weightScore) &&
                Objects.equals(capitalScore, that.capitalScore) &&
                Objects.equals(manageScore, that.manageScore) &&
                Objects.equals(sincerityScore, that.sincerityScore) &&
                Objects.equals(relationScore, that.relationScore) &&
                Objects.equals(complianceScore, that.complianceScore) &&
                Objects.equals(cheatScore, that.cheatScore) &&
                Objects.equals(riskResult, that.riskResult) &&
                Objects.equals(region, that.region) &&
                Objects.equals(city, that.city);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, companyId, companyName, scoreDt, weightScore, capitalScore, manageScore, sincerityScore, relationScore, complianceScore, cheatScore, riskResult, region, city);
    }
}
