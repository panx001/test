package com.cscs.portal.dto;

import java.util.Date;

/**
 * Created by sh on 2016/8/7.
 */
public class HotNewsInfoData {
	private long id;
	private String link;
	private String title;
	private String source;
	private String companyIdList;
	private String companyNmList;
	private Long status;

	private Date postdt;

	// 相关性
	private String relevance;

	private String warningType;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getCompanyIdList() {
		return companyIdList;
	}

	public void setCompanyIdList(String companyIdList) {
		this.companyIdList = companyIdList;
	}

	public String getCompanyNmList() {
		return companyNmList;
	}

	public void setCompanyNmList(String companyNmList) {
		this.companyNmList = companyNmList;
	}

	public Long getStatus() {
		return status;
	}

	public void setStatus(Long status) {
		this.status = status;
	}

	public Date getPostdt() {
		return postdt;
	}

	public void setPostdt(Date postdt) {
		this.postdt = postdt;
	}

	public String getRelevance() {
		return relevance;
	}

	public void setRelevance(String relevance) {
		this.relevance = relevance;
	}

	public String getWarningType() {
		return warningType;
	}

	public void setWarningType(String warningType) {
		this.warningType = warningType;
	}

}
