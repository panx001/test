package com.cscs.portal.controller;

import com.cscs.portal.dto.CompanyReport;
import com.cscs.portal.dto.CompanyReportIn;
import com.cscs.portal.services.CompanyReportServices;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by wang on 2016/8/24.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/companyReport")
public class CompanyReportController {

    @Autowired
    CompanyReportServices companyReportServices;

    @RequestMapping(value = "/cashflow", method = RequestMethod.POST)
    public CompanyReport getCompyCashflow(@RequestBody CompanyReportIn inData) throws JsonProcessingException {
        CompanyReport outData = new CompanyReport();
        List infoList = new LinkedList();
        long companyId = inData.getCompanyId();
        int subjectType = inData.getSubjectType();//1：资产负债表 2: 利润表 3: 现金流量表
        String rptTimetypeCd = inData.getRptTimetypeCd();//报告期，1：年报 2：中报 3：一季报 4：三季报 5：最新
        String rptDt = inData.getRptDt();//时间范围，0：全部，1：今年，2：去年，3：3年，5：5年，10：10年
        String isPublicRpt = inData.getIsPublicRpt();//上市前/上市后， 0：上市前， 1：上市后
        String combineTypeCd = inData.getCombineTypeCd();//报表类型， 1：母公司， 2：合并， 3：母公司调整， 4：合并调整
        String quarterly = inData.getQuarterly();//合计/单季    0：合计，1：单季
        String includeFlg = "";

        //1：资产负债表 2: 利润表 3: 现金流量表
        String tableName = "";
        if (subjectType == 1) {
            tableName = "COMPY_BALANCESHEET";
        } else if (subjectType == 2) {
            tableName = "COMPY_INCOMESTATE";
        } else if (subjectType == 3) {
            tableName = "COMPY_CASHFLOW";
        }
        //对应项目(字段)取得
        List<Object> columnEnm = companyReportServices.findColumnEnm(companyId, subjectType, tableName);
        StringBuilder sbColumnEnm1 = new StringBuilder("");
        int skipCount = 0;
        for (int i = 0; i < columnEnm.size(); i++) {
            Object[] item = (Object[]) columnEnm.get(i);
            if ("RPT_DT_LABEL".equals(item[8]) || "0".equals(item[8])) {
                skipCount++;
                continue;
            }
            sbColumnEnm1.append(item[8]).append(" as ").append((item[8]).toString().trim()+"_"+i);
            if (i != columnEnm.size() - 1) {
                sbColumnEnm1.append(", ");
            }
        }
        //合并：0 单季：1
        if("0".equals(quarterly)) {
            includeFlg = rptTimetypeCd;
            //报表时间类型  1,2,3,4,5：全部 1：年报 2：中报 3：一季报 4：三季报 5：最新
            if (rptTimetypeCd.indexOf("5") > -1) {
                rptTimetypeCd = "1,2,3,4";
            }
        }else{
            //'7'=第四季度报告, '8'=第二季度报告,  '3'=一季度报告,  '6,9'=7-9月季报/第三季度报告, '3,6,7,8,9'=全部
            if(rptTimetypeCd.indexOf("1") > -1){
                rptTimetypeCd = rptTimetypeCd.replaceAll("1","7");
            }
            if(rptTimetypeCd.indexOf("2") > -1){
                rptTimetypeCd = rptTimetypeCd.replaceAll("2","8");
            }
            if(rptTimetypeCd.indexOf("4") > -1){
                rptTimetypeCd = rptTimetypeCd.replaceAll("4","6,9");
            }
            includeFlg = rptTimetypeCd;
            if (rptTimetypeCd.indexOf("5") > -1) {
                rptTimetypeCd = "3,6,7,8,9";
            }
        }

        List<Object> compyReportsList = companyReportServices.findCompyReport(companyId, rptDt, isPublicRpt, rptTimetypeCd, combineTypeCd, tableName, sbColumnEnm1.toString());
        if (compyReportsList.size() != 0) {
            int index = 0;
            List rptDateList = new LinkedList();
            List compyReports = new LinkedList();
            String tmpRptDt = "";
            //过滤数据（最新）
            for (int j = 0; j < compyReportsList.size(); j++) {
                Object[] content = (Object[]) compyReportsList.get(j);
                if ("".equals(tmpRptDt)) {
                    tmpRptDt = content[content.length - 2].toString();
                }
                if ("5".equals(includeFlg)) {
                    compyReports.add(content);
                    break;
                } else if (includeFlg.indexOf("5") > -1) {
                    String typeCd = content[content.length - 3].toString();
                    //最新(日期相同的数据)
                    if (j == 0 || includeFlg.indexOf(typeCd) > -1) {
                        compyReports.add(content);
                    } else {
                        if (tmpRptDt.equals(content[content.length - 2].toString())) {
                            compyReports.add(content);
                        } else {
                            continue;
                        }
                    }
                } else{
                    compyReports.add(content);
                }
            }
            //组合数据(对应列数据)
            for (int i = 0; i < columnEnm.size(); i++) {
                List info = new LinkedList();
                Object[] item = (Object[]) columnEnm.get(i);
                if ("审计意见(境内)".equals(item[2])) {
                    continue;
                }
                info.add(item[0]);
                info.add(item[1]);
                info.add(item[2]);
                info.add(item[3]);
                info.add(item[4]);
                info.add(item[5]);
                info.add(item[6]);
                info.add(item[7]);
                if ("0".equals(item[8].toString())) {
                    infoList.add(info);
                    continue;
                }
                for (int j = 0; j < compyReports.size(); j++) {
                    Object[] content = (Object[]) compyReports.get(j);
                    if ("RPT_DT_LABEL".equals(item[8].toString())) {
                        info.add(content[columnEnm.size() - skipCount]);
                        rptDateList.add(content[columnEnm.size() - skipCount]);
                    } else if ("COMBINE_TYPE_CD".equals(item[8].toString())) {
                        String typeCd = content[index].toString();
                        String dataAjustType = content[columnEnm.size() - skipCount + 1].toString();
                        info.add(typeCd + "(" + dataAjustType + ")");
                    } else {
                        info.add(content[index]);
                    }
                }
                if (!"RPT_DT_LABEL".equals(item[8].toString())) {
                    index++;
                }
                if ("RPT_DT_LABEL".equals(item[8].toString())) {
                    infoList.add(0, info);
                } else if ("RPT_TIMETYPE_CD".equals(item[8].toString())) {
                    infoList.add(1, info);
                } else {
                    infoList.add(info);
                }
            }
            List<Object> finanauditList = companyReportServices.findCompyFinanaudit(companyId, rptDt);
            //审计意见(境内)
            List auditList = new LinkedList();
            List oauditList = new LinkedList();
            auditList.add(422);
            auditList.add("15");
            auditList.add("审计意见(境内)");
            auditList.add("0");
            auditList.add(1);
            auditList.add(1);
            auditList.add(0);
            auditList.add(0);
            //审计意见(境外)
            oauditList.add(423);
            oauditList.add("16");
            oauditList.add("审计意见(境外)");
            oauditList.add("0");
            oauditList.add(1);
            oauditList.add(1);
            oauditList.add(0);
            oauditList.add(0);
            if (finanauditList.size() > 0) {
                for (int i = 0; i < rptDateList.size(); i++) {
                    String item = rptDateList.get(i).toString();
                    boolean isExist = false;
                    outfor:
                    for (int j = 0; j < finanauditList.size(); j++) {
                        Object[] tmp = (Object[]) finanauditList.get(j);
                        if (item.equals(tmp[0].toString())) {
                            auditList.add(tmp[1]);
                            oauditList.add(tmp[2]);
                            isExist = true;
                            continue outfor;
                        }
                    }
                    if(!isExist) {
                        auditList.add(null);
                        oauditList.add(null);
                    }
                }
            }
            infoList.add(auditList);
            infoList.add(oauditList);
        }
        outData.setCompyReport(infoList);
        return outData;
    }
}
