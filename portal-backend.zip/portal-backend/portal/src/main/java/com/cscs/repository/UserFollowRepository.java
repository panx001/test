package com.cscs.repository;

import com.cscs.portal.entity.UserFollow;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * 用户关注表
 */
@SuppressWarnings("JpaQlInspection")
public interface UserFollowRepository extends JpaRepository<UserFollow, Long> {

}
