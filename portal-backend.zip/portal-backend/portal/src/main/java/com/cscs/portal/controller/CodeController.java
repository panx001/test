package com.cscs.portal.controller;

import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.util.CheckSumBuilder;
import com.cscs.util.Contants;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping(value = "/code")
public class CodeController {

    @RequestMapping(value = "/sendCode/{userPhone}", method = RequestMethod.GET)
    public BaseOutData sendCode(@PathVariable String userPhone) throws Exception {
        BaseOutData outData = new BaseOutData();
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost(Contants.SERVER_SENDCODE_URL);

        // 计算CheckSum的java代码
        String curTime = String.valueOf((new Date()).getTime() / 1000L);
        String checkSum = CheckSumBuilder.getCheckSum(Contants.APP_SECRET, Contants.NONCE, curTime);

        // 设置请求的header
        httpPost.addHeader("AppKey", Contants.APP_KEY);
        httpPost.addHeader("Nonce", Contants.NONCE);
        httpPost.addHeader("CurTime", curTime);
        httpPost.addHeader("CheckSum", checkSum);
        httpPost.addHeader("Content-Type", Contants.CONTENT_TYPE);

        // 设置请求的参数
        List<NameValuePair> nvps = new ArrayList<NameValuePair>();
        nvps.add(new BasicNameValuePair("mobile", userPhone));
        nvps.add(new BasicNameValuePair("templateid", Contants.MOULD_ID));
        httpPost.setEntity(new UrlEncodedFormEntity(nvps, Contants.UTF_8));

        // 执行请求
        CloseableHttpResponse response = httpClient.execute(httpPost);

        // 执行结果
        String responseEntity = EntityUtils.toString(response.getEntity(), Contants.UTF_8);
        JSONObject json = new JSONObject(responseEntity);
        System.out.println(json.getInt("code") );
        if (json.getInt("code") == 200) {
            outData.setCode("0");
        } else {
            outData.setCode("1");
        }
        return outData;
    }

    @RequestMapping(value = "/verifyCode/{userPhone}/{code}", method = RequestMethod.GET)
    public BaseOutData verifyCode(@PathVariable String userPhone, @PathVariable String code) throws Exception {
        BaseOutData outData = new BaseOutData();

        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost(Contants.SERVER_VERIFY_CODE);

        // 计算CheckSum的java代码
        String curTime = String.valueOf((new Date()).getTime() / 1000L);
        String checkSum = CheckSumBuilder.getCheckSum(Contants.APP_SECRET, Contants.NONCE, curTime);

        // 设置请求的header
        httpPost.addHeader("AppKey", Contants.APP_KEY);
        httpPost.addHeader("Nonce", Contants.NONCE);
        httpPost.addHeader("CurTime", curTime);
        httpPost.addHeader("CheckSum", checkSum);
        httpPost.addHeader("Content-Type", Contants.CONTENT_TYPE);

        // 设置请求的参数
        List<NameValuePair> nvps = new ArrayList<NameValuePair>();
        nvps.add(new BasicNameValuePair("mobile", userPhone));
        nvps.add(new BasicNameValuePair("code", code));
        nvps.add(new BasicNameValuePair("templateid", Contants.MOULD_ID));
        httpPost.setEntity(new UrlEncodedFormEntity(nvps, Contants.UTF_8));

        // 执行请求
        CloseableHttpResponse response = httpClient.execute(httpPost);

        // 执行结果
        String responseEntity = EntityUtils.toString(response.getEntity(), Contants.UTF_8);
        JSONObject json = new JSONObject(responseEntity);
        if (json.getInt("code") == 200) {
            outData.setCode("0");
        } else {
            outData.setCode("1");
        }
        return outData;
    }
}
