package com.cscs.portal.dto;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.Map;

public class CommonForCreditReportComparator implements Comparator<Map> {

	private String attrName;
	private String subStrName;
	
	public String getAttrName() {
		return attrName;
	}

	public void setAttrName(String attrName) {
		this.attrName = attrName;
	}

	public String getSubStrName() {
		return subStrName;
	}

	public void setSubStrName(String subStrName) {
		this.subStrName = subStrName;
	}

	public CommonForCreditReportComparator() {
		super();
	}
	public CommonForCreditReportComparator(String attrName,String subStrName) {
		this.attrName = attrName;
		this.subStrName = subStrName;
	}
	
	@Override
	public int compare(Map o1, Map o2) {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date dt1;
		Date dt2;
		try {
			//截取
			String subStr = (String) o1.get(this.getSubStrName());
			if(subStr.length()>60) {
				subStr = subStr.substring(0, 60);
			}
			o1.put(this.getSubStrName(), subStr);
			String subStr2 = (String) o2.get(this.getSubStrName());
			if(subStr2.length()>60) {
				subStr2 = subStr2.substring(0, 60);
			}
			o2.put(this.getSubStrName(), subStr2);
			
			dt1 = df.parse((String) o1.get(this.getAttrName()));
			dt2 = df.parse((String)o2.get(this.getAttrName()));
			//降序
			if (dt1.getTime() > dt2.getTime()) {	
				return -1;
			} else if (dt1.getTime() < dt2.getTime()) {
				return 1;
			} else {
				return 0;
			}
		} catch (ParseException e) {
			return 0;
		}catch (Exception e) {
			return 0;
		}
	}
}
