package com.cscs.portal.controller;

import com.alibaba.fastjson.JSON;
import com.cscs.portal.dto.PsecSearchConditon;
import com.cscs.portal.dto.PsecSearchOut;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.services.PFundSearchServices;
import com.cscs.util.Contants;
import com.cscs.util.HttpUtil;
import com.cscs.util.SolrUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/***
 *
 * @ClassName: PrivateEquitySearchController
 * @Description: 私募机构高级搜索相关接口
 * @author: liunn
 * @date: 2018年9月17日 下午2:45:44
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/private/equity/search")
public class PFundSearchController {
    protected final Log logger = LogFactory.getLog(this.getClass());
    //风险等级列表
    public static String RISK_GRADE = "p_f_riskgrade";
    //风险类型列表
    public static String RISK_TYPE = "p_f_risktype";
    //基金备案阶段列表
    public static String FUND_RECORD = "p_f_fundrecord";
    //机构类型列表
    public static String ORG_TYPE = "p_f_orgtype";
    //管理类型列表
    public static String MANAGE_TYPE = "p_f_managetype";
    //运作状态列表
    public static String OPERATION_STATUS = "p_f_operationstatus";
    //诚信信息列表
    public static String INTEGRITY_INFO = "p_f_integrityinfo";
    //提示事项列表
    public static String TIPS = "p_f_tips";

    @Autowired
    private StringRedisTemplate rt;
    @Autowired
    private PFundSearchServices pFundSearchServices;

    /**
     * @param condition
     * @return
     * @Title: getResult
     * @Description: 私募机构高级搜索
     * @return: Object
     */
    @RequestMapping(value = "/getResult", method = RequestMethod.POST)
    public Object getResult(@RequestBody PsecSearchConditon condition) {
        BaseOutData outData = new BaseOutData();
        List<PsecSearchOut> returnList = new ArrayList<PsecSearchOut>();
        long numFound = 0L;
        try {
            //创建Solr服务对象，通过此对象向solr服务发起请求
            SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_PFUND_METHOD);
            //创建查询对象
            SolrQuery query = new SolrQuery();
            //设置公共查询参数
            query = pFundSearchServices.setSolrQuery(condition, query);
            
            /*****************************过滤条件start*****************************************/
            //查询删除的数据
            query.addFilterQuery("isdel:0");
            //过滤成立时间
            if (StringUtils.isNotEmpty(condition.getFoundDt())) {
                String queryString = this.getQueryTime(condition.getFoundDt());
                query.addFilterQuery("pfound_dt:" + queryString);
            }
            //过滤登记时间
            if (StringUtils.isNotEmpty(condition.getRegDt())) {
                String queryString = this.getQueryTime(condition.getRegDt());
                query.addFilterQuery("pfreg_dt:" + queryString);
            }
            //过滤基金备案阶段
            if (StringUtils.isNotEmpty(condition.getRegPhase())) {
                query.addFilterQuery("pfreg_phase:\"" + condition.getRegPhase() + "\"");
            }
            //过滤机构类型
            if (StringUtils.isNotEmpty(condition.getOrgType())) {
                query.addFilterQuery("pfund_type:\"" + condition.getOrgType() + "\"");
            }
            //过滤管理类型
            if (StringUtils.isNotEmpty(condition.getManageType())) {
                query.addFilterQuery("pfmag_type:\"" + condition.getManageType() + "\"");
            }
            //过滤运作状态
            if (StringUtils.isNotEmpty(condition.getState())) {
                String[] arr = condition.getState() != null ? condition.getState().split(",") : null;
                for (int i = 0; arr != null && i < arr.length; i++) {
                    query.addFilterQuery("pfoper_status:\"" + arr[i]  + "\"");
                }
            }
            //过滤诚信信息
            if (StringUtils.isNotEmpty(condition.getIntegrityInfo())) {
                String[] arr = condition.getIntegrityInfo() != null ? condition.getIntegrityInfo().split(",") : null;
                for (int i = 0; arr != null && i < arr.length; i++) {
                    query.addFilterQuery("pftip_info:\"" + arr[i]+"\"");
                }
            }
            //过滤提示事项
            if (StringUtils.isNotEmpty(condition.getTipInfo())) {
                String[] arr = condition.getTipInfo() != null ? condition.getTipInfo().split(",") : null;
                for (int i = 0; arr != null && i < arr.length; i++) {
                    query.addFilterQuery("pfwarn_info:\"" + arr[i]+"\"");
                }
            }
            /*****************************过滤条件end*****************************************/
            //执行查询
            QueryResponse response = solrServer.query(query);
            //返回结果数量
            numFound = response.getResults().getNumFound();
            //获取返回数据
    		returnList = pFundSearchServices.getResponseDate(response);
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", returnList);
        outData.setCode("0");
        outData.setCount((int) numFound);
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /***
     *
     * @Title: getRiskTypeForSmjg
     * @Description: 风险类型列表-私募机构高级搜索
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/riskType", method = RequestMethod.GET)
    public BaseOutData getRiskType() {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(RISK_TYPE);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(Contants.HBASE_PRIVATE_EQUITY_SEARCH_RISKTYPE_URL);
                if (null != out) {
                    rt.opsForValue().set(RISK_TYPE, out.toString());
                    rt.expire(RISK_TYPE, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * @return
     * @Title: getJjbajd
     * @Description: 基金备案阶段列表-私募机构高级搜索
     * @return: BaseOutData
     */
    @RequestMapping(value = "/fundRecord", method = RequestMethod.GET)
    public BaseOutData getFundRecord() {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(FUND_RECORD);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(Contants.HBASE_PRIVATE_EQUITY_SEARCH_FUNDRECORD_URL);
                if (null != out) {
                    rt.opsForValue().set(FUND_RECORD, out.toString());
                    rt.expire(FUND_RECORD, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /***
     *
     * @Title: getOrgType
     * @Description: 机构类型列表-私募机构高级搜索
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/orgType", method = RequestMethod.GET)
    public BaseOutData getOrgType() {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(ORG_TYPE);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(Contants.HBASE_PRIVATE_EQUITY_SEARCH_ORGTYPE_URL);
                if (null != out) {
                    rt.opsForValue().set(ORG_TYPE, out.toString());
                    rt.expire(ORG_TYPE, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * @return
     * @Title: getManageType
     * @Description: 管理类型列表-私募机构高级搜索
     * @return: BaseOutData
     */
    @RequestMapping(value = "/manageType", method = RequestMethod.GET)
    public BaseOutData getManageType() {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(MANAGE_TYPE);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(Contants.HBASE_PRIVATE_EQUITY_SEARCH_MANAGETYPE_URL);
                if (null != out) {
                    rt.opsForValue().set(MANAGE_TYPE, out.toString());
                    rt.expire(MANAGE_TYPE, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * @return
     * @Title: getOperationStatus
     * @Description: 运作状态列表-私募机构高级搜索
     * @return: BaseOutData
     */
    @RequestMapping(value = "/operationStatus", method = RequestMethod.GET)
    public BaseOutData getOperationStatus() {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(OPERATION_STATUS);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(Contants.HBASE_PRIVATE_EQUITY_SEARCH_OPERATIONSTATUS_URL);
                if (null != out) {
                    rt.opsForValue().set(OPERATION_STATUS, out.toString());
                    rt.expire(OPERATION_STATUS, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * @return
     * @Title: getIntegrityInfo
     * @Description: 诚信信息列表-私募机构高级搜索
     * @return: BaseOutData
     */
    @RequestMapping(value = "/integrityInfo", method = RequestMethod.GET)
    public BaseOutData getIntegrityInfo() {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(INTEGRITY_INFO);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(Contants.HBASE_PRIVATE_EQUITY_SEARCH_INTEGRITYINFO_URL);
                if (null != out) {
                    rt.opsForValue().set(INTEGRITY_INFO, out.toString());
                    rt.expire(INTEGRITY_INFO, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * @return
     * @Title: getTips
     * @Description: 提示事项列表-私募机构高级搜索
     * @return: BaseOutData
     */
    @RequestMapping(value = "/tips", method = RequestMethod.GET)
    public BaseOutData getTips() {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(TIPS);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(Contants.HBASE_PRIVATE_EQUITY_SEARCH_TIPS_URL);
                if (null != out) {
                    rt.opsForValue().set(TIPS, out.toString());
                    rt.expire(TIPS, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    private String getQueryTime(String foundDt) throws ParseException {
        String queryStr = "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
        Date startTime = null;
        Date endTime = null;
        String[] foundDtArr = foundDt.split("-");
        if (foundDtArr != null && foundDtArr.length > 1) {
            String startDateStr = foundDtArr[0];
            String endDateStr = foundDtArr[1];
            startTime = formatter.parse(startDateStr);
            endTime = formatter.parse(endDateStr);
            queryStr = "[" + sdf.format(startTime) + " TO " + sdf.format(endTime) + "]";
        }
        return queryStr;
    }

}
