package com.cscs.portal.entity;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * Created by sh on 2016/11/2.
 */
@Entity
@Table(name = "ACCOUNT_ROLE_XW", schema = "CS_PORTAL", catalog = "")
@IdClass(AccountRoleXwPK.class)
public class AccountRoleXw {
    private long accountId;
    private long roleId;
    private Long createBy;
    private Timestamp createDt;
    private Long updtBy;
    private Timestamp updtDt;
//    private Account accountByAccountId;

    @Id
    @Column(name = "ACCOUNT_ID")
    public long getAccountId() {
        return accountId;
    }

    public void setAccountId(long accountId) {
        this.accountId = accountId;
    }

    @Basic
    @Column(name = "ROLE_ID")
    public long getRoleId() {
        return roleId;
    }

    public void setRoleId(long roleId) {
        this.roleId = roleId;
    }

    @Basic
    @Column(name = "CREATE_BY")
    public Long getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }

    @Basic
    @Column(name = "CREATE_DT")
    public Timestamp getCreateDt() {
        return createDt;
    }

    public void setCreateDt(Timestamp createDt) {
        this.createDt = createDt;
    }

    @Basic
    @Column(name = "UPDT_BY")
    public Long getUpdtBy() {
        return updtBy;
    }

    public void setUpdtBy(Long updtBy) {
        this.updtBy = updtBy;
    }

    @Basic
    @Column(name = "UPDT_DT")
    public Timestamp getUpdtDt() {
        return updtDt;
    }

    public void setUpdtDt(Timestamp updtDt) {
        this.updtDt = updtDt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AccountRoleXw that = (AccountRoleXw) o;

        if (accountId != that.accountId) return false;
        if (roleId != that.roleId) return false;
        if (createBy != null ? !createBy.equals(that.createBy) : that.createBy != null) return false;
        if (createDt != null ? !createDt.equals(that.createDt) : that.createDt != null) return false;
        if (updtBy != null ? !updtBy.equals(that.updtBy) : that.updtBy != null) return false;
        return updtDt != null ? updtDt.equals(that.updtDt) : that.updtDt == null;

    }

    @Override
    public int hashCode() {
        int result = (int) (accountId ^ (accountId >>> 32));
        result = 31 * result + (int) (roleId ^ (roleId >>> 32));
        result = 31 * result + (createBy != null ? createBy.hashCode() : 0);
        result = 31 * result + (createDt != null ? createDt.hashCode() : 0);
        result = 31 * result + (updtBy != null ? updtBy.hashCode() : 0);
        result = 31 * result + (updtDt != null ? updtDt.hashCode() : 0);
        return result;
    }

//    @ManyToOne
//    @JoinColumn(name = "ACCOUNT_ID", referencedColumnName = "ACCOUNT_ID", nullable = false)
//    public Account getAccountByAccountId() {
//        return accountByAccountId;
//    }

//    public void setAccountByAccountId(Account accountByAccountId) {
//        this.accountByAccountId = accountByAccountId;
//    }
}
