package com.cscs.portal.dto;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ChangeRecord implements Comparable<ChangeRecord> {

	private String changeTime;
	private String contentAfter;
	private String contentBefore;
	private String changeItem;

	public String getChangeTime() {
		return changeTime;
	}

	public void setChangeTime(String changeTime) {
		this.changeTime = changeTime;
	}

	public String getContentAfter() {
		return contentAfter;
	}

	public void setContentAfter(String contentAfter) {
		this.contentAfter = contentAfter;
	}

	public String getContentBefore() {
		return contentBefore;
	}

	public void setContentBefore(String contentBefore) {
		this.contentBefore = contentBefore;
	}

	public String getChangeItem() {
		return changeItem;
	}

	public void setChangeItem(String changeItem) {
		this.changeItem = changeItem;
	}

	@Override
	public int compareTo(ChangeRecord o) {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date dt1;
		Date dt2;
		try {
			dt1 = df.parse(changeTime);
			dt2 = df.parse(o.getChangeTime());
			//降序
			if (dt1.getTime() > dt2.getTime()) {	
				return -1;
			} else if (dt1.getTime() < dt2.getTime()) {
				return 1;
			} else {
				return 0;
			}
		} catch (ParseException e) {
			return 0;
		}

	}
}
