package com.cscs.portal.services.impl;

import com.cscs.portal.entity.UserFollow;
import com.cscs.portal.services.MyFollowService;
import com.cscs.repository.UserFollowRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import java.util.List;

@Service
public class MyFollowServiceImpl implements MyFollowService {

    @Autowired
    private UserFollowRepository userFollowRepository;

    @PersistenceContext
    EntityManager em;

    public List<Object> listCompanys(Long userId) {
        String sql = "SELECT A.ID,A.COMPANYID,NVL(B.COMPANYID,0),NVL(B.ID,0) AS monitorId FROM  USER_FOLLOW A\n " +
                "LEFT JOIN USER_MONITOR B ON A.COMPANYID = B.COMPANYID AND A.USERID = B.USERID AND B.ISDEL = 0\n " +
                "WHERE A.ISDEL = 0 AND A.USERID = ?1";
        Query query = em.createNativeQuery(sql);
        query.setParameter(1, userId);
        return query.getResultList();
    }

    public void save(UserFollow info) {
        userFollowRepository.save(info);
    }

    @Transactional
    public void delete(Long id,Long userId) {
        String sql = "UPDATE USER_FOLLOW SET ISDEL = 1 WHERE id= ?1 and userid = ?2" ;
        Query query = em.createNativeQuery(sql);
        query.setParameter(1, id);
        query.setParameter(2, userId);
        query.executeUpdate();
    }

	@Override
	public List<UserFollow> queryFollowByCondition(UserFollow info) {
		String sql = "SELECT ID,USERID,COMPANYID,DT,ISDEL FROM USER_FOLLOW WHERE USERID = ?1 AND COMPANYID = ?2";
		Query query = em.createNativeQuery(sql,UserFollow.class);
        query.setParameter(1, info.getUserId());
        query.setParameter(2, info.getCompanyId());
        return query.getResultList();
	}
}
