package com.cscs.portal.dto;

/**
 * Created by sh on 2016/8/7.
 */
public class AccountInfoData {

    private long userId;
    private String accountNm;
    private String accountPw;
    private long activityType;
    private String code;
    private String accountPwConfirm;
    private String email;
    private String companyNm;
    private String authorizeCd;
    private String roleId;
    private long browser;
    private boolean regeditFlg;
    private String accountOldPw;

    public String getAccountPwConfirm() {
        return accountPwConfirm;
    }

    public void setAccountPwConfirm(String accountPwConfirm) {
        this.accountPwConfirm = accountPwConfirm;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getAuthorizeCd() {
        return authorizeCd;
    }

    public void setAuthorizeCd(String authorizeCd) {
        this.authorizeCd = authorizeCd;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getAccountNm() {
        return accountNm;
    }

    public void setAccountNm(String accountNm) {
        this.accountNm = accountNm;
    }

    public String getAccountPw() {
        return accountPw;
    }

    public void setAccountPw(String accountPw) {
        this.accountPw = accountPw;
    }

    public long getActivityType() {
        return activityType;
    }

    public void setActivityType(long activityType) {
        this.activityType = activityType;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCompanyNm() {
        return companyNm;
    }

    public void setCompanyNm(String companyNm) {
        this.companyNm = companyNm;
    }

    public long getBrowser() {
        return browser;
    }

    public void setBrowser(long browser) {
        this.browser = browser;
    }

    public boolean isRegeditFlg() {
        return regeditFlg;
    }

    public void setRegeditFlg(boolean regeditFlg) {
        this.regeditFlg = regeditFlg;
    }

    public String getAccountOldPw() {
        return accountOldPw;
    }

    public void setAccountOldPw(String accountOldPw) {
        this.accountOldPw = accountOldPw;
    }
}
