package com.cscs.portal.dto;

/**
 * 
 * @ClassName: BondIssuerConditon
 * @Description: 债券区域发行分布查询条件
 * @author: liunn
 * @date: 2018年9月15日 下午9:34:11
 */
public class BondAreaConditon{
	//类型
    private String type;
	//省份
	private String province;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	
	
}
