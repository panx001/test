package com.cscs.portal.dto;

public class NewsDetailOut {

	private Object relatedcompylist;
	private Object newsdetail;

	private String company_nm;
	
	public String getCompany_nm() {
		return company_nm;
	}

	public void setCompany_nm(String company_nm) {
		this.company_nm = company_nm;
	}

	public Object getRelatedcompylist() {
		return relatedcompylist;
	}

	public void setRelatedcompylist(Object relatedcompylist) {
		this.relatedcompylist = relatedcompylist;
	}

	public Object getNewsdetail() {
		return newsdetail;
	}

	public void setNewsdetail(Object newsdetail) {
		this.newsdetail = newsdetail;
	}

}
