package com.cscs.portal.services;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.response.QueryResponse;

import com.cscs.portal.dto.NewsSearchConditon;
import com.cscs.portal.dto.NewsSearchOut;

/**
 * 
 * @ClassName: RiskSearchServices
 * @Description: 发债企业高级搜索服务接口
 * @author: liunn
 * @date: 2018年10月20日 下午4:37:27
 */
public interface NewsSearchServices {
    /**
     * 
     * @Title: setSolrQuery
     * @Description: 组装SolrQuery参数
     * @return
     * @return: SolrQuery
     */
	SolrQuery setSolrQuery(NewsSearchConditon condition,SolrQuery query);
	
	/**
	 * 
	 * @Title: getResponseDate
	 * @Description: 组装返回参数
	 * @param response
	 * @return
	 * @return: List<RiskSearchOut>
	 */
	List<NewsSearchOut> getResponseDate(QueryResponse response) throws ParseException;
	/**
	 * 
	 * @Title: getNegativeNewsCompany
	 * @Description: 负面新闻
	 * @param response
	 * @return
	 * @throws ParseException
	 * @return: List<Map>
	 */
	public List<Object> getNegativeNewsCompany(QueryResponse response) throws Exception;
	/***
	 * 
	 * @Title: getAnnounce
	 * @Description: 公告分析 - 公告分析
	 * @param response
	 * @return
	 * @throws ParseException
	 * @return: List<Map>
	 */
	public List<Object> getAnnounce(QueryResponse response) throws ParseException;
	/**
	 * 
	 * @Title: getTrendNewsList
	 * @Description: 热度趋势-新闻详情
	 * @param response
	 * @return
	 * @throws ParseException
	 * @return: List<Map>
	 */
	public List<Object> getTrendNewsList(QueryResponse response) throws ParseException;
	/**
	 * 
	 * @Title: getRelatedNewsList
	 * @Description: 关联方资讯-新闻详情
	 * @param response
	 * @return
	 * @throws ParseException
	 * @return: List<Map>
	 */
	public List<Object> getRelatedNewsList(QueryResponse response) throws ParseException;
	/**
	 * 
	 * @Title: getNegativeNews24h
	 * @Description: 获取24小时负面舆情-新闻列表
	 * @param response
	 * @return
	 * @throws ParseException
	 * @return: List<Object>
	 */
	public List<Map<String,Object>> getNegativeNews24h(QueryResponse response) throws ParseException;
	
	public String getQueryTime(String foundDt) throws ParseException;
	/***
	 * 
	 * @Title: negativeNewsRank
	 * @Description: 企业舆情排行榜排序
	 * @param list
	 * @return
	 * @return: List
	 */
	public List negativeNewsRankSort(List<Map> list);

	/**
	 * 新闻关联企业列表
	 * @param newsId
	 * @return
	 * @throws SolrServerException
	 */
	public List<Map> getRelateCompanyList(String newsId) throws SolrServerException;

	/**
	 * 根据企业id和时间参数查询该企业的负面新闻
	 * @param companyId
	 * @param queryTime
	 * @return
	 * @throws SolrServerException
	 */
	public List<Map> getNewsByCompanyId(String companyId,String queryTime) throws SolrServerException;


	/***
	 * 设置facet
	 * @param keyword
	 * @return
	 */
	SolrQuery setFacetQuery(String keyword);
}
