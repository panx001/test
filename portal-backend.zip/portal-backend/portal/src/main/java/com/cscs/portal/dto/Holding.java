package com.cscs.portal.dto;

public class Holding  extends InvestmentBase{

	private String holdingType;

	public String getHoldingType() {
		return holdingType;
	}

	public void setHoldingType(String holdingType) {
		this.holdingType = holdingType;
	}

}
