package com.cscs.repository;

import com.cscs.portal.entity.CompyBasicinfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by Sai on 4/27/2016.
 */
@SuppressWarnings("JpaQlInspection")
public interface CompanyBasicInfoRepository extends JpaRepository<CompyBasicinfo, Long> {

@Query(value = "select c from CompyBasicinfo c where c.blnumb = ?1 or c.legRepresent = ?1  or c.companyNm like '%'||?1||'%' order by c.regCapital desc")
List<CompyBasicinfo> findByKeyword(String keyword);

    /*
     * Created by qin on 8/15/2016.
     * 根据公司名字与工商登记号查询
     */
    @Query(value = "select c from CompyBasicinfo c where c.blnumb = ?1 and c.companyNm like '%'||?1||'%' order by c.regCapital desc")
    List<CompyBasicinfo> findByAllKeyword(String allKeyword);
    /*
   * Created by qin on 8/12/2016.
   * 根据企业名查询
   *//*
        @Query(value = "select c from CompyBasicinfo c where c.companyNm like CONCAT('%',:companyNm,'%')")
    List<CompyBasicinfo> findCompyBasicInfoByName(@Param("companyNm") String companyNm);

    *//*
   * Created by qin on 8/12/2016.
   * 根据企业工商登记号查询
   *//*
    @Query(value = "select c from CompyBasicinfo c where c.blnumb like CONCAT('%',:blnumb,'%')")
    List<CompyBasicinfo> findCompyBasicInfoByBlnumb(@Param("blnumb")  String blnumb);

    *//*
  * Created by qin on 8/12/2016.
  * 根据企业注册资本查询
  *//*
    @Query(value = "select c from CompyBasicinfo c where c.regCapital between :firstNum and  :secondNum and ROWNUM<=100")
    List<CompyBasicinfo> findByRegCapital(@Param("firstNum") Long firstNum,@Param("secondNum") Long secondNum);*/

    @Query(value = "select c from CompyBasicinfo c where id=:id and isDel=0")
    CompyBasicinfo findByIdIgnoreCase(@Param("id") Long id);
}
