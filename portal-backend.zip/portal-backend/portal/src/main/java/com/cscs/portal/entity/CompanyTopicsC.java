package com.cscs.portal.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "COMPANY_TOPICS_C", schema = "CS_PORTAL", catalog = "")
//@IdClass(CompanyTopicsCPK.class)
public class CompanyTopicsC {
    private long id;
    private long companyTopicsId;
    private long companyId;
    private String companyNm;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_HOT_COMPANY_TOPICS")
    @SequenceGenerator(sequenceName = "SEQ_HOT_COMPANY_TOPICS", name = "SEQ_HOT_COMPANY_TOPICS")
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "COMPANY_TOPICS_ID")
    public long getCompanyTopicsId() {
        return companyTopicsId;
    }

    public void setCompanyTopicsId(long companyTopicsId) {
        this.companyTopicsId = companyTopicsId;
    }

    @Basic
    @Column(name = "COMPANY_ID")
    public long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(long companyId) {
        this.companyId = companyId;
    }

    @Basic
    @Column(name = "COMPANY_NM")
    public String getCompanyNm() {
        return companyNm;
    }

    public void setCompanyNm(String companyNm) {
        this.companyNm = companyNm;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CompanyTopicsC that = (CompanyTopicsC) o;
        return id == that.id &&
                companyTopicsId == that.companyTopicsId &&
                Objects.equals(companyId, that.companyId) &&
                Objects.equals(companyNm, that.companyNm);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, companyTopicsId, companyId, companyNm);
    }
}
