package com.cscs.mq;

import com.cscs.mq.base.BaseProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

/**
 * 需要测试单元测试类MQTests， 要放开Component注释
 */
//@Component
public class TestProducer extends BaseProducer {
    private static final Logger LOGGER = LoggerFactory.getLogger(TestProducer.class);

    /**
     * 初始化
     */
    @PostConstruct
    public void start() {
        init("TestRocketMQProducer");
    }

    /**
     * 发送消息
     *
     * @param data  消息内容
     * @param topic 主题
     * @param tags  标签
     * @param keys  唯一主键
     */
    public void sendMessage(String data, String topic, String tags, String keys) {
        sdMessage(data, topic, tags, keys);
    }

    @PreDestroy
    public void stop() {
        destroy();
    }
}
