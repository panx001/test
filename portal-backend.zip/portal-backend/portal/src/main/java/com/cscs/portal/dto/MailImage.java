package com.cscs.portal.dto;

import com.cscs.portal.dto.base.BaseOutData;

import java.util.List;

/**
 * Created by sh on 2016/8/7.
 */
public class MailImage {
    private String name;
    private String image;

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
