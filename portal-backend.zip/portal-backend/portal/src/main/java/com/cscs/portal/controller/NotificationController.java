package com.cscs.portal.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.shiro.authz.annotation.RequiresRoles;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cscs.portal.dto.SystemNotificationInfoData;
import com.cscs.portal.dto.SystemNotificationOutData;
import com.cscs.portal.dto.base.BaseInData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.SystemNotification;
import com.cscs.portal.services.NotificationService;

@CrossOrigin
@RestController
@RequestMapping(value = "/notification")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;
    
    @Autowired
    private AsyncTask asyncTask;

    /**
     * 未读消息数量
     *理员删除或者用户删除的消息都不算在总数和未读数里面
     * @return
     */
    @RequestMapping(value = "/unreadCount", method = RequestMethod.GET)
    public BaseOutData getUnreadCount(HttpServletRequest request) {
        BaseOutData outData = new BaseOutData();
        Long userId = Long.valueOf((String)request.getAttribute("userId"));
        outData.setCount(notificationService.getUnreadCount(userId));
        return outData;
    }

    /**
     * 我的消息总数
     *理员删除或者用户删除的消息都不算在总数和未读数里面
     * @return
     */
    @RequestMapping(value = "/getAllCount", method = RequestMethod.GET)
    public BaseOutData getAllCount(HttpServletRequest request) {
        BaseOutData outData = new BaseOutData();
        Long userId = Long.valueOf((String)request.getAttribute("userId"));
        outData.setCount(notificationService.getAllCount(userId));
        return outData;
    }

    /**
     * 我的消息列表(用户查看自己的消息列表)
     *userId
     * @return
     */
    @RequestMapping(value = "/getAll", method = RequestMethod.POST)
    public List<SystemNotificationOutData> getAll(HttpServletRequest request,@RequestBody BaseInData inData) {
        List<SystemNotificationOutData> outData = new ArrayList<>();
        Long userId = Long.valueOf((String)request.getAttribute("userId"));
        List<Object> itemList = notificationService.getAll(inData,userId);
        SystemNotificationOutData info = null;
        for (int i = 0; i < itemList.size(); i++) {
            Object[] item = (Object[]) itemList.get(i);
            info = new SystemNotificationOutData();
            info.setId(Long.valueOf(item[0].toString()));
            info.setTitle(item[1].toString());
            info.setContent(item[2].toString());
            info.setDt(item[3].toString());
            info.setIsRead(Long.valueOf(item[4].toString()));
            outData.add(info);
        }
        return outData;
    }

    /**
     * 获取通知正文
     *id(USER_SYSTEM_NOTIFICATION.id)
     * @return
     */
    @RequestMapping(value = "/detail/{id}", method = RequestMethod.GET)
    public SystemNotificationOutData getContent(@PathVariable Long id) {
        SystemNotificationOutData outData = new SystemNotificationOutData();
        Object[] item = (Object[]) notificationService.getContent(id);
        outData.setId(Long.valueOf(item[0].toString()));
        outData.setTitle(item[1].toString());
        outData.setContent(item[2].toString());
        outData.setDt(item[3].toString());
        return outData;
    }

    /**
     * 设置通知已读
     *id(USER_SYSTEM_NOTIFICATION.id)
     * @return
     */
    @RequestMapping(value = "/markRead/{idList}", method = RequestMethod.GET)
    public BaseOutData markRed(HttpServletRequest request,@PathVariable String idList) {
        BaseOutData outData = new BaseOutData();
        Long userId = Long.valueOf((String)request.getAttribute("userId"));
        try {
            notificationService.markRead(idList,userId);
            outData.setCode("0");
        } catch (Exception ex) {
            outData.setCode("1");
        }
        return outData;
    }

    /**
     * 用户删除通知
     *	id(USER_SYSTEM_NOTIFICATION.id)
     * @return
     */
    @RequestMapping(value = "/deleteUser/{idList}", method = RequestMethod.GET)
    public BaseOutData deleteUser(HttpServletRequest request,@PathVariable String idList) {
        BaseOutData outData = new BaseOutData();
        Long userId = Long.valueOf((String)request.getAttribute("userId"));
        try {
            notificationService.deleteUser(idList,userId);
            outData.setCode("0");
        } catch (Exception ex) {
            outData.setCode("1");
        }
        return outData;
    }

    /**
     * 管理员删除通知
     *id(SYSTEM_NOTIFICATION.id)
     * @return
     */
    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
    public BaseOutData delete(@PathVariable Long id) {
        BaseOutData outData = new BaseOutData();
        try {
            SystemNotification info = notificationService.findOne(id);
            if (info.getStatus() == 1L) {
                outData.setCode("1");
                outData.setMessage("已发布的消息无法删除！");
                return outData;
            }
            notificationService.delete(id);
            outData.setCode("0");
        } catch (Exception ex) {
            outData.setCode("1");
        }
        return outData;
    }

    /**
     * 管理员获取消息总数
     *理员删除的消息都不算在总数里面
     * @return
     */
    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/adminGetCount", method = RequestMethod.GET)
    public BaseOutData getAdminCount() {
        BaseOutData outData = new BaseOutData();
        outData.setCount(notificationService.getAdminCount());
        return outData;
    }

    /**
     * 管理员获取系统通知列表
     * id(SYSTEM_NOTIFICATION.id)
     * @return
     */
    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/adminGetAll", method = RequestMethod.POST)
    public BaseOutData getAllNotifications(@RequestBody BaseInData inData) {
        List<SystemNotificationOutData> result = new ArrayList<>();
        BaseOutData outData = new BaseOutData();
        Map<String,List<SystemNotificationOutData>> resultMap = new HashMap<>();
        List<Object> itemList = notificationService.getAllAdmin(inData,outData);
        SystemNotificationOutData info = null;
        for (int i = 0; i < itemList.size(); i++) {
            Object[] item = (Object[]) itemList.get(i);
            info = new SystemNotificationOutData();
            info.setId(Long.valueOf(item[0].toString()));
            info.setTitle(item[1].toString());
            info.setContent(item[2].toString());
            info.setDt(item[3].toString());
            info.setStatus(Long.valueOf(item[4].toString()));
            result.add(info);
        }
        resultMap.put("result",result);
        outData.setData(resultMap);
        return outData;
    }

    /**
     * 创建消息
     *
     * @return
     */
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public BaseOutData create(@RequestBody SystemNotificationInfoData inData) {
        BaseOutData outData = new BaseOutData();
        try {
            SystemNotification info = new SystemNotification();
            if (inData.getId() != 0L) {
                info = notificationService.findOne(inData.getId());
                if (info != null && info.getStatus() == 1L) {
                    outData.setCode("1");
                    outData.setMessage("已发布的消息无法编辑！");
                    return outData;
                }
            } else {
                info.setIsRelation(0L);
            }
            BeanUtils.copyProperties(inData, info);
            info.setDt(new Date());
            info.setIsdel(0L);
            notificationService.save(info);
            outData.setCode("0");
            //调用异步任务
            //asyncTask.linkUser();
            if(info.getStatus()==1L) {
            	asyncTask.linkUserCurNotify(info.getId());
            }
        } catch (Exception ex) {
            outData.setCode("1");
        }
        return outData;
    }
}
