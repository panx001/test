package com.cscs.portal.services.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.springframework.stereotype.Service;

import com.cscs.portal.dto.PsecSearchConditon;
import com.cscs.portal.dto.PsecSearchOut;
import com.cscs.portal.services.PFundSearchServices;

/***
 * 
 * @ClassName: RiskSearchServicesImpl
 * @Description: 私募机构高级搜索服务实现类
 * @author: liunn
 * @date: 2018年10月20日 下午4:36:59
 */
@Service
public class PFundSearchServicesImpl implements PFundSearchServices {
	protected final Log logger = LogFactory.getLog(this.getClass());

	@Override
	public SolrQuery setSolrQuery(PsecSearchConditon condition,SolrQuery query) {
		//查询关键字，q不能省略
        if (StringUtils.isNotEmpty(condition.getKeyword())) {
        	query.set("q",condition.getKeyword());
        } else {
            query.set("q", "*:*");
        }
      //Boost Functions。用函数的方式计算boost。 
		query.set("bf", "log(max(regcapital,1))^8");
		//此参数用于控制小写单词作为布尔运算符，如”and” and “or”。设置与lowercaseOperators= true来允许此。默认为true
		query.set("lowercaseOperators", "true");
		//返回字段
		query.set("fl", "score,*");
		//指定query parser，常用defType=lucene, defType=dismax, defType=edismax
		query.set("defType", "edismax");
		//query fields，指定solr从哪些field中搜索 设置查询权重值
		query.set("qf", "lvl1_keyword^100 lvl2_keyword lvl3_keyword^0.1");
		//boosting phrases over words。用于指定一组field，当query完全匹配pf指定的某一个field时，来进行boost
		query.set("pf", "lvl2_keyword");
		//单词停用，true 或false
		query.set("stopwords", "true");
		//只查询存活的分片
		query.set("shards.tolerant", "true");
        //排序
        //参数：field域，排序类型（asc,desc）score desc,regcapital desc
        query.addSort("score", SolrQuery.ORDER.desc);
        query.addSort("regcapital", SolrQuery.ORDER.desc);
        //分页
        //实际开发时，知道当前页码和每页显示的个数最后求出开始下标
        int curPage = condition.getCurPage() == null ? 1 : condition.getCurPage();
        int rows = condition.getRowNum() == null ? 10 : condition.getRowNum();
        //计算出开始记录下标
        int start = rows * (curPage - 1);
        //向query中设置分页参数
        query.setStart(start);
        query.setRows(rows);
        //开启高亮
        query.setHighlight(true);
        //设置高亮 参数
        query.addHighlightField("company_nm,legal_person_nm,old_company_nm,security_snm,credit_cd,security_cd");
        //设置高亮前缀和后缀
        query.setHighlightSimplePre("<span class=\"highlight\">");
        query.setHighlightSimplePost("</span>");
		return query;
	}
	
	@Override
	public List<PsecSearchOut> getResponseDate(QueryResponse response){
		List<PsecSearchOut> returnList = new ArrayList<PsecSearchOut>();
		//从响应中得到结果
        SolrDocumentList documents = response.getResults();

        //从响应中获得高亮信息
        Map<String, Map<String, List<String>>> highlighting = response.getHighlighting();

        for (SolrDocument document : documents) {
            PsecSearchOut data = new PsecSearchOut();
            if (null != document.get("id")) {
                data.setCompanyId(String.valueOf(document.get("id")));
            }
            if (null != document.get("company_nm")) {
                data.setCompanyName(String.valueOf(document.get("company_nm")));
            }

            //公司状态
            if (null != document.get("company_st")) {
				data.setCompanySt(String.valueOf(document.get("company_st")));
            }
            if (null != document.get("legal_person_nm")) {
                data.setLegalPersonName(String.valueOf(document.get("legal_person_nm")));
            }
            if (null != document.get("regcapital")) {
                data.setRegCapital(document.get("regcapital"));
            }
            if (null != document.get("reg_region")) {
                data.setOfficeAddr(String.valueOf(document.get("reg_region")));
            }
            if (null != document.get("reg_num")) {
                data.setRegNum(String.valueOf(document.get("reg_num")));
            }
            if (null != document.get("pfound_dt")) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                data.setFoundDt(sdf.format((Date) document.get("pfound_dt")));
            }
            if (null != document.get("pfreg_dt")) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                data.setRegDt(sdf.format((Date) document.get("pfreg_dt")));
            }
            if (null != document.get("product_num")) {
                data.setProductNum(String.valueOf(document.get("product_num")));
            }
            if (null != document.get("pfreg_phase")) {
                List list = (List) document.get("pfreg_phase");
                data.setRegPhase(list);
            }
            //机构类型
            if (null != document.get("pfund_type")) {
                data.setOrgType(String.valueOf(document.get("pfund_type")));
            }
            if (null != document.get("pfmag_type")) {
                List list = (List) document.get("pfmag_type");
                data.setManageType(list);
            }
            //运作状态
            if (null != document.get("pfoper_status")) {
            	List list = (List) document.get("pfoper_status");
                data.setState(list);
            }
            if (null != document.get("pfwarn_info")) {
            	data.setTipInfo(String.valueOf(document.get("pfwarn_info")));
            }
            if (null != document.get("pftip_info")) {
                data.setIntegrityInfo(String.valueOf(document.get("pftip_info")));
            }
            if(null != document.get("credit_cd")) {
				data.setCreditCd(String.valueOf(document.get("credit_cd")));
			}
			if(null != document.get("old_company_nm")) {
				data.setOldCompanyNm(String.valueOf(document.get("old_company_nm")));
			}
			if(null != document.get("security_snm")) {
				List list = (List)document.get("security_snm");
				data.setSecuritySnm(list);
			}
			if(null != document.get("security_cd")) {
				List list = (List)document.get("security_cd");
				data.setSecurityCd(list);
			}
			//是否新三板
			if (null != document.get("islist3")) {
				data.setIslist3(String.valueOf(document.get("islist3")));
			}
			//是否发债
			if (null != document.get("isbond")) {
				data.setIsbond(String.valueOf(document.get("isbond")));
			}
            //获得高亮的信息
            if (highlighting != null) {
                //根据主键获取高亮信息
                Map<String, List<String>> map = highlighting.get(document.get("id"));
                if (map != null) {
                	List highlightColumns = new ArrayList();
                	List<String> companyNameList = map.get("company_nm");
					List<String> legalPersonNmList = map.get("legal_person_nm");
					List<String> securitySnmList = map.get("security_snm");
					List<String> securityCdList = map.get("security_cd");
					List<String> oldCompanyNmList = map.get("old_company_nm");
					List<String> creditCdList = map.get("credit_cd");
					if(companyNameList!=null){
						data.setCompanyName(companyNameList.get(0));
						highlightColumns.add("companyName");
					}
					if(legalPersonNmList!=null){
						data.setLegalPersonName(legalPersonNmList.get(0));
						highlightColumns.add("legalPersonName");
					}
					if(securitySnmList!=null){
						data.setSecuritySnm(securitySnmList);
						highlightColumns.add("securitySnm");
					}
					if(securityCdList!=null){
						data.setSecurityCd(securityCdList);
						highlightColumns.add("securityCd");
					}
					if(oldCompanyNmList!=null){
						data.setOldCompanyNm(oldCompanyNmList.get(0));
						highlightColumns.add("oldCompanyNm");
					}
					if(creditCdList!=null){
						data.setCreditCd(creditCdList.get(0));
						highlightColumns.add("creditCd");
					}
					data.setHighlightColumns(highlightColumns);
                }
            }
            returnList.add(data);
        }
		return returnList;
	}
	@Override
	public List<Map> cancelRecord(QueryResponse response){
		List<Map> returnList = new ArrayList<Map>();
		//从响应中得到结果
		SolrDocumentList documents = response.getResults();
		
		for (SolrDocument document : documents) {
			Map map = new HashMap();
			map.put("companyId", document.get("id"));
			map.put("name", document.get("company_nm"));
			map.put("date", "");
			returnList.add(map);
		}
		return returnList;
	}
	
	@Override
	public String getQueryTime(String foundDt) throws ParseException {
    	String queryStr = "";
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    	SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
    	Date startTime = null;
    	Date endTime = null;
    	String[] foundDtArr = foundDt.split("-");
    	if(foundDtArr!=null && foundDtArr.length>1) {
    		String startDateStr = foundDtArr[0];
    		String endDateStr = foundDtArr[1];
    		startTime = formatter.parse(startDateStr);
			endTime = formatter.parse(endDateStr);
			queryStr = "found_dt:["+sdf.format(startTime)+" TO "+sdf.format(endTime)+"]";
    	}
    	return queryStr;
    }
}
