package com.cscs.portal.services.impl;

import com.cscs.portal.services.CacheServices;
import com.cscs.util.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * Created by huchangchun on 2017/2/15.
 */
@Service
public class CacheServicesImpl implements CacheServices {

    private String curDate = DateUtils.getCurrentDate();

    @PersistenceContext
    EntityManager em;

    @Autowired
    RedisTemplate redisTemplate;

    public Set<String> getAccessRecord(String key) {
        return (Set<String>) redisTemplate.opsForValue().get(key);
    }

    public void updateAccessRecord(String key, Set<String> set) {
        redisTemplate.opsForValue().set(key, set);
        redisTemplate.expireAt(key, DateUtils.getNextDate());
    }

    public void updateAuthRecord(String key, int count) {
        redisTemplate.opsForValue().set(key, count);
    }

    public int getAuthRecord(String key) {
        Object value = redisTemplate.opsForValue().get(key);
        if (value != null) {
            return Integer.valueOf(value.toString());
        }
        return 0;
    }

    public void updateUser(String key, String value) {
        redisTemplate.opsForValue().set(key, value);
        redisTemplate.expire(key, 2, TimeUnit.HOURS);
    }

    public void deleteUser(String key) {
        redisTemplate.opsForValue().getOperations().delete(key);
    }

    public String getUser(String key) {
        return (String) redisTemplate.opsForValue().get(key);
    }

    //清空userCache缓存
    @CacheEvict(value = "user", allEntries = true)
    public void clearUser() {
    }

    //清空accountCache缓存
    @CacheEvict(value = "accessRecord", allEntries = true)
    public void clearAccessRecord() {
    }

    @CacheEvict(value = "cache", allEntries = true)// 清空 accountCache 缓存
    public void reload() {
        //clean
    }

    @Cacheable(value = "exposure")
    public Set<Long> getPlatformCompanyIds() {
        Query query = em
                .createNativeQuery(
                        "SELECT COMPANY_ID FROM COMPY_EXPOSURE WHERE EXPOSURE_SID = 6355 AND IS_NEW = 1 AND ISDEL = 0");
        List<Number> rs = query.getResultList();
        Set<Long> set = new HashSet<Long>();
        for (Number o : rs) {
            set.add(o.longValue());
        }
        return set;
    }
}
