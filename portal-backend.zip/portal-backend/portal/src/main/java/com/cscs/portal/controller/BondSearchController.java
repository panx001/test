package com.cscs.portal.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cscs.portal.dto.BondIssuerConditon;
import com.cscs.portal.dto.BondSearchConditon;
import com.cscs.portal.dto.BondSearchOut;
import com.cscs.portal.dto.RiskInfoSearchCondition;
import com.cscs.portal.dto.RiskSearchOut;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.services.BondSearchServices;
import com.cscs.portal.services.RiskSearchServices;
import com.cscs.util.Contants;
import com.cscs.util.DateUtils;
import com.cscs.util.HttpUtil;
import com.cscs.util.KylinAPI;
import com.cscs.util.SolrUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.response.FacetField;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/***
 * 
 * @ClassName: BondCompanySearchController
 * @Description: 发债企业高级搜索相关接口
 * @author: liunn
 * @date: 2018年9月17日 下午2:41:19
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/bond/search")
public class BondSearchController {
	protected final Log logger = LogFactory.getLog(this.getClass());
	//债券违约统计
	public static String BOND_DEFAULTS_STA = "b_s_defsta";
	//债券违约统计企业列表
	public static String BOND_DEFAULTS_STA_LIST = "b_s_defstalist";
	//主体评级下调统计
	public static String RATING_DOWN_STA = "b_s_downsta";
	//主体评级下调统计企业列表
	public static String RATING_DOWN_STA_LIST = "b_s_downstalist";
	//财务风险-非标准审计意见统计
	public static String FINANCIAL_RISK_STA = "b_s_fin_risksta";
	//财务风险-非标准审计意见统计企业列表
	public static String FINANCIAL_RISK_STA_LIST = "b_s_fin_riskstalist";
	//债券发行人统计-现债券融资额统计
	public static String BOND_ISSUER_CURRENT = "b_s_issuercurrent";
	//债券发行人统计-年内应归还债券额统计
	public static String BOND_ISSUER_WITHIN_YEAR = "b_s_withinyear";
	//债券发行人统计-存续期债券数
	public static String BOND_ISSUER_DURATION = "b_s_duration";
	//债券市场规模-债券市场上月发行情况
	public static String BOND_MARKET_PUBLISH_STA = "b_s_premonthsta";
	//债券市场规模-信用债市场净融资情况-按月
	public static String BOND_MARKET_FINANCING_STA = "b_s_financingsta";
	//债券区域发行分布-区域top10
	public static String BOND_AREA_PUBLISH_TOP10 = "b_s_areatop10";
	//债券区域发行分布-数量最多的省份
	public static String MAXP_ROVINCE = "b_s_maxprovince";
	//债券区域发行分布-按省份查询
	public static String PUBLISH_PROVINCE = "b_s_publishprovince";
	//最新投资等级列表
	public static String INVEST_GRADE = "b_s_investgrade";
	//最新主体评级列表
	public static String LAST_RATING = "b_s_lastrating";
	//最新评级展望列表
	public static String RATING_OUTLOOK = "b_s_ratingoutlook";
	//发债类型列表
	public static String BOND_TYPE = "b_s_bondtype";
	//审计意见列表
	public static String AUDIT_OPINION = "b_s_auditopinion";
	//行业列表
	public static String INDUSTRY_LIST = "b_s_industrylist";
	//重要财务指标不利变化列表
	public static String FINANCIAL_INDEX_CHANGE = "b_s_financialchange";
	
	public static String OFFICE_ADDR = "cs_officeaddr";
	
	@Autowired
    private StringRedisTemplate rt;
	//风险高级搜索服务
	@Autowired
    RiskSearchServices riskSearchServices;
	//发债企业高级搜索服务
	@Autowired
	BondSearchServices bondSearchServices;
	
	/***
     * 
     * @Title: getResult
     * @Description: 发债企业高级搜索
     * @param condition
     * @return
     * @return: Object
     */
    @RequestMapping(value = "/getResult", method = RequestMethod.POST)
    public Object getResult(@RequestBody BondSearchConditon condition){
    	BaseOutData outData = new BaseOutData();
    	List<BondSearchOut> returnList = null;
    	long numFound = 0L;
    	try {
    		//创建Solr服务对象，通过此对象向solr服务发起请求
    		SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_BOND_METHOD);
    		//创建查询对象
    		SolrQuery query = new SolrQuery();

    		//设置公共查询参数
    		query = bondSearchServices.setSolrQuery(condition, query);
    		/*****************************过滤条件start*****************************************/
    		//过滤投资等级
    		if(StringUtils.isNotEmpty(condition.getBondLevel())) {
    			query.addFilterQuery("rating_level:\""+condition.getBondLevel()+"\"");
    		}
    		//过滤主体评级
    		if(StringUtils.isNotEmpty(condition.getCreditChg())) {
    			query.addFilterQuery("credit_chg:\""+condition.getCreditChg()+"\"");
    		}
    		//过滤评级展望
    		if(StringUtils.isNotEmpty(condition.getRatingFwd())) {
    			query.addFilterQuery("rating_fwd_current:\""+condition.getRatingFwd()+"\"");
    		}
    		//过滤发债类型
    		if(StringUtils.isNotEmpty(condition.getBondType())) {
    			query.addFilterQuery("bond_type:\""+condition.getBondType()+"\"");
    		}
    		//过滤审计意见
    		if(StringUtils.isNotEmpty(condition.getFinanceAudit())) {
    			query.addFilterQuery("finance_audit:\""+condition.getFinanceAudit()+"\"");
    		}
    		//过滤注册地
    		if(StringUtils.isNotEmpty(condition.getRegRegion())) {
    			query.addFilterQuery("reg_region:\""+condition.getRegRegion()+"\"");
    		}
    		//过滤行业
    		if(StringUtils.isNotEmpty(condition.getIndustry())) {
    			query.addFilterQuery("industry:\""+condition.getIndustry()+"\"");
    		}
    		//重要财务指标不利变化
    		if(StringUtils.isNotEmpty(condition.getFinanceFactor())) {
    			String[] arr = condition.getFinanceFactor()!=null?condition.getFinanceFactor().split(","):null;
    			for(int i=0;arr!=null&&i<arr.length;i++) {
    				query.addFilterQuery("finance_factor:\""+arr[i]+"\"");
    			}
    		}
    		/*****************************过滤条件end*****************************************/
    		
    		//执行查询
    		QueryResponse response = solrServer.query(query);
    		//返回数量
    		numFound = response.getResults().getNumFound();
    		//获取返回数据
    		returnList = bondSearchServices.getResponseDate(response);
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        Map data = new HashMap();
        data.put("result", returnList);
        outData.setCode("0");
        outData.setCount((int)numFound);
        outData.setMessage("返回成功!");
        outData.setData(data);
    	return outData;
    }

    /***
     * 
     * @Title: bondDefaultsSta
     * @Description: 债券违约统计-按债券类型
     * @param inData
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/bondTypeSta", method = RequestMethod.POST)
    public BaseOutData bondTypeSta(@RequestBody Map<String,String> inData) {
		BaseOutData outData = new BaseOutData();
		String startdt = inData.get("startdt");
		String enddt = inData.get("enddt");
        Object obj = null;
        List returnList = new ArrayList();
        try {
        	startdt = DateUtils.formatDate(startdt, "yyyyMMdd", "yyyy-MM-dd");
    		enddt = DateUtils.formatDate(enddt, "yyyyMMdd", "yyyy-MM-dd");
        	StringBuffer sb = new StringBuffer();
        	sb.append("select bondtype,count(distinct secinner_id) as 违约量  ");
        	sb.append("from ");
        	sb.append("tmp_htable_bond_stat_kylin where viola_occurdt is not null and ");
        	sb.append("viola_occurdt>='"+startdt+"' ");
        	sb.append("and ");
        	sb.append("viola_occurdt<='"+enddt+"' group by bondtype");
			String result =KylinAPI.query(sb.toString(),0,-1);
			JSONObject jsonObj = JSON.parseObject(result);
			obj = jsonObj.get("results");
			//排序
			if(obj!=null) {
                List<List<String>> list = (List)obj;
				Collections.sort(list,new Comparator<List<String>>(){
					public int compare(List<String> arg0, List<String> arg1) {
						Double intArg1=Double.valueOf(arg1.get(1));
						Double intArg0=Double.valueOf(arg0.get(1));
						return intArg1.compareTo(intArg0);
					}
				});
                for (List<String> innerList : list) {
                    Map map = new HashMap();
                    map.put("name", innerList.get(0));
                    map.put("count", innerList.get(1));
                    returnList.add(map);
                }
			}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        Map data = new HashMap();
        data.put("result", returnList);
        outData.setCode("0");
        outData.setCount(0);
        outData.setMessage("返回成功!");
        outData.setData(data);
    	return outData;
    }
    /***
     * 
     * @Title: bondDefaultsSta
     * @Description: 债券违约统计-按行业
     * @param inData
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/industrySta", method = RequestMethod.POST)
    public BaseOutData industrySta(@RequestBody Map<String,String> inData) {
		BaseOutData outData = new BaseOutData();
		String startdt = inData.get("startdt");
		String enddt = inData.get("enddt");
		List returnList = new ArrayList();
		try {
			//创建Solr服务对象，通过此对象向solr服务发起请求
			SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_RISK_METHOD);
			//创建查询对象
			SolrQuery query = new SolrQuery();
			//设置公共查询参数
			query = riskSearchServices.queryCondition(new RiskInfoSearchCondition(), query);
			//过滤风险类型
			query.addFilterQuery("risk_type:\"债券违约\"");
			//过滤风险时间
			query.addFilterQuery("dt:"+riskSearchServices.getQueryTime(startdt,enddt));
			query.setFacet(true);
			//按行业统计
			query.addFacetField("industry");
			query.setFacetMinCount(1);
			//执行查询
			QueryResponse response = solrServer.query(query);
			FacetField facetField = response.getFacetField("industry");
			if (facetField != null) {
				List<FacetField.Count> counts = facetField.getValues();
				for (FacetField.Count count : counts) {
					Map map = new HashMap();
					map.put("name", count.getName());
					map.put("count", count.getCount());
					returnList.add(map);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        /*Object obj = null;
        List<List<String>> list = null;
        try {
        	startdt = DateUtils.formatDate(startdt, "yyyyMMdd", "yyyy-MM-dd");
    		enddt = DateUtils.formatDate(enddt, "yyyyMMdd", "yyyy-MM-dd");
        	StringBuffer sb = new StringBuffer();
        	sb.append("select industry,count(distinct secinner_id) as 违约量 ");
        	sb.append("from ");
        	sb.append("tmp_htable_bond_stat_kylin where viola_occurdt is not null and industry is not null and ");
        	sb.append("viola_occurdt>='"+startdt+"' ");
        	sb.append("and ");
        	sb.append("viola_occurdt<='"+enddt+"' group by industry");
			String result =KylinAPI.query(sb.toString(),0,-1);
			JSONObject jsonObj = JSON.parseObject(result);
			obj = jsonObj.get("results");
			//排序
			if(obj!=null) {
				list = (List)obj;
				Collections.sort(list,new Comparator<List<String>>(){
					public int compare(List<String> arg0, List<String> arg1) {
						Double intArg1=Double.valueOf(arg1.get(1));
						Double intArg0=Double.valueOf(arg0.get(1));
						return intArg1.compareTo(intArg0);
					}
				});
			}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}*/
        Map data = new HashMap();
        data.put("result", returnList);
        outData.setCode("0");
        outData.setCount(0);
        outData.setMessage("返回成功!");
        outData.setData(data);
    	return outData;
    }
    /**
     * 
     * @Title: bondDefaultsStaList
     * @Description: 债券违约统计企业列表
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/bondDefaultsStaList", method = RequestMethod.POST)
    public BaseOutData bondDefaultsStaList(@RequestBody RiskInfoSearchCondition condition) {
    	BaseOutData outData = new BaseOutData();
    	List<RiskSearchOut> returnList = null;
    	long numFound = 0L;
    	try {
    		//创建Solr服务对象，通过此对象向solr服务发起请求
    		SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_RISK_METHOD);
    		//创建查询对象
    		SolrQuery query = new SolrQuery();
    		//设置公共查询参数
    		query = riskSearchServices.queryCondition(condition, query);
    		/*****************************设置过滤条件start*****************************************/
    		//过滤债券类型
    		if(StringUtils.isNotEmpty(condition.getBondtype())) {
    			query.addFilterQuery("bondtype:\""+condition.getBondtype()+"\"");
    		}
    		//过滤所属行业
    		if(StringUtils.isNotEmpty(condition.getIndustry())) {
    			query.addFilterQuery("industry:\""+condition.getIndustry()+"\"");
    		}
    		//过滤风险类型
    		query.addFilterQuery("risk_type:\"债券违约\"");
    		//过滤风险时间
    		if(StringUtils.isNotEmpty(condition.getDt())) {
    			String queryString = riskSearchServices.getQueryTime2(condition.getDt());
    			query.addFilterQuery("dt:"+queryString);
    		}
    		/*****************************设置过滤条件end*****************************************/
    		//执行查询
    		QueryResponse response = solrServer.query(query);
    		//返回数量
    		numFound = response.getResults().getNumFound();
    		//获取返回数据
    		returnList = riskSearchServices.getBondDefaultsResult(response);
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        Map data = new HashMap();
        data.put("result", returnList);
        outData.setCode("0");
        outData.setCount((int)numFound);
        outData.setMessage("返回成功!");
        outData.setData(data);
    	return outData;
    }
    /***
     * 
     * @Title: ratingDownSta
     * @Description: 主体评级下调统计-按地区
     * @param inData
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/regionSta", method = RequestMethod.POST)
    public BaseOutData ratingDownSta(@RequestBody Map<String,String> inData) {
		BaseOutData outData = new BaseOutData();
		String startdt = inData.get("startdt");
		String enddt = inData.get("enddt");
		List returnList = new ArrayList();
		try {
			//创建Solr服务对象，通过此对象向solr服务发起请求
			SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_RISK_METHOD);
			//创建查询对象
			SolrQuery query = new SolrQuery();
			//设置公共查询参数
			query = riskSearchServices.queryCondition(new RiskInfoSearchCondition(), query);
			//过滤风险类型
			query.addFilterQuery("risk_type:\"主体评级下调\"");
			//过滤风险时间
			query.addFilterQuery("dt:"+riskSearchServices.getQueryTime(startdt,enddt));
			query.setFacet(true);
			//按行业统计
			query.addFacetField("reg_region");
			query.setFacetMinCount(1);
			//执行查询
			QueryResponse response = solrServer.query(query);
			FacetField facetField = response.getFacetField("reg_region");
			if (facetField != null) {
				List<FacetField.Count> counts = facetField.getValues();
				for (FacetField.Count count : counts) {
					Map map = new HashMap();
					map.put("name", count.getName());
					map.put("count", count.getCount());
					returnList.add(map);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        /*Object obj = null;
        List<List<String>> list = null;
        try {
        	startdt = DateUtils.formatDate(startdt, "yyyyMMdd", "yyyy-MM-dd");
    		enddt = DateUtils.formatDate(enddt, "yyyyMMdd", "yyyy-MM-dd");
        	StringBuffer sb = new StringBuffer();
        	sb.append("select region,count(distinct company_id) ");
        	sb.append("from ");
        	sb.append("tmp_htable_compy_stat_kylin where ratingdt is not null and ");
        	sb.append("ratingdt>='"+startdt+"' ");
        	sb.append("and ");
        	sb.append("ratingdt<='"+enddt+"' group by region");
			String result =KylinAPI.query(sb.toString(),0,-1);
			JSONObject jsonObj = JSON.parseObject(result);
			obj = jsonObj.get("results");
			//排序
			if(obj!=null) {
				list = (List)obj;
				Collections.sort(list,new Comparator<List<String>>(){
					public int compare(List<String> arg0, List<String> arg1) {
						Double intArg1=Double.valueOf(arg1.get(1));
						Double intArg0=Double.valueOf(arg0.get(1));
						return intArg1.compareTo(intArg0);
					}
				});
			}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}*/
        Map data = new HashMap();
        data.put("result", returnList);
        outData.setCode("0");
        outData.setCount(0);
        outData.setMessage("返回成功!");
        outData.setData(data);
    	return outData;
    }
    /***
     * 
     * @Title: ratingDownSta
     * @Description: 主体评级下调统计-按企业属性
     * @param inData
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/companyTypeSta", method = RequestMethod.POST)
    public BaseOutData companyTypeSta(@RequestBody Map<String,String> inData) {
		BaseOutData outData = new BaseOutData();
		String startdt = inData.get("startdt");
		String enddt = inData.get("enddt");
		List returnList = new ArrayList();
		try {
			//创建Solr服务对象，通过此对象向solr服务发起请求
			SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_RISK_METHOD);
			//创建查询对象
			SolrQuery query = new SolrQuery();
			//设置公共查询参数
			query = riskSearchServices.queryCondition(new RiskInfoSearchCondition(), query);
			//过滤风险类型
			query.addFilterQuery("risk_type:\"主体评级下调\"");
			//过滤风险时间
			query.addFilterQuery("dt:"+riskSearchServices.getQueryTime(startdt,enddt));
			query.setFacet(true);
			//按行业统计
			query.addFacetField("company_type");
			query.setFacetMinCount(1);
			//执行查询
			QueryResponse response = solrServer.query(query);
			FacetField facetField = response.getFacetField("company_type");
			if (facetField != null) {
				List<FacetField.Count> counts = facetField.getValues();
				for (FacetField.Count count : counts) {
					Map map = new HashMap();
					map.put("name", count.getName());
					map.put("count", count.getCount());
					returnList.add(map);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
    	/*Object obj = null;
    	List<List<String>> list = null;
    	try {
    		startdt = DateUtils.formatDate(startdt, "yyyyMMdd", "yyyy-MM-dd");
    		enddt = DateUtils.formatDate(enddt, "yyyyMMdd", "yyyy-MM-dd");
    		StringBuffer sb = new StringBuffer();
    		sb.append("select companytype,count(distinct company_id) ");
    		sb.append("from ");
    		sb.append("tmp_htable_compy_stat_kylin where ratingdt is not null and companytype is not null and ");
    		sb.append("ratingdt>='"+startdt+"' ");
    		sb.append("and ");
    		sb.append("ratingdt<='"+enddt+"' group by companytype");
    		String result =KylinAPI.query(sb.toString(),0,-1);
    		JSONObject jsonObj = JSON.parseObject(result);
    		obj = jsonObj.get("results");
    		if(obj!=null) {
    			//排序
    			list = (List)obj;
    			Collections.sort(list,new Comparator<List<String>>(){
    				public int compare(List<String> arg0, List<String> arg1) {
    					Double intArg1=Double.valueOf(arg1.get(1));
    					Double intArg0=Double.valueOf(arg0.get(1));
    					return intArg1.compareTo(intArg0);
    				}
    			});
    		}
    	} catch (Exception e) {
    		e.printStackTrace();
    		outData.setCode("1");
    		outData.setMessage("系统报错!");
    		return outData;
    	}*/
    	Map data = new HashMap();
    	data.put("result", returnList);
    	outData.setCode("0");
    	outData.setCount(0);
    	outData.setMessage("返回成功!");
    	outData.setData(data);
    	return outData;
    }
    /***
     * @Title: ratingDownStaList
     * @Description: 主体评级下调统计企业列表
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/ratingDownStaList", method = RequestMethod.POST)
    public BaseOutData ratingDownStaList(@RequestBody RiskInfoSearchCondition condition) {
    	BaseOutData outData = new BaseOutData();
    	List<RiskSearchOut> returnList = null;
    	long numFound = 0L;
    	try {
    		//创建Solr服务对象，通过此对象向solr服务发起请求
    		SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_RISK_METHOD);
    		//创建查询对象
    		SolrQuery query = new SolrQuery();
    		//设置公共查询参数
    		query = riskSearchServices.queryCondition(condition, query);
    		/*****************************设置过滤条件start*****************************************/
    		//过滤注册地址
    		if(StringUtils.isNotEmpty(condition.getOfficeAddr())) {
    			query.addFilterQuery("reg_region:\""+condition.getOfficeAddr()+"\"");
    		}
    		//过滤企业类型
    		if(StringUtils.isNotEmpty(condition.getCompanyType())) {
    			query.addFilterQuery("company_type:\""+condition.getCompanyType()+"\"");
    		}
    		//过滤风险类型
    		query.addFilterQuery("risk_type:\"主体评级下调\"");
    		//过滤风险时间
    		if(StringUtils.isNotEmpty(condition.getDt())) {
    			String queryString = riskSearchServices.getQueryTime2(condition.getDt());
    			query.addFilterQuery("dt:"+queryString);
    		}
    		/*****************************设置过滤条件end*****************************************/
    		//执行查询
    		QueryResponse response = solrServer.query(query);
    		//返回数量
    		numFound = response.getResults().getNumFound();
    		//获取返回数据
    		returnList = riskSearchServices.getResponseDate(response);
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        Map data = new HashMap();
        data.put("result", returnList);
        outData.setCode("0");
        outData.setCount((int)numFound);
        outData.setMessage("返回成功!");
        outData.setData(data);
    	return outData;
    }
    /**
     * @Title: financialRiskSta
     * @Description: 财务风险-非标准审计意见统计-按行业
     * @param inData
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/adviceIndustrySta", method = RequestMethod.POST)
    public BaseOutData adviceIndustrySta(@RequestBody Map<String,String> inData) {
    	BaseOutData outData = new BaseOutData();
    	String startdt = inData.get("startdt");
    	String enddt = inData.get("enddt");
		List returnList = new ArrayList();
		try {
			//创建Solr服务对象，通过此对象向solr服务发起请求
			SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_RISK_METHOD);
			//创建查询对象
			SolrQuery query = new SolrQuery();
			//设置公共查询参数
			query = riskSearchServices.queryCondition(new RiskInfoSearchCondition(), query);
			//过滤风险类型
			query.addFilterQuery("risk_type:\"财务风险\"");
			//是否发债
			query.addFilterQuery("isbond:\"1\"");
			//去掉标准无保留意见
			query.addFilterQuery("-auditadvice:\"标准无保留意见\"");
			//过滤风险时间
			query.addFilterQuery("dt:"+riskSearchServices.getQueryTime(startdt,enddt));
			query.setFacet(true);
			//按行业统计
			query.addFacetField("industry");
			query.setFacetMinCount(1);
			//执行查询
			QueryResponse response = solrServer.query(query);
			FacetField facetField = response.getFacetField("industry");
			if (facetField != null) {
				List<FacetField.Count> counts = facetField.getValues();
				for (FacetField.Count count : counts) {
					Map map = new HashMap();
					map.put("name", count.getName());
					map.put("count", count.getCount());
					returnList.add(map);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
    	/*Object obj = null;
    	List<List<String>> returnList = null;
    	try {
    		startdt = DateUtils.formatDate(startdt, "yyyyMMdd", "yyyy-MM-dd");
    		enddt = DateUtils.formatDate(enddt, "yyyyMMdd", "yyyy-MM-dd");
    		StringBuffer sb = new StringBuffer();
    		sb.append("select industry,count(company_id) from tmp_htable_compy_stat_kylin ");
    		sb.append("where reportyear is not null and industry is not null and ");
    		sb.append("reportyear>='"+startdt+"' ");
    		sb.append("and ");
    		sb.append("reportyear<='"+enddt+"' group by industry");
    		String result =KylinAPI.query(sb.toString(),0,-1);
    		JSONObject jsonObj = JSON.parseObject(result);
    		obj = jsonObj.get("results");
    		if(obj!=null) {
    			returnList = new ArrayList();
    			List<List<String>> list = (List)obj;
    			for(List<String> inList : list) {
    				Collections.replaceAll(inList, inList.get(0), inList.get(0).split("-")[0]);
    				returnList.add(inList);
    			}
    			//排序
    			Collections.sort(returnList,new Comparator<List<String>>(){
    				public int compare(List<String> arg0, List<String> arg1) {
    					Double intArg1=Double.valueOf(arg1.get(1));
    					Double intArg0=Double.valueOf(arg0.get(1));
    					return intArg1.compareTo(intArg0);
    				}
    			});
    		}
    	} catch (Exception e) {
    		e.printStackTrace();
    		outData.setCode("1");
    		outData.setMessage("系统报错!");
    		return outData;
    	}*/
    	Map data = new HashMap();
    	data.put("result", returnList);
    	outData.setCode("0");
    	outData.setCount(0);
    	outData.setMessage("返回成功!");
    	outData.setData(data);
    	return outData;
    }
    /**
     * @Title: financialRiskSta
     * @Description: 财务风险-非标准审计意见统计-按审计意见
     * @param inData
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/auditadviceSta", method = RequestMethod.POST)
    public BaseOutData auditadviceSta(@RequestBody Map<String,String> inData) {
		BaseOutData outData = new BaseOutData();
		String startdt = inData.get("startdt");
		String enddt = inData.get("enddt");
		List returnList = new ArrayList();
		try {
			//创建Solr服务对象，通过此对象向solr服务发起请求
			SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_RISK_METHOD);
			//创建查询对象
			SolrQuery query = new SolrQuery();
			//设置公共查询参数
			query = riskSearchServices.queryCondition(new RiskInfoSearchCondition(), query);
			//过滤风险类型
			query.addFilterQuery("risk_type:\"财务风险\"");
			//是否发债
			query.addFilterQuery("isbond:\"1\"");
			//去掉标准无保留意见
			query.addFilterQuery("-auditadvice:\"标准无保留意见\"");
			//过滤风险时间
			query.addFilterQuery("dt:" + riskSearchServices.getQueryTime(startdt, enddt));
			query.setFacet(true);
			//按审计意见统计
			query.addFacetField("auditadvice");
			query.setFacetMinCount(1);
			//执行查询
			QueryResponse response = solrServer.query(query);
			FacetField facetField = response.getFacetField("auditadvice");
			if (facetField != null) {
				List<FacetField.Count> counts = facetField.getValues();
				for (FacetField.Count count : counts) {
					Map map = new HashMap();
					map.put("name", count.getName());
					map.put("count", count.getCount());
					returnList.add(map);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
    	/*Object obj = null;
    	List<List<String>> returnList = new ArrayList<List<String>>();
    	List<String> list1 = new ArrayList<String>();
    	list1.add("无法(拒绝)表示意见");
    	list1.add("7");
    	List<String> list2 = new ArrayList<String>();
    	list2.add("保留意见");
    	list2.add("11");
    	List<String> list3 = new ArrayList<String>();
    	list3.add("带强调事项段的无保留意见");
    	list3.add("13");
    	returnList.add(list3);
    	returnList.add(list2);
    	returnList.add(list1);
    	try {
    		startdt = DateUtils.formatDate(startdt, "yyyyMMdd", "yyyy-MM-dd");
    		enddt = DateUtils.formatDate(enddt, "yyyyMMdd", "yyyy-MM-dd");
    		StringBuffer sb = new StringBuffer();
    		sb.append("select auditadvice,count(distinct company_id) ");
    		sb.append("from ");
    		sb.append("tmp_htable_compy_stat_kylin where ratingdt is not null and auditadvice is not null and ");
    		sb.append("reportyear>='"+startdt+"' ");
    		sb.append("and ");
    		sb.append("reportyear<='"+enddt+"' group by auditadvice");
    		String result =KylinAPI.query(sb.toString(),0,-1);
    		JSONObject jsonObj = JSON.parseObject(result);
    		obj = jsonObj.get("results");
    		if(obj!=null) {
    			returnList = new ArrayList();
    			List<List<String>> list = (List)obj;
    			for(List<String> inList : list) {
    				if(!"标准无保留意见".equals(inList.get(0))) {
    					returnList.add(inList);
    				}
    			}
    			//排序
    			Collections.sort(returnList,new Comparator<List<String>>(){
    				public int compare(List<String> arg0, List<String> arg1) {
    					Double intArg1=Double.valueOf(arg1.get(1));
    					Double intArg0=Double.valueOf(arg0.get(1));
    					return intArg1.compareTo(intArg0);
    				}
    			});
    		}
    	} catch (Exception e) {
    		e.printStackTrace();
    		outData.setCode("1");
    		outData.setMessage("系统报错!");
    		return outData;
    	}*/
		Map data = new HashMap();
		data.put("result", returnList);
		outData.setCode("0");
		outData.setCount(0);
		outData.setMessage("返回成功!");
		outData.setData(data);
		return outData;
	}
    /**
     * 
     * @Title: financialRiskStaList
     * @Description: 财务风险-非标准审计意见统计企业列表
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/financialRiskStaList", method = RequestMethod.POST)
    public BaseOutData financialRiskStaList(@RequestBody RiskInfoSearchCondition condition) {
    	BaseOutData outData = new BaseOutData();
    	Map returnMap = new HashMap();
    	List returnList = null;
    	long numFound = 0L;
    	try {
    		//创建Solr服务对象，通过此对象向solr服务发起请求
    		SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_RISK_METHOD);
    		//创建查询对象
    		SolrQuery query = new SolrQuery();
    		//设置公共查询参数
    		query = riskSearchServices.queryCondition(condition, query);
    		/*****************************设置过滤条件start*****************************************/
    		//过滤所属行业
    		if(StringUtils.isNotEmpty(condition.getIndustry())) {
    			query.addFilterQuery("industry:\""+condition.getIndustry()+"\"");
    		}
    		//过滤审计意见
    		if(StringUtils.isNotEmpty(condition.getAuditadvice())) {
    			query.addFilterQuery("auditadvice:\""+condition.getAuditadvice()+"\"");
    		}
    		//过滤风险类型
    		query.addFilterQuery("risk_type:\"财务风险\"");
    		//是否发债
    		query.addFilterQuery("isbond:\"1\"");
    		//去掉标准无保留意见
    		query.addFilterQuery("-auditadvice:\"标准无保留意见\"");
    		//过滤风险时间
    		if(StringUtils.isNotEmpty(condition.getDt())) {
    			String queryString = riskSearchServices.getQueryTime2(condition.getDt());
    			query.addFilterQuery("dt:"+queryString);
    		}
    		/*****************************设置过滤条件end*****************************************/
    		//执行查询
    		QueryResponse response = solrServer.query(query);
    		//返回数量
    		numFound = response.getResults().getNumFound();
    		//获取返回数据
    		returnList = riskSearchServices.getFinancialRiskStaList(response);
    		
    		returnMap.put("total", numFound);
    		returnMap.put("list", returnList);
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        Map data = new HashMap();
        data.put("result", returnMap);
        outData.setCode("0");
        outData.setCount((int)numFound);
        outData.setMessage("返回成功!");
        outData.setData(data);
    	return outData;
    }
    /***
     * 
     * @Title: bondDefaultsSta
     * @Description: 债券发行人统计-企业性质列表
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/companyTypeList", method = RequestMethod.GET)
    public BaseOutData getCompanyTypeList() {
    	BaseOutData outData = new BaseOutData();
    	long numFound = 0L;
        Object obj = null;
        try {
        	StringBuffer sb = new StringBuffer();
        	sb.append("select distinct companytype from tmp_htable_bond_stat_kylin ");
        	sb.append("where companytype is not null and ");
        	sb.append("companytype<>'null'");
			String result =KylinAPI.query(sb.toString(),0,-1);
			JSONObject jsonObj = JSON.parseObject(result);
			obj = jsonObj.get("results");
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        Map data = new HashMap();
        data.put("result", obj);
        outData.setCode("0");
        outData.setCount((int)numFound);
        outData.setMessage("返回成功!");
        outData.setData(data);
    	return outData;
    }
    /***
     * 
     * @Title: bondDefaultsSta
     * @Description: 债券发行人统计-CICS一级行业列表
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/cicsIndustryList", method = RequestMethod.GET)
    public BaseOutData getCicsIndustryList() {
    	BaseOutData outData = new BaseOutData();
    	long numFound = 0L;
    	Object obj = null;
    	try {
    		StringBuffer sb = new StringBuffer();
    		sb.append("select distinct industry from tmp_htable_bond_stat_kylin ");
    		sb.append("where industry is not null");
    		String result =KylinAPI.query(sb.toString(),0,-1);
    		JSONObject jsonObj = JSON.parseObject(result);
    		obj = jsonObj.get("results");
    	} catch (Exception e) {
    		e.printStackTrace();
    		outData.setCode("1");
    		outData.setMessage("系统报错!");
    		return outData;
    	}
    	Map data = new HashMap();
    	data.put("result", obj);
    	outData.setCode("0");
    	outData.setCount((int)numFound);
    	outData.setMessage("返回成功!");
    	outData.setData(data);
    	return outData;
    }
    /**
     * 
     * @Title: bondIssuerCurrent
     * @Description: 债券发行人统计-现债券融资额统计
     * @param inData
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/bondIssuerCurrent ", method = RequestMethod.POST)
    public BaseOutData bondIssuerCurrent(@RequestBody BondIssuerConditon inData) {
		BaseOutData outData = new BaseOutData();
    	List<Object> returnList = null;
    	long numFound = 0L;
    	try {
    		//创建Solr服务对象，通过此对象向solr服务发起请求
    		SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_BOND_METHOD);
    		//创建查询对象
    		SolrQuery query = new SolrQuery();
    		//设置公共查询参数
    		BondSearchConditon condition = new BondSearchConditon();
    		query = bondSearchServices.bondIssuerCondition(condition, query);
    		//设置排序
    		query.addSort("sum_issue_vol", SolrQuery.ORDER.desc);
    		/*****************************过滤条件start*****************************************/
    		//企业类型
    		if(StringUtils.isNotEmpty(inData.getCompanyType())) {
    			query.addFilterQuery("company_type:"+inData.getCompanyType());
    		}
    		//企业类型
    		if(StringUtils.isNotEmpty(inData.getIndustry())) {
    			query.addFilterQuery("industry:"+inData.getIndustry());
    		}
    		//是否上市
    		if(StringUtils.isNotEmpty(inData.getIslist())) {
    			query.addFilterQuery("islist:"+inData.getIslist());
    		}
    		/*****************************过滤条件end*****************************************/
    		
    		//执行查询
    		QueryResponse response = solrServer.query(query);
    		//返回数量
    		numFound = response.getResults().getNumFound();
    		//获取返回数据
    		returnList = bondSearchServices.getBondIssuerCurrent(response);
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        Map data = new HashMap();
        data.put("result", returnList);
        outData.setCode("0");
        outData.setCount((int)numFound);
        outData.setMessage("返回成功!");
        outData.setData(data);
    	return outData;
    }
    /**
     * 
     * @Title: bondIssuerWithinYear
     * @Description: 债券发行人统计-年内应归还债券额统计
     * @param inData
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/bondIssuerWithinYear", method = RequestMethod.POST)
    public BaseOutData bondIssuerWithinYear(@RequestBody BondIssuerConditon inData) {
		BaseOutData outData = new BaseOutData();
    	List<Object> returnList = null;
    	long numFound = 0L;
    	try {
    		//创建Solr服务对象，通过此对象向solr服务发起请求
    		SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_BOND_METHOD);
    		//创建查询对象
    		SolrQuery query = new SolrQuery();
    		//设置公共查询参数
    		BondSearchConditon condition = new BondSearchConditon();
    		query = bondSearchServices.bondIssuerCondition(condition, query);
    		//设置排序
    		query.addSort("sum_pay_vol", SolrQuery.ORDER.desc);
    		/*****************************过滤条件start*****************************************/
    		//企业类型
    		if(StringUtils.isNotEmpty(inData.getCompanyType())) {
    			query.addFilterQuery("company_type:"+inData.getCompanyType());
    		}
    		//企业类型
    		if(StringUtils.isNotEmpty(inData.getIndustry())) {
    			query.addFilterQuery("industry:"+inData.getIndustry());
    		}
    		//是否上市
    		if(StringUtils.isNotEmpty(inData.getIslist())) {
    			query.addFilterQuery("islist:"+inData.getIslist());
    		}
    		/*****************************过滤条件end*****************************************/
    		
    		//执行查询
    		QueryResponse response = solrServer.query(query);
    		//返回数量
    		numFound = response.getResults().getNumFound();
    		//获取返回数据
    		returnList = bondSearchServices.getBondIssuerWithinYear(response);
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        Map data = new HashMap();
        data.put("result", returnList);
        outData.setCode("0");
        outData.setCount((int)numFound);
        outData.setMessage("返回成功!");
        outData.setData(data);
    	return outData;
    }
    /**
     * 
     * @Title: bondIssuerDuration
     * @Description: 债券发行人统计-存续期债券数
     * @param inData
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/bondIssuerDuration", method = RequestMethod.POST)
    public BaseOutData bondIssuerDuration(@RequestBody BondIssuerConditon inData) {
		BaseOutData outData = new BaseOutData();
    	List<Object> returnList = null;
    	long numFound = 0L;
    	try {
    		//创建Solr服务对象，通过此对象向solr服务发起请求
    		SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_BOND_METHOD);
    		//创建查询对象
    		SolrQuery query = new SolrQuery();
    		//设置公共查询参数
    		BondSearchConditon condition = new BondSearchConditon();
    		query = bondSearchServices.bondIssuerCondition(condition, query);
    		//设置排序
    		query.addSort("sum_bond_cnt", SolrQuery.ORDER.desc);
    		/*****************************过滤条件start*****************************************/
    		//企业类型
    		if(StringUtils.isNotEmpty(inData.getCompanyType())) {
    			query.addFilterQuery("company_type:"+inData.getCompanyType());
    		}
    		//企业类型
    		if(StringUtils.isNotEmpty(inData.getIndustry())) {
    			query.addFilterQuery("industry:"+inData.getIndustry());
    		}
    		//是否上市
    		if(StringUtils.isNotEmpty(inData.getIslist())) {
    			query.addFilterQuery("islist:"+inData.getIslist());
    		}
    		/*****************************过滤条件end*****************************************/
    		
    		//执行查询
    		QueryResponse response = solrServer.query(query);
    		//返回数量
    		numFound = response.getResults().getNumFound();
    		//获取返回数据
    		returnList = bondSearchServices.getBondIssuerDuration(response);
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        Map data = new HashMap();
        data.put("result", returnList);
        outData.setCode("0");
        outData.setCount((int)numFound);
        outData.setMessage("返回成功!");
        outData.setData(data);
    	return outData;
    }
    /**
     * 
     * @Title: bondMarketPublishSta
     * @Description: 债券市场规模-债券市场上月发行情况
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/bondMarketPublishSta", method = RequestMethod.GET)
    public BaseOutData bondMarketPublishSta() {
    	BaseOutData outData = new BaseOutData();
    	long numFound = 0L;
    	Object obj = null;
    	List<List<String>> list = null;
    	try {
    		StringBuffer sb = new StringBuffer();
    		sb.append("select bondtype,count(1) as 发行数量 ,sum(issue_vol) as 发行额  from ");
    		sb.append("(select distinct bondtype,industry,region,companytype,issue_dt,issue_vol ");
    		sb.append("from tmp_htable_bond_stat_kylin where issue_dt is not null and ");
    		sb.append("issue_dt>='"+DateUtils.getFirstDayLastMonth()+"' and issue_dt<='"+DateUtils.getLastDayLastMonth()+"') ");
    		sb.append("as a group by bondtype ");
    		String result =KylinAPI.query(sb.toString(),0,-1);
    		JSONObject jsonObj = JSON.parseObject(result);
    		obj = jsonObj.get("results");
    		if(obj!=null) {
    			//排序
    			list = (List)obj;
    			Collections.sort(list,new Comparator<List<String>>(){
    	            public int compare(List<String> arg0, List<String> arg1) {
    	            	Double intArg1=Double.valueOf(arg1.get(2));
    	            	Double intArg0=Double.valueOf(arg0.get(2));
    	            	return intArg1.compareTo(intArg0);
    	            }
    	        });
    		}
    	} catch (Exception e) {
    		e.printStackTrace();
    		outData.setCode("1");
    		outData.setMessage("系统报错!");
    		return outData;
    	}
    	Map data = new HashMap();
    	data.put("result", list);
    	outData.setCode("0");
    	outData.setCount(list!=null?list.size():0);
    	outData.setMessage("返回成功!");
    	outData.setData(data);
    	return outData;
    }
    /**
     * 
     * @Title: bondMarketFinancingSta
     * @Description: 债券市场规模-信用债市场净融资情况-按月
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/bondMarketFinancingSta", method = RequestMethod.GET)
    public BaseOutData bondMarketFinancingSta() {
    	BaseOutData outData = new BaseOutData();
    	long numFound = 0L;
    	Object obj = null;
    	List<List<String>> list = null;
    	try {
    		String firstDay = DateUtils.formatDate(DateUtils.getCurrYearFirst(), "yyyy-MM-dd");
    		String lastDay = DateUtils.formatDate(DateUtils.getCurrYearLast(), "yyyy-MM-dd");
    		StringBuffer sb = new StringBuffer();
    		sb.append("select substring(cash_dt,1,7),count(distinct secinner_id) as 还款债数, ");
    		sb.append("sum (pay_vol) as 还款额   from   tmp_htable_bond_stat_kylin where cash_dt is not null ");
    		sb.append(" and cash_dt >= '"+firstDay+"' and cash_dt<='"+lastDay+"' ");
    		sb.append("group by substring(cash_dt,1,7)");
    		String result =KylinAPI.query(sb.toString(),0,-1);
    		JSONObject jsonObj = JSON.parseObject(result);
    		obj = jsonObj.get("results");
    		if(obj!=null) {
    			//排序
    			list = (List)obj;
    			Collections.sort(list,new Comparator<List<String>>(){
    	            public int compare(List<String> arg0, List<String> arg1) {
    	            	return arg1.get(0).compareTo(arg0.get(0));
    	            }
    	        });
    		}
    	} catch (Exception e) {
    		e.printStackTrace();
    		outData.setCode("1");
    		outData.setMessage("系统报错!");
    		return outData;
    	}
    	Map data = new HashMap();
    	data.put("result", list);
    	outData.setCode("0");
    	outData.setCount(list!=null?list.size():0);
    	outData.setMessage("返回成功!");
    	outData.setData(data);
    	return outData;
    }
    /**
     * 
     * @Title: countrySta
     * @Description: 债券区域发行分布-全国省份统计
     * @param type
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/countrySta/{type}", method = RequestMethod.GET)
    public BaseOutData countrySta(@PathVariable String type) {
    	BaseOutData outData = new BaseOutData();
    	long numFound = 0L;
    	Object obj = null;
    	try {
    		StringBuffer sb = new StringBuffer();
    		sb.append("select region ,cnt,summary  from (select region,count(1) as cnt ,sum(issue_vol) as summary ");
    		sb.append("from (select distinct bondtype,city,industry,region,companytype,issue_dt,issue_vol from tmp_htable_bond_stat_kylin ");
    		sb.append("where issue_dt is not null and city is not null ) as a ");
    		sb.append("where bondtype='"+type+"' group by bondtype,region)  ");
    		String result =KylinAPI.query(sb.toString(),0,-1);
    		JSONObject jsonObj = JSON.parseObject(result);
    		obj = jsonObj.get("results");
    	} catch (Exception e) {
    		e.printStackTrace();
    		outData.setCode("1");
    		outData.setMessage("系统报错!");
    		return outData;
    	}
    	Map data = new HashMap();
    	data.put("result", obj);
    	outData.setCode("0");
    	outData.setCount((int)numFound);
    	outData.setMessage("返回成功!");
    	outData.setData(data);
    	return outData;
    }
	/**
	 * 
	 * @Title: provinceTop10
	 * @Description: 债券区域发行分布-省top10
	 * @param type
	 * @return
	 * @return: BaseOutData
	 */
	@RequestMapping(value = "/provinceTop10/{type}", method = RequestMethod.GET)
	public BaseOutData provinceTop10(@PathVariable String type) {
		BaseOutData outData = new BaseOutData();
		long numFound = 0L;
		Object obj = null;
		try {
			StringBuffer sb = new StringBuffer();
			sb.append("select region ,cnt,summary  from (select region,count(1) as cnt ,sum(issue_vol) as summary ");
			sb.append("from (select distinct bondtype,city,industry,region,companytype,issue_dt,issue_vol from tmp_htable_bond_stat_kylin ");
			sb.append("where issue_dt is not null and city is not null ) as a ");
			sb.append("where bondtype='"+type+"' group by bondtype,region) order by cnt desc,summary desc limit 10 ");
			String result =KylinAPI.query(sb.toString(),0,-1);
			JSONObject jsonObj = JSON.parseObject(result);
			obj = jsonObj.get("results");
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
		Map data = new HashMap();
		data.put("result", obj);
		outData.setCode("0");
		outData.setCount((int)numFound);
		outData.setMessage("返回成功!");
		outData.setData(data);
		return outData;
	}
	/**
	 * 
	 * @Title: bondAreaPublishTop10
	 * @Description: 债券区域发行分布-城市top10
	 * @param type
	 * @return
	 * @return: BaseOutData
	 */
	@RequestMapping(value = "/cityTop10/{type}", method = RequestMethod.GET)
	public BaseOutData cityTop10(@PathVariable String type) {
		BaseOutData outData = new BaseOutData();
		long numFound = 0L;
		Object obj = null;
		try {
			StringBuffer sb = new StringBuffer();
			sb.append("select city,val ");
			sb.append("from ");
			sb.append("(select bondtype,city,val,row_number()over(partition by bondtype order by val desc) as rnk ");
			sb.append("from(select bondtype,city,count(distinct secinner_id) as val ");
			sb.append("from tmp_htable_bond_stat_kylin where city is not null group by bondtype,city) ");
			sb.append("where bondtype='"+type+"' )  ");
			sb.append("where rnk<=10 ");
			String result =KylinAPI.query(sb.toString(),0,-1);
			JSONObject jsonObj = JSON.parseObject(result);
			obj = jsonObj.get("results");
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
		Map data = new HashMap();
		data.put("result", obj);
		outData.setCode("0");
		outData.setCount((int)numFound);
		outData.setMessage("返回成功!");
		outData.setData(data);
		return outData;
	}
    /***
     * 
     * @Title: bondAreaPublishMaxProvince
     * @Description: 债券区域发行分布-区域分布-某个省份全部城市的数据
     * @param type
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/provinceSta/{type}/{province}", method = RequestMethod.GET)
    public BaseOutData regionSta(@PathVariable String type,@PathVariable String province) {
    	BaseOutData outData = new BaseOutData();
    	long numFound = 0L;
    	Object obj = null;
    	try {
    		StringBuffer sb = new StringBuffer();
    		sb.append("select city,count(1) as cnt ,sum(issue_vol) as summary from ");
    		sb.append("(select distinct bondtype,city,industry,region,companytype,issue_dt,issue_vol from ");
    		sb.append("tmp_htable_bond_stat_kylin where issue_dt is not null and city is not null ) as a ");
    		sb.append("where bondtype='"+type+"'  ");
    		sb.append("and region like '%"+province+"%' group by bondtype,region,city ");
    		String result =KylinAPI.query(sb.toString(),0,-1);
    		JSONObject jsonObj = JSON.parseObject(result);
    		obj = jsonObj.get("results");
    	} catch (Exception e) {
    		e.printStackTrace();
    		outData.setCode("1");
    		outData.setMessage("系统报错!");
    		return outData;
    	}
    	Map data = new HashMap();
    	data.put("result", obj);
    	outData.setCode("0");
    	outData.setCount((int)numFound);
    	outData.setMessage("返回成功!");
    	outData.setData(data);
    	return outData;
    }
	
	/***
	 * 
	 * @Title: bondAreaPublishMaxProvince
	 * @Description: 债券区域发行分布-区域分布-某个省份的总量
	 * @param type
	 * @return
	 * @return: BaseOutData
	 */
	@RequestMapping(value = "/provinceTotalSta/{type}/{province}", method = RequestMethod.GET)
	public BaseOutData regionTotalSta(@PathVariable String type,@PathVariable String province) {
		BaseOutData outData = new BaseOutData();
		long numFound = 0L;
		Object obj = null;
		try {
			StringBuffer sb = new StringBuffer();
			sb.append("select region ,cnt,summary ");
			sb.append("from ");
			sb.append("(select region,count(1) as cnt ,sum(issue_vol) as summary ");
			sb.append("from (select distinct bondtype,city,industry,region,companytype,issue_dt,issue_vol from tmp_htable_bond_stat_kylin ");
			sb.append("where issue_dt is not null and city is not null ) as a ");
			sb.append("where bondtype='"+type+"' group by bondtype,region) ");
			sb.append("where region='"+province+"'");
			String result =KylinAPI.query(sb.toString(),0,-1);
			JSONObject jsonObj = JSON.parseObject(result);
			obj = jsonObj.get("results");
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
		Map data = new HashMap();
		data.put("result", obj);
		outData.setCode("0");
		outData.setCount((int)numFound);
		outData.setMessage("返回成功!");
		outData.setData(data);
		return outData;
	}
    
    /***
     * 
     * @Title: bondAreaPublishMaxProvince
     * @Description: 债券区域发行分布-数量最多的省份
     * @param type
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/maxProvince/{type}", method = RequestMethod.GET)
    public BaseOutData maxProvince(@PathVariable String type) {
		BaseOutData outData = new BaseOutData();
		long numFound = 0L;
		Object obj = null;
		try {
			StringBuffer sb = new StringBuffer();
			sb.append("select region ,cnt,summary  from (select region,count(1) as cnt ,sum(issue_vol) as summary ");
			sb.append("from (select distinct bondtype,city,industry,region,companytype,issue_dt,issue_vol from tmp_htable_bond_stat_kylin ");
			sb.append("where issue_dt is not null and city is not null ) as a ");
			sb.append("where bondtype='"+type+"'  group by bondtype,region) order by cnt desc,summary desc limit 1 ");
			String result =KylinAPI.query(sb.toString(),0,-1);
			JSONObject jsonObj = JSON.parseObject(result);
			obj = jsonObj.get("results");
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
		Map data = new HashMap();
		data.put("result", obj);
		outData.setCode("0");
		outData.setCount((int)numFound);
		outData.setMessage("返回成功!");
		outData.setData(data);
		return outData;
    }
    /***
     * 
     * @Title: bondAreaPublishProvince
     * @Description: 债券区域发行分布-按照城市查询
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/citySta/{type}/{city}", method = RequestMethod.GET)
    public BaseOutData citySta(@PathVariable String type,@PathVariable String city) {
		BaseOutData outData = new BaseOutData();
		long numFound = 0L;
		Object obj = null;
		try {
			StringBuffer sb = new StringBuffer();
			sb.append("select city,count(1) as cnt ,sum(issue_vol) as summary from ");
			sb.append("(select distinct bondtype,city,industry,region,companytype,issue_dt,issue_vol ");
			sb.append("from tmp_htable_bond_stat_kylin where issue_dt is not null and city is not null ) as a ");
			sb.append("where bondtype='"+type+"' and city ='"+city+"' group by bondtype,region,city ");
			String result =KylinAPI.query(sb.toString(),0,-1);
			JSONObject jsonObj = JSON.parseObject(result);
			obj = jsonObj.get("results");
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
		Map data = new HashMap();
		data.put("result", obj);
		outData.setCode("0");
		outData.setCount((int)numFound);
		outData.setMessage("返回成功!");
		outData.setData(data);
		return outData;
    }
    /**
     * 
     * @Title: getInvestGrade
     * @Description: 最新投资等级列表-发债企业高级搜索
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/investGrade", method = RequestMethod.GET)
    public BaseOutData getInvestGrade() {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	try {
    		out = rt.opsForValue().get(INVEST_GRADE);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(Contants.HBASE_BOND_COMPANY_SEARCH_INVESTGRADE_URL);
    			if(null!=out) {
    				rt.opsForValue().set(INVEST_GRADE,out.toString());
    				rt.expire(INVEST_GRADE, Contants.REDIS_TIMEOUT, TimeUnit.HOURS);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
        Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }
    /***
     * 
     * @Title: getLastRating
     * @Description: 最新主体评级列表-发债企业高级搜索
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/lastRating", method = RequestMethod.GET)
    public BaseOutData getLastRating() {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	try {
    		out = rt.opsForValue().get(LAST_RATING);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(Contants.HBASE_BOND_COMPANY_SEARCH_LASTRATING_URL);
    			if(null!=out) {
    				rt.opsForValue().set(LAST_RATING,out.toString());
    				rt.expire(LAST_RATING, Contants.REDIS_TIMEOUT, TimeUnit.HOURS);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
        Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }
    /**
     * 
     * @Title: getRatingOutlook
     * @Description: 最新评级展望列表-发债企业高级搜索
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/ratingOutlook", method = RequestMethod.GET)
    public BaseOutData getRatingOutlook() {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	try {
    		out = rt.opsForValue().get(RATING_OUTLOOK);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(Contants.HBASE_BOND_COMPANY_SEARCH_RATINGOUTLOOK_URL);
    			if(null!=out) {
    				rt.opsForValue().set(RATING_OUTLOOK,out.toString());
    				rt.expire(RATING_OUTLOOK, Contants.REDIS_TIMEOUT, TimeUnit.HOURS);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
        Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }
    /***
     * 
     * @Title: getBondType
     * @Description: 发债类型列表-发债企业高级搜索
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/bondType", method = RequestMethod.GET)
    public BaseOutData getBondType() {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
		List<Map<String,String>> returnList = null;
		try {
    		out = rt.opsForValue().get(BOND_TYPE);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(Contants.HBASE_BOND_COMPANY_SEARCH_BONDTYPE_URL);
    			if(null!=out) {
    				rt.opsForValue().set(BOND_TYPE,out.toString());
    				rt.expire(BOND_TYPE, Contants.REDIS_TIMEOUT, TimeUnit.HOURS);
    			}
    		}
			if (out != null) {
				returnList = (List) JSON.parse(String.valueOf(out));
				for (int i=0;i<returnList.size();i++) {
					Map<String, String> map = returnList.get(i);
					if (map.get("name").equals("中小企业集合债券") || map.get("name").equals("中小企业集合票据")) {
						returnList.remove(i);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
        Map data = new HashMap();
    	data.put("result", returnList);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }
    /***
     * 
     * @Title: getAuditOpinion
     * @Description: 审计意见列表-发债企业高级搜索
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/auditOpinion", method = RequestMethod.GET)
    public BaseOutData getAuditOpinion() {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	try {
    		out = rt.opsForValue().get(AUDIT_OPINION);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(Contants.HBASE_BOND_COMPANY_SEARCH_AUDITOPINION_URL);
    			if(null!=out) {
    				rt.opsForValue().set(AUDIT_OPINION,out.toString());
    				rt.expire(AUDIT_OPINION, Contants.REDIS_TIMEOUT, TimeUnit.HOURS);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
        Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }
    /***
     * 
     * @Title: getRegAddr
     * @Description: 注册地-发债企业高级搜索(没有)
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/regAddr", method = RequestMethod.GET)
    public BaseOutData getRegAddr() {
		BaseOutData outData = new BaseOutData();
    	Object out = null;
    	try {
    		out = rt.opsForValue().get(OFFICE_ADDR);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(Contants.HBASE_COMPANY_SEARCH_REGREGION_URL);
    			if(null!=out) {
    				rt.opsForValue().set(OFFICE_ADDR,  out.toString());
    				rt.expire(OFFICE_ADDR, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }
    /**
     * 
     * @Title: getIndustryList
     * @Description: 行业列表-发债企业高级搜索
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/industryList", method = RequestMethod.GET)
    public BaseOutData getIndustryList() {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	try {
    		out = rt.opsForValue().get(INDUSTRY_LIST);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(Contants.HBASE_BOND_COMPANY_SEARCH_INDUSTRYLIST_URL);
    			if(null!=out) {
    				rt.opsForValue().set(INDUSTRY_LIST,out.toString());
    				rt.expire(INDUSTRY_LIST, Contants.REDIS_TIMEOUT, TimeUnit.HOURS);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
        Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }
    /***
     * 
     * @Title: getFinancialIndexChange
     * @Description: 重要财务指标不利变化列表-发债企业高级搜索
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/financialIndexChange", method = RequestMethod.GET)
    public BaseOutData getFinancialIndexChange() {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	try {
    		out = rt.opsForValue().get(FINANCIAL_INDEX_CHANGE);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(Contants.HBASE_BOND_COMPANY_SEARCH_FINANCIALCHANGE_URL);
    			if(null!=out) {
    				rt.opsForValue().set(FINANCIAL_INDEX_CHANGE,out.toString());
    				rt.expire(FINANCIAL_INDEX_CHANGE, Contants.REDIS_TIMEOUT, TimeUnit.HOURS);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
        Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }
    
}
