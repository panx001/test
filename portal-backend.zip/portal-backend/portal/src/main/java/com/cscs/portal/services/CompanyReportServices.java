package com.cscs.portal.services;

import java.util.List;

/**
 * Created by wang on 2016/8/24.
 */
public interface CompanyReportServices {
    List<Object> findColumnEnm(Long companyId, int subjectType, String tableName);

    List<Object> findCompyReport(Long companyId, String rptDt, String isPublicRpt, String rptTimetypeCd, String combineTypeCd, String tableName, String strColumnEnm1);

    //审计意见取得
    List<Object> findCompyFinanaudit(Long companyId, String rptDt);
}
