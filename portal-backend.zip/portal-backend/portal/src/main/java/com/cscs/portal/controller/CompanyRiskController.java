package com.cscs.portal.controller;

import com.alibaba.fastjson.JSON;
import com.cscs.portal.dto.CommonComparator;
import com.cscs.portal.dto.LikeRiskCompany;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.util.Contants;
import com.cscs.util.HttpUtil;
import com.cscs.util.SolrUtil;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.params.GroupParams;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.text.Collator;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 企业风险
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/company/risk")
public class CompanyRiskController {

    //债券违约
    public static String COMPANY_RISK_BONDVIOLATION = "c_r_bondviolation";
    //主体评级下调
    public static String COMPANY_RISK_CREDITCHANGE = "c_r_creditchange";
    //债券评级下调
    public static String COMPANY_RISK_BOND_CREDITCHANGE = "c_r_bond_creditchange";
    //财务风险
    public static String COMPANY_RISK_FINANCEALARM = "c_r_financealarm";
    //股权冻结
    public static String COMPANY_RISK_FROZENSHARE = "c_r_frozenshare";
    //裁判文书
    public static String COMPANY_RISK_DOCUMENT = "c_r_document";
    //法院公告
    public static String COMPANY_RISK_ANNOUNCEMENT = "c_r_announcement";
    //被执行人
    public static String COMPANY_RISK_LITIGANT = "c_r_litigant";
    //失信人
    public static String COMPANY_RISK_ISHONEST = "c_r_ishonest";
    //经营异常
    public static String COMPANY_RISK_OPEREXCEPT = "c_r_operexcept";
    //行政处罚
    public static String COMPANY_RISK_ADMINPENALTY = "c_r_adminpenalty";
    //严重违法
    public static String COMPANY_RISK_SERIVIOLAT = "c_r_seriviolat";
    //股权出质
    public static String COMPANY_RISK_EQUITYPLEDGE = "c_r_equitypledge";
    //动产抵押
    public static String COMPANY_RISK_CHATTELREG = "c_r_chattelreg";
    //风险影响企业
    public static String COMPANY_RISK_RISKRELA = "c_r_riskrela";
    //企业存在类似风险
    public static String COMPANY_RISK_RISKANALO = "c_r_riskanalo";

    @Autowired
    private StringRedisTemplate rt;

    /**
     * 债券违约
     *
     * @param companyId
     * @return
     */
    @SuppressWarnings("unchecked")

    @RequestMapping(value = "/bondViolation/{companyId}", method = RequestMethod.GET)
    public BaseOutData getBondViolation(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	List<Map> mapList = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_RISK_BONDVIOLATION + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_BONDVIOLATION_URL, companyId));
    			
    			if(null!=out) {
    				mapList = (List<Map>) JSON.parseArray(String.valueOf(out), Map.class);
        			Collections.sort(mapList, new CommonComparator("occurDt"));
        			out = JSON.toJSONString(mapList);
    				rt.opsForValue().set(COMPANY_RISK_BONDVIOLATION + companyId, out.toString());
    				rt.expire(COMPANY_RISK_BONDVIOLATION + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 主体评级下调
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/creditChange/{companyId}", method = RequestMethod.GET)
    public BaseOutData getCreditchange(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	List<Map> mapList = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_RISK_CREDITCHANGE + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_CREDITCHANGE_URL, companyId));
    			if(null!=out) {
    				mapList = (List<Map>) JSON.parseArray(String.valueOf(out), Map.class);
        			Collections.sort(mapList, new CommonComparator("ratingDtCurrent"));
        			out = JSON.toJSONString(mapList);
    				rt.opsForValue().set(COMPANY_RISK_CREDITCHANGE + companyId,out.toString());
    				rt.expire(COMPANY_RISK_CREDITCHANGE + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 债券评级下调
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/bondCreditChange/{companyId}", method = RequestMethod.GET)
    public BaseOutData getBondCreditchange(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	List<Map> mapList = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_RISK_BOND_CREDITCHANGE + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_BOND_CREDITCHANGE_URL, companyId));
    			if(null!=out) {
    				mapList = (List<Map>) JSON.parseArray(String.valueOf(out), Map.class);
        			Collections.sort(mapList, new CommonComparator("ratingDtCurrent"));
        			out = JSON.toJSONString(mapList);
    				rt.opsForValue().set(COMPANY_RISK_BOND_CREDITCHANGE + companyId,out.toString());
    				rt.expire(COMPANY_RISK_BOND_CREDITCHANGE + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 股权冻结
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/frozen/{companyId}", method = RequestMethod.GET)
    public BaseOutData getFrozen(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	List<Map> mapList = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_RISK_FROZENSHARE + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_FROZENSHARE_URL, companyId));
    			if(null!=out) {
    				mapList = (List<Map>) JSON.parseArray(String.valueOf(out), Map.class);
        			Collections.sort(mapList, new CommonComparator("noticeDt"));
        			out = JSON.toJSONString(mapList);
    				rt.opsForValue().set(COMPANY_RISK_FROZENSHARE + companyId,out.toString());
    				rt.expire(COMPANY_RISK_FROZENSHARE + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 监管处罚-违规处理
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/punish/{companyId}", method = RequestMethod.GET)
    public BaseOutData getPunish(@PathVariable String companyId) {
        BaseOutData out = new BaseOutData();
//        Map<String, Object> re = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_BOND_CREDITCHANGE_URL, companyId));
//        out.setData(re);
        out.setCode("0");
        return out;
    }

    /**
     * 监管处罚-诉讼仲裁
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/litigation/{companyId}", method = RequestMethod.GET)
    public BaseOutData getLitigation(@PathVariable String companyId) {
        BaseOutData out = new BaseOutData();
//        Map<String, Object> re = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_BOND_CREDITCHANGE_URL, companyId));
//        out.setData(re);
        out.setCode("0");
        return out;
    }

    /**
     * 财务风险
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/finance/{companyId}", method = RequestMethod.GET)
    public BaseOutData getFinanceRisk(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	List<Map> mapList = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_RISK_FINANCEALARM + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_FINANCEALARM_URL, companyId));
    			if(null!=out) {
    				mapList = (List<Map>) JSON.parseArray(String.valueOf(out), Map.class);
        			for (Map map : mapList) {
						Collections.sort((List<Map>) map.get("riskList"), new Comparator<Map>() {
							@Override
							public int compare(Map o1, Map o2) {
								Comparator<Object> com = Collator.getInstance(java.util.Locale.CHINA);
						        return com.compare(o1.get("financeName"), o2.get("financeName"));
							}
						});
					}
    				
        			out = JSON.toJSONString(mapList);
    				rt.opsForValue().set(COMPANY_RISK_FINANCEALARM + companyId,out.toString());
    				rt.expire(COMPANY_RISK_FINANCEALARM + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 裁判文书
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/document/{companyId}", method = RequestMethod.GET)
    public BaseOutData getDocument(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	List<Map> mapList = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_RISK_DOCUMENT + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_DOCUMENT_URL, companyId));
    			if(null!=out) {
    				mapList = (List<Map>) JSON.parseArray(String.valueOf(out), Map.class);
    				for (Map map : mapList) {
    					Collections.sort((List)map.get((String)map.get("case_type")), new CommonComparator("judgeDate"));
					}
    				
        			out = JSON.toJSONString(mapList);
    				rt.opsForValue().set(COMPANY_RISK_DOCUMENT + companyId,out.toString());
    				rt.expire(COMPANY_RISK_DOCUMENT + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 法院公告
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/announcement/{companyId}", method = RequestMethod.GET)
    public BaseOutData getAnnouncement(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	List<Map> mapList = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_RISK_ANNOUNCEMENT + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_ANNOUNCEMENT_URL, companyId));
    			if(null!=out) {
    				mapList = (List<Map>) JSON.parseArray(String.valueOf(out), Map.class);
        			Collections.sort(mapList, new CommonComparator("announceDt"));
        			out = JSON.toJSONString(mapList);
    				rt.opsForValue().set(COMPANY_RISK_ANNOUNCEMENT + companyId,out.toString());
    				rt.expire(COMPANY_RISK_ANNOUNCEMENT + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 被执行人
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/litigant/{companyId}", method = RequestMethod.GET)
    public BaseOutData getLitigant(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	List<Map> mapList = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_RISK_LITIGANT + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_LITIGANT_URL, companyId));
    			if(null!=out) {
    				mapList = (List<Map>) JSON.parseArray(String.valueOf(out), Map.class);
        			Collections.sort(mapList, new CommonComparator("regDt"));
        			out = JSON.toJSONString(mapList);
    				rt.opsForValue().set(COMPANY_RISK_LITIGANT + companyId, out.toString());
    				rt.expire(COMPANY_RISK_LITIGANT + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 失信人
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/ishonest/{companyId}", method = RequestMethod.GET)
    public BaseOutData getIshonest(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	List<Map> mapList = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_RISK_ISHONEST + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_ISHONEST_URL, companyId));
    			if(null!=out) {
    				mapList = (List<Map>) JSON.parseArray(String.valueOf(out), Map.class);
        			Collections.sort(mapList, new CommonComparator("regDt"));
        			out = JSON.toJSONString(mapList);
    				rt.opsForValue().set(COMPANY_RISK_ISHONEST + companyId,out.toString());
    				rt.expire(COMPANY_RISK_ISHONEST + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 经营异常
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/operexcept/{companyId}", method = RequestMethod.GET)
    public BaseOutData getOperexcept(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	List<Map> mapList = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_RISK_OPEREXCEPT + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_OPEREXCEPT_URL, companyId));
    			if(null!=out) {
    				mapList = (List<Map>) JSON.parseArray(String.valueOf(out), Map.class);
        			Collections.sort(mapList, new CommonComparator("listonDt"));
        			out = JSON.toJSONString(mapList);
    				rt.opsForValue().set(COMPANY_RISK_OPEREXCEPT + companyId,out.toString());
    				rt.expire(COMPANY_RISK_OPEREXCEPT + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 行政处罚
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/adminpenalty/{companyId}", method = RequestMethod.GET)
    public BaseOutData getAdminpenalty(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	List<Map> mapList = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_RISK_ADMINPENALTY + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_ADMINPENALTY_URL, companyId));
    			if(null!=out) {
    				mapList = (List<Map>) JSON.parseArray(String.valueOf(out), Map.class);
        			Collections.sort(mapList, new CommonComparator("decisionDt"));
        			out = JSON.toJSONString(mapList);
    				rt.opsForValue().set(COMPANY_RISK_ADMINPENALTY + companyId, out.toString());
    				rt.expire(COMPANY_RISK_ADMINPENALTY + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 严重违法
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/seriviolat/{companyId}", method = RequestMethod.GET)
    public BaseOutData getSeriviolat(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	List<Map> mapList = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_RISK_SERIVIOLAT + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_SERIVIOLAT_URL, companyId));
    			if(null!=out) {
    				mapList = (List<Map>) JSON.parseArray(String.valueOf(out), Map.class);
        			Collections.sort(mapList, new CommonComparator("listonDt"));
        			out = JSON.toJSONString(mapList);
    				rt.opsForValue().set(COMPANY_RISK_SERIVIOLAT + companyId, out.toString());
    				rt.expire(COMPANY_RISK_SERIVIOLAT + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 股权出质
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/pledge/{companyId}", method = RequestMethod.GET)
    public BaseOutData getPledgeRisk(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	List<Map> mapList = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_RISK_EQUITYPLEDGE + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_EQUITYPLEDGE_URL, companyId));
    			if(null!=out) {
    				mapList = (List<Map>) JSON.parseArray(String.valueOf(out), Map.class);
        			Collections.sort(mapList, new CommonComparator("regDt"));
        			out = JSON.toJSONString(mapList);
    				rt.opsForValue().set(COMPANY_RISK_EQUITYPLEDGE + companyId,out.toString());
    				rt.expire(COMPANY_RISK_EQUITYPLEDGE + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 动产抵押
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/mortgage/{companyId}", method = RequestMethod.GET)
    public BaseOutData getMortgage(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	List<Map> mapList = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_RISK_CHATTELREG + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_CHATTELREG_URL, companyId));
    			if(null!=out) {
    				mapList = (List<Map>) JSON.parseArray(String.valueOf(out), Map.class);
        			Collections.sort(mapList, new CommonComparator("regDate"));
        			out = JSON.toJSONString(mapList);
    				rt.opsForValue().set(COMPANY_RISK_CHATTELREG + companyId,out.toString());
    				rt.expire(COMPANY_RISK_CHATTELREG + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 风险影响企业
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/influenceCompy/{companyId}", method = RequestMethod.GET)
    public BaseOutData getInfluenceCompy(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_RISK_RISKRELA + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_RISKRELA_URL, companyId));
    			if(null!=out) {
    				rt.opsForValue().set(COMPANY_RISK_RISKRELA + companyId, out.toString());
    				rt.expire(COMPANY_RISK_RISKRELA + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 企业存在类似风险
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/existCompy/{companyId}", method = RequestMethod.GET)
    public BaseOutData getExistCompy(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	
    	//行业类型
    	String industry = "房地产";
    	QueryResponse response = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_RISK_RISKANALO + companyId);
    		if (out == null) {
    			
    			SolrServer solrServerForIndustry = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_COMPANY_METHOD);
        		//创建查询对象
        		SolrQuery queryIndustry = new SolrQuery();
        		queryIndustry.set("q", "id:\""+companyId+"\"");
        		queryIndustry.set("wt", "json");
        		queryIndustry.set("shards.tolerant", "true");
        		QueryResponse responseForIndustry = solrServerForIndustry.query(queryIndustry);
    			for (SolrDocument solrDocument: responseForIndustry.getResults()) {
    				industry = (String) solrDocument.get("industry");
				}
        		if(industry==null) {
    				return outData;
    			};
    			//industry = (String) ((Map)companyBasicInfoController.getBasicInfo(companyId).getData().get("result")).get("industry");
    			//out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_RISKANALO_URL, companyId));
    			List<String> hitRiskTypeList = new ArrayList<>();
    			if(this.getBondViolation(companyId).getData().get("result")!=null) {
    				//债券违约
    				hitRiskTypeList.add("债券违约");
    			}
    			if(this.getCreditchange(companyId).getData().get("result")!=null||this.getBondCreditchange(companyId).getData().get("result")!=null) {
    				//评级下调
    				hitRiskTypeList.add("评级下调");
    			}
    			
    			if(this.getFrozen(companyId).getData().get("result")!=null) {
    				//股权冻结
    				hitRiskTypeList.add("股权冻结");
    			}

    			//监管处罚
    			
//    			if(this.getFinanceRisk(companyId).getData().get("result")!=null) {
//    				//财务风险
//    				hitRiskTypeList.add("财务风险");
//    			}
    			if(this.getDocument(companyId).getData().get("result")!=null) {
    				//裁判文书
    				hitRiskTypeList.add("裁判文书");
    			}
    			if(this.getAnnouncement(companyId).getData().get("result")!=null) {
    				//法院公告
    				hitRiskTypeList.add("法院公告");
    			}
    			if(this.getLitigant(companyId).getData().get("result")!=null) {
    				//被执行人
    				hitRiskTypeList.add("被执行人");
    			}
    			if(this.getIshonest(companyId).getData().get("result")!=null) {
    				//失信人
    				hitRiskTypeList.add("失信人");
    			}
    			if(this.getOperexcept(companyId).getData().get("result")!=null) {
    				//经营异常
    				hitRiskTypeList.add("经营异常");
    			}
    			if(this.getAdminpenalty(companyId).getData().get("result")!=null) {
    				//行政处罚
    				hitRiskTypeList.add("行政处罚");
    			}
    			if(this.getSeriviolat(companyId).getData().get("result")!=null) {
    				//严重违法
    				hitRiskTypeList.add("严重违法");
    			}
    			if(this.getPledgeRisk(companyId).getData().get("result")!=null) {
    				//股权出质
    				hitRiskTypeList.add("股权出质");
    			}
    			if(this.getMortgage(companyId).getData().get("result")!=null) {
    				//动产抵押
    				hitRiskTypeList.add("动产抵押");
    			}
    			
    			if(hitRiskTypeList.size()==0) {
    				return outData;
    			}
    			
    			SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_RISK_METHOD);
		        //创建一个SolrQuery对象
		        SolrQuery query = new SolrQuery();
		        query.set("q","industry:" + industry);
		        StringBuffer sb = new StringBuffer();
		        for (String riskType : hitRiskTypeList) {
					sb.append(" risk_type:").append(riskType);
				}
		        query.set("fq",sb.toString());
		       // query.set("fq","risk_type:" +"裁判文书"+ "   risk_type:"+"法院公告");
		        query.setSort("regcapital", SolrQuery.ORDER.desc);
		        query.set("fl", "company_id,company_nm,risk_type,industry");
		        query.set("wt", "json");
		        query.set("shards.tolerant", "true");
		        query.setParam(GroupParams.GROUP,true);
		        query.setParam(GroupParams.GROUP_MAIN,true);
		        query.setParam(GroupParams.GROUP_FIELD,"company_id");
		        query.setParam(GroupParams.GROUP_LIMIT,"1");
		        query.setStart(0);
		        query.setRows(8);
		        response = solrServer.query(query);
		        //GroupResponse groupResponse =  response.getGroupResponse();
		        SolrDocumentList groupResponse =  response.getResults();
		        List<LikeRiskCompany> likeRiskCompanyList = new ArrayList<>();
		        LikeRiskCompany likeRiskCompany = null;
		       /* if(groupResponse != null) {  
				     List<GroupCommand> groupList = groupResponse.getValues();  
				     for(GroupCommand groupCommand : groupList) {  
				         List<Group> groups = groupCommand.getValues();  
				         for(Group group : groups) {  
				            
				             for (SolrDocument solrDocument :  group.getResult()) {
				            	 likeRiskCompany = new LikeRiskCompany();
				            	 likeRiskCompany.setIndustry((String) solrDocument.get("industry"));
				            	 likeRiskCompany.setWarningType((String) solrDocument.get("risk_type"));
				            	 likeRiskCompany.setCompyId((String) solrDocument.get("company_id"));
				            	 likeRiskCompany.setCompyName((String) solrDocument.get("company_nm"));
				            	 likeRiskCompanyList.add(likeRiskCompany);
			    		        }
				         }  
				     }  
				 } */
		        for (SolrDocument solrDocument :  groupResponse) {
	            	 likeRiskCompany = new LikeRiskCompany();
	            	 likeRiskCompany.setIndustry((String) solrDocument.get("industry"));
	            	 likeRiskCompany.setWarningType((String) solrDocument.get("risk_type"));
	            	 likeRiskCompany.setCompyId((String) solrDocument.get("company_id"));
	            	 likeRiskCompany.setCompyName((String) solrDocument.get("company_nm"));
	            	 likeRiskCompanyList.add(likeRiskCompany);
   		        }
		        if(likeRiskCompanyList.size()>0) {
		        	out = JSON.toJSONString(likeRiskCompanyList);
		        }
    			if(null!=out) {
    				rt.opsForValue().set(COMPANY_RISK_RISKANALO + companyId,out.toString());
    				rt.expire(COMPANY_RISK_RISKANALO + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }
}
