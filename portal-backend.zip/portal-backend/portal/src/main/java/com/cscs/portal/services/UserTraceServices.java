package com.cscs.portal.services;

import com.cscs.portal.dto.UserTraceInfoData;
import com.cscs.portal.dto.UserTraceOutData;
import com.cscs.portal.entity.UserTrace;

import java.util.List;

/**
 * Created by dch on 2016/11/14.
 * 用户跟踪接口
 */
public interface UserTraceServices {
    /**
     * 查询用户跟踪信息数量
     */
    int findUserTraceCount(String accountNm, String startDtString, String endDtString);

    /**
     * 查询用户跟踪信息
     */
    List<Object> findUserTrace(String accountNm, String startDtString, String endDtString, int page, int pageSize);

    /**
     * 新增用户跟踪信息
     */
    void addUserTrace(Long userId, String path, String ip);

    boolean tracePath(String path);
    
    public List<Object> visitRecord(UserTraceInfoData userTraceInfoData);
}
