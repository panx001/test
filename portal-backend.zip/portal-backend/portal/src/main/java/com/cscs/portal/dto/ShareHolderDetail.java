package com.cscs.portal.dto;

public class ShareHolderDetail implements Comparable<ShareHolderDetail>{

	private String sharehdId;
	private String sharehdName;
	private String islist;
	private String isbond;
	private String islist3;
	private String ispfund;
	private String isCompany;
	private String shareType;
	private String sharehdNum;
	private String sharehdRatio;
	private String changeAmount;
	private String changeRatio;
	
	public String getSharehdId() {
		return sharehdId;
	}

	public void setSharehdId(String sharehdId) {
		this.sharehdId = sharehdId;
	}


	public String getSharehdName() {
		return sharehdName;
	}


	public void setSharehdName(String sharehdName) {
		this.sharehdName = sharehdName;
	}


	public String getIslist() {
		return islist;
	}


	public void setIslist(String islist) {
		this.islist = islist;
	}


	public String getIsbond() {
		return isbond;
	}


	public void setIsbond(String isbond) {
		this.isbond = isbond;
	}


	public String getIslist3() {
		return islist3;
	}


	public void setIslist3(String islist3) {
		this.islist3 = islist3;
	}


	public String getIspfund() {
		return ispfund;
	}


	public void setIspfund(String ispfund) {
		this.ispfund = ispfund;
	}


	public String getIsCompany() {
		return isCompany;
	}


	public void setIsCompany(String isCompany) {
		this.isCompany = isCompany;
	}


	public String getShareType() {
		return shareType;
	}


	public void setShareType(String shareType) {
		this.shareType = shareType;
	}


	public String getSharehdNum() {
		return sharehdNum;
	}


	public void setSharehdNum(String sharehdNum) {
		this.sharehdNum = sharehdNum;
	}


	public String getSharehdRatio() {
		return sharehdRatio;
	}


	public void setSharehdRatio(String sharehdRatio) {
		this.sharehdRatio = sharehdRatio;
	}


	public String getChangeAmount() {
		return changeAmount;
	}


	public void setChangeAmount(String changeAmount) {
		this.changeAmount = changeAmount;
	}


	public String getChangeRatio() {
		return changeRatio;
	}


	public void setChangeRatio(String changeRatio) {
		this.changeRatio = changeRatio;
	}


	@Override
	public int compareTo(ShareHolderDetail o) {
		double o1 = Double.parseDouble(sharehdRatio.split("%")[0]);
		double o2 = Double.parseDouble(o.sharehdRatio.split("%")[0]);
		if(o1>o2)
			return -1;
		else if(o1<o2)
			return 1;
		else
			return 0;
	}

}
