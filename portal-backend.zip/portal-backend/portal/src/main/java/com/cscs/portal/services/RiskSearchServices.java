package com.cscs.portal.services;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.response.QueryResponse;

import com.cscs.portal.dto.RiskInfoSearchCondition;
import com.cscs.portal.dto.RiskSearchOut;

/**
 * 
 * @ClassName: RiskSearchServices
 * @Description: 风险高级搜索服务接口
 * @author: liunn
 * @date: 2018年10月20日 下午4:37:27
 */
public interface RiskSearchServices {
    /**
     * 
     * @Title: setSolrQuery
     * @Description: 组装SolrQuery参数
     * @return
     * @return: SolrQuery
     */
	SolrQuery setSolrQuery(RiskInfoSearchCondition condition,SolrQuery query);
	
	/**
	 * 
	 * @Title: getResponseDate
	 * @Description: 组装返回参数
	 * @param response
	 * @return
	 * @return: List<RiskSearchOut>
	 */
	List<RiskSearchOut> getResponseDate(QueryResponse response);
	/**
	 * 
	 * @Title: getBondDefaultsResult
	 * @Description: 债券违约统计企业列表
	 * @param response
	 * @return
	 * @return: List<RiskSearchOut>
	 */
	public List<RiskSearchOut> getBondDefaultsResult(QueryResponse response);
	/**
	 * 
	 * @Title: bondDefaultsCondition
	 * @Description: 债券违约统计企业列表-查询条件
	 * @param condition
	 * @param query
	 * @return
	 * @return: SolrQuery
	 */
	public SolrQuery queryCondition(RiskInfoSearchCondition condition,SolrQuery query);
	/**
	 * 
	 * @Title: getFinancialRiskStaList
	 * @Description: 财务风险-非标准审计意见统计企业列表
	 * @param response
	 * @return
	 * @return: List<RiskSearchOut>
	 */
	public List<Map<String,String>> getFinancialRiskStaList(QueryResponse response);
	
	public String getQueryTime(String foundDt) throws ParseException;

	public String getQueryTime(String startDt, String endDt) throws ParseException;

	public String getQueryTime2(String foundDt) throws ParseException;
}
