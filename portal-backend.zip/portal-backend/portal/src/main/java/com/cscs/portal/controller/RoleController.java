package com.cscs.portal.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.shiro.authz.annotation.RequiresRoles;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cscs.portal.dto.RoleInfoData;
import com.cscs.portal.dto.RoleOutData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.Role;
import com.cscs.portal.services.RoleServices;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by dch on 2016/11/7.
 * 角色信息
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/role")
public class RoleController {

    @Autowired
    RoleServices roleServices;

    /**
     * 新增或更新角色信息
     *
     * @param inData
     * @return
     */
    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public BaseOutData save(HttpServletRequest request, @RequestBody RoleInfoData inData) {
        BaseOutData out = new BaseOutData();
        Long userId = Long.valueOf((String)request.getAttribute("userId"));
        inData.setAccountId(userId);
        if (StringUtils.isEmpty(inData.getRoleNm())) {
            out.setCode("1");
            out.setMessage("新增角色信息不能为空!");
            return out;
        }
        try {
            this.roleServices.save(inData);
            out.setCode("0");
        } catch (Exception e) {
            out.setCode("1");
            out.setMessage(e.getMessage());
        }
        return out;
    }

//    /**
//     * 删除角色信息,允许批量删除
//     *
//     * @param inData
//     * @return
//     */
//    @RequestMapping(value = "/delete", method = RequestMethod.POST)
//    public BaseOutData delete(@RequestBody RoleInfoData inData) {
//        BaseOutData out = new BaseOutData();
//        if (StringUtils.isEmpty(inData.getRoleIdArray())) {
//            out.setCode("1");
//            out.setMessage("删除角色，ID不能为空!");
//            return out;
//        }
//        try {
//            this.roleServices.deleteRole(inData.getRoleIdArray());
//            out.setCode("0");
//        } catch (Exception e) {
//            out.setCode("1");
//            out.setMessage(e.getMessage());
//        }
//        return out;
//    }

    /**
     * 查询全部的角色信息
     *
     * @return
     */
    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/findRoleAll", method = RequestMethod.GET)
    public List<RoleOutData> findRoleAll() {
        List<RoleOutData> out = new ArrayList<>();
        List<Role> itemList = roleServices.findAll();
        for (Role item : itemList) {
            RoleOutData info = new RoleOutData();
            BeanUtils.copyProperties(item, info);
            out.add(info);
        }
        return out;
    }

    /**
     * 根据角色名称获取角色信息
     *
     * @param roleNm
     * @return
     */
    @RequiresRoles(value = "admin")
    @RequestMapping(value = "/findRole/{roleNm}", method = RequestMethod.GET)
    public RoleOutData findRoelByOne(@PathVariable String roleNm) {
        RoleOutData out = new RoleOutData();
        Role role = this.roleServices.findOne(roleNm);
        if(role != null) {
            BeanUtils.copyProperties(role, out);
        }
        return out;
    }
}
