package com.cscs.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cscs.portal.entity.UserBasicinfo;

/**
 * Created by dch on 2016/8/9.
 * 用户详细信息表
 */
@SuppressWarnings("JpaQlInspection")
public interface UserBasicinfoRepository extends JpaRepository<UserBasicinfo, Long> {
    /**
     * 根据账户Id查询用户信息
     * @param aid
     * @return
    //     */
//    @Query(value = "select u.userNm,u.headUrl,u.birth,u.userGender,u.idCardNo, u.cellphone,u.phone,u.email,u.address,u.major,u.educational,u.politicalStatus,u.introduction,u.userType,u.companyId,u.companyNm,u.goodType,u.industrySid,u.updtBy,u.updtDt from userBasicinfo u  join account a on a.userId=u.userId where a.accountId=:aid")
//    UserBasicinfo findUserBasicinfoByAccountId(@Param("aid") Long aid);
	
	  //判断账户是否存在
    @Query(value = "select pu from UserBasicinfo pu where pu.accountNm=:accountNm")
    List<UserBasicinfo> findByAccountNm(@Param("accountNm") String accountNm);

//    @Query(value = "select SEQ_USER_BASICINFO.NEXTVAL")
//    Long generatedValue();
    
    //判断账户密码是否正确
    @Query(value = "select pu from UserBasicinfo pu where pu.accountNm=:accountNm and pu.accountPw=:accountPw")
    List<UserBasicinfo> findByAccount(@Param("accountNm") String accountNm, @Param("accountPw") String accountPw);
}
