package com.cscs.portal.controller;

import com.alibaba.fastjson.JSON;
import com.cscs.portal.dto.NewsDetailOut;
import com.cscs.portal.dto.NewsSearchConditon;
import com.cscs.portal.dto.NewsWarningInData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.services.NewsSearchServices;
import com.cscs.portal.services.NewsWarningServices;
import com.cscs.util.Contants;
import com.cscs.util.DateUtils;
import com.cscs.util.HttpUtil;
import com.cscs.util.SolrUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 新闻舆情
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/company/news")
public class CompanyNewsController {

    @Autowired
    private StringRedisTemplate rt;
    @Autowired
	private NewsSearchServices newsSearchServices;
    @Autowired
    NewsWarningServices services;

    //负面新闻统计
    public static String COMPANY_NEWS_STATISTICS = "cn_newssta";
    //负面新闻命中的预警指标
    public static String COMPANY_NEWS_WARNINGCODE = "cn_warncode";
    //负面新闻提到的企业
    public static String COMPANY_NEWS_RELATECOMPANY = "cn_relatecom";
    //负面新闻
    public static String COMPANY_NEWS_NEGATIVENEWS = "cn_negnews";

    //公告分析 - 标签统计
    public static String COMPANY_NEWS_ANNOUNCE_STATISTICS = "cn_astatis";
    //公告分析 - 公告分析
    public static String COMPANY_NEWS_ANNOUNCE = "cn_announce";
    //热度趋势-舆情趋势
    public static String COMPANY_NEWS_TREND = "cn_trend";
    //热度趋势-词云
    public static String COMPANY_NEWS_WORDSFUZZY = "cn_wordfuzzy";
    //热度趋势-新闻详情
    public static String COMPANY_NEWS_TRENDNEWS_LIST = "cn_trendnews";
    //关联方资讯 - 统计
    public static String COMPANY_NEWS_RELATED_STATISTICS = "cn_restatis";
    //关联方资公讯-新闻详情
    public static String COMPANY_NEWS_RELATEDNEWS_LIST = "cn_renews";
    //新闻详情(新闻详情页)
    public static String COMPANY_NEWS_NEWS_DETAIL = "cn_news_detail";

    /**
     * 负面新闻统计
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/negativenewsstatis/{companyId}", method = RequestMethod.GET)
    public Object getNegativeNewsStatistics(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_NEWS_STATISTICS + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_NEWS_NEGATIVENEWSSTATIS_URL, companyId));
    			if(out!=null) {
    				rt.opsForValue().set(COMPANY_NEWS_STATISTICS + companyId,out.toString());
    				rt.expire(COMPANY_NEWS_STATISTICS + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
        Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 负面新闻命中的预警指标
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/negativenewswarningcode/{companyId}", method = RequestMethod.GET)
    public BaseOutData getNegativeNewsWarningCode(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	List<Map> list = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_NEWS_WARNINGCODE + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_NEWS_NEGATIVENEWSWARNINGCODE_URL, companyId));
    			if(out!=null) {
    				rt.opsForValue().set(COMPANY_NEWS_WARNINGCODE + companyId,out.toString());
    				rt.expire(COMPANY_NEWS_WARNINGCODE + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
    		if(out!=null) {
    			//排序
    			list = JSON.parseArray(String.valueOf(out), Map.class);
    			Collections.sort(list,new Comparator<Map>(){
    	            public int compare(Map arg0, Map arg1) {
    	                return Integer.valueOf(arg1.get("warningCt").toString()).compareTo(Integer.valueOf(arg0.get("warningCt").toString()));
    	            }
    	        });
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
        Map data = new HashMap();
    	data.put("result", list);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 负面新闻提到的企业
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/negativenewscompany/{companyId}", method = RequestMethod.GET)
    public BaseOutData getNegativeNewsCompany(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	List<Map> list = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_NEWS_RELATECOMPANY + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_NEWS_NEGATIVENEWSCOMPANY_URL, companyId));
    			if(out!=null) {
    				rt.opsForValue().set(COMPANY_NEWS_RELATECOMPANY + companyId,out.toString());
    				rt.expire(COMPANY_NEWS_RELATECOMPANY + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
    		if(out!=null) {
    			//排序
    			list = JSON.parseArray(String.valueOf(out), Map.class);
    			Collections.sort(list,new Comparator<Map>(){
    	            public int compare(Map arg0, Map arg1) {
    	                return Integer.valueOf(arg1.get("relatedCompyCt").toString()).compareTo(Integer.valueOf(arg0.get("relatedCompyCt").toString()));
    	            }
    	        });
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
        Map data = new HashMap();
    	data.put("result", list);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 负面新闻
     * @return
     */
    @RequestMapping(value = "/negativenews", method = RequestMethod.POST)
    public BaseOutData getNegativeNewsCompany(@RequestBody Map<String,String> inData) {
    	String companyId = inData.get("companyId");
        String warningNm = inData.get("warningNm");
        String relatedCompyName = inData.get("relatedCompyName");
        String page = inData.get("page");
        String pageSize = inData.get("pageSize");
        
        BaseOutData outData = new BaseOutData();
    	List<Object> returnList;
    	long numFound = 0L;
    	try {
    		//创建Solr服务对象，通过此对象向solr服务发起请求
    		SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_SENTIMENT_METHOD);
    		//创建查询对象
    		SolrQuery query = new SolrQuery();
    		//设置公共参数
    		NewsSearchConditon condition = new NewsSearchConditon();
    		condition.setCurPage(StringUtils.isNotBlank(page)?Integer.valueOf(page):1);
    		condition.setRowNum(StringUtils.isNotBlank(page)?Integer.valueOf(pageSize):10);
    		query = newsSearchServices.setSolrQuery(condition, query);
    		
    		/*****************************过滤条件start*****************************************/
    		//媒体类型
    		query.addFilterQuery("data_src:\"新闻\"");
    		//负面新闻
    		query.addFilterQuery("negtive:\"1\"");
    		//三个月时间限制
    		String queryString = this.getQueryTime(this.getThreeMonth());
    		query.addFilterQuery("post_dt:"+queryString);
    		//三颗星以上
    		query.addFilterQuery("relevancy:[3 TO *]");
    		//过滤公司id
    		if(StringUtils.isNotEmpty(companyId)) {
    			query.addFilterQuery("company_id:"+companyId);
    		}
    		//过滤公司id
    		if(StringUtils.isNotEmpty(relatedCompyName)) {
    			query.addFilterQuery("relatedcompyarray:\""+relatedCompyName+"\"");
    		}
    		//过滤风险类型
    		if(StringUtils.isNotEmpty(warningNm)) {
    			query.addFilterQuery("sheet_l1:\""+warningNm+"\"");
    		}
    		/*****************************过滤条件end*****************************************/
    		
    		//执行查询
    		QueryResponse response = solrServer.query(query);
    		//返回的数据量
    		numFound = response.getResults().getNumFound();
    		//返回的数据
    		returnList = newsSearchServices.getNegativeNewsCompany(response);
    		
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        Map data = new HashMap();
        data.put("result", returnList);
        outData.setCode("0");
        outData.setCount((int)numFound);
        outData.setMessage("返回成功!");
        outData.setData(data);
    	return outData;
    }
    
    private String getThreeMonth() {
		String startStr = DateUtils.formatDate(org.apache.commons.lang3.time.DateUtils.addMonths(new Date(), -3), "yyyyMMddHHmmss");
		String endStr = DateUtils.formatDate(new Date(), "yyyyMMddHHmmss");
    	return startStr+"-"+endStr;
    }

    /**
     * 公告分析 - 标签统计
     * @return
     */
    @RequestMapping(value = "/announcestatistics/{companyId}", method = RequestMethod.GET)
    public BaseOutData getAnnounceStatistics(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_NEWS_ANNOUNCE_STATISTICS + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_NEWS_ANNOUNCESTATISTICS_URL, companyId));
                if(out!=null) {
                    rt.opsForValue().set(COMPANY_NEWS_ANNOUNCE_STATISTICS + companyId,out.toString());
                    rt.expire(COMPANY_NEWS_ANNOUNCE_STATISTICS + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 公告分析 - 公告分析
     * @return
     */
    @RequestMapping(value = "/announce", method = RequestMethod.POST)
    public BaseOutData getAnnounce(@RequestBody Map<String,String> inData) {
    	String page = inData.get("page");
        String pageSize = inData.get("pageSize");
        String companyId = inData.get("companyId");
        String firstRiskLabel = inData.get("firstRiskLabel");
        String secondRiskLabel = inData.get("secondRiskLabel");

        BaseOutData outData = new BaseOutData();
    	List<Object> returnList = new ArrayList<Object>();
    	long numFound = 0L;
    	try {
    		//创建Solr服务对象，通过此对象向solr服务发起请求
    		SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_SENTIMENT_METHOD);
    		//创建查询对象
    		SolrQuery query = new SolrQuery();
    		//设置公共参数
    		NewsSearchConditon condition = new NewsSearchConditon();
    		condition.setCurPage(StringUtils.isNotBlank(page)?Integer.valueOf(page):1);
    		condition.setRowNum(StringUtils.isNotBlank(page)?Integer.valueOf(pageSize):10);
    		query = newsSearchServices.setSolrQuery(condition, query);
    		
    		/*****************************过滤条件start*****************************************/
    		//过滤公司id
    		if(StringUtils.isNotEmpty(companyId)) {
    			query.addFilterQuery("company_id:"+companyId);
    		}
    		//过滤媒体类型
    		query.addFilterQuery("data_src:\"公告\"");
    		//一级风险标签
    		if(StringUtils.isNotEmpty(firstRiskLabel)) {
    			query.addFilterQuery("sheet_l1:\""+firstRiskLabel+"\"");
    		}
    		//二级风险标签
    		if(StringUtils.isNotEmpty(secondRiskLabel)) {
    			query.addFilterQuery("sheet_l2:\""+secondRiskLabel+"\"");
    		}
    		/*****************************过滤条件end*****************************************/
    		
    		//执行查询
    		QueryResponse response = solrServer.query(query);
    		//返回的数据量
    		numFound = response.getResults().getNumFound();
    		//返回的数据
    		returnList = newsSearchServices.getAnnounce(response);
    		
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        Map data = new HashMap();
        data.put("result", returnList);
        outData.setCode("0");
        outData.setCount((int)numFound);
        outData.setMessage("返回成功!");
        outData.setData(data);
    	return outData;
    }

    /**
     * 热度趋势-舆情趋势
     * @return
     */

    @RequestMapping(value = "/trendnews", method = RequestMethod.POST)
    public Map getTrendNews(@RequestBody NewsWarningInData inData) {
//        String companyId = inData.get("companyId");
//        String timeFlg = inData.get("timeFlg");
//
//        BaseOutData out = new BaseOutData();
//
//        Map<String, Object> re = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_NEWS_TRENDNEWS_URL, companyId));
//        out.setData(re);
//        out.setCode("0");
//        return out;

        //暂时先用1.0的舆情舆情接口代替
        int newsCount = 0;
        int negativeNewsCount = 0;
        Map<String, Map> outData = new LinkedHashMap<>();
        List<Object> itemList = services.findchart(inData);
        Map<String, Map> infoList = new LinkedHashMap<>();
        Map<String, String> countMap = new LinkedHashMap<>();
        for (int i = 0; i < itemList.size(); i++) {
            Map<String, String> info = new LinkedHashMap<>();
            Object[] item = (Object[]) itemList.get(i);
            info.put("newsCount", item[0] != null ? item[0].toString() : "0");
            info.put("negativeNewsCount", item[1] != null ? item[1].toString() : "0");
            infoList.put(item[2] != null ? item[2].toString() : "", info);
            newsCount += item[0] != null ? Integer.valueOf(item[0].toString()) : 0;
            negativeNewsCount += item[1] != null ? Integer.valueOf(item[1].toString()) : 0;
        }
        countMap.put("newsCount", String.valueOf(newsCount));
        countMap.put("negativeNewsCount", String.valueOf(negativeNewsCount));
        if (negativeNewsCount == 0) {
            countMap.put("rate", "0");
        } else {
            countMap.put("rate", String.format("%.2f", (double) negativeNewsCount / newsCount * 100) + "%");
        }
        outData.put("data", infoList);
        outData.put("count", countMap);
        return outData;
    }

    /**
     * 热度趋势-词云
     * @return
     */

    @RequestMapping(value = "/wordsfuzzy/{companyId}", method = RequestMethod.GET)
    public BaseOutData getWordsFuzzy(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_NEWS_WORDSFUZZY + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_NEWS_WORDSFUZZY_URL, companyId));
                if(out!=null) {
                    rt.opsForValue().set(COMPANY_NEWS_WORDSFUZZY + companyId,out.toString());
                    rt.expire(COMPANY_NEWS_WORDSFUZZY + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 热度趋势-新闻详情
     * @return
     */
    @RequestMapping(value = "/treadnewslist", method = RequestMethod.POST)
    public BaseOutData getTrendNewsList(@RequestBody Map<String,String> inData) {
    	String companyId = inData.get("companyId");
        String keyword = inData.get("keyword");
        String score = inData.get("score");
        String page = inData.get("page");
        String pageSize = inData.get("pageSize");

        BaseOutData outData = new BaseOutData();
    	List<Object> returnList = new ArrayList<Object>();
    	long numFound = 0L;
    	try {
    		//创建Solr服务对象，通过此对象向solr服务发起请求
    		SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_SENTIMENT_METHOD);
    		//创建查询对象
    		SolrQuery query = new SolrQuery();
    		//设置公共参数
    		NewsSearchConditon condition = new NewsSearchConditon();
    		condition.setCurPage(page!=null?Integer.valueOf(page):1);
    		condition.setRowNum(pageSize!=null?Integer.valueOf(pageSize):10);
    		condition.setKeyword(keyword);
    		query = newsSearchServices.setSolrQuery(condition, query);
    		
    		/*****************************过滤条件start*****************************************/
    		//过滤媒体类型
    		query.addFilterQuery("data_src:\"新闻\"");
    		//过滤公司id
    		if(StringUtils.isNotEmpty(companyId)) {
    			query.addFilterQuery("company_id:"+companyId);
    		}
    		//是否负面新闻
    		if(StringUtils.isNotEmpty(score)) {
    			query.addFilterQuery("negtive:"+score);
    		}
    		/*****************************过滤条件end*****************************************/
    		
    		//执行查询
    		QueryResponse response = solrServer.query(query);
    		//返回的数据量
    		numFound = response.getResults().getNumFound();
    		//返回的数据
    		returnList = newsSearchServices.getTrendNewsList(response);
    		
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        Map data = new HashMap();
        data.put("result", returnList);
        outData.setCode("0");
        outData.setCount((int)numFound);
        outData.setMessage("返回成功!");
        outData.setData(data);
    	return outData;
    }

    /**
     * 关联方资讯 - 关系
     * @return
     */

    @RequestMapping(value = "/relatedstatistics/{companyId}", method = RequestMethod.GET)
    public BaseOutData getRelatedStatistics(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_NEWS_RELATED_STATISTICS + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_NEWS_RELATEDSTATISTICS_URL, companyId));
                if(out!=null) {
                    rt.opsForValue().set(COMPANY_NEWS_RELATED_STATISTICS + companyId,out.toString());
                    rt.expire(COMPANY_NEWS_RELATED_STATISTICS + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 关联方资讯-新闻详情
     * @return
     */
    @RequestMapping(value = "/relatednewslist", method = RequestMethod.POST)
    public BaseOutData getRelatedNewsList(@RequestBody Map<String,String> inData) {
    	String companyId = inData.get("companyId");
        String relevance = inData.get("relevance");
        String warningType = inData.get("warningType");
        String page = inData.get("page");
        String pageSize = inData.get("pageSize");

        BaseOutData outData = new BaseOutData();
    	List<Object> returnList = new ArrayList<Object>();
    	long numFound = 0L;
    	try {
    		//创建Solr服务对象，通过此对象向solr服务发起请求
    		SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_SENTIMENT_METHOD);
    		//创建查询对象
    		SolrQuery query = new SolrQuery();
    		//设置公共参数
    		NewsSearchConditon condition = new NewsSearchConditon();
    		condition.setCurPage(Integer.valueOf(page));
    		condition.setRowNum(Integer.valueOf(pageSize));
    		query = newsSearchServices.setSolrQuery(condition, query);
    		
    		/*****************************过滤条件start*****************************************/
    		//过滤媒体类型
    		query.addFilterQuery("data_src:\"新闻\"");
    		//过滤公司id
    		if(StringUtils.isNotEmpty(companyId)) {
    			query.addFilterQuery("company_id:"+companyId);
    		}
    		//关联度
    		if(StringUtils.isNotEmpty(relevance)) {
    			query.addFilterQuery("relevancy:"+relevance);
    		}
    		//二级风险标签
    		if(StringUtils.isNotEmpty(warningType)) {
    			query.addFilterQuery("sheet_l2:\""+warningType+"\"");
    		}
    		/*****************************过滤条件end*****************************************/
    		
    		//执行查询
    		QueryResponse response = solrServer.query(query);
    		//返回的数据量
    		numFound = response.getResults().getNumFound();
    		//返回的数据
    		returnList = newsSearchServices.getRelatedNewsList(response);
    		
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        Map data = new HashMap();
        data.put("result", returnList);
        outData.setCode("0");
        outData.setCount((int)numFound);
        outData.setMessage("返回成功!");
        outData.setData(data);
    	return outData;
    }
    /**
     * 新闻详情(新闻详情页)
     * @return
     */
    @SuppressWarnings("unchecked")

    @RequestMapping(value = "/detail/{companyId}/{newsId}", method = RequestMethod.GET)
    public BaseOutData getDetail(@PathVariable String companyId,@PathVariable String newsId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        NewsDetailOut newsDetail = null;
        String key = COMPANY_NEWS_NEWS_DETAIL + companyId + '_' + newsId;
        QueryResponse response = null;
        Map data = new HashMap();
        try {
            out = rt.opsForValue().get(key);
            if (out == null) {
                SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_SENTIMENT_METHOD);
                //创建一个SolrQuery对象
                SolrQuery query = new SolrQuery();
                query.set("wt", "json");
                query.set("q", "info_sid:" + newsId);
                query.set("fq", "company_id:" + companyId);
                response = solrServer.query(query);
                for (SolrDocument solrDocument : response.getResults()) {
                    newsDetail = new NewsDetailOut();
                    if (solrDocument.get("relatedcompylist") != null && solrDocument.get("newsdetail") != null) {
                        newsDetail.setRelatedcompylist(JSON.parse((String) solrDocument.get("relatedcompylist")));
                        newsDetail.setNewsdetail(JSON.parse((String) solrDocument.get("newsdetail")));
                    } else {
                        newsDetail.setRelatedcompylist(newsSearchServices.getRelateCompanyList(newsId));
                        //组装newsdetail
                        Map newsdetailMap = new HashMap();
                        List sheetLabel = new ArrayList();
                        List sheet_l1 = (List) solrDocument.get("sheet_l1");
                        for (int i = 0; sheet_l1 != null && i < sheet_l1.size(); i++) {
                            Map sheetl1Map = new HashMap();
                            sheetl1Map.put("label", "-1");
                            sheetl1Map.put("SHEET_L1", sheet_l1.get(i));
                            sheetLabel.add(sheetl1Map);
                        }
                        newsdetailMap.put("sheetLabel", sheetLabel);
                        newsdetailMap.put("publishTime", solrDocument.get("post_dt") != null ? DateUtils.formatDate((Date) solrDocument.get("post_dt"), "yyyy-MM-dd HH:mm:ss") : null);
                        newsdetailMap.put("score", solrDocument.get("data_score"));
                        newsdetailMap.put("warningType", solrDocument.get("sheet_l1") != null ? String.join(",", (List) solrDocument.get("sheet_l1")) : null);
                        newsdetailMap.put("newsSource", solrDocument.get("media_nm"));
                        newsdetailMap.put("importance", solrDocument.get("importance"));
                        newsdetailMap.put("relevance", solrDocument.get("relevance"));
                        newsdetailMap.put("newsTitle", solrDocument.get("data_title"));
                        newsdetailMap.put("content", solrDocument.get("news_content"));
                        newsDetail.setNewsdetail(newsdetailMap);
                    }

                    newsDetail.setCompany_nm((String) solrDocument.get("company_nm"));
                    out = newsDetail;
                }
                if (out != null) {
                    rt.opsForValue().set(key, JSON.toJSONString(out));
                    rt.expire(key, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
                data.put("result", out);
            } else {
                data.put("result", JSON.parseObject(String.valueOf(out), NewsDetailOut.class));
            }
        } catch (Exception e) {
            outData.setCode("1");
            outData.setMessage("系统报错!" + e.getMessage());
            return outData;
        }
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /***
     * 新闻推荐
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/recommend/{companyId}", method = RequestMethod.GET)
    public BaseOutData getRecommend(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Map data = new HashMap();
        List returnList = new ArrayList();
        long returnCount;
        try {
            SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_SENTIMENT_METHOD);
            //创建一个SolrQuery对象
            SolrQuery query = new SolrQuery();
            query.set("wt", "json");
            //只查询存活的分片
            query.set("shards.tolerant", "true");
            query.set("q", "company_id:" + companyId);
            //过滤负面
            query.addFilterQuery("negtive:1");
            //新闻
            query.addFilterQuery("data_src:新闻");
            //三星及三星以上
            query.addFilterQuery("relevancy:[3 TO *]");
            //排序
            query.addSort("post_dt", SolrQuery.ORDER.desc);
            //取前三条记录
            query.setRows(3);
            QueryResponse response = solrServer.query(query);
            returnCount = response.getResults().getNumFound();
            for (SolrDocument solrDocument : response.getResults()) {
                Map map = new HashMap();
                map.put("newstitle", solrDocument.get("data_title"));
                map.put("newsId", solrDocument.get("info_sid"));
                map.put("newscode", solrDocument.get("info_cd"));
                map.put("publishTime", solrDocument.get("post_dt")!=null?DateUtils.formatDate((Date)solrDocument.get("post_dt"),"yyyy-MM-dd HH:mm:ss"):null);
                returnList.add(map);
            }
            data.put("result", returnList);
        } catch (SolrServerException e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!" + e.getMessage());
            return outData;
        }
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        outData.setCount((int)returnCount);
        return outData;
    }

    
    private String getQueryTime(String foundDt) throws ParseException {
    	String queryStr = "";
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    	SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
    	Date startTime = null;
    	Date endTime = null;
    	String[] foundDtArr = foundDt.split("-");
    	if(foundDtArr!=null && foundDtArr.length>1) {
    		String startDateStr = foundDtArr[0];
    		String endDateStr = foundDtArr[1];
    		startTime = formatter.parse(startDateStr);
			endTime = formatter.parse(endDateStr);
			queryStr = "["+sdf.format(startTime)+" TO "+sdf.format(endTime)+"]";
    	}
    	return queryStr;
    }
}
