package com.cscs.portal.dto;

import java.util.List;

/**
 *  新闻舆情接口返回数据

 * @ClassName: NewsSearchOut

 * @Description: TODO

 * @author: liunn

 * @date: 2018年9月13日 上午11:33:31
 */
public class NewsSearchOut{
	//企业id
	private String companyId;
	//媒体类型
	private String mediaType;
	//标题
    private String title;
    //来源
    private String source;
    //发布时间
    private String publishTime;
    //相关企业
    private String companyName;
    //风险类型
    private String riskType;
    //是否负面新闻
    private String negative;
    //相关程度
    private String relevancy;
    //新闻编码
    private String infoCd;
    //新闻id
    private String newsId;
    //一级标签
    private List sheetL1;
    //二级标签
    private List sheetL2;
    //score
	private String dataScore;
	private String newsContent;
	private String relevance;
	private String importance;
    //高亮字段
    private List highlightColumns;

	public String getDataScore() {
		return dataScore;
	}

	public void setDataScore(String dataScore) {
		this.dataScore = dataScore;
	}

	public String getNewsContent() {
		return newsContent;
	}

	public void setNewsContent(String newsContent) {
		this.newsContent = newsContent;
	}

	public String getRelevance() {
		return relevance;
	}

	public void setRelevance(String relevance) {
		this.relevance = relevance;
	}

	public String getImportance() {
		return importance;
	}

	public void setImportance(String importance) {
		this.importance = importance;
	}

	public String getNewsId() {
		return newsId;
	}

	public void setNewsId(String newsId) {
		this.newsId = newsId;
	}

	public List getSheetL1() {
		return sheetL1;
	}
	public void setSheetL1(List sheetL1) {
		this.sheetL1 = sheetL1;
	}
	public List getSheetL2() {
		return sheetL2;
	}
	public void setSheetL2(List sheetL2) {
		this.sheetL2 = sheetL2;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getInfoCd() {
		return infoCd;
	}
	public void setInfoCd(String infoCd) {
		this.infoCd = infoCd;
	}
	public List getHighlightColumns() {
		return highlightColumns;
	}
	public void setHighlightColumns(List highlightColumns) {
		this.highlightColumns = highlightColumns;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getRelevancy() {
		return relevancy;
	}
	public void setRelevancy(String relevancy) {
		this.relevancy = relevancy;
	}
	public String getMediaType() {
		return mediaType;
	}
	public void setMediaType(String mediaType) {
		this.mediaType = mediaType;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getPublishTime() {
		return publishTime;
	}
	public void setPublishTime(String publishTime) {
		this.publishTime = publishTime;
	}
	public String getRiskType() {
		return riskType;
	}
	public void setRiskType(String riskType) {
		this.riskType = riskType;
	}

	public String getNegative() {
		return negative;
	}

	public void setNegative(String negative) {
		this.negative = negative;
	}
}
