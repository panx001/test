package com.cscs.portal.controller;

import com.alibaba.fastjson.JSON;
import com.cscs.portal.dto.RiskInfoSearchCondition;
import com.cscs.portal.dto.RiskSearchOut;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.services.RiskSearchServices;
import com.cscs.util.Contants;
import com.cscs.util.HttpUtil;
import com.cscs.util.SolrUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/***
 * 
 * @ClassName: RiskSearchController
 * @Description: 风险信息高级搜索相关接口
 * @author: liunn
 * @date: 2018年9月17日 下午2:30:49
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/risk/search")
public class RiskSearchController {
	protected final Log logger = LogFactory.getLog(this.getClass());
	//风险类型
    public static String RISK_TYPE = "r_s_risktype";
    @Autowired
    private StringRedisTemplate rt;
    @Autowired
    RiskSearchServices riskSearchServices;
    /**
     * 
     * @Title: getResult
     * @Description: 高级搜索-风险信息查询
     * @param condition
     * @return
     * @return: Object
     */
    @RequestMapping(value = "/getResult", method = RequestMethod.POST)
    public Object getResult(@RequestBody RiskInfoSearchCondition condition){
    	BaseOutData outData = new BaseOutData();
    	List<RiskSearchOut> returnList = null;
    	long numFound = 0L;
    	try {
    		//创建Solr服务对象，通过此对象向solr服务发起请求
    		SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_RISK_METHOD);
    		//创建查询对象
    		SolrQuery query = new SolrQuery();
    		//设置公共查询参数
    		query = riskSearchServices.setSolrQuery(condition, query);
    		/*****************************设置过滤条件start*****************************************/
    		//风险搜索去掉财务风险
			query.addFilterQuery("-risk_type:\"财务风险\"");
    		//过滤风险类型
    		if(StringUtils.isNotEmpty(condition.getRiskType())) {
    			String[] riskTypeArr = condition.getRiskType()!=null?condition.getRiskType().split(","):null;
    			for(int i=0;riskTypeArr!=null&&i<riskTypeArr.length;i++) {
    				query.addFilterQuery("risk_type:\""+riskTypeArr[i]+"\"");
    			}
    		}
    		//过滤注册地
    		if(StringUtils.isNotEmpty(condition.getOfficeAddr())) {
    			query.addFilterQuery("reg_region:\""+condition.getOfficeAddr()+"\"");
    		}
    		//过滤所属行业
    		if(StringUtils.isNotEmpty(condition.getIndustry())) {
    			query.addFilterQuery("industry:\""+condition.getIndustry()+"\"");
    		}
    		//过滤注册资本
    		if(StringUtils.isNotEmpty(condition.getRegCapital())) {
    			String[] regCapital = condition.getRegCapital().split("-");
    			query.addFilterQuery("regcapital:["+Integer.valueOf(regCapital[0])+" TO "+Integer.valueOf(regCapital[1])+"]");
    		}
    		//过滤成立时间
    		if(StringUtils.isNotEmpty(condition.getFoundDt())) {
    			String queryString = riskSearchServices.getQueryTime(condition.getFoundDt());
    			query.addFilterQuery(queryString);
    		}
    		//过滤企业状态
    		if(StringUtils.isNotEmpty(condition.getCompanySt())) {
    			query.addFilterQuery("company_st:\""+condition.getCompanySt()+"\"");
    		}
    		/*****************************设置过滤条件end*****************************************/
    		
    		//执行查询
    		QueryResponse response = solrServer.query(query);
    		
    		//返回数量
    		numFound = response.getResults().getNumFound();
    		
    		//获取返回数据
    		returnList = riskSearchServices.getResponseDate(response);
    		
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        Map data = new HashMap();
        data.put("result", returnList);
        outData.setCode("0");
        outData.setCount((int)numFound);
        outData.setMessage("返回成功!");
        outData.setData(data);
    	return outData;
    }
    /**
     * 
     * @Title: getRiskType
     * @Description: 获取风险类型
     * @return
     * @return: Object
     */
    @RequestMapping(value = "/riskType", method = RequestMethod.GET)
    public Object getRiskType(){
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	List<Map<String,String>> list = null;
    	try {
    		out = rt.opsForValue().get(RISK_TYPE);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(Contants.HBASE_RISK_SEARCH_RISKYTYPE_URL);
    			if(null!=out) {
    				rt.opsForValue().set(RISK_TYPE,out.toString());
    				rt.expire(RISK_TYPE, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
    		if(out!=null) {
    			list = (List)JSON.parse(String.valueOf(out));
    			for(int i=0;i<list.size();i++) {
    				Map map = list.get(i);
    				if(map.get("name").equals("财务风险")) {
    					list.remove(i);
    				}
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
        Map data = new HashMap();
    	data.put("result", list);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }
    
}
