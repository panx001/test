package com.cscs.portal.controller;

import com.alibaba.fastjson.JSON;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.util.Contants;
import com.cscs.util.HttpUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * 基础展台 - 私募信息
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/company/pfund")
public class CompanyPrivateFundController {
    @Autowired
    private StringRedisTemplate rt;

    //机构备案信息
    public static String COMPANY_PFUND_RECORDINFO = "cp_recordinfo";
    //法定代表人
    public static String COMPANY_PFUND_LEGREPRESENT = "cp_legrepresent";
    //高管
    public static String COMPANY_PFUND_EXECUTIVESLIST = "cp_executiveslist";
    //股东
    public static String COMPANY_PFUND_SHAREHOLDER = "cp_sh";
    //私募机构产品信息
    public static String COMPANY_PFUND_INFO = "cp_info";
    //机构诚信信息
    public static String COMPANY_PFUND_CREDITINFO = "cp_crediti";
    //数据异常
    public static String COMPANY_PFUND_DATAEXCEPTION = "cp_dataexception";

    /**
     * 机构备案信息
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/recordinfo/{companyId}", method = RequestMethod.GET)
    public BaseOutData getBasicInfo(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_PFUND_RECORDINFO + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_PFUND_RECORDINFO_URL, companyId));
    			if(out!=null) {
    				rt.opsForValue().set(COMPANY_PFUND_RECORDINFO + companyId,out.toString());
    				rt.expire(COMPANY_PFUND_RECORDINFO + companyId, Contants.REDIS_TIMEOUT, TimeUnit.HOURS);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 法定代表人
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/legrepresent/{companyId}", method = RequestMethod.GET)
    public BaseOutData getLegrepresent(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_PFUND_LEGREPRESENT + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_PFUND_LEGREPRESENTLIST_URL, companyId));
    			if(out!=null) {
    				rt.opsForValue().set(COMPANY_PFUND_LEGREPRESENT + companyId,out.toString());
    				rt.expire(COMPANY_PFUND_LEGREPRESENT + companyId, Contants.REDIS_TIMEOUT, TimeUnit.HOURS);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 高管
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/executiveslist/{companyId}", method = RequestMethod.GET)
    public BaseOutData getExecutivesList(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
    	Object out = null;
    	try {
    		out = rt.opsForValue().get(COMPANY_PFUND_EXECUTIVESLIST + companyId);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_PFUND_EXECUTIVESLIST_URL, companyId));
    			if(out!=null) {
    				rt.opsForValue().set(COMPANY_PFUND_EXECUTIVESLIST + companyId,out.toString());
    				rt.expire(COMPANY_PFUND_EXECUTIVESLIST + companyId, Contants.REDIS_TIMEOUT, TimeUnit.HOURS);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}
    	Map data = new HashMap();
    	data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    /**
     * 股东
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/shareholderlist/{companyId}", method = RequestMethod.GET)
    public BaseOutData getShareHolderList(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_PFUND_SHAREHOLDER + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_PFUND_SHAREHOLDERLIST_URL, companyId));
                if(out!=null) {
                	rt.opsForValue().set(COMPANY_PFUND_SHAREHOLDER + companyId,out.toString());
                	rt.expire(COMPANY_PFUND_SHAREHOLDER + companyId, Contants.REDIS_TIMEOUT, TimeUnit.HOURS);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 私募机构产品信息
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/productlist/{companyId}", method = RequestMethod.GET)
    public BaseOutData getProductList(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_PFUND_INFO + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_PFUND_PRODUCTLIST_URL, companyId));
                if(out!=null) {
                	rt.opsForValue().set(COMPANY_PFUND_INFO + companyId,out.toString());
                	rt.expire(COMPANY_PFUND_INFO + companyId, Contants.REDIS_TIMEOUT, TimeUnit.HOURS);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 机构诚信信息
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/credibilityInfo/{companyId}", method = RequestMethod.GET)
    public BaseOutData getCredibilityInfo(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_PFUND_CREDITINFO + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_PFUND_CREDIBILITYINFO_URL, companyId));
                if(out!=null) {
                	rt.opsForValue().set(COMPANY_PFUND_CREDITINFO + companyId,out.toString());
                	rt.expire(COMPANY_PFUND_CREDITINFO + companyId, Contants.REDIS_TIMEOUT, TimeUnit.HOURS);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 数据异常
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/dataexception/{companyId}", method = RequestMethod.GET)
    public BaseOutData getDataException(@PathVariable String companyId) {
    	BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_PFUND_DATAEXCEPTION + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_PFUND_DATAEXCEPTION_URL, companyId));
                if(out!=null) {
                	rt.opsForValue().set(COMPANY_PFUND_DATAEXCEPTION + companyId,out.toString());
                	rt.expire(COMPANY_PFUND_DATAEXCEPTION + companyId, Contants.REDIS_TIMEOUT, TimeUnit.HOURS);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out!=null?JSON.parse(String.valueOf(out)):null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }
}
