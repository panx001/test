package com.cscs.portal.dto;

/**
 *  人名查询接口返回数据

 * @ClassName: PersonNameSearchOut

 * @Description: TODO

 * @author: liunn

 * @date: 2018年9月13日 上午11:33:31
 */
public class PersonNameSearchOut{
	//id
	private String id;
	//人名
	private String person;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPerson() {
		return person;
	}
	public void setPerson(String person) {
		this.person = person;
	}
	
    
}
