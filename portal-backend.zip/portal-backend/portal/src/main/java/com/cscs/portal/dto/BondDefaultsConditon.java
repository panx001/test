package com.cscs.portal.dto;

/**
 *  债券违约查询条件

 * @ClassName: BondDefaultsConditon

 * @Description: TODO

 * @author: liunn

 * @date: 2018年9月13日 上午11:33:31
 */
public class BondDefaultsConditon{
	//当前页
    private Integer curPage;
    //每页显示的条数
    private Integer rowNum;
	//统计开始时间
    private String startDt;
    //统计结束时间
    private String endDt;
    //统计类型分类
    private String type;
	//具体类型名称（债券类型取14种债券，行业类型取行业一级分类）
	private String typeName;
	public Integer getCurPage() {
		return curPage;
	}
	public void setCurPage(Integer curPage) {
		this.curPage = curPage;
	}
	public Integer getRowNum() {
		return rowNum;
	}
	public void setRowNum(Integer rowNum) {
		this.rowNum = rowNum;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public String getStartDt() {
		return startDt;
	}
	public void setStartDt(String startDt) {
		this.startDt = startDt;
	}
	public String getEndDt() {
		return endDt;
	}
	public void setEndDt(String endDt) {
		this.endDt = endDt;
	}
	
}
