package com.cscs.util;

import org.json.JSONArray;

import java.sql.Clob;

public class StringUtil {

	public static boolean isEmpty(String s) {
		return s == null || s.trim().length() == 0;
	}

	public static String toString(Object o) {
		if (o != null) {
			if (o instanceof Clob) {
				try {
					return ConstantWebUtils.ClobToString((Clob) o);
				} catch (Exception e) {
					e.printStackTrace();
					return "";
				}
			} else if (o instanceof JSONArray) {
				JSONArray array = (JSONArray) o;
				if (array.length() > 0) {
					return toString(array.get(0));
				}
			}
			return o.toString();
		}
		return "";
	}


	/**
	 * 去除字符串中所包含的空格（包括:空格(全角，半角)、制表符、换页符等）
	 * 
	 * @param s
	 * @return
	 */
	public static String removeAllBlank(String s) {
		String result = "";
		if (null != s && !"".equals(s)) {
			result = s.replaceAll("[　*| *| *|//s*]*", "");
		}
		return result;
	}

	/**
	 * 去除字符串中头部和尾部所包含的空格（包括:空格(全角，半角)、制表符、换页符等）
	 * 
	 * @param s
	 * @return
	 */
	public static String trim(String s) {
		String result = "";
		if (null != s && !"".equals(s)) {
			result = s.replaceAll("^[　*| *| *|//s*]*", "").replaceAll("[　*| *| *|//s*]*$", "");
		}
		return result;
	}

}