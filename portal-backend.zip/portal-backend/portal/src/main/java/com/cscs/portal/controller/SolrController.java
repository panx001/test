package com.cscs.portal.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cscs.util.Contants;

@CrossOrigin
@RestController
@RequestMapping(value = "/search")
public class SolrController {
	@RequestMapping(value = "/test", method = RequestMethod.GET)
    public Map<String, Object> save() throws SolrServerException {
        SolrServer solrServer = new HttpSolrServer("http://10.100.45.20:8983/solr/cs");
        //创建一个SolrQuery对象
        SolrQuery query = new SolrQuery();
        //设置查询条件、过滤条件、分页条件、排序条件、高亮
        query.set("q", "company_nm:碧桂园");
        query.set("defType","edismax");
        query.set("mm","90%");
//        query.setQuery("手机");
        //分页条件
        query.setStart(0);
        query.setRows(10);

        query.setSort("score", SolrQuery.ORDER.desc);
        query.addSort("regcapitaln", SolrQuery.ORDER.desc);
        //设置默认搜索域
//        query.set("df", "item_keywords");
        //设置高亮
        query.setHighlight(true);
        //高亮显示的域
        query.addHighlightField("company_nm");
        query.setHighlightSimplePre("<div>");
        query.setHighlightSimplePost("</div>");
        //执行查询，得到一个Response对象
        QueryResponse response = solrServer.query(query);
        //取查询结果
        SolrDocumentList solrDocumentList = response.getResults();
        //取查询结果总记录数
        System.out.println("查询结果总记录数：" + solrDocumentList.getNumFound());
        Map<String, Object> result = new HashMap<>();
        result.put("total", solrDocumentList.getNumFound());
        List<Map<String, String>> data = new ArrayList<>();
        for (SolrDocument solrDocument : solrDocumentList) {
            System.out.println(solrDocument.get("id"));

            //取高亮显示
            Map<String, Map<String, List<String>>> highlighting = response.getHighlighting();
            List<String> list = highlighting.get(solrDocument.get("id")).get("company_nm");

            String companyName = "";
            if (list != null && list.size() >0) {
                companyName = list.get(0);
            } else {
                companyName = String.valueOf(solrDocument.get("company_nm"));
            }
            Map<String, String> d = new HashMap<>();
            d.put("id", String.valueOf(solrDocument.get("id")));
            d.put("company_nm", companyName);
            d.put("regcapital", String.valueOf(solrDocument.get("regcapital")));
            data.add(d);
        }
        result.put("data", data);
        return result;
    }
	
	@RequestMapping(value = "/searchcompany", method = RequestMethod.GET)
    public String searchcompany(@RequestParam("companyName") String companyName) throws SolrServerException {
        SolrServer solrServer = new HttpSolrServer(Contants.SOLR_SERVICE_COMPANY_URL);
        //创建一个SolrQuery对象
        SolrQuery query = new SolrQuery();
        //设置查询条件、过滤条件、分页条件、排序条件、高亮
        //query.set("q", String.format("\"%s\"", companyName));
        query.set("q", String.format("company_nm:\"%s\"", companyName));
        query.set("defType","edismax");
        query.set("wt","json");
        //query.set("stopwords","true");
        //query.set("pf","lvl2_keyword");
        //query.set("qf","lvl1_keyword^100 lvl2_keyword lvl3_keyword^0.1");
        
        //query.setSort("score", SolrQuery.ORDER.desc);
        //设置默认搜索域
        query.setStart(0);
        query.setRows(20);
        QueryResponse response = solrServer.query(query);
        //取查询结果
        SolrDocumentList solrDocumentList = response.getResults();
        //取查询结果总记录数
        String id = null;
        for (SolrDocument solrDocument : solrDocumentList) {
        	if(companyName.equals((String) solrDocument.get("company_nm"))) {
        		 id = (String) solrDocument.get("id");
        		 break;
        	}
        }
        return id;
    }
}
