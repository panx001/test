package com.cscs.portal.services.impl;

import com.cscs.portal.services.RegionServices;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by qin on 2016/8/11.
 * 地区
 */
@SuppressWarnings({"JpaQlInspection", "JpaQueryApiInspection"})
@Service
public class RegionServicesImpl implements RegionServices {

    @PersistenceContext
    EntityManager em;

    private static final String RESTRICTEDAREA = "不限区域";
    /**
     * Created by qin on 2016/8/11.
     * 地区
     */
    @Override
    public List<Object> findProvinceCity() {
        Session session = em.unwrap(Session.class);
        Query query = session.createSQLQuery("SELECT L1.REGION_CD AS L1CODE,L1.REGION_NM AS L1REGION,\n" +
                "    L2.REGION_CD AS L2CODE,L2.REGION_NM AS L2REGION,\n" +
                "    L3.REGION_CD AS L3CODE,L3.REGION_NM AS L3REGION\n" +
                "FROM (SELECT REGION_CD,REGION_NM,PARENT_CD,REGION_TYPE\n" +
                "    FROM LKP_REGION\n" +
                "    WHERE REGION_TYPE = 1 AND REGION_CD != 100000)L1 \n" +
                "LEFT JOIN (SELECT REGION_CD,REGION_NM,PARENT_CD,REGION_TYPE\n" +
                "    FROM LKP_REGION\n" +
                "    WHERE REGION_TYPE = 2)L2 ON L2.PARENT_CD = L1.REGION_CD\n" +
                "LEFT JOIN (SELECT REGION_CD,REGION_NM,PARENT_CD,REGION_TYPE\n" +
                "    FROM LKP_REGION\n" +
                "    WHERE REGION_TYPE = 3)L3 ON L3.PARENT_CD = L2.REGION_CD\n" +
                "ORDER BY L1CODE,L2CODE,L3CODE");
        query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
        List resultQuery = query.list();

        List<Object> regionList = filterList(resultQuery,1,"");
        for (int i = 0;i < regionList.size(); i++){
            Map<Object,Object> regionMap = (Map) regionList.get(i);
            String regionKey = regionMap.get("id").toString();
            List<Map> cityList = filterList(resultQuery,2,regionKey);
            for (int j = 0;j < cityList.size(); j++){
                Map<Object,Object> cityMap = (Map) cityList.get(j);
                String cityKey = cityMap.get("id") != null ? cityMap.get("id").toString() : "";
                if(!"".equals(cityKey)) cityMap.put("citydistrict",filterList(resultQuery,3,cityKey));
            }
            regionMap.put("regioncity",cityList);
        }
        return regionList;
    }

    private List filterList(List resultQuery,int Level,String filerCode){
        List<Map> filterList = new ArrayList<>();
        String column,value,parentColumn;
        if(1 == Level){
            parentColumn = "L1CODE";
            column = "L1CODE";
            value = "L1REGION";
        } else if(2 == Level){
            parentColumn = "L1CODE";
            column = "L2CODE";
            value = "L2REGION";
        } else if(3 == Level){
            parentColumn = "L2CODE";
            column = "L3CODE";
            value = "L3REGION";
        } else {
            return filterList;
        }
        List<String> codelist = new ArrayList<>();
        for (int i = 0;i < resultQuery.size(); i++){
            Map filterMap = new HashMap();
            Map<Object,Object> map = (Map) resultQuery.get(i);
            String parentKey = map.get(parentColumn) != null ? map.get(parentColumn).toString() : "";
            if("".equals(parentKey)) continue;
            if("".equals(filerCode) || parentKey.equals(filerCode)){
                String key = map.get(column) != null ? map.get(column).toString() : "";
                if(!codelist.contains(key) && !"".equals(key)) {
                    if(codelist.size() == 0){
                        filterMap.put("id", 0);
                        filterMap.put("name", RESTRICTEDAREA);
                        filterList.add(filterMap);
                        filterMap = new HashMap();
                    }
                    filterMap.put("id", map.get(column));
                    filterMap.put("name", map.get(value));
                    filterList.add(filterMap);
                    codelist.add(key);
                }
            }
        }
        return filterList;
    }
}