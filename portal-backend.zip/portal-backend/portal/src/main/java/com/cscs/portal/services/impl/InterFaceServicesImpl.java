package com.cscs.portal.services.impl;

import com.cscs.portal.dto.InterFaceQueryInfoData;
import com.cscs.portal.entity.Interface;
import com.cscs.portal.services.IInterFaceServices;
import com.cscs.repository.InterfaceRepository;
import com.cscs.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

/**
 * Created by levy on 2017/12/2
 */
@SuppressWarnings("JpaQlInspection")
@Service
public class InterFaceServicesImpl implements IInterFaceServices {


    @PersistenceContext
    EntityManager em;

    @Autowired
    InterfaceRepository interfaceRepository;

    @Override
    public List<Object> findInterFaceList(InterFaceQueryInfoData interFaceQueryInfoData) {
        String sqlWhere = "";
        if (!StringUtil.isEmpty(interFaceQueryInfoData.getInterfaceNm()) && interFaceQueryInfoData.getInterfaceNm() != null) {
            sqlWhere = " AND  INTERFACE_NM LIKE " + "'%" + interFaceQueryInfoData.getInterfaceNm() + "%'";
        }
        if (!StringUtil.isEmpty(interFaceQueryInfoData.getInterfaceCtlType()) && interFaceQueryInfoData.getInterfaceCtlType() != null) {
            sqlWhere = " AND  CTL_TYPE = " + interFaceQueryInfoData.getInterfaceCtlType() + "";
        }
        String sql = "select INTERFACE_ID,INTERFACE_NM,INTERFACE_URL,CTL_TYPE,CTL_NAME from INTERFACE WHERE 1 = 1  " + sqlWhere;
        Query query = em.createNativeQuery(sql);
        query.setFirstResult(interFaceQueryInfoData.getPage() * 10);
        query.setMaxResults(10);

        return query.getResultList();
    }

    @Override
    public int findInterFaceCount(InterFaceQueryInfoData interFaceQueryInfoData) {
        String sqlWhere = "";
        if (!StringUtil.isEmpty(interFaceQueryInfoData.getInterfaceNm()) && interFaceQueryInfoData.getInterfaceNm() != null) {
            sqlWhere = " AND  INTERFACE_NM LIKE " + "'%" + interFaceQueryInfoData.getInterfaceNm() + "%'";
        }
        if (!StringUtil.isEmpty(interFaceQueryInfoData.getInterfaceCtlType()) && interFaceQueryInfoData.getInterfaceCtlType() != null) {
            sqlWhere = " AND  CTL_TYPE = " + interFaceQueryInfoData.getInterfaceCtlType() + "";
        }
        String sql = "select count(*) from INTERFACE WHERE 1 = 1 " + sqlWhere;
        Query query = em.createNativeQuery(sql);
        return Integer.valueOf(query.getSingleResult().toString());
    }

    @Transactional
    @Override
    public void saveOrUpdate(Interface info) {
        interfaceRepository.save(info);
    }

    @Override
    public List<Object> findInterFaceTypeList() {
        String sql = "SELECT  CTL_TYPE,CTL_NAME  FROM INTERFACE GROUP BY CTL_TYPE,CTL_NAME";
        Query query = em.createNativeQuery(sql);
        return query.getResultList();
    }

    @Override
    public String getCtlNameByCtlType(String CtlType) {
        String sql = "SELECT  DISTINCT  CTL_NAME  FROM INTERFACE WHERE CTL_TYPE = '" + CtlType + "'";
        return em.createNativeQuery(sql).getSingleResult().toString();
    }

    @Override
    @Transactional
    public void delete(Long interfaceId) {
        String sql = "DELETE INTERFACE WHERE INTERFACE_ID = ?1";
        Query query = em.createNativeQuery(sql);
        query.setParameter(1,interfaceId);
        query.executeUpdate();
    }
}
