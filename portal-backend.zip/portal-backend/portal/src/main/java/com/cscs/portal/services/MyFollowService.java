package com.cscs.portal.services;

import com.cscs.portal.entity.UserFollow;

import java.util.List;

public interface MyFollowService {
    List<Object> listCompanys(Long userId);

    void save(UserFollow info);

    void delete(Long id,Long userId);
    
    List<UserFollow> queryFollowByCondition(UserFollow info);
}
