package com.cscs.portal.services.impl;

import com.cscs.portal.dto.SystemNotificationInData;
import com.cscs.portal.dto.base.BaseInData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.SystemNotification;
import com.cscs.portal.services.NotificationService;
import com.cscs.repository.SystemNotificationRepository;
import com.cscs.repository.UserSystemNotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import java.util.Arrays;
import java.util.List;

@Service
public class NotificationServiceImpl implements NotificationService {
    @PersistenceContext
    EntityManager em;

    @Autowired
    private SystemNotificationRepository repository;

    @Autowired
    private UserSystemNotificationRepository userRepository;

    public int getUnreadCount(Long userId) {
       // String sql = "SELECT COUNT(1) FROM USER_SYSTEM_NOTIFICATION WHERE ISDEL = 0 AND ISREAD = 0 AND USERID = ?1";
        String sql = "SELECT COUNT(1) FROM USER_SYSTEM_NOTIFICATION A\n" +
                "INNER JOIN SYSTEM_NOTIFICATION B ON A.SYSTEM_NOTIFICATION_ID = B.ID\n" +
                "WHERE A.ISDEL = 0 AND A.ISREAD = 0 AND B.ISDEL = 0 AND A.USERID = ?1";
        Query query = em.createNativeQuery(sql);
        query.setParameter(1, userId);
        return Integer.valueOf(query.getSingleResult().toString());
    }

    public int getAllCount(Long userId) {
        String sql = "SELECT COUNT(1) FROM USER_SYSTEM_NOTIFICATION A\n" +
                "INNER JOIN SYSTEM_NOTIFICATION B ON A.SYSTEM_NOTIFICATION_ID = B.ID\n" +
                "WHERE A.ISDEL = 0 AND B.ISDEL = 0 AND A.USERID = ?1";
        Query query = em.createNativeQuery(sql);
        query.setParameter(1, userId);
        return Integer.valueOf(query.getSingleResult().toString());
    }

    public List<Object> getAll(BaseInData inData,Long userId) {
        int page = inData.getPage() == 0 ? 0 : inData.getPage() - 1;
        int pageSize = inData.getPageSize() == 0 ? 1 : inData.getPageSize();
        String sql = "SELECT A.ID,B.TITLE,B.CONTENT,B.DT,A.ISREAD FROM USER_SYSTEM_NOTIFICATION A\n" +
                "INNER JOIN SYSTEM_NOTIFICATION B ON A.SYSTEM_NOTIFICATION_ID = B.ID\n" +
                "WHERE A.ISDEL = 0 AND B.ISDEL = 0 AND A.USERID = ?1\n" +
                " ORDER BY B.DT DESC";

        Query query = em.createNativeQuery(sql);
        query.setParameter(1, userId);
        query.setFirstResult(page * pageSize);
        query.setMaxResults(pageSize);
        return query.getResultList();
    }

    public List<Object> getAllAdmin(BaseInData inData,BaseOutData outData) {
        int page = inData.getPage() == 0 ? 0 : inData.getPage() - 1;
        int pageSize = inData.getPageSize() == 0 ? 10 : inData.getPageSize();
        String sql = "SELECT B.ID,B.TITLE,B.CONTENT,B.DT,B.STATUS FROM SYSTEM_NOTIFICATION B\n" +
                "WHERE B.ISDEL = 0\n" +
                " ORDER BY B.DT DESC";
        outData.setCount(getAdminCount());
        Query query = em.createNativeQuery(sql);
        query.setFirstResult(page * pageSize);
        query.setMaxResults(pageSize);
        return query.getResultList();
    }

    public int getAdminCount() {
        String sql = "SELECT COUNT(1) FROM SYSTEM_NOTIFICATION A WHERE A.ISDEL = 0\n";
        Query query = em.createNativeQuery(sql);
        return Integer.valueOf(query.getSingleResult().toString());
    }

    public Object getContent(Long id) {
        String sql = "SELECT A.ID,B.TITLE,B.CONTENT,B.DT FROM USER_SYSTEM_NOTIFICATION A\n" +
                "INNER JOIN SYSTEM_NOTIFICATION B ON A.SYSTEM_NOTIFICATION_ID = B.ID\n" +
                "WHERE A.ISDEL = 0 AND B.ISDEL = 0 AND A.ID =" + id;
        return em.createNativeQuery(sql).getSingleResult();
    }

    @Transactional
    public void markRead(String idList,Long userId) {
        String sql = "UPDATE USER_SYSTEM_NOTIFICATION SET ISREAD  = 1 WHERE ID in (?1) AND USERID = ?2";
        Query query = em.createNativeQuery(sql);
        List<String> strList = Arrays.asList(idList.trim().split(","));
        query.setParameter(1, strList);
        query.setParameter(2, userId);
        query.executeUpdate();
    }

    @Transactional
    public void deleteUser(String idList,Long userId) {
        String sql = "UPDATE USER_SYSTEM_NOTIFICATION SET ISDEL  = 1 WHERE ID in (?1) AND USERID = ?2";
        Query query = em.createNativeQuery(sql);
        List<String> strList = Arrays.asList(idList.trim().split(","));
        query.setParameter(1, strList);
        query.setParameter(2, userId);
        query.executeUpdate();
    }

    @Transactional
    public void delete(Long id) {
        //String sql = "UPDATE USER_SYSTEM_NOTIFICATION SET ISDEL  = 1 WHERE ID = (SELECT SYSTEM_NOTIFICATION_ID FROM USER_SYSTEM_NOTIFICATION WHERE ID = ?1)";
        String sql = "UPDATE SYSTEM_NOTIFICATION SET ISDEL  = 1 WHERE ID = ?1";
        Query query = em.createNativeQuery(sql);
        query.setParameter(1, id);
        query.executeUpdate();
    }

    @Transactional
    public SystemNotification findOne(Long id) {
        return repository.findOne(id);
    }

    @Transactional
    public void save(SystemNotification info) {
        repository.save(info);
    }

    public List<Object> getUnLinkCount() {
        String sql = "SELECT ID FROM SYSTEM_NOTIFICATION WHERE ISDEL = 0 AND IS_RELATION = 0 AND STATUS = 1";
        return em.createNativeQuery(sql).getResultList();
    }

    public void setRelation(Long id) {
        String sql = "UPDATE SYSTEM_NOTIFICATION SET IS_RELATION = 1 WHERE ISDEL  = 0 AND IS_RELATION = 0 AND STATUS = 1 AND ID="+id;
        em.createNativeQuery(sql).executeUpdate();
    }

    @Transactional
    public void saveUser(Long id) {
        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO USER_SYSTEM_NOTIFICATION\n");
        sql.append("SELECT SEQ_USER_SYSTEM_NOTIFICATION.NEXTVAL," + id + ",0,USER_ID,0\n");
        sql.append("FROM ACCOUNT");
        em.createNativeQuery(sql.toString()).executeUpdate();
        //关联标志设置
        setRelation(id);
    }
}
