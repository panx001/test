package com.cscs.portal.services.impl;

import com.cscs.portal.dto.AccountQueryInData;
import com.cscs.portal.dto.AccountQueryInfoData;
import com.cscs.portal.entity.UserBasicinfo;
import com.cscs.portal.services.AccountQueryServices;
import com.cscs.portal.services.AccountRoleXwServices;
import com.cscs.portal.services.AccountServices;
import com.cscs.portal.services.UserBasicInfoServices;
import com.cscs.repository.AccountRepository;
import com.cscs.repository.UserBasicinfoRepository;
import com.cscs.util.StringUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

/**
 * Created by dch on 2016/11/14.
 */
@SuppressWarnings("JpaQlInspection")
@Service
public class AccountQueryServicesImpl implements AccountQueryServices {

    @Autowired
    private AccountServices accountServices;

    @Autowired
    AccountRoleXwServices accountRoleXwServices;

    //账号
    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private UserBasicinfoRepository userBasicinfoRepository;
    
    @Autowired
    private UserBasicInfoServices userBasicInfoServices; 

    @PersistenceContext
    EntityManager em;

    //账户查询(条数)
    @Override
    public int findAccountCount(AccountQueryInfoData inData) {
        String sql = "SELECT COUNT(1) FROM user_basicinfo A\n" +
                "WHERE 1=1\n";
        if (!StringUtils.isEmpty(inData.getAccountNm())) {
            sql += "AND A.ACCOUNT_NM like ?1\n";
        }
        if (!StringUtils.isEmpty(inData.getStartDtString())) {
            sql += "AND TO_CHAR(A.REGEDIT_DT, 'yyyy-MM-dd') >= ?2\n";
        }
        if (!StringUtils.isEmpty(inData.getEndDtString())) {
            sql += "AND TO_CHAR(A.REGEDIT_DT, 'yyyy-MM-dd') <= ?3\n";
        }
        Query query = em.createNativeQuery(sql);
        if (!StringUtils.isEmpty(inData.getAccountNm())) {
            query.setParameter(1, "%" + inData.getAccountNm() + "%");
        }
        if (!StringUtils.isEmpty(inData.getStartDtString())) {
            query.setParameter(2, inData.getStartDtString());
        }
        if (!StringUtils.isEmpty(inData.getEndDtString())) {
            query.setParameter(3, inData.getEndDtString());
        }
        return Integer.valueOf(query.getSingleResult().toString());
    }

    //根据用户名或帐户Id查询帐户信息
    @Override
    public List<Object> findAccountAll(AccountQueryInfoData inData) {
        int page = inData.getPage() == 0 ? 0 : inData.getPage() - 1;
        int pageSize = inData.getPageSize() == 0 ? 10 : inData.getPageSize();
        String sql = "SELECT A.ACCOUNT_NM, A.REGEDIT_DT,B.ROLE_NM,A.user_id \n" +
                "FROM user_basicinfo A LEFT JOIN ACCOUNT_ROLE_XW D ON A.user_id = D.ACCOUNT_ID\n" +
                "left JOIN \"ROLE\" B ON B.ROLE_ID = D.ROLE_ID\n" +
                "WHERE 1=1\n";
        if (!StringUtils.isEmpty(inData.getAccountNm())) {
            sql += "AND A.ACCOUNT_NM like ?1\n";
        }
        if (!StringUtils.isEmpty(inData.getStartDtString())) {
            sql += "AND TO_CHAR(A.REGEDIT_DT, 'yyyy-MM-dd') >= ?2\n";
        }
        if (!StringUtils.isEmpty(inData.getEndDtString())) {
            sql += "AND TO_CHAR(A.REGEDIT_DT, 'yyyy-MM-dd') <= ?3\n";
        }
        sql += "ORDER BY A.REGEDIT_DT DESC";
        Query query = em.createNativeQuery(sql);

        if (!StringUtils.isEmpty(inData.getAccountNm())) {
            query.setParameter(1, "%" + inData.getAccountNm() + "%");
        }
        if (!StringUtils.isEmpty(inData.getStartDtString())) {
            query.setParameter(2, inData.getStartDtString());
        }
        if (!StringUtils.isEmpty(inData.getEndDtString())) {
            query.setParameter(3, inData.getEndDtString());
        }
        query.setFirstResult(page * pageSize);
        query.setMaxResults(pageSize);
        return query.getResultList();
    }

    @Override
    @Transactional
    public int saveAccount(AccountQueryInData inData) {
    	  //获取userid
    	
        //Long userId = userBasicInfoServices.generatedValue();
        //用户信息
        UserBasicinfo userInfo = new UserBasicinfo();
        userInfo.setUserNm(inData.getAccountNm());
        Date date = new Date();
        userInfo.setUpdtDt(new Timestamp(date.getTime()));
        userInfo.setEmail(inData.getEmail());
        userInfo.setCompanyNm(inData.getCompanyNm());
        
        userInfo.setAccountPw(inData.getAccountPw());
        userInfo.setAccountNm(inData.getAccountNm());
        userInfo.setRegeditDt(date);
        userInfo.setCreateDt(date);
        userInfo.setRegeditType(0L);
//        userInfo.setUserId(userId);
//        userInfo.setCreateBy(userId);
//        userInfo.setUpdtBy(userId);
        userInfo.setActivityType(0L);;
        
        userInfo = this.saveBasic(userInfo);

//        Account account = new Account();
//        account.setAccountNm(inData.getAccountNm());
//        account.setActivityType(0L);
//        account.setAccountPw(inData.getAccountPw());
//        account.setUserId(userInfo.getUserId());
//        account.setUpdtDt(new Timestamp(new Date().getTime()));
//        account.setUpdtBy(userInfo.getUserId());
//        account = this.saveAccount(account);

        accountRoleXwServices.setAccountRoleXw(userInfo.getUserId(), inData.getRoleNm());
        return 0;
    }

    
    @Override
    @Transactional
    public int updateAccount(AccountQueryInData inData) {
    	  //获取userid
    	if(!StringUtil.isEmpty(inData.getAccountPw())) {
    		Query query = em.createQuery("update UserBasicinfo as p set p.accountPw =?1,p.updtDt=sysdate,p.updtBy=?2 where p.userId=?3");
            query.setParameter(1, inData.getAccountPw());
            query.setParameter(2, inData.getUserId());
            query.setParameter(3, inData.getUserId());
            query.executeUpdate();
    	}

        accountRoleXwServices.updateAccountRoleXw(inData.getUserId(), inData.getRoleNm());
        return 0;
    }
    
    
    
    @Override
    public int findByAccountNm(String accountNm) {
        //Account account = accountServices.findByAccountNm(accountNm);
    	UserBasicinfo account =  userBasicInfoServices.findByAccountNm(accountNm);
        if (account == null) return 0;
        return 1;
    }

    @Override
    @Transactional
    public UserBasicinfo saveBasic(UserBasicinfo info) {
        return userBasicinfoRepository.save(info);
    }

//    @Override
//    @Transactional
//    public Account saveAccount(Account info) {
//        return accountRepository.save(info);
//    }

    @Override
    @Transactional
    public void updateUserPwd(String accountNm, String pwd) {
        //accountServices.updateUserPwd(accountNm, pwd);
        userBasicInfoServices.updateUserPwd(accountNm, pwd);
    }

    @Override
    public List<Object> findAccountAllNoPaging(AccountQueryInfoData inData) {
        String sql = "SELECT A.ACCOUNT_NM,nvl(A.USER_NM,A.Account_Nm),A.COMPANY_NM, A.REGEDIT_DT " +
                "FROM user_basicinfo A order by A.Regedit_Dt desc";

        /*if (!StringUtils.isEmpty(inData.getAccountNm())) {
            sql += "AND A.ACCOUNT_NM like ?1\n";
        }
        if (!StringUtils.isEmpty(inData.getStartDtString())) {
            sql += "AND TO_CHAR(A.REGEDIT_DT, 'yyyy-MM-dd') >= ?2\n";
        }
        if (!StringUtils.isEmpty(inData.getEndDtString())) {
            sql += "AND TO_CHAR(A.REGEDIT_DT, 'yyyy-MM-dd') <= ?3\n";
        }*/
        Query query = em.createNativeQuery(sql);

        /*if (!StringUtils.isEmpty(inData.getAccountNm())) {
            query.setParameter(1, "%" + inData.getAccountNm() + "%");
        }
        if (!StringUtils.isEmpty(inData.getStartDtString())) {
            query.setParameter(2, inData.getStartDtString());
        }
        if (!StringUtils.isEmpty(inData.getEndDtString())) {
            query.setParameter(3, inData.getEndDtString());
        }*/
        return query.getResultList();
    }
}
