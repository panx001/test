package com.cscs.portal.services.impl;

import com.cscs.portal.dto.NewsWarningInData;
import com.cscs.portal.services.NewsWarningServices;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@SuppressWarnings("JpaQlInspection")
@Service
public class NewsWarningServicesImpl implements NewsWarningServices {

    @PersistenceContext
    EntityManager em;

    @Override
    public List<Object> findchart(NewsWarningInData inData) {
        String sqlWhere = "";
        String classify = "";
        if (inData.getTime() == 1) {
            sqlWhere = " AND POST_DT >= SYSDATE - 7 ";
            classify = " TO_CHAR(POST_DT,'YYYY-MM-DD')";
        } else if (inData.getTime() == 2) {
            sqlWhere = " AND POST_DT >= ADD_MONTHS(SYSDATE, -1)";
            classify = " TO_CHAR(POST_DT,'YYYY-MM-DD')";
        } else if (inData.getTime() == 3) {
            sqlWhere = " AND POST_DT >= ADD_MONTHS(SYSDATE, -3) ";
            classify = " TO_CHAR(POST_DT,'YYYY-IW')";
        } else if (inData.getTime() == 4) {
            sqlWhere = " AND POST_DT >= ADD_MONTHS(SYSDATE, -12) ";
            classify = " TO_CHAR(POST_DT,'YYYY-MM')";
        } else {
            sqlWhere = " AND POST_DT >= SYSDATE - 7";
            classify = " TO_CHAR(POST_DT,'YYYY-MM-DD')";
        }
        String sql = "SELECT CN1,CN2,A.POST_DT FROM(\n" +
                "   SELECT COUNT(1) CN1," + classify + " POST_DT FROM XW_NEWS_COMPANY B" +
                "   INNER JOIN NEWS_BASICINFO C ON C.NEWS_BASICINFO_SID = B.NEWS_BASICINFO_SID\n" +
                "   WHERE COMPANY_ID = " + inData.getCompyId() + " AND B.ISDEL = 0 AND (B.RELEVANCE > 0.01 OR B.IMPORTANCE > 0) " + sqlWhere + "\n" +
                "   GROUP BY " + classify + ")A\n" +
                "LEFT JOIN(\n" +
                "   SELECT COUNT(1) CN2," + classify + " POST_DT FROM XW_NEWS_COMPANY B " +
                "   INNER JOIN NEWS_BASICINFO C ON C.NEWS_BASICINFO_SID = B.NEWS_BASICINFO_SID\n" +
                "   WHERE COMPANY_ID = " + inData.getCompyId() + " AND B.SCORE < 0 AND B.ISDEL = 0 AND (B.RELEVANCE > 0.01 OR B.IMPORTANCE > 0)" + sqlWhere + "\n" +
                "   GROUP BY " + classify + ")B ON A.POST_DT = B.POST_DT \n" +
                "ORDER BY POST_DT DESC";
        return em.createNativeQuery(sql).getResultList();
    }

}
