package com.cscs.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONObject;

public class KylinAPI {

  private static final String BASIC_URL="http://10.100.49.110:7070/kylin/api";
  private static String auth;

  public static String post(String url,String postDataStr) throws Exception {

    HttpPost post = new HttpPost(url);
    RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(30 * 1000).build();
    requestConfig.isAuthenticationEnabled();
    HttpClient client = HttpClientBuilder.create().setDefaultRequestConfig(requestConfig).build();
    // add request header
    //request.addHeader("User-Agent", USER_AGENT);
    post.setHeader("Authorization","Basic " + auth);

    if (postDataStr.length() != 0) {
      StringEntity postData = new StringEntity(postDataStr, "utf-8");
      postData.setContentType("application/json;charset=UTF-8");

      post.setEntity(postData);
    }

    HttpResponse response = client.execute(post);
    System.out.println("Response Code : " + response.getStatusLine().getStatusCode());
    // HTTP 204 NO CONTENT, null pointer
    return readHttpResponse(response);

  }

  public static String readHttpResponse(HttpResponse response) throws Exception {

    BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
    StringBuffer result = new StringBuffer();
    String line = "";
    while ((line = rd.readLine()) != null) {
      result.append(line+"\n");
    }
    return result.toString();
  }

  public static void genAuth(String account,String pwd) {
    // Authorization data encoded by basic auth is needed in the header
    byte[] key = (account+":"+pwd).getBytes();
    auth = (new sun.misc.BASE64Encoder()).encode(key);
  }

  public static String query(String sql,int offset,int limit) throws Exception{
    genAuth("ANALYST","dwEQ8qpmdTbcOseUhOJbaw==");
    System.out.println(auth);
    String para = "/query";
    JSONObject jsonObject = new JSONObject();
    jsonObject.put("sql",sql);
    jsonObject.put("offset",offset);
    jsonObject.put("project","portal_cube");
    if(limit>0){
      jsonObject.put("limit",limit);
    }
    return post(BASIC_URL+para, jsonObject.toString());
  }

  public static void main(String[] args) throws Exception{
    //String sql="select bondtype,issue_dt,count(1) as 发行数量,sum(issue_vol) as 发行额(融资额) from (select distinct bondtype,industry,region,companytype,issue_dt,issue_vol from tmp_htable_bond_stat_kylin where issue_dt is not null) as a group by bondtype,issue_dt";
//    String sql="select bondtype,cash_dt, count(distinct secinner_id) as 还款债数, sum (pay_vol) as 还款额   from   tmp_htable_bond_stat_kylin where cash_dt is not null group by bondtype,cash_dt";
    String sql="select distinct companytype from tmp_htable_bond_stat_kylin";
    StringBuffer sb = new StringBuffer();
    sb.append("select industry,count(distinct secinner_id) as 违约量 ");
	sb.append("from ");
	sb.append("tmp_htable_bond_stat_kylin where viola_occurdt is not null and industry is not null and ");
	sb.append("viola_occurdt>='2017-10-29' ");
	sb.append("and ");
	sb.append("viola_occurdt<='2018-10-29' group by industry");
    String result =KylinAPI.query(sb.toString(),0,-1);
    System.out.println(sb.toString());
  }


}
