package com.cscs.portal.services;

import com.cscs.portal.dto.RoleInfoData;
import com.cscs.portal.entity.Role;

import java.util.List;

/**
 * Created by dch on 2016/11/7.
 * 角色接口
 */
public interface RoleServices {

    /**
     * 新增或者更新角色
     * @param roleInfoData
     */
    void save(RoleInfoData roleInfoData);

    /**
     * 删除角色
     * @param roleIdString
     */
    void deleteRole(String roleIdString);

    /**
     * 查询角色信息
     * @return
     */
    List<Role> findAll();

    /**
     * 查询角色信息
     * @param roleNm
     * @return
     */
    Role findOne(String roleNm);
}
