package com.cscs.portal.services;

import java.util.Set;

/**
 * Created by huchangchun on 2017/2/15.
 */
public interface CacheServices {
    /**
     * @param key
     * @return user short url对应的id集合
     */
    Set<String> getAccessRecord(String key);

    /**
     * 更新 user short url对应的id集合
     * @param key
     * @param set
     */
    void updateAccessRecord(String key, Set<String> set);

    void updateAuthRecord(String key, int count);

    int getAuthRecord(String key);

    void deleteUser(String userId);

    String getUser(String userId);

    void updateUser(String userId, String brower);

    void reload();

    /**
     * @return 城投平台公司ID集合
     */
    public Set<Long> getPlatformCompanyIds();

}
