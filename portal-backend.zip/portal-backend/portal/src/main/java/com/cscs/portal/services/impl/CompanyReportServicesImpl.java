package com.cscs.portal.services.impl;

import com.cscs.portal.services.CompanyReportServices;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by wang on 2016/8/24.
 */
@Service
public class CompanyReportServicesImpl implements CompanyReportServices {

    @PersistenceContext
    EntityManager em;

    @Override
    public List<Object> findColumnEnm(Long companyId, int subjectType, String tableName) {
        String sql = "SELECT LKP_FINANSUBJECT_DISP_SID, SUBJECT_CD, SUBJECT_NM, PARENT_SUBJECT_CD, SUBJECT_LEVEL, IS_LABEL, IS_BOLD, IS_FORMULAR,SUBJECT_ENM\n" +
                "FROM LKP_FINANSUBJECT_DISP L, \n" +
                "   (SELECT COMPANY_TYPE FROM " + tableName + " WHERE COMPANY_ID = " + companyId + " AND ISDEL = 0 AND rownum = 1) C  \n" +
                "WHERE L.COMPANY_TYPE = C.COMPANY_TYPE AND L.ISDEL = 0 AND L.SUBJECT_TYPE = " + subjectType + "\n" +
                "AND L.DISP_TYPE = 2 AND L.IS_FORMULAR = 0\n" +
                "ORDER BY LKP_FINANSUBJECT_DISP_SID";
        return em.createNativeQuery(sql).getResultList();
    }

    @Override
    public List<Object> findCompyReport(Long companyId, String rptDt, String isPublicRpt, String rptTimetypeCd, String combineTypeCd, String tableName, String strColumnEnm1) {
        String whereSql = checkCondition(combineTypeCd);
        String columnSql = "\n";
        if (!"0".equals(rptDt)) {
            int range = Integer.valueOf(rptDt) - 1;
            whereSql += " AND SUBSTR(RPT_DT, 1, 4) >= TO_CHAR(ADD_MONTHS(SYSDATE,-" + range * 12 + "), 'YYYY') \n";
        }

        String sql = "SElECT " + strColumnEnm1 + ",RPT_DT,DATA_AJUST_TYPE" + columnSql +
                "FROM " + tableName + "\n" +
                "WHERE COMPANY_ID = " + companyId + " AND RPT_TIMETYPE_CD IN (?1) AND IS_PUBLIC_RPT IN (?2)\n" +
                "AND ISDEL = 0 " + whereSql +
                "ORDER BY RPT_DT DESC,DATA_AJUST_TYPE DESC,COMBINE_TYPE_CD DESC";
        Query query = em.createNativeQuery(sql);
        query.setParameter(1, getList(rptTimetypeCd));
        query.setParameter(2, getList(isPublicRpt));
        return query.getResultList();
    }

    @Override
    public List<Object> findCompyFinanaudit(Long companyId, String rptDt) {
        String whereSql = "";
        if (!"0".equals(rptDt)) {
            int range = Integer.valueOf(rptDt) - 1;
            whereSql += " AND SUBSTR(RPT_DT, 7, 4) >= TO_CHAR(ADD_MONTHS(SYSDATE,-" + range * 12 + "), 'YYYY') \n";
        }
        String sql = "SELECT TO_CHAR(TO_DATE(SUBSTR(RPT_DT,1,10),'MM/DD/YYYY'),'YYYYMMDD'),B.CONSTANT_NM NAME1,C.CONSTANT_NM NAME2\n" +
                "FROM COMPY_FINANAUDIT A\n" +
                "LEFT JOIN LKP_CHARCODE B ON A.AUDIT_VIEW_TYPEID = B.CONSTANT_ID AND B.CONSTANT_TYPE = 35\n" +
                "LEFT JOIN LKP_CHARCODE C ON A.OAUDIT_VIEW_TYPEID = C.CONSTANT_ID AND C.CONSTANT_TYPE = 35\n" +
                "WHERE RPT_DT IS NOT NULL AND COMPANY_ID = " + companyId + whereSql;
        return em.createNativeQuery(sql).getResultList();
    }

    private String checkCondition(String combineTypeCd) {
        StringBuilder sql = new StringBuilder();
        String[] combineType = combineTypeCd.split(",");
        if (combineType.length == 4) {
            sql.append("AND COMBINE_TYPE_CD IN(1,2) AND DATA_AJUST_TYPE IN(2,3)\n");
            return sql.toString();
        }
        if (combineType.length == 3) {
            sql.append(" AND ( ");
            if (combineTypeCd.indexOf("1") > -1 && combineTypeCd.indexOf("3") > -1) {
                sql.append("(");
                sql.append(" COMBINE_TYPE_CD = 2 AND DATA_AJUST_TYPE IN(2,3)");
                sql.append(" ) OR ( ");
                if (combineTypeCd.indexOf("2") > -1) {
                    sql.append(" COMBINE_TYPE_CD = 1 AND DATA_AJUST_TYPE = 3");
                } else if (combineTypeCd.indexOf("4") > -1) {
                    sql.append(" COMBINE_TYPE_CD = 1 AND DATA_AJUST_TYPE = 2");
                }
                sql.append(")");
            } else if (combineTypeCd.indexOf("2") > -1 && combineTypeCd.indexOf("4") > -1) {
                sql.append("(");
                sql.append(" COMBINE_TYPE_CD = 1 AND DATA_AJUST_TYPE IN(2,3) ");
                sql.append(" ) OR ( ");
                if (combineTypeCd.indexOf("1") > -1) {
                    sql.append(" COMBINE_TYPE_CD = 2 AND DATA_AJUST_TYPE = 3");
                } else if (combineTypeCd.indexOf("3") > -1) {
                    sql.append(" COMBINE_TYPE_CD = 2 AND DATA_AJUST_TYPE = 2");
                }
                sql.append(")");
            }
            sql.append(" )\n");
        }
        if (combineType.length == 2) {
            if (combineTypeCd.indexOf("1") > -1 && combineTypeCd.indexOf("2") > -1) {
                sql.append(" AND COMBINE_TYPE_CD IN(1,2) AND DATA_AJUST_TYPE = 3 \n");
            } else if(combineTypeCd.indexOf("1") > -1 && combineTypeCd.indexOf("3") > -1) {
                sql.append(" AND COMBINE_TYPE_CD = 2 AND DATA_AJUST_TYPE IN(2,3) \n");
            } else if (combineTypeCd.indexOf("1") > -1 && combineTypeCd.indexOf("4") > -1) {
                sql.append(" AND ((");
                sql.append(" COMBINE_TYPE_CD = 2 AND DATA_AJUST_TYPE = 3");
                sql.append(" ) OR ( ");
                sql.append(" COMBINE_TYPE_CD = 1 AND DATA_AJUST_TYPE = 2");
                sql.append("))\n");
            } else if (combineTypeCd.indexOf("2") > -1 && combineTypeCd.indexOf("3") > -1) {
                sql.append(" AND ((");
                sql.append(" COMBINE_TYPE_CD = 1 AND DATA_AJUST_TYPE = 3");
                sql.append(" ) OR ( ");
                sql.append(" COMBINE_TYPE_CD = 2 AND DATA_AJUST_TYPE = 2");
                sql.append("))\n");
            } else if (combineTypeCd.indexOf("2") > -1 && combineTypeCd.indexOf("4") > -1) {
                sql.append(" AND COMBINE_TYPE_CD = 1 AND DATA_AJUST_TYPE IN(2,3) \n");
            } else if (combineTypeCd.indexOf("3") > -1 && combineTypeCd.indexOf("4") > -1) {
                sql.append(" AND COMBINE_TYPE_CD IN(1,2) AND DATA_AJUST_TYPE = 2 \n");
            }
        }
        if (combineType.length == 1) {
            if (combineTypeCd.indexOf("1") > -1) {
                sql.append(" AND COMBINE_TYPE_CD = 2 AND DATA_AJUST_TYPE = 3 \n");
            } else if (combineTypeCd.indexOf("2") > -1) {
                sql.append(" AND COMBINE_TYPE_CD = 1 AND DATA_AJUST_TYPE = 3 \n");
            } else if (combineTypeCd.indexOf("3") > -1) {
                sql.append(" AND COMBINE_TYPE_CD = 2 AND DATA_AJUST_TYPE = 2 \n");
            } else if (combineTypeCd.indexOf("4") > -1) {
                sql.append(" AND COMBINE_TYPE_CD = 1 AND DATA_AJUST_TYPE = 2 \n");
            }
        }
        return sql.toString();
    }

    private List<String> getList(String value) {
        String[] itemList = value.split(",");
        List<String> tmpList = new ArrayList<>();
        for (String tmp : itemList) {
            tmpList.add(tmp);
        }
        return tmpList;
    }
}