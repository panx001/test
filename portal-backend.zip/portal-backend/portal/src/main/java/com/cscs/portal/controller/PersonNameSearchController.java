package com.cscs.portal.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cscs.portal.dto.PersonNameSearchConditon;
import com.cscs.portal.dto.PersonNameSearchOut;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.util.Contants;
import com.cscs.util.SolrUtil;
import com.cscs.util.StringUtil;

/***
 * 
 * @ClassName: PersonNameSearchController
 * @Description: 人名搜索
 * @author: liunn
 * @date: 2018年10月21日 下午6:08:22
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/person/search")
public class PersonNameSearchController {
	protected final Log logger = LogFactory.getLog(this.getClass());
	
	@Autowired
    private StringRedisTemplate rt;

    /**
     * 
     * @Title: getResult
     * @Description: 人名搜索
     * @param condition
     * @return
     * @return: Object
     */
    @RequestMapping(value = "/getResult", method = RequestMethod.POST)
    public Object getResult(@RequestBody PersonNameSearchConditon condition){
    	BaseOutData outData = new BaseOutData();
    	List<PersonNameSearchOut> returnList = new ArrayList<PersonNameSearchOut>();
    	Set set = new HashSet();
    	long numFound = 0L;
    	try {
    		//创建Solr服务对象，通过此对象向solr服务发起请求
    		SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_PERSON_METHOD);
    		//创建查询对象
    		SolrQuery query = new SolrQuery();
    		//查询关键字，q不能省略
    		if(StringUtils.isNotEmpty(condition.getKeyword())) {
    			query.set("q","person:\""+condition.getKeyword()+"\"");
    		}else {
    			query.set("q","*:*");
    		}
    		//只查询存活的分片
    		query.set("shards.tolerant", "true");
    		
    		//排序
    		//参数：field域，排序类型（asc,desc）score desc,regcapital desc
    		query.addSort("score", SolrQuery.ORDER.desc);
    		query.addSort("person_pinyin", SolrQuery.ORDER.asc);
    		//分页
    		//实际开发时，知道当前页码和每页显示的个数最后求出开始下标
    		int curPage = condition.getCurPage()==null?1:condition.getCurPage();
    		int rows = condition.getRowNum()==null?10:condition.getRowNum();
    		//计算出开始记录下标
    		int start = rows * (curPage - 1);
    		//向query中设置分页参数
    		query.setStart(start);
    		query.setRows(rows);
    		//开启高亮
    		query.setHighlight(true);
    		//设置高亮 参数
    		query.addHighlightField("person");
    		//设置高亮前缀和后缀
    		query.setHighlightSimplePre("<span class=\"highlight\">");
    		query.setHighlightSimplePost("</span>");
    		
    		//执行查询
    		QueryResponse response = solrServer.query(query);
    		//从响应中得到结果
    		SolrDocumentList documents = response.getResults();
    		
    		//匹配到的总记录数
    		numFound = documents.getNumFound();
    		logger.info("匹配到的总记录数："+numFound);
    		
    		
    		for (SolrDocument document:documents){
    			PersonNameSearchOut data = new PersonNameSearchOut();
    			if(null != document.get("id")) {
    				data.setId(StringUtil.removeAllBlank(String.valueOf(document.get("id"))));
    			}
    			String person = "";
    			if(null != document.get("person")) {
    				person = StringUtil.removeAllBlank(String.valueOf(document.get("person")));
    				data.setPerson(person);
    			}
    			//去重
    			if (set.add(data.getPerson())) {
    				//从响应中获得高亮信息
    				Map<String, Map<String, List<String>>> highlighting = response.getHighlighting();
    				//获得高亮的信息
    				if(highlighting!=null){
    					//根据主键获取高亮信息
    					Map<String, List<String>> map = highlighting.get(document.get("id"));
    					if(map!=null){
    						List<String> personList = map.get("person");
    						if(personList!=null){
    							person = StringUtil.trim(personList.get(0));
    							data.setPerson(person);
    						}
    					}
    				}
    				returnList.add(data);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        Map data = new HashMap();
        data.put("result", returnList);
        outData.setCode("0");
        outData.setCount((int)numFound);
        outData.setMessage("返回成功!");
        outData.setData(data);
    	return outData;
    }
    
}
