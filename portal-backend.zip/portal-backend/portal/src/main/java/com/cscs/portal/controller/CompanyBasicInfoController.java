package com.cscs.portal.controller;

import com.alibaba.fastjson.JSON;
import com.cscs.portal.dto.ChangeRecord;
import com.cscs.portal.dto.Holding;
import com.cscs.portal.dto.Investment;
import com.cscs.portal.dto.ManageLevel;
import com.cscs.portal.dto.ShareHolder;
import com.cscs.portal.dto.SharehdInvest;
import com.cscs.portal.dto.SharehdInvestnb;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.util.Contants;
import com.cscs.util.HttpUtil;
import com.cscs.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.text.MessageFormat;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 企业基础信息
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/company/basic")
public class CompanyBasicInfoController {

    //工商信息
    public static String COMPANY_BASICINFO = "c_basicinfo";
    //风险提示
    public static String COMPANY_RISK = "c_risk";
    //管理层
    public static String COMPANY_MANAGELEVEL = "c_manage";
    //管理层-对外投资对外任职
    public static String COMPANY_LPPOSITIONINVEST = "c_lppositioninvest";
    //股东信息-发起人股东
    public static String COMPY_SHAREHDINVEST = "c_sharehdinvest";
    //股东信息-十大股东
    public static String COMPY_SHAREHOLDER = "c_shareholder";
    //股东信息-年报披露股东及出资信息
    public static String COMPY_SHAREHDINVESTNB = "c_sharehdinvestnb";
    //对外投资-对外投资企业
    public static String COMPANY_INVESTMENT = "c_investment";
    //变更记录
    public static String COMPANY_COMPYCHANGE = "c_change";
    //对外投资-参控企业
    public static String COMPANY_HOLDINGS = "c_holdings";
    //分支机构
    public static String COMPANY_BRANCH = "c_branch";

    @Autowired
    private StringRedisTemplate rt;


    @RequestMapping(value = "/getIdentifier/{companyName}", method = RequestMethod.GET)
    public BaseOutData getIdentifier(@PathVariable String companyName) {
        BaseOutData outData = new BaseOutData();
        String id = "";
        try {
            Object res = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANYID_FROM_NAME_URL, companyName));
            id = res == null ? "" : res.toString();
            if (StringUtil.isEmpty(id) || id.equals("Not found\r\n")) {
                id = "";
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", id);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 工商信息
     *
     * @param companyId
     * @return Object
     */
    @RequestMapping(value = "/info/{companyId}", method = RequestMethod.GET)
    public BaseOutData getBasicInfo(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_BASICINFO + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_BASICINFO_URL, companyId));
                if(out!=null) {
                	rt.opsForValue().set(COMPANY_BASICINFO + companyId, out.toString());
                	rt.expire(COMPANY_BASICINFO + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 风险提示
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/riskTip/{companyId}", method = RequestMethod.GET)
    public BaseOutData getRiskTip(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_RISK + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_URL, companyId));
                if(out!=null) {
                	rt.opsForValue().set(COMPANY_RISK + companyId, out.toString());
                	rt.expire(COMPANY_RISK + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 管理层
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/manager/{companyId}", method = RequestMethod.GET)
    public BaseOutData getManageLevel(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        List<ManageLevel> manageLevelList=null;
        try {
            out = rt.opsForValue().get(COMPANY_MANAGELEVEL + companyId);
            if (out == null) {
                 out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_MANAGELEVEL_URL, companyId));
                 
                 if(out!=null) {
                	 manageLevelList = (List<ManageLevel>) JSON.parseArray(String.valueOf(out), ManageLevel.class);
                	 Collections.sort(manageLevelList); 
                	 out = JSON.toJSONString(manageLevelList);
                	 rt.opsForValue().set(COMPANY_MANAGELEVEL + companyId, String.valueOf(out));
                	 rt.expire(COMPANY_MANAGELEVEL + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 管理层对外投资对外任职
     *
     * @param companyId
     * @return
     */
    //@RequestMapping(value = "/manageLL/{companyId}/{name}", method = RequestMethod.GET)
    @RequestMapping(value = "/manageLL/{companyId}", method = RequestMethod.GET)
    public BaseOutData getManageLL(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_LPPOSITIONINVEST + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_LPPOSITION_LPINVEST_URL, companyId));
                if(out!=null) {
                	rt.opsForValue().set(COMPANY_LPPOSITIONINVEST + companyId, out.toString());
                	rt.expire(COMPANY_LPPOSITIONINVEST + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 股东信息-发起人股东
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/investorSharehd/{companyId}", method = RequestMethod.GET)
    public BaseOutData getSharehd(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        List<SharehdInvest> sharehdInvestrList= null;
        try {
            out = rt.opsForValue().get(COMPY_SHAREHDINVEST + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_SHAREHDINVEST_URL, companyId));
                if(out!=null) {
                	sharehdInvestrList = (List<SharehdInvest>) JSON.parseArray(String.valueOf(out), SharehdInvest.class);
                	Collections.sort(sharehdInvestrList);
                	out = JSON.toJSONString(sharehdInvestrList);
                	rt.opsForValue().set(COMPY_SHAREHDINVEST + companyId,out.toString());
                	rt.expire(COMPY_SHAREHDINVEST + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 股东信息-十大股东
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/top10sharehd/{companyId}", method = RequestMethod.GET)
    public BaseOutData getTop10sharehd(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        List<ShareHolder> shareHolderList = null;
        try {
            out = rt.opsForValue().get(COMPY_SHAREHOLDER + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_SHAREHOLDER_URL, companyId));
                
                if(out!=null) {
                	shareHolderList = (List<ShareHolder>) JSON.parseArray(String.valueOf(out), ShareHolder.class);
                	
                	Collections.sort(shareHolderList);
                	for (ShareHolder shareHolder : shareHolderList) {
                		Collections.sort(shareHolder.getSharehdList());
					}
                	 out = JSON.toJSONString(shareHolderList);
                	rt.opsForValue().set(COMPY_SHAREHOLDER + companyId, out.toString());
                	rt.expire(COMPY_SHAREHOLDER + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 股东信息-企业自主公示股东及出资信息
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/compySharehd/{companyId}", method = RequestMethod.GET)
    public BaseOutData getCompySharehd(@PathVariable String companyId) {
        BaseOutData out = new BaseOutData();

//        Map<String, Object> re = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_LPPOSITION_LPINVEST_URL, companyId));
//        out.setData(re);
        out.setCode("0");
        return out;
    }

    /**
     * 股东信息-年报披露股东及出资信息
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/reportSharehd/{companyId}", method = RequestMethod.GET)
    public Object getReportSharehd(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        List<SharehdInvestnb> sharehdInvestnbList = null;
        try {
            out = rt.opsForValue().get(COMPY_SHAREHDINVESTNB + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_SHAREHDINVESTNB_URL, companyId));
                if(out!=null) {
                	sharehdInvestnbList = (List<SharehdInvestnb>) JSON.parseArray(String.valueOf(out), SharehdInvestnb.class);
                	Collections.sort(sharehdInvestnbList);
                	for (SharehdInvestnb sharehdInvestnb : sharehdInvestnbList) {
                		Collections.sort(sharehdInvestnb.getSharehdList());
					}
                	out = JSON.toJSONString(sharehdInvestnbList);
                	rt.opsForValue().set(COMPY_SHAREHDINVESTNB + companyId,out.toString());
                	rt.expire(COMPY_SHAREHDINVESTNB + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }
    
    /**
     * 对外投资-对外投资企业
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/investment/{companyId}", method = RequestMethod.GET)
    public BaseOutData getInvestment(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        List<Investment> investmentList = null;
        try {
            out = rt.opsForValue().get(COMPANY_INVESTMENT + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_INVESTMENT_URL, companyId));
                if(out!=null) {
                	investmentList = (List<Investment>) JSON.parseArray(String.valueOf(out), Investment.class);
                	Collections.sort(investmentList);
                	out = JSON.toJSONString(investmentList);
                	rt.opsForValue().set(COMPANY_INVESTMENT + companyId, out.toString());
                	rt.expire(COMPANY_INVESTMENT + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 对外投资-参控企业
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/holding/{companyId}", method = RequestMethod.GET)
    public BaseOutData getHolding(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        List<Holding> holdingList = null;
        try {
            out = rt.opsForValue().get(COMPANY_HOLDINGS + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_HOLDINGS_URL, companyId));
                if(out!=null) {
                	holdingList = (List<Holding>) JSON.parseArray(String.valueOf(out), Holding.class);
                	Collections.sort(holdingList);
                	out = JSON.toJSONString(holdingList);
                	rt.opsForValue().set(COMPANY_HOLDINGS + companyId,out.toString());
                	rt.expire(COMPANY_HOLDINGS + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 分支机构
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/branch/{companyId}", method = RequestMethod.GET)
    public BaseOutData getBranch(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_BRANCH + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_BRANCH_URL, companyId));
                if(out!=null) {
                	rt.opsForValue().set(COMPANY_BRANCH + companyId,out.toString());
                	rt.expire(COMPANY_BRANCH + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

//    /**
//     * 疑似/实际控制人
//     *
//     * @param companyId
//     * @return
//     */
//    @RequestMapping(value = "/actualController/{companyId}", method = RequestMethod.GET)
//    public BaseOutData getActualController(@PathVariable String companyId) {
//        BaseOutData out = new BaseOutData();
////        Map<String, Object> re = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_LPPOSITION_LPINVEST_URL, companyId));
////        out.setData(re);
//        out.setCode("0");
//        return out;
//    }

    /**
     * 变更记录
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/compyChange/{companyId}", method = RequestMethod.GET)
    public BaseOutData getCompyChange(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        List<ChangeRecord> changeRecordList = null;
        try {
            out = rt.opsForValue().get(COMPANY_COMPYCHANGE + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_COMPYCHANGE_URL, companyId));
                if(out!=null) {
                	changeRecordList = (List<ChangeRecord>) JSON.parseArray(String.valueOf(out), ChangeRecord.class);
                	Collections.sort(changeRecordList);
                	out = JSON.toJSONString(changeRecordList);
                	rt.opsForValue().set(COMPANY_COMPYCHANGE + companyId, out.toString() );
                	rt.expire(COMPANY_COMPYCHANGE + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }
}
