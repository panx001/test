package com.cscs.portal.dto;

import java.io.File;
import java.util.List;
import java.util.Map;

/**
 * Created by sh on 2016/8/7.
 */
public class CompanyTopicsInfoData {
    private long id;
    private String name;
    private String snapshot;
    private Long priority;
    private String summary;
    private String pic;
    private Long status;
    private List<CompanyTopicsCInfoData> cInfo;
    
    //相关公司详细信息
    private List<Map<String,Object>> companyDetailInfos;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSnapshot() {
        return snapshot;
    }

    public void setSnapshot(String snapshot) {
        this.snapshot = snapshot;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public Long getPriority() {
        return priority;
    }

    public void setPriority(Long priority) {
        this.priority = priority;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public Long getStatus() {
        return status;
    }

    public void setStatus(Long status) {
        this.status = status;
    }

    public List<CompanyTopicsCInfoData> getcInfo() {
        return cInfo;
    }

    public void setcInfo(List<CompanyTopicsCInfoData> cInfo) {
        this.cInfo = cInfo;
    }

	public List<Map<String, Object>> getCompanyDetailInfos() {
		return companyDetailInfos;
	}

	public void setCompanyDetailInfos(List<Map<String, Object>> companyDetailInfos) {
		this.companyDetailInfos = companyDetailInfos;
	}
    
    
}
