package com.cscs.portal.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cscs.portal.dto.UserTraceInfoData;
import com.cscs.portal.dto.UserTraceOutData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.services.UserTraceServices;
import com.cscs.util.DateUtils;

/**
 * Created by dch on 2016/11/14.
 * 用户跟踪信息
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/userTrace")
public class UserTraceController {
    @Autowired
    UserTraceServices userTraceServices;

    /**
     * 查询用户跟踪信息数量
     * @param userTraceInfoData
     * @return
     */

    @RequestMapping(value = "/findUserTraceCount", method = RequestMethod.POST)
    public BaseOutData FindUserTraceCount(@RequestBody UserTraceInfoData userTraceInfoData) {
        BaseOutData outData = new BaseOutData();
        String accountNm = userTraceInfoData.getAccountNm();
        String startDtString = userTraceInfoData.getStartDtString();
        String endDtString = userTraceInfoData.getEndDtString();
        int count = userTraceServices.findUserTraceCount(accountNm,startDtString,endDtString);
        outData.setCount(count);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        return outData;
    }

    /**
     * 查询用户跟踪信息
     * @param userTraceInfoData
     * @return
     */
    @RequestMapping(value = "/findUserTrace", method = RequestMethod.POST)
    public BaseOutData FindUserTrace(@RequestBody UserTraceInfoData userTraceInfoData) {
        String accountNm = userTraceInfoData.getAccountNm();
        String startDtString = userTraceInfoData.getStartDtString();
        String endDtString = userTraceInfoData.getEndDtString();
        int page = userTraceInfoData.getPage();
        int pageSize = userTraceInfoData.getPageSize();

        BaseOutData out = new BaseOutData();

        List<UserTraceOutData> userTraceList = new ArrayList<>();

        List<Object> itemList = userTraceServices.findUserTrace(accountNm, startDtString, endDtString, page, pageSize);;
        for(int i = 0; i< itemList.size();i++){
            Object[] item = (Object[]) itemList.get(i);
            UserTraceOutData outData = new UserTraceOutData();
            outData.setAccountNm(item[0] != null ? item[0].toString() :"");
            outData.setVisitUrl(item[1] != null ? item[1].toString() :"");
            outData.setVisitDt(item[2] != null ? item[2].toString() :"");
            outData.setVisitStopDt(item[3] != null ? item[3].toString() :"");
            userTraceList.add(outData);
        }
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("result", userTraceList);
        out.setData(map);
        out.setCode("0");
        return out;
    }
    
    /**
     * 访问记录生成
     *
     * @return
     */
    @RequestMapping(value = "/visitRecord", method = RequestMethod.POST)
    public BaseOutData visitRecord(@RequestBody UserTraceInfoData userTraceInfoData, HttpServletRequest request, HttpServletResponse response) throws Exception {
        BaseOutData out = new BaseOutData();
        try {
            List<Object> visitRecordList = userTraceServices.visitRecord(userTraceInfoData);
            HSSFWorkbook wb = new HSSFWorkbook();
            HSSFSheet sheet = wb.createSheet(DateUtils.getCurrentDate());
            // 3.在sheet中添加表头第0行，老版本poi对excel行数列数有限制short
            HSSFRow row = sheet.createRow((int) 0);
            // 4.创建单元格，设置值表头，设置表头居中
            HSSFCellStyle style = wb.createCellStyle();
            // 居中格式
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            // 设置表头
            HSSFCell cell = row.createCell(0);
            cell.setCellValue("访问URL");
            cell.setCellStyle(style);

            cell = row.createCell(1);
            cell.setCellValue("功能名称");
            cell.setCellStyle(style);

            cell = row.createCell(2);
            cell.setCellValue("访问次数");
            cell.setCellStyle(style);


            response.setContentType("application/vnd.ms-excel");
            response.setHeader("Content-disposition", "attachment;filename=" + URLEncoder.encode("访问记录统计表", "UTF-8") + ".xls");


            // 循环将数据写入Excel
            for (int i = 0; i < visitRecordList.size(); i++) {
                row = sheet.createRow((int) i + 1);
                // 创建单元格，设置值
                Object[] item = (Object[]) visitRecordList.get(i);
                row.createCell(0).setCellValue(item[0].toString());
                row.createCell(1).setCellValue(item[1].toString());
                row.createCell(2).setCellValue(item[2].toString());
            }

            String filepath = getClass().getClassLoader().getResource("").getPath() + "/templates/";
            File file = new File(filepath + "访问记录统计表.xls");
            OutputStream ouputStream = new FileOutputStream(file);
            wb.write(ouputStream);
            ouputStream.flush();
            ouputStream.close();
            //确定文件存在
            if (file.exists()) {//判断文件是否存在
                if (file.isFile()) {//判断是否是文件
                    out.setCode("0");
                    out.setMessage("visitRecordDownload");
                }
            }
        } catch (Exception ex) {
            out.setCode("1");
            out.setMessage("导出失败！！"+ex.getMessage());
        }
        return out;
    }

    /**
     * 访问记录下载
     */
    @RequestMapping(value = "/visitRecordDownload", method = RequestMethod.GET)
    public void visitRecordDownload(HttpServletResponse response) throws Exception {
        File file = null;
        InputStream fis = null;
        ServletOutputStream out = null;

        try {
            String filepath = getClass().getClassLoader().getResource("").getPath() + "/templates/";
            String fileName = "访问记录统计表.xls".toString(); // 文件的默认保存名
            file = new File(filepath + fileName);

            // 读到流中
            fis = new FileInputStream(file);// 文件的存放路径

            // 设置输出的格式
            response.reset();

            response.setContentType("application/vnd.ms-excel");

            response.setHeader("Content-disposition", "attachment;filename=" + URLEncoder.encode("访问记录统计表", "UTF-8") + ".xls");
            response.setHeader("Access-Control-Allow-Origin", "*");

            out = response.getOutputStream();

            // 循环取出流中的数据
            int len;
            byte[] buffer = new byte[512];

            while ((len = fis.read(buffer)) > 0) {
                out.write(buffer, 0, len);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) fis.close();
            if (out != null) out.close();
            if (file != null) file.delete();
        }
    }
}
