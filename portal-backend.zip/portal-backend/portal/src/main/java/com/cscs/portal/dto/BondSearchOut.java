package com.cscs.portal.dto;

import java.util.List;

/**
 * 
 * @ClassName: BondSearchOut
 * @Description: 发债企业高级搜索返回数据
 * @author: liunn
 * @date: 2018年9月15日 下午10:42:00
 */
public class BondSearchOut{
	//企业id
	private String companyId;
	//企业名称
	private String companyNm;
	//企业状态
	private String companySt;
	//评级机构
	private String creditOrgNm;
	//之前的评级
	private String ratingPrev;
	//现在的评级
	private String ratingCurrent;
	//之前的评级时间
	private String ratingDtPrev;
	//现在的评级时间
	private String ratingDtCurrent;
	//审计意见
	private String financeAudit;
	//之前的评级展望
	private String ratingFwdPrev;
	//现在的评级展望
	private String ratingFwdCurrent;
	//企业类型
	private String companyType;
	//成立时间
	private String foundDt;
	//总经理
	private String gmanager;
	//是否三板 0:非三板 1新三板 2老三版
	private String islist3;
	//上市代码
	private List securityCd;
	//重要财务指标不利变化
	private List financeFactor;
	//主体评级
	private List creditChg;
	//是否发债 0:false 1:true
	private String isbond;
	//行业
	private String industry;
	//法定代表人
	private String legalPersonNm;
	//是否私募企业 0:false 1:true
	private String ispfund;
	//社会信用代码
	private String creditCd;
	//注册资本
	private String regcapital;
	//董事长
	private String chairman;
	//发债类型
	private List bondType;
	//注册地
	private String regRegion;
	//是否上市企业 0:false 1:true
	private String islist;
	//证券简称
	private String securitySnm;
	//投资等级
	private String bondLevel;
	//高亮字段
	private List highlightColumns;
	
	
	
	public String getBondLevel() {
		return bondLevel;
	}
	public void setBondLevel(String bondLevel) {
		this.bondLevel = bondLevel;
	}
	public String getSecuritySnm() {
		return securitySnm;
	}
	public void setSecuritySnm(String securitySnm) {
		this.securitySnm = securitySnm;
	}
	public List getHighlightColumns() {
		return highlightColumns;
	}
	public void setHighlightColumns(List highlightColumns) {
		this.highlightColumns = highlightColumns;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getCompanyNm() {
		return companyNm;
	}
	public void setCompanyNm(String companyNm) {
		this.companyNm = companyNm;
	}
	public String getCompanySt() {
		return companySt;
	}
	public void setCompanySt(String companySt) {
		this.companySt = companySt;
	}
	public String getCreditOrgNm() {
		return creditOrgNm;
	}
	public void setCreditOrgNm(String creditOrgNm) {
		this.creditOrgNm = creditOrgNm;
	}
	public String getRatingPrev() {
		return ratingPrev;
	}
	public void setRatingPrev(String ratingPrev) {
		this.ratingPrev = ratingPrev;
	}
	public String getRatingCurrent() {
		return ratingCurrent;
	}
	public void setRatingCurrent(String ratingCurrent) {
		this.ratingCurrent = ratingCurrent;
	}
	public String getRatingDtPrev() {
		return ratingDtPrev;
	}
	public void setRatingDtPrev(String ratingDtPrev) {
		this.ratingDtPrev = ratingDtPrev;
	}
	public String getRatingDtCurrent() {
		return ratingDtCurrent;
	}
	public void setRatingDtCurrent(String ratingDtCurrent) {
		this.ratingDtCurrent = ratingDtCurrent;
	}
	
	public String getFinanceAudit() {
		return financeAudit;
	}
	public void setFinanceAudit(String financeAudit) {
		this.financeAudit = financeAudit;
	}
	public String getRatingFwdPrev() {
		return ratingFwdPrev;
	}
	public void setRatingFwdPrev(String ratingFwdPrev) {
		this.ratingFwdPrev = ratingFwdPrev;
	}
	public String getRatingFwdCurrent() {
		return ratingFwdCurrent;
	}
	public void setRatingFwdCurrent(String ratingFwdCurrent) {
		this.ratingFwdCurrent = ratingFwdCurrent;
	}
	public String getCompanyType() {
		return companyType;
	}
	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}
	public String getFoundDt() {
		return foundDt;
	}
	public void setFoundDt(String foundDt) {
		this.foundDt = foundDt;
	}
	public String getGmanager() {
		return gmanager;
	}
	public void setGmanager(String gmanager) {
		this.gmanager = gmanager;
	}
	public String getIslist3() {
		return islist3;
	}
	public void setIslist3(String islist3) {
		this.islist3 = islist3;
	}
	public List getSecurityCd() {
		return securityCd;
	}
	public void setSecurityCd(List securityCd) {
		this.securityCd = securityCd;
	}
	public List getFinanceFactor() {
		return financeFactor;
	}
	public void setFinanceFactor(List financeFactor) {
		this.financeFactor = financeFactor;
	}
	public List getCreditChg() {
		return creditChg;
	}
	public void setCreditChg(List creditChg) {
		this.creditChg = creditChg;
	}
	public String getIsbond() {
		return isbond;
	}
	public void setIsbond(String isbond) {
		this.isbond = isbond;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getLegalPersonNm() {
		return legalPersonNm;
	}
	public void setLegalPersonNm(String legalPersonNm) {
		this.legalPersonNm = legalPersonNm;
	}
	public String getIspfund() {
		return ispfund;
	}
	public void setIspfund(String ispfund) {
		this.ispfund = ispfund;
	}
	public String getCreditCd() {
		return creditCd;
	}
	public void setCreditCd(String creditCd) {
		this.creditCd = creditCd;
	}
	public String getRegcapital() {
		return regcapital;
	}
	public void setRegcapital(String regcapital) {
		this.regcapital = regcapital;
	}
	public String getChairman() {
		return chairman;
	}
	public void setChairman(String chairman) {
		this.chairman = chairman;
	}
	public List getBondType() {
		return bondType;
	}
	public void setBondType(List bondType) {
		this.bondType = bondType;
	}
	public String getRegRegion() {
		return regRegion;
	}
	public void setRegRegion(String regRegion) {
		this.regRegion = regRegion;
	}
	public String getIslist() {
		return islist;
	}
	public void setIslist(String islist) {
		this.islist = islist;
	}
	
}
