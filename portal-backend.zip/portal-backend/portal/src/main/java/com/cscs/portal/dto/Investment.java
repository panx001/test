package com.cscs.portal.dto;

public class Investment  extends InvestmentBase{

	private String legRepresent;

	public String getLegRepresent() {
		return legRepresent;
	}

	public void setLegRepresent(String legRepresent) {
		this.legRepresent = legRepresent;
	}

}
