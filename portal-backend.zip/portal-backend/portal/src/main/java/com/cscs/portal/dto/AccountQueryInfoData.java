package com.cscs.portal.dto;

import com.cscs.portal.dto.base.BaseInData;

/**
 * Created by dch on 2016/11/14.
 * 账户查询入参
 */
public class AccountQueryInfoData extends BaseInData{
    private String accountNm;
    private String startDtString;
    private String endDtString;

    public String getAccountNm() {
        return accountNm;
    }

    public void setAccountNm(String accountNm) {
        this.accountNm = accountNm;
    }

    public String getStartDtString() {
        return startDtString;
    }

    public void setStartDtString(String startDtString) {
        this.startDtString = startDtString;
    }

    public String getEndDtString() {
        return endDtString;
    }

    public void setEndDtString(String endDtString) {
        this.endDtString = endDtString;
    }
}
