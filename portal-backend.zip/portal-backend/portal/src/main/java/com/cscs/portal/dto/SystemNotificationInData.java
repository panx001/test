package com.cscs.portal.dto;

import com.cscs.portal.dto.base.BaseInData;

public class SystemNotificationInData extends BaseInData {
    private Long userId;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}
