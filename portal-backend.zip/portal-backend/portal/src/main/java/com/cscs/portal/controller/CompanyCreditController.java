package com.cscs.portal.controller;

import com.alibaba.fastjson.JSON;
import com.cscs.portal.dto.CreditDetail;
import com.cscs.portal.dto.FinanceFactorRank;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.util.Contants;
import com.cscs.util.HttpUtil;
import com.cscs.util.SolrUtil;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 企业资信状况
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/company/credit")
public class CompanyCreditController {

    //主体评级
    public static String COMPANY_CREDIT_CREDITRATING = "c_c_creditrating";
    //信用评估-风险评估
    public static String COMPANY_CREDIT_CSCSCREDIT = "c_c_cscscredit";
    //信用评估-风险分布
    public static String COMPANY_CREDIT_CSCSCREDITDETAIL = "c_c_cscscreditdetail";
    //信用评估-敞口类型
    public static String COMPANY_CREDIT_EXPOSURE = "c_c_exposure";
    //财务情况_企业年报
    public static String COMPANY_CREDIT_BASICINFONB = "c_c_basicinfonb";
    //财务分析-指标筛选
    public static String COMPANY_CREDIT_QUANFACTOR = "c_c_quanfactor";
    //财务分析-指标显示
    public static String COMPANY_CREDIT_FINANCEFACTOR = "c_c_financefactor";
    //财务分析-指标行业排名
    public static String COMPANY_CREDIT_FINANCEFACTORRANKIND = "c_c_financefactorrankind";
    //财务分析-财务指标数据历史走势
    public static String COMPANY_CREDIT_FINANCEFACTORTREND = "c_c_financefactortrend";
    //财务分析-经营情况
    public static String COMPANY_CREDIT_OPERATIONFACTOR = "c_c_operationfactor";

    //股权质押
    public static String COMPANY_CREDIT_FROZENPLEDGE = "c_c_frozenpledge";
    //债务及偿还情况-存续期债券
    public static String COMPANY_CREDIT_BONDINPERIOD = "c_c_bondinperiod";
    //债务及偿还情况-历史发行债券
    public static String COMPANY_CREDIT_BONDISSUEHIST = "c_c_bondissuehist";
    //债务及偿还情况-债务偿还统计表
    public static String COMPANY_CREDIT_BONDCASHHIST = "c_c_bondcashhist";
    //授信
    public static String COMPANY_CREDIT_COMPYCREDIT = "c_c_compycredit";
    //担保-东财
    public static String COMPANY_CREDIT_COMPYGUARANTEE = "c_c_compyguarantee";
    //担保-工商披露年报信息
    public static String COMPANY_CREDIT_COMPYGUARANTEEGS = "c_c_compyguaranteegs";
    //公司公告
    public static String COMPANY_CREDIT_ANNOUNCEINFO = "c_c_announceinfo";

    @Autowired
    private StringRedisTemplate rt;

    /**
     * 主体评级
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/compyCredit/{companyId}", method = RequestMethod.GET)
    public BaseOutData getCompyCredit(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        List<Map> list = null;
        try {
            out = rt.opsForValue().get(COMPANY_CREDIT_CREDITRATING + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_CREDIT_CREDITRATING_URL, companyId));
                if (out != null) {
                    rt.opsForValue().set(COMPANY_CREDIT_CREDITRATING + companyId, out.toString());
                    rt.expire(COMPANY_CREDIT_CREDITRATING + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
            if(out!=null) {
    			//排序
    			list = JSON.parseArray(String.valueOf(out), Map.class);
    			Collections.sort(list,new Comparator<Map>(){
    	            public int compare(Map arg0, Map arg1) {
    	            	return arg1.get("ratingDt").toString().compareTo(arg0.get("ratingDt").toString());
    	            }
    	        });
    		}
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", list);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 信用评估-风险评估
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/compyRating/{companyId}", method = RequestMethod.GET)
    public BaseOutData getCompyRating(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_CREDIT_CSCSCREDIT + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_CREDIT_CSCSCREDIT_URL, companyId));
                if (out != null) {
                    rt.opsForValue().set(COMPANY_CREDIT_CSCSCREDIT + companyId, out.toString());
                    rt.expire(COMPANY_CREDIT_CSCSCREDIT + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 信用评估-敞口类型
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/exposure/{companyId}", method = RequestMethod.GET)
    public BaseOutData getExposure(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_CREDIT_EXPOSURE + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_CREDIT_EXPOSURE_URL, companyId));
                if (out != null) {
                    rt.opsForValue().set(COMPANY_CREDIT_EXPOSURE + companyId, out.toString());
                    rt.expire(COMPANY_CREDIT_EXPOSURE + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", String.valueOf(out));
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }


    /**
     * 信用评估-风险分布
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/financeScatter/{companyId}", method = RequestMethod.GET)
    public BaseOutData getFinanceScatter(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        QueryResponse response = null;
        try {
            out = rt.opsForValue().get(COMPANY_CREDIT_CSCSCREDITDETAIL + companyId);
            if (out == null) {
            	//获取敞口类型
            	String type = (String)this.getExposure(companyId).getData().get("result");
                //out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_CREDIT_CSCSCREDITDETAIL_URL, companyId));
 				SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_CREDIT_METHOD);
 		        //创建一个SolrQuery对象
 		        SolrQuery query = new SolrQuery();
 		        query.set("wt", "json");
 		        query.set("q","exposure:" + type);
 		        //query.set("fq","company_id:" + companyId);
 		        query.set("shards.tolerant", "true");
 		        response = solrServer.query(query);
 		        List<CreditDetail> creditDetailList = new ArrayList<CreditDetail>();
 		        CreditDetail creditDetail = null;
 		        for (SolrDocument solrDocument : response.getResults()) {
 		        	creditDetail = JSON.parseObject((String)solrDocument.get("cscscreditdetail"),CreditDetail.class);
 		        	creditDetailList.add(creditDetail);
 		        	
 		        }
 		        if(creditDetailList.size()>0) {
 		        	out = JSON.toJSONString(creditDetailList);
 		        }
            	if (out != null) {
                    rt.opsForValue().set(COMPANY_CREDIT_CSCSCREDITDETAIL + companyId, out.toString());
                    rt.expire(COMPANY_CREDIT_CSCSCREDITDETAIL + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 财务情况
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/finance/{companyId}", method = RequestMethod.GET)
    public BaseOutData getFinance(@PathVariable String companyId) {
        BaseOutData out = new BaseOutData();
//        Map<String, Object> re = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_COMPYCHANGE_URL, companyId));
//        out.setData(re);
        out.setCode("0");
        return out;
    }

    /**
     * 企业年报
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/yearReport/{companyId}", method = RequestMethod.GET)
    public BaseOutData getYearReport(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        List<Map> list = null;
        try {
            out = rt.opsForValue().get(COMPANY_CREDIT_BASICINFONB + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_CREDIT_BASICINFONB_URL, companyId));
                if (out != null) {
                    rt.opsForValue().set(COMPANY_CREDIT_BASICINFONB + companyId, out.toString());
                    rt.expire(COMPANY_CREDIT_BASICINFONB + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
            if(out!=null) {
    			//排序
    			list = JSON.parseArray(String.valueOf(out), Map.class);
    			Collections.sort(list,new Comparator<Map>(){
    	            public int compare(Map arg0, Map arg1) {
    	            	return arg1.get("reportYear").toString().compareTo(arg0.get("reportYear").toString());
    	            }
    	        });
    		}
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", list);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 财务分析_指标筛选
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/quanFactorAll/{companyId}", method = RequestMethod.GET)
    public BaseOutData getQuanFactorTemplate(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_CREDIT_QUANFACTOR + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_CREDIT_QUANFACTOR_URL, companyId));
                if (out != null) {
                    rt.opsForValue().set(COMPANY_CREDIT_QUANFACTOR + companyId, out.toString());
                    rt.expire(COMPANY_CREDIT_QUANFACTOR + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 财务分析_指标显示
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/quanFactor/{companyId}", method = RequestMethod.GET)
    public BaseOutData getQuanFactor(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_CREDIT_FINANCEFACTOR + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_CREDIT_FINANCEFACTOR_URL, companyId));
                if (out != null) {
                    rt.opsForValue().set(COMPANY_CREDIT_FINANCEFACTOR + companyId, out.toString());
                    rt.expire(COMPANY_CREDIT_FINANCEFACTOR + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

//    /**
//     * 财务分析_某个财务指标数据
//     *
//     * @param companyId
//     * @return
//     */
//    @RequestMapping(value = "/quanFactorDetail/{companyId}/{code}", method = RequestMethod.GET)
//    public BaseOutData getQuanFactorDetail(@PathVariable String companyId, @PathVariable String code) {
//        BaseOutData out = new BaseOutData();
////        Map<String, Object> re = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_COMPYCHANGE_URL, companyId));
////        out.setData(re);
//        out.setCode("0");
//        return out;
//    }

    /**
     * 财务分析_财务指标数据历史走势
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/quanFactorHistory/{companyId}/{code}", method = RequestMethod.GET)
    public BaseOutData getQuanFactorHistory(@PathVariable String companyId,@PathVariable String code) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        List<Object> list = null;
        try {
            out = rt.opsForValue().get(COMPANY_CREDIT_FINANCEFACTORTREND + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_CREDIT_FINANCEFACTORTREND_URL, companyId));
                if (out != null) {
                    rt.opsForValue().set(COMPANY_CREDIT_FINANCEFACTORTREND + companyId, out.toString());
                    rt.expire(COMPANY_CREDIT_FINANCEFACTORTREND + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
            if(out != null) {
            	list = this.historySort(out,code);
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", list);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }
    
    public List<Object> historySort(Object out,String code) throws ParseException{
    	SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
    	List<Map> list = JSON.parseArray(String.valueOf(out), Map.class);
    	List<Object> returnList = new ArrayList<Object>();
    	List<Date> sortList = new ArrayList<Date>();
    	Map<String,Object> data = new HashMap<String,Object>();
    	for(Map<String, String> map : list) {
    		if(map.get("factorCode").equals(code)) {
    			for (Map.Entry<String, String> entry : map.entrySet()) {
    				if(!entry.getKey().equals("factorCode")) {
    					String key = entry.getKey();
    					sortList.add(sf.parse(entry.getKey()));
    					data.put(entry.getKey(), map);
    				}
    			}
    		}
    	}
    	Collections.sort(sortList,new Comparator<Date>(){
    		@Override
    		public int compare(Date o1, Date o2) {
    			return o2.compareTo(o1);
    		}
    	});
    	for(Date date : sortList) {
    		String dateStr = sf.format(date);
    		returnList.add(data.get(dateStr));
    	}
    	return returnList;
    }

    /**
     * 财务分析_指标行业排名
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/quanFactorIndustry/{companyId}/{code}", method = RequestMethod.GET)
    public BaseOutData getQuanFactorIndustry(@PathVariable String companyId, @PathVariable String code) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        QueryResponse response = null;
        try {
            out = rt.opsForValue().get(COMPANY_CREDIT_FINANCEFACTORRANKIND + companyId);
            if (out == null) {
            	//out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_CREDIT_FINANCEFACTORRANKIND_URL, companyId));
            	//获取敞口类型
            	String type = (String)this.getExposure(companyId).getData().get("result");
            	SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_CREDIT_METHOD);
		        //创建一个SolrQuery对象
		        SolrQuery query = new SolrQuery();
		        query.set("wt", "json");
		        query.set("q","code:" + code);
		        query.set("fq","exposure:" + type);
		        //query.set("fq","company_id:" + companyId);
		        query.set("shards.tolerant", "true");
		        response = solrServer.query(query);
		        List<FinanceFactorRank> financeFactorRankList = new ArrayList<FinanceFactorRank>();
		        FinanceFactorRank financeFactorRank = null;
		        for (SolrDocument solrDocument : response.getResults()) {
		        	financeFactorRank = new FinanceFactorRank();
		        	financeFactorRank.setCompyName((String)solrDocument.get("compyname"));
		        	financeFactorRank.setValue((String)solrDocument.get("value"));
		        	financeFactorRankList.add(financeFactorRank);
		        	
		        }
		        if(financeFactorRankList.size()>0) {
		        	Collections.sort(financeFactorRankList);
		        	out = JSON.toJSONString(financeFactorRankList);
		        }
		        
		        if (out != null) {
                    rt.opsForValue().set(COMPANY_CREDIT_FINANCEFACTORRANKIND + companyId, out.toString());
                    rt.expire(COMPANY_CREDIT_FINANCEFACTORRANKIND + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : "");
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

//    /**
//     * 财务分析
//     *
//     * @param companyId
//     * @return
//     */
//    @RequestMapping(value = "/anlysisDefault/{companyId}", method = RequestMethod.GET)
//    public BaseOutData getAnlysis(@PathVariable String companyId) {
//        BaseOutData out = new BaseOutData();
////        Map<String, Object> re = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_COMPYCHANGE_URL, companyId));
////        out.setData(re);
//        out.setCode("0");
//        return out;
//    }

    /**
     * 经营情况
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/operation/{companyId}", method = RequestMethod.GET)
    public BaseOutData getOperation(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        try {
            out = rt.opsForValue().get(COMPANY_CREDIT_OPERATIONFACTOR + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_CREDIT_OPERATIONFACTOR_URL, companyId));
                if (out != null) {
                    rt.opsForValue().set(COMPANY_CREDIT_OPERATIONFACTOR + companyId, out.toString());
                    rt.expire(COMPANY_CREDIT_OPERATIONFACTOR + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", out != null ? JSON.parse(String.valueOf(out)) : null);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 股权质押-累计汇总
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/frozenSummary/{companyId}", method = RequestMethod.GET)
    public BaseOutData getFrozenSummary(@PathVariable String companyId) {
        BaseOutData out = new BaseOutData();
//        Map<String, Object> re = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_COMPYCHANGE_URL, companyId));
//        out.setData(re);
        out.setCode("0");
        return out;
    }

    /**
     * 股权质押
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/pledge/{companyId}", method = RequestMethod.GET)
    public BaseOutData getPledge(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        List<Map> list = null;
        try {
            out = rt.opsForValue().get(COMPANY_CREDIT_FROZENPLEDGE + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_CREDIT_FROZENPLEDGE_URL, companyId));
                if (out != null) {
                    rt.opsForValue().set(COMPANY_CREDIT_FROZENPLEDGE + companyId, out.toString());
                    rt.expire(COMPANY_CREDIT_FROZENPLEDGE + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
            if(out!=null) {
    			//排序
    			list = JSON.parseArray(String.valueOf(out), Map.class);
    			Collections.sort(list,new Comparator<Map>(){
    	            public int compare(Map arg0, Map arg1) {
    	            	return arg1.get("noticeDt").toString().compareTo(arg0.get("noticeDt").toString());
    	            }
    	        });
    		}
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", list);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 债务及偿还情况-存续期债券
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/expect/{companyId}", method = RequestMethod.GET)
    public BaseOutData getExpect(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        List<Map> list = null;
        try {
            out = rt.opsForValue().get(COMPANY_CREDIT_BONDINPERIOD + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_CREDIT_BONDINPERIOD_URL, companyId));
                if (out != null) {
                    rt.opsForValue().set(COMPANY_CREDIT_BONDINPERIOD + companyId, out.toString());
                    rt.expire(COMPANY_CREDIT_BONDINPERIOD + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
            if(out!=null) {
    			//排序
    			list = JSON.parseArray(String.valueOf(out), Map.class);
    			Collections.sort(list,new Comparator<Map>(){
    	            public int compare(Map arg0, Map arg1) {
    	            	return arg1.get("issueDt").toString().compareTo(arg0.get("issueDt").toString());
    	            }
    	        });
    		}
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", list);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 债务及偿还情况-历史发行债券
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/expectHistory/{companyId}", method = RequestMethod.GET)
    public BaseOutData getExpectHistory(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        List<Map> list = null;
        try {
            out = rt.opsForValue().get(COMPANY_CREDIT_BONDISSUEHIST + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_CREDIT_BONDISSUEHIST_URL, companyId));
                if (out != null) {
                    rt.opsForValue().set(COMPANY_CREDIT_BONDISSUEHIST + companyId, out.toString());
                    rt.expire(COMPANY_CREDIT_BONDISSUEHIST + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
            if(out!=null) {
    			//排序
    			list = JSON.parseArray(String.valueOf(out), Map.class);
    			Collections.sort(list,new Comparator<Map>(){
    	            public int compare(Map arg0, Map arg1) {
    	            	return arg1.get("issueDt").toString().compareTo(arg0.get("issueDt").toString());
    	            }
    	        });
    		}
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", list);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 债务及偿还情况-债务偿还统计表
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/expectScatter/{companyId}", method = RequestMethod.GET)
    public BaseOutData getExpectScatter(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        Map<String,Object> map = null;
        try {
            //out = rt.opsForValue().get(COMPANY_CREDIT_BONDCASHHIST + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_CREDIT_BONDCASHHIST_URL, companyId));
                if (out != null) {
                    rt.opsForValue().set(COMPANY_CREDIT_BONDCASHHIST + companyId, out.toString());
                    rt.expire(COMPANY_CREDIT_BONDCASHHIST + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
            if(out != null) {
            	map = this.expectScatterSort(out);
            }
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", map);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }
    
    public Map<String,Object> expectScatterSort(Object out) throws ParseException{
    	Map<String,Object> map = (Map)JSON.parse(String.valueOf(out));
    	LinkedHashMap<String,Object> returnMap = new LinkedHashMap<String,Object>();
    	List<String> sortList = new ArrayList<String>();
    	Map<String,Object> data = new HashMap<String,Object>();
    	for (Map.Entry<String,Object> entry : map.entrySet()) {
    		String key = entry.getKey();
    		sortList.add(key);
    	}
    	Collections.sort(sortList);
    	for(String str : sortList) {
    		returnMap.put(str, map.get(str));
    	}
    	return returnMap;
    }
    
    /**
     * 授信
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/credit/{companyId}", method = RequestMethod.GET)
    public BaseOutData getCredit(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        List<Map> list = null;
        try {
            out = rt.opsForValue().get(COMPANY_CREDIT_COMPYCREDIT + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_CREDIT_COMPYCREDIT_URL, companyId));
                if (out != null) {
                    rt.opsForValue().set(COMPANY_CREDIT_COMPYCREDIT + companyId, out.toString());
                    rt.expire(COMPANY_CREDIT_COMPYCREDIT + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
            if(out!=null) {
    			//排序
    			list = JSON.parseArray(String.valueOf(out), Map.class);
    			Collections.sort(list,new Comparator<Map>(){
    	            public int compare(Map arg0, Map arg1) {
    	            	return arg1.get("noticeDt").toString().compareTo(arg0.get("noticeDt").toString());
    	            }
    	        });
    		}
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", list);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 担保-累计担保数据
     *
     * @param companyId
     * @return
     */

    @RequestMapping(value = "/guaranteeSummary/{companyId}", method = RequestMethod.GET)
    public BaseOutData getGuaranteeSummary(@PathVariable String companyId) {
        BaseOutData out = new BaseOutData();
//        Map<String, Object> re = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_COMPYCHANGE_URL, companyId));
//        out.setData(re);
        out.setCode("0");
        return out;
    }

    /**
     * 担保-东财
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/guarantee/{companyId}", method = RequestMethod.GET)
    public BaseOutData getGuarantee(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        List<Map> list = null;
        try {
            out = rt.opsForValue().get(COMPANY_CREDIT_COMPYGUARANTEE + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_CREDIT_COMPYGUARANTEE_URL, companyId));
                if (out != null) {
                    rt.opsForValue().set(COMPANY_CREDIT_COMPYGUARANTEE + companyId, out.toString());
                    rt.expire(COMPANY_CREDIT_COMPYGUARANTEE + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
            if(out!=null) {
    			//排序
    			list = JSON.parseArray(String.valueOf(out), Map.class);
    			Collections.sort(list,new Comparator<Map>(){
    	            public int compare(Map arg0, Map arg1) {
    	            	return arg1.get("noticeDt").toString().compareTo(arg0.get("noticeDt").toString());
    	            }
    	        });
    		}
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", list);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 担保-工商披露年报信息
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/guaranteeReport/{companyId}", method = RequestMethod.GET)
    public BaseOutData getGuaranteeReport(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        List<Map> list = null;
        try {
            out = rt.opsForValue().get(COMPANY_CREDIT_COMPYGUARANTEEGS + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_CREDIT_COMPYGUARANTEEGS_URL, companyId));
                if (out != null) {
                    rt.opsForValue().set(COMPANY_CREDIT_COMPYGUARANTEEGS + companyId, out.toString());
                    rt.expire(COMPANY_CREDIT_COMPYGUARANTEEGS + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
            if(out!=null) {
    			//排序
    			list = JSON.parseArray(String.valueOf(out), Map.class);
    			Collections.sort(list,new Comparator<Map>(){
    	            public int compare(Map arg0, Map arg1) {
    	            	return arg1.get("reportYear").toString().compareTo(arg0.get("reportYear").toString());
    	            }
    	        });
    		}
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", list);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }

    /**
     * 公司公告
     *
     * @param companyId
     * @return
     */
    @RequestMapping(value = "/compyAnnounce/{companyId}", method = RequestMethod.GET)
    public Object getCompyAnnounce(@PathVariable String companyId) {
        BaseOutData outData = new BaseOutData();
        Object out = null;
        List<Map> list = null;
        try {
            out = rt.opsForValue().get(COMPANY_CREDIT_ANNOUNCEINFO + companyId);
            if (out == null) {
                out = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_CREDIT_ANNOUNCEINFO_URL, companyId));
                if (out != null) {
                    rt.opsForValue().set(COMPANY_CREDIT_ANNOUNCEINFO + companyId, out.toString());
                    rt.expire(COMPANY_CREDIT_ANNOUNCEINFO + companyId, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
                }
            }
            if(out!=null) {
    			//排序
    			list = JSON.parseArray(String.valueOf(out), Map.class);
    			Collections.sort(list,new Comparator<Map>(){
    	            public int compare(Map arg0, Map arg1) {
    	            	return arg1.get("announcedt").toString().compareTo(arg0.get("announcedt").toString());
    	            }
    	        });
    		}
        } catch (Exception e) {
            e.printStackTrace();
            outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
        }
        Map data = new HashMap();
        data.put("result", list);
        outData.setCode("0");
        outData.setMessage("返回成功!");
        outData.setData(data);
        return outData;
    }
}
