package com.cscs.portal.dto;

public class CreditDetail {

	private String level;

	private String compyName;
	private String financeValue;
	private String operationValue;

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getCompyName() {
		return compyName;
	}

	public void setCompyName(String compyName) {
		this.compyName = compyName;
	}

	public String getFinanceValue() {
		return financeValue;
	}

	public void setFinanceValue(String financeValue) {
		this.financeValue = financeValue;
	}

	public String getOperationValue() {
		return operationValue;
	}

	public void setOperationValue(String operationValue) {
		this.operationValue = operationValue;
	}

}
