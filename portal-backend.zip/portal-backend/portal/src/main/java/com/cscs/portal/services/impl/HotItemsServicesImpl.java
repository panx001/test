package com.cscs.portal.services.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cscs.portal.dto.base.BaseInData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.HotCompanies;
import com.cscs.portal.services.HotItemsServices;
import com.cscs.repository.HotItemsRepository;

@SuppressWarnings("JpaQlInspection")
@Service
public class HotItemsServicesImpl implements HotItemsServices {

    @Autowired
    private HotItemsRepository repository;

    @Autowired
    EntityManager em;

    public List<HotCompanies> search() {
        String sql = "SELECT h FROM HotCompanies h WHERE isDel = 0 order by priority ,dt desc";
        Query query = em.createQuery(sql);
        query.setFirstResult(0);
        query.setMaxResults(10);
        return query.getResultList();
    }

    public HotCompanies searchById(Long id) {
        String sql = "SELECT h FROM HotCompanies h WHERE isdel = 0 and id = ?1";
        Query query = em.createQuery(sql);
        query.setParameter(1, id);
        return (HotCompanies) query.getSingleResult();
    }

    @Transactional
    public void save(HotCompanies hotCompanies) {
        repository.save(hotCompanies);
    }

    @Transactional
    public int delete(Long id) {
        String sql = "UPDATE hot_companies SET ISDEL = 1 WHERE ID = " + id;
        return em.createNativeQuery(sql).executeUpdate();
    }

	@Override
	public List<HotCompanies> listByPaging(BaseInData inData, BaseOutData outData) {
		 	int page = inData.getPage() == 0 ? 0 : inData.getPage() - 1;
	        int pageSize = inData.getPageSize() == 0 ? 10 : inData.getPageSize();
	        String sql = "SELECT h FROM HotCompanies h WHERE isDel = 0 order by priority ,dt desc";
	        String countSql = "SELECT count(1) FROM hot_companies  WHERE isdel = 0";
	        Query query = em.createQuery(sql);
	        Query countQuery = em.createNativeQuery(countSql);
	        Integer total = Integer.valueOf(countQuery.getSingleResult().toString());
	        outData.setCount(total);
	        query.setFirstResult(page * pageSize);
	        query.setMaxResults(pageSize);
	        return query.getResultList();
	}
}
