package com.cscs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cscs.portal.entity.HotCompanies;


@SuppressWarnings("JpaQlInspection")
public interface HotItemsRepository extends JpaRepository<HotCompanies, Long> {

}
