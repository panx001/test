package com.cscs.portal.dto;
import java.util.List;

public class SharehdInvestnb implements Comparable<SharehdInvestnb> {

	private String reportYear;
	private List<SharehdInvestnbDetail> sharehdList;

	public String getReportYear() {
		return reportYear;
	}

	public void setReportYear(String reportYear) {
		this.reportYear = reportYear;
	}

	public List<SharehdInvestnbDetail> getSharehdList() {
		return sharehdList;
	}

	public void setSharehdList(List<SharehdInvestnbDetail> sharehdList) {
		this.sharehdList = sharehdList;
	}

	@Override
	public int compareTo(SharehdInvestnb o) {
			//降序
			if (Integer.parseInt(reportYear) > Integer.parseInt(o.getReportYear())) {
				return -1;
			} else if (Integer.parseInt(reportYear) < Integer.parseInt(o.getReportYear())) {
				return 1;
			} else {
				return 0;
			}

	}

}
