package com.cscs.portal.dto;

public class CompanySearchResultOut {

	private String companyNm;
	
	private String companyId;
	
	private boolean isFoundFlag;

	public String getCompanyNm() {
		return companyNm;
	}

	public void setCompanyNm(String companyNm) {
		this.companyNm = companyNm;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public boolean getIsFoundFlag() {
		return isFoundFlag;
	}

	public void setIsFoundFlag(boolean isFoundFlag) {
		this.isFoundFlag = isFoundFlag;
	}
	
	
}
