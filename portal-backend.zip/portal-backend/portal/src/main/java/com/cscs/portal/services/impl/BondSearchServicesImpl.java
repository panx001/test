package com.cscs.portal.services.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.springframework.stereotype.Service;

import com.cscs.portal.dto.BondSearchConditon;
import com.cscs.portal.dto.BondSearchOut;
import com.cscs.portal.services.BondSearchServices;

/***
 * 
 * @ClassName: RiskSearchServicesImpl
 * @Description: 发债企业高级搜索服务实现类
 * @author: liunn
 * @date: 2018年10月20日 下午4:36:59
 */
@Service
public class BondSearchServicesImpl implements BondSearchServices {
	protected final Log logger = LogFactory.getLog(this.getClass());

	@Override
	public SolrQuery setSolrQuery(BondSearchConditon condition,SolrQuery query) {
		//查询关键字，q不能省略
		if(StringUtils.isNotEmpty(condition.getKeyword())) {
			query.set("q","company_nm:"+condition.getKeyword());
		}else {
			query.set("q","*:*");
		}
		//query fields，指定solr从哪些field中搜索 设置查询权重值
		query.set("defType", "edismax");
		//只查询存活的分片
		query.set("shards.tolerant", "true");
		//排序
		//参数：field域，排序类型（asc,desc）
		query.addSort("score", SolrQuery.ORDER.desc);
		query.addSort("regcapital", SolrQuery.ORDER.desc);
		//分页
		//实际开发时，知道当前页码和每页显示的个数最后求出开始下标
		int curPage = condition.getCurPage()==null?1:condition.getCurPage();
		int rows = condition.getRowNum()==null?10:condition.getRowNum();
		//计算出开始记录下标
		int start = rows * (curPage - 1);
		//向query中设置分页参数
		query.setStart(start);
		query.setRows(rows);
		//开启高亮
		query.setHighlight(true);
		//设置高亮 参数
		query.addHighlightField("company_nm,security_snm");
		//设置高亮前缀和后缀
		query.setHighlightSimplePre("<span class=\"highlight\">");
		query.setHighlightSimplePost("</span>");
		return query;
	}
	@Override
	public SolrQuery bondIssuerCondition(BondSearchConditon condition,SolrQuery query) {
		//查询关键字，q不能省略
		query.set("q","*:*");
		//query fields，指定solr从哪些field中搜索 设置查询权重值
		query.set("defType", "edismax");
		//只查询存活的分片
		query.set("shards.tolerant", "true");
		//分页
		//实际开发时，知道当前页码和每页显示的个数最后求出开始下标
		int curPage = condition.getCurPage()==null?1:condition.getCurPage();
		int rows = condition.getRowNum()==null?10:condition.getRowNum();
		//计算出开始记录下标
		int start = rows * (curPage - 1);
		//向query中设置分页参数
		query.setStart(start);
		query.setRows(rows);
		return query;
	}
	
	@Override
	public List<BondSearchOut> getResponseDate(QueryResponse response){
		List<BondSearchOut> returnList = new ArrayList<BondSearchOut>();
		//从响应中得到结果
		SolrDocumentList documents = response.getResults();
		//从响应中获得高亮信息
		Map<String, Map<String, List<String>>> highlighting = response.getHighlighting();
		
		for (SolrDocument document:documents){
			BondSearchOut data = new BondSearchOut();
			if(null != document.get("id")) {
				data.setCompanyId(String.valueOf(document.get("id")));
			}
			if(null != document.get("company_nm")) {
				data.setCompanyNm(String.valueOf(document.get("company_nm")));
			}
			if(null != document.get("company_st")) {
				data.setCompanySt(String.valueOf(document.get("company_st")));
			}
			if(null != document.get("credit_org_nm")) {
				data.setCreditOrgNm(String.valueOf(document.get("credit_org_nm")));
			}
			if(null != document.get("rating_prev")) {
				data.setRatingPrev(String.valueOf(document.get("rating_prev")));
			}
			if(null != document.get("rating_current")) {
				data.setRatingCurrent(String.valueOf(document.get("rating_current")));
			}
			if(null != document.get("rating_dt_prev")) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				data.setRatingDtPrev(sdf.format((Date)document.get("rating_dt_prev")));
			}
			if(null != document.get("rating_dt_current")) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				data.setRatingDtCurrent(sdf.format((Date)document.get("rating_dt_current")));
			}
			if(null != document.get("found_dt")) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				data.setFoundDt(sdf.format((Date)document.get("found_dt")));
			}
			if(null != document.get("finance_audit")) {
				data.setFinanceAudit(String.valueOf(document.get("finance_audit")));
			}
			if(null != document.get("rating_fwd_prev")) {
				data.setRatingFwdPrev(String.valueOf(document.get("rating_fwd_prev")));
			}
			if(null != document.get("rating_fwd_current")) {
				data.setRatingFwdCurrent(String.valueOf(document.get("rating_fwd_current")));
			}
			if(null != document.get("company_type")) {
				data.setCompanyType(String.valueOf(document.get("company_type")));
			}
			if(null != document.get("gmanager")) {
				data.setGmanager(String.valueOf(document.get("gmanager")));
			}
			if(null != document.get("islist3")) {
				data.setIslist3(String.valueOf(document.get("islist3")));
			}
			if(null != document.get("security_cd")) {
				List list = (List)document.get("security_cd");
				data.setSecurityCd(list);
			}
			if(null != document.get("finance_factor")) {
				List list = (List)document.get("finance_factor");
				data.setFinanceFactor(list);
			}
			if(null != document.get("credit_chg")) {
				List list = (List)document.get("credit_chg");
				data.setCreditChg(list);
			}
			if(null != document.get("isbond")) {
				data.setIsbond(String.valueOf(document.get("isbond")));
			}
			if(null != document.get("industry")) {
				data.setIndustry(String.valueOf(document.get("industry")));
			}
			if(null != document.get("legal_person_nm")) {
				data.setLegalPersonNm(String.valueOf(document.get("legal_person_nm")));
			}
			if(null != document.get("ispfund")) {
				data.setIspfund(String.valueOf(document.get("ispfund")));
			}
			if(null != document.get("credit_cd")) {
				data.setCreditCd(String.valueOf(document.get("credit_cd")));
			}
			if(null != document.get("regcapital")) {
				data.setRegcapital(String.valueOf(document.get("regcapital")));
			}
			if(null != document.get("chairman")) {
				data.setChairman(String.valueOf(document.get("chairman")));
			}
			if(null != document.get("bond_type")) {
				List list = (List)document.get("bond_type");
				data.setBondType(list);
			}
			if(null != document.get("rating_level")) {
				data.setBondLevel(String.valueOf(document.get("rating_level")));
			}
			if(null != document.get("reg_region")) {
				data.setRegRegion(String.valueOf(document.get("reg_region")));
			}
			if(null != document.get("islist")) {
				data.setIslist(String.valueOf(document.get("islist")));
			}
			
			//获得高亮的信息
			if(highlighting!=null){
				//根据主键获取高亮信息
				Map<String, List<String>> map = highlighting.get(document.get("id"));
				if(map!=null){
					List highlightColumns = new ArrayList();
					List<String> companyNmList = map.get("company_nm");
					List<String> securitySnmList = map.get("security_snm");
					if(companyNmList!=null){
						data.setCompanyNm(companyNmList.get(0));
						highlightColumns.add("companyNm");
					}
					if(securitySnmList!=null){
						data.setSecuritySnm(securitySnmList.get(0));
						highlightColumns.add("securitySnm");
					}
					data.setHighlightColumns(highlightColumns);
				}
			}
			returnList.add(data);
		}
		return returnList;
	}
	
	@Override
	public List getBondIssuerCurrent(QueryResponse response){
		List returnList = new ArrayList();
		//从响应中得到结果
		SolrDocumentList documents = response.getResults();
		
		for (SolrDocument document:documents){
			Map map = new HashMap();
			map.put("id", document.get("id"));
			map.put("name", document.get("company_nm"));
			map.put("val", document.get("sum_issue_vol"));
			returnList.add(map);
		}
		return returnList;
	}
	@Override
	public List getBondIssuerWithinYear(QueryResponse response){
		List returnList = new ArrayList();
		//从响应中得到结果
		SolrDocumentList documents = response.getResults();
		
		for (SolrDocument document:documents){
			Map map = new HashMap();
			map.put("id", document.get("id"));
			map.put("name", document.get("company_nm"));
			map.put("val", document.get("sum_pay_vol"));
			returnList.add(map);
		}
		return returnList;
	}
	@Override
	public List getBondIssuerDuration(QueryResponse response){
		List returnList = new ArrayList();
		//从响应中得到结果
		SolrDocumentList documents = response.getResults();
		
		for (SolrDocument document:documents){
			Map map = new HashMap();
			map.put("id", document.get("id"));
			map.put("name", document.get("company_nm"));
			map.put("val", document.get("sum_bond_cnt"));
			returnList.add(map);
		}
		return returnList;
	}
	
	@Override
	public String getQueryTime(String foundDt) throws ParseException {
    	String queryStr = "";
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    	SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
    	Date startTime = null;
    	Date endTime = null;
    	String[] foundDtArr = foundDt.split("-");
    	if(foundDtArr!=null && foundDtArr.length>1) {
    		String startDateStr = foundDtArr[0];
    		String endDateStr = foundDtArr[1];
    		startTime = formatter.parse(startDateStr);
			endTime = formatter.parse(endDateStr);
			queryStr = "found_dt:["+sdf.format(startTime)+" TO "+sdf.format(endTime)+"]";
    	}
    	return queryStr;
    }
}
