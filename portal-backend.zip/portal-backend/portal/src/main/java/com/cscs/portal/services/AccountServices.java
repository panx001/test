package com.cscs.portal.services;

import com.cscs.portal.dto.UserTraceInfoData;
import com.cscs.portal.entity.Account;

import java.util.List;

/**
 * Created by dch on 2016/11/2
 */
public interface AccountServices {

    /**
     * 新规/更新
     */
    Account save(Account account) throws Exception;

    /**
     * 删除
     */
    void delete(Account account) throws Exception;

    /**
     * 查询账号是否存在
     */
    Account findByAccountNm(String accountNm);

    /**
     * 查询密码是否正确
     */
    Account findByAccount(String accountNm, String accountPw);

    /**
     * 修改密码
     */
    Integer updateUserPwd(String accountNm, String accountPw);

    /**
     * 查询账号是否存在
     */
    Account findByUserId(Long userId);

    /**
     * 账户导出数据
     */
    List<Object> findAccountList(String startDtString, String endDtString);

    /**
     * 访问记录数据导出
     */
    List<Object> visitRecord(UserTraceInfoData userTraceInfoData);

    //判断当前数据是是否存在
    Account findByAccountNmAndName(String accountnm, String userName);

    //判断当前数据是是否存在
    Object findAccountName(Long userId);

    /**
     * 查询账号信息
     */
    List<Object> getAccount(String accountNm, String accountPw);
}
