package com.cscs.portal.services;

import com.cscs.portal.dto.HotNewsInData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.HotNews;

import java.util.List;

public interface HotNewsServices {

   List<HotNews> search(HotNewsInData inData,BaseOutData outData);

   HotNews searchById(Long id);

   void save(HotNews hotNews);

   int delete(Long id);
}
