package com.cscs.repository;

import com.cscs.portal.entity.HotNews;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

/**
 * Created by dch on 2016/11/2.
 */
@SuppressWarnings("JpaQlInspection")
public interface HotNewsRepository extends JpaRepository<HotNews, Long> {

}
