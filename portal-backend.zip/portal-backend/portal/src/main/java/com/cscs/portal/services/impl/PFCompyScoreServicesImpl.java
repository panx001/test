package com.cscs.portal.services.impl;

import com.cscs.portal.dto.PFCompySearchIn;
import com.cscs.portal.entity.PFCompyScore;
import com.cscs.portal.services.PFCompyScoreServices;
import com.cscs.repository.PfcompyScoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

/**
 * Created by dch on 2016/11/7.
 */
@SuppressWarnings("JpaQlInspection")
@Service
public class PFCompyScoreServicesImpl implements PFCompyScoreServices {

    @Autowired
    private PfcompyScoreRepository pfcompyScoreRepository;

    @PersistenceContext
    EntityManager em;

    @Override
    public void save(PFCompyScore infoData) {
        pfcompyScoreRepository.save(infoData);
    }

    @Override
    public String searchWeigh() {
        String sql = "SELECT NVL(ROUND(SUM(WEIGHT_SCORE)/SUM(1),2),0) FROM PFCOMPY_SCORE WHERE TRUNC(SCORE_DT) = TRUNC(SYSDATE)";
        return em.createNativeQuery(sql).getSingleResult().toString();
    }

    @Override
    public int searchSum() {
        String sql = "SELECT NVL(SUM(1),0) FROM PFCOMPY_SCORE WHERE TRUNC(SCORE_DT) = TRUNC(SYSDATE)";
        return Integer.valueOf(em.createNativeQuery(sql).getSingleResult().toString());
    }

    @Override
    public int highRisk() {
        String sql = "SELECT COUNT(1) FROM PFCOMPY_SCORE WHERE RISK_RESULT = 1 AND TRUNC(SCORE_DT) = TRUNC(SYSDATE)";
        return Integer.valueOf(em.createNativeQuery(sql).getSingleResult().toString());
    }

    @Override
    public List<Object> searchByTime(int type) {
        String sql = "";
        if (1 == type) {
            sql += "SELECT SUM(1),RISK_RESULT,TO_CHAR(SCORE_DT,'YYYY-MM-DD') FROM PFCOMPY_SCORE\n";
            sql += "WHERE TRUNC(SCORE_DT) > TRUNC(SYSDATE - 7) AND TRUNC(SCORE_DT) <= TRUNC(SYSDATE)\n";
            sql += "GROUP BY RISK_RESULT,TO_CHAR(SCORE_DT,'YYYY-MM-DD')";
            sql += "ORDER BY TO_CHAR(SCORE_DT,'YYYY-MM-DD')";
        } else if (2 == type) {
            sql += "SELECT SUM(1),RISK_RESULT,TO_CHAR(SCORE_DT,'YYYY-MM-DD') FROM PFCOMPY_SCORE\n";
            sql += "WHERE TRUNC(SCORE_DT) > TRUNC(SYSDATE - 31) AND TRUNC(SCORE_DT) <= TRUNC(SYSDATE)\n";
            sql += "GROUP BY RISK_RESULT,TO_CHAR(SCORE_DT,'YYYY-MM-DD')";
            sql += "ORDER BY TO_CHAR(SCORE_DT,'YYYY-MM-DD')";
        } else if (3 == type) {
            sql += "SELECT SUM(1),RISK_RESULT,TO_CHAR(SCORE_DT,'YYYY-MM-DD') FROM PFCOMPY_SCORE\n";
            sql += "WHERE TO_CHAR(SCORE_DT,'YYYY-MM-DD') IN (SELECT MAX(TO_CHAR(SCORE_DT,'YYYY-MM-DD')) FROM PFCOMPY_SCORE\n";
            sql += "    WHERE TO_CHAR(SCORE_DT,'YYYY-MM') > TO_CHAR(ADD_MONTHS(SYSDATE,-3),'YYYY-MM') AND TRUNC(SCORE_DT) <= TRUNC(SYSDATE)\n";
            sql += "    GROUP BY TO_CHAR(SCORE_DT,'YYYYWW'))\n";
            sql += "GROUP BY RISK_RESULT,TO_CHAR(SCORE_DT,'YYYY-MM-DD')";
            sql += "ORDER BY TO_CHAR(SCORE_DT,'YYYY-MM-DD')";
        } else if (4 == type) {
            sql += "SELECT SUM(1),RISK_RESULT,TO_CHAR(SCORE_DT,'YYYY-MM') FROM PFCOMPY_SCORE\n";
            sql += "WHERE TO_CHAR(SCORE_DT,'YYYY-MM-DD') IN (SELECT MAX(TO_CHAR(SCORE_DT,'YYYY-MM-DD')) FROM PFCOMPY_SCORE\n";
            sql += "   WHERE TO_CHAR(SCORE_DT,'YYYY') > TO_CHAR(ADD_MONTHS(SYSDATE,-12),'YYYY') AND TRUNC(SCORE_DT) <= TRUNC(SYSDATE)\n";
            sql += "   GROUP BY TO_CHAR(SCORE_DT,'YYYY-MM'))\n";
            sql += "GROUP BY RISK_RESULT,TO_CHAR(SCORE_DT,'YYYY-MM')\n";
            sql += "ORDER BY TO_CHAR(SCORE_DT,'YYYY-MM')";
        }
        return em.createNativeQuery(sql).getResultList();
    }

//    @Override
//    public List<Object> searchWeightByTime(int type) {
//        String sql = "";
//        if (1 == type) {
//            sql += "SELECT ROUND(SUM(WEIGHT_SCORE)/SUM(1),2),TO_CHAR(SCORE_DT,'YYYY-MM') FROM PFCOMPY_SCORE\n";
//            sql += "WHERE TO_CHAR(SCORE_DT,'YYYY-MM-DD') IN (SELECT MAX(TO_CHAR(SCORE_DT,'YYYY-MM-DD')) FROM PFCOMPY_SCORE\n";
//            sql += "   WHERE TO_CHAR(SCORE_DT,'YYYY') = TO_CHAR(SYSDATE,'YYYY')\n";
//            sql += "   GROUP BY TO_CHAR(SCORE_DT,'YYYY-MM'))\n";
//            sql += "GROUP BY TO_CHAR(SCORE_DT,'YYYY-MM')\n";
//            sql += "ORDER BY TO_CHAR(SCORE_DT,'YYYY-MM')";
//        } else if (2 == type) {
//            sql += "SELECT ROUND(SUM(WEIGHT_SCORE)/SUM(1),2),TO_CHAR(SCORE_DT,'YYYY-MM-DD') FROM PFCOMPY_SCORE\n";
//            sql += "WHERE TO_CHAR(SCORE_DT,'YYYY-MM') = TO_CHAR(SYSDATE,'YYYY-MM')\n";
//            sql += "GROUP BY TO_CHAR(SCORE_DT,'YYYY-MM-DD')\n";
//            sql += "ORDER BY TO_CHAR(SCORE_DT,'YYYY-MM-DD')";
//        } else {
//            sql += "SELECT ROUND(SUM(WEIGHT_SCORE)/SUM(1),2),TO_CHAR(SCORE_DT,'YYYY-MM-DD') FROM PFCOMPY_SCORE\n";
//            sql += "WHERE TRUNC(SCORE_DT) >= TRUNC(SYSDATE -7)\n";
//            sql += "GROUP BY TO_CHAR(SCORE_DT,'YYYY-MM-DD')\n";
//            sql += "ORDER BY TO_CHAR(SCORE_DT,'YYYY-MM-DD')";
//        }
//        return em.createNativeQuery(sql).getResultList();
//    }

    @Override
    public List<Object> searchByType(int type) {
        String sql = "SELECT COMPANY_ID,COMPANY_NAME,";
        switch (type) {
            case 1:
                sql += "WEIGHT_SCORE FROM PFCOMPY_SCORE WHERE ROWNUM <= 10 AND TRUNC(SCORE_DT) = TRUNC(SYSDATE) ORDER BY CAPITAL_SCORE DESC";
                break;
            case 2:
                sql += "WEIGHT_SCORE FROM PFCOMPY_SCORE WHERE ROWNUM <= 10 AND TRUNC(SCORE_DT) = TRUNC(SYSDATE) ORDER BY MANAGE_SCORE DESC";
                break;
            case 3:
                sql += "WEIGHT_SCORE FROM PFCOMPY_SCORE WHERE ROWNUM <= 10 AND TRUNC(SCORE_DT) = TRUNC(SYSDATE) ORDER BY SINCERITY_SCORE DESC";
                break;
            case 4:
                sql += "WEIGHT_SCORE FROM PFCOMPY_SCORE WHERE ROWNUM <= 10  AND TRUNC(SCORE_DT) = TRUNC(SYSDATE) ORDER BY RELATION_SCORE DESC";
                break;
            case 5:
                sql += "WEIGHT_SCORE FROM PFCOMPY_SCORE WHERE ROWNUM <= 10 AND TRUNC(SCORE_DT) = TRUNC(SYSDATE) ORDER BY COMPLIANCE_SCORE DESC";
                break;
//            case 6:
//                sql += "CHEAT_SCORE FROM PFCOMPY_SCORE WHERE ROWNUM <= 10 AND TRUNC(SCORE_DT) = TRUNC(SYSDATE) ORDER BY CHEAT_SCORE DESC";
//                break;
//            default:
//                sql += "CAPITAL_SCORE FROM PFCOMPY_SCORE WHERE ROWNUM <= 10 AND TRUNC(SCORE_DT) = TRUNC(SYSDATE) ORDER BY CAPITAL_SCORE DESC";
        }
        return em.createNativeQuery(sql).getResultList();
    }

    @Override
    public List<Object> wholeCount() {
        String sql = "SELECT SUM(1),RISK_RESULT FROM PFCOMPY_SCORE WHERE TRUNC(SCORE_DT) = TRUNC(SYSDATE) GROUP BY RISK_RESULT";
        return em.createNativeQuery(sql).getResultList();
    }

    @Override
    public List<Object> searchCount(String region) {
        String sql = "";
        if (!"全国".equals(region)) {
            sql += "SELECT ROUND(SUM(WEIGHT_SCORE)/SUM(1),2) CN,CITY FROM PFCOMPY_SCORE\n";
            sql += " WHERE TRUNC(SCORE_DT) = TRUNC(SYSDATE) AND REGION LIKE ?1\n";
            sql += "GROUP BY CITY ORDER BY CN DESC";
        } else {
            sql += "SELECT ROUND(SUM(WEIGHT_SCORE)/SUM(1),2) CN,REGION FROM PFCOMPY_SCORE\n";
            sql += "WHERE TRUNC(SCORE_DT) = TRUNC(SYSDATE) AND REGION IS NOT NULL\n";
            sql += "GROUP BY REGION ORDER BY CN DESC";
        }
        Query query = em.createNativeQuery(sql);
        if (!"全国".equals(region)) {
            query.setParameter(1, region + "%");
        }

        return query.getResultList();
    }

//    @Override
//    public List<Object> searchTop10(String region) {
//        String sql = "";
//        if (!"全国".equals(region)) {
//            sql += "SELECT * FROM (SELECT ROUND(SUM(WEIGHT_SCORE)/SUM(1),2) CN ,CITY FROM PFCOMPY_SCORE WHERE TRUNC(SCORE_DT) = TRUNC(SYSDATE)\n";
//            sql += "WHERE TRUNC(SCORE_DT) = TRUNC(SYSDATE) AND REGION = ?1\n";
//            sql += "AND REGION = ?1 GROUP BY REGION,CITY ORDER BY CN DESC) WHERE ROWNUM <= 10";
//        } else {
//            sql += "SELECT * FROM (SELECT ROUND(SUM(WEIGHT_SCORE)/SUM(1),2) CN ,REGION FROM PFCOMPY_SCORE\n";
//            sql += "WHERE TRUNC(SCORE_DT) = TRUNC(SYSDATE) AND REGION IS NOT NULL\n";
//            sql += "GROUP BY REGION ORDER BY CN DESC) WHERE ROWNUM <= 10";
//        }
//        Query query = em.createNativeQuery(sql);
//        if (!"全国".equals(region)) {
//            query.setParameter(1, region);
//        }
//        return query.getResultList();
//    }


    @Override
    public List<Object> searchByTypeCount(PFCompySearchIn inData) {
        int page = inData.getPage() == 0 ? 0 : inData.getPage() - 1;
        int pageSize = inData.getPageSize() == 0 ? 10 : inData.getPageSize();
        String sql = "SELECT COMPANY_ID,COMPANY_NAME,";
        switch (inData.getType()) {
            case 1:
                sql += "WEIGHT_SCORE FROM PFCOMPY_SCORE WHERE TRUNC(SCORE_DT) = TRUNC(SYSDATE) ORDER BY CAPITAL_SCORE DESC";
                break;
            case 2:
                sql += "WEIGHT_SCORE FROM PFCOMPY_SCORE WHERE TRUNC(SCORE_DT) = TRUNC(SYSDATE) ORDER BY MANAGE_SCORE DESC";
                break;
            case 3:
                sql += "WEIGHT_SCORE FROM PFCOMPY_SCORE WHERE TRUNC(SCORE_DT) = TRUNC(SYSDATE) ORDER BY SINCERITY_SCORE DESC";
                break;
            case 4:
                sql += "WEIGHT_SCORE FROM PFCOMPY_SCORE WHERE TRUNC(SCORE_DT) = TRUNC(SYSDATE) ORDER BY RELATION_SCORE DESC";
                break;
            case 5:
                sql += "WEIGHT_SCORE FROM PFCOMPY_SCORE WHERE TRUNC(SCORE_DT) = TRUNC(SYSDATE) ORDER BY COMPLIANCE_SCORE DESC";
                break;
//            case 6:
//                sql += "CHEAT_SCORE FROM PFCOMPY_SCORE WHERE ROWNUM <= 10 AND TRUNC(SCORE_DT) = TRUNC(SYSDATE) ORDER BY CHEAT_SCORE DESC";
//                break;
//            default:
//                sql += "CAPITAL_SCORE FROM PFCOMPY_SCORE WHERE ROWNUM <= 10 AND TRUNC(SCORE_DT) = TRUNC(SYSDATE) ORDER BY CAPITAL_SCORE DESC";
        }
        Query query = em.createNativeQuery(sql);
        query.setFirstResult(page * pageSize);
        query.setMaxResults(pageSize);
        return query.getResultList();
    }
}
