package com.cscs.portal.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cscs.util.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.response.FacetField;
import org.apache.solr.client.solrj.response.PivotField;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.util.NamedList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.cscs.portal.dto.NewsSearchConditon;
import com.cscs.portal.dto.NewsSearchOut;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.services.NewsSearchServices;

/***
 * 
 * @ClassName: NewsSearchController
 * @Description: 找咨询/新闻舆情相关接口
 * @author: liunn
 * @date: 2018年9月17日 下午2:37:12
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/news/search")
public class NewsSearchController {
	protected final Log logger = LogFactory.getLog(this.getClass());
	//获取24小时负面舆情-风险标签（风险二级标签）
	public static String TYPE_24H = "n_s_type24h";
	//获取24小时负面舆情-新闻列表
	public static String NEGATIVE_NEWS_24H = "n_s_negative24h";
	//获取负面舆论top10
	public static String NEGATIVE_NEWS_TOP10_1 = "n_s_negativetop10_1";
	public static String NEGATIVE_NEWS_TOP10_3 = "n_s_negativetop10_3";
	public static String NEGATIVE_NEWS_TOP10_7 = "n_s_negativetop10_7";
	public static String NEGATIVE_NEWS_TOP10_30 = "n_s_negativetop10_30";
	//获取媒体类型
	public static String MEDIA_TYPE = "n_s_mediatype";
	//风险类型二级标签列表
	public static String RISK_TYPE_LABEL = "n_s_risktypelabel";
	//新闻详情页
	public static String NEWS_DETAIL = "n_s_newsdetail";
	//新闻关联企业列表
	public static String RELATE_COMPANY = "n_s_relatecompany";
	
	@Autowired
    private StringRedisTemplate rt;
	@Autowired
	private NewsSearchServices newsSearchServices;

	/***
     * 
     * @Title: getResult
     * @Description: 获取舆情新闻搜索结果列表
     * @param condition
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/getResult", method = RequestMethod.POST)
    public BaseOutData getResult(@RequestBody NewsSearchConditon condition) {
    	BaseOutData outData = new BaseOutData();
    	List<NewsSearchOut> returnList = new ArrayList<NewsSearchOut>();
    	long numFound = 0L;
    	try {
    		//创建Solr服务对象，通过此对象向solr服务发起请求
    		SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_SENTIMENT_METHOD);
    		//创建查询对象
    		SolrQuery query = new SolrQuery();
    		//设置公共参数
    		query = newsSearchServices.setSolrQuery(condition, query);
    		
    		/*****************************过滤条件start*****************************************/
    		//过滤媒体类型
    		if(StringUtils.isNotEmpty(condition.getMediaType())) {
    			query.addFilterQuery("data_src:\""+condition.getMediaType()+"\"");
    		}
    		//过滤发布时间
    		if(StringUtils.isNotEmpty(condition.getPublishTime())) {
    			String queryString = this.getQueryTime(condition.getPublishTime());
    			query.addFilterQuery("post_dt:"+queryString);
    		}
    		//过滤风险类型
    		if(StringUtils.isNotEmpty(condition.getRiskType())) {
    			String[] riskTypeArr = condition.getRiskType()!=null?condition.getRiskType().split(","):null;
    			for(int i=0;riskTypeArr!=null&&i<riskTypeArr.length;i++) {
    				query.addFilterQuery("sheet_l1:\""+riskTypeArr[i]+"\"");
    			}
    		}
    		/*****************************过滤条件end*****************************************/
    		
    		//执行查询
    		QueryResponse response = solrServer.query(query);
    		//返回的数据量
    		numFound = response.getResults().getNumFound();
    		//返回的数据
    		returnList = newsSearchServices.getResponseDate(response);
    		
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        Map data = new HashMap();
        data.put("result", returnList);
        outData.setCode("0");
        outData.setCount((int)numFound);
        outData.setMessage("返回成功!");
        outData.setData(data);
    	return outData;
    }
    /**
     * 
     * @Title: getType24h
     * @Description: 获取24小时负面舆情-风险标签（风险二级标签）
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/type24h", method = RequestMethod.GET)
    public BaseOutData getType24h() {
    	BaseOutData outData = new BaseOutData();
		List returnList = new ArrayList();
		try {
			//创建Solr服务对象，通过此对象向solr服务发起请求
			SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_SENTIMENT_METHOD);
			//创建查询对象
			SolrQuery query = new SolrQuery();
			//设置公共参数
			query = newsSearchServices.setSolrQuery(new NewsSearchConditon(), query);
			//时间过滤：一周
			query.addFilterQuery("post_dt:[NOW/DAY-7DAY TO NOW/DAY]");
			//过滤负面
			query.addFilterQuery("negtive:1");
			//新闻
			query.addFilterQuery("data_src:新闻");
			query.setFacet(true);
			query.addFacetField("sheet_l1");
			query.setFacetMinCount(1);
			//执行查询
			QueryResponse response = solrServer.query(query);
			FacetField facetField = response.getFacetField("sheet_l1");
			if (facetField != null) {
				Map totalMap = new HashMap();
				totalMap.put("name", "全部");
				totalMap.put("count", response.getResults().getNumFound());
				returnList.add(totalMap);
				List<FacetField.Count> counts = facetField.getValues();
				for (FacetField.Count count : counts) {
					if (!count.getName().equals("None")) {
						Map map = new HashMap();
						map.put("name", count.getName());
						map.put("count", count.getCount());
						returnList.add(map);
					}
				}
			}
		} catch (SolrServerException e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
    	/*Object out = null;
    	List<Map<String,String>> list = null;
    	try {
    		out = rt.opsForValue().get(TYPE_24H);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(Contants.HBASE_NEWS_SEARCH_TYPE24H_URL);
    			if(null!=out) {
    				rt.opsForValue().set(TYPE_24H,out.toString());
    				rt.expire(TYPE_24H, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
    		if(out!=null) {
    			list = (List)JSON.parse(String.valueOf(out));
    			Collections.sort(list, (arg0, arg1) -> {
					Integer intArg1=Integer.valueOf(arg1.get("count"));
					Integer intArg0=Integer.valueOf(arg0.get("count"));
					return intArg1.compareTo(intArg0);
				});
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}*/
        Map data = new HashMap();
    	data.put("result", returnList);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }
    
    /**
     * 
     * @Title: getNegativeNews24h
     * @Description: 获取24小时负面舆情-新闻列表
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/negativeNews24h", method = RequestMethod.POST)
    public Object getNegativeNews24h(@RequestBody Map<String,String> inData) {
    	String curPage = inData.get("curPage");
        String rowNum = inData.get("rowNum");
        String riskType = inData.get("riskType");
        
        BaseOutData outData = new BaseOutData();
        List<Map<String,Object>> returnList;
    	long numFound;
    	try {
    		//创建Solr服务对象，通过此对象向solr服务发起请求
    		SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_SENTIMENT_METHOD);
    		//创建查询对象
    		SolrQuery query = new SolrQuery();
    		//设置公共参数
    		NewsSearchConditon condition = new NewsSearchConditon();
    		condition.setCurPage(StringUtils.isNotEmpty(curPage)?Integer.valueOf(curPage):1);
    		condition.setRowNum(StringUtils.isNotEmpty(rowNum)?Integer.valueOf(rowNum):10);
    		query = newsSearchServices.setSolrQuery(condition, query);
    		
    		/*****************************过滤条件start*****************************************/
    		//过滤风险类型
    		if(StringUtils.isNotEmpty(riskType)) {
    			query.addFilterQuery("sheet_l1:\""+riskType+"\"");
    		}
    		//时间过滤：一周
    		query.addFilterQuery("post_dt:[NOW/DAY-7DAY TO NOW/DAY]");
    		//过滤负面
    		query.addFilterQuery("negtive:1");
    		//新闻
    		query.addFilterQuery("data_src:新闻");
    		/*****************************过滤条件end*****************************************/
    		
    		//执行查询
    		QueryResponse response = solrServer.query(query);
    		//返回的数据量
    		numFound = response.getResults().getNumFound();
    		//返回的数据
    		returnList = newsSearchServices.getNegativeNews24h(response);
    		
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
        Map data = new HashMap();
        data.put("result", returnList);
        outData.setCode("0");
        outData.setCount((int)numFound);
        outData.setMessage("返回成功!");
        outData.setData(data);
    	return outData;
    }

    
    /***
     * 
     * @Title: getNegativeNewsTop10
     * @Description: 企业舆情排行榜
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/negativeNewsRank/{type}", method = RequestMethod.GET)
    public BaseOutData getNegativeNewsRank(@PathVariable int type) {
    	BaseOutData outData = new BaseOutData();
		List returnList = new ArrayList();
		String queryTime = "";
		switch (type) {
			case 1:
				queryTime = "post_dt:[NOW/DAY-1DAY TO NOW/DAY]";
				break;
			case 2:
				queryTime = "post_dt:[NOW/DAY-3DAY TO NOW/DAY]";
				break;
			case 3:
				queryTime = "post_dt:[NOW/DAY-7DAY TO NOW/DAY]";
				break;
			case 4:
				queryTime = "post_dt:[NOW/DAY-30DAY TO NOW/DAY]";
				break;
			default:
				queryTime = "post_dt:[NOW/DAY-1DAY TO NOW/DAY]";
				break;
		}
		try {
			//创建Solr服务对象，通过此对象向solr服务发起请求
			SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_SENTIMENT_METHOD);
			//创建查询对象
			SolrQuery query = new SolrQuery();
			//设置公共参数
			query = newsSearchServices.setSolrQuery(new NewsSearchConditon(), query);
			//时间过滤
			query.addFilterQuery(queryTime);
			//过滤负面
			query.addFilterQuery("negtive:1");
			//新闻
			query.addFilterQuery("data_src:新闻");
			//三星及三星以上
			query.addFilterQuery("relevancy:[3 TO *]");
			query.setFacet(true);
			query.addFacetPivotField("{!key=ccs}company_id,company_nm,sheet_l1");
			query.setFacetMinCount(1);
			query.setFacetLimit(10);
			//执行查询
			QueryResponse response = solrServer.query(query);
			NamedList<List<PivotField>> namedList = response.getFacetPivot();
			List<PivotField> pivotFieldList = namedList.get("ccs");
			for (PivotField pivotField : pivotFieldList) {
				Map rankMap = new HashMap();
				rankMap.put("companyId", pivotField.getValue());
				rankMap.put("negativeNewsCount", pivotField.getCount());
				if (pivotField.getPivot() != null && pivotField.getPivot().size() > 0) {
					PivotField companyNamePivotField = pivotField.getPivot().get(0);
					rankMap.put("companyNm", companyNamePivotField.getValue());
					if (companyNamePivotField.getPivot() != null && companyNamePivotField.getPivot().size() > 0) {
						List<PivotField> sheetL1PivotFieldList = companyNamePivotField.getPivot();
						List warningLabels = new ArrayList();
						for (PivotField sheetL1PivotField : sheetL1PivotFieldList) {
							Map warningLabel = new HashMap();
							warningLabel.put("count", sheetL1PivotField.getCount());
							warningLabel.put("type", sheetL1PivotField.getValue());
							warningLabels.add(warningLabel);
						}
						rankMap.put("warningLabels", warningLabels);
					}
				}
				//查询负面新闻
				List<Map> negativeNewsList = newsSearchServices.getNewsByCompanyId(pivotField.getValue().toString(), queryTime);
				rankMap.put("negativeNewsList", negativeNewsList);

				returnList.add(rankMap);

			}
		} catch (SolrServerException e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
    	/*Object out = null;
    	try {
    		switch (type) {
			case 1:
				out = rt.opsForValue().get(NEGATIVE_NEWS_TOP10_1);
	    		if (out == null) {
	    			out = HttpUtil.getHBaseResponse(Contants.HBASE_NEWS_SEARCH_NEGATIVETOP10_URL1);
	    			if(null!=out) {
	    				List<Map> list = JSON.parseArray(String.valueOf(out), Map.class);
	    				//排序
	    				list = newsSearchServices.negativeNewsRankSort(list);
	    				if(list.size()>10) {
	    					list = list.subList(0, 10);
	        			}
	    				out = list;
	    				rt.opsForValue().set(NEGATIVE_NEWS_TOP10_1,JSON.toJSONString(out));
	    				rt.expire(NEGATIVE_NEWS_TOP10_1, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
	    			}
	    		}else {
	    			out = JSON.parse(out.toString());
	    		}
				break;
			case 2:
				out = rt.opsForValue().get(NEGATIVE_NEWS_TOP10_3);
	    		if (out == null) {
	    			out = HttpUtil.getHBaseResponse(Contants.HBASE_NEWS_SEARCH_NEGATIVETOP10_URL3);
	    			if(null!=out) {
	    				List<Map> list = JSON.parseArray(String.valueOf(out), Map.class);
	    				//排序
	    				list = newsSearchServices.negativeNewsRankSort(list);
	    				if(list.size()>10) {
	    					list = list.subList(0, 10);
	        			}
	    				out = list;
	    				rt.opsForValue().set(NEGATIVE_NEWS_TOP10_3,JSON.toJSONString(out));
	    				rt.expire(NEGATIVE_NEWS_TOP10_3, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
	    			}
	    		}else {
	    			out = JSON.parse(out.toString());
	    		}
				break;
			case 3:
				out = rt.opsForValue().get(NEGATIVE_NEWS_TOP10_7);
				if (out == null) {
					out = HttpUtil.getHBaseResponse(Contants.HBASE_NEWS_SEARCH_NEGATIVETOP10_URL7);
					if(null!=out) {
						List<Map> list = JSON.parseArray(String.valueOf(out), Map.class);
						//排序
	    				list = newsSearchServices.negativeNewsRankSort(list);
	    				if(list.size()>10) {
	    					list = list.subList(0, 10);
	        			}
	    				out = list;
						rt.opsForValue().set(NEGATIVE_NEWS_TOP10_7,JSON.toJSONString(out));
						rt.expire(NEGATIVE_NEWS_TOP10_7, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
					}
				}else {
	    			out = JSON.parse(out.toString());
	    		}
				break;
			case 4:
				out = rt.opsForValue().get(NEGATIVE_NEWS_TOP10_30);
				if (out == null) {
					out = HttpUtil.getHBaseResponse(Contants.HBASE_NEWS_SEARCH_NEGATIVETOP10_URL30);
					if(null!=out) {
						List<Map> list = JSON.parseArray(String.valueOf(out), Map.class);
						//排序
	    				list = newsSearchServices.negativeNewsRankSort(list);
	    				if(list.size()>10) {
	    					list = list.subList(0, 10);
	        			}
	    				out = list;
						rt.opsForValue().set(NEGATIVE_NEWS_TOP10_30,JSON.toJSONString(out));
						rt.expire(NEGATIVE_NEWS_TOP10_30, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
					}
				}else {
	    			out = JSON.parse(out.toString());
	    		}
				break;
			default:
				break;
			}
    		
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}*/
        Map data = new HashMap();
    	data.put("result", returnList);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }
    
    /***
     * 
     * @Title: getMediaType
     * @Description: 获取媒体类型
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/mediaType", method = RequestMethod.POST)
    public BaseOutData getMediaType(@RequestBody Map<String,String> inData) {
		//关键词
		String keyword = inData.get("keyword");
		//
		List<Map> returnList = new ArrayList<>();

		BaseOutData outData = new BaseOutData();
		try {
			//创建Solr服务对象，通过此对象向solr服务发起请求
			SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_SENTIMENT_METHOD);
			//创建查询对象
            NewsSearchConditon condition = new NewsSearchConditon();
            condition.setKeyword(keyword);
            SolrQuery query = new SolrQuery();
            query = newsSearchServices.setSolrQuery(condition, query);
            query.setFacet(true);
			query.set("facet.field", "data_src");
			//执行查询
			QueryResponse response = solrServer.query(query);
			FacetField dataSrc = response.getFacetField("data_src");
			if (dataSrc != null) {
				List<FacetField.Count> counts = dataSrc.getValues();
				for (FacetField.Count count : counts) {
					Map map = new HashMap();
					map.put("name", count.getName());
					map.put("count", count.getCount());
					returnList.add(map);
				}
				Map yb = new HashMap();
				yb.put("name", "研报");
				yb.put("count", "0");
				returnList.add(yb);
			}
		} catch (SolrServerException e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
    	/*Object out = null;
    	try {
    		out = rt.opsForValue().get(MEDIA_TYPE);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(Contants.HBASE_NEWS_SEARCH_MEDIATYPE_URL);
    			if(null!=out) {
    				rt.opsForValue().set(MEDIA_TYPE,out.toString());
    				rt.expire(MEDIA_TYPE, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}*/
        Map data = new HashMap();
    	data.put("result", returnList);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

	/***
	 * 获取发布时间
	 * @param inData
	 * @return
	 */
	@RequestMapping(value = "/publishTime", method = RequestMethod.POST)
	public BaseOutData getPublishTime(@RequestBody Map<String,String> inData) {
		//关键词
		String keyword = inData.get("keyword");
		//
		List returnList = new ArrayList();

		BaseOutData outData = new BaseOutData();
		try {
			//创建Solr服务对象，通过此对象向solr服务发起请求
			SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_SENTIMENT_METHOD);
            //创建查询对象
            NewsSearchConditon condition = new NewsSearchConditon();
            condition.setKeyword(keyword);
            SolrQuery query = new SolrQuery();
            query = newsSearchServices.setSolrQuery(condition, query);
            query.setFacet(true);
			query.addFacetQuery("{!key=1日以内}post_dt:[NOW/DAY-1DAY TO NOW/DAY]");
			query.addFacetQuery("{!key=3日以内}post_dt:[NOW/DAY-3DAY TO NOW/DAY]");
			query.addFacetQuery("{!key=1周以内}post_dt:[NOW/DAY-7DAY TO NOW/DAY]");
			query.addFacetQuery("{!key=1月以内}post_dt:[NOW/DAY-30DAY TO NOW/DAY]");
			//执行查询
			QueryResponse response = solrServer.query(query);
			Map<String, Integer> facetMap = response.getFacetQuery();
			for (Map.Entry<String, Integer> entry : facetMap.entrySet()) {
				Map returnMap = new HashMap();
				returnMap.put("name", entry.getKey());
				returnMap.put("count", entry.getValue());
				returnList.add(returnMap);
			}
		} catch (SolrServerException e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
		Map data = new HashMap();
		data.put("result", returnList);
		outData.setCode("0");
		outData.setMessage("返回成功!");
		outData.setData(data);
		return outData;
	}
    
    /***
     * 
     * @Title: getRiskType
     * @Description: 风险类型一级标签列表
     * @return
     * @return: BaseOutData
     */
    @RequestMapping(value = "/riskType", method = RequestMethod.POST)
    public BaseOutData getRiskType(@RequestBody Map<String,String> inData) {
		//关键词
		String keyword = inData.get("keyword");
		//
		List returnList = new ArrayList();

		BaseOutData outData = new BaseOutData();
		try {
			//创建Solr服务对象，通过此对象向solr服务发起请求
			SolrServer solrServer = SolrUtil.getSolrServer(Contants.SOLR_SERVICE_SENTIMENT_METHOD);
            //创建查询对象
            NewsSearchConditon condition = new NewsSearchConditon();
            condition.setKeyword(keyword);
            SolrQuery query = new SolrQuery();
            query = newsSearchServices.setSolrQuery(condition, query);
			query.addFilterQuery("post_dt:[2018-11-22T00:00:00Z TO *]");
            query.setFacet(true);
			query.set("facet.field", "sheet_l1");
			query.setFacetMinCount(1);
			//执行查询
			QueryResponse response = solrServer.query(query);
			FacetField dataSrc = response.getFacetField("sheet_l1");
			if (dataSrc != null) {
				List<FacetField.Count> counts = dataSrc.getValues();
				for (FacetField.Count count : counts) {
					if (!count.getName().equals("None")) {
						Map map = new HashMap();
						map.put("name", count.getName());
						map.put("count", count.getCount());
						returnList.add(map);
					}
				}
			}
		} catch (SolrServerException e) {
			e.printStackTrace();
			outData.setCode("1");
			outData.setMessage("系统报错!");
			return outData;
		}
    	/*Object out = null;
    	try {
    		out = rt.opsForValue().get(RISK_TYPE_LABEL);
    		if (out == null) {
    			out = HttpUtil.getHBaseResponse(Contants.HBASE_NEWS_SEARCH_RISKTYPELABEL_URL);
    			if(null!=out) {
    				rt.opsForValue().set(RISK_TYPE_LABEL,out.toString());
    				rt.expire(RISK_TYPE_LABEL, Contants.REDIS_TIMEOUT, Contants.REDIS_TIMEUNIT);
    			}
    		}
		} catch (Exception e) {
			e.printStackTrace();
			outData.setCode("1");
            outData.setMessage("系统报错!");
            return outData;
		}*/
        Map data = new HashMap();
    	data.put("result", returnList);
    	outData.setCode("0");
        outData.setMessage("返回成功!");
    	outData.setData(data);
        return outData;
    }

    private String getQueryTime(String foundDt) throws ParseException {
    	String queryStr = "";
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    	SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
    	Date startTime = null;
    	Date endTime = null;
    	String[] foundDtArr = foundDt.split("-");
    	if(foundDtArr!=null && foundDtArr.length>1) {
    		String startDateStr = foundDtArr[0];
    		String endDateStr = foundDtArr[1];
    		startTime = formatter.parse(startDateStr);
			endTime = formatter.parse(endDateStr);
			queryStr = "["+sdf.format(startTime)+" TO "+sdf.format(endTime)+"]";
    	}
    	return queryStr;
    }
    
    private String getHour24() {
		String startStr = DateUtils.formatDate(org.apache.commons.lang3.time.DateUtils.addDays(new Date(), -7), "yyyyMMddHHmmss");
		String endStr = DateUtils.formatDate(new Date(), "yyyyMMddHHmmss");
    	return startStr+"-"+endStr;
    }
}
