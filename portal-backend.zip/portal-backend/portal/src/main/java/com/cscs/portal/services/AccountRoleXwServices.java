package com.cscs.portal.services;

/**
 * Created by dch on 2016/11/7.
 *
 *  账户角色关系
 */
public interface AccountRoleXwServices {

    /**
     * 新增/更新账户角色关系
     * @param accountId 账户ID
     */
    void setAccountRoleXw(Long accountId,String roleNm);

    /**
     * 根据用户ID获取角色信息
     */
    int findAccountRoleById(Long accountId);
    
    public void updateAccountRoleXw(Long accountId,String roleNm);
}
