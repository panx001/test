package com.cscs.portal.services.impl;

import com.alibaba.fastjson.JSON;
import com.cscs.portal.dto.RiskInfoSearchCondition;
import com.cscs.portal.dto.RiskSearchOut;
import com.cscs.portal.services.RiskSearchServices;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/***
 *
 * @ClassName: RiskSearchServicesImpl
 * @Description: 风险高级搜索服务实现类
 * @author: liunn
 * @date: 2018年10月20日 下午4:36:59
 */
@Service
public class RiskSearchServicesImpl implements RiskSearchServices {
    protected final Log logger = LogFactory.getLog(this.getClass());

    //金融债小类
    private static List financeBondList = Arrays.asList(new String[]{"金融租赁公司债", "汽车金融公司债", "其它金融债", "保险公司金融债", "政策性银行债", "政策性银行次级债",
            "特种金融债", "商业银行普通债", "商业银行次级债", "证券公司债", "证券公司短期融资券", "证券公司次级债", "保险公司债", "财务公司债", "券商专项资产管理",
            "混合资本债"});

    @Override
    public SolrQuery setSolrQuery(RiskInfoSearchCondition condition, SolrQuery query) {
        //查询关键字，q不能省略
        if (StringUtils.isNotEmpty(condition.getKeyword())) {
            query.set("q", "fullsearch:" + condition.getKeyword() + ",part_search:\"" + condition.getKeyword() + "\",fuzzy_search:" + condition.getKeyword() + "");
        } else {
            query.set("q", "*:*");
        }
        //查询权重排序
        query.set("defType", "edismax");
        //设置查询权重值
        query.set("qf", "full_search^100 part_search^10 fuzzy_search^0.1");
        //只查询存活的分片
        query.set("shards.tolerant", true);
        //返回字段
        query.set("fl", "score,*");
        //排序
        //参数：field域，排序类型（asc,desc）score desc,regcapital desc
        query.addSort("score", SolrQuery.ORDER.desc);
        query.addSort("dt", SolrQuery.ORDER.desc);
        //分页
        //实际开发时，知道当前页码和每页显示的个数最后求出开始下标
        int curPage = condition.getCurPage() == null ? 1 : condition.getCurPage();
        int rows = condition.getRowNum() == null ? 10 : condition.getRowNum();
        //计算出开始记录下标
        int start = rows * (curPage - 1);
        //向query中设置分页参数
        query.setStart(start);
        query.setRows(rows);
        //开启高亮
        query.setHighlight(true);
        //设置高亮 参数
        query.addHighlightField("company_nm,legal_person_nm,old_company_nm,security_snm,credit_cd,security_cd,chairman,gmanage");
        //设置高亮前缀和后缀
        query.setHighlightSimplePre("<span class=\"highlight\">");
        query.setHighlightSimplePost("</span>");
        return query;
    }

    @Override
    public SolrQuery queryCondition(RiskInfoSearchCondition condition, SolrQuery query) {
        //查询关键字，q不能省略
        if (StringUtils.isNotEmpty(condition.getKeyword())) {
            query.set("q", "fullsearch:" + condition.getKeyword() + ",part_search:\"" + condition.getKeyword() + "\",fuzzy_search:" + condition.getKeyword() + "");
        } else {
            query.set("q", "*:*");
        }
        //查询权重排序
        query.set("defType", "edismax");
        //设置查询权重值
        query.set("qf", "full_search^100 part_search^10 fuzzy_search^0.1");
        //只查询存活的分片
        query.set("shards.tolerant", true);
        //返回字段
        query.set("fl", "score,*");
        //排序
        //参数：field域，排序类型（asc,desc）score desc,regcapital desc
        query.addSort("dt", SolrQuery.ORDER.desc);
        //分页
        //实际开发时，知道当前页码和每页显示的个数最后求出开始下标
        int curPage = condition.getCurPage() == null ? 1 : condition.getCurPage();
        int rows = condition.getRowNum() == null ? 10 : condition.getRowNum();
        //计算出开始记录下标
        int start = rows * (curPage - 1);
        //向query中设置分页参数
        query.setStart(start);
        query.setRows(rows);
        return query;
    }

    @Override
    public List<RiskSearchOut> getResponseDate(QueryResponse response) {
        List<RiskSearchOut> returnList = new ArrayList<RiskSearchOut>();
        //从响应中得到结果
        SolrDocumentList documents = response.getResults();

        //从响应中获得高亮信息
        Map<String, Map<String, List<String>>> highlighting = response.getHighlighting();

        for (SolrDocument document : documents) {
            RiskSearchOut data = new RiskSearchOut();
            if (null != document.get("company_id")) {
                data.setCompanyId(String.valueOf(document.get("company_id")));
            }
            if (null != document.get("company_nm")) {
                data.setCompanyName(String.valueOf(document.get("company_nm")));
            }
            if (null != document.get("risk_type")) {
                data.setRiskType(String.valueOf(document.get("risk_type")));
            }
            if (null != document.get("bondtype")) {
                data.setBondtype(String.valueOf(document.get("bondtype")));
            }
            if (null != document.get("company_type")) {
                data.setCompanyType(String.valueOf(document.get("company_type")));
            }
            if (null != document.get("company_st")) {
                data.setCompanySt(String.valueOf(document.get("company_st")));
            }
            if (null != document.get("legal_person_nm")) {
                data.setLegalPersonName(String.valueOf(document.get("legal_person_nm")));
            }
            if (null != document.get("gmanager")) {
                data.setGmanager(String.valueOf(document.get("gmanager")));
            }
            if (null != document.get("regcapital")) {
                data.setRegCapital(String.valueOf(document.get("regcapital")));
            }
            if (null != document.get("reg_region")) {
                data.setOfficeAddr(String.valueOf(document.get("reg_region")));
            }
            if (null != document.get("industry")) {
                data.setIndustry(String.valueOf(document.get("industry")));
            }
            if (null != document.get("found_dt")) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                data.setFoundDt(sdf.format((Date) document.get("found_dt")));
            }
            System.out.println(document.get("dt"));
            if (null != document.get("dt")) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                data.setDt(sdf.format((Date) document.get("dt")));
            }
            if (null != document.get("old_company_nm")) {
                data.setOldCompanyNm(String.valueOf(document.get("old_company_nm")));
            }
            if (null != document.get("credit_cd")) {
                data.setCreditCd(String.valueOf(document.get("credit_cd")));
            }
            if (null != document.get("chairman")) {
                data.setChairman(String.valueOf(document.get("chairman")));
            }
            if (null != document.get("security_snm")) {
                List list = (List) document.get("security_snm");
                data.setSecuritySnm(list);
            }
            if (null != document.get("security_cd")) {
                List list = (List) document.get("security_cd");
                data.setSecurityCd(list);
            }
            if (null != document.get("auditadvice")) {
                data.setAuditadvice(String.valueOf(document.get("auditadvice")));
            }
            if (null != document.get("risk_json")) {
                data.setRiskJson(JSON.parse(String.valueOf(document.get("risk_json"))));
            }
            //获得高亮的信息
            if (highlighting != null) {
                //根据主键获取高亮信息
                Map<String, List<String>> map = highlighting.get(document.get("id"));
                if (map != null) {
                    //存储高亮字段
                    List highlightColumns = new ArrayList();
                    List<String> companyNameList = map.get("company_nm");
                    List<String> legalPersonNmList = map.get("legal_person_nm");
                    List<String> oldCompanyNmList = map.get("old_company_nm");
                    List<String> creditCdList = map.get("credit_cd");
                    List<String> chairmanList = map.get("chairman");
                    List<String> gmanagerList = map.get("gmanager");
                    if (companyNameList != null) {
                        //高亮-企业名称
                        data.setCompanyName(companyNameList.get(0));
                        highlightColumns.add("companyName");
                    }
                    if (legalPersonNmList != null) {
                        //高亮-法定代表人
                        data.setLegalPersonName(legalPersonNmList.get(0));
                        highlightColumns.add("legalPersonName");
                    }
                    if (oldCompanyNmList != null) {
                        //高亮-曾用名
                        data.setOldCompanyNm(oldCompanyNmList.get(0));
                        highlightColumns.add("oldCompanyNm");
                    }
                    if (creditCdList != null) {
                        //高亮-社会信用代码
                        data.setCreditCd(creditCdList.get(0));
                        highlightColumns.add("creditCd");
                    }
                    if (chairmanList != null) {
                        //高亮-董事长
                        data.setChairman(chairmanList.get(0));
                        highlightColumns.add("chairman");
                    }
                    if (gmanagerList != null) {
                        //高亮-总经理
                        data.setGmanager(gmanagerList.get(0));
                        highlightColumns.add("gmanager");
                    }
                    data.setHighlightColumns(highlightColumns);
                }
            }
            returnList.add(data);
        }
        return returnList;
    }

    @Override
    public List<RiskSearchOut> getBondDefaultsResult(QueryResponse response) {
        List<RiskSearchOut> returnList = new ArrayList<RiskSearchOut>();
        //从响应中得到结果
        SolrDocumentList documents = response.getResults();

        //从响应中获得高亮信息
        Map<String, Map<String, List<String>>> highlighting = response.getHighlighting();

        for (SolrDocument document : documents) {
            RiskSearchOut data = new RiskSearchOut();
            if (null != document.get("company_id")) {
                data.setCompanyId(String.valueOf(document.get("company_id")));
            }
            if (null != document.get("company_nm")) {
                data.setCompanyName(String.valueOf(document.get("company_nm")));
            }
            if (null != document.get("risk_type")) {
                data.setRiskType(String.valueOf(document.get("risk_type")));
            }
            if (null != document.get("bondtype")) {
                data.setBondtype(String.valueOf(document.get("bondtype")));
            }
            if (null != document.get("company_type")) {
                data.setCompanyType(String.valueOf(document.get("company_type")));
            }
            if (null != document.get("company_st")) {
                data.setCompanySt(String.valueOf(document.get("company_st")));
            }
            if (null != document.get("legal_person_nm")) {
                data.setLegalPersonName(String.valueOf(document.get("legal_person_nm")));
            }
            if (null != document.get("gmanager")) {
                data.setGmanager(String.valueOf(document.get("gmanager")));
            }
            if (null != document.get("regcapital")) {
                data.setRegCapital(String.valueOf(document.get("regcapital")));
            }
            if (null != document.get("reg_region")) {
                data.setOfficeAddr(String.valueOf(document.get("reg_region")));
            }
            if (null != document.get("industry")) {
                data.setIndustry(String.valueOf(document.get("industry")));
            }
            if (null != document.get("found_dt")) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                data.setFoundDt(sdf.format((Date) document.get("found_dt")));
            }
            System.out.println(document.get("dt"));
            if (null != document.get("dt")) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                data.setDt(sdf.format((Date) document.get("dt")));
            }
            if (null != document.get("old_company_nm")) {
                data.setOldCompanyNm(String.valueOf(document.get("old_company_nm")));
            }
            if (null != document.get("credit_cd")) {
                data.setCreditCd(String.valueOf(document.get("credit_cd")));
            }
            if (null != document.get("chairman")) {
                data.setChairman(String.valueOf(document.get("chairman")));
            }
            if (null != document.get("security_snm")) {
                List list = (List) document.get("security_snm");
                data.setSecuritySnm(list);
            }
            if (null != document.get("security_cd")) {
                List list = (List) document.get("security_cd");
                data.setSecurityCd(list);
            }
            if (null != document.get("auditadvice")) {
                data.setAuditadvice(String.valueOf(document.get("auditadvice")));
            }
            if (null != document.get("risk_json")) {
                data.setRiskJson(JSON.parse(String.valueOf(document.get("risk_json"))));
            }
            returnList.add(data);
        }
        for (RiskSearchOut risk : returnList) {
            Object obj = risk.getRiskJson();
            if (obj != null) {
                Map map = (Map) obj;
                List<Map<String, String>> list = (List) map.get("bondViolationList");
                if (list != null) {
                    //排序
                    Collections.sort(list, new Comparator<Map<String, String>>() {
                        public int compare(Map<String, String> arg0, Map<String, String> arg1) {
                            return arg1.get("noticeDt").compareTo(arg0.get("noticeDt"));
                        }
                    });
                }
                map.put("bondViolationList", list);
                //金融债替换
                if (risk.getBondtype().equals("金融债")) {
                    if (financeBondList.contains(map.get("bondType"))) {
                        map.put("bondType", "金融债");
                    }
                }
                risk.setRiskJson(map);
            }
        }
        return returnList;
    }

    @Override
    public List<Map<String, String>> getFinancialRiskStaList(QueryResponse response) {
        List<Map<String, String>> returnList = new ArrayList<Map<String, String>>();
        //从响应中得到结果
        SolrDocumentList documents = response.getResults();

        //从响应中获得高亮信息
        Map<String, Map<String, List<String>>> highlighting = response.getHighlighting();

        for (SolrDocument document : documents) {
            if (null != document.get("risk_json")) {
                returnList.add((Map) JSON.parse(String.valueOf(document.get("risk_json"))));
            }
        }
        //排序
        Collections.sort(returnList, new Comparator<Map<String, String>>() {
            public int compare(Map<String, String> arg0, Map<String, String> arg1) {
                return arg1.get("reportYear").compareTo(arg0.get("reportYear"));
            }
        });
        return returnList;
    }


    @Override
    public String getQueryTime(String foundDt) throws ParseException {
        String queryStr = "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
        Date startTime = null;
        Date endTime = null;
        String[] foundDtArr = foundDt.split("-");
        if (foundDtArr != null && foundDtArr.length > 1) {
            String startDateStr = foundDtArr[0];
            String endDateStr = foundDtArr[1];
            startTime = formatter.parse(startDateStr);
            endTime = formatter.parse(endDateStr);
            queryStr = "found_dt:[" + sdf.format(startTime) + " TO " + sdf.format(endTime) + "]";
        }
        return queryStr;
    }

    @Override
    public String getQueryTime(String startDt, String endDt) throws ParseException {
        String queryStr = "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
        Date startTime = formatter.parse(startDt);
        Date endTime = formatter.parse(endDt);
        queryStr = "[" + sdf.format(startTime) + " TO " + sdf.format(endTime) + "]";
        return queryStr;
    }

    @Override
    public String getQueryTime2(String foundDt) throws ParseException {
        String queryStr = "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
        Date startTime = null;
        Date endTime = null;
        String[] foundDtArr = foundDt.split("-");
        if (foundDtArr != null && foundDtArr.length > 1) {
            String startDateStr = foundDtArr[0];
            String endDateStr = foundDtArr[1];
            startTime = formatter.parse(startDateStr);
            endTime = formatter.parse(endDateStr);
            queryStr = "[" + sdf.format(startTime) + " TO " + sdf.format(endTime) + "]";
        }
        return queryStr;
    }
}
