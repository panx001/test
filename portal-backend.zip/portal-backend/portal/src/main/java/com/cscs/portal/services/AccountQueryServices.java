package com.cscs.portal.services;

import com.cscs.portal.dto.AccountQueryInData;
import com.cscs.portal.dto.AccountQueryInfoData;
import com.cscs.portal.entity.Account;
import com.cscs.portal.entity.UserBasicinfo;

import java.util.List;

/**
 * Created by dch on 2016/11/14.
 * 账户查询接口
 */
public interface AccountQueryServices {
    //账户查询
    List<Object> findAccountAll(AccountQueryInfoData infoData);

    //账户查询(条数)
    int findAccountCount(AccountQueryInfoData infoData);

    //保存账户信息
    int saveAccount(AccountQueryInData inData);

    //账户查询
    int findByAccountNm(String AccountNm);

    //账户基础保存
    UserBasicinfo saveBasic(UserBasicinfo info);

//    //账户保存
//    Account saveAccount(Account account);

    //账户密码修正
    void updateUserPwd(String accountNm, String pwd);
    
    public int updateAccount(AccountQueryInData inData);

    //账户导出查询
    List<Object> findAccountAllNoPaging(AccountQueryInfoData infoData);
}
