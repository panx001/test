package com.cscs.portal.dto;

/**
 * Created by dch on 2016/11/14.
 * 账户查询出参
 */
public class AccountQueryOutData{
    private String accountNm;//账户名
    private String regeditDt;//注册时间
    private String roleNm;
    private long userId;

    public String getAccountNm() {
        return accountNm;
    }

    public void setAccountNm(String accountNm) {
        this.accountNm = accountNm;
    }

    public String getRegeditDt() {
        return regeditDt;
    }

    public void setRegeditDt(String regeditDt) {
        this.regeditDt = regeditDt;
    }

    public String getRoleNm() {
        return roleNm;
    }

    public void setRoleNm(String roleNm) {
        this.roleNm = roleNm;
    }

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}
    
    
}
