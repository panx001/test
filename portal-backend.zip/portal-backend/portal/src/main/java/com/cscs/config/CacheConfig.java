package com.cscs.config;

import com.cscs.util.StringUtil;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisNode;
import org.springframework.data.redis.connection.RedisSentinelConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 使用Redis作为缓存。替换ehcache。
 */
@Configuration
@EnableCaching
public class CacheConfig extends CachingConfigurerSupport {

  @Value("${spring.redis.host}")
  String host;
  @Value("${spring.redis.port}")
  int port;
  @Value("${spring.redis.password}")
  String password;
  @Value("${spring.redis.sentinel.master}")
  String master;
  @Value("${spring.redis.sentinel.nodes}")
  String nodes;
  @Value("${spring.redis.timeout}")
  int timeout;
  @Value("${spring.redis.commandTimeout}")
  private int commandTimeout;

  @Value("${spring.redis.pool.max-active}")
  private int maxActive;
  @Value("${spring.redis.pool.max-idle}")
  private int maxIdle;
  @Value("${spring.redis.pool.max-wait}")
  private long maxWaitMillis;
  @Value("${spring.redis.pool.max-redirects}")
  private int maxRedirects;

  @Value("${spring.redis.cluster.nodes}")
  private String clusterNodes;

  static final RedisSentinelConfiguration SENTINEL_CONFIG = new RedisSentinelConfiguration()
      .master("T1") //
      .sentinel("106.14.30.97", 26379) //
      .sentinel("106.14.30.97", 26380) //
      .sentinel("106.14.30.97", 26381);

  @Bean(name = "customPool")
  public JedisPool jedisPool() {
    JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
    jedisPoolConfig.setMaxTotal(maxActive);
    jedisPoolConfig.setMaxIdle(maxIdle);
    jedisPoolConfig.setMaxWaitMillis(maxWaitMillis);

    JedisPool jedisPool = new JedisPool(jedisPoolConfig, host, port, timeout, password);

    return jedisPool;
  }

  /************************************************集群配置****************************************************************/
  @Lazy
  @Bean
  public JedisCluster getJedisCluster() {
    String[] cNodes = clusterNodes.split(",");
    Set<HostAndPort> nodes = new HashSet<>();
    //分割出集群节点
    for (String node : cNodes) {
      String[] hp = node.split(":");
      nodes.add(new HostAndPort(hp[0], Integer.parseInt(hp[1])));
    }
    JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
    jedisPoolConfig.setMaxIdle(maxIdle);
    jedisPoolConfig.setMaxWaitMillis(maxWaitMillis);
    jedisPoolConfig.setTestOnBorrow(true);
    jedisPoolConfig.setTestWhileIdle(true);

    //创建集群对象
    JedisCluster jedisCluster = new JedisCluster(nodes, commandTimeout, timeout, 10, password, jedisPoolConfig);
    return jedisCluster;
  }
  /**
   * 配置 Redis 连接池信息
   */
  @Lazy
  @Bean
  public JedisPoolConfig getJedisPoolConfig() {
    JedisPoolConfig jedisPoolConfig =new JedisPoolConfig();
    jedisPoolConfig.setMaxIdle(maxIdle);
    jedisPoolConfig.setMaxWaitMillis(maxWaitMillis);
    jedisPoolConfig.setTestOnBorrow(true);
    jedisPoolConfig.setTestWhileIdle(true);

    return jedisPoolConfig;
  }

  /**
   * 配置 Redis Cluster 信息
   */
  @Lazy
  @Bean
  public RedisClusterConfiguration getJedisClusterConfiguration() {
    RedisClusterConfiguration redisClusterConfiguration = new RedisClusterConfiguration();
    redisClusterConfiguration.setMaxRedirects(maxRedirects);

    List<RedisNode> nodeList = new ArrayList<>();

    String[] cNodes = clusterNodes.split(",");
    //分割出集群节点
    for(String node : cNodes) {
      String[] hp = node.split(":");
      nodeList.add(new RedisNode(hp[0], Integer.parseInt(hp[1])));
    }
    redisClusterConfiguration.setClusterNodes(nodeList);

    return redisClusterConfiguration;
  }
  /************************************************集群配置****************************************************************/

  @Bean
  public JedisConnectionFactory redisConnectionFactory() {
    JedisConnectionFactory cf;
    if (!StringUtil.isEmpty(clusterNodes)) {
      JedisPoolConfig jedisPoolConfig =  this.getJedisPoolConfig();
      RedisClusterConfiguration redisClusterConfiguration = this.getJedisClusterConfiguration();
      cf = new JedisConnectionFactory(redisClusterConfiguration, jedisPoolConfig);
    }else if (StringUtil.isEmpty(master) || StringUtil.isEmpty(nodes)) {
      cf = new JedisConnectionFactory();
      cf.setHostName(host);
      cf.setPort(port);
      cf.setTimeout(timeout);
    } else {

      RedisSentinelConfiguration sentinelConfiguration = new RedisSentinelConfiguration();
      sentinelConfiguration.master(master);
      String[] nodes = this.nodes.split(",");
      for (String node : nodes) {
        String[] items = node.split(":");
        String ip = items[0].trim();
        int port = Integer.valueOf(items[1].trim());
        sentinelConfiguration.sentinel(ip, port);
      }
      cf = new JedisConnectionFactory(sentinelConfig());
    }

    if (!StringUtil.isEmpty(password)) {
      cf.setPassword(password);
    }

    return cf;
  }

  @Bean
  public RedisSentinelConfiguration sentinelConfig() {
    return SENTINEL_CONFIG;
  }

  /*@Bean
  public RedisTemplate<String, String> redisTemplate(RedisConnectionFactory cf) {
    RedisTemplate<String, String> redisTemplate = new RedisTemplate<String, String>();
    redisTemplate.setConnectionFactory(cf);
    return redisTemplate;
  }*/

  /**
   * 设置数据存入redis 的序列化方式
   * </br>redisTemplate序列化默认使用的jdkSerializeable,存储二进制字节码,导致key会出现乱码，所以自定义
   * 序列化类
   *
   * @paramredisConnectionFactory
   */
  @Bean
  public RedisTemplate<Object, Object> redisTemplate(RedisConnectionFactory redisConnectionFactory) throws UnknownHostException {
    RedisTemplate<Object, Object> redisTemplate = new RedisTemplate<>();
    redisTemplate.setConnectionFactory(redisConnectionFactory);
    Jackson2JsonRedisSerializer jackson2JsonRedisSerializer = new Jackson2JsonRedisSerializer(Object.class);
    ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
    objectMapper.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
    jackson2JsonRedisSerializer.setObjectMapper(objectMapper);

    redisTemplate.setValueSerializer(jackson2JsonRedisSerializer);
    redisTemplate.setKeySerializer(new StringRedisSerializer());
    redisTemplate.setHashKeySerializer(new StringRedisSerializer());

    redisTemplate.afterPropertiesSet();

    return redisTemplate;
  }

  @Bean
  public CacheManager cacheManager(RedisTemplate redisTemplate) {
    RedisCacheManager cacheManager = new RedisCacheManager(redisTemplate);
    return cacheManager;
  }
  
  @Override
  @Bean
  public KeyGenerator keyGenerator() {
      return (target, method, params) -> {
          StringBuilder sb = new StringBuilder();
          sb.append(target.getClass().getName());
          sb.append(method.getName());
          for (Object obj : params) {
              sb.append(obj.toString());
          }
          return sb.toString();
      };
  }


}
