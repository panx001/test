package com.cscs.portal.dto;

import com.cscs.portal.dto.base.BaseOutData;

/**
 * Created by levy on 2017/12/2.
 * 接口界面出参
 */
public class InterFaceOutData extends BaseOutData{
    private long interfaceId;//Id
    private String interfaceNm;//接口名称
    private String interfaceUrl;//接口地址
    private String ctlType;//页面类型
    private String ctlNm;//页面名称

    public long getInterfaceId() {
        return interfaceId;
    }

    public void setInterfaceId(long interfaceId) {
        this.interfaceId = interfaceId;
    }

    public String getInterfaceNm() {
        return interfaceNm;
    }

    public void setInterfaceNm(String interfaceNm) {
        this.interfaceNm = interfaceNm;
    }

    public String getInterfaceUrl() {
        return interfaceUrl;
    }

    public void setInterfaceUrl(String interfaceUrl) {
        this.interfaceUrl = interfaceUrl;
    }

    public String getCtlType() {
        return ctlType;
    }

    public void setCtlType(String ctlType) {
        this.ctlType = ctlType;
    }

    public String getCtlNm() {
        return ctlNm;
    }

    public void setCtlNm(String ctlNm) {
        this.ctlNm = ctlNm;
    }
}
