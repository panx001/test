package com.cscs.portal.dto;

/**
 * Created by levy on 2017/12/2.
 *
 */
public class InterFaceQueryInfoData {
    private Long interfaceId;
    private String interfaceNm;
    private String interfaceUrl;
    private String interfaceCtlType;
    private String interfaceCtlNm;
    private int page;

    public Long getInterfaceId() {
        return interfaceId;
    }

    public void setInterfaceId(Long interfaceId) {
        this.interfaceId = interfaceId;
    }

    public String getInterfaceNm() {
        return interfaceNm;
    }

    public void setInterfaceNm(String interfaceNm) {
        this.interfaceNm = interfaceNm;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public String getInterfaceUrl() {
        return interfaceUrl;
    }

    public void setInterfaceUrl(String interfaceUrl) {
        this.interfaceUrl = interfaceUrl;
    }

    public String getInterfaceCtlType() {
        return interfaceCtlType;
    }

    public void setInterfaceCtlType(String interfaceCtlType) {
        this.interfaceCtlType = interfaceCtlType;
    }

    public String getInterfaceCtlNm() {
        return interfaceCtlNm;
    }

    public void setInterfaceCtlNm(String interfaceCtlNm) {
        this.interfaceCtlNm = interfaceCtlNm;
    }
}
