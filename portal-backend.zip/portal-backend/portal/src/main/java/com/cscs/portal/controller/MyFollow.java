package com.cscs.portal.controller;

import com.cscs.portal.dto.UserFollowInfoData;
import com.cscs.portal.dto.base.BaseOutData;
import com.cscs.portal.entity.UserFollow;
import com.cscs.portal.services.MyFollowService;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping(value = "/myFollow")
public class MyFollow {

    @Autowired
    private MyFollowService myFollowService;
    
    @Autowired
    private CompanyBasicInfoController companyBasicInfoController;

    /**
     * 我的关注企业列表
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public List<Map<String,Object>> list(HttpServletRequest request) {
        List<Map<String,Object>> outData = new ArrayList<>();
        Long userId = Long.valueOf((String)request.getAttribute("userId"));
        List<Object> itemList = myFollowService.listCompanys(userId);
        //UserFollowInfoData info =null;
        BaseOutData companyBasicResp = null;
        Map<String,Object> companyBasicInfo = null;
        Object[] item = null;
        for (int i = 0; i < itemList.size(); i++) {
        	item = (Object[]) itemList.get(i);
        	companyBasicResp = (BaseOutData) companyBasicInfoController.getBasicInfo(item[1].toString());
        	if("0".equals(companyBasicResp.getCode())&&companyBasicResp.getData()!=null&&companyBasicResp.getData().get("result")!=null) {
        		companyBasicInfo =  (Map<String,Object>)companyBasicResp.getData().get("result");
        		Long isMonitor = Long.valueOf(item[2].toString());
        		Long monitorId = Long.valueOf(item[3].toString());
        		companyBasicInfo.put("isMonitored", isMonitor == 0L ? "0" : "1");
        		companyBasicInfo.put("companyId", item[1].toString());
        		companyBasicInfo.put("focusId", item[0].toString());
        		if(monitorId!=0L) {
        			companyBasicInfo.put("monitorId", item[3].toString());
        		}
        		outData.add(companyBasicInfo);
        	}
        	//info = new UserFollowInfoData();
//            info.setId(Long.valueOf(item[0].toString()));
//            info.setCompanyId(Long.valueOf(item[1].toString()));
//            Long isMonitor = Long.valueOf(item[2].toString());
//            info.setIsMonitor(isMonitor == 0L ? 0L : 1L);
            
        }
        return outData;
    }

    /**
     * 关注企业
     */
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public BaseOutData save(HttpServletRequest request,@RequestBody UserFollowInfoData infoData) {
        BaseOutData outData = new BaseOutData();
        try {
            UserFollow info = new UserFollow();
            Long userId = Long.valueOf((String)request.getAttribute("userId"));
            infoData.setUserId(userId);
            BeanUtils.copyProperties(infoData, info);
            info.setDt(new Date());
            info.setIsdel(0L);
            List<UserFollow> existFollowList = myFollowService.queryFollowByCondition(info);
            if(!CollectionUtils.isEmpty(existFollowList)) {
            	info.setId(existFollowList.get(0).getId());
            }	
            myFollowService.save(info);
            outData.setCode("0");
        } catch (Exception ex) {
            outData.setCode("1");
        }
        return outData;
    }

    /**
     * 取消关注企业 USER_FOLLOW.ID
     */
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
    public BaseOutData unMonitor(HttpServletRequest request,@PathVariable Long id) {
        BaseOutData outData = new BaseOutData();
        Long userId = Long.valueOf((String)request.getAttribute("userId"));
        try {
            myFollowService.delete(id,userId);
            outData.setCode("0");
        } catch (Exception ex) {
            outData.setCode("1");
        }
        return outData;
    }
}
