package com.cscs.portal.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "USER_SYSTEM_NOTIFICATION", schema = "CS_PORTAL", catalog = "")
public class UserSystemNotification {
    private long id;
    private long systemNotificationId;
    private Long isdel;
    private Long userid;
    private Long isread;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_USER_SYSTEM_NOTIFICATION")
    @SequenceGenerator(sequenceName = "SEQ_USER_SYSTEM_NOTIFICATION", name = "SEQ_USER_SYSTEM_NOTIFICATION")
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "SYSTEM_NOTIFICATION_ID")
    public long getSystemNotificationId() {
        return systemNotificationId;
    }

    public void setSystemNotificationId(long systemNotificationId) {
        this.systemNotificationId = systemNotificationId;
    }

    @Basic
    @Column(name = "ISDEL")
    public Long getIsdel() {
        return isdel;
    }

    public void setIsdel(Long isdel) {
        this.isdel = isdel;
    }

    @Basic
    @Column(name = "USERID")
    public Long getUserid() {
        return userid;
    }

    public void setUserid(Long userid) {
        this.userid = userid;
    }

    @Basic
    @Column(name = "ISREAD")
    public Long getIsread() {
        return isread;
    }

    public void setIsread(Long isread) {
        this.isread = isread;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UserSystemNotification that = (UserSystemNotification) o;
        return id == that.id &&
                systemNotificationId == that.systemNotificationId &&
                Objects.equals(isdel, that.isdel) &&
                Objects.equals(userid, that.userid) &&
                Objects.equals(isread, that.isread);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, systemNotificationId, isdel, userid, isread);
    }
}
