package com.cscs.portal.services;

import com.cscs.portal.dto.NewsWarningInData;

import java.util.List;

/**
 * Created by sh on 2017/10/27.
 */
public interface NewsWarningServices {


    //趋势图
    public List<Object> findchart(NewsWarningInData inData);

}
