package com.cscs.repository;

import com.cscs.portal.entity.UserTrace;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Date;

/**
 * Created by dch on 2016/11/14.
 * 用户跟踪信息
 */
@SuppressWarnings("JpaQlInspection")
public interface UserTraceRepository extends JpaRepository<UserTrace,Long> {


    @Query(value = "select max(an.userTraceId) from UserTrace an where an.userId=:userId")
    Long findUserTraceByUserId(@Param("userId") Long userId);

    @Query(value = "select ut from UserTrace ut where ut.visitDt between :start and :stop")
    List<UserTrace> findUserTraceByPeriod(@Param("start") Date start, @Param("stop") Date stop);
}
