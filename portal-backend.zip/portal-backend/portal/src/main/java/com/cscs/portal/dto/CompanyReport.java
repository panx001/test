package com.cscs.portal.dto;

import com.cscs.portal.dto.base.BaseOutData;

import java.util.List;

/**
 * Created by sh on 2016/8/29.
 */
public class CompanyReport extends BaseOutData {

    public List<Object> getCompyReport() {
        return compyReport;
    }

    public void setCompyReport(List<Object> compyReport) {
        this.compyReport = compyReport;
    }

    List<Object> compyReport;


}
