package com.cscs.portal.dto;

/**
 *   私募机构查询条件

 * @ClassName: NewsSearchConditon

 * @Description: TODO

 * @author: liunn

 * @date: 2018年9月13日 上午11:33:31
 */
public class PsecSearchConditon{
	//搜索框关键字
    private String keyword;
    //当前页
    private Integer curPage;
    //每页显示的条数
    private Integer rowNum;
    //成立时间
    private String foundDt;
	//登记时间
	private String regDt;
    //基金备案阶段
    private String regPhase;
    //机构类型
    private String orgType;
    //管理类型
    private String manageType;
    //运作状态
    private String state;
    //诚信信息
    private String integrityInfo;
    //提示事项
    private String tipInfo;
    
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public Integer getCurPage() {
		return curPage;
	}
	public void setCurPage(Integer curPage) {
		this.curPage = curPage;
	}
	public Integer getRowNum() {
		return rowNum;
	}
	public void setRowNum(Integer rowNum) {
		this.rowNum = rowNum;
	}
	public String getFoundDt() {
		return foundDt;
	}
	public void setFoundDt(String foundDt) {
		this.foundDt = foundDt;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	public String getRegPhase() {
		return regPhase;
	}
	public void setRegPhase(String regPhase) {
		this.regPhase = regPhase;
	}
	public String getOrgType() {
		return orgType;
	}
	public void setOrgType(String orgType) {
		this.orgType = orgType;
	}
	public String getManageType() {
		return manageType;
	}
	public void setManageType(String manageType) {
		this.manageType = manageType;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getIntegrityInfo() {
		return integrityInfo;
	}
	public void setIntegrityInfo(String integrityInfo) {
		this.integrityInfo = integrityInfo;
	}
	public String getTipInfo() {
		return tipInfo;
	}
	public void setTipInfo(String tipInfo) {
		this.tipInfo = tipInfo;
	}
}
