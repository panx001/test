#打包代码
./build.sh

#启动docker
./run.sh {container_name} {port}
example:
./run.sh portal 7080

#关闭docker容器
./stop.sh {container_name}
example:
./run.sh portal