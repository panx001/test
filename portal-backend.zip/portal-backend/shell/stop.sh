#! /bin/sh

echo $0
echo "name-$1"
docker stop $1
docker rm $1