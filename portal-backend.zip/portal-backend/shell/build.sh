#! /bin/sh

cd ../portalsecurity
pwd
mvn install
cd ../portal
mvn clean install -P test -DskipTests