#! /bin/sh

echo $0
echo "name-$1"
echo "port-$2"

cd ../docker
cp ../portal/target/portal.war .
./docker-build.sh
docker run --name $1 -d -p $2:8080 tomcat-portal