code_path=/d/sourcecode
docker_path=$code_path/dockercompose
front_path=$code_path/portal-frontend
wap_path=$code_path/portal-mobile-develop
manage_path=$code_path/portal-management-system-develop
portal_path=$code_path/portal-backend
beneficial_path=$code_path/beneficialowner_develop/webservice

echo 'front start';
cd $front_path
npm install
npm run build
cp -rf dist/portal/* $docker_path/front/portal
echo 'front end';

echo '------------------------------------------------';

echo 'wap start';
cd $wap_path
npm install
npm run build
cp -rf dist/portal/* $docker_path/wap/portal
echo 'wap end';

echo '------------------------------------------------';

echo 'manage start';
cd $manage_path
npm install
npm run build
cp -rf dist/portal/* $docker_path/manage/portal
echo 'manage end';

echo '------------------------------------------------';

echo 'portal start';
cd $portal_path/portalsecurity
mvn clean install
cd $portal_path/portal
mvn clean install -DskipTests
cp -rf target/portal.war $docker_path/portal/
echo 'portal end';

echo '------------------------------------------------';

echo 'beneficial start';
cd $beneficial_path
mvn clean install -DskipTests
cp -rf target/beneficialowner.war $docker_path/beneficial/
echo 'beneficial end';