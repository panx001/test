#docker-compose stop
#docker-compose rm -f -s
docker-compose down
./build.sh
docker-compose pull
docker-compose build
docker-compose up -d