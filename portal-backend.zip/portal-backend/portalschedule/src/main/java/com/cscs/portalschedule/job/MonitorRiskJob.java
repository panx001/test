package com.cscs.portalschedule.job;

import com.cscs.portalschedule.Contants;
import com.cscs.portalschedule.entity.UserMonitorXw;
import com.cscs.portalschedule.service.MyMonitorService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.PersistJobDataAfterExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@PersistJobDataAfterExecution
@DisallowConcurrentExecution
public class MonitorRiskJob extends QuartzJobBean {
    private final static Log logger = LogFactory.getLog(MonitorRiskJob.class);
    @Autowired
    private MyMonitorService myMonitorService;

    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
        logger.info("MonitorRiskJob:start");
        try {
            QueryResponse response = null;
            SolrDocumentList solrDocumentList = null;
            String cursor = "*";
            List<UserMonitorXw> companiesList = null;
            UserMonitorXw userMonitorXw = null;

            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DATE, -14);
            Date time = cal.getTime();
            String startDateStr = new SimpleDateFormat("yyyy-MM-dd").format(time);
            Date toTime = new Date();
            String toDateStr = new SimpleDateFormat("yyyy-MM-dd").format(toTime);
            do {
                companiesList = new ArrayList<>();
                try {
                    response = getCompanyRisksByPaging(cursor, startDateStr, toDateStr);
                } catch (SolrServerException e) {
                    e.printStackTrace();
                }
                solrDocumentList = response.getResults();
                for (SolrDocument solrDocument : solrDocumentList) {
                    if(myMonitorService.findMonitorXWByRiskId(String.valueOf(solrDocument.get("id")))>0){
                        continue;
                    }
                    userMonitorXw = new UserMonitorXw();
                    userMonitorXw.setCompanyId(Long.parseLong(String.valueOf(solrDocument.get("company_id"))));
                    userMonitorXw.setDt((Date) solrDocument.get("dt"));
                    userMonitorXw.setType(String.valueOf(solrDocument.get("risk_type")));
                    userMonitorXw.setRiskId(String.valueOf(solrDocument.get("id")));
                    userMonitorXw.setCompanyName(String.valueOf(solrDocument.get("company_nm")));

                    userMonitorXw.setContent(String.valueOf(solrDocument.get("risk_json")));
                    companiesList.add(userMonitorXw);
                }
                //写监控动态表
                if(companiesList.size()>0) {
                    myMonitorService.batchSaveCompanies(companiesList);
                }
                cursor = response.getNextCursorMark();
            } while (solrDocumentList.size() == 10 );
        }
        catch(Exception e) {
            JobExecutionException e2 = new JobExecutionException(e);
            // true 表示 Quartz 会自动取消所有与这个 job 有关的 trigger，从而避免再次运行 job
            e2.setUnscheduleAllTriggers(true);
            throw e2;
        }
        logger.info("MonitorRiskJob:end");
    }

    private QueryResponse getCompanyRisksByPaging(String cursorMark, String startDateStr, String toDateStr) throws SolrServerException {
        SolrServer solrServer = new HttpSolrServer(Contants.SOLR_SERVICE_RISK_URL);
        //创建一个SolrQuery对象
        SolrQuery query = new SolrQuery();
        //设置查询条件、过滤条件、分页条件、排序条件、高亮
        query.set("q", "*:*");
        query.set("defType", "edismax");
        query.set("wt", "json");
        //分页条件
        //query.setStart(5);
        query.setRows(10);

        //使用cursormark
        query.set("cursorMark", cursorMark);
        query.setSort("id", SolrQuery.ORDER.desc);

        query.setFilterQueries(String.format("dt:[%sT14:00:00Z TO %sT14:00:00Z]",startDateStr, toDateStr));
        //执行查询，得到一个Response对象
        return solrServer.query(query);
    }
}
