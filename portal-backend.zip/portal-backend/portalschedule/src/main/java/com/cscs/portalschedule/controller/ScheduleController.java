package com.cscs.portalschedule.controller;

import com.cscs.portalschedule.job.TestJob;
import com.cscs.portalschedule.service.QuartzService;
import com.cscs.portalschedule.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@org.springframework.web.bind.annotation.RestController
@RequestMapping(value = "/schedule")
public class ScheduleController {

    @Autowired
    private QuartzService quartzService;

    @RequestMapping(value = "/startJobFromClass", method = RequestMethod.POST)
    public void startJobFromClassName(@RequestBody Map inData) throws ClassNotFoundException {
        String className = (String)inData.get("className");
        String jobName = (String)inData.get("jobName");
        String jobGroupName = (String)inData.get("jobGroupName");
        jobName = StringUtil.isEmpty(jobName) ? className : jobName;
        jobGroupName = StringUtil.isEmpty(jobGroupName) ? className : jobGroupName;
        String cron = (String)inData.get("cron");
        Class cl = Class.forName(className);
        Map<String, Object> data = (Map<String, Object>)inData.get("data");
        if (StringUtil.isEmpty(cron)) {
            quartzService.addJob(cl, jobName, jobGroupName, 1, 0, data);
        }
        else {
            quartzService.addJob(cl, jobName, jobGroupName, cron, data);
        }
    }

    @RequestMapping(value ="/updateJob", method = RequestMethod.POST)
    public void updateJob(@RequestBody Map inData) {
        String jobName = (String)inData.get("jobName");
        String jobGroupName = (String)inData.get("jobGroupName");
        String jobTime = (String)inData.get("cron");
        quartzService.updateJob(jobName, jobGroupName, jobTime);
    }

    @RequestMapping(value ="/updateJobs", method = RequestMethod.POST)
    public void updateJobs(@RequestBody Map inData) {

    }

    @RequestMapping(value ="/deleteJob", method = RequestMethod.POST)
    public void deleteJob(@RequestBody Map inData) {
        String jobName = (String)inData.get("jobName");
        String jobGroupName = (String)inData.get("jobGroupName");
        quartzService.deleteJob(jobName, jobGroupName);
    }
    @RequestMapping(value ="/deleteJobs", method = RequestMethod.POST)
    public void deleteJobs(@RequestBody Map inData) {

    }

    @RequestMapping(value ="/pauseJob", method = RequestMethod.POST)
    public void pauseJob(@RequestBody Map inData) {
        String jobName = (String)inData.get("jobName");
        String jobGroupName = (String)inData.get("jobGroupName");
        quartzService.pauseJob(jobName, jobGroupName);
    }

    @RequestMapping(value ="/pauseJobs", method = RequestMethod.POST)
    public void pauseJobs(@RequestBody Map inData) {

    }

    @RequestMapping(value ="/resumeJob", method = RequestMethod.POST)
    public void resumeJob(@RequestBody Map inData) {
        String jobName = (String)inData.get("jobName");
        String jobGroupName = (String)inData.get("jobGroupName");
        quartzService.resumeJob(jobName, jobGroupName);
    }

    @RequestMapping(value ="/resumeJobs", method = RequestMethod.POST)
    public void resumeJobs(@RequestBody Map inData) {

    }

    @RequestMapping("/queryAllJob")
    public Object queryAllJob() {
        return quartzService.queryAllJob();
    }

    @RequestMapping("/queryRunJob")
    public Object queryRunJob() {
        return quartzService.queryRunJob();
    }

    @RequestMapping("/shutdown")
    public void shutdown() {
        quartzService.shutdown();
    }

    @RequestMapping("/start")
    public void start() {
        quartzService.start();
    }

    @RequestMapping(value ="/runJobOnce", method = RequestMethod.POST)
    public void runJobOnce(@RequestBody Map inData) {
        String jobName = (String)inData.get("jobName");
        String jobGroupName = (String)inData.get("jobGroupName");
        quartzService.runAJobNow(jobName, jobGroupName);
    }
}