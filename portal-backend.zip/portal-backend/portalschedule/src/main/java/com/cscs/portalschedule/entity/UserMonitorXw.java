package com.cscs.portalschedule.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "USER_MONITOR_XW", schema = "CS_PORTAL", catalog = "")
public class UserMonitorXw {
    private long id;
    private Long companyId;
    private Date dt;
    private String type;
    private String content;
    //private Long isRead;
    
    private String riskId;
    
    private String companyName;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_USER_MONITOR_XW")
    @SequenceGenerator(sequenceName = "SEQ_USER_MONITOR_XW", name = "SEQ_USER_MONITOR_XW")
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "COMPANY_ID")
    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }
    
    @Basic
    @Column(name = "company_name")
    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    
    @Basic
    @Column(name = "DT")
    public Date getDt() {
        return dt;
    }

    public void setDt(Date dt) {
        this.dt = dt;
    }

    @Basic
    @Column(name = "TYPE")
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    
    @Basic
    @Column(name = "RISK_ID")
    public String getRiskId() {
		return riskId;
	}

	public void setRiskId(String riskId) {
		this.riskId = riskId;
	}

	@Basic
    @Column(name = "CONTENT")
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

//    @Basic
//    @Column(name = "IS_READ")
//    public Long getIsRead() {
//        return isRead;
//    }
//
//    public void setIsRead(Long isRead) {
//        this.isRead = isRead;
//    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UserMonitorXw that = (UserMonitorXw) o;
        return id == that.id &&
                Objects.equals(companyId, that.companyId) &&
                Objects.equals(dt, that.dt) &&
                Objects.equals(type, that.type) &&
                Objects.equals(content, that.content)&&
               Objects.equals(riskId, that.riskId)&&
               Objects.equals(companyName, that.companyName);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, companyId, dt, type, content,riskId,companyName);
    }
}
