package com.cscs.portalschedule.controller;

import com.cscs.portalschedule.Contants;
import com.cscs.portalschedule.job.PfScoreDetailJob;
import com.cscs.portalschedule.service.QuartzService;
import com.cscs.portalschedule.util.StringUtil;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping(value = "/pfScore")
public class PfScoreController {
    @Value("${pf.score.task.count}")
    int tasks;

    public final static String JOB_NAME = "pf_score";
    public final static String JOB_GROUP_NAME = "pf_score_group";

    @Autowired
    private QuartzService quartzService;

    private int getPFCompanyCount() throws SolrServerException {
        SolrServer solrServer = new HttpSolrServer(Contants.SOLR_SERVICE_PFUND_URL);
        //创建一个SolrQuery对象
        SolrQuery query = new SolrQuery();
        //设置查询条件、过滤条件、分页条件、排序条件、高亮
        query.set("q", "isdel:0");
        query.set("fl", "id");
        query.set("defType", "edismax");
        query.set("wt", "json");
        query.set("shards.tolerant", "true");
        //执行查询，得到一个Response对象
        QueryResponse response = solrServer.query(query);
        int total = Integer.valueOf(String.valueOf(response.getResults().getNumFound())).intValue();
        return total;
    }

    @RequestMapping(value = "/schedule", method = RequestMethod.POST)
    public void schedule(@RequestBody Map inData) throws ClassNotFoundException, SolrServerException {
        int total = getPFCompanyCount();
        String jobTime = (String)inData.get("cron");
        //切分任务total
        int per = total/tasks;
        int start = 0;
        for (int i = 1; i <= tasks; i++) {
            Map<String, Object> data = new HashMap<>();
            data.put("start", start);
            if (i == tasks) {
                per = 3*per;
            }
            data.put("rows", per);
            quartzService.addJob(PfScoreDetailJob.class, JOB_NAME + String.valueOf(i), JOB_GROUP_NAME, jobTime, data);
            start = start + per;
        }
    }

    @RequestMapping(value ="/update", method = RequestMethod.POST)
    public void updateJob(@RequestBody Map inData) {
        String jobTime = (String)inData.get("cron");
        for (int i = 1; i <= tasks; i++) {
            quartzService.updateJob(JOB_NAME + String.valueOf(i), JOB_GROUP_NAME, jobTime);
        }
    }

    @RequestMapping(value ="/del", method = RequestMethod.GET)
    public void delJobs() {
        for (int i = 1; i <= tasks; i++) {
            quartzService.deleteJob(JOB_NAME + String.valueOf(i), JOB_GROUP_NAME);
        }
    }

    @RequestMapping(value ="/reschedule", method = RequestMethod.POST)
    public void reschedule(@RequestBody Map inData) throws SolrServerException, ClassNotFoundException {
        delJobs();
        schedule(inData);
    }
}