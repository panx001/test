package com.cscs.portalschedule.job;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cscs.portalschedule.Contants;
import com.cscs.portalschedule.entity.PFCompyScore;
import com.cscs.portalschedule.service.PFCompyScoreService;
import com.cscs.portalschedule.service.QuartzService;
import com.cscs.portalschedule.util.DateUtils;
import com.cscs.portalschedule.util.HttpUtil;
import com.cscs.portalschedule.util.JsonArrayComparator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;
import org.quartz.PersistJobDataAfterExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@PersistJobDataAfterExecution
@DisallowConcurrentExecution
public class PfScoreJob extends QuartzJobBean {
    private final static Log logger = LogFactory.getLog(PfScoreJob.class);
    public final static int ROW_INTERVAL = 500;
    public final static int TASKS = 3;

    @Autowired
    PFCompyScoreService scoreServices;

    @Autowired
    private QuartzService quartzService;

    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
        logger.info("PfScoreJob:start");
        JobKey key = context.getJobDetail().getKey();
        try {
            QueryResponse response = getPFCompyByPaging("*");
            int total = Integer.valueOf(String.valueOf(response.getResults().getNumFound())).intValue();

            Date inertDate = new Date();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(inertDate);
            calendar.add(Calendar.DAY_OF_MONTH, 1);
            SimpleDateFormat sm = new SimpleDateFormat("yyyy-MM-dd");
            String dateStr = sm.format(calendar.getTime());
            int per = total / TASKS;
            int start = 0;
            for (int i = 0; i < TASKS; i++) {
                Map<String, Object> data = new HashMap<>();
                data.put("start", start);
                if (i == TASKS - 1) {
                    per = total - (TASKS - 1) * per;
                }
                data.put("rows", per);
                quartzService.addJob(PfScoreDetailJob.class, "pf" + dateStr + String.valueOf(i), "PFDetailGroup", 1, 0, data);
                start = start + per;
            }
//
//
//
//            String cursor = "*";
//            SolrDocumentList solrDocumentList = null;
//            String companyId = null;
//            QueryResponse response = null;
//
//            Date inertDate = new Date();
//            Calendar calendar = Calendar.getInstance();
//            calendar.setTime(inertDate);
//            calendar.add(Calendar.DAY_OF_MONTH, 1);
//            do {
//                response = getPFCompyByPaging(cursor);
//                solrDocumentList = response.getResults();
//
//                for (SolrDocument solrDocument : solrDocumentList) {
//                    try {
//                        companyId = String.valueOf(solrDocument.get("id"));
//                        int capitalScore = 0, manageScore = 0, sincerityScore = 0, relationScore = 0, complianceScore = 0, cheatScore = 0;
//                        double weightScore = 0d;
//
//                        //企业信息
//                        JSONObject pfund = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_PFUND_RECORDINFO_URL, companyId));
//                        if (pfund == null) {
//                            logger.info("没有数据：" + companyId);
//                            continue;
//                        }
//
//                        //关联风险
//                        String chartList = HttpUtil.getResponse(Contants.DAASCOMPANYSEARCH_URL + pfund.getString("compyNm"));
//                        JSONObject chartJson = JSON.parseObject(chartList);
//
//                        //资本风险
//                        capitalScore = capitalRisk(pfund);
//                        weightScore += capitalScore * 0.3;
//
//                        //经营风险
//                        manageScore = managementRisk(companyId, chartJson);
//                        weightScore += manageScore * 0.1;
//
//                        //诚信风险
//                        int tmpScore = sincerityRisk1(companyId);
//                        sincerityScore = tmpScore;
//                        weightScore += tmpScore * 0.27;
//                        tmpScore = sincerityRisk2(companyId);
//                        sincerityScore += tmpScore;
//                        weightScore += tmpScore * 0.03;
//
//                        //关联风险
//                        relationScore = relationRisk(chartJson);
//                        weightScore += relationScore * 0.3;
//
//                        //合规风险
//                        complianceScore = complianceRisk(pfund, companyId);
//                        //欺诈风险
//                        cheatScore = cheatRisk(companyId);
//
//                        //评分最大值，最小值取区间
//                        int riskLevel = 0;
//                        if (weightScore > 8.6 || 5 <= complianceScore || 5 <= cheatScore) {
//                            riskLevel = 1;
//                        } else if (6.2 <= weightScore && weightScore < 8.6) {
//                            riskLevel = 2;
//                        } else {
//                            riskLevel = 3;
//                        }
//                        PFCompyScore infoData = new PFCompyScore();
//                        infoData.setCompanyId(Long.valueOf(companyId));
//                        infoData.setCompanyName(pfund.getString("compyNm"));
//                        infoData.setScoreDt(calendar.getTime());
//                        infoData.setWeightScore(weightScore);
//                        infoData.setCapitalScore(capitalScore);
//                        infoData.setManageScore(manageScore);
//                        infoData.setSincerityScore(sincerityScore);
//                        infoData.setRelationScore(relationScore);
//                        infoData.setComplianceScore(complianceScore);
//                        infoData.setCheatScore(cheatScore);
//                        infoData.setRiskResult(riskLevel);
//                        infoData.setRegion(pfund.getString("region"));
//                        infoData.setCity(pfund.getString("city"));
//                        scoreServices.save(infoData);
////                    batchArgs.add(new Object[]{companyId, pfund.getString("compyNm"),date, weightScore, capitalScore, manageScore, sincerityScore, relationScore, complianceScore, cheatScore, riskLevel, pfund.getString("region"), pfund.getString("city")});
//                    } catch (Exception ex) {
//                        logger.info("出错数据：" + companyId);
//                        logger.info(ex.getMessage());
//                    }
//                }
////            String sql = "insert into pfcompy_score_tmp(COMPANY_ID,COMPANY_NAME,SCORE_DT,WEIGHT_SCORE,\n";
////            sql += "CAPITAL_SCORE,MANAGE_SCORE,SINCERITY_SCORE,RELATION_SCORE,COMPLIANCE_SCORE,CHEAT_SCORE,RISK_RESULT,REGION,CITY) values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
////            jdbcTemplate.batchUpdate(sql, batchArgs);
//                cursor = response.getNextCursorMark();
//            } while (solrDocumentList.size() == 1000);
        }
        catch(Exception e) {
            JobExecutionException e2 = new JobExecutionException(e);
            // true 表示 Quartz 会自动取消所有与这个 job 有关的 trigger，从而避免再次运行 job
            e2.setUnscheduleAllTriggers(true);
            throw e2;
        }
        logger.info("PfScoreJob:end");
    }
    //资本风险
    private int capitalRisk(JSONObject pfund) {
        int score = 0;
        //资本风险
        double regCapital = pfund.containsKey("regCapital") ? pfund.getDoubleValue("regCapital") : 0L;
        double shareCapital = pfund.containsKey("shareCapital") ? pfund.getDoubleValue("shareCapital") : 0L;
        double captialAmt = pfund.containsKey("actualCapital") ? regCapital / shareCapital : 0L;
        if (shareCapital < 100 || captialAmt < 0.1) {
            score += 3;
        } else if ((100 <= shareCapital && shareCapital < 1000) || (0.1 <= captialAmt && captialAmt < 0.25)) {
            score += 2;
        } else if (shareCapital >= 1000 && captialAmt >= 0.25) {
            score += 1;
        }
        return score;
    }

    //经营风险
    private int managementRisk(String companyId, JSONObject chartJson) throws Exception {
        int score = 0;
        JSONObject pfund = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_PFUND_RECORDINFO_URL, companyId));
        //经营风险-经营历史
        if (pfund.containsKey("foundDt")) {
            Calendar fund = Calendar.getInstance();
            fund.setTime(DateUtils.ISO_DATE_FORMAT.parse(pfund.getString("foundDt")));
            Calendar now = Calendar.getInstance();
            now.setTime(new Date());
            int year = now.get(Calendar.YEAR) - fund.get(Calendar.YEAR);
            if (year < 1) {
                score += 3;
            } else if (1 <= year && year < 3) {
                score += 2;
            } else if (year >= 3) {
                score += 1;
            }
        }

        JSONArray shareholderList = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_PFUND_SHAREHOLDERLIST_URL, companyId));
        JSONArray jsonArray = null;
        if (shareholderList != null) {
            jsonArray = JsonArrayComparator.sortJSONArray(shareholderList, "subscribeRatio");
            JSONObject info = jsonArray.getJSONObject(0);
            score += checkShorehd(info.getString("sharehdName"));
        }

        //背景实力-实际控制人实力
        String sharehdName = chartJson.getString("大股东穿透");
        if ("null".equals(sharehdName))
            score += checkShorehd(sharehdName);
        else
            score += 1;

        //背景实力-其他股东实力
        if (jsonArray != null) {
            boolean isCHK = false;
            int maxLen = jsonArray.size() > 5 ? 5 : jsonArray.size();
            for (int i = 0; i < maxLen; i++) {
                JSONObject info = jsonArray.getJSONObject(i);
                isCHK = checkCompyName(info.getString("sharehdName"));
                if (isCHK) {
                    break;
                }
            }
            if (isCHK) {
                score += 3;
            } else {
                score += 1;
            }
        }
        return score;
    }

    //诚信风险
    private int sincerityRisk1(String companyId) {
        int score = 0;
        //企业及其重要利益相关方涉及司法诉讼
        Object ishonest = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_ISHONEST_URL, companyId));
        Object announcement = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_ANNOUNCEMENT_URL, companyId));
        Object document = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_DOCUMENT_URL, companyId));
        Object litigant = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_LITIGANT_URL, companyId));
        if (ishonest == null || announcement == null || document == null || litigant == null) {
            score += 3;
        } else {
            score += 1;
        }

        //监管机构对企业及其重要利益相关方的处罚
        Object adminpenalty = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_ADMINPENALTY_URL, companyId));
        Object equitypledge = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_EQUITYPLEDGE_URL, companyId));
        Object chattelreg = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_CHATTELREG_URL, companyId));
        if (adminpenalty == null || equitypledge == null || chattelreg == null) {
            score += 3;
        } else {
            score += 1;
        }
        return score;
    }

    private int sincerityRisk2(String companyId) {
        int score = 0;
        //经营异常评价
        Object operexcept = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_RISK_OPEREXCEPT_URL, companyId));
        if (operexcept == null) {
            score = 3;
        } else {
            score = 1;
        }
        return score;
    }

    //关联风险
    private int relationRisk(JSONObject chartJson) {
        int score = 0;
        score += (int) chartJson.get("投资有限合伙企业情况");
        score += (int) chartJson.get("股东跨领域经营评价");
        score += (int) chartJson.get("股东跨区域经营评价");
        score += (int) chartJson.get("对外投资跨领域经营评价");
        score += (int) chartJson.get("对外投资跨区域经营评价");

        score += (int) chartJson.get("企业与问题企业关联");
        score += (int) chartJson.get("有限合伙产品嵌套评价");
        score += (int) chartJson.get("交叉持股评价");
        score += (int) chartJson.get("两层以上环状投资评价");
        return score;
    }

    //合规风险
    private int complianceRisk(JSONObject pfund, String companyId) {
        int score = 0;
        JSONObject base = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_BASICINFO_URL, companyId));
        JSONObject legRepresentList = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_PFUND_LEGREPRESENTLIST_URL, companyId));

        //管理人备案不实
        String legRepresent = legRepresentList.getString("legRepresent");
        String legalPersonName = base.getString("legalPersonName");
        if (legRepresent.equals(legalPersonName)) {
            score += 1;
        }

        //备案产品不实
        JSONArray holdings = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_HOLDINGS_URL, companyId));
        JSONArray productList = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_PFUND_PRODUCTLIST_URL, companyId));
        if (holdings == null) holdings = new JSONArray();
        if (productList == null) productList = new JSONArray();
        int holdingsCount = 0, executivesCount = 0;
        for (int i = 0; i < holdings.size(); i++) {
            JSONObject item = holdings.getJSONObject(i);
            if (item.getString("compyNm").contains("有限合伙")) {
                holdingsCount++;
            }
        }
        for (int i = 0; i < productList.size(); i++) {
            JSONObject item = productList.getJSONObject(i);
            if (item.get("productNm").toString().contains("有限合伙")) {
                executivesCount++;
            }
        }
        if (holdingsCount > executivesCount)
            score += 1;

        //管理人备案情况--没有数据表
        //机构名称、经营范围均未含有指定字样
        boolean isKey = true;
        String[] keywordList = {"基金管理", "投资管理", "资产管理", "股权投资", "创业投资"};
        for (String keyword : keywordList)
            if (base.getString("compyName").contains(keyword) || base.getString("businScope").contains(keyword))
                isKey = false;
        if (isKey)
            score += 2;

        //从业人员人数
        String fundType = pfund.getString("fundType") != null ? pfund.getString("fundType") : "";
        JSONArray executivesList = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_PFUND_EXECUTIVESLIST_URL, companyId));
        if (fundType.contains("私募证券投资基金") && executivesList.size() < 3)
            score += 1;

        if (fundType.contains("私募股权投资基金") && executivesList.size() < 2)
            score += 1;

        //从业人员从业资格
        if (fundType.contains("私募证券投资基金")) {
            for (int i = 0; i < executivesList.size(); i++) {
                JSONObject item = executivesList.getJSONObject(i);
                if (!item.get("certificated").toString().contains("是"))
                    score += 3;
            }
        } else {
            for (int i = 0; i < executivesList.size(); i++) {
                JSONObject item = executivesList.getJSONObject(i);
                if (legRepresent.equals(item.get("name")) && !item.get("certificated").toString().contains("是"))
                    score += 3;
            }
        }
        return score;
    }

    //欺诈风险
    private int cheatRisk(String companyId) throws Exception {
        int score = 0;
        //高管变更频繁
        //股东变更频繁
        JSONArray compyChange = HttpUtil.getHBaseResponse(MessageFormat.format(Contants.HBASE_COMPANY_COMPYCHANGE_URL, companyId));
        if (compyChange != null) {
            int managreChange = 0, sharehdCount = 0;
            Calendar now = Calendar.getInstance();
            now.add(Calendar.YEAR, -1);
            JSONArray jsonArray = JsonArrayComparator.sortJSONArray(compyChange, "changeTime");
            for (int i = 0; i < jsonArray.size(); i++) {
                JSONObject json = jsonArray.getJSONObject(i);
                Calendar checkTime = Calendar.getInstance();
                checkTime.setTime(DateUtils.ISO_DATE_FORMAT.parse(json.getString("changeTime")));
                if (checkTime.getTimeInMillis() > now.getTimeInMillis()) {
                    if ("股东".equals(json.getString("changeItem")) || "股东信息".equals(json.getString("changeItem"))) {
                        sharehdCount++;
                    }
                    if ("法定代表人".equals(json.getString("changeItem")) || "总经理".equals(json.getString("changeItem")) || "董事长".equals(json.getString("changeItem"))) {
                        managreChange++;
                    }
                } else {
                    break;
                }
            }
            //高管变更频繁
            if (managreChange == 2) {
                score += 2;
            } else if (managreChange > 3) {
                score += 3;
            }
            //股东变更频繁
            if (sharehdCount == 2) {
                score += 2;
            } else if (sharehdCount > 3) {
                score += 3;
            }
        }
        return score;
    }

    //国资背景
    private int checkShorehd(String sharehdName) {
        int score = 3;
        if ("null".equals(sharehdName))
            score = 3;
        else if (sharehdName.length() < 4 && !sharehdName.equals("国务院"))
            score = 3;
        else if (sharehdName.contains("公司"))
            score = 3;
        else
            score = 1;
        return score;
    }

    //其他股东实力
    private boolean checkCompyName(String sharehdName) {
        String[] CHECK_NAME = {
                "中国工商银行股份有限公司", "中国农业银行股份有限公司", "中国银行股份有限公司", "中国建设银行股份有限公司", "交通银行股份有限公司", "华夏银行股份有限公司",
                "中国光大银行股份有限公司", "招商银行股份有限公司", "中信银行股份有限公司", "中国民生银行股份有限公司", "兴业银行股份有限公司", "上海浦东发展银行股份有限公司",
                "北京银行股份有限公司", "平安银行股份有限公司", "广东发展银行股份有限公司", "中国邮政储蓄银行股份有限公司", "上海银行股份有限公司", "渤海银行股份有限公司",
                "宁波银行股份有限公司", "浙商银行股份有限公司", "海通证券股份有限公司", "国信证券股份有限公司", "徽商银行股份有限公司", "广州农村商业银行股份有限公司",
                "招商证券股份有限公司", "中国证券登记结算有限责任公司", "包商银行股份有限公司", "恒丰银行股份有限公司", "杭州银行股份有限公司", "南京银行股份有限公司",
                "广发证券股份有限公司", "国泰君安证券股份有限公司", "江苏银行股份有限公司", "中国银河证券股份有限公司", "华泰证券股份有限公司", "中信证券股份有限公司",
                "兴业证券股份有限公司", "中国证券金融股份有限公司", "中信建投证券股份有限公司", "中国国际金融股份有限公司", "恒泰证券股份有限公司", "中泰证券股份有限公司",
                "国金证券股份有限公司", "爱建证券有限责任公司", "安信证券股份有限公司", "北京高华证券有限责任公司", "渤海证券股份有限公司", "财达证券股份有限公司",
                "财富证券有限责任公司", "财通证券股份有限公司", "财通证券资产管理有限公司", "长城国瑞证券有限公司", "长城证券股份有限公司", "长江证券(上海)资产管理有限公司",
                "长江证券承销保荐有限公司", "长江证券股份有限公司", "网信证券有限责任公司", "川财证券有限责任公司", "大通证券股份有限公司", "大同证券经纪有限责任公司",
                "德邦证券股份有限公司", "第一创业摩根大通证券有限责任公司", "第一创业证券股份有限公司", "东北证券股份有限公司", "东方花旗证券有限公司", "东方证券股份有限公司",
                "东海证券股份有限公司", "东莞证券股份有限公司", "东吴证券股份有限公司", "东兴证券股份有限公司", "方正证券股份有限公司", "高盛高华证券有限责任公司",
                "光大证券股份有限公司", "广发证券资产管理(广东)有限公司", "广州证券股份有限公司", "国都证券股份有限公司", "国海证券股份有限公司", "国开证券有限责任公司",
                "国联证券股份有限公司", "国盛证券有限责任公司", "国元证券股份有限公司", "海际证券有限责任公司", "恒泰长财证券有限责任公司", "红塔证券股份有限公司",
                "宏信证券有限责任公司", "华安证券股份有限公司", "华宝证券有限责任公司", "华创证券有限责任公司", "华福证券有限责任公司", "华金证券有限责任公司", "华林证券有限责任公司",
                "华龙证券股份有限公司", "华融证券股份有限公司", "华泰联合证券有限责任公司", "华泰证券(上海)资产管理有限公司", "华西证券股份有限公司", "华鑫证券有限责任公司",
                "华英证券有限责任公司", "江海证券有限公司", "金通证券有限责任公司", "金元证券股份有限公司", "九州证券股份有限公司", "开源证券股份有限公司", "联讯证券股份有限公司",
                "民生证券股份有限公司", "摩根士丹利华鑫证券有限责任公司", "南京证券股份有限公司", "平安证券股份有限公司", "齐鲁证券(上海)资产管理有限公司", "国融证券股份有限公司",
                "瑞信方正证券有限责任公司", "瑞银证券有限责任公司", "山西证券股份有限公司", "上海东方证券资产管理有限公司", "上海光大证券资产管理有限公司",
                "上海国泰君安证券资产管理有限公司", "上海海通证券资产管理有限公司", "上海华信证券有限责任公司", "上海证券有限责任公司", "申万宏源西部证券有限公司",
                "申万宏源证券承销保荐有限责任公司", "申万宏源证券有限公司", "世纪证券有限责任公司", "首创证券有限责任公司", "太平洋证券股份有限公司", "天风证券股份有限公司",
                "万和证券股份有限公司", "万联证券股份有限公司", "五矿证券有限公司", "西部证券股份有限公司", "西藏东方财富证券股份有限公司", "西南证券股份有限公司",
                "湘财证券有限责任公司", "新时代证券股份有限公司", "信达证券股份有限公司", "兴证证券资产管理有限公司", "银河金汇证券资产管理有限公司", "银泰证券有限责任公司",
                "英大证券有限责任公司", "招商证券资产管理有限公司", "浙江浙商证券资产管理有限公司", "浙商证券股份有限公司", "中德证券有限责任公司", "中国民族证券有限责任公司",
                "中国中投证券有限责任公司", "中航证券有限公司", "中山证券有限责任公司", "中天证券股份有限公司", "中信证券(山东)有限责任公司", "中银国际证券有限责任公司",
                "中邮证券有限责任公司", "中原证券股份有限公司", "联储证券有限责任公司", "国盛证券资产管理有限公司", "东证融汇证券资产管理有限公司", "渤海汇金证券资产管理有限公司",
                "申港证券股份有限公司", "华菁证券有限公司"};
        for (String compynm : CHECK_NAME)
            if (compynm.equals(sharehdName))
                return true;
        return false;
    }

    //私募机构检索
    private QueryResponse getPFCompyByPaging(String cursorMark) throws SolrServerException {
        SolrServer solrServer = new HttpSolrServer(Contants.SOLR_SERVICE_PFUND_URL);
        //创建一个SolrQuery对象
        SolrQuery query = new SolrQuery();
        //设置查询条件、过滤条件、分页条件、排序条件、高亮
        query.set("q", "isdel:0");
        query.set("fl", "id");
        query.set("defType", "edismax");
        query.set("wt", "json");
        query.set("shards.tolerant", "true");
        //分页条件
//        query.setStart(0);
        query.setRows(1000);

        //使用cursormark
        query.set("cursorMark", cursorMark);
        query.setSort("id", SolrQuery.ORDER.desc);

        //执行查询，得到一个Response对象
        return solrServer.query(query);
    }
}
