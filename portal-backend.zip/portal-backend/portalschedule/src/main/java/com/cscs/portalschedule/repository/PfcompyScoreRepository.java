package com.cscs.portalschedule.repository;

import com.cscs.portalschedule.entity.PFCompyScore;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by dch on 2016/11/2.
 */
@SuppressWarnings("JpaQlInspection")
public interface PfcompyScoreRepository extends JpaRepository<PFCompyScore, Long> {
}
