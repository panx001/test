package com.cscs.portalschedule.service;

import com.cscs.portalschedule.entity.PFCompyScore;
import com.cscs.portalschedule.repository.PfcompyScoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.stereotype.Service;

import java.util.List;

@SuppressWarnings("JpaQlInspection")
@Service
public class PFCompyScoreService {

    @Autowired
    private PfcompyScoreRepository pfcompyScoreRepository;

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public void save(PFCompyScore infoData) {
        pfcompyScoreRepository.save(infoData);
    }

    public void batchSave(List<PFCompyScore> list) {
        SqlParameterSource[] beanSources  = SqlParameterSourceUtils.createBatch(list.toArray());
        String sql = "INSERT INTO PFCOMPY_SCORE(COMPANY_ID,COMPANY_NAME,SCORE_DT,WEIGHT_SCORE,CAPITAL_SCORE,MANAGE_SCORE,SINCERITY_SCORE,RELATION_SCORE,COMPLIANCE_SCORE,CHEAT_SCORE,RISK_RESULT,REGION,CITY) " +
                "VALUES (:companyId,:companyName,:scoreDt,:weightScore,:capitalScore,:manageScore,:sincerityScore,:relationScore,:complianceScore,:cheatScore,:riskResult,:region,:city)";
        namedParameterJdbcTemplate.batchUpdate(sql, beanSources);
    }
}
