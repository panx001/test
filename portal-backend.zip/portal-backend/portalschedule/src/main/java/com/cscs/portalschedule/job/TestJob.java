package com.cscs.portalschedule.job;

import com.alibaba.fastjson.JSON;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;
import org.quartz.PersistJobDataAfterExecution;
import org.quartz.TriggerKey;
import org.springframework.scheduling.quartz.QuartzJobBean;

import java.util.Date;

@PersistJobDataAfterExecution
@DisallowConcurrentExecution
public class TestJob extends QuartzJobBean {
    private final static Log logger = LogFactory.getLog(PfScoreJob.class);

    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
        logger.info(Thread.currentThread().getName() + new Date());
        JobKey key = context.getJobDetail().getKey();//获取JobDetail的标识信息
        logger.info("JobDetail‘s name and group are "+key.getName()+":"+key.getGroup()+":"+"start");
        TriggerKey triggerKey = context.getTrigger().getKey();//获取Trigger的标识信息
        logger.info("Trigger‘s name and group are "+triggerKey.getName()+":"+triggerKey.getGroup());
        //获取JobDetail通过JobDataMap传递的参数信息
        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();

        logger.info("jobDataMap:"+ JSON.toJSONString(jobDataMap));
        try {
            Thread.sleep(600000l);
            logger.info("JobDetail‘s name and group are "+key.getName()+":"+key.getGroup()+":"+"end");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}