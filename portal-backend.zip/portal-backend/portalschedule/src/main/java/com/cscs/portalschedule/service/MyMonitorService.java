package com.cscs.portalschedule.service;

import com.cscs.portalschedule.entity.UserMonitorXw;
import com.cscs.portalschedule.repository.UserMonitorXwRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import java.util.List;

@Service
@SuppressWarnings("JpaQlInspection")
public class MyMonitorService {
    @Autowired
    private UserMonitorXwRepository userMonitorXwRepository;

    @PersistenceContext
    EntityManager em;
	
	 public int findMonitorXWByRiskId(String riskId) {
	        String countSql = "SELECT Count(1) FROM USER_MONITOR_XW  where risk_id=?1 ";
	        Query countQuery = em.createNativeQuery(countSql);
	        countQuery.setParameter(1, riskId);
	        return Integer.valueOf(countQuery.getSingleResult().toString());
    }

    @Transactional
    public void batchSaveCompanies(List<UserMonitorXw> companiesList) {
        userMonitorXwRepository.save(companiesList);
    }
}
