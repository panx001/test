package com.cscs.portalschedule.controller;

import com.cscs.portalschedule.Contants;
import com.cscs.portalschedule.job.MonitorRiskJob;
import com.cscs.portalschedule.job.PfScoreDetailJob;
import com.cscs.portalschedule.service.QuartzService;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping(value = "/monitor/risk")
public class MonitorRiskController {
    public final static String JOB_NAME = "monitor_risk";
    public final static String JOB_GROUP_NAME = "monitor_risk_group";

    @Autowired
    private QuartzService quartzService;

    @RequestMapping(value = "/schedule", method = RequestMethod.POST)
    public void schedule(@RequestBody Map inData) throws ClassNotFoundException, SolrServerException {
        String jobTime = (String)inData.get("cron");
        quartzService.addJob(MonitorRiskJob.class, JOB_NAME, JOB_GROUP_NAME, jobTime, new HashMap<>());
    }

    @RequestMapping(value ="/update", method = RequestMethod.POST)
    public void updateJob(@RequestBody Map inData) {
        String jobTime = (String)inData.get("cron");
        quartzService.updateJob(JOB_NAME , JOB_GROUP_NAME, jobTime);
    }

    @RequestMapping(value ="/del", method = RequestMethod.GET)
    public void delJobs() {
        quartzService.deleteJob(JOB_NAME, JOB_GROUP_NAME);
    }
}