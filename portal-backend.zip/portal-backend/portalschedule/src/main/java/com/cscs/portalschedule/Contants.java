package com.cscs.portalschedule;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import javax.annotation.PostConstruct;
import java.util.concurrent.TimeUnit;

@Configuration
public class Contants {
    @Autowired
    private Environment _environment;

    //风险企业高级搜索solr服务URL
    public static String SOLR_SERVICE_RISK_URL;
    //私募机构高级搜索solr服务URL
    public static String SOLR_SERVICE_PFUND_URL;

    //企业基础信息
    public static String HBASE_COMPANY_BASICINFO_URL;//工商信息
    public static String HBASE_COMPANY_RISK_URL;//风险提示
    public static String HBASE_COMPANY_MANAGELEVEL_URL;//管理层对外投资对外任职
    public static String HBASE_COMPANY_LPPOSITION_LPINVEST_URL;//管理层对外投资对外任职
    public static String HBASE_COMPANY_SHAREHOLDER_URL;//股东信息-十大股东
    public static String HBASE_COMPANY_SHAREHDINVEST_URL;//股东信息-发起人股东
    public static String HBASE_COMPANY_SHAREHDINVESTNB_URL;//股东信息-年报披露股东及出资信息
    public static String HBASE_COMPANY_INVESTMENT_URL;//对外投资-对外投资企业
    public static String HBASE_COMPANY_COMPYCHANGE_URL;//变更记录
    public static String HBASE_COMPANY_HOLDINGS_URL;//对外投资-参控企业
    public static String HBASE_COMPANY_BRANCH_URL;//分支机构

    //展台私募信息
    public static String HBASE_COMPANY_PFUND_RECORDINFO_URL;//机构备案基本信息
    public static String HBASE_COMPANY_PFUND_LEGREPRESENTLIST_URL;//法定代表人
    public static String HBASE_COMPANY_PFUND_EXECUTIVESLIST_URL;//高管
    public static String HBASE_COMPANY_PFUND_SHAREHOLDERLIST_URL;//股东
    public static String HBASE_COMPANY_PFUND_PRODUCTLIST_URL;//私募机构产品信息
    public static String HBASE_COMPANY_PFUND_CREDIBILITYINFO_URL;//机构诚信信息
    public static String HBASE_COMPANY_PFUND_DATAEXCEPTION_URL;//数据异常

    //评分_关联风险
    public static String DAASCOMPANYSEARCH_URL;

    //企业风险
    public static String HBASE_COMPANY_RISK_BONDVIOLATION_URL;//债券违约
    public static String HBASE_COMPANY_RISK_CREDITCHANGE_URL;//主体评级下调
    public static String HBASE_COMPANY_RISK_BOND_CREDITCHANGE_URL;//债券评级下调
    public static String HBASE_COMPANY_RISK_FINANCEALARM_URL;//财务风险
    public static String HBASE_COMPANY_RISK_FROZENSHARE_URL;//股权冻结
    public static String HBASE_COMPANY_RISK_DOCUMENT_URL;//裁判文书
    public static String HBASE_COMPANY_RISK_ANNOUNCEMENT_URL;//法院公告
    public static String HBASE_COMPANY_RISK_LITIGANT_URL;//被执行人
    public static String HBASE_COMPANY_RISK_ISHONEST_URL; //失信人
    public static String HBASE_COMPANY_RISK_OPEREXCEPT_URL;//经营异常
    public static String HBASE_COMPANY_RISK_ADMINPENALTY_URL;//行政处罚
    public static String HBASE_COMPANY_RISK_SERIVIOLAT_URL;//严重违法
    public static String HBASE_COMPANY_RISK_EQUITYPLEDGE_URL;//股权出质
    public static String HBASE_COMPANY_RISK_CHATTELREG_URL;//动产抵押
    public static String HBASE_COMPANY_RISK_RISKRELA_URL;//风险影响企业
    public static String HBASE_COMPANY_RISK_RISKANALO_URL;//企业存在类似风险

    @PostConstruct
    public void initialization() {

        //风险信息高级搜索solr查询接口
        SOLR_SERVICE_RISK_URL = _environment.getProperty("cscs.portal.solr.risk.search");
        //私募机构高级搜索solr查询接口
        SOLR_SERVICE_PFUND_URL = _environment.getProperty("cscs.portal.solr.pfund.search");

        //企业基础信息
        HBASE_COMPANY_BASICINFO_URL = _environment.getProperty("hbase.company.base.info.basicinfo.url");
        HBASE_COMPANY_RISK_URL = _environment.getProperty("hbase.company.base.info.risk.url");
        HBASE_COMPANY_MANAGELEVEL_URL = _environment.getProperty("hbase.company.base.info.managelevel.url");
        HBASE_COMPANY_LPPOSITION_LPINVEST_URL = _environment.getProperty("hbase.company.base.info.lpposition.lpinvest.url");
        HBASE_COMPANY_SHAREHOLDER_URL = _environment.getProperty("hbase.company.base.info.shareholder.url");
        HBASE_COMPANY_SHAREHDINVEST_URL = _environment.getProperty("hbase.company.base.info.sharehdinvest.url");
        HBASE_COMPANY_SHAREHDINVESTNB_URL = _environment.getProperty("hbase.company.base.info.sharehdinvestnb.url");
        HBASE_COMPANY_INVESTMENT_URL = _environment.getProperty("hbase.company.base.info.investment.url");
        HBASE_COMPANY_COMPYCHANGE_URL = _environment.getProperty("hbase.company.base.info.compyChange.url");
        HBASE_COMPANY_HOLDINGS_URL = _environment.getProperty("hbase.company.base.info.holdings.url");
        HBASE_COMPANY_BRANCH_URL = _environment.getProperty("hbase.company.base.info.branch.url");

        //展台私募信息
        HBASE_COMPANY_PFUND_RECORDINFO_URL = _environment.getProperty("hbase.company.pfund.recordinfo.url");
        HBASE_COMPANY_PFUND_LEGREPRESENTLIST_URL = _environment.getProperty("hbase.company.pfund.legrepresentlist.url");
        HBASE_COMPANY_PFUND_EXECUTIVESLIST_URL = _environment.getProperty("hbase.company.pfund.executiveslist.url");
        HBASE_COMPANY_PFUND_SHAREHOLDERLIST_URL = _environment.getProperty("hbase.company.pfund.shareholderlist.url");
        HBASE_COMPANY_PFUND_PRODUCTLIST_URL = _environment.getProperty("hbase.company.pfund.productlist.url");
        HBASE_COMPANY_PFUND_CREDIBILITYINFO_URL = _environment.getProperty("hbase.company.pfund.credibilityInfo.url");
        HBASE_COMPANY_PFUND_DATAEXCEPTION_URL = _environment.getProperty("hbase.company.pfund.dataexception.url");
        DAASCOMPANYSEARCH_URL = _environment.getProperty("cscs.portal.DAASCompanySearch.server");

        //企业风险
        HBASE_COMPANY_RISK_BONDVIOLATION_URL = _environment.getProperty("hbase.company.risk.bondviolation.url");
        HBASE_COMPANY_RISK_CREDITCHANGE_URL = _environment.getProperty("hbase.company.risk.creditchange.url");
        HBASE_COMPANY_RISK_BOND_CREDITCHANGE_URL = _environment.getProperty("hbase.company.risk.bond.creditchange.url");
        HBASE_COMPANY_RISK_FINANCEALARM_URL = _environment.getProperty("hbase.company.risk.financealarm.url");
        HBASE_COMPANY_RISK_FROZENSHARE_URL = _environment.getProperty("hbase.company.risk.frozenshare.url");
        HBASE_COMPANY_RISK_DOCUMENT_URL = _environment.getProperty("hbase.company.risk.document.url");
        HBASE_COMPANY_RISK_ANNOUNCEMENT_URL = _environment.getProperty("hbase.company.risk.announcement.url");
        HBASE_COMPANY_RISK_LITIGANT_URL = _environment.getProperty("hbase.company.risk.litigant.url");
        HBASE_COMPANY_RISK_ISHONEST_URL = _environment.getProperty("hbase.company.risk.dishonest.url");
        HBASE_COMPANY_RISK_OPEREXCEPT_URL = _environment.getProperty("hbase.company.risk.operexcept.url");
        HBASE_COMPANY_RISK_ADMINPENALTY_URL = _environment.getProperty("hbase.company.risk.adminpenalty.url");
        HBASE_COMPANY_RISK_SERIVIOLAT_URL = _environment.getProperty("hbase.company.risk.seriviolat.url");
        HBASE_COMPANY_RISK_EQUITYPLEDGE_URL = _environment.getProperty("hbase.company.risk.equitypledge.url");
        HBASE_COMPANY_RISK_CHATTELREG_URL = _environment.getProperty("hbase.company.risk.chattelreg.url");
        HBASE_COMPANY_RISK_RISKRELA_URL = _environment.getProperty("hbase.company.risk.riskrela.url");
        HBASE_COMPANY_RISK_RISKANALO_URL = _environment.getProperty("hbase.company.risk.riskanalo.url");
    }
}

