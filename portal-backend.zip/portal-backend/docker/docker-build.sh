#! /bin/sh

docker build -t tomcat-portal .
