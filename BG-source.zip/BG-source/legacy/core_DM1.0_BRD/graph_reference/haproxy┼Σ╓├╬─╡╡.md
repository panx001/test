## haproxy配置启动
 ```bash
vi /usr/local/haproxy/example_config.conf

验证conf文件是否正确
sudo /usr/local/haproxy/sbin/haproxy -f /usr/local/haproxy/example_config.conf -c
```
#### 启动

```bash
sudo /usr/local/haproxy/sbin/haproxy -f /usr/local/haproxy/example_config.conf 
```
#### 杀掉进程（记得修改配置后先kill掉之前的haproxy进程，否则会造成端口冲突）

```bash
# killall haproxy
ps aux | grep -ie haproxy | grep -v grep | awk '{print $2}' | xargs kill -9
```

## haproxy配置文件内容
```

global                            #全局变量设置
    daemon
    maxconn 256
    log  127.0.0.1 local0 info    #log记录配置

defaults
    log global
    mode tcp                      #此处mode的修改会影响下面个端口不配置mode的默认值
    option tcplog
    option dontlognull
    timeout connect 30s     
    timeout client 2h               #服务器和客户端空闲超过两小时，终止连接
    timeout server 2h


frontend http-in                  #当前主机的前端配置（访问haproxy集群的入口）
    bind *:80
    mode http
    default_backend neo4j-slaves    #指向集群中的slave节点

backend neo4j-master            #后端配置（通过前端访问那些机器）
    mode http
    option httpchk GET /db/manage/server/ha/master      #试试访问10.100.45.15/db/manage/server/ha/master，用来判断该节点是否是master/slave，如果neo4j不允许不带登录信息的访问，需要在后面加上HTTP/1.0\r\nAuthorization:\ Basic\ bmVvNGo6YWJjMTIzCg==
    server s1 10.100.45.13:7474 maxconn 32 check           #搭建集群的三台服务器
    server s2 10.100.45.14:7474 maxconn 32 check
    server s3 10.100.45.15:7474 maxconn 32 check

frontend http-in-slaves
    bind *:7475
    mode http
    default_backend neo4j-master

backend neo4j-slaves
    option httpchk GET /db/manage/server/ha/slave
    mode http
    server s1 10.100.45.13:7474 maxconn 32 check
    server s2 10.100.45.14:7474 maxconn 32 check
    server s3 10.100.45.15:7474 maxconn 32 check

frontend http-in-neo4j-prod-slave
    bind *:6474
    mode http
    default_backend neo4j-prod-slave

backend neo4j-prod-master
    option httpchk GET /db/manage/server/ha/master
    mode http
    server s1 10.100.47.21:7474 maxconn 32 check
    server s2 10.100.47.19:7474 maxconn 32 check
    server s3 10.100.47.20:7474 maxconn 32 check

frontend http-in-neo4j-prod-master
    bind *:6475
    mode http
    default_backend neo4j-prod-master

backend neo4j-prod-slave
    #balance roundrobin                 #平衡策略：轮循
    #stick-table type integer size 1k expire 70s
    #stick match path,word(4,/)
    #stick store-response hdr(Location),word(6,/)
    #option httpchk GET /db/manage/server/ha/available
    mode http
    option httpchk GET /db/manage/server/ha/slave
    server s1 10.100.47.21:7474 maxconn 32 check
    server s2 10.100.47.19:7474 maxconn 32 check
    server s3 10.100.47.20:7474 maxconn 32 check

frontend bolt-in-neo4j-prod-slave                   #bolt协议需要通过tcp方式来处理，测试可以通过neo4j浏览器来连接这个配置好的haproxy端口，或通过java程序直接连接这个haproxy前端口，切记切记把端口权限开了（无论是哪种方式测试）！
    bind *:6687
    mode tcp
    default_backend neo4j-prod-slave-bolt

backend neo4j-prod-master-bolt
    mode tcp
    option httpchk GET /db/manage/server/ha/master HTTP/1.0\r\nAuthorization:\ Basic\ bmVvNGo6YWJjMTIzCg==
    server s1 10.100.47.21:7687 check port 7474
    server s2 10.100.47.19:7687 check port 7474
    server s3 10.100.47.20:7687 check port 7474

frontend bolt-in-neo4j-prod-master
    bind *:6688
    mode tcp
    default_backend neo4j-prod-master-bolt

backend neo4j-prod-slave-bolt
    mode tcp
    balance roundrobin
    option httpchk GET /db/manage/server/ha/slave HTTP/1.0\r\nAuthorization:\ Basic\ bmVvNGo6YWJjMTIzCg==
    server s1 10.100.47.21:7687 check port 7474
    server s2 10.100.47.19:7687 check port 7474
    server s3 10.100.47.20:7687 check port 7474


listen admin
    bind *:8080
    mode http
    stats enable

listen stats            #监控状态的http页面
   bind *:50000
   mode http
   stats enable
   stats hide-version
   stats realm Haproxy\ Statistics
   stats uri /
   stats auth admin:admin
```



## haproxy日志配置
    haproxy默认不打开日志系统
    # rpm -q rsyslog   查看rsyslog是否安装

```
    1. 修改"/usr/local/haproxy/example_config.conf"
    log         127.0.0.1 local2

    2. vi /etc/sysconfig/rsyslog
    SYSLOGD_OPTIONS="-r -m 0 -c 2"
    #-c 2 使用兼容模式，默认是 -c 5
    ##-r 开启远程日志
    ##-m 0 标记时间戳。单位是分钟，为0时，表示禁用该功能 


    3. vi /etc/rsyslog.conf    取消注释或添加一下几行
    $ModLoad imudp
    $UDPServerRun 514
    local0.*   /var/log/haproxy.log

    4. service rsyslog restart

    5. kill haproxy 重启 
```
