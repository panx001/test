package org.neo4j.tooling.config;

/**
 * Created by wuchenglong on 2017/12/27.
 */
public class DbConnectionConfig {

    public static String  JdbcDriverClassName;
    public static String JdbcUrl;
    public static String  Username;
    public static String  Password;

}
