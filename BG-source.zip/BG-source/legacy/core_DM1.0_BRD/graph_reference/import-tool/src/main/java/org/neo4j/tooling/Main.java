package org.neo4j.tooling;
/*
 * Copyright (c) 2002-2018 "Neo Technology,"
 * Network Engine for Objects in Lund AB [http://neotechnology.com]
 *
 * This file is part of Neo4j.
 *
 * Neo4j is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
import org.apache.commons.lang3.StringUtils;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.sql.*;
import java.util.*;
import org.neo4j.commandline.admin.CommandFailed;
import org.neo4j.commandline.admin.IncorrectUsage;
import org.neo4j.commandline.admin.OutsideWorld;
import org.neo4j.commandline.admin.RealOutsideWorld;
import org.neo4j.commandline.dbms.ImportCommand;
import static org.neo4j.helpers.ArrayUtil.join;
import org.neo4j.tooling.DbConnection.DataCopier;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
import static org.neo4j.tooling.ImportTool.MULTI_FILE_DELIMITER;
public class Main
{
//    private static Logger logger = LogManager.getLogger(Main.class);
    //private  String targetdir = "D://test";
    //private  String csvdir = "D://target";
    private  String targetdir = "/data/database";
    private  String csvdir = "/data/csv";
    private File targetfile =new File(targetdir);
    public static Connection connectionToOracle(String databasename) throws Exception {
        Connection conn = null;
//        String dbURL2 = "";
//        String username = "";
//        String password = "";
        if(databasename.equals("gc"))
        {
            DataCopier copier = DataCopier.getInstance("gc.properties");
            conn = copier.database.openConnection();
//            dbURL2 = "jdbc:oracle:thin:@172.19.6.12:1521:ORCL_DEV";
//            username = "CS_GS_DM";
//            password = "abc123";
        }
        else
        {
            DataCopier copier = DataCopier.getInstance("portal.properties");
            conn = copier.database.openConnection();
            // uat oracle
//            dbURL2 = "jdbc:oracle:thin:@10.100.45.12:1521:orcl";
//            username = "oracle_graphdb_trans";
//            password = "oeTsRSBfSga17SSx";
            //prod oracle
//            dbURL2 = "jdbc:oracle:thin:@10.100.47.14:1521:orclp";
//            username = "cs_portal";
//            password = "RGDU2Csp";
        }
        try {
            // registers Oracle JDBC driver - though this is no longer required
            // since JDBC 4.0, but added here for backward compatibility
//            Class.forName("oracle.jdbc.OracleDriver");
//            conn = DriverManager.getConnection(dbURL2, username, password);
            return conn;
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
    public static String cleanStr(String str)
    {
        String result = "";
        if (str != null && !str.equals(""))
        {
            result ="\""+ str.replace("\"","\"\"").replace("\\","").replace("\r","").replace("\n","").replace("（","(").replace("）",")")+"\"";
            result = result.replaceAll("\\s+", " ");
        }
        else
        {
            result = "";
        }
        return  result;
    }
//    public  static List resultToList(ResultSet resultSet) throws SQLException {
//        List resultList = new ArrayList();
//        ResultSetMetaData result =resultSet.getMetaData();
//        int columnCount = result.getColumnCount();
//        while (resultSet.next()) {
//            Map rowData = new HashMap<String, String>(columnCount);
//            for (int i = 1; i <= columnCount; ++i) {
//                rowData.put(i, resultSet.getString(i));
//            }
//            resultList.add(rowData);
//        }
//        return resultList;
//    }
    public static void exportOracleToCsv(File csvFile,String query,String databasename) throws Exception
    {
        //logger.debug("正在导出文件："+csvFile.getAbsolutePath());
        System.out.println("正在导出文件："+csvFile.getAbsolutePath());
        Connection conn = null;
        try ( PrintStream out = new PrintStream(csvFile))
        {
            conn = connectionToOracle(databasename);
            conn.setAutoCommit(false);
//            Statement stmt = conn.createStatement();
//            ResultSet rs = stmt.executeQuery(query);
            PreparedStatement stmt = conn.prepareStatement(query,ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
            stmt.setFetchSize(50000);
            stmt.setFetchDirection(ResultSet.FETCH_REVERSE);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                if (rs.getRow()%50000 == 0)
                {
                    //logger.debug("正在导出文件："+csvFile.getAbsoluteFile().getPath()+":"+String.valueOf(rs.getRow()));
                    System.out.println("正在导出文件："+csvFile.getAbsoluteFile().getPath()+":"+String.valueOf(rs.getRow()));
                }
                String resultline = "";
                for(int i=1;i<=rs.getMetaData().getColumnCount();i++){
                    //resultline = resultline + Main.cleanStr(rs.getString(i)== null?"":rs.getString(i))+",";
                    resultline = resultline + Main.cleanStr(rs.getString(i))+",";
                }
                resultline = resultline.substring(0,resultline.length()-1);
                out.println(resultline);
            }
//            while(rs.next()){
//                if (rs.getRow()%0 +rownum== 0)
//                {
//                    System.out.println(csvFile.getAbsoluteFile().getPath()+":"+String.valueOf(rs.getRow()));
//                }
//            List<Map>sqpresult = Main.resultToList(rs);
//            for (Map res :sqpresult)
//            {
//                String resultline = "";
//                for (int j = 1;j<=res.size();j++)
//                {
//                    resultline = resultline + Main.cleanStr((res.get(j) == null?"":res.get(j)).toString())+",";
//                }
//                resultline = resultline.substring(0,resultline.length()-1);
//                out.println(resultline);
//            }
                //out.println(rs.getString("COMPANY_ID") + "," +cleanStr(rs.getString("COMPANY_NM")) +","+cleanStr(rs.getString("LEG_REPRESENT")) +","+cleanStr(rs.getString("CONSTANT_NM"))+","+cleanStr(rs.getString("COMPANY_NM")).replace("（","(").replace("）",")"));
//            }
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    public static void exportOracleToCsvWithSplit(File csvFile,String query,String databasename) throws Exception
    {
        //logger.debug("正在导出文件："+csvFile.getAbsolutePath());
        System.out.println("正在导出文件："+csvFile.getAbsolutePath());
        Connection conn = null;
        try ( PrintStream out = new PrintStream(csvFile))
        {
            conn = connectionToOracle(databasename);
            conn.setAutoCommit(false);
//            Statement stmt = conn.createStatement();
//            ResultSet rs = stmt.executeQuery(query);
            PreparedStatement stmt = conn.prepareStatement(query,ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
            stmt.setFetchSize(50000);
            stmt.setFetchDirection(ResultSet.FETCH_REVERSE);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                if (rs.getRow()%50000 == 0)
                {
                    //logger.debug("正在导出文件："+csvFile.getAbsoluteFile().getPath()+":"+String.valueOf(rs.getRow()));
                    System.out.println("正在导出文件："+csvFile.getAbsoluteFile().getPath()+":"+String.valueOf(rs.getRow()));
                }
                if(rs.getString(rs.getMetaData().getColumnCount()) != null)
                {
                    for (String pos : rs.getString(rs.getMetaData().getColumnCount()).split(",|兼") )
                    {
                        String resultline = "";
                        for(int i=1;i<=rs.getMetaData().getColumnCount()-1;i++){
                            //resultline = resultline + Main.cleanStr(rs.getString(i)== null?"":rs.getString(i))+",";
                            resultline = resultline + Main.cleanStr(rs.getString(i))+",";
                        }
                        resultline = resultline + pos;
                        out.println(resultline);
                    }
                }


            }
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    public static void exportOracleToCsvheader(File csvHeaderFile,String header) throws Exception
    {
        // if (!csvHeaderFile.exists()||!csvHeaderFile.isDirectory()){
        //     csvHeaderFile.mkdir();
        // }
        File fileParent = csvHeaderFile.getParentFile();

        if(!fileParent.exists()){
            fileParent.mkdirs();
        }
        System.out.println(fileParent.getAbsolutePath());
        System.out.println(fileParent.exists());
        System.out.println(fileParent.isDirectory());

        if (!csvHeaderFile.exists()){
            csvHeaderFile.createNewFile();
        }

        //logger.debug("正在导出文件："+csvHeaderFile.getAbsolutePath());
        System.out.println("正在导出文件："+csvHeaderFile.getAbsolutePath());
        //System.out.println();
        try ( PrintStream out = new PrintStream( csvHeaderFile ) )
        {
            out.println(header);
        }
    }
    public void separateHeadersCsvImport() throws Exception
    {
//        int rownum = 500000;
        //企业基本信息csv头文件
        File cominfoHeader = file( "ops", "company-info-header.csv" );
        String companyInfoHeaderLine = "COMPANY_ID:ID(COMPANY_ID),COMPANY_NM,STATUS,ORGNUM,REG_CAPITAL";
        Main.exportOracleToCsvheader(cominfoHeader,companyInfoHeaderLine);
        //企业基本信息csv内容
        String query_compbasicinfo = "  SELECT COMPANY_ID,COMPANY_NM,E.CONSTANT_NM,ORGNUM,REG_CAPITAL FROM  CS_GS_DM.VW_COMPY_BASICINFO A LEFT  JOIN CS_CREDIT.LKP_NUMBCODE E ON A.COMPANY_ST = E.CONSTANT_CD AND E.CONSTANT_TYPE =3 ";//WHERE ROWNUM< "+rownum
        File cominfo = file("ops","company-info.csv");
        Main.exportOracleToCsv(cominfo,query_compbasicinfo,"gc");
        //产品基本信息csv头文件
        File securityHeader = file( "ops", "security-info-header.csv" );
        String securityHeaderLine = "SECINNER_ID:ID(SECINNER_ID),SECURITY_CD,SECURITY_NM,SECURITY_TYPE";
        Main.exportOracleToCsvheader(securityHeader,securityHeaderLine);
        //发行关系基本信息csv头文件
        File issueHeader = file( "ops", "issue-info-header.csv" );
        String issueHeaderLine = ":END_ID(SECINNER_ID),:START_ID(COMPANY_ID)" ;
        Main.exportOracleToCsvheader(issueHeader,issueHeaderLine);

        //产品基本信息csv内容
        String query_securityinfo = "SELECT  SECINNER_ID,SECURITY_CD,REPLACE(REPLACE(SECURITY_NM,'）',')'),'（','(') AS SECURITY_NM,B.CONSTANT_NM  FROM CS_CREDIT.SECURITY A  LEFT JOIN CS_CREDIT.LKP_CHARCODE B ON A.SECURITY_TYPE_ID = B.CONSTANT_ID WHERE B.CONSTANT_NM NOT  IN ('A股','B股','H股','三板股')  AND A.SECURITY_NM   NOT   LIKE '%公司' AND A.SECURITY_NM   NOT   LIKE '%有限合伙%'  AND  A.ISDEL = 0 ";//WHERE ROWNUM<100 AND COMPANY_ID = '17'
        File securityinfo = file( "ops", "security-info.csv" );
        Main.exportOracleToCsv(securityinfo,query_securityinfo,"gc");
        //发行关系基本信息csv内容
        String query_issue = "SELECT  SECINNER_ID,COMPANY_ID  FROM CS_CREDIT.SECURITY A  LEFT JOIN CS_CREDIT.LKP_CHARCODE B ON A.SECURITY_TYPE_ID = B.CONSTANT_ID WHERE B.CONSTANT_NM NOT  IN ('A股','B股','H股','三板股')  AND A.SECURITY_NM   NOT   LIKE '%公司' AND A.SECURITY_NM   NOT   LIKE '%有限合伙%'  AND  A.ISDEL = 0 ";//WHERE ROWNUM<100 AND COMPANY_ID = '17'
        File issuerelation = file( "ops", "issue-relation.csv" );
        Main.exportOracleToCsv(issuerelation,query_issue,"gc");
        //高管基本信息csv头文件
        File employeepersonHeader = file( "ops", "employeeperson-info-header.csv" );
        String employeepersonHeaderLine = "PERSON_ID:ID(PERSON_ID),PERSON_NM";
        Main.exportOracleToCsvheader(employeepersonHeader,employeepersonHeaderLine);
        //高管基本信息csv内容
        //String query_employeepersoninfo = "select TO_CHAR(COMPANY_ID)||SHAREHD_NAME AS PERSON_ID,SHAREHD_NAME FROM  CS_GS_DM.VW_COMPY_SHAREHDINVEST_XYGS  WHERE SHAREHD_TYPE = '1' AND ROWNUM< 0+rownum";//WHERE ROWNUM<10 AND COMPANY_ID = '17'0
        String query_employeepersoninfo = "SELECT COMPANY_ID||PERSON_NM AS PERSON_ID,PERSON_NM FROM  CS_GS_DM.VW_COMPY_EMPLOYEE_XYGS  ";//WHERE ROWNUM<100 AND COMPANY_ID = '17'
        File employeepersoninfo = file( "ops", "employeeperson-info.csv" );
        Main.exportOracleToCsv(employeepersoninfo,query_employeepersoninfo,"gc");
        //法定代表人基本信息csv内容
        String query_frpersoninfo = "SELECT COMPANY_ID||LEG_REPRESENT AS PERSON_ID,LEG_REPRESENT AS PERSON_NM FROM  CS_GS_DM.VW_COMPY_BASICINFO WHERE LEG_REPRESENT IS NOT NULL";//WHERE ROWNUM<100 AND COMPANY_ID = '17'
        File frpersoninfo = file("ops","frperson-info.csv");
        Main.exportOracleToCsv(frpersoninfo,query_frpersoninfo,"gc");
        //任职关系csv头文件
        File employeeHeader = file( "ops", "employ-info-header.csv" );
        String employeeHeaderLine = "PERSON_ID:START_ID(PERSON_ID),COMPANY_ID:END_ID(COMPANY_ID),POSITION";
        Main.exportOracleToCsvheader(employeeHeader,employeeHeaderLine);
        //任职关系基本信息csv内容
        String query_employee = "SELECT  COMPANY_ID||PERSON_NM AS PERSON_ID,COMPANY_ID,POSITION FROM  CS_GS_DM.VW_COMPY_EMPLOYEE_XYGS WHERE POSITION IS NOT NULL";//WHERE ROWNUM<100 AND COMPANY_ID = '17'
        File employeerelation = file( "ops", "employ-info.csv" );
        Main.exportOracleToCsvWithSplit(employeerelation,query_employee,"gc");
        //法定代表人关系基本信息csv内容
        String query_fr = "SELECT  COMPANY_ID||LEG_REPRESENT AS PERSON_ID,COMPANY_ID,'法定代表人' FROM CS_GS_DM.VW_COMPY_BASICINFO WHERE LEG_REPRESENT IS NOT NULL";//WHERE ROWNUM<100 AND COMPANY_ID = '17'
        File frrelation = file( "ops", "frrelation-info.csv" );
        Main.exportOracleToCsv(frrelation,query_fr,"gc");
        //自然人股东基本信息csv头文件
        File shareHDPersonHeader = file( "ops", "sharehdperson-info-header.csv" );
        String shareHDPersonHeaderLine = "PERSON_ID:ID(PERSON_ID),PERSON_NM";
        Main.exportOracleToCsvheader(shareHDPersonHeader,shareHDPersonHeaderLine);
        //自然人股东基本信息csv内容
        String query_shareHDPersoninfo = "select TO_CHAR(COMPANY_ID)||SHAREHD_NAME AS PERSON_ID,SHAREHD_NAME FROM  CS_GS_DM.VW_COMPY_SHAREHDINVEST_XYGS  WHERE SHAREHD_TYPE = '1' AND ISDEL = 0 ";//AND ROWNUM< "+rownum
        File shareHDPersoninfo = file( "ops", "sharehdperson-info.csv" );
        Main.exportOracleToCsv(shareHDPersoninfo,query_shareHDPersoninfo,"gc");
        //自然人股东关系csv头文件
        File sharehdPersonrelationHeader = file( "ops", "sharehdperson-relation-header.csv" );
        String sharehdPersonrelationHeaderLine = "PERSON_ID:START_ID(PERSON_ID),COMPANY_ID:END_ID(COMPANY_ID),NUM";
        Main.exportOracleToCsvheader(sharehdPersonrelationHeader,sharehdPersonrelationHeaderLine);
        //自然人股东关系基本信息csv内容
        String query_sharehdPersonrelation = "SELECT  COMPANY_ID||SHAREHD_NAME AS PERSON_ID,COMPANY_ID,PAID_AMT AS NUM FROM  CS_GS_DM.VW_COMPY_SHAREHDINVEST_XYGS  WHERE SHAREHD_TYPE = '1' AND ISDEL = 0 ";//AND ROWNUM< "+rownum
        File sharehdPersonrelation = file( "ops", "sharehdperson-relation.csv" );
        Main.exportOracleToCsv(sharehdPersonrelation,query_sharehdPersonrelation,"gc");
        //法人股东关系csv头文件
        File sharehdComprelationHeader = file( "ops", "sharehdcomp-relation-header.csv" );
        String sharehdComprelationHeaderLine = "SHACOMP_ID:START_ID(COMPANY_ID),COMPANY_ID:END_ID(COMPANY_ID),NUM";
        Main.exportOracleToCsvheader(sharehdComprelationHeader,sharehdComprelationHeaderLine);
        //法人股东关系基本信息csv内容
        String query_sharehdComprelation = " SELECT CASE WHEN SHAREHD_ID <> -1 THEN TO_CHAR(SHAREHD_ID) ELSE TO_CHAR(COMPANY_ID)||SHAREHD_NAME END SHACOMP_ID,COMPANY_ID,PAID_AMT AS NUM FROM CS_GS_DM.VW_COMPY_SHAREHDINVEST_XYGS  WHERE SHAREHD_TYPE = '2' AND SHAREHD_ID IS NOT NULL AND ISDEL = 0 ";//AND ROWNUM< "+rownum
        File sharehdComprelation = file( "ops", "sharehdcomp-relation.csv" );
        Main.exportOracleToCsv(sharehdComprelation,query_sharehdComprelation,"gc");
        //自然人股东基本信息csv内容
        String query_shareHDCompanyinfo = "SELECT TO_CHAR(COMPANY_ID)||SHAREHD_NAME AS COMAPNY_ID,SHAREHD_NAME,'','','' FROM  CS_GS_DM.VW_COMPY_SHAREHDINVEST_XYGS WHERE SHAREHD_TYPE = '2' AND SHAREHD_ID = -1 AND ISDEL = 0";//AND ROWNUM< "+rownum
        File shareHDCompanyinfo = file( "ops", "sharehdcompany-info.csv" );
        Main.exportOracleToCsv(shareHDCompanyinfo,query_shareHDCompanyinfo,"gc");
//
////
////        //other info export
////       String query_pfcompany = "SELECT A.COMPANY_ID,B.COMPANY_NM,B.FOUND_DT,SHAREHD_ID,C.COMPANY_ID,SHAREHD_NAME,REG_CD  FROM    CS_CREDIT.COMPY_SHAREHDINVEST_XYGS A    LEFT JOIN CS_CREDIT.COMPY_BASICINFO B ON A.COMPANY_ID = B.COMPANY_ID INNER JOIN  CS_CREDIT.PFCOMPY_BASICINFO C ON A.SHAREHD_NAME = C.COMPANY_NM WHERE    A.SRC_CD = 'TYCGS'    AND B.COMPANY_NM LIKE '%有限合伙%' AND C.ISDEL = 0";//AND ROWNUM< "+rownum
////        File pfcompany = file( "ops", "pfcompany.csv" );
////        Main.exportOracleToCsv(pfcompany,query_pfcompany,"gc");
////
////        String query_manager = " SELECT  SECINNER_ID,SECURITY_NM,MANAGER_ID,B.COMPANY_NM FROM CS_CREDIT.PFUND_BASICINFO A LEFT JOIN CS_CREDIT.COMPY_BASICINFO B ON A.MANAGER_ID = B.COMPANY_ID WHERE SECURITY_NM LIKE '%有限合伙%'";//AND ROWNUM< "+rownum
////        File manager = file( "ops", "manager.csv" );
////        Main.exportOracleToCsv(manager,query_manager,"gc");


        // WHEN
//        String[] arguments = arguments( "--mode", "csv", "--database", "the_database",
//                "--nodes:"+ join( new String[]{"COMPANY"}, ":" ),
//                cominfoHeader.getAbsolutePath() + MULTI_FILE_DELIMITER + cominfo.getAbsolutePath(),
//                "--nodes:"+ join( new String[]{"PERSON"}, ":" ),
//                shareHDPersonHeader.getAbsolutePath() + MULTI_FILE_DELIMITER + shareHDPersoninfo.getAbsolutePath(),
//                "--nodes:"+ join( new String[]{"PERSON"}, ":" ),
//                employeepersonHeader.getAbsolutePath() + MULTI_FILE_DELIMITER + employeepersoninfo.getAbsolutePath()  + MULTI_FILE_DELIMITER + frpersoninfo.getAbsolutePath() ,
//                "--nodes:"+ join( new String[]{"SECURITY"}, ":" ),
//                securityHeader.getAbsolutePath() + MULTI_FILE_DELIMITER + securityinfo.getAbsolutePath(),
//                "--relationships:" + join( new String[]{"ISSUE"}, ":" ),
//                issueHeader.getAbsolutePath() + MULTI_FILE_DELIMITER + issuerelation.getAbsolutePath(),
//                "--relationships:" + join( new String[]{"INVEST"}, ":" ),
//                sharehdPersonrelationHeader.getAbsolutePath() + MULTI_FILE_DELIMITER + sharehdPersonrelation.getAbsolutePath(),
//                "--relationships:" + join( new String[]{"INVEST"}, ":" ),
//                sharehdComprelationHeader.getAbsolutePath() + MULTI_FILE_DELIMITER + sharehdComprelation.getAbsolutePath(),
//                "--relationships:" + join( new String[]{"WORK"}, ":" ),
//                employeeHeader.getAbsolutePath() + MULTI_FILE_DELIMITER + employeerelation.getAbsolutePath() + MULTI_FILE_DELIMITER +  frrelation.getAbsolutePath(),
//                "--ignore-missing-nodes" ,
//                "--ignore-duplicate-nodes"
//                );
//        //importTool( arguments );
//        //
//        // DOCS
//        String realDir = cominfo.getParentFile().getAbsolutePath();
//        printCommandToFile( arguments, realDir, "separate-header-example-command.adoc" );
    }

    private File file( String section, String name )
    {
        File directory = new File( new File( new File(csvdir), "docs" ), section );
        directory.mkdirs();
        return new File( directory, name );
    }
    private String[] arguments( String... arguments )
    {
        return arguments;
    }
    private void printCommandToFile( String[] arguments, String dir, String fileName ) throws FileNotFoundException
    {
        List<String> cleanedArguments = new ArrayList<>();
        for ( String argument : arguments )
        {
            if ( argument.contains( " " ) || argument.contains( "," ) ||
                    Arrays.asList( new String[]{";", "|", "'"} ).contains( argument ) )
            {
                cleanedArguments.add( '"' + argument + '"' );
            }
            else
            {
                cleanedArguments.add( argument );
            }
        }
        String documentationArgs = StringUtils.join( cleanedArguments, " " );
        documentationArgs = documentationArgs.replace( dir + File.separator, "" )
                .replace( targetfile.getAbsolutePath(), "path_to_target_directory" );
        String docsCommand = "neo4j-admin import " + documentationArgs;
        try ( PrintStream out = new PrintStream( file( "ops", fileName ) ) )
        {
            out.println( docsCommand );
        }
    }
//    private void importTool( String[] arguments, OutsideWorld outsideWorld ) throws CommandFailed, IncorrectUsage
//    {
//        ImportCommand importCommand =
//                new ImportCommand( targetfile.toPath(), targetfile.toPath(), outsideWorld );
//        importCommand.execute( arguments );
//    }
//
//    private void importTool( String[] arguments ) throws CommandFailed, IncorrectUsage
//    {
//        importTool( arguments, new RealOutsideWorld( ) );
//    }
    public void otherexporttask() throws Exception {
        //other info export
        String company_id_list = "(12024071,12027626,12022247,11694694,8456380,7573295,6112849,6110773,565940,565092,567128,558740,521963,521870,566684,621930,621912,2931527,6109918,579310,6109821,2930616,574680,2930544,578024,1776472,2931713,486510,488649,488532,487991,484953,487745,509040,490180,491169,476544,479455,479337,478069,482527,481297,481261,422604,451637,450751,430291,422627,467732,470703,466632,459998,468861,468829,473360,475340,416645,417527,417477,421145,418854,420943,419693,420496,419580,420403,406307,369437,370033,369894,369893,368718,406416,368501,406384,412306,408616,412026,409330,409097,410733,410573,411707,407800,408703,409850,411002,362685,358444,358366,358181,360481,358143,359179,360344,357507,366274,363783,364222,364160,364153,367118,309629,309545,350446,349446,332388,337214,357164,355254,356942,354993,357321,356581,296911,297802,295142,297703,297689,297647,297294,295959,296986,303181,308431,304218,307696,301603,304163,301602,305313,307498,289130,287462,287067,284871,284736,291609,292658,294495,294477,294363,294357,294347,293851,289771,289138,291224,289817,241004,239325,241935,241932,241188,239997,246381,246352,280831,244396,263384,244222,255136,244105,242170,231044,230912,232133,233080,232650,233844,232584,235683,237223,237884,235001,237771,182816,185703,180100,184652,179296,181655,178364,186060,221997,190408,192577,220091,189312,228879,189462,227917,191358,211135,189412,206647,189178,223190,223189,164085,165611,166769,169868,177800,175470,174236,175345,175233,121606,119952,122382,122287,121363,119630,119317,121105,119165,160819,163204,163185,146399,146354,158479,161738,159042,161008,143204,113898,113509,113140,109913,118182,116120,117055,117850,117844,117661,115219,79509,67447,70965,88892,62939,68485,62814,108354,105335,105331,107489,54020,53432,50155,53354,49619,51351,47117,49057,56406,54485,60733,56152,55054,57327,54955,35995,35821,37965,29423,37767,37646,25517,43642,40115,43450,42987,42629,44800,39077,43756,10480867,12013772,10240353,12017743,12027700,606793,574429,561166,1776494,580000,563586,566716,566611,6112730,2931640,505354,485291,485237,484312,491387,481142,480982,491224,507401,520914,411997,415407,422169,418803,414056,420766,442344,470720,479449,475442,469842,468981,468977,468965,464232,354264,336219,350609,346917,313695,354826,363725,363235,366419,361580,407126,366124,360559,365080,364986,400902,244386,241084,286904,286061,239922,239797,285767,242334,246371,239402,245203,238634,238439,238399,298262,294497,304197,303959,296656,292393,181313,169839,169835,181215,180458,173844,168925,187308,187287,168590,167802,167743,166467,216449,211083,234536,230173,232577,105666,111903,115296,115293,110589,79505,109779,69612,118690,121374,121361,121088,117853,117641,117582,160852,160839,159861,125557,119754,35429,7933323,35078,40337,34759,40006,53302,59367,65474,56663,50573,42493,61980,41416,60693,41370,41302,46003,12030741,175369,557302,9299440,6109784,386284,301619,505940,294896,37766,419023,12063789,135017,68709,106855,7338080)";
        String query_pfcompany = "SELECT *  FROM    CS_CREDIT.COMPY_BASICINFONB_XYGS A  WHERE COMPANY_ID IN " + company_id_list;
        File pfcompany = file( "ops", "COMPY_BASICINFONB_XYGS.csv" );
        Main.exportOracleToCsv(pfcompany,query_pfcompany,"gc");

    }



    public static void main(String[] args) throws Exception {
        Main main = new Main();
        main.separateHeadersCsvImport();
        //main.otherexporttask();

    }

}
