package org.neo4j.tooling.util;

/**
 * Created by wuchenglong on 2017/12/27.
 */



import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.util.*;
import java.util.logging.Logger;
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;

public class ConfigUtil {

    private static final Logger LOGGER = Logger.getLogger(ConfigUtil.class.getName());

    /**
     * 初始化配置文件
     * @param configFileName
     * @param mappingClass
     * @throws Exception
     */
    public static void initConfig(String configFileName, Class<?> mappingClass) throws Exception {
        Map<String, String> map = convertToMap(configFileName);
        mapping(map, mappingClass);
        LOGGER.info("Loading config file successfully");
    }

    private static Map<String, String> convertToMap(String configFileName) throws Exception {
        LOGGER.info(configFileName);
        Map<String, String> map = new HashMap<>();
        try {
            Properties prop = new Properties();
            prop.load(new InputStreamReader(ConfigUtil.class.getClassLoader().getResourceAsStream(configFileName),
                    "utf-8"));
            for (Object k : prop.keySet()) {
                Object v = prop.get(k);
                String key = String.valueOf(k), value = String.valueOf(v);
                map.put(key, value);
            }

        } catch (Exception e) {
            LOGGER.severe("Occurring an exception when to execute the method 'convertToMap' for "+ e.toString());
            throw e;
        }
        return map;
    }

    private static void mapping(Map<String, String> map, Class<?> mappingClass) {
        try {
            Field[] fields = mappingClass.getFields();
            for (Field f : fields) {
                String val = map.get(f.getName());
                if (val == null || val.length() == 0) {
                    continue;
                }
                if (f.getType() == Integer.class || f.getType() == int.class) {
                    f.set(mappingClass, Integer.valueOf(val));
                } else if (f.getType() == Byte.class || f.getType() == byte.class) {
                    f.set(mappingClass, Byte.valueOf(val));
                } else if (f.getType() == Long.class || f.getType() == long.class) {
                    f.set(mappingClass, Long.valueOf(val));
                } else if (f.getType() == Short.class || f.getType() == short.class) {
                    f.set(mappingClass, Short.valueOf(val));
                } else if (f.getType() == String.class) {
                    f.set(mappingClass, String.valueOf(val));
                } else if (f.getType() == Double.class || f.getType() == double.class) {
                    f.set(mappingClass, Double.valueOf(val));
                } else if (f.getType() == Float.class || f.getType() == float.class) {
                    f.set(mappingClass, Float.valueOf(val));
                } else if (f.getType() == Boolean.class || f.getType() == boolean.class) {
                    f.set(mappingClass, Boolean.valueOf(val));
                } else if (f.getType() == List.class || f.getType() == ArrayList.class
                        || f.getType() == LinkedList.class) {
                    List<String> list = new ArrayList<>();
                    Collections.addAll(list, val.split(";"));
                    f.set(mappingClass, list);
                } else {
                    throw new Exception("unsupported data type");
                }
            }

        } catch (Exception e) {
            LOGGER.severe("Occurring an exception when to execute the method 'mapping' for {}"+ e.toString());
        }

    }

}