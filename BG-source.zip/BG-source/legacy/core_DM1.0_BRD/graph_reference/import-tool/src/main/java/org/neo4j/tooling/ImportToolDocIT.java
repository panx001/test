package org.neo4j.tooling;
/*
 * Copyright (c) 2002-2018 "Neo Technology,"
 * Network Engine for Objects in Lund AB [http://neotechnology.com]
 *
 * This file is part of Neo4j.
 *
 * Neo4j is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
import org.apache.commons.lang3.StringUtils;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.sql.*;
import java.util.*;
import org.neo4j.commandline.admin.CommandFailed;
import org.neo4j.commandline.admin.IncorrectUsage;
import org.neo4j.commandline.admin.OutsideWorld;
import org.neo4j.commandline.admin.RealOutsideWorld;
import org.neo4j.commandline.dbms.ImportCommand;
import static org.neo4j.helpers.ArrayUtil.join;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
import static org.neo4j.tooling.ImportTool.MULTI_FILE_DELIMITER;
public class ImportToolDocIT
{
//    private static Logger logger = LogManager.getLogger(ImportToolDocIT.class);
    //private  String targetdir = "D://test";
    //private  String csvdir = "D://target";
    private  String targetdir = "data/database";
    private  String csvdir = "data/csv";
    private File targetfile =new File(targetdir);
    public static Connection connectionToOracle(String databasename)
    {
        Connection conn = null;
        String dbURL2 = "";
        String username = "";
        String password = "";
        if(databasename.equals("gc"))
        {
            dbURL2 = "jdbc:oracle:thin:@172.19.6.12:1521:ORCL_DEV";
            username = "cs_gs_dm";
            password = "abc123";
        }
        else
        {
            dbURL2 = "jdbc:oracle:thin:@10.100.45.12:1521:orcl";
            username = "oracle_graphdb_trans";
            password = "oeTsRSBfSga17SSx";
        }
        try {
            // registers Oracle JDBC driver - though this is no longer required
            // since JDBC 4.0, but added here for backward compatibility
            Class.forName("oracle.jdbc.OracleDriver");
            conn = DriverManager.getConnection(dbURL2, username, password);
            return conn;
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }
    public static String cleanStr(String str)
    {
        String result = "";
        if (str != null)
        {
            result ="\""+ str.replace("\"","\"\"").replace("\\","").replace("\r","").replace("\n","")+"\"";
        }
        else
        {
            result = null;
        }
        return  result;
    }
    public  static List resultToList(ResultSet resultSet) throws SQLException {
        List resultList = new ArrayList();
        ResultSetMetaData result =resultSet.getMetaData();
        int columnCount = result.getColumnCount();
        while (resultSet.next()) {
            Map rowData = new HashMap<String, String>(columnCount);
            for (int i = 1; i <= columnCount; ++i) {
                rowData.put(i, resultSet.getString(i));
            }
            resultList.add(rowData);
        }
        return resultList;
    }
    public static void exportOracleToCsv(File csvFile,String query,String databasename) throws Exception
    {
        //logger.debug("正在导出文件："+csvFile.getAbsolutePath());
        System.out.println("正在导出文件："+csvFile.getAbsolutePath());
        Connection conn = null;
        try ( PrintStream out = new PrintStream(csvFile))
        {
            conn = connectionToOracle(databasename);
            conn.setAutoCommit(false);
//            Statement stmt = conn.createStatement();
//            ResultSet rs = stmt.executeQuery(query);
            PreparedStatement stmt = conn.prepareStatement(query,ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
            stmt.setFetchSize(50000);
            stmt.setFetchDirection(ResultSet.FETCH_REVERSE);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                if (rs.getRow()%50000 == 0)
                {
                    //logger.debug("正在导出文件："+csvFile.getAbsoluteFile().getPath()+":"+String.valueOf(rs.getRow()));
                    System.out.println("正在导出文件："+csvFile.getAbsoluteFile().getPath()+":"+String.valueOf(rs.getRow()));
                }
                String resultline = "";
//                List<Map>sqpresult = ImportToolDocIT.resultToList(rs);
//                for (Map res :sqpresult)
//                {
//                    String resultline = "";
//                    for (int j = 1;j<=res.size();j++)
//                    {
//                        resultline = resultline + ImportToolDocIT.cleanStr((res.get(j) == null?"":res.get(j)).toString())+",";
//                    }
//                    resultline = resultline.substring(0,resultline.length()-1);
//                    out.println(resultline);
//                }
                for(int i=1;i<=rs.getMetaData().getColumnCount();i++){
                    resultline = resultline + ImportToolDocIT.cleanStr(rs.getString(i)== null?"":rs.getString(i));
                }
                resultline = resultline.substring(0,resultline.length()-1);
                out.println(resultline);
            }
//            while(rs.next()){
//                if (rs.getRow()%0 +rownum== 0)
//                {
//                    System.out.println(csvFile.getAbsoluteFile().getPath()+":"+String.valueOf(rs.getRow()));
//                }
//            List<Map>sqpresult = ImportToolDocIT.resultToList(rs);
//            for (Map res :sqpresult)
//            {
//                String resultline = "";
//                for (int j = 1;j<=res.size();j++)
//                {
//                    resultline = resultline + ImportToolDocIT.cleanStr((res.get(j) == null?"":res.get(j)).toString())+",";
//                }
//                resultline = resultline.substring(0,resultline.length()-1);
//                out.println(resultline);
//            }
                //out.println(rs.getString("COMPANY_ID") + "," +cleanStr(rs.getString("COMPANY_NM")) +","+cleanStr(rs.getString("LEG_REPRESENT")) +","+cleanStr(rs.getString("CONSTANT_NM"))+","+cleanStr(rs.getString("COMPANY_NM")).replace("（","(").replace("）",")"));
//            }
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    public static void exportOracleToCsvheader(File csvHeaderFile,String header) throws Exception
    {
        // if (!csvHeaderFile.exists()||!csvHeaderFile.isDirectory()){
        //     csvHeaderFile.mkdir();
        // }
        File fileParent = csvHeaderFile.getParentFile();

        if(!fileParent.exists()){
            fileParent.mkdirs();
        }
        System.out.println(fileParent.getAbsolutePath());
        System.out.println(fileParent.exists());
        System.out.println(fileParent.isDirectory());

        if (!csvHeaderFile.exists()){
            csvHeaderFile.createNewFile();
        }

        //logger.debug("正在导出文件："+csvHeaderFile.getAbsolutePath());
        System.out.println("正在导出文件："+csvHeaderFile.getAbsolutePath());
        //System.out.println();
        try ( PrintStream out = new PrintStream( csvHeaderFile ) )
        {
            out.println(header);
        }
    }
    public void separateHeadersCsvImport() throws Exception
    {
        int rownum = 500000;
        //企业基本信息csv头文件
        File cominfoHeader = file( "ops", "company-info-header.csv" );
        String companyInfoHeaderLine = "COMPANY_ID:ID(COMPANY_ID),COMPANY_NM,LEG_REPRESENT,CONSTANT_NM,ORGNUM";
        ImportToolDocIT.exportOracleToCsvheader(cominfoHeader,companyInfoHeaderLine);
        //企业基本信息csv内容
        String query_compbasicinfo = "select COMPANY_ID,COMPANY_NM,LEG_REPRESENT,E.CONSTANT_NM,ORGNUM FROM  CS_GS_DM.VW_COMPY_BASICINFO A LEFT  JOIN CS_CREDIT.LKP_NUMBCODE E ON A.COMPANY_ST = E.CONSTANT_CD AND E.CONSTANT_TYPE =3 ";//WHERE ROWNUM< "+rownum
        File cominfo = file("ops","company-info.csv");
        ImportToolDocIT.exportOracleToCsv(cominfo,query_compbasicinfo,"gc");
        //产品基本信息csv头文件
        File securityHeader = file( "ops", "sucurity-info-header.csv" );
        String securityHeaderLine = "SECINNER_ID:ID(SECINNER_ID),SECURITY_CD,SECURITY_NM,IS_DEL";
        ImportToolDocIT.exportOracleToCsvheader(securityHeader,securityHeaderLine);
        //发行关系基本信息csv头文件
        File issueHeader = file( "ops", "issue-info-header.csv" );
        String issueHeaderLine = ":END_ID(SECINNER_ID),:START_ID(COMPANY_ID)" ;
        ImportToolDocIT.exportOracleToCsvheader(issueHeader,issueHeaderLine);
//
//        //产品基本信息csv内容
        String query_securityinfo = "SELECT  SECINNER_ID,SECURITY_CD,SECURITY_NM,ISDEL AS IS_DEL FROM CS_PORTAL.SECURITY ";//WHERE ROWNUM<100 AND COMPANY_ID = '17'
        File securityinfo = file( "ops", "security-info.csv" );
        ImportToolDocIT.exportOracleToCsv(securityinfo,query_securityinfo,"portal");
        //发行关系基本信息csv内容
        String query_issue = "SELECT  SECINNER_ID,COMPANY_ID FROM CS_PORTAL.SECURITY ";//WHERE ROWNUM<100 AND COMPANY_ID = '17'
        File issuerelation = file( "ops", "issue-relation.csv" );
        ImportToolDocIT.exportOracleToCsv(issuerelation,query_issue,"portal");
//
        //高管基本信息csv头文件
        File employeepersonHeader = file( "ops", "employeeperson-info-header.csv" );
        String employeepersonHeaderLine = "PERSON_ID:ID(PERSON_ID),PERSON_NM";
        ImportToolDocIT.exportOracleToCsvheader(employeepersonHeader,employeepersonHeaderLine);
        //高管基本信息csv内容
        //String query_employeepersoninfo = "select TO_CHAR(COMPANY_ID)||SHAREHD_NAME AS PERSON_ID,SHAREHD_NAME FROM  CS_GS_DM.VW_COMPY_SHAREHDINVEST_XYGS  WHERE SHAREHD_TYPE = '1' AND ROWNUM< 0+rownum";//WHERE ROWNUM<10 AND COMPANY_ID = '17'0
        String query_employeepersoninfo = "select COMPANY_ID||PERSON_NM AS PERSON_ID,PERSON_NM FROM  CS_GS_DM.VW_COMPY_EMPLOYEE_XYGS  ";//WHERE ROWNUM<100 AND COMPANY_ID = '17'
        File employeepersoninfo = file( "ops", "employeeperson-info.csv" );
        ImportToolDocIT.exportOracleToCsv(employeepersoninfo,query_employeepersoninfo,"gc");
        //任职关系csv头文件
        File employeeHeader = file( "ops", "employ-info-header.csv" );
        String employeeHeaderLine = "PERSON_ID:START_ID(PERSON_ID),COMPANY_ID:END_ID(COMPANY_ID),POSITION";
        ImportToolDocIT.exportOracleToCsvheader(employeeHeader,employeeHeaderLine);
        //任职关系基本信息csv内容
        String query_employee = "SELECT  COMPANY_ID||PERSON_NM AS PERSON_ID,COMPANY_ID,POSITION FROM  CS_GS_DM.VW_COMPY_EMPLOYEE_XYGS  ";//WHERE ROWNUM<100 AND COMPANY_ID = '17'
        File employeerelation = file( "ops", "employ-info.csv" );
        ImportToolDocIT.exportOracleToCsv(employeerelation,query_employee,"gc");
        //自然人股东基本信息csv头文件
        File shareHDPersonHeader = file( "ops", "sharehdperson-info-header.csv" );
        String shareHDPersonHeaderLine = "PERSON_ID:ID(PERSON_ID),PERSON_NM";
        ImportToolDocIT.exportOracleToCsvheader(shareHDPersonHeader,shareHDPersonHeaderLine);
        //自然人股东基本信息csv内容
        String query_shareHDPersoninfo = "select TO_CHAR(COMPANY_ID)||SHAREHD_NAME AS PERSON_ID,SHAREHD_NAME FROM  CS_GS_DM.VW_COMPY_SHAREHDINVEST_XYGS  WHERE SHAREHD_TYPE = '1' ";//AND ROWNUM< "+rownum
        File shareHDPersoninfo = file( "ops", "sharehdperson-info.csv" );
        ImportToolDocIT.exportOracleToCsv(shareHDPersoninfo,query_shareHDPersoninfo,"gc");
        //自然人股东关系csv头文件
        File sharehdPersonrelationHeader = file( "ops", "sharehdperson-relation-header.csv" );
        String sharehdPersonrelationHeaderLine = "PERSON_ID:START_ID(PERSON_ID),COMPANY_ID:END_ID(COMPANY_ID),NUM";
        ImportToolDocIT.exportOracleToCsvheader(sharehdPersonrelationHeader,sharehdPersonrelationHeaderLine);
        //自然人股东关系基本信息csv内容
        String query_sharehdPersonrelation = "SELECT  COMPANY_ID||SHAREHD_NAME AS PERSON_ID,COMPANY_ID,PAID_AMT AS NUM FROM  CS_GS_DM.VW_COMPY_SHAREHDINVEST_XYGS  WHERE SHAREHD_TYPE = '1' ";//AND ROWNUM< "+rownum
        File sharehdPersonrelation = file( "ops", "sharehdperson-relation.csv" );
        ImportToolDocIT.exportOracleToCsv(sharehdPersonrelation,query_sharehdPersonrelation,"gc");
        //法人股东关系csv头文件
        File sharehdComprelationHeader = file( "ops", "sharehdcomp-relation-header.csv" );
        String sharehdComprelationHeaderLine = "SHACOMP_ID:START_ID(COMPANY_ID),COMPANY_ID:END_ID(COMPANY_ID),NUM";
        ImportToolDocIT.exportOracleToCsvheader(sharehdComprelationHeader,sharehdComprelationHeaderLine);
        //法人股东关系基本信息csv内容
        String query_sharehdComprelation = "SELECT  SHAREHD_ID AS SHACOMP_ID,COMPANY_ID,PAID_AMT AS NUM FROM CS_GS_DM.VW_COMPY_SHAREHDINVEST_XYGS  WHERE SHAREHD_TYPE = '2' ";//AND ROWNUM< "+rownum
        File sharehdComprelation = file( "ops", "sharehdcomp-relation.csv" );
        ImportToolDocIT.exportOracleToCsv(sharehdComprelation,query_sharehdComprelation,"gc");
        // WHEN
        String[] arguments = arguments( "--mode", "csv", "--database", "the_database",
                "--nodes:"+ join( new String[]{"COMPANY"}, ":" ),
                cominfoHeader.getAbsolutePath() + MULTI_FILE_DELIMITER + cominfo.getAbsolutePath(),
                "--nodes:"+ join( new String[]{"PERSON"}, ":" ),
                shareHDPersonHeader.getAbsolutePath() + MULTI_FILE_DELIMITER + shareHDPersoninfo.getAbsolutePath(),
                "--nodes:"+ join( new String[]{"PERSON"}, ":" ),
                employeepersonHeader.getAbsolutePath() + MULTI_FILE_DELIMITER + employeepersoninfo.getAbsolutePath(),
                "--nodes:"+ join( new String[]{"SECURITY"}, ":" ),
                securityHeader.getAbsolutePath() + MULTI_FILE_DELIMITER + securityinfo.getAbsolutePath(),
                "--relationships:" + join( new String[]{"ISSUE"}, ":" ),
                issueHeader.getAbsolutePath() + MULTI_FILE_DELIMITER + issuerelation.getAbsolutePath(),
                "--relationships:" + join( new String[]{"INVEST"}, ":" ),
                sharehdPersonrelationHeader.getAbsolutePath() + MULTI_FILE_DELIMITER + sharehdPersonrelation.getAbsolutePath(),
                "--relationships:" + join( new String[]{"INVEST"}, ":" ),
                sharehdComprelationHeader.getAbsolutePath() + MULTI_FILE_DELIMITER + sharehdComprelation.getAbsolutePath(),
                "--relationships:" + join( new String[]{"WORK"}, ":" ),
                employeeHeader.getAbsolutePath() + MULTI_FILE_DELIMITER + employeerelation.getAbsolutePath(),
                "--ignore-missing-nodes" ,
                "--ignore-duplicate-nodes"
                );
        //importTool( arguments );
        //
        // DOCS
        String realDir = cominfo.getParentFile().getAbsolutePath();
        printCommandToFile( arguments, realDir, "separate-header-example-command.adoc" );
    }
    private void printCommandToFile( String[] arguments, String dir, String fileName ) throws FileNotFoundException
    {
        List<String> cleanedArguments = new ArrayList<>();
        for ( String argument : arguments )
        {
            if ( argument.contains( " " ) || argument.contains( "," ) ||
                    Arrays.asList( new String[]{";", "|", "'"} ).contains( argument ) )
            {
                cleanedArguments.add( '"' + argument + '"' );
            }
            else
            {
                cleanedArguments.add( argument );
            }
        }
        String documentationArgs = StringUtils.join( cleanedArguments, " " );
        documentationArgs = documentationArgs.replace( dir + File.separator, "" )
                .replace( targetfile.getAbsolutePath(), "path_to_target_directory" );
        String docsCommand = "neo4j-admin import " + documentationArgs;
        try ( PrintStream out = new PrintStream( file( "ops", fileName ) ) )
        {
            out.println( docsCommand );
        }
    }
    private File file( String section, String name )
    {
        File directory = new File( new File( new File(csvdir), "docs" ), section );
        directory.mkdirs();
        return new File( directory, name );
    }
    private String[] arguments( String... arguments )
    {
        return arguments;
    }
    private void importTool( String[] arguments, OutsideWorld outsideWorld ) throws CommandFailed, IncorrectUsage
    {
        ImportCommand importCommand =
                new ImportCommand( targetfile.toPath(), targetfile.toPath(), outsideWorld );
        importCommand.execute( arguments );
    }
    private void importTool( String[] arguments ) throws CommandFailed, IncorrectUsage
    {
        importTool( arguments, new RealOutsideWorld( ) );
    }
    public static void main(String[] args) throws Exception {
        ImportToolDocIT importToolDocIT = new ImportToolDocIT();
        importToolDocIT.separateHeadersCsvImport();
    }
}
