package org.neo4j.tooling.DbConnection;

import org.neo4j.tooling.config.DbConnectionConfig;
import org.neo4j.tooling.util.ConfigUtil;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;


/**
 * Created by wuchenglong on 2017/12/21.
 */

public class DataCopier {

    public Database database;

    public static void rollBack(Connection con) {
        try {
            con.rollback();
        } catch (SQLException ex) {
            //Do Nothing
        }
    }

    public DataCopier() {
        this.database = new Database();
    }

    public static DataCopier getInstance(String fileName) throws Exception {
        try {
            ConfigUtil.initConfig(fileName, DbConnectionConfig.class);
            DataCopier copier = new DataCopier();

            copier.database.setJdbcDriverClassName(DbConnectionConfig.JdbcDriverClassName);
            copier.database.setJdbcUrl(DbConnectionConfig.JdbcUrl);
            copier.database.setUsername(DbConnectionConfig.Username);
            copier.database.setPassword(DbConnectionConfig.Password);

            return copier;

        } catch (FileNotFoundException e) {
            throw new IllegalArgumentException("unable to locate input-file = " + fileName);
        } catch (IOException e) {
            throw new RuntimeException("unable to close the input stream");
        }

    }

    public String toString() {
        return database.toString();
    }
}