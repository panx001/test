
#! /bin/sh

today=`date +%Y_%m_%d`
delete_day=`date -d '-30 day' +%Y_%m_%d`
echo $today
mkdir "/data/update/$today" -p
rm -rf "/data/update/$delete_day"

start="`date '+%Y-%m-%d %H:%M:%S'` 非公开企业增量更新开始"
echo $start  >>  "/data/update/`date +%Y_%m_%d`/info.log"
#cd /home/zhoujr/target && java -cp  Neo4jConnection-1.1-SNAPSHOT.jar spring.data.neo4j.UpdatePrivateCompanyFromCsv test  >>  "/data/update/`date +%Y_%m_%d`/info.log"

echo "`date '+%Y-%m-%d %H:%M:%S'` 增量更新结束" >>  "/data/update/`date +%Y_%m_%d`/info.log"
/opt/neo4j-enterprise-3.3.0/bin/neo4j-shell -host 10.100.45.35 -port 1337 -file /home/zhoujr/increaseUpdate.cql >>  "/data/update/`date +%Y_%m_%d`/info.log"
echo "`date '+%Y-%m-%d %H:%M:%S'` 公开企业全量更新结束" >>  "/data/update/`date +%Y_%m_%d`/info.log"

cd /home/zhoujr/target && java -cp  Neo4jConnection-1.1-SNAPSHOT.jar spring.data.neo4j.UpdateRiskLabelFromRedis test  >>  "/data/update/`date +%Y_%m_%d`/info.log"
echo "`date '+%Y-%m-%d %H:%M:%S'` 私募企业风险信息更新结束" >>  "/data/update/`date +%Y_%m_%d`/info.log"
cd /home/zhoujr/target && java -cp  Neo4jConnection-1.1-SNAPSHOT.jar spring.data.neo4j.UpdatePrivateCompanyRiskLabelFromOracle test  >>  "/data/update/`date +%Y_%m_%d`/info.log"
echo "`date '+%Y-%m-%d %H:%M:%S'` 非公开企业风险信息更新结束" >>  "/data/update/`date +%Y_%m_%d`/info.log"
cd /home/zhoujr/target && java -cp  Neo4jConnection-1.1-SNAPSHOT.jar spring.data.neo4j.UpdateDailyMail test
echo "`date '+%Y-%m-%d %H:%M:%S'` 发送邮件完成" >>  "/data/update/`date +%Y_%m_%d`/info.log"