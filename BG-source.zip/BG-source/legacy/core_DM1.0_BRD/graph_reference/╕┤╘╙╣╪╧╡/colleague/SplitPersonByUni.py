#-*- coding:utf-8 -*-
import time,os,math,csv
from optparse import OptionParser

# with open('resume_for_database.csv','r',encoding = 'utf-8') as f:
#     lines = csv.reader(f)
#     for line in lines:
#         print(line['birth_date'])
#         break
# text = "20167111	宁兴勇	1966		"
# print(text.split("\t"))


# lines = [line.replace("\n","").split("\t") for line in (open('resume_for_database.txt', "r",encoding="utf-8").readlines()[1:])]
# print(lines)
# for i,line1 in enumerate(lines):
#     if(i%10000 == 0):
#         print(i)
#     # print(line1)
#     # print(line1[0])
#     # print(i)
#     # print(range(i,len(lines)))
#     # break
#     if (line1[4] != ''):
#         for j in range(i,len(lines)):
#             # print(lines[j])
#             try:
#                 if (line1[0]!=lines[j][0] and line1[4]==lines[j][4] and ((line1[2] !='' and lines[j][2]!='' and abs(int(line1[2])-int(lines[j][2]))<5) or (line1[3] !='' and lines[j][3]!='' and abs(int(line1[3])-int(lines[j][3]))<5))):
#                     # print([line1,lines[j]])
#                     f.write(line1[0]+','+lines[j][0]+'\n')
#             except Exception as e:
#                 print(line1)
#                 print(lines[j])
#                 print(e)
#                 break
lines = open('resume_for_database_v3.txt', "r",encoding="utf-8").readlines()[1:]
for i,line1 in enumerate(lines):
    line = line1.replace("\n","").split("\t")
    with open(os.path.join('colleague',line[5][:2]+'.csv'), 'a',encoding = 'UTF-8') as f:
        f.write(line1)
