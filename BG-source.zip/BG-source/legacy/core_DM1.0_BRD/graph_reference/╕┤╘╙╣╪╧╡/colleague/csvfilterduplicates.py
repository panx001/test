#-*- coding:utf-8 -*-
import os,csv,json

from optparse import OptionParser
#USAGE = "usage: cd /root/NLP-pythonProj/news_sentiment &&  /opt/python3-env/bin/python combine_result.py --cnndir data_prediction --lstmdir data_prediction_lstm --nbdir data_prediction_nb --target data_result "
USAGE = "usage: python csvfilterduplicates.py --soursefile result_csv/link_invest.csv --targetfile result_csv/link_invest.csv "
parser = OptionParser(USAGE)
parser.add_option("--soursefile", dest="soursefile",default = "result_csv/link_invest.csv",help="源csv文件")
parser.add_option("--targetfile", dest="targetfile",default = "result_csv/link_invest_filter.csv",help="写出csv文件")
opt, args = parser.parse_args()
# NEO4J_ENV = opt.NEO4J_ENV if opt.NEO4J_ENV else "UAT_NEO4J"

class FilterDuplicates:
    def __init__(self):
        pass

    def filterCSV(self,soursefile,targetfile):
        soursefile = open(soursefile,'r',encoding = 'UTF-8').readlines()
        filehead = soursefile[0]
        soursefile = soursefile[1:]
        # print(soursefile)
        resultfile = list(set(soursefile))
        with open(targetfile,'a+',newline='',encoding = 'UTF-8') as f:
            f.write(filehead)
            f.writelines(resultfile)


if __name__ == "__main__":
    filterDuplicates = FilterDuplicates()
    filterDuplicates.filterCSV(opt.soursefile,opt.targetfile)