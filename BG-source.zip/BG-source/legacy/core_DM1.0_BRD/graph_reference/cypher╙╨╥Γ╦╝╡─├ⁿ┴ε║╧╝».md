# Cypher apoc命令

## 数据库预热
    CALL apoc.warmup.run()

## 显示数据库中边和点的各种统计信息

    CALL apoc.meta.stats yield labelCount, relTypeCount, propertyKeyCount, nodeCount, relCount, labels, relTypes, stats


## 导出csv文件
call apoc.export.csv.query("
match(C:COMPANY) where (C)<-[:INVEST]-(C)
return distinct C.COMPANY_ID,C.COMPANY_NM","/home/zhoujr/selfinvest.csv",{})



## 点边的连接方式
    CALL apoc.meta.schema();
    CALL apoc.meta.graphSample()



## 判断属性的数据结构

    MATCH (n:Person)
    CALL apoc.meta.isType(n.age,"INTEGER")
    RETURN n LIMIT 5


## 转成json

    CALL apoc.convert.toJson( {a:42,b:"foo",c:[1,2,3]})
    CALL apoc.convert.fromJsonMap( '{"a":42,"b":"foo","c":[1,2,3]}')


## 查询翻页

    CALL apoc.warmup.run()

    apoc.convert.toString(value)        tries it’s best to convert the value to a string
    apoc.convert.toMap(value)           tries it’s best to convert the value to a map
    apoc.convert.toList(value)          tries it’s best to convert the value to a list
    apoc.convert.toBoolean(value)       tries it’s best to convert the value to a boolean
    apoc.convert.toNode(value)          tries it’s best to convert the value to a node
    apoc.convert.toRelationship(value)  tries it’s best to convert the value to a relationship
    apoc.convert.toSet(value)           tries it’s best to convert the value to a set


    apoc.coll.sum([0.5,1,2.3])          sum of all values in a list
    apoc.coll.avg([0.5,1,2.3])          avg of all values in a list
    apoc.coll.min([0.5,1,2.3])          minimum of all values in a list
    apoc.coll.max([0.5,1,2.3])          maximum of all values in a list
    ........


## 时间转换

    CALL apoc.date.formatTimeZone(timestamp(),'ms', 'yyyy/MM/dd HH/mm/ss','PRC')  



## 域名识别

    WITH 'foo@bar.com' AS email
    CALL apoc.data.domain(email) YIELD domain
    RETURN domain // will return 'bar.com'


## ！！！//PageRank相关的的四个函数，当前版本3.0.x中，pagerank只支持全图的pr计算，不支持子图pr。实际使用时感觉不是原版的全节点pagerank计算，因为1827个节点的万科两层pr计算只用了31s。但不相关的100个点运行了很久很久

    public Stream<NodeScore> pageRank(@Name("nodes") List<Node> nodes)   //传入节点即可
    public Stream<NodeScore> pageRankWithConfig(@Name("nodes") List<Node> nodes, @Name("config") Map<String, Object> config)    //传入节点+参数
    public Stream<PageRankStatistics> pageRankStats(@Name("config") Map<String, Object> config)@Description( "CALL apoc.algo.pageRankStats({iterations:_,types:_,write:true,...}) YIELD nodeCount - calculates page rank on graph for given nodes and potentially writes back")
    public Stream<PageRankStatistics> pageRankWithCypher( @Name("config") Map<String, Object> config)       //@Description("CALL apoc.algo.pageRankWithCypher({iterations,node_cypher,rel_cypher,write,property,numCpu}) - calculates page rank based on cypher input")

## pagerank例子：

    match(c:COMPANY)-[*0..2]-(p:COMPANY) where c.COMPANY_NM = '万科企业股份有限公司'      //万科两条以内节点
    with collect(p) as nods
    call apoc.algo.pageRankWithConfig(nods,{types:'INVEST'}) YIELD node, score                  //参数type：边的类型  默认迭代20次   其他可选参数iterations,node_cypher,rel_cypher,write,property,numCpu   
    with node, score 
    return distinct CASE WHEN node:PERSON THEN node.PERSON_NM ELSE node.COMPANY_NM END AS NODENM , score


## 一个不错的参考网站：http://www.codesec.net/view/449354.html

## 中心度计算//算法复杂度较高。取一层关联的节点计算得到的结果比较奇怪，可能要放大一点子图的大小（放大子图后运行时间有点长）（在neo4j自带的movie数据集上，171个点，耗时218ms）

    match(c:COMPANY)-[*0..2]-(p:COMPANY) where c.COMPANY_NM = '万科企业股份有限公司'
    with collect(p) as nods
    CALL apoc.algo.closeness(['INVEST'],nods,'INCOMING') YIELD node, score
    return distinct CASE WHEN node:PERSON THEN node.PERSON_NM ELSE node.COMPANY_NM END AS NODENM , score
    ORDER BY score DESC

## //Betweenness centrality,与上面一个类似 图中所有除节点v外的节点对之间经过v的最短路径数/图中所有除节点v外的节点对之间所有的最短路径数;

    match(c:COMPANY)-[*0..2]-(p:COMPANY) where c.COMPANY_NM = '万科企业股份有限公司'
    with collect(p) as nods
    CALL apoc.algo.betweenness(['INVEST'], nods, 'BOTH')  YIELD node, score
    return distinct CASE WHEN node:PERSON THEN node.PERSON_NM ELSE node.COMPANY_NM END AS NODENM , score
    ORDER BY score DESC


## ！！！//边扩展，从一个节点开始，设定边的类型方向，向外扩展，minlevel和maxlevel设置停止点的层级范围
match (c:COMPANY)  where c.COMPANY_NM = '万科企业股份有限公司'

    call apoc.path.expand(c,"INVEST<","+COMPANY|PERSON",0,6) yield path as pp return pp


## ！！！//将字符串转换为经纬度位置，后台地理编码服务 OSM，Google，OpenCage，区县一级还是能返回数据的，具体到路就不行了

    CALL apoc.spatial.geocodeOnce('中国上海浦东新区') YIELD location
    RETURN location.latitude, location.longitude

## 寻找路径排序样例，不过这个函数我们现在的数据库不支持

    CREATE (bruges:City {name:"bruges", latitude: 51.2605829, longitude: 3.0817189})
    CREATE (brussels:City {name:"brussels", latitude: 50.854954, longitude: 4.3051786})
    CREATE (paris:City {name:"paris", latitude: 48.8588376, longitude: 2.2773455})
    CREATE (dresden:City {name:"dresden", latitude: 51.0767496, longitude: 13.6321595})
    MERGE (bruges)-[:NEXT]->(brussels)
    MERGE (brussels)-[:NEXT]->(dresden)
    MERGE (brussels)-[:NEXT]->(paris)
    MERGE (bruges)-[:NEXT]->(paris)
    MERGE (paris)-[:NEXT]->(dresden)

    MATCH (a:City {name:'bruges'}), (b:City {name:'dresden'})
    MATCH p=(a)-[*]->(b)
    WITH collect(p) as paths
    CALL apoc.spatial.sortPathsByDistance(paths) YIELD path, distance
    RETURN path, distance



## //社区检测，这个神奇的算法我实在是没试验成功过。。。

    CALL apoc.algo.community(1,null,'name','ACTED_IN','OUTGOING','weight',10)        

## //找到图中的极大团，实测不好用，图谱较大直接内存溢出，小图谱运行很久后也没有看到结果

    CALL apoc.algo.cliques(10) YIELD clique return clique    //	search the graph and return all maximal cliques at least at large as the minimum size argument.  

## //度统计

    MATCH (c:Character) RETURN c.name AS character, size( (c)-[:INTERACTS]-() ) AS degree ORDER BY degree DESC
    MATCH (c:Character)-[r:INTERACTS]-() RETURN c.name AS character, sum(r.weight) AS weightedDegree ORDER BY weightedDegree DESC

## load json

    WITH "http://10.100.45.16:7073/chart/pfcompany/company/company_id?link_id=5rex5Zyz5rCR5qOu5oqV6LWE5pyJ6ZmQ5YWs5Y_4&label=1" AS url
    CALL apoc.load.json(url) YIELD value
    return value.Basicinfo,value.RelationList,value.EntityList

## load jdbc
### mysql
    with "jdbc:mysql://localhost:3306/northwind?user=root" as url
    cypher CALL apoc.load.jdbc(url,"products") YIELD row
    RETURN count(*);

### transactional batches

    CALL apoc.periodic.iterate('
    call apoc.load.jdbc("jdbc:mysql://localhost:3306/northwind?user=root","company")',
    'CREATE (p:Person) SET p += value', {batchSize:10000, parallel:true})
    RETURN batches, total

## call
    jdbc:mysql://<hostname>:<port/3306>/<database>?user=<user>&password=<pass>
    jdbc:postgresql://<hostname>/<database>?user=<user>&password=<pass>
    jdbc:oracle:thin:<user>/<pass>@<host>:<port>/<service_name>
    jdbc:sqlserver://;servername=<servername>;databaseName=<database>;user=<user>;password=<pass>
    jdbc:db2://<host>:<port/5021>/<database>:user=<user>;password=<pass>;
    jdbc:derby:derbyDB
    jdbc:cassandra://<host>:<port/9042>/<database>

## Gephi ，需要安装
    match path = (:Person)-[:ACTED_IN]->(:Movie)
    WITH path LIMIT 1000
    with collect(path) as paths
    call apoc.gephi.add(null,'workspace0', paths) yield nodes, relationships, time
    return nodes, relationships, time

## XML
    call apoc.load.xml("https://raw.githubusercontent.com/neo4j-contrib/neo4j-apoc-procedures/master/src/test/resources/books.xml") yield value as catalog
    UNWIND catalog._children as book
    RETURN book.id

## 属性重构
    MATCH (n)
    CALL apoc.refactor.normalizeAsBoolean(n, "prop", ["Y", "YES"], ["N", NO"])
    RETURN n.prop

    CALL apoc.refactor.categorize('color','HAS_ATTRIBUTE',true,'Color','colour',['popularity'],1)

    MATCH (n:Movie)
    CALL apoc.create.addLabels( id(n), [ n.genre ] ) YIELD node
    REMOVE node.studio
    RETURN node

## periodoc
    CALL apoc.periodic.iterate(
    "MATCH (p:Person) WHERE (p)-[:ACTED_IN]->() RETURN p",
    "SET p:Actor", {batchSize:10000, parallel:true})

    call apoc.periodic.commit("
    match (user:User) WHERE exists( user.city )
    with user limit {limit}
    MERGE (city:City {name:user.city})
    MERGE (user)-[:LIVES_IN]->(city)
    REMOVE user.city
    RETURN count(*)
    ",{limit:10000})