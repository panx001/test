#!/usr/bin/env python
#-*- coding:utf-8 -*-
#@Time  : 17/3/6 上午8:10
#@Author: wuchenglong

####################
# 根据规则添加控股股东
# 实际控制人信息
####################
import sys,os
sys.path.append(os.path.dirname(os.path.abspath(sys.argv[0])))
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0]))))
from py2neo import Graph, Node
from update_neo4j_data.neo4j_ha_master_choose import _neo4j_ha_master_choose
from config import proj_config
proj_config.cfg_dump()
from config.config import Config
import datetime
from my_log import  logger,log_capture_string
from mail import SendMail
from optparse import OptionParser
USAGE = '''usage:  /opt/python3-env/bin/python /root/python_neo4j_update/update_neo4j_data/add_controller_majority_info.py --NEO4J_ENV TEST_NEO4J --condition  " C.COMPANY_NM_MATCH = '深圳市创新资本投资有限公司' AND "    '''
parser = OptionParser(USAGE)
parser.add_option("--condition", dest="condition",default = "",help="查询企业周围定位合并条件")
parser.add_option("--NEO4J_ENV", dest="NEO4J_ENV",default = "TEST_FUND_NEO4J",help="环境配置：UAT环境-UAT_NEO4J  生产环境-PROD_NEO4J  测试环境-TEST_NEO4J  其他-TEST_FUND_NEO4J")
opt, args = parser.parse_args()
condition = opt.condition if opt.condition else ""
NEO4J_ENV = opt.NEO4J_ENV if opt.NEO4J_ENV else "TEST_NEO4J"


class AddTYCSharatioAndFRInfo():
    def __init__(self,proj_config = Config("config.conf") ,NEO4J_ENV = "TEST_NEO4J"):
        # 生产服务器  oracle_ip = 10.100.13.9  orale_server = orclha
        ha_master_node = _neo4j_ha_master_choose(proj_config.cfg.get(NEO4J_ENV, "neo4j_slaves").split(","))
        self.proj_config = proj_config
        # self.neo4j_ip = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_ip")
        self.neo4j_ip = ha_master_node if ha_master_node else self.proj_config.cfg.get(NEO4J_ENV, "neo4j_ip")
        self.neo4j_ip = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_ip")
        self.http_port = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_http_port")
        self.https_port = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_https_port")
        self.bolt_port = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_bolt_port")
        self.neo4j_user = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_user")
        self.neo4j_password = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_password")
        pass

    def graph_connection(self):
        base_database_url = "http://{ip}:{http_port}" if self.http_port else "http://{ip}"
        logger.debug([self.neo4j_ip ,self.http_port ,self.bolt_port,self.https_port,self.neo4j_user ,self.neo4j_password ])
        try:
            self.g = Graph(base_database_url.format(ip=self.neo4j_ip, http_port=self.http_port), bolt_port=int(self.bolt_port), https_port=int(self.https_port),user="{user}".format(user=self.neo4j_user),
                           password="{password}".format(password=self.neo4j_password))  ## readme need to document setting environment variable in pycharm
        except Exception as e:
            raise e
        self.tx = self.g.begin()

    def _UPDATE_SHARATIO_FR_INFO(self):
        update_sha_ratio = '''
            MATCH(C:COMPANY)<-[R:INVEST]-()
            WITH C,R LIMIT 10000
            WHERE EXISTS(C.COMPANY_ID_TYC) AND EXISTS(C.REG_CAPITAL) AND NOT TOFLOAT(C.REG_CAPITAL) = 0 AND NOT C.REG_CAPITAL = '' 
                AND EXISTS(R.NUM) AND NOT NOT TOFLOAT(R.NUM) = 0 AND NOT R.NUM = '' AND NOT EXISTS(R.SHA_RATIO) AND TOFLOAT(R.NUM)/TOFLOAT(C.REG_CAPITAL)<=100 AND TOFLOAT(R.NUM)/TOFLOAT(C.REG_CAPITAL)>=0
            SET 
            R.SHA_RATIO = TOFLOAT(R.NUM)/TOFLOAT(C.REG_CAPITAL)
            RETURN 1
        '''

        update_FR = '''
            MATCH (C:COMPANY)
            WHERE EXISTS(C.COMPANY_ID_TYC) AND NOT EXISTS(C.COMPANY_TYPE) AND EXISTS (C.LEG_REPRESENT ) AND NOT C. LEG_REPRESENT = ''
                AND NOT (C)<-[:WORK{{POSITION:'法定代表人'}}]-()
            WITH C,C.LEG_REPRESENT  AS  PERSON_NM,C.LEG_REPRESENT_ID AS PERSON_ID_TYC LIMIT 10000
            WITH  C,PERSON_NM,
            MERGE (P:PERSON{{PERSON_ID:C.COMPANY_ID_TYC+'-'+PERSON_ID_TYC}})
                ON CREATE SET
                    P.PERSON_NM = PERSON_NM,
                    p.PERSON_ID_TYC = PERSON_ID_TYC
            MERGE (P)-[r:WORK{{POSITION:'法定代表人'}}]->(C)
                ON CREATE SET
                    r.SOURCE= 'BASIC_INFO_TYC'
            RETURN 1
        '''

        # A的控股股东的实际控制人也是A的实际控制人
        all_query_info = [
            ("更新天眼查股东投资比例",update_sha_ratio),
            ("更新天眼查企业法定代表人信息",update_FR),
        ]

        for query in all_query_info:
            # condition = "( C.company_type= '{relation_type}' or not exists(C.company_type)) and ".format(
            #     relation_type="0")
            # condition = " C.COMPANY_NM_MATCH = '深圳市创新资本投资有限公司' AND "
            # condition = " C.relation_type= '{relation_type}' and ".format(relation_type="1")
            # logger.debug(query[1].format(condition=condition))
            iter = 1
            a = True
            while a:
                logger.debug("＝＝＝＝{rule} {iter} 次创建关系＝＝＝＝".format(iter=iter, rule=query[0]))
                cql_result = self.g.run(query[1].format(condition=condition))
                logger.debug(cql_result.stats())
                a = list(cql_result)
                iter += 1


if __name__ == "__main__":
    add_sharandfr_info = AddTYCSharatioAndFRInfo(proj_config=proj_config,NEO4J_ENV=NEO4J_ENV,)
    add_sharandfr_info.graph_connection()
    starttime = datetime.datetime.now()
    print(starttime.strftime('%Y-%m-%d'))
    add_sharandfr_info._UPDATE_SHARATIO_FR_INFO()

    log_contents = log_capture_string.getvalue()
    log_capture_string.close()
    sendMail = SendMail()
    sendMail._send_finished_mail(message=str(log_contents),Subject=os.path.splitext(os.path.split(__file__)[-1])[0]+" 执行完成")
    # logger._send_finished_mail(Subject=os.path.splitext(os.path.split(__file__)[-1])[0]+" 执行完成")