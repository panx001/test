#!/usr/bin/env python
#-*- coding:utf-8 -*-
#@Time  : 17/3/6 上午8:10
#@Author: wuchenglong

####################
# 根据规则添加控股股东
# 实际控制人信息
####################
import sys,os
sys.path.append(os.path.dirname(os.path.abspath(sys.argv[0])))
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0]))))
from py2neo import Graph, Node
from update_neo4j_data.neo4j_ha_master_choose import _neo4j_ha_master_choose
from config import proj_config
proj_config.cfg_dump()
from config.config import Config
import datetime
from my_log import  logger,log_capture_string
from mail import SendMail
from optparse import OptionParser
USAGE = '''usage:  /opt/python3-env/bin/python /root/python_neo4j_update/update_neo4j_data/add_controller_majority_info.py --NEO4J_ENV TEST_NEO4J --condition  " C.COMPANY_NM_MATCH = '深圳市创新资本投资有限公司' AND "    '''
parser = OptionParser(USAGE)
parser.add_option("--condition", dest="condition",default = "",help="查询企业周围定位合并条件")
parser.add_option("--NEO4J_ENV", dest="NEO4J_ENV",default = "TEST_FUND_NEO4J",help="环境配置：UAT环境-UAT_NEO4J  生产环境-PROD_NEO4J  测试环境-TEST_NEO4J  其他-TEST_FUND_NEO4J")
opt, args = parser.parse_args()
condition = opt.condition if opt.condition else ""
NEO4J_ENV = opt.NEO4J_ENV if opt.NEO4J_ENV else "TEST_NEO4J"


class AddControllerInfo():
    def __init__(self,proj_config = Config("config.conf") ,NEO4J_ENV = "TEST_NEO4J"):
        # 生产服务器  oracle_ip = 10.100.13.9  orale_server = orclha
        ha_master_node = _neo4j_ha_master_choose(proj_config.cfg.get(NEO4J_ENV, "neo4j_slaves").split(","))
        self.proj_config = proj_config
        # self.neo4j_ip = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_ip")
        self.neo4j_ip = ha_master_node if ha_master_node else self.proj_config.cfg.get(NEO4J_ENV, "neo4j_ip")
        self.neo4j_ip = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_ip")
        self.http_port = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_http_port")
        self.https_port = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_https_port")
        self.bolt_port = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_bolt_port")
        self.neo4j_user = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_user")
        self.neo4j_password = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_password")
        pass

    def graph_connection(self):
        base_database_url = "http://{ip}:{http_port}" if self.http_port else "http://{ip}"
        logger.debug([self.neo4j_ip ,self.http_port ,self.bolt_port,self.https_port,self.neo4j_user ,self.neo4j_password ])
        try:
            self.g = Graph(base_database_url.format(ip=self.neo4j_ip, http_port=self.http_port), bolt_port=int(self.bolt_port), https_port=int(self.https_port),user="{user}".format(user=self.neo4j_user),
                           password="{password}".format(password=self.neo4j_password))  ## readme need to document setting environment variable in pycharm
        except Exception as e:
            raise e
        self.tx = self.g.begin()

    def _UPDATE_CONTROLLER_MAJORITY_INFO(self):
        extra_added_rule2 = '''
        //MATCH  (C:COMPANY)<-[R:CONTROLLER{{RELATION_TYPE:'控股股东'}}]-(B:COMPANY)
        MATCH (C:COMPANY)-[*0..2]->(:PFCOMPANY)
        MATCH  (C)<-[R:CONTROLLER{{RELATION_TYPE:'控股股东'}}]-(B:COMPANY)
        MATCH (B)<-[:CONTROLLER{{RELATION_TYPE:'实际控制人'}}]-(A)
        WHERE  NOT (C)<-[:CONTROLLER{{RELATION_TYPE:'实际控制人'}}]-(A)
        WITH C,A limit 1000
        MERGE (C)<-[R3:CONTROLLER{{RELATION_TYPE:'实际控制人'}}]-(A)
        RETURN 1;
        '''

        extra_added_rule3 = '''
        //MATCH (C:COMPANY)-[]-(:COMPANY{{COMPANY_TYPE:'1'}})
        MATCH (C:COMPANY)-[*0..2]->(:PFCOMPANY)
        WHERE  NOT C:SECURITY AND NOT (C)<-[:CONTROLLER{{RELATION_TYPE:'实际控制人'}}]-()
        MATCH (C)<-[R:INVEST]-(P:PERSON) WHERE toFloat(R.SHA_RATIO) >=50
        WITH C,P limit 1000
        MERGE (C)<-[R3:CONTROLLER{{RELATION_TYPE:'实际控制人'}}]-(P)
        RETURN 1;
        '''

        extra_added_rule4 =  '''
        //MATCH (C:COMPANY)-[]-(:COMPANY{{COMPANY_TYPE:'1'}})
        MATCH (C:COMPANY)-[*0..2]->(:PFCOMPANY)
        WHERE  NOT C:SECURITY AND NOT (C)<-[:CONTROLLER{{RELATION_TYPE:'控股股东'}}]-()
                    MATCH (C)<-[R:INVEST]-(P) WHERE toFloat(R.SHA_RATIO) >=50
                    WITH C,P  limit 1000
                    MERGE (C)<-[R3:CONTROLLER{{RELATION_TYPE:'控股股东'}}]-(P)
                    RETURN 1 ;
                    '''

        # A的控股股东的实际控制人也是A的实际控制人
        all_query_info = [
            ("超过50% 的股东是控股股东",extra_added_rule4),
            ("超过50%的自然人股东是实际控制人",extra_added_rule3),
            ("A的控股股东的实际控制人也是A的实际控制人",extra_added_rule2),
        ]

        for query in all_query_info:
            # condition = "( C.company_type= '{relation_type}' or not exists(C.company_type)) and ".format(
            #     relation_type="0")
            # condition = " C.COMPANY_NM_MATCH = '深圳市创新资本投资有限公司' AND "
            # condition = " C.relation_type= '{relation_type}' and ".format(relation_type="1")
            # logger.debug(query[1].format(condition=condition))
            iter = 1
            a = True
            while a:
                logger.debug("＝＝＝＝{rule} {iter} 次创建关系＝＝＝＝".format(iter=iter, rule=query[0]))
                cql_result = self.g.run(query[1].format(condition=condition))
                logger.debug(cql_result.stats())
                a = list(cql_result)
                iter += 1


if __name__ == "__main__":
    add_controller_info = AddControllerInfo(proj_config=proj_config,NEO4J_ENV=NEO4J_ENV,)
    add_controller_info.graph_connection()
    starttime = datetime.datetime.now()
    print(starttime.strftime('%Y-%m-%d'))
    add_controller_info._UPDATE_CONTROLLER_MAJORITY_INFO()

    log_contents = log_capture_string.getvalue()
    log_capture_string.close()
    sendMail = SendMail()
    sendMail._send_finished_mail(message=str(log_contents),Subject=os.path.splitext(os.path.split(__file__)[-1])[0]+" 执行完成")
    # logger._send_finished_mail(Subject=os.path.splitext(os.path.split(__file__)[-1])[0]+" 执行完成")