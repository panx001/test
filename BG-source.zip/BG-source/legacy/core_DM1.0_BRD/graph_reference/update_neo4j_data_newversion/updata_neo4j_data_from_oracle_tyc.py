#!/usr/bin/env python
#-*- coding:utf-8 -*-
#@Time  : 17/3/21 下午7:08
#@Author: wuchenglong

from py2neo import Graph, Node
import re,os,datetime,sys
sys.path.append(os.path.dirname(os.path.abspath(sys.argv[0])))
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0]))))
from config import proj_config
proj_config.cfg_dump()
from config.config import Config
# from update_neo4j_data import import_fund_data_cql
# from cypher_collection import *
from my_log import  logger,log_capture_string
from mail import SendMail
import data_import_cql_daas,data_import_cql_dfcf,data_import_cql_dfcf_new,data_import_cql_modify,data_import_cql_tyc

from optparse import OptionParser
from update_neo4j_data.neo4j_ha_master_choose import _neo4j_ha_master_choose

# '''/opt/python3-env/bin/python /root/python_neo4j_update_test/update_neo4j_data/updata_neo4j_data_from_oracle.py --NEO4J_ENV TEST_NEO4J --ORACLE_ENV PROD_ORACLE --import_method incre  --interval_days 2'''
# '''/opt/python3-env/bin/python /root/python_neo4j_update_uat/update_neo4j_data/updata_neo4j_data_from_oracle.py --NEO4J_ENV TEST_NEO4J --ORACLE_ENV PROD_ORACLE --import_method incre  --interval_days 2'''
# '''/opt/python3-env/bin/python /root/python_neo4j_update_prod/update_neo4j_data/updata_neo4j_data_from_oracle.py --NEO4J_ENV TEST_NEO4J --ORACLE_ENV PROD_ORACLE --import_method incre  --interval_days 2'''
# '''python updata_neo4j_data_from_oracle_tyc.py --NEO4J_ENV NEW_NEO4J_TEST --ORACLE_ENV PROD_ORACLE --import_method incre'''
USAGE = "usage:  /opt/python3-env/bin/python /root/python_neo4j_update/update_neo4j_data/updata_neo4j_data_from_oracle.py --NEO4J_ENV TEST_FUND_NEO4J --ORACLE_ENV PROD_ORACLE --import_method total  --interval_days 2"
parser = OptionParser(USAGE)
parser.add_option("--NEO4J_ENV", dest="NEO4J_ENV",default = "TEST_NEO4J",help="环境配置：UAT环境-UAT_NEO4J  生产环境-PROD_NEO4J  测试环境-TEST_NEO4J  其他-TEST_FUND_NEO4J")
parser.add_option("--ORACLE_ENV", dest="ORACLE_ENV",default = "PROD_ORACLE",help="环境配置：UAT环境-UAT_ORACLE  生产环境-PROD_ORACLE ")
parser.add_option("--import_method", dest="import_method",default = "incre", help="更新方式，全量更新-total  增量更新-incre")
parser.add_option("--interval_days", dest="interval_days",default = "5",help=" 更新中最近 interval_days 天数内的数据")
opt, args = parser.parse_args()
NEO4J_ENV = opt.NEO4J_ENV
ORACLE_ENV = opt.ORACLE_ENV
import_method = opt.import_method
interval_days = opt.interval_days

starttime = datetime.datetime.now() + datetime.timedelta(days=-1)
yestoday_date = starttime.strftime('%Y-%m-%d %H:%M:%S')


class Neo4jDataUpdate():
    def __init__(self,import_method = "incre",proj_config = Config("config.conf") ,NEO4J_ENV = "TEST_NEO4J", ORACLE_ENV = "PROD_ORACLE"):
        # 生产服务器  oracle_ip = 10.100.13.9  orale_server = orclha
        ha_master_node = _neo4j_ha_master_choose(proj_config.cfg.get(NEO4J_ENV, "neo4j_slaves").split(","))
        self.import_method = import_method
        self.proj_config = proj_config
        self.oracle_server = self.proj_config.cfg.get(ORACLE_ENV, "oracle_server")
        self.oracle_ip = self.proj_config.cfg.get(ORACLE_ENV, "oracle_ip")
        self.oracle_password = self.proj_config.cfg.get(ORACLE_ENV, "oracle_password")
        self.neo4j_ip = ha_master_node if ha_master_node else self.proj_config.cfg.get(NEO4J_ENV, "neo4j_ip")
        self.http_port = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_http_port")
        self.https_port = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_https_port")
        self.bolt_port = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_bolt_port")
        self.neo4j_user = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_user")
        self.neo4j_password = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_password")
        self.jdbc_url = "jdbc:oracle:thin:oracle_graphdb_trans/{oracle_password}@{oracle_ip}:1521/{oracle_server}".format(oracle_password = self.oracle_password,  oracle_server=self.oracle_server,oracle_ip=self.oracle_ip)
        #  "jdbc:oracle:thin:oracle_graphdb_trans/oeTsRSBfSga17SSx@10.100.13.9:1521/orclha"
        self.import_method = import_method
        if os.path.exists(os.path.join(os.path.dirname(__file__), "update.cql")):
            os.remove(os.path.join(os.path.dirname(__file__), "update.cql"))

    def _save_data(self,file,obj,mode ="a+"):
        f = open(file,mode=mode)
        f.write(obj)
        f.write("\n")
        f.close()

    def excute_cypher(self,query,save_cql = True,is_excute=True):
        logger.debug("-"*50)
        # logger.debug(query)
        if save_cql:
            self._save_data(os.path.join(os.path.dirname(__file__), "update.cql"), query)
        if is_excute:
            excuted_result = self.g.run(query)
            logger.debug(["执行结果统计"])
            logger.debug(excuted_result.stats())
            logger.debug(list(excuted_result))
            return excuted_result
        else:
            return None

    def graph_connection(self):
        base_database_url = "http://{ip}:{http_port}/db/data/" if self.http_port else "http://{ip}"
        logger.debug(base_database_url.format(ip=self.neo4j_ip, http_port=self.http_port))
        logger.debug([self.neo4j_ip ,self.http_port ,self.bolt_port,self.https_port,self.neo4j_user ,self.neo4j_password ])
        try:
            self.g = Graph(base_database_url.format(ip=self.neo4j_ip, http_port=self.http_port), bolt_port=int(self.bolt_port), https_port=int(self.https_port),user="{user}".format(user=self.neo4j_user), password="{password}".format(password=self.neo4j_password))  ## readme need to document setting environment variable in pycharm
            # self.g = Graph(base_database_url.format(ip="10.100.13.13", http_port="7474"),user="{user}".format(user=self.neo4j_user), password="{password}".format(password=self.neo4j_password))  ## readme need to document setting environment variable in pycharm
            # self.g = Graph(base_database_url.format(ip=self.neo4j_ip, http_port=self.http_port),user="{user}".format(user=self.neo4j_user), password="{password}".format(password=self.neo4j_password))  ## readme need to document setting environment variable in pycharm
        except Exception as e:
            raise e
        self.tx = self.g.begin()

    def create_index(self):
        all_index_cql = {
            "INDEX SECURITY-SECURITY_NM": '''CREATE INDEX ON :SECURITY(SECURITY_NM);''',
            "INDEX SECURITY-SECURITY_NM_MATCH": '''CREATE INDEX ON :SECURITY(SECURITY_NM_MATCH);''',
            "CONSTRAINT SECURITY-SECINNER_ID": '''CREATE CONSTRAINT ON (S:SECURITY) ASSERT S.SECINNER_ID IS UNIQUE;''',
            "INDEX SECURITY-SECINNER_ID": '''CREATE INDEX ON :SECURITY(SECINNER_ID);''',
            "INDEX PFUND-SECURITY_NM": '''CREATE INDEX ON :PFUND(SECURITY_NM);''',
            "INDEX PFUND-SECURITY_NM_MATCH": '''CREATE INDEX ON :PFUND(SECURITY_NM_MATCH);''',
            "CONSTRAINT PFUND-SECINNER_ID": '''CREATE CONSTRAINT ON (S:PFUND) ASSERT S.SECINNER_ID IS UNIQUE;''',
            "INDEX PERSON-NAME": '''CREATE INDEX ON :PERSON(PERSON_NM);''',
            "CONSTRAINT PERSON-PERSON_ID": '''CREATE CONSTRAINT ON (P:PERSON) ASSERT P.PERSON_ID IS UNIQUE;''',
            "INDEX COMPANY-COMPANY_NM_MATCH" : '''CREATE INDEX ON :COMPANY(COMPANY_NM_MATCH);''',
            "INDEX COMPANY-SECURITY_CD" : '''CREATE INDEX ON :COMPANY(SECURITY_CD);''',
            "INDEX COMPANY-COMPANY_NM" : '''CREATE INDEX ON :COMPANY(COMPANY_NM);''',
            "INDEX COMPANY-COMPANY_TYPE" : '''CREATE INDEX ON :COMPANY(COMPANY_TYPE);''',
            "INDEX COMPANY-COMPANY_TYPE_LIST" : '''CREATE INDEX ON :COMPANY(COMPANY_TYPE_LIST);''',
            "INDEX COMPANY-CLENS_COMPANY_NM_MATCH" : '''CREATE INDEX ON :COMPANY(CLENS_COMPANY_NM_MATCH);''',
            "INDEX COMPANY-CLENS_COMPANY_NM" : '''CREATE INDEX ON :COMPANY(CLENS_COMPANY_NM);''',
            "INDEX COMPANY-UPDT_DT" : '''CREATE INDEX ON :COMPANY(UPDT_DT);''',
            "INDEX COMPANY-COMPANY_ID" : '''CREATE INDEX ON :COMPANY(COMPANY_ID);''',
            "INDEX COMPANY-COMPANY_ID" : '''CREATE INDEX ON :PFCOMPANY(COMPANY_ID);''',
            "CONSTRAINT COMPANY-COMPANY_ID" : '''CREATE CONSTRAINT ON (C:COMPANY) ASSERT C.COMPANY_ID IS UNIQUE;''',
            "INDEX COMPANY-REG_CD" : '''CREATE INDEX ON :COMPANY(REG_CD);''',
            "INDEX COMPANY-COMPANY_ID_TYC" : '''CREATE INDEX ON :COMPANY(COMPANY_ID_TYC);''',
            "INDEX PERSON-PERSON_ID_TYC" : '''CREATE INDEX ON :PERSON(PERSON_ID_TYC);''',
        }

        for key,value in all_index_cql.items():
            try:
                logger.debug(key)
                self.excute_cypher(value,save_cql = False,is_excute=True)
            except Exception as e:
                logger.debug(e)
                logger.debug("创建主键出现错误")


    def _IMPORT_COMPANY_NODE(self):
        logger.debug("读入企业基本信息表并创建法定代表人节点和关系")
        if self.import_method == "incre":
            try:
                MAX_UP_DT = list(self.excute_cypher(
                    "MATCH p=(C:COMPANY) WHERE C.SOURCE = 'COMPY_BASICINFO' RETURN MAX(C.UPDT_DT) AS MAX_UP_DT",save_cql = False,is_excute=True))[0][
                    "MAX_UP_DT"]
                MAX_UP_DT_IS_TIME = re.match("\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$", MAX_UP_DT)
                if MAX_UP_DT_IS_TIME:
                    condition = "  WHERE UPDT_DT >=  '{MAX_UP_DT}'".format(MAX_UP_DT=MAX_UP_DT)
                else:
                    condition = ""
            except:
                condition = ""
            logger.debug(["condition", condition])
        else:
            condition = ""
        if condition:
            logger.debug("增量更新")
            self.excute_cypher(data_import_cql_dfcf.IMPORT_COMPANY_NODE.format(jdbc_url=self.jdbc_url,condition=condition))
        else:
            try:
                max_num  = list(self.excute_cypher('''CALL apoc.load.jdbc('{jdbc_url}',"SELECT COUNT(*)  AS COMPANY_NUM FROM CS_PORTAL.COMPY_BASICINFO ")yield row WITH row AS  LINE
                                 RETURN LINE LIMIT 1 ;'''.format(jdbc_url=self.jdbc_url),save_cql = False,is_excute=True))[0]["LINE"]["COMPANY_NUM"]
            except:
                max_num = 10000000
            split_num = 300000
            Rn_split = list(range(0, int(max_num) + split_num, split_num))
            for i in range(len(Rn_split) - 1):
                logger.debug([i, len(Rn_split)])
                self.excute_cypher(data_import_cql_dfcf.IMPORT_COMPANY_NODE.format(jdbc_url=self.jdbc_url,
                    condition=" WHERE RN BETWEEN {startRn} AND {endRn} ".format(startRn=Rn_split[i],
                                                                              endRn=Rn_split[i + 1])))

    def _IMPORT_TYC_COMPANY_SHAREHOLDER(self):
        logger.debug("导入天眼查股东信息")
        MAX_UP_DT = list(self.excute_cypher(data_import_cql_tyc.TYC_COMPANY_SHAREHOLDER_SQL))
        index  = 0
        for sql in MAX_UP_DT:
            logger.debug([index,len(MAX_UP_DT)])
            self.excute_cypher(data_import_cql_tyc.TYC_COMPANY_SHAREHOLDER_CQL.format(sql = sql["sql"]),save_cql=False)
            index = index + 1

    def _IMPORT_TYC_COMPANY_MANAGER(self):
        logger.debug("导入天眼查高管信息")
        MAX_UP_DT = list(self.excute_cypher(data_import_cql_tyc.TYC_COMPANY_MANAGER_SQL))
        index = 0
        for sql in MAX_UP_DT:
            logger.debug([index, len(MAX_UP_DT)])
            self.excute_cypher(data_import_cql_tyc.TYC_COMPANY_MANAGER_CQL.format(sql=sql["sql"]), save_cql=False)
            index = index + 1

    def _IMPORT_TYC_COMPANY_INVEST(self):
        logger.debug("导入天眼查对外投资信息")
        MAX_UP_DT = list(self.excute_cypher(data_import_cql_tyc.TYC_COMPANY_INVEST_SQL))
        index = 0
        for sql in MAX_UP_DT:
            logger.debug([index, len(MAX_UP_DT)])
            self.excute_cypher(data_import_cql_tyc.TYC_COMPANY_INVEST_CQL.format(sql=sql["sql"]), save_cql=False)
            index = index + 1

    # def _DAAS_COMPANY_BASIC_IMPORT(self):
    #     logger.debug("公司的基本信息以及法人代表")
    #     self.excute_cypher(import_fund_data_cql.DAAS_COMPANY_BASIC_IMPORT)
    # def _DAAS_COMPANY_APPOINT_IMPORT(self):
    #     logger.debug("公司的基本信息委派人")
    #     self.excute_cypher(import_fund_data_cql.DAAS_COMPANY_APPOINT_IMPORT)
    # def _DAAS_COMPANY_SHAREHOLDER_IMPORT(self):
    #     logger.debug("公司的公司的股东")
    #     self.excute_cypher(import_fund_data_cql.DAAS_COMPANY_SHAREHOLDER_IMPORT)
    # def _DAAS_COMPANY_MANAGER_IMPORT(self):
    #     logger.debug("公司的高管")
    #     self.excute_cypher(import_fund_data_cql.DAAS_COMPANY_MANAGER_IMPORT)
    # def _DAAS_COMPANY_INVEST_IMPORT(self):
    #     logger.debug("公司对外投资")
    #     self.excute_cypher(import_fund_data_cql.DAAS_COMPANY_INVEST_IMPORT)
    # def _DAAS_COMPANY_FINVEST_IMPORT(self):
    #     logger.debug("法定代表人对外投资")
    #     self.excute_cypher(import_fund_data_cql.DAAS_COMPANY_FINVEST_IMPORT)
    # def _DAAS_COMPANY_FWORK_IMPORT(self):
    #     logger.debug("法定代表人对外任职")
    #     self.excute_cypher(import_fund_data_cql.DAAS_COMPANY_FWORK_IMPORT)


if __name__ == "__main__":

    neo4j_data_update = Neo4jDataUpdate(import_method=import_method, proj_config=proj_config,NEO4J_ENV=NEO4J_ENV,ORACLE_ENV=ORACLE_ENV)
    neo4j_data_update.graph_connection()
    for j in neo4j_data_update.excute_cypher("MATCH (n) RETURN COUNT(n)",save_cql = False,is_excute=True):
        logger.debug(dict(j))
    try:
        ###################################################################################
        # 创建索引
        # neo4j_data_update.create_index()
        ###################################################################################
        # 在天眼查库数据import后，导入东财数据
        DFCF_UPDATE_CQL = [
            #####################################################################################
            ###插入公开企业信息时，覆盖掉天眼查的信息
            #("创建公开企业信息节点",   data_import_cql_dfcf_new.IMPORT_PUBLIC_COMPANY_NODE," WHERE  A.UPDT_DT >=  SYSDATE - {interval_days} "),

            #####################################################################################
            ###产品信息添加
            ("创建产品信息节点",   data_import_cql_dfcf_new.IMPORT_SECURITY_NODE," WHERE  A.UPDT_DT >=  SYSDATE - {interval_days} "),
            ("产品节点增加COMPANY_TYPE的LABEL",   data_import_cql_dfcf_new.ADD_SECURITY_LABEL,"  "),
            ###私募信息添加
            ("创建私募基金节点",   data_import_cql_dfcf_new.IMPORT_PFUND_NODE," AND  A.UPDT_DT >=  SYSDATE - {interval_days} "),
            ("删除私募基金管理人label",   data_import_cql_dfcf_new.DELETE_PFCOMPANY_NODE_LABEL," "),
            ("创建私募基金管理人label",   data_import_cql_dfcf_new.IMPORT_PFCOMPANY_NODE, " "),
            ###企业标记添加
            ("删除企业是否是公开企业属性",   data_import_cql_dfcf_new.DELETE_COMPANY_TYPE_PROPERTY,""),
            ("创建企业是否是公开企业属性",   data_import_cql_dfcf_new.ADD_COMPANY_TYPE_PROPERTY,""),
            ("删除企业新三板发债上市属性",   data_import_cql_dfcf_new.DELETE_COMPANY_TYPE_LIST_PROPERTY,""),
            ("创建企业新三板发债上市属性",   data_import_cql_dfcf_new.ADD_COMPANY_TYPE_LIST_PROPERTY,""),
            ###私募企业风险信息从redis读取
            ("删除公开企业企业风险属性",   data_import_cql_dfcf_new.DELETE_PUBLIC_RISK_LIST_PROPERTY,""),
            ("添加公开企业风险属性",   data_import_cql_dfcf_new.ADD_PUBLIC_RISK_LIST_PROPERTY,""),
            ###("删除评级结果",   data_import_cql_dfcf_new.DELETE_COMPANY_CREDITRATING_INFO,""),
            ###("创建评级结果",   data_import_cql_dfcf_new.ADD_COMPANY_CREDITRATING_INFO,""),
            ###("删除上市代码",   data_import_cql_dfcf_new.DELETE_SECURITY_CODE_PROPERTY,""),
            ###("添加上市代码",   data_import_cql_dfcf_new.ADD_SECURITY_CODE_PROPERTY,""),
            ###高管股东控制人产品客户供应商等信息添加
            ("删除历史公开企业高管",   data_import_cql_dfcf_new.DELETE_WORKER_RELATION_FROM_MANAGELEVEL," AND  A.UPDT_DT >=  SYSDATE -{interval_days} "),
            ("添加公开企业高管",   data_import_cql_dfcf_new.ADD_WORKER_RELATION_FROM_MANAGELEVEL," AND  A.UPDT_DT >=  SYSDATE -{interval_days} "),
            ("添加公开企业法定代表人信息",   data_import_cql_dfcf_new.ADD_LEG_REPRESENT_RELATION," AND  A.UPDT_DT >=  SYSDATE -{interval_days} "),
            ("删除历史前十大企业股东",   data_import_cql_dfcf_new.DELETE_TOP10SHAREHOLDER_RELATION," WHERE UPDT_DT >=  SYSDATE - {interval_days} "),
            ("前十大企业股东",   data_import_cql_dfcf_new.CREATE_NODE_FROM_TOP10SHAREHOLDER_COMPANY," WHERE UPDT_DT >=  SYSDATE - {interval_days} "),
            ("前十大产品股东",   data_import_cql_dfcf_new.CREATE_NODE_FROM_TOP10SHAREHOLDER_PRODUCT,"  WHERE UPDT_DT >=  SYSDATE - {interval_days} "),
            ("前十大个人股东",   data_import_cql_dfcf_new.CREATE_RELATION_TOP10SHAREHOLDER_PERSON," WHERE UPDT_DT >=  SYSDATE - {interval_days} "),
            ("删除控制关系",   data_import_cql_dfcf_new.DELETE_CONTROL_RELATION,""),            
            ("添加是否有控股股东属性",   data_import_cql_dfcf_new.ADD_COMAPNY_HAS_MAJORITY_PROPERTY,""),
            ("添加是否有实际控制人属性",   data_import_cql_dfcf_new.ADD_COMAPNY_HAS_CONTROLLER_PROPERTY,""),
            ("添加自然人控制关系属性",   data_import_cql_dfcf_new.CREATE_RELATION_PERSON_AFFIL,""),
            ("添加机构控制关系属性",   data_import_cql_dfcf_new.CREATE_RELATION_COMPANY_AFFIL,""),
            ("创建亲属关系",   data_import_cql_dfcf_new.CREATE_RELATION_FAMILY,""),
            ("创建子公司关系",   data_import_cql_dfcf_new.CREATE_RELATION_SUBCOMPANY," WHERE UPDT_DT >=  SYSDATE - {interval_days} "),
            ("创建参控股",   data_import_cql_dfcf_new.CREATE_RELATION_HOLDINGS," AND UPDT_DT >=  SYSDATE - {interval_days} "),
            ("创建担保关系",   data_import_cql_dfcf_new.CREATE_RELATION_GUARANTEE,""),
            ("创建担保关系-汇总",   data_import_cql_dfcf_new.UPDATE_GUARANTEE_TOTAL,""),
            ("主要客户",   data_import_cql_dfcf_new.CREATE_RELATION_CUST,""),
            ("主要供应商",   data_import_cql_dfcf_new.CREATE_RELATION_SUPPLIER,""),
            ("清除预警数据",   data_import_cql_dfcf_new.CLEAR_COMPANY_WARNING_NUM,""),
            ("添加预警数据",   data_import_cql_dfcf_new.ADD_COMPANY_WARNING_NUM,""),
            #### ("私募基金高管",   data_import_cql_dfcf.ADD_PFCOMPANY_MANAGER,""),
        ]
        for elem in DFCF_UPDATE_CQL:
            logger.debug(elem[0])
            neo4j_data_update.excute_cypher(elem[1].format(jdbc_url=neo4j_data_update.jdbc_url,condition = " " if import_method == "total" else  elem[2].format(interval_days=interval_days)))

        # 导入中数智慧缓存数据
        TYC_UPDATE_CQL = [
            #("天眼查法定代表人更新", data_import_cql_dfcf_new.ADD_LEG_REPRESENT_RELATION_TYC,""),
            #("计算天眼查持股比例", data_import_cql_dfcf_new.CALCULATE_SHA_RATIO_TYC,""),
        ]
        for elem in TYC_UPDATE_CQL:
            logger.debug(elem[0])
            print(import_method)
            neo4j_data_update.excute_cypher(elem[1].format(jdbc_url=neo4j_data_update.jdbc_url, condition =  " " if import_method == "total" else  elem[2].format(interval_days=interval_days)))

        #修复数据
        MODIFY_UPDATE_CQL = [
            ("添加company-nm-match属性", data_import_cql_modify.ADD_COMPANY_NM_MATCH_PROPERTY),
        ]
        for elem in MODIFY_UPDATE_CQL:
            logger.debug(elem[0])
            neo4j_data_update.excute_cypher(elem[1].format(jdbc_url=neo4j_data_update.jdbc_url, ))

        log_contents = log_capture_string.getvalue()
        log_capture_string.close()
        #sendMail = SendMail()
        #sendMail._send_finished_mail(message=str(log_contents),
        #                             Subject=os.path.splitext(os.path.split(__file__)[-1])[0] + " 执行完成")

    except Exception as e:
        logger.debug(e)
        log_contents = log_capture_string.getvalue()
        log_capture_string.close()
        #sendMail = SendMail()
        #sendMail._send_finished_mail(message=str(log_contents),
        #                             Subject=os.path.splitext(os.path.split(__file__)[-1])[0] + " 执行错误")
        # raise e

