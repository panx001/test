#!/usr/bin/env python
#-*- coding:utf-8 -*-

####################
# 从redis读取风险信息数据，并插入到了neo4j中
####################
import sys,os
import redis,json
sys.path.append(os.path.dirname(os.path.abspath(sys.argv[0])))
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0]))))
from py2neo import Graph, Node
from update_neo4j_data.neo4j_ha_master_choose import _neo4j_ha_master_choose
from config import proj_config
proj_config.cfg_dump()
from config.config import Config
import datetime
from my_log import  logger,log_capture_string
from mail import SendMail
from optparse import OptionParser
USAGE = '''usage:  /opt/python3-env/bin/python /root/python_neo4j_update/update_neo4j_data/updata_neo4j_data_from_redis.py --NEO4J_ENV TEST_NEO4J --REDIS_ENV UAT_REDIS""    '''
parser = OptionParser(USAGE)
parser.add_option("--condition", dest="condition",default = "",help="查询企业周围定位合并条件")
parser.add_option("--NEO4J_ENV", dest="NEO4J_ENV",default = "TEST_FUND_NEO4J",help="环境配置：UAT环境-UAT_NEO4J  生产环境-PROD_NEO4J  测试环境-TEST_NEO4J  其他-TEST_FUND_NEO4J")
parser.add_option("--REDIS_ENV", dest="REDIS_ENV",default = "UAT_REDIS",help="REDIS地址配置，PROD_REDIS,UAT_REDIS,TEST_REDIS")
opt, args = parser.parse_args()
condition = opt.condition if opt.condition else ""
NEO4J_ENV = opt.NEO4J_ENV if opt.NEO4J_ENV else "TEST_NEO4J"
REDIS_ENV = opt.REDIS_ENV if opt.REDIS_ENV else "UAT_REDIS"

class AddRiskLabelInfo():
    def __init__(self,proj_config = Config("config.conf") ,NEO4J_ENV = "TEST_NEO4J",REDIS_ENV = "UAT_REDIS"):
        # 生产服务器  oracle_ip = 10.100.13.9  orale_server = orclha
        ha_master_node = _neo4j_ha_master_choose(proj_config.cfg.get(NEO4J_ENV, "neo4j_slaves").split(","))
        self.proj_config = proj_config
        # self.neo4j_ip = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_ip")
        self.neo4j_ip = ha_master_node if ha_master_node else self.proj_config.cfg.get(NEO4J_ENV, "neo4j_ip")
        self.neo4j_ip = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_ip")
        self.http_port = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_http_port")
        self.https_port = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_https_port")
        self.bolt_port = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_bolt_port")
        self.neo4j_user = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_user")
        self.neo4j_password = self.proj_config.cfg.get(NEO4J_ENV, "neo4j_password")
        self.redis_ip = self.proj_config.cfg.get(REDIS_ENV, "redis_ip")
        self.redis_port = self.proj_config.cfg.get(REDIS_ENV, "redis_port")
        self.redis_password = self.proj_config.cfg.get(REDIS_ENV, "redis_password")
        pass

    def graph_connection(self):
        base_database_url = "http://{ip}:{http_port}" if self.http_port else "http://{ip}"
        logger.debug([self.neo4j_ip ,self.http_port ,self.bolt_port,self.https_port,self.neo4j_user ,self.neo4j_password ])
        try:
            self.g = Graph(base_database_url.format(ip=self.neo4j_ip, http_port=self.http_port), bolt_port=int(self.bolt_port), https_port=int(self.https_port),user="{user}".format(user=self.neo4j_user),
                           password="{password}".format(password=self.neo4j_password))  ## readme need to document setting environment variable in pycharm
        except Exception as e:
            raise e
        self.tx = self.g.begin()

    #从redis读取风险信息数据
    def get_pfcompany_info(self):
        #risk_list = []
        redis_conn = redis.StrictRedis(host=self.redis_ip,password=self.redis_password,port=self.redis_port)
        keys = redis_conn.keys()
        for key in keys:
            try:
                key = key.decode('utf8')
                #print(key)
            except Exception as e:
                continue
            try:
                if 'pfund_data' in key:
                    data = json.loads(redis_conn.get(key).decode('utf8'))
                    risk = data['risk']
                    keyset = risk.keys()
                    result = []
                    if risk['exceptionList']:
                        result.append(1)
                    if risk['shareholdersFreeze']:
                        result.append(2)
                    if risk['administrativePenalties']:
                        result.append(3)
                    if risk['equityPledged']:
                        result.append(4)
                    if risk['chattelMortgage']:
                        result.append(5)
                    if risk['supervisionPunishment']:
                        result.append(6)
                    if risk['integrityInformation']:
                        result.append(7)
                    if risk['dataException']:
                        result.append(8)
                    if 'disruptinfo' in keyset:
                        if risk['disruptinfo']:
                            result.append(9) 
                    #elif 'punished' in keyset:
                        #if risk['punished']:
                            result.append(9) 
                    if risk['undertaker']:
                        result.append(11)
                    if risk['wenshutheme']:
                        result.append(12)
                    if risk['court']:
                        result.append(13)
                    yield [key.replace("pfund_data",""),result]
            except Exception as e:
                print(key.replace("pfund_data",""))
                
    def get_pricompany_info(self):
        #risk_list = []
        redis_conn = redis.StrictRedis(host=self.redis_ip,password=self.redis_password,port=self.redis_port)
        keys = redis_conn.keys()
        for key in keys:
            try:
                key = key.decode('utf-8')
                #print(len(key))
            except Exception as e:
                continue 
            try:
                if 'bcompy_' in key:
                    #print(key)
                    data = json.loads(redis_conn.get(key).decode('utf8'))
                    risk = data['risk']
                    keyset = risk.keys()
                    result = []
                    #if 'operexcept' in keyset:
                    if risk['operexcept']:
                        result.append(31)
                    #if 'frozenshare' in keyset:
                    if risk['frozenshare']:
                        result.append(32)
                    #if 'adminpenalty' in keyset:
                    if risk['adminpenalty']:
                        result.append(33)
                    #if 'equitypledge' in keyset:
                    if risk['equitypledge']:
                        result.append(34)
                    #if 'chattelreg' in keyset:
                    if risk['chattelreg']:
                        result.append(35)
                    #if 'guarantee' in keyset:
                    if risk['guarantee']:
                        result.append(36)
                    #if 'ligignt' in keyset:
                    if risk['ligignt']:
                        result.append(37)
                    #if 'dishonstligignt' in keyset:
                    if risk['dishonstligignt']:
                        result.append(38)
                    #if 'judgementdoc' in keyset:
                    if risk['judgementdoc']:
                        result.append(39)
                    #if 'courtAnnounce' in keyset:
                    if risk['courtAnnounce']:
                        result.append(40)
                    #print(result)
                    yield([key.replace("bcompy_",""),result]) 
            except Exception as e:
                print(key.replace("bcompy_",""))

                
    def updata_pfcompany_risk_label_from_redis(self):    #AND ((C.COMPANY_TYPE = '1' AND C.SHA_INFO_COMPLETE = '1') OR NOT EXISTS(C.COMPANY_TYPE))
        clean_query =  '''
            MATCH (C:PFCOMPANY) WHERE EXISTS(C.RISK_LIST)   WITH C  SET C.RISK_LIST = NULL
        '''
        query = '''  
            MATCH (C:PFCOMPANY) 
            WHERE C.COMPANY_ID = '{company_id}' 
            SET C.RISK_LIST = {risk_label}
        '''
        self.g.run(clean_query)
        logger.debug("删除私募风险信息重新添加")
        resultlist = self.get_pfcompany_info()
        count = 0
        for result in resultlist:
            if count%1000 == 0 and  count!= 0:
                #print(result)
                logger.debug("＝＝＝＝{count} 次添加关系＝＝＝＝".format(count=count))
            #print(query.format(company_id=result[0],risk_label = result[1]))
            cql_result = self.g.run(query.format(company_id=result[0],risk_label = result[1]))
            count += 1
            #logger.debug(cql_result.stats())
    
    def updata_pricompany_risk_label_from_redis(self):    #AND ((C.COMPANY_TYPE = '1' AND C.SHA_INFO_COMPLETE = '1') OR NOT EXISTS(C.COMPANY_TYPE))
        clean_query =  '''
            MATCH (C:COMPANY) WHERE not C:PFCOMPANY AND EXISTS(C.RISK_LIST) AND (not EXISTS(C.COMPANY_TYPE) or C.COMPANY_TYPE <> '1')     
            WITH C  
            SET C.RISK_LIST = NULL
        '''
        query = '''  
            MATCH (C:COMPANY) 
            WHERE not C:PFCOMPANY AND C.COMPANY_NM_MATCH = '{company_nm}'  AND (not EXISTS(C.COMPANY_TYPE) or C.COMPANY_TYPE <> '1')
            SET C.RISK_LIST = {risk_label}
        '''
        self.g.run(clean_query)
        logger.debug("删除非公开企业风险信息重新添加")
        resultlist = self.get_pricompany_info()
        count = 0
        for result in resultlist:
            if count%1000 == 0 and  count!= 0:
                #print(result)
                logger.debug("＝＝＝＝{count} 次添加关系＝＝＝＝".format(count=count))
            #print(query.format(company_id=result[0],risk_label = result[1]))
            #print(result[0].replace('（','(').replace('）',')'))
            #print(result[1])
            cql_result = self.g.run(query.format(company_nm=result[0].replace('（','(').replace('）',')'),risk_label = result[1]))
            count += 1
            #logger.debug(cql_result.stats())

if __name__ == "__main__":
    add_risk_info = AddRiskLabelInfo(proj_config=proj_config,NEO4J_ENV=NEO4J_ENV,)
    add_risk_info.graph_connection()
    starttime = datetime.datetime.now()
    print(starttime.strftime('%Y-%m-%d'))
    add_risk_info.updata_pfcompany_risk_label_from_redis()
    add_risk_info.updata_pricompany_risk_label_from_redis()

    log_contents = log_capture_string.getvalue()
    log_capture_string.close()
    sendMail = SendMail()
    sendMail._send_finished_mail(message=str(log_contents),Subject=os.path.splitext(os.path.split(__file__)[-1])[0]+" 执行完成")

