#!/usr/bin/env python
# -*- coding: utf-8 -*-
import cx_Oracle
from optparse import OptionParser
from urllib.request import urlopen
import json,urllib
import datetime
USAGE = "usage: cd /root/NLP-pythonProj/news_sentiment &&  /opt/python3-env/bin/python bond_news.py --ip 106.14.30.97 --port 1521 --server orcl --uid CS_PORTAL --pw abc123"
parser = OptionParser(USAGE)
parser.add_option("--ip", dest="ip",default = "10.100.47.14",help="链接oracle的ip")
parser.add_option("--port", dest="port",default = "1521",help="链接oracle的port")
parser.add_option("--uid", dest="uid",default = "CS_PORTAL",help="链接oracle的userid")
parser.add_option("--pw", dest="pw",default = "RGDU2Csp",help="链接oracle的password")
parser.add_option("--server", dest="server",default = "orclp",help="链接oracle的server")
opt, args = parser.parse_args()
# NEO4J_ENV = opt.NEO4J_ENV if opt.NEO4J_ENV else "UAT_NEO4J"
today = datetime.date.today().strftime("%Y_%m_%d")
day0_today =  datetime.date.today().strftime("%Y-%m-%d")
day7_before = (datetime.date.today()-datetime.timedelta(days = 7)).strftime("%Y-%m-%d")
day30_before = (datetime.date.today()-datetime.timedelta(days = 30)).strftime("%Y-%m-%d")
day60_before = (datetime.date.today()-datetime.timedelta(days = 60)).strftime("%Y-%m-%d")
ret_num = 300

query_news_company = '''
SELECT E.COMPANY_ID AS COMPANY_ID,E.COMPANY_NM AS COMPANY_NM,E.COMPANY_SNM AS COMPANY_SNM FROM COMPY_BASICINFO E
INNER JOIN
(
SELECT DISTINCT COMPANY_ID FROM  XW_NEWS_COMPANY A 
INNER JOIN NEWS_BASICINFO B
ON A.NEWS_BASICINFO_SID = B.NEWS_BASICINFO_SID
WHERE B.POST_DT > ADD_MONTHS(SYSTIMESTAMP,-2) AND A.ISDEL = 0
) F
ON E.COMPANY_ID = F.COMPANY_ID
WHERE E.IS_DEL = 0
'''

query_public_company = '''
SELECT E.COMPANY_ID AS COMPANY_ID,E.COMPANY_NM AS COMPANY_NM,E.COMPANY_SNM AS COMPANY_SNM  FROM COMPY_BASICINFO E
INNER JOIN
(SELECT DISTINCT COMPANY_ID FROM  VW_COMPY_TYPE WHERE COMPANY_TYPE = 1) F
ON E.COMPANY_ID = F.COMPANY_ID
WHERE E.IS_DEL = 0

'''

query_pfcompany = '''
SELECT E.COMPANY_ID AS COMPANY_ID,E.COMPANY_NM AS COMPANY_NM,E.COMPANY_SNM AS COMPANY_SNM  FROM COMPY_BASICINFO E
INNER JOIN
(SELECT DISTINCT COMPANY_ID FROM PFCOMPY_BASICINFO WHERE ISDEL = 0) F
ON E.COMPANY_ID = F.COMPANY_ID
WHERE E.IS_DEL = 0
'''
class ExportBondNewsFromOracle:
    def __init__(self):
        pass

    def oracle_connect(self,ip='106.14.30.97',port=1521,server = 'orcl',uid = 'CS_PORTAL' ,pw = 'abc123'):
        '''
        链接oracle
        :param ip:  oracle 的IP
        :param port: oracle 服务器的端口
        :param server: oracle连接的方式
        :return:
        '''
        print([ip,port,server,uid,pw])
        dsn_tns = cx_Oracle.makedsn(ip, port, server)
        self.con = cx_Oracle.connect(uid, pw, dsn_tns, encoding="UTF-8", nencoding="UTF-8")
        print(self.con.version)
        self.cursor = self.con.cursor()
        
    def oracle_connection_close(self):
        '''
        关闭oracle的链接
        :return:
        '''
        self.cursor.close()
        self.con.close()
    
    def save_query_result(self,query = query_news_company):
        
        self.cursor.execute(query)
        #row = self.cursor.fetchone()
        row = self.cursor.fetchall()
        #print(row)
        return row
    def get_news(self,comid,subname,compnm,max_ret_num,day_before):
            #headers = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0'}  
            #print(subname)
            try:
                url=urlopen("http://10.100.46.15:8984/solr/db/select?fq=last_modified:["+day_before+"T00:00:00.000Z%20TO%20"+day0_today+"T23:59:59.000Z]&indent=on&q=company_ids:"+comid+"&rows="+str(max_ret_num)+"&sort=last_modified%20desc&wt=json")
                data = json.loads(url.read().decode('utf-8',errors='ignore')  )
                newslist = data['response']['docs']    
                #if not newslist:
                    #url=urlopen("http://10.100.46.15:8984/solr/db/select?fq=last_modified:["+day_before+"T00:00:00.000Z%20TO%20"+day0_today+"T23:59:59.000Z]&indent=on&q=text:"+urllib.parse.quote('\"'+subname+'\"')+"&rows="+str(max_ret_num)+"&sort=last_modified%20desc&wt=json")
                    #data = json.loads(url.read().decode('utf-8',errors='ignore')  )
                    #print(data)
                    #newslist = data['response']['docs']
                #if not newslist:
                    #url=urlopen("http://10.100.46.15:8984/solr/db/select?fq=last_modified:["+day_before+"T00:00:00.000Z%20TO%20"+day0_today+"T23:59:59.000Z]&indent=on&q=text:"+urllib.parse.quote('\"'+compnm+'\"')+"&rows="+str(max_ret_num)+"&sort=last_modified%20desc&wt=json")
                    #data = json.loads(url.read().decode('utf-8',errors='ignore')  )
                    #newslist = data['response']['docs']
                print([subname,len(newslist)])
                for bond_news in newslist:
                    newsid = bond_news['id']
                    title = "".join(bond_news['title'][0].split()) 
                    content = "".join(bond_news['content'][0].split()) 
                    #print(newsid)
                    #print(title)
                    #print(content)
                    #print(comid)
                    with open('/mnt/oracle/news/'+today+'/company_id_info_cd.csv', 'a+',errors = "ignore") as f1: 
                        f1.write("\""+comid+"\",\""+newsid+"\"\n")
                    with open('/mnt/oracle/news/'+today+'/info_cd_plain_text.csv', 'a+',errors = "ignore") as f2: 
                        f2.write("\""+newsid+"\",\""+title+"\",\""+content+"\"\n")
            except Exception as e:
                print(subname)
                print(e)
            
if __name__ == "__main__":
    export_news_from_oracle = ExportBondNewsFromOracle()
    export_news_from_oracle.oracle_connect(ip=opt.ip,port=opt.port,server=opt.server,uid = opt.uid,pw = opt.pw)
    news_company = export_news_from_oracle.save_query_result(query  = query_news_company)
    #print(news_company)
    #results_pfcompany = export_news_from_oracle.save_query_result(query  = query_pfcompany)
    #results = [(12021044, '都赛股份'), (12021045, '天易成')]
    with open('/mnt/oracle/news/'+today+'/company_id_info_cd.csv', 'w') as f1: 
        f1.write("COMPANY_ID,INFO_CD\n")
    with open('/mnt/oracle/news/'+today+'/info_cd_plain_text.csv', 'w') as f2: 
        f2.write("INFO_CD,TITLE,PLAIN_TEXT\n")
    for result in news_company:
        export_news_from_oracle.get_news(str(result[0]),result[2] if result[2] else result[1],result[1],ret_num,day60_before)
    #for result in results_pfcompany:
        #export_news_from_oracle.get_news(str(result[0]),result[2] if result[2] else result[1],result[1],ret_num,day30_before)
    export_news_from_oracle.oracle_connection_close()
