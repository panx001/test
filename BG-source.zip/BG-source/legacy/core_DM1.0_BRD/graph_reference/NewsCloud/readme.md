# portal 词云定时更新流程  

    更新执行服务器：10.100.45.15

## 每日执行的crontab脚本（见crontab.txt）

    0 1 * * * /bin/bash /home/oracle/news/crontab_info.sh    > /dev/null 2>&1
    0 2 * * * /bin/bash /root/NLP-pythonProj/news_cloud_extract/dailyUpdate.sh  > /home/zhoujr/crontab.log 2>&1

    /bin/bash /home/oracle/news/crontab_info.sh   //用于从solr导出每日企业相关新闻
    /root/NLP-pythonProj/news_cloud_extract/dailyUpdate.sh     //用于计算新闻中tfidf前50的单词，将结果写入到redis中

### crontab_info.sh

    将每日新闻导出到文件夹（同时删除历史数据），目前导出两个月新闻

### dailyUpdate.sh

    news_cut.py      //对导出的新闻进行切词
    company_word_cloud_with_split_file.py     //计算tfidf结果
    news_cloud_redis_export_prod.py/news_cloud_redis_export_uat.py       //将计算结果写到redis中，计算结果在redis中缓存5天时间