#!/bin/bash
/opt/python3-env/bin/python3 /root/NLP-pythonProj/news_cloud_extract/news_cut.py
/opt/python3-env/bin/python3 /root/NLP-pythonProj/news_cloud_extract/company_word_cloud_with_split_file.py
/opt/python3-env/bin/python3 /root/NLP-pythonProj/news_cloud_extract/news_cloud_redis_export_prod.py
/opt/python3-env/bin/python3 /root/NLP-pythonProj/news_cloud_extract/news_cloud_redis_export_uat.py

