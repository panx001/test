#!/usr/bin/env python
#-*- coding:utf-8 -*-
#@Time  : 17/1/23 下午2:36
#@Author: wuchenglong



# from gensim import corpora, models
# from scipy.sparse import csr_matrix
# from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
# from sklearn import svm
# import numpy as np
# import os,re,time,logging
# import jieba
# import pickle as pkl
# import jieba.analyse
# import numpy as np
# import pandas as pd
# import jieba,re
# import jieba.posseg as pseg
import sys,os
sys.path.append(os.path.dirname(os.path.abspath(sys.argv[0])))
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0]))))
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))))
print(sys.path)
from collections import defaultdict
import codecs,os,random
from operator import itemgetter
from optparse import OptionParser
from python_neo4j_update.my_log import logger,log_capture_string
from python_neo4j_update.update_neo4j_data.mail import SendMail
import  datetime
from sklearn.feature_extraction.text import TfidfVectorizer

import os
proj_dir = os.path.dirname(__file__)
print(os.getcwd())
os.chdir(proj_dir)
print(os.getcwd())
USAGE = "usage: python company_word_cloud.py -f [file name to out put] -d [the cuted file to store ]"
# rm -rf /root/news_keywords.csv
# /opt/python3-env/bin/python3 /root/NLP-pythonProj/news_cloud_extract/company_word_cloud_with_split_file.py
# /opt/python3-env/bin/python3 /root/NLP-pythonProj/news_cloud_extract/company_word_cloud_with_split_file.py -f /root/news_keywords.csv -d /home/oracle/news/2017_02_20/info_cd_plain_text_combine/
# /Users/wuchenglong/myApp/python35Env/bin/python /Users/wuchenglong/Documents/MyNoteBook/NLP/NLP-pythonProj/news_cloud_extract/company_word_cloud_with_split_file.py  -f /Users/wuchenglong/Documents/TextClassifyCorpus/news_keywords1.csv -d /Users/wuchenglong/Documents/TextClassifyCorpus/news/
parser = OptionParser(USAGE)
parser.add_option("-d", dest="corpus_dir")
parser.add_option("-f", dest="file")
opt, args = parser.parse_args()
copurs_dir = "/mnt/oracle/news/"
updt_date = max([elem  for elem in os.listdir(copurs_dir) if os.path.isdir(os.path.join(copurs_dir,elem))])

corpus_dir = opt.corpus_dir if opt.corpus_dir else  os.path.join(copurs_dir, updt_date, "info_cd_plain_text_combine")
# corpus_dir = "/home/oracle/news/{today}/info_cd_plain_text_combine/".format(today=datetime.datetime.now().strftime("%Y_%m_%d"))
file = opt.file if opt.file else os.path.join(copurs_dir, updt_date, "news_keywords.csv")
# file = '/home/oracle/news/{today}/news_keywords.csv'.format(today=datetime.datetime.now().strftime("%Y_%m_%d"))


def read_doc_list(corpus_dir,file_list):
    """read segmented docs"""
    trade_list = []
    doc_list = []
    for txt in file_list:
        trade_list.append(txt.split(".")[0])
        with codecs.open(os.path.join(corpus_dir, txt), "r", "utf-8",errors='ignore') as fr:
            doc_list.append(fr.read().replace('\n', ' '))
    return trade_list, doc_list

def tfidf_top(trade_list, doc_list, max_df, topn):
    vectorizer = TfidfVectorizer(max_df=max_df)
    matrix = vectorizer.fit_transform(doc_list)
    feature_dict = {v: k for k, v in vectorizer.vocabulary_.items()}  # index -> feature_name
    # print(matrix.todense())
    word = vectorizer.get_feature_names()
    weight = matrix.toarray()


    tail = [[trade_list[i],word[j], weight[i][j] ]  for i in range(len(weight)) for j in range(len(word)) ]
    tail_dict = defaultdict(list)
    tail = sorted(tail, key=itemgetter(2,1),reverse=True)
    for elem in tail:
        if len(tail_dict[elem[0]])<100 and elem[2]>0 :
            tail_dict[elem[0]].append([elem[1],elem[2]])

    fw = codecs.open(file, 'a+', 'utf-8')
    for key in tail_dict.keys():
        # logger.debug('========================={key}============================='.format(key=key))
        for elem in tail_dict[key]:
            fw.write(','.join([key]+[str(elem_i) for elem_i in elem])+"\n")
    fw.close()


if __name__=='__main__':

    if os.path.exists(file):
        logger.debug("delete the old file")
        os.remove(file)

    fw = codecs.open(file, 'a+', 'utf-8')
    fw.write(",".join(("company_id", "keyword", "weight")) + "\n")
    fw.close()
    files = [elem for elem in os.listdir(corpus_dir) if elem.endswith("txt")]
    random.shuffle(files)
    file_sliced_index = [files[i:i + 20] for i in range(0, len(files), 20)]

    slice_index = 1
    logger.debug("=======总共 {slice_index}个slices======".format(slice_index=len(file_sliced_index)))
    for file_elem in file_sliced_index:
        tl, dl = read_doc_list(corpus_dir, file_elem)
        tdf = tfidf_top(tl, dl, max_df=0.90, topn=10)
        slice_index = slice_index + 1
        if slice_index % 100 == 0:
            logger.debug("======={slice_index} 个slice 完成======".format(slice_index=slice_index))

    logger.debug("======={tips}======".format(tips="完成"))

    log_contents = log_capture_string.getvalue()
    log_capture_string.close()
    sendMail = SendMail()
    sendMail._send_finished_mail(message=str(log_contents),
                                 Subject=os.path.splitext(os.path.split(__file__)[-1])[0] + " 执行完成")

