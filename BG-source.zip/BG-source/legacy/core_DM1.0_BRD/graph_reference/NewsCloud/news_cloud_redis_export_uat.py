import json
import redis,os
from collections import defaultdict
#redis_conn = redis.StrictRedis(host='10.100.24.12',password='Cscs@31$2016#',port=6379)
redis_conn = redis.StrictRedis(host='10.100.44.16',password='Cscs@31$2016#',port=6379)
#redis_conn = redis.StrictRedis(host='10.100.46.18',password='Cscs@31$2016#',port=6379)
copurs_dir = "/mnt/oracle/news/"
updt_date = max([elem  for elem in os.listdir(copurs_dir) if os.path.isdir(os.path.join(copurs_dir,elem))])
#print(redis_conn.get('北京一丢丢科技有限公司__周亚辉'))
#print(redis_conn.get('pfund_data427038').decode('utf8'))
#keys = redis_conn.keys()
#index = 1

def save_wordcloud_to_redis(clouddata):
    for key in clouddata.keys():
        try:
            print(key, end = ' ')
            result = sorted(clouddata.get(key),key=lambda x:x.get("value"),reverse=True)
            if len(result)>=50:
                result = result[:50]
            print(len(result))
            #print(result)
            redis_conn.set('newscloud_'+key,json.dumps(result),ex=432000)#,ex=432000
        except Exception as e:
            print(e)
            #break
            #print(key, end = ' ')


if __name__=='__main__':
    param = [line.strip().split(",") for line in open('/mnt/oracle/news/'+updt_date+'/news_keywords.csv', "r",encoding="utf-8").readlines()[1:]]
    result = defaultdict(list)
    for company_id,word,tfnum in param:
        try:
            result[company_id].append({"name":word,"value":float(tfnum)})
        except Exception as e:
            print(e)
    save_wordcloud_to_redis(result)
