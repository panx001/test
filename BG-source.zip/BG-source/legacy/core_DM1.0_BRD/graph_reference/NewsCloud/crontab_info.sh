# crontab
# chmod +x /home/oracle/news/crontab_info.sh
# 0 1 * * 2,4,6 /home/oracle/news/crontab_info.sh    > /dev/null 2>&1

today=`date +%Y_%m_%d`
lastday=`date -d '-7 day' +%Y_%m_%d`
echo $today
base_dir='/mnt/oracle/news/'

rm -rf $base_dir$lastday
echo "$base_dir$lastday 历史文件删除成功"
mkdir $base_dir$today -p
echo "$base_dir$today 文件夹创建成功"
source ~/.bash_profile
# source /etc/profile
source /etc/profile


export NLS_LANG="American_America.UTF8"
echo "`date '+%Y-%m-%d %H:%M:%S'` 开始导出新闻数据"
#sqlplus oracle_graphdb_trans/oeTsRSBfSga17SSx@portal_prod @/home/oracle/news/company_id_info_cd.sql
#sqlplus oracle_graphdb_trans/oeTsRSBfSga17SSx@portal_prod @/home/oracle/news/info_cd_plain_text.sql
/opt/python3-env/bin/python3 /home/oracle/news/cloud_news_from_solr.py  > /home/oracle/news/log.log 2>&1

echo "`date '+%Y-%m-%d %H:%M:%S'` 导出新闻数据完成"
