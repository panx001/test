#!/usr/bin/env python
#-*- coding:utf-8 -*-
#@Time  : 17/1/20 下午1:48
#@Author: wuchenglong

import sys,os
sys.path.append(os.path.dirname(os.path.abspath(sys.argv[0])))
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0]))))
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))))
print(sys.path)
from collections import defaultdict
from python_neo4j_update.my_log import logger,log_capture_string
from python_neo4j_update.update_neo4j_data.mail import SendMail
import  csv,os,re
import jieba,datetime
import jieba.posseg as pseg
# 支持并行分词;提高分词效率
# jieba.enable_parallel(3)
proj_dir = os.path.dirname(__file__)
logger.debug(os.getcwd())
os.chdir(proj_dir)
logger.debug(os.getcwd())

from optparse import OptionParser
USAGE = "usage: python news_cut.py [file name] -d [the cuted file to store ]"
# source /opt/python3-env/bin/activate
# rm -rf /root/news/*
# /opt/python3-env/bin/python3 /root/NLP-pythonProj/news_cloud_extract/news_cut.py
# /opt/python3-env/bin/python3 /root/NLP-pythonProj/news_cloud_extract/news_cut.py -f /home/oracle/news/2017_02_19/info_cd_plain_text.csv -d /home/oracle/news/2017_02_19/info_cd_plain_text
parser = OptionParser(USAGE)
parser.add_option("-d", dest="corpus_dir")
parser.add_option("-f", dest="file")
opt, args = parser.parse_args()
logger.debug("---opt.file---")
logger.debug(opt.file)

copurs_dir = "/mnt/oracle/news/"
updt_date = max([elem  for elem in os.listdir(copurs_dir) if os.path.isdir(os.path.join(copurs_dir,elem))])

corpus_dir = opt.corpus_dir if opt.corpus_dir else os.path.join(copurs_dir,updt_date,"info_cd_plain_text")
if not os.path.exists(corpus_dir):
    os.mkdir(corpus_dir)
file = opt.file if opt.file else os.path.join(copurs_dir,updt_date,"info_cd_plain_text.csv")
if not os.path.exists(corpus_dir+"_combine"):
    os.mkdir(corpus_dir+"_combine")
else:
    pass

#jieba.load_userdict("user_dict/company_nm.txt")
#jieba.load_userdict("user_dict/person_name.txt")
#jieba.load_userdict("user_dict/user_dict.txt")
#jieba.load_userdict("user_dict/stop_words.txt")
#jieba.load_userdict("user_dict/bond_name.txt")

pseg.re_han_internal = re.compile("([\u4E00-\u9FD5a-zA-Z0-9+#&()（）\._]+)")
for dict_file in sorted(os.listdir("user_dict")):
    if not dict_file.endswith("txt"):
        continue
    jieba.load_userdict(os.path.join("user_dict",dict_file))
    logger.debug("---user dict {dict_file}{space} loaded---".format(dict_file=dict_file,space=" "*(20-len(dict_file))))


# while True:
#     words1 = input(">>>>")
#     # print(list(jieba.cut(words1)))
#     # print('/'.join(jieba.cut(words1, HMM=False)))
#     # words = pseg.cut(words1)
#     # for word, flag in words:
#     #     print('%s %s' % (word, flag))
#     words = pseg.cut(words1)
#     for word, flag in words:
#         if flag not in ["x", "d", "m", "eng", "stopword","p","vg","uj","t","c","q"] and len(word)>1:
#             print('%s %s' % (word, flag))


company_industry = defaultdict(str)
company_industry_train_or_test_type = defaultdict(str)
company_news_count = defaultdict(int)
if __name__ == "__main__":
    # 先将新闻分到每个txt文件
    logger.info("＝＝＝＝＝＝分词开始＝＝＝＝＝")

    with open(file,errors='ignore',encoding='utf-8') as f:
        f_csv = csv.DictReader(f,delimiter=',')
        i= 1
        for row in f_csv:
            with open(os.path.join(corpus_dir, row['INFO_CD']  + ".txt"), 'w',encoding='utf-8') as f:
                all_keywords = []
                for  elem, flag in  pseg.cut(" ".join([row["TITLE"]*10,row["PLAIN_TEXT"]])):
                    if  flag not in ["x", "d", "m", "eng", "stopword","p","vg","uj","t","c","q"] and len(elem)>1:
                        if flag in ["personname","bondname","companynm"]:
                            all_keywords.extend([elem] * 5)
                        else:
                            all_keywords.extend([elem])
                f.write(" ".join(all_keywords))
            if i % 1000 == 0:
                logger.debug("处理了{i}行".format(i=i))
            i = i + 1

    logger.info("＝＝＝＝＝合并分词结果到企业＝＝＝＝＝")
    # 将分词后的新闻合并到各个公司下面
    with open(os.path.join(os.path.dirname(file),"company_id_info_cd.csv"),errors='ignore',encoding='utf-8') as f:
        f_csv = csv.DictReader(f,delimiter=',')
        i = 1
        for row in f_csv:
            try:
                f_write = open(os.path.join(corpus_dir+"_combine",row["COMPANY_ID"]+".txt"),'a+',encoding='utf-8')
                f_write.write(" ".join([line.strip() for line in open(os.path.join(corpus_dir,row["INFO_CD"]+".txt"))]))
                f_write.close()
            except Exception as e:
                logger.debug(e)
            if i % 1000 == 0:
                logger.debug("处理了{i}行".format(i=i))
            i = i + 1

    log_contents = log_capture_string.getvalue()
    log_capture_string.close()
    sendMail = SendMail()
    sendMail._send_finished_mail(message=str(log_contents),
                                 Subject=os.path.splitext(os.path.split(__file__)[-1])[0] + " 执行完成")
