package spring.data.neo4j;

/**
 * Created by wuchenglong on 16/12/12.
 */

import org.springframework.context.annotation.*;
import net.sf.json.JSONObject;
import net.sf.json.JSONArray;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.junit.Test;
import org.omg.Messaging.SYNC_WITH_TRANSPORT;
import org.springframework.web.bind.annotation.RequestParam;
import spring.data.neo4j.Util.String2MD5;

import javax.net.ssl.HttpsURLConnection;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.lang.*;

public class HttpClientExample {
    private String access_token;
    private String queryResult;
    public String getQueryResult(){
        return queryResult;
    }

    private final String USER_AGENT = "Mozilla/5.0";

    public static void main(String[] args) throws Exception {

        HttpClientExample http = new HttpClientExample();

        // System.out.println("Testing 1 - Send Http GET request");
        // http.sendGet();
        // System.out.println("\nTesting 2 - Send Http POST request");
        http.getTokenBySendPost();
        // http.sendGet("西宁伊河龙清真肉食品有限公司");
        // http.sendGet("青海银龙酒店有限公司");
        // http.sendGet("青海省创业发展孵化器有限公司");

        // http.GetPersonInfoByCompanyNameAndPersonName("海东市嘉美餐饮服务有限公司","席维成");
        // System.out.println(http.getQueryResult());
    }

    // HTTP GET request



    @Test
    public void nodeIdCreate() throws Exception{
        System.out.println("王石".hashCode());
        System.out.println("往事".hashCode());
        // System.out.println("万科企业股份有限公司".hashCode());
        System.out.println("青海银龙酒店有限公司".hashCode());
        // GetCompanyInfoByCompanyName("深圳长城汇理资产管理有限公司");
    }

    @Test
    public void GetPersonInfoByCompanyNameAndPersonName() throws Exception {
        String companyName = "";
        String personName = "";
        // String url = "http://218.17.133.57:7070/enterprise/fuzzy/"+URLEncoder.encode(keyWord,"UTF-8");
        String url = String.format("http://139.196.212.16:7070/person/company_name/%s/person_name/%s",URLEncoder.encode(companyName,"UTF-8"),URLEncoder.encode(personName,"UTF-8"));
        // System.out.println(URLEncoder.encode("this中华人民共和国","UTF-8"));
        HttpClient client = new DefaultHttpClient();
        HttpGet request = new HttpGet(url);
        // add request header
        request.addHeader("Authorization", "bearer "+this.access_token);
        HttpResponse response = client.execute(request);
        BufferedReader rd = new BufferedReader(
                new InputStreamReader(response.getEntity().getContent()));

        StringBuffer result = new StringBuffer();
        String line = "";
        while ((line = rd.readLine()) != null) {
            result.append(line);
        }

        JSONObject dataOfJson = JSONObject.fromObject(result.toString());

        System.out.println(dataOfJson);
        System.out.println(dataOfJson.getJSONObject("DATA").keySet());
        // System.out.println(dataOfJson.getJSONObject("DATA").getJSONObject("PERSON").get("ITEM"));

        Object RYPOSFR = dataOfJson.getJSONObject("DATA").get("RYPOSFR");
        if(RYPOSFR instanceof JSONObject) {
            System.out.println("法定代表人");

            // System.out.println(((JSONObject) ENTINV).get("ITEM").getClass());
            if (((JSONObject) RYPOSFR).get("ITEM") instanceof JSONArray) {
                for (Object item : (JSONArray) (((JSONObject) RYPOSFR).get("ITEM"))) {
                    JSONObject newItem = (JSONObject) item;
                    RelationNode newNode = new RelationNode("法定代表人",newItem.get("ENTNAME").toString(),"","Company");
                    System.out.println(newNode.toMap().toString());
                }
            }
            if (((JSONObject) RYPOSFR).get("ITEM") instanceof JSONObject) {
                JSONObject newItem = (JSONObject) ((JSONObject) RYPOSFR).get("ITEM");
                RelationNode newNode = new RelationNode("法定代表人",newItem.get("ENTNAME").toString(),"","Company");
                System.out.println(newNode.toMap().toString());
            }
        }else{
            System.out.println("无法定代表人信息");
        }

        Object RYPOSSHA = dataOfJson.getJSONObject("DATA").get("RYPOSSHA");
        if(RYPOSSHA instanceof JSONObject) {
            System.out.println("对外投资");

            // System.out.println(((JSONObject) ENTINV).get("ITEM").getClass());
            if (((JSONObject) RYPOSSHA).get("ITEM") instanceof JSONArray) {
                for (Object item : (JSONArray) (((JSONObject) RYPOSSHA).get("ITEM"))) {
                    JSONObject newItem = (JSONObject) item;
                    RelationNode newNode = new RelationNode(newItem.get("FUNDEDRATIO"),newItem.get("ENTNAME").toString(),"","Company");
                    System.out.println(newNode.toMap());
                }
            }
            if (((JSONObject) RYPOSSHA).get("ITEM") instanceof JSONObject) {
                JSONObject newItem = (JSONObject) ((JSONObject) RYPOSSHA).get("ITEM");
                RelationNode newNode = new RelationNode(newItem.get("FUNDEDRATIO"),newItem.get("ENTNAME").toString(),"","Company");
                System.out.println(newNode.toMap());
            }
        }else{
            System.out.println("无对外投资信息");
        }

        Object RYPOSPER = dataOfJson.getJSONObject("DATA").get("RYPOSPER");
        if(RYPOSSHA instanceof JSONObject) {
            System.out.println("对外任职");

            // System.out.println(((JSONObject) ENTINV).get("ITEM").getClass());
            if (((JSONObject) RYPOSPER).get("ITEM") instanceof JSONArray) {
                for (Object item : (JSONArray) (((JSONObject) RYPOSPER).get("ITEM"))) {
                    JSONObject newItem = (JSONObject) item;
                    RelationNode newNode = new RelationNode(newItem.get("POSITION"),newItem.get("ENTNAME").toString(),"","Company");
                    System.out.println(newNode.toMap());
                }
            }
            if (((JSONObject) RYPOSPER).get("ITEM") instanceof JSONObject) {
                JSONObject newItem = (JSONObject) ((JSONObject) RYPOSPER).get("ITEM");
                RelationNode newNode = new RelationNode(newItem.get("POSITION"),newItem.get("ENTNAME").toString(),"","Company");
                System.out.println(newNode.toMap());
            }
        }else{
            System.out.println("无对对外任职");
        }

        this.queryResult=result.toString();
    }


    @Test
    public void GetCompanyInfoByCompanyName() throws Exception {
        String  companyName = "深圳长城汇理资产管理有限公司";

        // String url = "http://218.17.133.57:7070/enterprise/fuzzy/"+URLEncoder.encode(keyWord,"UTF-8");
        String url = "http://218.17.133.57:7070/enterprise/info/"+       URLEncoder.encode(companyName,"UTF-8");
        // String url = "http://218.17.133.57:7070" + "/enterprise/info/" + URLEncoder.encode(companyName, "UTF-8");
        // System.out.println(URLEncoder.encode("this中华人民共和国","UTF-8"));

        HttpClient client = new DefaultHttpClient();
        HttpGet request = new HttpGet(url);

        // add request header
        request.addHeader("Authorization", "bearer "+this.access_token);

        HttpResponse response = client.execute(request);

        // System.out.println("\nSending 'GET' request to URL : " + url);
        // System.out.println("Response Code : " +  response.getStatusLine().getStatusCode());

        BufferedReader rd = new BufferedReader(
                new InputStreamReader(response.getEntity().getContent()));

        StringBuffer result = new StringBuffer();
        String line = "";
        while ((line = rd.readLine()) != null) {
            result.append(line);
        }

        JSONObject dataOfJson = JSONObject.fromObject(result.toString());

        System.out.println(dataOfJson);
        System.out.println(dataOfJson.getJSONObject("DATA").keySet());
        System.out.println(dataOfJson.getJSONObject("DATA").getJSONObject("PERSON").get("ITEM"));
        System.out.println(dataOfJson.getJSONObject("DATA").getJSONObject("SHAREHOLDER").get("ITEM"));
        System.out.println(dataOfJson.getJSONObject("DATA").getJSONObject("FRINV").get("ITEM"));
        System.out.println(dataOfJson.getJSONObject("DATA").get("ENTINV"));
        Object ENTINV = dataOfJson.getJSONObject("DATA").get("ENTINV");
        System.out.println(ENTINV.getClass());
        System.out.println(ENTINV instanceof String);
        if(ENTINV instanceof JSONObject) {
            System.out.println("对外投资");
            // System.out.println(((JSONObject) ENTINV).get("ITEM").getClass());
            if (((JSONObject) ENTINV).get("ITEM") instanceof JSONArray) {
                for (Object item : (JSONArray) (((JSONObject) ENTINV).get("ITEM"))) {
                    JSONObject newItem = (JSONObject) item;
                    System.out.println(newItem.get("FUNDEDRATIO"));
                    System.out.println(newItem.get("ENTNAME"));
                }
                // System.out.println(((JSONArray) ((JSONObject) ENTINV).get("ITEM")).get(0).getClass());
            }
            if (((JSONObject) ENTINV).get("ITEM") instanceof JSONObject) {
                JSONObject newItem = (JSONObject) ((JSONObject) ENTINV).get("ITEM");
                System.out.println(newItem.get("FUNDEDRATIO"));
                System.out.println(newItem.get("ENTNAME"));
            }
        }else{
            System.out.println("无对外投资");
        }

        Object SHAREHOLDER = dataOfJson.getJSONObject("DATA").get("SHAREHOLDER");
        if(SHAREHOLDER instanceof JSONObject) {
                System.out.println("股东");

            // System.out.println(((JSONObject) ENTINV).get("ITEM").getClass());
            if (((JSONObject) SHAREHOLDER).get("ITEM") instanceof JSONArray) {
                for (Object item : (JSONArray) (((JSONObject) SHAREHOLDER).get("ITEM"))) {
                    JSONObject newItem = (JSONObject) item;
                    System.out.println(newItem.get("FUNDEDRATIO"));
                    System.out.println(newItem.get("SHANAME"));
                }
                // System.out.println(((JSONArray) ((JSONObject) ENTINV).get("ITEM")).get(0).getClass());
            }
            if (((JSONObject) SHAREHOLDER).get("ITEM") instanceof JSONObject) {
                JSONObject newItem = (JSONObject) ((JSONObject) SHAREHOLDER).get("ITEM");
                System.out.println(newItem.get("FUNDEDRATIO"));
                System.out.println(newItem.get("SHANAME"));
            }
        }else{
            System.out.println("无股东");
        }

        Object PERSON = dataOfJson.getJSONObject("DATA").get("PERSON");
        if(PERSON instanceof JSONObject) {
            System.out.println("高管");

            // System.out.println(((JSONObject) ENTINV).get("ITEM").getClass());
            if (((JSONObject) PERSON).get("ITEM") instanceof JSONArray) {
                for (Object item : (JSONArray) (((JSONObject) PERSON).get("ITEM"))) {
                    JSONObject newItem = (JSONObject) item;
                    System.out.println(newItem.get("POSITION"));
                    System.out.println(newItem.get("PERNAME"));
                }
                // System.out.println(((JSONArray) ((JSONObject) ENTINV).get("ITEM")).get(0).getClass());
            }
            if (((JSONObject) PERSON).get("ITEM") instanceof JSONObject) {
                JSONObject newItem = (JSONObject) ((JSONObject) PERSON).get("ITEM");
                System.out.println(newItem.get("POSITION"));
                System.out.println(newItem.get("PERNAME"));
            }
        }else{
            System.out.println("无股东");
        }

        this.queryResult=result.toString();
    }

    // HTTP POST request
    @Test
    public void getTokenBySendPost() throws Exception {

        String url = "http://218.17.133.57:7070/oauth/token";

        HttpClient client = new DefaultHttpClient();
        HttpPost post = new HttpPost(url);


        // add header
        // post.setHeader("User-Agent", USER_AGENT);
        post.setHeader("Authorization", "Basic Y2xpZW50YXBwOjEyMzQ1Ng==");
        List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();

        // add header
        post.setHeader("Authorization", "Basic Y2xpZW50YXBwOjEyMzQ1Ng==");
        urlParameters.add(new BasicNameValuePair("client_id", "clientapp"));
        urlParameters.add(new BasicNameValuePair("grant_type", "password"));
        urlParameters.add(new BasicNameValuePair("username", "portal"));
        urlParameters.add(new BasicNameValuePair("password", "123"));


        post.setEntity(new UrlEncodedFormEntity(urlParameters));
        // post.setEntity(new UrlEncodedFormEntity(urlParameters));

        HttpResponse response = client.execute(post);
        // System.out.println("\nSending 'POST' request to URL : " + url);
        // System.out.println("Post parameters : " + post.getEntity());
        // System.out.println("Response Code : " + response.getStatusLine().getStatusCode());

        BufferedReader rd = new BufferedReader(
                new InputStreamReader(response.getEntity().getContent()));

        StringBuffer result = new StringBuffer();
        String line = "";
        while ((line = rd.readLine()) != null) {
            result.append(line);
        }

        // JSONObject resultJson = (JSONObject)response.getEntity();
        JSONObject dataOfJson = JSONObject.fromObject(result.toString());
        // JSONObject dataOfJson1 = JSONObject.fromObject(rd);
        String access_token = dataOfJson.get("access_token").toString();
        System.out.println(access_token);
        // System.out.println(dataOfJson);
        // System.out.println(result.toString());
        this.access_token=access_token;
    }



    // HTTP GET request
    @Test
    public void sendGet1() throws Exception {

        String url = "http://www.google.com/search?q=mkyong";

        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();

        // optional default is GET
        con.setRequestMethod("GET");

        //add request header
        con.setRequestProperty("User-Agent", USER_AGENT);

        int responseCode = con.getResponseCode();
        System.out.println("\nSending 'GET' request to URL : " + url);
        System.out.println("Response Code : " + responseCode);

        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        //print result
        System.out.println(response.toString());

    }

    // HTTP POST request
    @Test
    public void sendPost1() throws Exception {

        String url = "https://selfsolve.apple.com/wcResults.do";
        URL obj = new URL(url);
        HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();

        //add reuqest header
        con.setRequestMethod("POST");
        con.setRequestProperty("User-Agent", USER_AGENT);
        con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");

        String urlParameters = "sn=C02G8416DRJM&cn=&locale=&caller=&num=12345";

        // Send post request
        con.setDoOutput(true);
        DataOutputStream wr = new DataOutputStream(con.getOutputStream());
        wr.writeBytes(urlParameters);
        wr.flush();
        wr.close();

        int responseCode = con.getResponseCode();
        System.out.println("\nSending 'POST' request to URL : " + url);
        System.out.println("Post parameters : " + urlParameters);
        System.out.println("Response Code : " + responseCode);

        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        //print result
        System.out.println(response.toString());

    }

    @Test
    public void sendPost2() throws Exception {

        CloseableHttpClient httpclient = HttpClients.createDefault();
        // HttpGet httpGet = new HttpGet("http://targethost/homepage");
        // CloseableHttpResponse response1 = httpclient.execute(httpGet);
        // // The underlying HTTP connection is still held by the response object
        // // to allow the response content to be streamed directly from the network socket.
        // // In order to ensure correct deallocation of system resources
        // // the user MUST call CloseableHttpResponse#close() from a finally clause.
        // // Please note that if response content is not fully consumed the underlying
        // // connection cannot be safely re-used and will be shut down and discarded
        // // by the connection manager.
        // try {
        //     System.out.println(response1.getStatusLine());
        //     HttpEntity entity1 = response1.getEntity();
        //     // do something useful with the response body
        //     // and ensure it is fully consumed
        //     EntityUtils.consume(entity1);
        // } finally {
        //     response1.close();
        // }
        //




        HttpPost httpPost = new HttpPost("http://218.17.133.57:7070/oauth/token");
        httpPost.setHeader("Authorization", "Basic Y2xpZW50YXBwOjEyMzQ1Ng==");
        httpPost.setHeader("Content-Type", "application/form-data");
        List<NameValuePair> nvps = new ArrayList<NameValuePair>();
        nvps.add(new BasicNameValuePair("client_id", "clientapp"));
        nvps.add(new BasicNameValuePair("grant_type", "password"));
        nvps.add(new BasicNameValuePair("username", "portal"));
        nvps.add(new BasicNameValuePair("password", "123"));
        httpPost.setEntity(new UrlEncodedFormEntity(nvps));
        CloseableHttpResponse response2 = httpclient.execute(httpPost);

        try {
            System.out.println(response2.getStatusLine());
            HttpEntity entity2 = response2.getEntity();
            // do something useful with the response body
            // and ensure it is fully consumed
            EntityUtils.consume(entity2);
        } finally {
            response2.close();
        }
    }
}


class RelationNode{

    private Object nexus ;
    private String name;
    private String id;
    private String createdId;
    private String nodeType;
    // @JsonIgnore
    private Map<String,String> typeMap = new HashMap<String,String>(){{
        put("Company", "c-");
        put("PERSON", "p-");
    }};


    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getCreatedId() {
        return createdId;
    }
    public void setCreatedId(String createdId) {
        this.createdId=createdId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name=name;
        this.createdId=String.valueOf(name.hashCode());
    }
    public String getNodeType() {
        return nodeType;
    }
    public void setNodeType(String nodeType) {
        this.nodeType=nodeType;
    }
    public Object getNexus() {
        return nexus;
    }
    public void setNexus(Object nexus) {
        this.nexus=nexus;
    }


    public RelationNode(){
    }
    public RelationNode(Object nexus,String name,String createdId,String nodeType){
        this.id=typeMap.getOrDefault(nodeType,"u") + String2MD5.md5(String.valueOf(name.hashCode()));
        this.nexus=nexus;
        this.name=name;
        this.nodeType=nodeType;
        this.createdId=createdId;
    }
    @Override
    public String toString(){
        return "id: "+this.id+"  name:  "+this.name+"  createdId:  "+this.createdId;
    }



    public Map toMap(){
        Map resultMap = new HashMap();
        resultMap.put("info",this);
        // Map map = new HashMap<>();
        // map.put(id, resultMap);
        return resultMap;
    }
}