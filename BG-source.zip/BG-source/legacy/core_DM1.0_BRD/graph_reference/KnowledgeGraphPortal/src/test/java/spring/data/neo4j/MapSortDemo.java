package spring.data.neo4j;

/**
 * Created by wuchenglong on 16/12/15.
 */

import spring.data.neo4j.Entity.RelationNode;

import java.util.*;
import java.util.Map.Entry;


public class MapSortDemo {

    public static void main(String[] args) {

        Map<String, String> map = new TreeMap<String, String>();

        map.put("KFC", "kfc");
        map.put("WNBA", "wnba");
        map.put("NBA", "nba");
        map.put("CBA", "cba");

        // Map<String, String> resultMap = sortMapByKey(map);	//按Key进行排序
        Map<String, String> resultMap = sortMapByValue(map); //按Value进行排序

        for (Map.Entry<String, String> entry : resultMap.entrySet()) {
            System.out.println(entry.getKey() + " " + entry.getValue());
        }

        Map<String, RelationNode>  map2 = new HashMap<>();

        map2.put("1",new RelationNode("38.00%","厦门合兴包装印刷股份有限公司","","Company"));
        map2.put("3",new RelationNode("58.00%","壹家电(厦门)电器有限责任公司","","Company"));
        map2.put("2",new RelationNode("18.00%","壹家电(厦门)电器有限责任公司","","Company"));
        // map2.put("9",new RelationNode("0.08％","","",""));
        // map2.put("5",new RelationNode("","","",""));

        // Map<String, String> resultMap = sortMapByKey(map);	//按Key进行排序
        Map<String, RelationNode> resultMap2 = sortMapByNexusValue(map2); //按Value进行排序
        System.out.print(resultMap2);

        // for (Map.Entry<String, RelationNode> entry : resultMap2.entrySet()) {
        //     System.out.println(entry.getKey() + " " + entry.getValue().toString());
        // }
    }
    /**
     * 使用 Map按value进行排序
     * @param
     * @return
     */
    public static Map<String, String> sortMapByValue(Map<String, String> oriMap) {
        if (oriMap == null || oriMap.isEmpty()) {
            return null;
        }
        Map<String, String> sortedMap = new LinkedHashMap<String, String>();
        List<Map.Entry<String, String>> entryList = new ArrayList<Map.Entry<String, String>>(
                oriMap.entrySet());
        Collections.sort(entryList, new MapValueComparator());

        Iterator<Map.Entry<String, String>> iter = entryList.iterator();
        Map.Entry<String, String> tmpEntry = null;
        while (iter.hasNext()) {
            tmpEntry = iter.next();
            sortedMap.put(tmpEntry.getKey(), tmpEntry.getValue());
        }
        return sortedMap;
    }


    public static Map<String, RelationNode> sortMapByNexusValue(Map<String, RelationNode> oriMap) {
        if (oriMap == null || oriMap.isEmpty()) {
            return null;
        }
        Map<String, RelationNode> sortedMap = new LinkedHashMap<String, RelationNode>();
        List<Map.Entry<String, RelationNode>> entryList = new ArrayList<Map.Entry<String, RelationNode>>(
                oriMap.entrySet());
        Collections.sort(entryList, new MapNexusValueComparator());

        Iterator<Map.Entry<String, RelationNode>> iter = entryList.iterator();
        Map.Entry<String, RelationNode> tmpEntry;
        while (iter.hasNext()) {
            tmpEntry = iter.next();
            sortedMap.put(tmpEntry.getKey(), tmpEntry.getValue());
        }
        return sortedMap;
    }
}


class MapValueComparator implements Comparator<Map.Entry<String, String>> {

    @Override
    public int compare(Entry<String, String> me1, Entry<String, String> me2) {

        return me1.getValue().compareTo(me2.getValue());
    }
}


class MapNexusValueComparator implements Comparator<Map.Entry<String, RelationNode>> {
    @Override
    public int compare(Entry<String,RelationNode> me1, Entry<String, RelationNode> me2) {
        try {
            Double me1Value;
            Double me2Value;
            // String Nexus1 = "";
            // String Nexus2 = "";
            try {
                // System.out.print(me1.getValue().getNexus().toString());
                // System.out.print((me1.getValue().getNexus().toString()).replace("%",""));
                // System.out.print("dfdf%".replace("%",""));
                String Nexus1 =  me1.getValue().getNexus().toString();
                me1Value = Double.valueOf(Nexus1.replace("％","").replace("%",""));
                // System.out.print(me1Value);
            }catch (Exception e){
                me1Value = 0.0;
            }
            try{
                String Nexus2 = me2.getValue().getNexus().toString();
                me2Value = Double.valueOf(Nexus2.replace("％","").replace("%",""));
                // System.out.print(me2Value);
            }catch (Exception e){
                me2Value = 0.0;
            }
            return - me1Value.compareTo(me2Value);
        }catch (Exception e){
            return 0;
        }
    }
}

