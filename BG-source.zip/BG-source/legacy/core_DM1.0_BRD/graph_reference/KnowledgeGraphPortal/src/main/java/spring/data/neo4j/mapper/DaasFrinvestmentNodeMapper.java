package spring.data.neo4j.mapper;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;
import spring.data.neo4j.domain.DaasFrinvestmentNode;
import spring.data.neo4j.domain.NodeShow;

/**
 * Created by wuchenglong on 2018/1/10.
 */

@Mapper
public interface DaasFrinvestmentNodeMapper {

    DaasFrinvestmentNodeMapper MAPPER = Mappers.getMapper(DaasFrinvestmentNodeMapper.class);

    @Mappings({
            @Mapping(target = "suggestedLabel", constant = "COMPANY"),
            @Mapping(source = "ENTNAME", target = "name"),
    })
    NodeShow QueryResultToNodeShow(DaasFrinvestmentNode daasFrinvestmentNode);

    @InheritInverseConfiguration
    DaasFrinvestmentNode NodeShowToQueryResult(NodeShow nodeShow);


}
