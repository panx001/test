package spring.data.neo4j.mapper;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;
import spring.data.neo4j.domain.DaasShareHolderNode;
import spring.data.neo4j.domain.NodeShow;

/**
 * Created by wuchenglong on 2018/1/10.
 */

@Mapper
public interface DaasPersonShareHolderNodeMapper {

    DaasPersonShareHolderNodeMapper MAPPER = Mappers.getMapper(DaasPersonShareHolderNodeMapper.class);

    @Mappings({
            @Mapping(target = "suggestedLabel", constant = "PERSON"),
            @Mapping(source = "SHANAME", target = "name"),
            @Mapping(source = "LINK_ID", target = "link_id"),
    })
    NodeShow QueryResultToNodeShow(DaasShareHolderNode daasShareHolderNode);

    @InheritInverseConfiguration
    DaasShareHolderNode NodeShowToQueryResult(NodeShow nodeShow);


}
