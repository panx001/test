package spring.data.neo4j.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.collections.list.SetUniqueList;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import spring.data.neo4j.Util.UseFulFunc;

import java.util.*;

/**
 * Created by wuchenglong on 2018/1/9.
 */

public class FindRelationResultReturnCollection {

    private static Logger logger = LogManager.getLogger(FindRelationResultReturnCollection.class);

    @JsonProperty("entityResult")
    private List<FindRelationNodeShow> nodeShowsUniqueList = SetUniqueList.decorate(new ArrayList<FindRelationNodeShow>());
    @JsonProperty("relationResult")
    private List<FindRelationRelationShipShow> relationShipShowUniqueList = SetUniqueList.decorate(new ArrayList<FindRelationRelationShipShow>());

    @JsonIgnore
    public HashMap<String, FindRelationNodeShow> nodeShowHashMap = new HashMap<>();
    @JsonIgnore
    public HashMap<String, FindRelationRelationShipShow> relationShipShowHashMap = new HashMap<>();

    @JsonIgnore
    public HashMap<String,String> keep_path = new HashMap<>();

    public FindRelationResultReturnCollection(){

    }
    public void setKeep_path(HashMap<String,String> keep_path) {
        this.keep_path = keep_path;
    }

    public HashMap<String,String> getKeep_path() {
        return keep_path;
    }


    public void setNodeShowHashMap(HashMap<String, FindRelationNodeShow> nodeShowHashMap) {
        this.nodeShowHashMap = nodeShowHashMap;
    }

    public HashMap<String, FindRelationNodeShow> getNodeShowHashMap() {
        return nodeShowHashMap;
    }

    public HashMap<String, FindRelationRelationShipShow> getRelationShipShowHashMap() {
        return relationShipShowHashMap;
    }

    public void setRelationShipShowHashMap(HashMap<String, FindRelationRelationShipShow> relationShipShowHashMap) {
        this.relationShipShowHashMap = relationShipShowHashMap;
    }


    public void setNodeShowsUniqueList(List<FindRelationNodeShow> nodeShowsUniqueList) {
        this.nodeShowsUniqueList = nodeShowsUniqueList;
    }

    public List<FindRelationNodeShow> getNodeShowsUniqueList() {
        return nodeShowsUniqueList;
    }

    public void setRelationShipShowUniqueList(List<FindRelationRelationShipShow> relationShipShowUniqueList) {
        this.relationShipShowUniqueList = relationShipShowUniqueList;
    }

    public List<FindRelationRelationShipShow> getRelationShipShowUniqueList() {
        return relationShipShowUniqueList;
    }


    public void add(FindRelationNodeShow nodeShow){
        if (!this.nodeShowHashMap.containsKey(nodeShow.getId())){
            this.nodeShowHashMap.put(nodeShow.getId(),nodeShow);
        }else{
            // logger.debug("已经存在 " + nodeShow.getName() + nodeShow.getId());
        }
    }

    public void add(FindRelationRelationShipShow relationShipShow){
        if (!this.keep_path.containsKey(relationShipShow.getPath_id()) && relationShipShow.getPath_type().size()>0) {
            this.keep_path.put(relationShipShow.getPath_id(),relationShipShow.getPath_type().get(0));
        }
        if (!this.relationShipShowHashMap.containsKey(relationShipShow.getId())){
            this.relationShipShowHashMap.put(relationShipShow.getId(),relationShipShow);
        }else{
            if (relationShipShow.getPath_type().size()>0 && this.keep_path.containsValue(relationShipShow.getPath_type().get(0))){
                this.relationShipShowHashMap.get(relationShipShow.getId()).updatePathType(relationShipShow.getPath_type());
            }
            if(relationShipShow.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("WORK","0"))){
                this.relationShipShowHashMap.get(relationShipShow.getId()).updateNexus(relationShipShow.getNexus());
            }
        }
    }

    public void add(ResultReturn resultReturn){
        this.add(resultReturn.getStartFindRelationNodeShow());
        this.add(resultReturn.getEndFindRelationNodeShow());
        this.add(resultReturn.getFindRelationNodeShow());
    }

    @JsonIgnore
    public boolean isEmpty(){
        return this.nodeShowHashMap.isEmpty() && this.relationShipShowHashMap.isEmpty();
    }

    public void updateElemtList(){
        Iterator iterNode = nodeShowHashMap.entrySet().iterator();
        while (iterNode.hasNext()) {
            Map.Entry entry = (Map.Entry) iterNode.next();
            nodeShowsUniqueList.add((FindRelationNodeShow)(entry.getValue()));
        }

        Iterator iterRelation = relationShipShowHashMap.entrySet().iterator();
        while (iterRelation.hasNext()) {
            Map.Entry entry = (Map.Entry) iterRelation.next();
            relationShipShowUniqueList.add((FindRelationRelationShipShow) entry.getValue());
        }
    }

}
