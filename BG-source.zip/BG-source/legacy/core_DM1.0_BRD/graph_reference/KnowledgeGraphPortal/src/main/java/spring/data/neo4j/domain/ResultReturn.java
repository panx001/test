package spring.data.neo4j.domain;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import spring.data.neo4j.Util.UseFulFunc;

import java.util.List;

/**
 * Created by wuchenglong on 2018/1/9.
 */

@SuppressWarnings("unused")
public class ResultReturn {

    private static Logger logger = LogManager.getLogger(ResultReturn.class);

    private NodeShow startNodeShow;
    private FindRelationNodeShow startFindRelationNodeShow;
    private NodeShow endNodeShow;
    private FindRelationNodeShow endFindRelationNodeShow;
    private RelationShipShow relationShipShow;
    private FindRelationRelationShipShow findRelationNodeShow;
    private List<String> pathtype;

    public ResultReturn(){

    }

    public ResultReturn(NodeShow startNodeShow,RelationShipShow relationShipShow,NodeShow endNodeShow){
        this.startNodeShow = startNodeShow;
        // logger.debug(startNodeShow);
        // logger.debug(new org.apache.commons.beanutils.BeanMap(startNodeShow).entrySet());
        this.startNodeShow.infoUpdate();
        this.endNodeShow = endNodeShow;
        this.endNodeShow.infoUpdate();
        this.relationShipShow = relationShipShow;
        this.relationShipShow.setSource_id(this.startNodeShow.getId());
        this.relationShipShow.setTarget_id(this.endNodeShow.getId());
        this.relationShipShow.setType(UseFulFunc.RELATION_TYPE_MAP.getOrDefault(this.relationShipShow.getType(),"0"));
        this.relationShipShow.infoUpdate();
        if (this.relationShipShow.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("INVEST","0"))
                && this.relationShipShow.getNexus()==null && this.relationShipShow.getInvest_num()!=null
                ){
            try {
                Double num1 =Double.parseDouble(this.relationShipShow.getInvest_num());
                Double num2 =Double.parseDouble(this.endNodeShow.getReg_capital());
                Double result = num1/num2;
                // logger.debug(result);
                this.relationShipShow.setNexus(UseFulFunc.floatFormat(result.toString()));
            }catch (Exception e){
                logger.debug(e);
            }
        }
    }

    public ResultReturn(FindRelationNodeShow startNodeShow,FindRelationRelationShipShow relationShipShow,FindRelationNodeShow endNodeShow){
        this.startFindRelationNodeShow = startNodeShow;
        // logger.debug(startNodeShow);
        // logger.debug(new org.apache.commons.beanutils.BeanMap(startNodeShow).entrySet());
        this.startFindRelationNodeShow.infoUpdate();
        this.endFindRelationNodeShow = endNodeShow;
        this.endFindRelationNodeShow.infoUpdate();
        this.findRelationNodeShow = relationShipShow;
        this.findRelationNodeShow.setSource_id(this.startFindRelationNodeShow.getId());
        this.findRelationNodeShow.setTarget_id(this.endFindRelationNodeShow.getId());
        this.findRelationNodeShow.setType(UseFulFunc.RELATION_TYPE_MAP.getOrDefault(this.findRelationNodeShow.getType(),"0"));
        this.findRelationNodeShow.infoUpdate();
        if (this.findRelationNodeShow.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("INVEST","0"))
                && this.findRelationNodeShow.getNexus()==null && this.findRelationNodeShow.getInvest_num()!=null
                ){
            try {
                Double num1 =Double.parseDouble(this.findRelationNodeShow.getInvest_num());
                Double num2 =Double.parseDouble(this.endFindRelationNodeShow.getReg_capital());
                Double result = num1/num2;
                // logger.debug(result);
                this.findRelationNodeShow.setNexus(UseFulFunc.floatFormat(result.toString()));
            }catch (Exception e){
                logger.debug(e);
            }
        }
    }

    public ResultReturn(NodeShow startNodeShow,RelationShipShow relationShipShow,NodeShow endNodeShow,String pathtype){
        this.startNodeShow = startNodeShow;
        // logger.debug(startNodeShow);
        // logger.debug(new org.apache.commons.beanutils.BeanMap(startNodeShow).entrySet());
        this.startNodeShow.infoUpdate();
        this.endNodeShow = endNodeShow;
        this.endNodeShow.infoUpdate();
        this.relationShipShow = relationShipShow;
        this.relationShipShow.setSource_id(this.startNodeShow.getId());
        this.relationShipShow.setTarget_id(this.endNodeShow.getId());
        this.relationShipShow.setType(UseFulFunc.RELATION_TYPE_MAP.getOrDefault(this.relationShipShow.getType(),"0"));
        this.relationShipShow.infoUpdate();
        if (this.relationShipShow.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("INVEST","0"))
                && this.relationShipShow.getNexus()==null && this.relationShipShow.getInvest_num()!=null
                ){
            try {
                Double num1 =Double.parseDouble(this.relationShipShow.getInvest_num());
                Double num2 =Double.parseDouble(this.endNodeShow.getReg_capital());
                Double result = num1/num2;
                this.relationShipShow.setNexus(UseFulFunc.floatFormat(result.toString()));
            }catch (Exception e){
                logger.debug(e);
            }
        }
    }

    public void setStartNodeShow(NodeShow startNodeShow) {
        this.startNodeShow = startNodeShow;
    }

    public NodeShow getStartNodeShow() {
        return startNodeShow;
    }

    public void setEndNodeShow(NodeShow endNodeShow) {
        this.endNodeShow = endNodeShow;
    }

    public NodeShow getEndNodeShow() {
        return endNodeShow;
    }

    public void setRelationShipShow(RelationShipShow relationShipShow) {
        this.relationShipShow = relationShipShow;
    }

    public RelationShipShow getRelationShipShow() {
        return relationShipShow;
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    public FindRelationNodeShow getStartFindRelationNodeShow() {
        return startFindRelationNodeShow;
    }

    public void setStartFindRelationNodeShow(FindRelationNodeShow startFindRelationNodeShow) {
        this.startFindRelationNodeShow = startFindRelationNodeShow;
    }

    public FindRelationNodeShow getEndFindRelationNodeShow() {
        return endFindRelationNodeShow;
    }

    public void setEndFindRelationNodeShow(FindRelationNodeShow endFindRelationNodeShow) {
        this.endFindRelationNodeShow = endFindRelationNodeShow;
    }

    public FindRelationRelationShipShow getFindRelationNodeShow() {
        return findRelationNodeShow;
    }

    public void setFindRelationNodeShow(FindRelationRelationShipShow findRelationNodeShow) {
        this.findRelationNodeShow = findRelationNodeShow;
    }
}
