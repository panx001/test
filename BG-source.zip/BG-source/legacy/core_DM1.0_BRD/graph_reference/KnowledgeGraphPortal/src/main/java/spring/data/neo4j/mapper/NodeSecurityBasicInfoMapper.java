package spring.data.neo4j.mapper;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;
import spring.data.neo4j.domain.NodeQueryBasicInfoResult;
import spring.data.neo4j.domain.NodeShowBasicInfo;

/**
 * Created by wuchenglong on 2018/1/10.
 */

@Mapper
public interface NodeSecurityBasicInfoMapper {
    NodeSecurityBasicInfoMapper MAPPER = Mappers.getMapper(NodeSecurityBasicInfoMapper.class);
    @Mappings({
            @Mapping(target = "suggestedLabel", constant = "SECURITY"),
            @Mapping(source = "SECURITY_NM", target = "name"),
            @Mapping(source = "SECURITY_ID", target = "company_id"),
            @Mapping(source = "LABELS", target = "labels"),
    })
    NodeShowBasicInfo QueryResultToNodeShow(NodeQueryBasicInfoResult nodeQueryResult);

    @InheritInverseConfiguration
    NodeQueryBasicInfoResult NodeShowToQueryResult(NodeShowBasicInfo nodeShow);

}
