package spring.data.neo4j.controller;

/**
 * Created by wuchenglong on 16/10/18.
 */

import net.sf.json.JSONObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import spring.data.neo4j.Util.Base64;
import spring.data.neo4j.Util.String2MD5;
import spring.data.neo4j.repositories.ObjectRepository;

import java.util.*;

@CrossOrigin
@RestController
@RequestMapping(value = "/chart/findThumbnail")
public class FindThumbnail {

    Map<String, String> setTypeMape() {
        //节点的 type （0 公司，1 股东， 2 高管， 3 担保， 4 投资）
        Map typeMap = new HashMap();
        // typeMap.put("gongsi","0");
        typeMap.put("股东", "1");
        typeMap.put("高管", "2");
        typeMap.put("对外担保", "3");
        typeMap.put("对外投资", "4");
        return typeMap;
    }

    Map<String, String> setEnTypeMape() {
        //节点的 type （0 公司，1 股东， 2 高管， 3 担保， 4 投资）
        Map typeMap = new HashMap();
        // typeMap.put("gongsi","0");
        typeMap.put("股东", "gudong");
        typeMap.put("高管", "gaoguan");
        typeMap.put("对外担保", "danbao");
        typeMap.put("对外投资", "touzi");
        return typeMap;
    }

    String UniqueRelation(String relations) {
        String[] aa = relations.split(",");
        List list = Arrays.asList(aa);
        ArrayList<String> newst = new ArrayList<String>(new LinkedHashSet<String>(list));//不改变之前顺序
        // String uniqueRelation = "";
        String uniqueRelation = String.join(",", newst);
        // for (int i = 0; i < newst.size(); i++) {
        //     if (newst.get(i).toString().length() > 0) {
        //         uniqueRelation += "," + newst.get(i).toString();
        //     }
        // }
        return uniqueRelation;
    }

    Map<String, String> typeMap = setTypeMape();
    Map<String, String> enTypeMap = setEnTypeMape();

    @Autowired
    ObjectRepository objectRepository;

    private static Logger logger = LogManager.getLogger(FindThumbnail.class);

    private Map<String, String> countNumOfType(String company_name) throws Exception {
        Map data = new HashMap();
        List<Map<String,Object>> companyIsExist = objectRepository.getByCompanyName(company_name);
        if (companyIsExist.size() == 0) {
            logger.debug("调用中数接口");
            JSONObject chinaDaasInfo =  GetChinaDaasData.downLoadChinaDaasDataByCompanyNm(company_name);
            if (chinaDaasInfo.keySet().contains("gaoguan")) {
                data.put("高管", String.format("(%s)", ((Map)chinaDaasInfo.get("gaoguan")).size()));
            } else {
                data.put("高管", "(0)");
            }
            if (chinaDaasInfo.keySet().contains("touzi")) {
                data.put("对外投资", String.format("(%s)", ((Map)chinaDaasInfo.get("touzi")).size()));
            } else {
                data.put("对外投资", "(0)");
            }
            if (chinaDaasInfo.keySet().contains("gudong")) {
                data.put("股东", String.format("(%s)", ((Map)chinaDaasInfo.get("gudong")).size()));
            } else {
                data.put("股东", "(0)");
            }

        } else {
            logger.debug("调用图数据库");
            List<Map<String, Object>> queryResult;
            queryResult = objectRepository.getGaoguanCount(company_name);
            logger.debug(queryResult);
            if (queryResult.size() > 0) {
                data.put("高管", String.format("(%s)", queryResult.get(0).get("高管")));
            } else {
                data.put("高管", "(0)");
            }
            queryResult = objectRepository.getGudongCount(company_name);
            logger.debug(queryResult);
            if (queryResult.size() > 0) {
                data.put("股东", String.format("(%s)", queryResult.get(0).get("股东")));
            } else {
                data.put("股东", "(0)");
            }
            queryResult = objectRepository.getTouziCount(company_name);
            logger.debug(queryResult);
            if (queryResult.size() > 0) {
                data.put("对外投资", String.format("(%s)", queryResult.get(0).get("对外投资")));
            } else {
                data.put("对外投资", "(0)");
            }
            queryResult = objectRepository.getDanbaoCount(company_name);
            logger.debug(queryResult);
            if (queryResult.size() > 0) {
                data.put("对外担保", String.format("(%s)", queryResult.get(0).get("对外担保")));
            } else {
                data.put("对外担保", "(0)");
            }
        }
        return data;
    }

    @RequestMapping(value = "/thumbnailSearchResult/{company_name}", method = RequestMethod.GET)
    private SearchResult findThumbnailSearchResult(@PathVariable String company_name) throws Exception {

        Map<String, String> countResult = countNumOfType(company_name);
        logger.debug(countResult);
        // Map thumbnail = new HashMap();
        SearchResult result = new SearchResult();
        List<EntityResult> entityResults = new ArrayList<>();
        List<RelationResult> relationResults = new ArrayList<>();

        EntityResult entityResult = new EntityResult();
        entityResult.setType("0");
        entityResult.setId("c" + String2MD5.md5(Base64.encode(company_name)));
        // entityResult.setName(companyRepository.getByCompanyName(company_name).getName());
        entityResult.setName(company_name);
        entityResult.setDescription(company_name);
        entityResults.add(entityResult);
        // result.setEntityResult(entityResults);
        logger.debug("节点存在");

        RelationResult relationResult = new RelationResult();
        for (String countType : typeMap.keySet()) {

            entityResult = new EntityResult();
            entityResult.setType(typeMap.get(countType));
            entityResult.setId(enTypeMap.get(countType));
            entityResult.setName(countType + countResult.getOrDefault(countType, "(0)"));
            entityResult.setFatherNodeType(countType);
            entityResults.add(entityResult);
            // result.setEntityResult(entityResults);

            relationResult = new RelationResult();
            relationResult.setType(typeMap.get(countType));
            relationResult.setTarget(enTypeMap.get(countType));
            relationResult.setSource("c" + String2MD5.md5(Base64.encode(company_name)));
            relationResult.setDirection("1");
            relationResults.add(relationResult);
        }
        result.setRelationResult(relationResults);
        result.setEntityResult(entityResults);

        return result;
    }

    @RequestMapping(value = "/thumbnail/company_name/{company_name}", method = RequestMethod.GET)
    private Map findThumbnailByCompanyName(@PathVariable String company_name) {

        Map mapresult = new HashMap();
        Map nodemap = new HashMap();
        Map edgemap = new HashMap();
        Map result = new HashMap();

        try {
            logger.debug(company_name);
            SearchResult getsearchresult = findThumbnailSearchResult(company_name);

            List<EntityResult> getentityresults = getsearchresult.getEntityResult();
            List<RelationResult> getrelationresults = getsearchresult.getRelationResult();

            for (EntityResult getentityresult : getentityresults) {
                if (!nodemap.containsKey(getentityresult.getId())) {
                    nodemap.put(getentityresult.getId(), getentityresult);
                }
            }

            for (RelationResult getrelationresult : getrelationresults) {

                HashMap relationcolor = new HashMap();
                relationcolor.put("type", getrelationresult.getType());
                relationcolor.put("direction", getrelationresult.getDirection());
                relationcolor.put("relationType", getrelationresult.getRelationType());

                HashMap relationproperty = new HashMap();
                relationproperty.put(getrelationresult.getTarget(), relationcolor);

                if (!edgemap.containsKey(getrelationresult.getSource())) {
                    edgemap.put(getrelationresult.getSource(), relationproperty);
                } else {
                    // HashMap relationproperty2 = new HashMap();
                    HashMap relationproperty2 = (HashMap) edgemap.get(getrelationresult.getSource());
                    if (relationproperty2.containsKey(getrelationresult.getTarget())) {
                        logger.debug("-----yes------");
                        HashMap targetNode = (HashMap) relationproperty2.get(getrelationresult.getTarget());
                        targetNode.put("relationType", UniqueRelation(targetNode.getOrDefault("relationType", "") + "," + getrelationresult.getRelationType()));
                        relationproperty2.put(getrelationresult.getTarget(), targetNode);
                        edgemap.put(getrelationresult.getSource(), relationproperty2);
                    } else {
                        logger.debug("-----no------");
                        relationproperty2.put(getrelationresult.getTarget(), relationcolor);
                        edgemap.put(getrelationresult.getSource(), relationproperty2);
                    }
                }
            }
            if (edgemap.size() > 0) {
                mapresult.put("edges", edgemap);
            }
            if (nodemap.size() > 0) {
                mapresult.put("nodes", nodemap);
            }
            result.put("NodeEdgesCount", mapresult);

            return result;
        } catch (Exception e) {
            logger.debug(e);
            return result;
        }
    }

    @RequestMapping(value = "/thumbnail/company_id/{company_id}", method = RequestMethod.GET)
    private Map findThumbnailByCompanyNameEncodeId(@PathVariable String company_id) {
        return findThumbnailByCompanyName(spring.data.neo4j.Util.Base64.decode(company_id).replace("（","(").replace("）",")"));
    }

}

class SearchResult {
    private List<EntityResult> entityResult = new ArrayList<EntityResult>();
    private List<RelationResult> relationResult = new ArrayList<RelationResult>();


    public SearchResult(){}
    public SearchResult(List<EntityResult> entityResult , List<RelationResult> relationResult )
    {
        this.entityResult = entityResult;
        this.relationResult = relationResult;
    }

    public List<EntityResult> getEntityResult() {
        return entityResult;
    }
    public void setEntityResult(List<EntityResult> entityResult) {
        this.entityResult = entityResult;
    }
    public List<RelationResult> getRelationResult() {
        return relationResult;
    }
    public void setRelationResult(List<RelationResult> relationResult) {
        this.relationResult = relationResult;
    }


    public SearchResult adds(SearchResult partSearchResult)
    {
        this.entityResult.addAll(partSearchResult.getEntityResult());
        this.relationResult.addAll(partSearchResult.getRelationResult());
        return this;
    }

}


class EntityResult {

    //PERSON,COMPANY,Worker,Shareholder
    private String type;
    //    节点的颜色
    private String name;
    private String id;
    private String description;
    private String fatherNodeType;
//    节点是在 担保 ， 高管哪种type下

    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    public String getFatherNodeType() {
        return fatherNodeType;
    }
    public void setFatherNodeType(String fatherNodeType) {
        this.fatherNodeType = fatherNodeType;
    }

    @Override
    public boolean equals(Object obj) {
        EntityResult entityResult = (EntityResult) obj;
        if(entityResult.getId().equals(this.id)) {
            return true;
        }
        return false;
    }

    @Override
    public int hashCode() {
        // TODO Auto-generated method stub
        // return (this.Source + this.Target).hashCode();
        return 123;
    }
}

class RelationResult {

    //PERSON,COMPANY,Worker,Shareholder
    private String type;
    //    边的颜色 属性
    private String Source;
    private String Target;
    private String direction;
    private String data;
    private String relationType;
    private String shaRatio;
//    边是  高管，担保 等哪种类型

    // @Override
    // public boolean equals(Object o)

    public Map<String, Object> toJson() {
        Map<String, Object> result = new HashMap<String,Object>(2);
        result.put("Source",this.Source);
        result.put("Target",this.Target);
        result.put("direction",this.direction);
        result.put("relationType",this.relationType);
        result.put("type",this.type);
        return result;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSource() {
        return Source;
    }

    public void setSource(String source) {
        Source = source;
    }

    public String getTarget() {
        return Target;
    }

    public void setTarget(String target) {
        Target = target;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getRelationType() {
        return relationType;
    }

    public void setRelationType(String relationType) {
        this.relationType = relationType;
    }

    public String getShaRatio() {
        return shaRatio;
    }

    public void setShaRatio(String shaRatio) {
        this.shaRatio = shaRatio;
    }


    @Override
    public boolean equals(Object obj) {
        RelationResult relationResult = (RelationResult) obj;
        // System.out.print(obj);
        if ((relationResult.getRelationType().contains("亲属关系")||relationResult.getRelationType().contains("亲戚关系")) && (this.relationType.contains("亲属关系")||this.relationType.contains("亲戚关系"))){
            System.out.println("亲属关系");
            if(relationResult.getTarget().equals(this.Target)&&relationResult.getSource().equals(this.Source)){
                return true;
            }
            if(relationResult.getTarget().equals(this.Source)&&relationResult.getSource().equals(this.Target)){
                return true;
            }
        }
        if (relationResult.getTarget().equals(this.Target)&&relationResult.getSource().equals(this.Source)&&relationResult.getRelationType().equals(this.relationType)){
            return true;
        }
        return false;
    }

    @Override
    public int hashCode() {
        // TODO Auto-generated method stub
        // return (this.Source + this.Target).hashCode();
        return 123;

    }


}

