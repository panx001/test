package spring.data.neo4j.mapper;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;
import spring.data.neo4j.domain.FindRelationNodeShow;
import spring.data.neo4j.domain.NodeQueryResult;
import spring.data.neo4j.domain.NodeShow;

/**
 * Created by wuchenglong on 2018/1/8.
 */

@SuppressWarnings("unused")
@Mapper
public interface NodeSecurityMapper {

    NodeSecurityMapper MAPPER = Mappers.getMapper(NodeSecurityMapper.class);

    @Mappings({
            @Mapping(target = "suggestedLabel", constant = "SECURITY"),
            @Mapping(source = "SECURITY_NM", target = "name"),
            @Mapping(source = "SECURITY_ID", target = "company_id"),
            @Mapping(target = "risk_list", ignore = true),
            @Mapping(source = "LABELS", target = "labels")
    })
    NodeShow QueryResultToNodeShow(NodeQueryResult nodeQueryResult);

    @Mappings({
            @Mapping(target = "suggestedLabel", constant = "SECURITY"),
            @Mapping(source = "SECURITY_NM", target = "name"),
            @Mapping(source = "SECURITY_ID", target = "company_id"),
            @Mapping(target = "risk_list", ignore = true),
            @Mapping(source = "LABELS", target = "labels")
    })
    FindRelationNodeShow QueryResultToFindRelationNodeShow(NodeQueryResult nodeQueryResult);

    @InheritInverseConfiguration
    NodeQueryResult NodeShowToQueryResult(NodeShow nodeShow);
    @InheritInverseConfiguration
    NodeQueryResult FindRelationNodeShowToQueryResult(FindRelationNodeShow nodeShow);

}
