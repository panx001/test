package spring.data.neo4j.controller;

/**
 * Created by wuchenglong on 2018/1/3.
 */

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.neo4j.ogm.response.model.QueryResultModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import spring.data.neo4j.Util.Base64;
import spring.data.neo4j.Util.ConnectionToPortal;
import spring.data.neo4j.Util.UseFulFunc;
import spring.data.neo4j.domain.FindRelationResultReturnCollection;
import spring.data.neo4j.domain.NodeShowBasicInfo;
import spring.data.neo4j.domain.ResultReturn;
import spring.data.neo4j.domain.ResultReturnCollection;
import spring.data.neo4j.mapper.QueryResultMapper;
import spring.data.neo4j.repositories.ObjectRepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
// import org.springframework.data.neo4j.repository.support.Neo4jTemplate;

@CrossOrigin
@RestController
@RequestMapping(value = "/chart/FindRelation")
public class GetRelation {

    private static Logger logger = LogManager.getLogger(GetRelation.class);

    @Autowired
    ObjectRepository objectRepository;


    void addQueryresult(FindRelationResultReturnCollection resultReturnCollection,QueryResultModel searchresult)
    {
        for (Map<String, Object> result:searchresult) {
            try {
//                for(Map<String, Object> result:((LinkedHashMap[])results.get("PATH_INFO")))
//                {
                    ResultReturn resultReturn = new ResultReturn(
                            QueryResultMapper.MapFindRelationNodeShowMapper((Map<String, Object>)result.get("sourceNodeInfo")),
                            QueryResultMapper.MapFindRelationRelationShipShowwMapper((Map<String, Object>)result.get("relationInfo")),
                            QueryResultMapper.MapFindRelationNodeShowMapper((Map<String, Object>)result.get("targetNodeInfo")));
                    resultReturnCollection.add(resultReturn);
//                }
            }
            catch (Exception e)
            {
                logger.debug(e);
            }
        }
    }
    @RequestMapping(value = "/GetAllNodesAndRels", method = RequestMethod.GET)
    private FindRelationResultReturnCollection FindRelationOfMultiNodes(@RequestParam(defaultValue = "1") String IdPara) {
        FindRelationResultReturnCollection resultReturnCollection = new FindRelationResultReturnCollection();
        logger.debug("===IdPara==="+IdPara);
        String[] IdInfoes = IdPara.split(",");
        List<String> list = Arrays.asList(IdInfoes);

        for (int i = 0; i < list.size(); i++) {
            for (int j = i; j < list.size(); j++) {
                if (!list.get(i).equals(list.get(j))) {
                    String label1 = list.get(i).substring(0, 1).trim();
                    String para1 = list.get(i).substring(1);
                    String label2 = list.get(j).substring(0, 1).trim();
                    String para2 = list.get(j).substring(1);
                    logger.debug(label1);
                    logger.debug(label2);
                    logger.debug(para1);
                    logger.debug(para2);
                    logger.debug("------------");
                    String layernum = "3";
                    if (label1.equals("C") & label2.equals("C")) {
                        if (UseFulFunc.isNumeric(para1) & !UseFulFunc.isNumeric(para2)){
                            QueryResultModel searchresult =objectRepository.getCompanyWithCompanyPathByNameId(para1, Base64.decode(para2));
                            if (Iteratorsize(searchresult.iterator()) == 0){
                                layernum = "7";
                                searchresult =objectRepository.getCompanyWithCompanyShortestPathByNameId(para1, Base64.decode(para2));
                            }
                            addQueryresult(resultReturnCollection,searchresult);
//                            QueryResultModel searchresultwithsuspect  = layernum.equals("7")?objectRepository.getSuspectrelationCompanyWithCompanyShortestPathByNameId(para1, Base64.decode(para2),layernum):objectRepository.getThreeLayerSuspectrelationCompanyWithCompanyShortestPathByNameId(para1, Base64.decode(para2),layernum);
//                            addQueryresult(resultReturnCollection,searchresultwithsuspect);
                        }
                        if (!UseFulFunc.isNumeric(para1) & !UseFulFunc.isNumeric(para2)){
                            QueryResultModel searchresult = objectRepository.getCompanyWithCompanyPathByName(Base64.decode(para1), Base64.decode(para2));
                            if (Iteratorsize(searchresult.iterator()) == 0){
                                layernum = "7";
                                searchresult =objectRepository.getCompanyWithCompanyShortestPathByName(Base64.decode(para1), Base64.decode(para2));
                            }
                            addQueryresult(resultReturnCollection,searchresult);
//                            QueryResultModel searchresultwithsuspect  = layernum.equals("7")?objectRepository.getSuspectrelationCompanyWithCompanyShortestPathByName(Base64.decode(para1), Base64.decode(para2),layernum):objectRepository.getThreeLayerSuspectrelationCompanyWithCompanyShortestPathByName(Base64.decode(para1), Base64.decode(para2),layernum);
//                            addQueryresult(resultReturnCollection,searchresultwithsuspect);
                        }
                        if (!UseFulFunc.isNumeric(para1) & UseFulFunc.isNumeric(para2)){
                            QueryResultModel searchresult =objectRepository.getCompanyWithCompanyPathByNameId(para2,Base64.decode(para1));
                            if (Iteratorsize(searchresult.iterator()) == 0){
                                layernum = "7";
                                searchresult =objectRepository.getCompanyWithCompanyShortestPathByNameId(para2,Base64.decode(para1));
                            }
                            addQueryresult(resultReturnCollection,searchresult);
//                            QueryResultModel searchresultwithsuspect  = layernum.equals("7")?objectRepository.getSuspectrelationCompanyWithCompanyShortestPathByNameId(para2,Base64.decode(para1),layernum):objectRepository.getThreeLayerSuspectrelationCompanyWithCompanyShortestPathByNameId(para2,Base64.decode(para1),layernum);
//                            addQueryresult(resultReturnCollection,searchresultwithsuspect);
                        }else{
                            QueryResultModel searchresult =objectRepository.getCompanyWithCompanyPathId(para1, para2);
                            if (Iteratorsize(searchresult.iterator()) == 0){
                                layernum = "7";
                                searchresult =objectRepository.getCompanyWithCompanyShortestPathId(para1, para2);
                            }
                            addQueryresult(resultReturnCollection,searchresult);
//                            QueryResultModel searchresultwithsuspect  = layernum.equals("7")?objectRepository.getSuspectrelationCompanyWithCompanyShortestPathId(para1, para2,layernum): objectRepository.getThreeLayerSuspectrelationCompanyWithCompanyShortestPathId(para1, para2,layernum);
//                            addQueryresult(resultReturnCollection,searchresultwithsuspect);
                        }
                    }
                    if (label1.equals("C") & label2.equals("P")) {
                        logger.debug("----2----");
                        if (!UseFulFunc.isNumeric(para1)){
                            QueryResultModel searchresult =objectRepository.getCompanyWithPersonPathByNameId(Base64.decode(para1), para2);
                            if (Iteratorsize(searchresult.iterator()) == 0){
                                layernum = "7";
                                searchresult =objectRepository.getCompanyWithPersonShortestPathByNameId(Base64.decode(para1), para2);
                            }
                            addQueryresult(resultReturnCollection,searchresult);
//                            QueryResultModel searchresultwithsuspect  = layernum.equals("7")?objectRepository.getSuspectrelationCompanyWithPersonShortestPathByNameId(Base64.decode(para1), para2,layernum):objectRepository.getThreeLayerSuspectrelationCompanyWithPersonShortestPathByNameId(Base64.decode(para1), para2,layernum);
//                            addQueryresult(resultReturnCollection,searchresultwithsuspect);
                        }else{
                            QueryResultModel searchresult =objectRepository.getCompanyWithPersonPathId(para1, para2);
                            if (Iteratorsize(searchresult.iterator()) == 0){
                                layernum = "7";
                                searchresult =objectRepository.getCompanyWithPersonShortestPathId(para1, para2);
                            }
                            addQueryresult(resultReturnCollection,searchresult);
//                            QueryResultModel searchresultwithsuspect  = layernum.equals("7")?objectRepository.getSuspectrelationCompanyWithPersonShortestPathId(para1, para2,layernum):objectRepository.getThreeLayerSuspectrelationCompanyWithPersonShortestPathId(para1, para2,layernum);
//                            addQueryresult(resultReturnCollection,searchresultwithsuspect);
                        }
                    }
                    if (label1.equals("P") & label2.equals("C")) {
                        logger.debug("----3----");
                        if (!UseFulFunc.isNumeric(para2)){
                            QueryResultModel searchresult =objectRepository.getCompanyWithPersonPathByNameId(Base64.decode(para2), para1);
                            if (Iteratorsize(searchresult.iterator()) == 0){
                                layernum = "7";
                                searchresult =objectRepository.getCompanyWithPersonShortestPathByNameId(Base64.decode(para2), para1);
                            }
                            addQueryresult(resultReturnCollection,searchresult);
//                            QueryResultModel searchresultwithsuspect  = layernum.equals("7")?objectRepository.getSuspectrelationCompanyWithPersonShortestPathByNameId(Base64.decode(para2), para1,layernum):objectRepository.getThreeLayerSuspectrelationCompanyWithPersonShortestPathByNameId(Base64.decode(para2), para1,layernum);
//                            addQueryresult(resultReturnCollection,searchresultwithsuspect);
                        }else{
                            QueryResultModel searchresult =objectRepository.getCompanyWithPersonPathId(para2, para1);
                            if (Iteratorsize(searchresult.iterator()) == 0){
                                layernum = "7";
                                searchresult =objectRepository.getCompanyWithPersonShortestPathId(para2, para1);
                            }
                            addQueryresult(resultReturnCollection,searchresult);
//                            QueryResultModel searchresultwithsuspect  = layernum.equals("7")?objectRepository.getSuspectrelationCompanyWithPersonShortestPathId(para2, para1,layernum):objectRepository.getThreeLayerSuspectrelationCompanyWithPersonShortestPathId(para2, para1,layernum);
//                            addQueryresult(resultReturnCollection,searchresultwithsuspect);
                        }
                    }
                    if (label1.equals("P") & label2.equals("P")) {
                        logger.debug("----4----");
                        QueryResultModel searchresult =objectRepository.getPeronWithPersonPathId(para1, para2);
                        if (Iteratorsize(searchresult.iterator()) == 0){
                            layernum = "7";
                            searchresult =objectRepository.getPeronWithPersonShortestPathId(para1, para2);
                        }
                        addQueryresult(resultReturnCollection,searchresult);
//                        QueryResultModel searchresultwithsuspect  = layernum.equals("7")?objectRepository.getSuspectrelationPeronWithPersonShortestPathId(para1, para2,layernum):objectRepository.getThreeLayerSuspectrelationPeronWithPersonShortestPathId(para1, para2,layernum);
//                        addQueryresult(resultReturnCollection,searchresultwithsuspect);
                    }
                }
            }
        }
        logger.debug(resultReturnCollection.getNodeShowHashMap().size());
        logger.debug(resultReturnCollection.getRelationShipShowHashMap().size());
        resultReturnCollection.updateElemtList();
        logger.debug(resultReturnCollection.getNodeShowsUniqueList().size());
        logger.debug(resultReturnCollection.getRelationShipShowUniqueList().size());
        return resultReturnCollection;
    }



    private List<String> getAllRelsIds(String IdPara) {
        logger.debug("===IdPara==="+IdPara);
        String[] IdInfoes = IdPara.split(",");
        List<String> list = Arrays.asList(IdInfoes);
        return list;
    }

    private Integer Iteratorsize(Iterator inte)
    {
        int i = 0;
        for ( ; inte.hasNext() ; ++i ) inte.next();
        return i;
    }

}
