package spring.data.neo4j.mapper;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;
import spring.data.neo4j.domain.FindRelationRelationShipShow;
import spring.data.neo4j.domain.RelationQueryResult;
import spring.data.neo4j.domain.RelationShipShow;

/**
 * Created by wuchenglong on 2018/1/9.
 */


@SuppressWarnings("unused")
@Mapper
public interface RelationMapper {

    RelationMapper MAPPER = Mappers.getMapper(RelationMapper.class);

    @Mappings({
            @Mapping(target = "id", ignore = true ),
            @Mapping(source = "INVEST_SHA_RATIO", target = "invest_sha_ratio"),
            @Mapping(source = "TYPE", target = "type"),
            @Mapping(source = "PATH_TYPE", target = "path_type"),
            @Mapping(source = "INVEST_NUM", target = "invest_num"),
            @Mapping(source = "WORK_POSITION", target = "work_position"),
            @Mapping(source = "SC_RELATION_TYPE", target = "sc_relation_type"),
            @Mapping(source = "PATH_ID", target = "path_id"),
            @Mapping(source = "GUAR_INFO", target = "guar_info")
    })
    RelationShipShow QueryMapToRelationShipShow(RelationQueryResult relationQueryResult);

    @Mappings({
            @Mapping(target = "id", ignore = true ),
            @Mapping(source = "INVEST_SHA_RATIO", target = "invest_sha_ratio"),
            @Mapping(source = "TYPE", target = "type"),
            @Mapping(source = "PATH_TYPE", target = "path_type"),
            @Mapping(source = "INVEST_NUM", target = "invest_num"),
            @Mapping(source = "WORK_POSITION", target = "work_position"),
            @Mapping(source = "SC_RELATION_TYPE", target = "sc_relation_type"),
            @Mapping(source = "PATH_ID", target = "path_id"),
            @Mapping(source = "GUAR_INFO", target = "guar_info")
    })
    FindRelationRelationShipShow QueryMapToFindRelationRelationShipShow(RelationQueryResult relationQueryResult);

    @InheritInverseConfiguration
    RelationQueryResult RelationShipShowToQuery(RelationShipShow relationShipShow);
    @InheritInverseConfiguration
    RelationQueryResult FindRelationRelationShipShowToQuery(FindRelationRelationShipShow relationShipShow);

}
