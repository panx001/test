package spring.data.neo4j.domain;

import java.util.ArrayList;

/**
 * Created by wuchenglong on 2018/1/8.
 */


@SuppressWarnings("unused")
public class NodeQueryResult {

    private ArrayList<String> LABELS;
    private String COMPANY_ID;
    private String COMPANY_NM;
    private ArrayList<String> COMPANY_TYPE;
    private String PERSON_ID;
    private String PERSON_NM;
    private String LINK_ID;
    private String SECURITY_NM;
    private String SECURITY_ID;
    private String REG_CAPITAL;
    private ArrayList<Object> RISK_LIST;  // 风险标签

    public NodeQueryResult(){

    }

    public void setCOMPANY_TYPE(ArrayList<String> COMPANY_TYPE) {
        this.COMPANY_TYPE = COMPANY_TYPE;
    }

    public ArrayList<String> getCOMPANY_TYPE() {
        return COMPANY_TYPE;
    }

    public void setLABELS(ArrayList<String> LABELS) {
        this.LABELS = LABELS;
    }

    public ArrayList<String> getLABELS() {
        return LABELS;
    }

    public void setCOMPANY_ID(String COMPANY_ID) {
        this.COMPANY_ID = COMPANY_ID;
    }

    public String getCOMPANY_ID() {
        return COMPANY_ID;
    }

    public void setCOMPANY_NM(String COMPANY_NM) {
        this.COMPANY_NM = COMPANY_NM;
    }

    public String getCOMPANY_NM() {
        return COMPANY_NM;
    }

    public void setPERSON_ID(String PERSON_ID) {
        this.PERSON_ID = PERSON_ID;
    }

    public String getPERSON_ID() {
        return PERSON_ID;
    }

    public void setPERSON_NM(String PERSON_NM) {
        this.PERSON_NM = PERSON_NM;
    }

    public String getPERSON_NM() {
        return PERSON_NM;
    }

    public void setREG_CAPITAL(String REG_CAPITAL) {
        this.REG_CAPITAL = REG_CAPITAL;
    }

    public String getREG_CAPITAL() {
        return REG_CAPITAL;
    }

    public void setRISK_LIST(ArrayList<Object> RISK_LIST) {
        this.RISK_LIST = RISK_LIST;
    }

    public ArrayList<Object> getRISK_LIST() {
        return RISK_LIST;
    }

    public String getSECURITY_NM() {
        return SECURITY_NM;
    }

    public void setSECURITY_NM(String SECURITY_NM) {
        this.SECURITY_NM = SECURITY_NM;
    }

    public String getSECURITY_ID() {
        return SECURITY_ID;
    }

    public void setSECURITY_ID(String SECURITY_ID) {
        this.SECURITY_ID = SECURITY_ID;
    }

    public String getLINK_ID() {
        return LINK_ID;
    }

    public void setLINK_ID(String LINK_ID) {
        this.LINK_ID = LINK_ID;
    }
}
