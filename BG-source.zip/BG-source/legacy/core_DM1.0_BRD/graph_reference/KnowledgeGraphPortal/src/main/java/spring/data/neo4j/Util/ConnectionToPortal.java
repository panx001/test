package spring.data.neo4j.Util;

import org.apache.commons.lang.text.StrSubstitutor;

import java.sql.Connection;
// import java.sql.DriverManager;
// import java.sql.SQLException;
import java.util.HashMap;

/**
 * Created by wuchenglong on 2018/1/8.
 */

public class ConnectionToPortal {
    public ConnectionToPortal(){}
    public Connection connectionToPortal() {
        Database database = new Database();
        database.setJdbcUrl("jdbc:oracle:thin:@10.100.47.14:1521:orclp");
        database.setUsername("cs_portal");
        database.setPassword("RGDU2Csp");
        database.setJdbcDriverClassName("oracle.jdbc.driver.OracleDriver");
        Connection conn = database.openConnection();
        try {
            return conn;
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public String getBasicInfoQueryByCompanyId(String company_id) {
        HashMap<String, String> paraHashMap = new HashMap<>();
        paraHashMap.put("company_id",company_id);
        StrSubstitutor sub = new StrSubstitutor(paraHashMap, "{", "}");
        String query = "SELECT A.COMPANY_NM COMPANY_NM ,A.LEG_REPRESENT LEG_REPRESENT,TO_CHAR(A.FOUND_DT,'YYYY-MM-DD HH:MM:SS' ) AS FOUND_DT,A.REG_CAPITAL AS REG_CAPITAL,A.REG_ADDR AS REG_ADDR,B.RATING AS RATING FROM CS_PORTAL.COMPY_BASICINFO A\n" +
                "LEFT JOIN  (SELECT * FROM(\n" +
                "SELECT COMPANY_ID, RATING, RATING_DT FROM CS_PORTAL.COMPY_CREDITRATING WHERE COMPANY_ID = {company_id} AND ISDEL = 0 ORDER BY RATING_DT DESC)\n" +
                "WHERE ROWNUM = 1) B\n" +
                "ON A.COMPANY_ID = B.COMPANY_ID\n" +
                "WHERE A.COMPANY_ID = {company_id} ";
        return  sub.replace(query);
    }

    public String getBasicInfoQueryByCompanyNm(String company_nm) {
        HashMap<String, String> paraHashMap = new HashMap<>();
        paraHashMap.put("company_nm",company_nm);
        StrSubstitutor sub = new StrSubstitutor(paraHashMap, "{", "}");
        String query = "SELECT A.COMPANY_NM COMPANY_NM ,A.LEG_REPRESENT,TO_CHAR(A.FOUND_DT,'YYYY-MM-DD HH:MM:SS' ) AS FOUND_DT,A.REG_CAPITAL AS REG_CAPITAL,A.REG_ADDR AS REG_ADDR,B.RATING AS RATING FROM CS_PORTAL.COMPY_BASICINFO A\n" +
                "LEFT JOIN  (SELECT * FROM(\n" +
                "SELECT X.COMPANY_ID, X.RATING, X.RATING_DT FROM CS_PORTAL.COMPY_CREDITRATING X INNER JOIN CS_PORTAL.COMPY_BASICINFO Z ON X.COMPANY_ID = Z.COMPANY_ID WHERE Z.COMPANY_NM = '{companynm}' AND ISDEL = 0 ORDER BY RATING_DT DESC)\n" +
                "WHERE ROWNUM = 1) B\n" +
                "ON A.COMPANY_ID = B.COMPANY_ID\n" +
                "WHERE A.COMPANY_NM = '{company_nm}' ";
        return sub.replace(query);
    }
}
