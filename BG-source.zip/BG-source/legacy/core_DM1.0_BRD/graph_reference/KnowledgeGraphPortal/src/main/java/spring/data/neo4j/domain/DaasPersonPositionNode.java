package spring.data.neo4j.domain;

/**
 * Created by wuchenglong on 2018/1/10.
 */

@SuppressWarnings("unused")
public class DaasPersonPositionNode {
    private String ENTSTATUS;  // 企业状态
    private String POSITION; //
    private String ENTNAME;   // 任职企业名称
    private String LINK_ID;

    public DaasPersonPositionNode(){}

    public void setENTNAME(String ENTNAME) {
        this.ENTNAME = ENTNAME;
    }

    public String getENTNAME() {
        return ENTNAME;
    }

    public void setENTSTATUS(String ENTSTATUS) {
        this.ENTSTATUS = ENTSTATUS;
    }

    public String getENTSTATUS() {
        return ENTSTATUS;
    }

    public String getPOSITION() {
        return POSITION;
    }

    public void setPOSITION(String POSITION) {
        this.POSITION = POSITION;
    }

    public String getLINK_ID() {
        return LINK_ID;
    }

    public void setLINK_ID(String LINK_ID) {
        this.LINK_ID = LINK_ID;
    }
}

