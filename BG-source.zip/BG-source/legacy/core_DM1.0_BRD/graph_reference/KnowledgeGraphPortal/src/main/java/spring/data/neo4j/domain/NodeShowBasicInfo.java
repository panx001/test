package spring.data.neo4j.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import spring.data.neo4j.Util.Base64;
import spring.data.neo4j.Util.String2MD5;
import spring.data.neo4j.Util.UseFulFunc;

import java.util.ArrayList;
import java.util.stream.Collectors;

/**
 * Created by wuchenglong on 2018/1/10.
 */

@SuppressWarnings("unused")
public class NodeShowBasicInfo {
    private static Logger logger = LogManager.getLogger(NodeShowBasicInfo.class);
    private String id;
    @JsonProperty("label")
    private String suggestedLabel;
    private ArrayList<String> labels = new ArrayList<>();
    private String name;
    private String company_id;
    private Object company_type_list;
    private String company_type;
    private String link_id;
    private String leg_present;
    private String reg_capital;
    private String found_dt;
    private String reg_addr;
    private String security_code;

    public NodeShowBasicInfo(){
    }

    public void infoUpdate(){
        this.id = String2MD5.md5(this.name == null ?"":this.name);
        this.suggestedLabel = UseFulFunc.NODE_LABEL_MAP.getOrDefault(this.suggestedLabel,"None");
        this.link_id = (this.company_id != null) ? this.company_id : Base64.encode(this.name) ;//&& this.company_type.equals("1")
        //stream.collect(Collectors.toCollection(ArrayList::new));
        if (this.labels!=null&&!this.labels.isEmpty()){
            this.labels = this.labels.stream().map(x -> UseFulFunc.NODE_LABEL_MAP.getOrDefault(x,"None")).collect(Collectors.toCollection(ArrayList::new));
        }else {
            this.labels.add(getSuggestedLabel());
        }
    }

    public void setCompany_type(String company_type) {
        this.company_type = company_type;
    }

    public String getCompany_type() {
        return company_type;
    }

    public void setCompany_type_list(Object company_type_list) {
        this.company_type_list = company_type_list;
    }

    public Object getCompany_type_list() {
        return company_type_list;
    }

    public void setCompany_id(String company_id) {
        this.company_id = company_id;
    }

    public String getCompany_id() {
        return company_id;
    }


    public void setLink_id(String link_id) {
        this.link_id = link_id;
    }

    public String getLink_id() {
        return link_id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setSuggestedLabel(String suggestedLabel) {
        this.suggestedLabel = suggestedLabel;
    }

    public String getSuggestedLabel() {
        return suggestedLabel;
    }

    public void setLabels(ArrayList<String> labels) {
        this.labels = labels;
    }

    public ArrayList<String> getLabels() {
        return labels;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setReg_capital(String reg_capital) {
        this.reg_capital = reg_capital;
    }

    public String getReg_capital() {
        return reg_capital;
    }

    public void setFound_dt(String found_dt) {
        this.found_dt = found_dt;
    }

    public String getFound_dt() {
        return found_dt;
    }

    public void setSecurity_code(String security_code) {
        this.security_code = security_code;
    }

    public String getSecurity_code() {
        return security_code;
    }

    public void setReg_addr(String reg_addr) {
        this.reg_addr = reg_addr;
    }

    public String getReg_addr() {
        return reg_addr;
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof NodeShow)){
            return false;
        }
        NodeShow nodeShow = (NodeShow) obj;
        return nodeShow.getName().equals(this.name);
    }

    @Override
    public int hashCode() {
        return 123;
    }


    public String getLeg_present() {
        return leg_present;
    }

    public void setLeg_present(String leg_present) {
        this.leg_present = leg_present;
    }
}
