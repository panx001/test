package spring.data.neo4j.domain;

/**
 * Created by wuchenglong on 2018/1/10.
 */

@SuppressWarnings("unused")
public class DaasMainPersonNode {

    private String PERNAME;  // 高管名称
    private String POSITION;  //职位
    private String SEX;  //性别
    private String LINK_ID;  //用于名称匹配的id

    public DaasMainPersonNode(){}

    public void setPERNAME(String PERNAME) {
        this.PERNAME = PERNAME;
    }

    public String getPERNAME() {
        return PERNAME;
    }

    public void setSEX(String SEX) {
        this.SEX = SEX;
    }

    public String getSEX() {
        return SEX;
    }

    public void setPOSITION(String POSITION) {
        this.POSITION = POSITION;
    }

    public String getPOSITION() {
        return POSITION;
    }

    public String getLINK_ID() {
        return LINK_ID;
    }

    public void setLINK_ID(String LINK_ID) {
        this.LINK_ID = LINK_ID;
    }
}
