package spring.data.neo4j.mapper;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;
import spring.data.neo4j.domain.NodeQueryBasicInfoResult;
import spring.data.neo4j.domain.NodeShowBasicInfo;

/**
 * Created by wuchenglong on 2018/1/10.
 */

@Mapper
public interface NodePersonBasicInfoMapper {
    NodePersonBasicInfoMapper MAPPER = Mappers.getMapper(NodePersonBasicInfoMapper.class);
    @Mappings({
            @Mapping(target = "suggestedLabel", constant = "PERSON"),
            @Mapping(source = "PERSON_NM", target = "name"),
            @Mapping(source = "PERSON_ID", target = "company_id"),
            @Mapping(source = "LABELS", target = "labels"),
    })
    NodeShowBasicInfo QueryResultToNodeShow(NodeQueryBasicInfoResult nodeQueryResult);

    @InheritInverseConfiguration
    NodeQueryBasicInfoResult NodeShowToQueryResult(NodeShowBasicInfo nodeShow);

}
