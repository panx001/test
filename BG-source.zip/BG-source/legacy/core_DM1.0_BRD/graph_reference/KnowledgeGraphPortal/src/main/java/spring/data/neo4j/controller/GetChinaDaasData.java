package spring.data.neo4j.controller;


import spring.data.neo4j.Util.Map2Obj;
import spring.data.neo4j.domain.*;
import spring.data.neo4j.mapper.QueryResultMapper;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.util.*;

/**
 * Created by wuchenglong on 2018/1/10.
 */

@SuppressWarnings({"unused","unchecked"})
@CrossOrigin
@RestController
@RequestMapping(value = "/chart/daasData")
public class GetChinaDaasData {

    private static Logger logger = LogManager.getLogger(GetChinaDaasData.class);
    private static String BASE_URL = "http://10.100.46.15:7070";// PROD

    // public static String TEST_BASE_URL = "http://10.100.44.17:7070"; // UAT
    public static String PROD_BASE_URL = "http://10.100.46.15:7070";
    // public static String TOKEN_URL =  TEST_BASE_URL + "/oauth/token";
    // public static String TOKEN_URL = "http://139.196.212.16:7070/oauth/token";
    // public static String TEST_BASE_URL = "http://139.196.212.16:7070";

    private static CloseableHttpClient httpclient = HttpClients.createDefault();

    private String access_token;
    public String getAccess_token(){
        return access_token;
    }

    public GetChinaDaasData(){
    }

    private final String USER_AGENT = "Mozilla/5.0";

    public static void Test() throws Exception {
        GetChinaDaasData http = new GetChinaDaasData();
        downLoadChinaDaasDataByCompanyNmPersonNm("海东市嘉美餐饮服务有限公司", "席维成");
    }

    private static JSONObject downLoadDataByUrl(String url)  throws Exception {
        HttpGet httpGet = new HttpGet(url);
        CloseableHttpResponse response = httpclient.execute(httpGet);
        BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
        StringBuilder result = new StringBuilder();
        String line ;
        while ((line = rd.readLine()) != null) {
            result.append(line);
        }
        return JSONObject.fromObject(result.toString());
    }

    @RequestMapping(value = "/company", method = RequestMethod.GET)
    public static JSONObject downLoadChinaDaasDataByCompanyNm(@RequestParam String companyNm)  throws Exception {
        String url = String.format(BASE_URL + "/enterprise/info/%s", URLEncoder.encode(companyNm, "UTF-8"));
        return  downLoadDataByUrl(url);
    }

    @RequestMapping(value = "/person", method = RequestMethod.GET)
    public static JSONObject downLoadChinaDaasDataByCompanyNmPersonNm(@RequestParam String companyNm,@RequestParam String personNm)  throws Exception {
        String url = String.format(BASE_URL + "/person/company_name/%s/person_name/%s",
                URLEncoder.encode(companyNm, "UTF-8"),
                URLEncoder.encode(personNm, "UTF-8"));
        return  downLoadDataByUrl(url);
    }

    public static NodeShowBasicInfo getBasicInfoOfJson(JSONObject dataOfJson) throws Exception {
        NodeShowBasicInfo nodeShowBasicInfo = new NodeShowBasicInfo();
        Object object = dataOfJson.getJSONObject("DATA").getJSONObject("BASIC");
        if (object != null) {
            if (((JSONObject) object).get("ITEM") instanceof JSONObject) {
                JSONObject newItem = (JSONObject) ((JSONObject) object).get("ITEM");
                logger.debug(newItem.get("REGCAP"));
                logger.debug(newItem.get("REGCAP").getClass());
                logger.debug(new org.apache.commons.beanutils.BeanMap(Map2Obj.map2Obj(newItem, DaasCompanyBasicInfoNode.class)).entrySet());

                nodeShowBasicInfo = QueryResultMapper.DaasMapBasicInfoNodeShowMapper(newItem);
            }
        }
        return nodeShowBasicInfo;
    }

    public static NodeShowBasicInfo getPersonBasicInfoOfJson(JSONObject dataOfJson){
        NodeShowBasicInfo nodeShowBasicInfo;
        nodeShowBasicInfo = QueryResultMapper.DaasMapPersonBasicInfoNodeShowMapper(dataOfJson);
        return nodeShowBasicInfo;
    }


    public static ResultReturnCollection getRelationOfJson(JSONObject dataOfJson) throws Exception {
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();

        JSONObject basicNewItem = (JSONObject)dataOfJson.getJSONObject("DATA").getJSONObject("BASIC").get("ITEM");
        logger.debug(new org.apache.commons.beanutils.BeanMap(Map2Obj.map2Obj(basicNewItem, DaasCompanyBasicInfoNode.class)).entrySet());
//        NodeShow nodeShowBasic = QueryResultMapper.DaasMapBasicInfoNodeShowToNodeShowMapper(basicNewItem);
        List<String> relationSources = Arrays.asList("ENTINV", "SHAREHOLDER", "PERSON");
        for (String relationSource:relationSources){

            Object object = dataOfJson.getJSONObject("DATA").get(relationSource);
            if (object instanceof JSONObject) {
                logger.debug(relationSource);
                if (((JSONObject) object).get("ITEM") instanceof JSONArray) {
                    for (Object item : (JSONArray) (((JSONObject) object).get("ITEM"))) {
                        JSONObject newItem = (JSONObject) item;
                        ResultReturn resultReturn;
                        if (relationSource.equals("ENTINV")){
                            // logger.debug(newItem);
                            // logger.debug((DaasInvestmentNode) Map2Obj.map2Obj(newItem, DaasInvestmentNode.class));
                            // logger.debug(new org.apache.commons.beanutils.BeanMap((DaasInvestmentNode) Map2Obj.map2Obj(newItem, DaasInvestmentNode.class)).entrySet());
                            // logger.debug(new org.apache.commons.beanutils.BeanMap(QueryResultMapper.DaasMapNodeShowMapper(newItem,relationSource)).entrySet());
                            // logger.debug(new org.apache.commons.beanutils.BeanMap(nodeShowBasic).entrySet());
                            resultReturn = new ResultReturn(
                                    QueryResultMapper.DaasMapBasicInfoNodeShowToNodeShowMapper(basicNewItem),
                                    new RelationShipShow(newItem,relationSource),
                                    QueryResultMapper.DaasMapNodeShowMapper(newItem,relationSource,basicNewItem.get("ENTNAME").toString()));
                        }else{
                            resultReturn = new ResultReturn(
                                    QueryResultMapper.DaasMapNodeShowMapper(newItem,relationSource,basicNewItem.get("ENTNAME").toString()),
                                    new RelationShipShow(newItem,relationSource),
                                    QueryResultMapper.DaasMapBasicInfoNodeShowToNodeShowMapper(basicNewItem)
                            );
                        }

                        resultReturnCollection.add(resultReturn);
                    }
                }
                if (((JSONObject) object).get("ITEM") instanceof JSONObject) {
                    JSONObject newItem = (JSONObject) ((JSONObject) object).get("ITEM");
                    ResultReturn resultReturn;
                    if (relationSource.equals("ENTINV")){
                        resultReturn = new ResultReturn(
                                QueryResultMapper.DaasMapBasicInfoNodeShowToNodeShowMapper(basicNewItem),
                                new RelationShipShow(newItem,relationSource),
                                QueryResultMapper.DaasMapNodeShowMapper(newItem,relationSource,basicNewItem.get("ENTNAME").toString()));
                    }else{
                        resultReturn = new ResultReturn(
                                QueryResultMapper.DaasMapNodeShowMapper(newItem,relationSource,basicNewItem.get("ENTNAME").toString()),
                                new RelationShipShow(newItem,relationSource),
                                QueryResultMapper.DaasMapBasicInfoNodeShowToNodeShowMapper(basicNewItem)
                        );
                    }
                    resultReturnCollection.add(resultReturn);
                }
            } else {
                logger.debug(relationSource);
            }
        }
        return resultReturnCollection;
    }


    public static ResultReturnCollection getPersonRelationOfJson(JSONObject dataOfJson,JSONObject basicInfo) throws Exception {
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        logger.debug(new org.apache.commons.beanutils.BeanMap(Map2Obj.map2Obj(basicInfo, DaasPersonBasicInfoNode.class)).entrySet());
        List<String> relationSources = Arrays.asList("RYPOSSHA", "RYPOSFR", "RYPOSPER");
        for (String relationSource:relationSources){

            Object object = dataOfJson.getJSONObject("DATA").get(relationSource);
            if (object instanceof JSONObject) {
                logger.debug(relationSource);
                if (((JSONObject) object).get("ITEM") instanceof JSONArray) {
                    for (Object item : (JSONArray) (((JSONObject) object).get("ITEM"))) {
                        JSONObject newItem = (JSONObject) item;
                        ResultReturn resultReturn;
                        resultReturn = new ResultReturn(
                                QueryResultMapper.DaasMapPersonBasicInfoNodeShowToPersonNodeShowMapper(basicInfo),
                                new RelationShipShow(newItem,relationSource),
                                QueryResultMapper.DaasMapNodeShowMapper(newItem,relationSource,"")
                        );
                        resultReturnCollection.add(resultReturn);
                    }
                }
                if (((JSONObject) object).get("ITEM") instanceof JSONObject) {
                    JSONObject newItem = (JSONObject) ((JSONObject) object).get("ITEM");
                    ResultReturn resultReturn;
                    resultReturn = new ResultReturn(
                            QueryResultMapper.DaasMapPersonBasicInfoNodeShowToPersonNodeShowMapper(basicInfo),
                            new RelationShipShow(newItem,relationSource),
                            QueryResultMapper.DaasMapNodeShowMapper(newItem,relationSource,"")
                    );
                    resultReturnCollection.add(resultReturn);
                }
            } else {
                logger.debug(relationSource);
            }
        }
        return resultReturnCollection;
    }


}
