package spring.data.neo4j.mapper;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;
import spring.data.neo4j.domain.DaasPersonBasicInfoNode;
import spring.data.neo4j.domain.NodeShow;

/**
 * Created by wuchenglong on 2018/1/11.
 */

@Mapper
public interface DaasPersonBasicInfoNodeShowNodeMapper {

    DaasPersonBasicInfoNodeShowNodeMapper MAPPER = Mappers.getMapper(DaasPersonBasicInfoNodeShowNodeMapper.class);

    @Mappings({
            @Mapping(target = "suggestedLabel", constant = "PERSON"),
            @Mapping(source = "RYNAME", target = "name"),
    })
    NodeShow QueryResultToNodeShow(DaasPersonBasicInfoNode nodeQueryResult);

    @InheritInverseConfiguration
    DaasPersonBasicInfoNode NodeShowToQueryResult(NodeShow nodeShow);

}
