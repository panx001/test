package spring.data.neo4j.mapper;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;
import spring.data.neo4j.domain.NodeQueryBasicInfoResult;
import spring.data.neo4j.domain.NodeShowBasicInfo;

/**
 * Created by wuchenglong on 2018/1/10.
 */

@Mapper
public interface NodeCompanyBasicInfoMapper {
    NodeCompanyBasicInfoMapper MAPPER = Mappers.getMapper(NodeCompanyBasicInfoMapper.class);
    @Mappings({
            @Mapping(target = "suggestedLabel", constant = "COMPANY"),
            @Mapping(source = "COMPANY_NM", target = "name"),
            @Mapping(source = "COMPANY_ID", target = "company_id"),
            @Mapping(source = "COMPANY_TYPE", target = "company_type"),
            @Mapping(source = "COMPANY_TYPE_LIST", target = "company_type_list"),
            @Mapping(source = "REG_CAPITAL", target = "reg_capital"),
            @Mapping(source = "LEG_REPRESENT", target = "leg_present"),
            @Mapping(source = "FOUND_DT", target = "found_dt"),
            @Mapping(source = "REG_ADDR", target = "reg_addr"),
            @Mapping(source = "LABELS", target = "labels")
    })
    NodeShowBasicInfo QueryResultToNodeShow(NodeQueryBasicInfoResult nodeQueryResult);

    @InheritInverseConfiguration
    NodeQueryBasicInfoResult NodeShowToQueryResult(NodeShowBasicInfo nodeShow);

}
