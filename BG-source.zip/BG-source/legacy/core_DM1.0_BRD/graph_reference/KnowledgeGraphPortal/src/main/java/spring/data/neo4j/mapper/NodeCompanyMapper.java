package spring.data.neo4j.mapper;
/**
 * Created by wuchenglong on 2018/1/8.
 */

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;
import spring.data.neo4j.domain.FindRelationNodeShow;
import spring.data.neo4j.domain.NodeQueryResult;
import spring.data.neo4j.domain.NodeShow;


@SuppressWarnings("unused")
@Mapper
public interface NodeCompanyMapper {

    NodeCompanyMapper MAPPER = Mappers.getMapper(NodeCompanyMapper.class);

    @Mappings({
            @Mapping(target = "suggestedLabel", constant = "COMPANY"),
            @Mapping(source = "COMPANY_NM", target = "name"),
            @Mapping(source = "COMPANY_ID", target = "company_id"),
            @Mapping(source = "RISK_LIST", target = "risk_list"),
            @Mapping(source = "COMPANY_TYPE", target = "company_type"),
            // @Mapping(target = "company_type", ignore = true),
            @Mapping(source = "REG_CAPITAL", target = "reg_capital"),
            @Mapping(source = "LABELS", target = "labels")
    })
    NodeShow QueryResultToNodeShow(NodeQueryResult nodeQueryResult);

    @Mappings({
            @Mapping(target = "suggestedLabel", constant = "COMPANY"),
            @Mapping(source = "COMPANY_NM", target = "name"),
            @Mapping(source = "COMPANY_ID", target = "company_id"),
            @Mapping(source = "RISK_LIST", target = "risk_list"),
            @Mapping(source = "COMPANY_TYPE", target = "company_type"),
            // @Mapping(target = "company_type", ignore = true),
            @Mapping(source = "REG_CAPITAL", target = "reg_capital"),
            @Mapping(source = "LABELS", target = "labels")
    })
    FindRelationNodeShow QueryResultToFindRelationNodeShow(NodeQueryResult nodeQueryResult);

    @InheritInverseConfiguration
    NodeQueryResult NodeShowToQueryResult(NodeShow nodeShow);
    @InheritInverseConfiguration
    NodeQueryResult FindRelationNodeShowToQueryResult(FindRelationNodeShow nodeShow);

}
