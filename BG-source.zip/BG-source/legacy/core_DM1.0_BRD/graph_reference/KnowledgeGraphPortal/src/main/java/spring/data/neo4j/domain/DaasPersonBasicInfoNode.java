package spring.data.neo4j.domain;

/**
 * Created by wuchenglong on 2018/1/10.
 */

@SuppressWarnings("unused")
public class DaasPersonBasicInfoNode {

    private String RYNAME; // 自然人名称
    private String ENTNAME; // 企业名称


    public DaasPersonBasicInfoNode(){

    }

    public void setENTNAME(String ENTNAME) {
        this.ENTNAME = ENTNAME;
    }

    public String getENTNAME() {
        return ENTNAME;
    }


    public String getRYNAME() {
        return RYNAME;
    }

    public void setRYNAME(String RYNAME) {
        this.RYNAME = RYNAME;
    }
}
