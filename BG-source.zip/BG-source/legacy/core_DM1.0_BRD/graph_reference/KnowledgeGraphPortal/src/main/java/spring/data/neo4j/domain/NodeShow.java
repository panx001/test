package spring.data.neo4j.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;
import java.util.stream.Collectors;

import spring.data.neo4j.Util.Base64;
import spring.data.neo4j.Util.String2MD5;
import spring.data.neo4j.Util.UseFulFunc;

/**
 * Created by wuchenglong on 2018/1/7.
 */


@SuppressWarnings("unused")
public class NodeShow {

    private static Logger logger = LogManager.getLogger(NodeShow.class);

    private String id;
    @JsonProperty("label")
    private String suggestedLabel;
    private ArrayList<String> labels = new ArrayList<>();
    //@JsonProperty("nexus")
    private String name;
    @JsonIgnore
    private String company_id;
    //@JsonIgnore
    private ArrayList<String> company_type;
    private String link_id;
    @JsonProperty("risk_label")
    private ArrayList<Object> risk_list;
    @JsonIgnore
    private String reg_capital;

    public NodeShow(){
    }

    public void infoUpdate(){
        this.name = this.name == null ?"":this.name;
        this.id = String2MD5.md5(this.name);
        this.suggestedLabel = UseFulFunc.NODE_LABEL_MAP.getOrDefault(this.suggestedLabel,"None");
        this.link_id = this.suggestedLabel.equals("2")&&this.link_id!=null?Base64.encode(this.link_id):((this.company_id != null) ? this.company_id : Base64.encode(this.name)) ;//&& this.company_type.equals("1")
        //stream.collect(Collectors.toCollection(ArrayList::new));
        if (this.labels!=null&&!this.labels.isEmpty()){
            this.labels = this.labels.stream().map(x -> UseFulFunc.NODE_LABEL_MAP.getOrDefault(x,"None")).collect(Collectors.toCollection(ArrayList::new));
        }else {
            this.labels.add(getSuggestedLabel());
        }
        this.company_type = this.company_type==null?null:this.company_type.stream().map(x -> UseFulFunc.NODE_TYPE_MAP.getOrDefault(x,"None")).collect(Collectors.toCollection(ArrayList::new));
        if(this.company_type != null && this.company_type.contains("O")){
            this.company_type.remove("3");
            this.company_type.remove("O");
        }
        if(this.risk_list!=null && !this.risk_list.isEmpty() ){  //&& risk_label.contains("RISK")
            ArrayList<Object> risk_list = new ArrayList<>();
            for (Object i: this.risk_list)
            {
                if (!i.toString().equals(""))
                {
                    risk_list.add(Integer.parseInt((i.toString())));
                }
            }
            this.risk_list = risk_list;
        }

    }

    public void setCompany_id(String company_id) {
        this.company_id = company_id;
    }

    public String getCompany_id() {
        return company_id;
    }

    public void setCompany_type(ArrayList<String> company_type) {
        this.company_type = company_type;
    }

    public ArrayList<String> getCompany_type() {
        return company_type;
    }

    public void setLink_id(String link_id) {
        this.link_id = link_id;
    }

    public String getLink_id() {
        return link_id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setSuggestedLabel(String suggestedLabel) {
        this.suggestedLabel = suggestedLabel;
    }

    public String getSuggestedLabel() {
        return suggestedLabel;
    }

    public void setLabels(ArrayList<String> labels) {
        this.labels = labels;
    }

    public ArrayList<String> getLabels() {
        return labels;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setReg_capital(String reg_capital) {
        this.reg_capital = reg_capital;
    }

    public String getReg_capital() {
        return reg_capital;
    }

    public void setRisk_list(ArrayList<Object> risk_list) {
        this.risk_list = risk_list;
    }

    public ArrayList<Object> getRisk_list() {
        return risk_list;
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof NodeShow)){
            return false;
        }
        NodeShow nodeShow = (NodeShow) obj;
        return nodeShow.getName().equals(this.name);
    }

    @Override
    public int hashCode() {
        return 123;
    }
}
