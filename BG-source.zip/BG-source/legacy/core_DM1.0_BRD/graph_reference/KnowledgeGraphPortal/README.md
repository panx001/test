
#### 从neo4j查询数据
http://localhost:7077/chart/company/neo4j?companyNm=中证征信(深圳)有限公司
#### 从中数查询数据
http://localhost:7077/chart/daasData/company?companyNm=中证信用增进股份有限公司
### 从neo4j返回企业基本信息
http://localhost:7077/chart/company/basicInfo/neo4j?companyNm=万科企业股份有限公司
### 从中数返回企业基本信息
http://localhost:7077/chart/company/basicInfo/daas?companyNm=中证信用增进股份有限公司

