package spring.data.neo4j;

import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.text.StrSubstitutor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.ogm.response.model.QueryStatisticsModel;
import redis.clients.jedis.Jedis;
import spring.data.neo4j.config.DbConnectionConfig;
import spring.data.neo4j.neo4jConnector.Neo4jAccess;
import spring.data.neo4j.util.MailUtil;
import spring.data.neo4j.util.UtilConfig;

import java.io.File;
import java.io.PrintStream;
import java.util.*;
import java.util.stream.Collectors;


/**
 * Created by chinacscs on 2018/5/2.
 */
public class UpdateRiskLabelFromRedis {
    private static Jedis jedis;
    private static final Logger logger = LogManager.getLogger(Main.class);
    HashMap<String, String> paraHashMap = new HashMap<String, String>();

    private static String clean_query = "MATCH (C:PFCOMPANY) WHERE EXISTS(C.RISK_LIST)   WITH C  SET C.RISK_LIST = NULL";
    private static String update_query =
            "USING PERIODIC COMMIT 10000 \n" +
            "LOAD CSV  \n" +
            "WITH HEADERS \n" +
            "FROM 'file:///${csv_url}' AS LINE\n" +
            " MATCH (C:PFCOMPANY) \n" +
            "            WHERE C.COMPANY_ID = LINE.COMPANY_ID \n" +
            "            SET C.RISK_LIST = [x in split(LINE.RISK_LIST,\",\")|toint(x)]";

    public final static Map<String,Integer> RISK_LABEL_MAP = new HashMap<String,Integer>(){{
        put("exceptionList", 1);
        put("shareholdersFreeze", 2);
        put("administrativePenalties", 3);
        put("equityPledged", 4);
        put("chattelMortgage", 5);
        put("supervisionPunishment", 6);
        put("integrityInformation", 7);
        put("dataException", 8);
        put("disruptinfo", 9);
        put("undertaker", 11);
        put("wenshutheme", 12);
        put("court", 13);
    }};

    @Before
    public void setJedis(String redisUrl) {
        //连接redis服务器(在这里是连接本地的)
        redisUrl = redisUrl==null?"10.100.24.12":redisUrl;
        jedis = new Jedis(redisUrl, 6379);
        //权限认证
        jedis.auth("Cscs@31$2016#");
        System.out.println("连接服务成功");
    }


    @Test
    public void testString() {
        System.out.println(jedis.ping());//读取key为name的值
        Set<String> keys = jedis.keys("pfund_data");
        Iterator<String> it=keys.iterator() ;
        while(it.hasNext()){
            System.out.println(getRiskLabel(it));
        }
    }



    @Test
    public void getRiskDataToCSV() throws Exception {
        DbConnectionConfig dbConnectionConfig = null;
        File dir = UtilConfig.file("/data/update/" + UtilConfig.getData() + "/risklabel");
        PrintStream out = null;
        out = new PrintStream(new File(dir,"0.csv"));
        out.println("COMPANY_ID,RISK_LIST");


//        try {
//            dbConnectionConfig = (DbConnectionConfig) UtilConfig.configFileToBean(
//                    "dbConnectionConfig_test.properties",
//                    DbConnectionConfig.class);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        String jdbc_url = dbConnectionConfig.neo4jUri;
//        logger.debug(jdbc_url);


        System.out.println(jedis.ping());//读取key为name的值
        Set<String> keys = jedis.keys("pfund_data*");
        Iterator<String> it = keys.iterator();
        while (it.hasNext()) {
            ArrayList<String> riskLabelResult = getRiskLabel(it);
            if (!riskLabelResult.get(1).equals(""))
            {
                out.println("\"" + riskLabelResult.get(0) +"\",\""+riskLabelResult.get(1) +"\"");
            }
        }
    }

    @Test
    public void printRedisData() throws Exception {
        System.out.println(jedis.ping());//读取key为name的值
        String key = "newscloud_239589";
        System.out.print(jedis.get(key).toString());
        jedis.del(key);
        System.out.print(jedis.get(key));
    }



    @Test
    public void updateCSVToNeo4j(DbConnectionConfig dbConnectionConfig) throws Exception {
        File dir = UtilConfig.file("/data/update/" + UtilConfig.getData() + "/risklabel");

        String[] array = dir.list();
        if(array==null) {
            return;
        }
        for (String targetCSVDir :array) {
            HashMap<String, String> paraHashMap = new HashMap<String, String>();
            paraHashMap.put("csv_url",new File(dir,targetCSVDir).getAbsolutePath().replace("\\","\\\\"));
            StrSubstitutor sub = new StrSubstitutor(paraHashMap);
            String updateQuery = sub.replace(update_query);

            String jdbc_url = DbConnectionConfig.neo4jUri;
            logger.debug(jdbc_url);
            try{
                Neo4jAccess neo4jAccess = new Neo4jAccess(dbConnectionConfig);
                neo4jAccess.establishConnection();
                StatementResult result_del = neo4jAccess.session.run(clean_query);
                QueryStatisticsModel queryStatisticsModel_del = new QueryStatisticsModel();
                queryStatisticsModel_del.setProperties_set(result_del.consume().counters().propertiesSet());
                logger.debug(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel_del).entrySet().stream().filter(w -> w.getValue() instanceof Integer).filter(w -> (Integer) w.getValue() != 0).collect(Collectors.toList()));
                StatementResult result = neo4jAccess.session.run(updateQuery);
                QueryStatisticsModel queryStatisticsModel = new QueryStatisticsModel();
                queryStatisticsModel.setProperties_set(result.consume().counters().propertiesSet());
                logger.debug(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet().stream().filter(w -> w.getValue() instanceof Integer).filter(w -> (Integer) w.getValue() != 0).collect(Collectors.toList()));
                neo4jAccess.closeConnection();
            }
            catch (Exception e) {
                logger.debug(e);
            }
        }
    }


    private static ArrayList<String> getRiskLabel(Iterator<String> it) {
        ArrayList<String> resultArray = new ArrayList<>();
        ArrayList<Integer> result = new ArrayList<>();
        String key = it.next();
        try {
            JSONObject dataOfJson = JSONObject.fromObject(jedis.get(key).toString()).getJSONObject("risk");
            Set<String> riskKeys = dataOfJson.keySet();
            Iterator<String> riskIt = riskKeys.iterator();
            while(riskIt.hasNext()){
                String riskKey = riskIt.next();
                if(!(dataOfJson.get(riskKey).toString().equals("")||dataOfJson.get(riskKey).toString().equals("[]"))){
                    if (RISK_LABEL_MAP.containsKey(riskKey)){
                        result.add(RISK_LABEL_MAP.get(riskKey));
                    }
                }
            }
        }
        catch (Exception e) {
            logger.debug("Error key:"+key);
        }
        String resultString = StringUtils.join(result,",") ;
        resultArray.add(key.replace("pfund_data",""));
        resultArray.add(resultString);
        return resultArray;
    }

    public static void main(String[] args){
        DbConnectionConfig dbConnectionConfig = null;
        try{
            String targetNeo4j = "dbConnectionConfig_test.properties";
            if(args.length!=0) {
                targetNeo4j = UtilConfig.getEnvironment(args[0]);
                logger.debug(args[0]+":"+targetNeo4j);
            }
            dbConnectionConfig = (DbConnectionConfig) UtilConfig.configFileToBean(
                        targetNeo4j,
                        DbConnectionConfig.class);

            UpdateRiskLabelFromRedis updateRiskLabelFromRedis = new UpdateRiskLabelFromRedis();
            updateRiskLabelFromRedis.setJedis(dbConnectionConfig.redisUrl);
            updateRiskLabelFromRedis.getRiskDataToCSV();
            updateRiskLabelFromRedis.updateCSVToNeo4j(dbConnectionConfig);
        } catch (Exception e) {
            MailUtil.sendLogEmail(args[0],"从Redis更新风险信息出错:"+e.toString());
            e.printStackTrace();
        }
//        cleanNewsCloud(args);
    }

    private static void cleanNewsCloud(String[] args) {
                DbConnectionConfig dbConnectionConfig = null;
        try{
            String targetNeo4j = "dbConnectionConfig_test.properties";
            if(args.length!=0) {
                targetNeo4j = UtilConfig.getEnvironment(args[0]);
                logger.debug(args[0]+":"+targetNeo4j);
            }
            dbConnectionConfig = (DbConnectionConfig) UtilConfig.configFileToBean(
                        targetNeo4j,
                        DbConnectionConfig.class);
            UpdateRiskLabelFromRedis updateRiskLabelFromRedis = new UpdateRiskLabelFromRedis();
            updateRiskLabelFromRedis.setJedis(dbConnectionConfig.redisUrl);
            updateRiskLabelFromRedis.printRedisData();
    }catch (Exception e) {
//            MailUtil.sendLogEmail(args[0],"从Redis更新风险信息出错:"+e.toString());
            e.printStackTrace();
        }

    }
}
