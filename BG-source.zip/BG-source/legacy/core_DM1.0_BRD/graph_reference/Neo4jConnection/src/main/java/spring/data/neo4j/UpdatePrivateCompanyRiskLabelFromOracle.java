package spring.data.neo4j;


import org.apache.commons.lang.text.StrSubstitutor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.ogm.response.model.QueryStatisticsModel;
import spring.data.neo4j.config.DbConnectionConfig;
import spring.data.neo4j.neo4jConnector.Neo4jAccess;
import spring.data.neo4j.util.MailUtil;
import spring.data.neo4j.util.UtilConfig;

import java.io.File;
import java.util.*;
import java.util.stream.Collectors;


/**
 * Created by chinacscs on 2018/5/2.
 */
public class UpdatePrivateCompanyRiskLabelFromOracle {
    private static final Logger logger = LogManager.getLogger(Main.class);

    private static String exportSQL ="SELECT  DECODE(E.COMPANY_ID,NULL,F.COMPANY_ID,E.COMPANY_ID) AS COMPANY_ID,RISK|| DECODE(F.COMPANY_ID,NULL,NULL,35||',') AS RISK\n" +
            "FROM( SELECT DECODE(C.COMPANY_ID,NULL,D.COMPANY_ID,C.COMPANY_ID) AS COMPANY_ID,RISK|| DECODE(D.COMPANY_ID,NULL,NULL,34||',') AS RISK\n" +
            "FROM( \n" +
            "SELECT DECODE(A.COMPANY_ID,NULL,B.COMPANY_ID,A.COMPANY_ID) AS COMPANY_ID, DECODE(A.COMPANY_ID,NULL,NULL,31||',') || DECODE(B.COMPANY_ID,NULL,NULL,33||',') AS RISK   FROM (SELECT DISTINCT COMPANY_ID FROM CS_GS_DM.VW_COMPY_OPEREXCEPT_XYGS) A\n" +
            "FULL JOIN (SELECT DISTINCT COMPANY_ID FROM CS_GS_DM.VW_COMPY_ADMINPENALTY_XYGS) B\n" +
            "ON A.COMPANY_ID = B.COMPANY_ID \n" +
            ") C\n" +
            "FULL JOIN (SELECT DISTINCT COMPANY_ID FROM CS_GS_DM.VW_COMPY_EQUITYPLEDGE_XYGS) D\n" +
            "ON C.COMPANY_ID = D.COMPANY_ID\n" +
            ")E\n" +
            "FULL JOIN (SELECT DISTINCT COMPANY_ID FROM CS_GS_DM.VW_COMPY_CHATTELREG_XYGS) F\n" +
            "ON E.COMPANY_ID = F.COMPANY_ID";

    private static String update_query =
            "USING PERIODIC COMMIT 10000 \n" +
                    "LOAD CSV  \n" +
                    "WITH HEADERS \n" +
                    "FROM 'file:///${csv_url}' AS LINE\n" +
                    " MATCH (C:COMPANY) \n" +
                    "            WHERE C.COMPANY_ID = LINE.COMPANY_ID AND NOT (EXISTS(C.COMPANY_TYPE_LIST) AND ANY(ELEM IN ['A股','B股','H股','三板股','私募企业'] WHERE ELEM IN C.COMPANY_TYPE_LIST )   ) \n" +
                    "            SET C.RISK_LIST = [x in split(left(LINE.RISK,size(LINE.RISK)-1),',')|toint(x)]";



    @Test
    public void getRiskDataToCSV() throws Exception {
        File dir = UtilConfig.file("/data/update/" + UtilConfig.getData() + "/privatecompanyrisklabel");
        UpdatePrivateCompanyFromCsv updatePrivateCompanyFromCsv = new UpdatePrivateCompanyFromCsv();
        updatePrivateCompanyFromCsv.exportDataByQueryToDirFiles(dir,exportSQL,"");
    }

    public void updateCSVToNeo4j(String targetNeo4j) throws Exception {
        DbConnectionConfig dbConnectionConfig = null;
        File dir = UtilConfig.file("/data/update/" + UtilConfig.getData() + "/privatecompanyrisklabel");

        String[] array = dir.list();
        if(array==null) {
            return;
        }
        for (String targetCSVDir :array) {
            HashMap<String, String> paraHashMap = new HashMap<String, String>();
            paraHashMap.put("csv_url",new File(dir,targetCSVDir).getAbsolutePath().replace("\\","\\\\"));
            StrSubstitutor sub = new StrSubstitutor(paraHashMap);
            String updateQuery = sub.replace(update_query);
           // logger.debug(updateQuery);
            logger.debug("执行内存清理");
            UtilConfig.exec("sync && echo 1 > /proc/sys/vm/drop_caches");
            UtilConfig.exec("sync && echo 2 > /proc/sys/vm/drop_caches");
            UtilConfig.exec("sync && echo 3 > /proc/sys/vm/drop_caches");
            logger.debug("内存清理完成");
            try {
                dbConnectionConfig = (DbConnectionConfig) UtilConfig.configFileToBean(
                        targetNeo4j,
                        DbConnectionConfig.class);
            } catch (Exception e) {
                e.printStackTrace();
            }
            try{
                Neo4jAccess neo4jAccess = new Neo4jAccess(dbConnectionConfig);
                neo4jAccess.establishConnection();
                StatementResult result = neo4jAccess.session.run(updateQuery);
                QueryStatisticsModel queryStatisticsModel = new QueryStatisticsModel();
                queryStatisticsModel.setProperties_set(result.consume().counters().propertiesSet());
                logger.debug(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet().stream().filter(w -> w.getValue() instanceof Integer).filter(w -> (Integer) w.getValue() != 0).collect(Collectors.toList()));
                neo4jAccess.closeConnection();
            }
            catch (Exception e) {
                logger.debug(e);
            }
            //暂停一分钟以便neo4j处理更新
            logger.debug("睡眠一分钟");
            UtilConfig.exec("sleep 60s");
        }
    }


    public static void main(String[] args) {
        try{
            String targetNeo4j = "dbConnectionConfig_test.properties";
            if(args.length!=0) {
                targetNeo4j = UtilConfig.getEnvironment(args[0]);
                logger.debug(args[0]+":"+targetNeo4j);
            }
            UpdatePrivateCompanyRiskLabelFromOracle updatePrivateCompanyRiskLabelFromOracle = new UpdatePrivateCompanyRiskLabelFromOracle();
            updatePrivateCompanyRiskLabelFromOracle.getRiskDataToCSV();
            updatePrivateCompanyRiskLabelFromOracle.updateCSVToNeo4j(targetNeo4j);
        } catch (Exception e) {
            MailUtil.sendLogEmail(args[0],"从Oracle更新非公开企业风险信息出错:"+e.toString());
            e.printStackTrace();
        }
    }
}
