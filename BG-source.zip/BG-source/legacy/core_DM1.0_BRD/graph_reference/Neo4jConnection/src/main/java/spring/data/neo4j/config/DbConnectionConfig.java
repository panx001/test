package spring.data.neo4j.config;

/**
 * Created by wuchenglong on 2018/1/15.
 */
public class DbConnectionConfig {

    public static String JdbcUri;
    public static String neo4jUri;
    public static String neo4jUserName;
    public static String neo4jPassword;
    public static String interval_days;
    public static String redisUrl;
    public static String redisPort;

}
