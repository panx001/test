package spring.data.neo4j.util;

import java.util.*;

/**
 * Created by wuchenglong on 2018/1/15.
 */

public class UtilCql {

    public  final static Map<String,List<String>> updatePublicCompanyCqlMap = new LinkedHashMap<String, List<String>>() {{

        // //////// 创建公开企业基本信息
        // put("IMPORT_PUBLIC_COMPANY",Arrays.asList(IMPORT_PUBLIC_COMPANY," AND  A.UPDT_DT >=  SYSDATE - %s"));

        /////-------------- 以下更新逻辑可用 ------
        //////// 更新非产品企业节点
        put("UPDATA_NOTCOMPANY_SECURITY_INFO",Arrays.asList(UPDATA_NOTCOMPANY_SECURITY_INFO,""));
        //////// 更新产品企业节点
        put("UPDATA_COMPANY_SECURITY_NODE",Arrays.asList(UPDATA_COMPANY_SECURITY_NODE,""));
        //////// 更新产品企业关系
        put("UPDATA_COMPANY_SECURITY_RELATION",Arrays.asList(UPDATA_COMPANY_SECURITY_RELATION,""));
        //////// 删除管理人托管人关系
        put("DELETE_PFUND_RELATION",Arrays.asList(DELETE_PFUND_RELATION,""));
        //////// 创建私募基金节点
        put("IMPORT_PFUND_NODE",Arrays.asList(IMPORT_PFUND_NODE," AND  A.UPDT_DT >=  SYSDATE - %s"));

        //////// 创建私募基金管理人label
        put("IMPORT_PFCOMPANY_NODE",Arrays.asList(IMPORT_PFCOMPANY_NODE," WHERE UPDT_DT >=  SYSDATE - %s "));

        //////// 删除企业新三板发债上市属性
        put("DELETE_COMPANY_TYPE_LIST_PROPERTY",Arrays.asList(DELETE_COMPANY_TYPE_LIST_PROPERTY,""));

        //////// 创建企业新三板发债上市属性
        put("ADD_COMPANY_TYPE_LIST_PROPERTY",Arrays.asList(ADD_COMPANY_TYPE_LIST_PROPERTY,""));

        //////// 删除企业上市代码
        put("DELETE_SECURITY_CODE_PROPERTY",Arrays.asList(DELETE_SECURITY_CODE_PROPERTY,""));

        //////// 创建企业上市代码
        put("ADD_SECURITY_CODE_PROPERTY",Arrays.asList(ADD_SECURITY_CODE_PROPERTY,""));

        //////// 删除公开企业企业风险属性
        put("DELETE_PUBLIC_RISK_LIST_PROPERTY",Arrays.asList(DELETE_PUBLIC_RISK_LIST_PROPERTY,""));

        //////// 添加公开企业风险属性
        put("ADD_PUBLIC_RISK_LIST_PROPERTY",Arrays.asList(ADD_PUBLIC_RISK_LIST_PROPERTY,""));

        //////// 删除历史公开企业高管
        put("DELETE_WORKER_RELATION_FROM_MANAGELEVEL",Arrays.asList(DELETE_WORKER_RELATION_FROM_MANAGELEVEL," AND  A.UPDT_DT >=  SYSDATE - %s "));

        //////// 添加公开企业高管
        put("ADD_WORKER_RELATION_FROM_MANAGELEVEL",Arrays.asList(ADD_WORKER_RELATION_FROM_MANAGELEVEL," AND  A.UPDT_DT >=  SYSDATE - %s "));

        //////// 删除历史前十大企业股东
        put("DELETE_TOP10SHAREHOLDER_RELATION",Arrays.asList(DELETE_TOP10SHAREHOLDER_RELATION," WHERE UPDT_DT >=  SYSDATE - %s"));

        //////// 公开企业前十大股东
        put("CREATE_NODE_FROM_TOP10SHAREHOLDER_COMPANY",Arrays.asList(ADD_TOP10SHAREHOLDER," WHERE UPDT_DT >=  SYSDATE - %s"));

        //////// 创建亲属关系
        put("CREATE_RELATION_FAMILY",Arrays.asList(CREATE_RELATION_FAMILY,""));

        /////// 删除控制关系
        put("DELETE_CONTROL_RELATION",Arrays.asList(DELETE_CONTROL_RELATION,""));

        /////// 添加控制关系属性
        put("CREATE_RELATION_PERSON_AFFIL",Arrays.asList(CREATE_RELATION_AFFIL,""));

        /////// 清除预警数据
        put("CLEAR_COMPANY_WARNING_NUM",Arrays.asList(CLEAR_COMPANY_WARNING_NUM,""));

        /////// 添加预警数据
        put("ADD_COMPANY_WARNING_NUM",Arrays.asList(ADD_COMPANY_WARNING_NUM,""));

        /////// 删除担保关系
        put("DELETE_RELATION_GUARANTEE",Arrays.asList(DELETE_RELATION_GUARANTEE,""));

        /////// 创建担保关系
        put("CREATE_RELATION_GUARANTEE",Arrays.asList(CREATE_RELATION_GUARANTEE,""));

        //////// 删除管理人托管人关系
        put("DELETE_CUST_SUPPLIER_RELATION",Arrays.asList(DELETE_CUST_SUPPLIER_RELATION,""));

        //////// 主要客户
        put("CREATE_RELATION_CUSTOMER",Arrays.asList(CREATE_RELATION_CUSTOMER,""));

        //////// 主要供应商
        put("CREATE_RELATION_SUPPLIER",Arrays.asList(CREATE_RELATION_SUPPLIER,""));

    }};

    public  final static Map<String,List<String>> updatePublicCompanyCqlMap_incre = new LinkedHashMap<String, List<String>>() {{
        /////-------------- 仅用于增量更新的cypher ------
        //////// 创建私募基金节点
        put("IMPORT_SECURITY_NODE",Arrays.asList(IMPORT_SECURITY_NODE," AND  A.UPDT_DT >=  SYSDATE - %s"));

    }};
    private final static String UPDATA_NOTCOMPANY_SECURITY_INFO =
            "\n// 更新产品非企业节点 \n " +
                    "WITH '{jdbc_url}' AS url\n" +
                    "CALL apoc.load.jdbc(url,\"\n" +
                    "SELECT SECINNER_ID,SECURITY_CD,COMPANY_ID,REPLACE(REPLACE(SECURITY_NM,'）',')'),'（','(') AS SECURITY_NM  FROM CS_PORTAL.SECURITY A  LEFT JOIN CS_PORTAL.LKP_CHARCODE B ON A.SECURITY_TYPE_ID = B.CONSTANT_ID WHERE B.CONSTANT_NM NOT  IN ('A股','B股','H股','三板股')  AND A.SECURITY_NM   NOT   LIKE '%公司' AND A.SECURITY_NM   NOT   LIKE '%有限合伙%'  AND  A.ISDEL = 0 AND TO_CHAR(A.UPDT_DT,'YYYY-MM-DD') >TO_CHAR(SYSDATE-5,'YYYY-MM-DD')\n" +
                    "\") YIELD row WITH row as LINE\n" +
                    "WHERE ( LINE.SECINNER_ID IS NOT NULL AND NOT LINE.SECINNER_ID = '' )\n" +
                    "    AND ( LINE.COMPANY_ID IS NOT NULL AND NOT LINE.COMPANY_ID = '' )\n" +
                    "    AND ( LINE.SECINNER_ID IS NOT NULL AND NOT LINE.SECINNER_ID = '' )\n" +
                    "    WITH LINE\n" +
                    "    MERGE (S:SECURITY{SECINNER_ID:toString(LINE.SECINNER_ID)})\n" +
                    "    SET\n" +
                    "        S.SECURITY_CD = toString(LINE.SECURITY_CD),\n" +
                    "        S.SECURITY_NM = toString(LINE.SECURITY_NM)\n" +
                    "    WITH S, LINE\n" +
                    "    MATCH (C:COMPANY{COMPANY_ID:toString(LINE.COMPANY_ID)})\n" +
                    "    MERGE(C)-[F:ISSUE{RELATIONSHIP:'发行'}]->(S);";


    private final static String UPDATA_COMPANY_SECURITY_NODE =
            "\n// 更新产品企业节点 \n " +
                    "WITH '{jdbc_url}' AS url\n" +
                    "CALL apoc.load.jdbc(url,\"\n" +
                    "SELECT  B.CONSTANT_NM,SECINNER_ID,SECURITY_CD,REPLACE(REPLACE(SECURITY_NM,'）',')'),'（','(') AS SECURITY_NM,COMPANY_ID  FROM CS_PORTAL.SECURITY A  \n" +
                    "LEFT JOIN CS_PORTAL.LKP_CHARCODE B ON \n" +
                    "A.SECURITY_TYPE_ID = B.CONSTANT_ID\n" +
                    "WHERE B.CONSTANT_NM NOT  IN ('A股','B股','H股','三板股')   \n" +
                    "AND  A.ISDEL = 0\n" +
                    "AND  (\n" +
                    "    A.SECURITY_NM       LIKE '%公司' \n" +
                    "    OR A.SECURITY_NM       LIKE '%有限合伙%'\n" +
                    ") -- AND A.SECINNER_ID = '17615085'\n" +
                    " \")yield row \n" +
                    "WITH row as  LINE  \n" +
                    "WITH LINE\n" +
                    "// LIMIT 2000\n" +
                    "// REPLACE(REPLACE(COMPANY_NM,\\\\'）\\\\',\\\\')\\\\'),\\\\'（\\\\',\\\\'(\\\\')\n" +
                    "OPTIONAL MATCH  (A:COMPANY{COMPANY_NM:LINE.SECURITY_NM}) WHERE NOT EXISTS(A.SECINNER_ID)\n" +
                    "OPTIONAL MATCH  (S:SECURITY{SECINNER_ID:LINE.SECINNER_ID})\n" +
                    "WITH LINE, COLLECT(A) AS A_LIST,COLLECT(S) AS S_LIST\n" +
                    "WITH LINE ,A_LIST[0] AS A, S_LIST[0] AS S \n" +
                    "// S 存在不更新\n" +
                    "FOREACH(LINE_ELEM IN CASE WHEN S IS NOT NULL THEN [] ELSE [] END | \n" +
                    "    SET \n" +
                    "        S:SECURITY,\n" +
                    "        S.SOURCE = 'TEST',\n" +
                    "        S.SECURITY_NM = LINE.SECURITY_NM  \n" +
                    "        ) \n" +
                    "// S 不存在，且没有匹配到A\n" +
                    "FOREACH(LINE_ELEM IN CASE WHEN S IS NOT NULL THEN [] ELSE CASE WHEN A IS NULL THEN [LINE] ELSE [] END END | \n" +
                    "    CREATE (C:SECURITY{SECINNER_ID:LINE.SECINNER_ID})\n" +
                    "    SET \n" +
                    "        C.SOURCE = 'TEST',\n" +
                    "        C.SECURITY_NM = LINE.SECURITY_NM  \n" +
                    "        ) \n" +
                    "// S 不存在，匹配到A\n" +
                    "FOREACH(LINE_ELEM IN CASE WHEN S IS NOT NULL THEN [] ELSE CASE WHEN A IS NOT NULL THEN [LINE] ELSE [] END END | \n" +
                    "    SET \n" +
                    "        A:SECURITY,\n" +
                    "        A.SECINNER_ID = LINE.SECINNER_ID,\n" +
                    "        A.SOURCE = 'TEST',\n" +
                    "        A.SECURITY_NM = LINE.SECURITY_NM\n" +
                    "        );";

    private final static String UPDATA_COMPANY_SECURITY_RELATION =
            "\n// 更新产品企业关系 \n " +
                    "WITH '{jdbc_url}' AS url\n" +
                    "CALL apoc.load.jdbc(url,\"\n" +
                    "SELECT  SECINNER_ID,COMPANY_ID  FROM CS_PORTAL.SECURITY A  \n" +
                    "LEFT JOIN CS_PORTAL.LKP_CHARCODE B ON \n" +
                    "A.SECURITY_TYPE_ID = B.CONSTANT_ID\n" +
                    "WHERE B.CONSTANT_NM NOT  IN ('A股','B股','H股','三板股')   \n" +
                    "AND  A.ISDEL = 0\n" +
                    "AND  (\n" +
                    "    A.SECURITY_NM       LIKE '%公司' \n" +
                    "    OR A.SECURITY_NM       LIKE '%有限合伙%'\n" +
                    ") -- AND A.SECINNER_ID = '17615085'\n" +
                    " \")yield row \n" +
                    "WITH row as  LINE \n" +
                    "WHERE ( LINE.SECINNER_ID IS NOT NULL AND NOT LINE.SECINNER_ID = '' )\n" +
                    "    AND ( LINE.COMPANY_ID IS NOT NULL AND NOT LINE.COMPANY_ID = '' )\n" +
                    "// CALL apoc.date.formatDefault(timestamp()+8*60*60*1000,'ms') yield value  as TIME_STAMP\n" +
                    "MATCH (S:SECURITY{SECINNER_ID:toString(LINE.SECINNER_ID)})\n" +
                    "MATCH (C:COMPANY{COMPANY_ID:toString(LINE.COMPANY_ID)})\n" +
                    "MERGE(C)-[F:ISSUE{RELATIONSHIP:'发行'}]->(S) ;";

    public final static String IMPORT_PUBLIC_COMPANY = "// 导入 公开企业基本信息 信息 \n" +
            "WITH '{jdbc_url}' AS url\n" +
            "CALL apoc.load.jdbc(url,\"\n" +
            "SELECT  A.COMPANY_ID,A.COMPANY_NM,E.CONSTANT_NM AS STATUS,TO_CHAR(A.UPDT_DT,'yyyy-mm-dd HH24:MI:SS') AS UPDT_DT,A.LEG_REPRESENT FROM CS_PORTAL.COMPY_BASICINFO A\n" +
            "INNER JOIN CS_PORTAL.SECURITY C\n" +
            "ON C.COMPANY_ID = A.COMPANY_ID\n" +
            "INNER JOIN CS_PORTAL.LKP_NUMBCODE E\n" +
            "ON A.COMPANY_ST = E.CONSTANT_CD AND E.CONSTANT_TYPE =3\n" +
            "INNER JOIN (SELECT CONSTANT_ID AS SECURITY_TYPE_ID, CONSTANT_NM AS SECURITY_TYPE FROM CS_PORTAL.LKP_CHARCODE WHERE CONSTANT_TYPE = 401 AND ISDEL = 0) LKP1\n" +
            "ON C.SECURITY_TYPE_ID = LKP1.SECURITY_TYPE_ID\n" +
            "WHERE A.IS_DEL=0 AND  LKP1.SECURITY_TYPE IN ('A股', 'B股', 'H股', '三板股')"+
            "  {condition}\n" +
            "    \")yield row WITH row AS  LINE\n" +
            "    WHERE ( LINE.COMPANY_ID IS NOT NULL AND NOT LINE.COMPANY_ID = '' )\n" +
            "    AND LINE.COMPANY_NM IS NOT NULL\n" +
            "    WITH apoc.date.format(timestamp()+8*60*60*1000,\"ms\",\"yyyy-MM-dd HH:mm:ss\") AS TIME_STAMP,LINE\n" +
            "    MERGE (C:COMPANY{COMPANY_ID:toString(LINE.COMPANY_ID)})\n" +
            "    SET\n" +
            "        C.TIME_STAMP = TIME_STAMP,\n" +
            "        C.COMPANY_NM = LINE.COMPANY_NM,\n" +
            "        C.STATUS = LINE.STATUS,\n" +
            "        C.SOURCE = 'COMPY_BASICINFO',\n" +
            "        C.UPDT_DT = LINE.UPDT_DT,\n" +
            "        C.LEG_REPRESENT=LINE.LEG_REPRESENT\n" +
            "    WITH C,TIME_STAMP, LINE, CASE WHEN LINE.LEG_REPRESENT IS NOT NULL AND NOT LINE.LEG_REPRESENT = '' THEN [LINE.LEG_REPRESENT] ELSE [] END  AS LEG_REPRESENTS\n" +
            "    UNWIND LEG_REPRESENTS AS LEG_REPRESENT\n" +
            "    MERGE (P:PERSON{PERSON_ID:LINE.COMPANY_ID+LEG_REPRESENT})\n" +
            "    ON CREATE SET\n" +
            "        P.SOURCE = 'COMPY_BASICINFO',\n" +
            "        P.TIME_STAMP = TIME_STAMP,\n" +
            "        P.UPDT_DT = LINE.UPDT_DT,\n" +
            "        P.PERSON_NM = LINE.LEG_REPRESENT\n" +
            "    MERGE(P)-[W:WORK{POSITION:'法定代表人'}]->(C)\n" +
            "    ON CREATE SET\n" +
            "        P.SOURCE = 'COMPY_BASICINFO',\n" +
            "        P.TIME_STAMP = TIME_STAMP,\n" +
            "        P.UPDT_DT = LINE.UPDT_DT,\n" +
            "        P.PERSON_NM = LINE.LEG_REPRESENT,\n" +
            "        W.TIME_STAMP = TIME_STAMP,\n" +
            "        W.SOURCE='COMPY_BASICINFO'\n" +
            "        ;";



    private final static String IMPORT_SECURITY_NODE =
            "\n// 导入 SECURITY 信息 \n" +
            "WITH '{jdbc_url}' AS url\n" +
            "CALL apoc.load.jdbc(url,\"\n" +
            "SELECT  B.CONSTANT_NM,SECINNER_ID,SECURITY_CD,REPLACE(REPLACE(SECURITY_NM,'）',')'),'（','(') AS SECURITY_NM,COMPANY_ID  FROM cs_CREDIT.SECURITY A\n" +
            "LEFT JOIN cs_CREDIT.LKP_CHARCODE B ON\n" +
            "A.SECURITY_TYPE_ID = B.CONSTANT_ID\n" +
            "WHERE B.CONSTANT_NM NOT  IN ('A股','B股','H股','三板股')\n" +
            "AND  A.ISDEL = 0 \n" +
            "{condition} \n" +
            "\") YIELD row WITH row as LINE\n" +
            "OPTIONAL MATCH  (A:COMPANY{COMPANY_NM:LINE.SECURITY_NM}) WHERE NOT EXISTS(A.SECINNER_ID)\n" +
            "OPTIONAL MATCH  (S:SECURITY{SECINNER_ID:LINE.SECINNER_ID})\n" +
            "WITH LINE, COLLECT(A) AS A_LIST,COLLECT(S) AS S_LIST\n" +
            "WITH LINE ,A_LIST[0] AS A, S_LIST[0] AS S\n" +
            "// S 存在不更新\n" +
            "FOREACH(LINE_ELEM IN CASE WHEN S IS NOT NULL THEN [] ELSE [] END |\n" +
            "    SET\n" +
            "        S:SECURITY,\n" +
            "        S.SOURCE = 'TEST',\n" +
            "        S.SECURITY_NM = LINE.SECURITY_NM\n" +
            "        )\n" +
            "// S 不存在，且没有匹配到A\n" +
            "FOREACH(LINE_ELEM IN CASE WHEN S IS NOT NULL THEN [] ELSE CASE WHEN A IS NULL THEN [LINE] ELSE [] END END |\n" +
            "    CREATE (C:SECURITY{SECINNER_ID:LINE.SECINNER_ID})\n" +
            "    SET\n" +
            "        C.SOURCE = 'TEST',\n" +
            "        C.SECURITY_NM = LINE.SECURITY_NM\n" +
            "        )\n" +
            "// S 不存在，匹配到A\n" +
            "FOREACH(LINE_ELEM IN CASE WHEN S IS NOT NULL THEN [] ELSE CASE WHEN A IS NOT NULL THEN [LINE] ELSE [] END END |\n" +
            "    SET\n" +
            "        A:SECURITY,\n" +
            "        A.SECINNER_ID = LINE.SECINNER_ID,\n" +
            "        A.SOURCE = 'TEST',\n" +
            "        A.SECURITY_NM = LINE.SECURITY_NM\n" +
            "        )\n" +
            "WITH LINE\n" +
            "   WHERE ( LINE.SECINNER_ID IS NOT NULL AND NOT LINE.SECINNER_ID = '' )\n" +
            "    AND ( LINE.COMPANY_ID IS NOT NULL AND NOT LINE.COMPANY_ID = '' )\n" +
            "   MATCH (S:SECURITY{SECINNER_ID:toString(LINE.SECINNER_ID)})\n" +
            "   MATCH (C:COMPANY{COMPANY_ID:toString(LINE.COMPANY_ID)})\n" +
            "   MERGE(C)-[F:ISSUE{RELATIONSHIP:'发行'}]->(S) ;";


    private final static String DELETE_PFUND_RELATION =
            "\n// 删除已有的托管人管理人关系 \n " +
                    "MATCH (:COMPANY)-[r:MANAGER|TRUSTEE]->(:PFUND) \n" +
                    "DELETE r;";

    private final static String IMPORT_PFUND_NODE = "// 导入 PFUND 信息 \n" +
            "WITH '{jdbc_url}' AS url\n" +
            "CALL apoc.load.jdbc(url,\"\n" +
            "SELECT SECINNER_ID,MANAGER_ID,TRUSTEE_ID,B.CONSTANT_NM AS STATUS\n" +
            "FROM CS_PORTAL.PFUND_PUBLICINFO A \n" +
            "INNER JOIN CS_PORTAL.LKP_CHARCODE B\n" +
            "ON A.OPERATE_STATUS_ID = B.CONSTANT_ID\n" +
            "WHERE B.CONSTANT_TYPE = 306 AND A.ISDEL = 0  {condition} \n" +
            "\") YIELD row WITH row as LINE\n" +
            "WHERE ( LINE.SECINNER_ID IS NOT NULL AND NOT LINE.SECINNER_ID = '' )\n" +
            "    AND ( LINE.MANAGER_ID IS NOT NULL AND NOT LINE.MANAGER_ID = '' )\n" +
            "    //AND ( LINE.SECURITY_CD IS NOT NULL AND NOT LINE.SECURITY_CD = '' )\n" +
            "    WITH apoc.date.format(timestamp()+8*60*60*1000,\"ms\",\"yyyy-MM-dd HH:mm:ss\") AS TIME_STAMP,LINE\n" +
            "    MATCH (S:SECURITY{SECINNER_ID:toString(LINE.SECINNER_ID)})\n" +
            "    SET\n" +
            "        S:PFUND,\n" +
            "        S.STATUS = LINE.STATUS\n" +
            "    WITH S,TIME_STAMP, LINE\n" +
            "    MATCH (C:COMPANY{COMPANY_ID:toString(LINE.MANAGER_ID)})\n" +
            "    MERGE(C)-[F:MANAGER{RELATIONSHIP:'管理人'}]->(S)\n" +
            "    ON CREATE SET\n" +
            "        F.SOURCE = 'PFUND_PUBLICINFO',\n" +
            "        F.TIME_STAMP = TIME_STAMP\n" +
            "    WITH S,LINE,TIME_STAMP\n" +
            "    MATCH (T:COMPANY{COMPANY_ID:toString(LINE.TRUSTEE_ID)})\n" +
            "    MERGE(T)-[TR:TRUSTEE{RELATIONSHIP:'托管方'}]->(S)\n" +
            "    ON CREATE SET\n" +
            "        TR.SOURCE = 'PFUND_PUBLICINFO',\n" +
            "        TR.TIME_STAMP = TIME_STAMP;";


    private final static String IMPORT_PFCOMPANY_NODE =
            "// 导入 PFCOMPANY 信息 \n" +
            "CALL apoc.load.jdbc('{jdbc_url}',\"\n" +
            "SELECT COMPANY_ID,ORG_FORM,FUND_TYPE,IS_REVOKE,TO_CHAR(REG_DT,'YYYY-MM-DD HH24:MI:SS')REG_DT,REG_CD,TO_CHAR(UPDT_DT,'YYYY-MM-DD HH24:MI:SS') UPDT_DT ,ISDEL AS IS_DEL FROM CS_PORTAL.PFCOMPY_BASICINFO A\n" +
            " \")yield row WITH row as  LINE  \n" +
            "WHERE ( LINE.COMPANY_ID IS NOT NULL AND NOT LINE.COMPANY_ID = '' )\n" +
            "OPTIONAL MATCH  (A:COMPANY{COMPANY_ID:LINE.COMPANY_ID}) \n" +
            "OPTIONAL MATCH  (PF:PFCOMPANY{COMPANY_ID:LINE.COMPANY_ID}) \n" +
            "FOREACH(ELEM IN CASE WHEN PF IS NOT NULL AND ( LINE.IS_REVOKE = '1' OR LINE.IS_DEL = '1' ) THEN ['1'] ELSE [] END |\n" +
            "    REMOVE PF:PFCOMPANY\n" +
            "    SET \n" +
            "    PF.ORG_FORM = NULL,\n" +
            "    PF.IS_REVOKE =  NULL,\n" +
            "    PF.REG_DT = NULL,\n" +
            "    PF.REG_CD = NULL\n" +
            "    )\n" +
            "FOREACH(ELEM IN CASE WHEN PF IS NOT NULL AND NOT ( LINE.IS_REVOKE = '1' OR LINE.IS_DEL = '1' ) THEN ['1'] ELSE [] END |\n" +
            "    SET\n" +
            "        PF.ORG_FORM = LINE.ORG_FORM,\n" +
            "        PF.IS_REVOKE = LINE.IS_REVOKE,\n" +
            "        PF.REG_DT = LINE.REG_DT,\n" +
            "        PF.REG_CD = LINE.REG_CD\n" +
            "    )\n" +
            "FOREACH(ELEM IN CASE WHEN PF IS NULL AND A IS NOT NULL AND NOT ( LINE.IS_REVOKE = '1' OR LINE.IS_DEL = '1' ) THEN ['1'] ELSE [] END |\n" +
            "    SET\n" +
            "        A:PFCOMPANY,\n" +
            "        A.ORG_FORM = LINE.ORG_FORM,\n" +
            "        A.IS_REVOKE = LINE.IS_REVOKE,\n" +
            "        A.REG_DT = LINE.REG_DT,\n" +
            "        A.REG_CD = LINE.REG_CD\n" +
            "    );";


    private final static String DELETE_COMPANY_TYPE_LIST_PROPERTY =
            "\n// 删除已有的 COMPANY_TYPE_LIST 是否上市发债等属性 \n " +
            "MATCH (C:COMPANY) WHERE EXISTS(C.COMPANY_TYPE_LIST) \n" +
            "WITH C  \n " +
            "   SET C.COMPANY_TYPE_LIST = NULL;";

    private final static String ADD_COMPANY_TYPE_LIST_PROPERTY =
            "\n// 导入公开企业属性\n" +
            "WITH '{jdbc_url}' AS url\n" +
            "CALL apoc.load.jdbc(url,\"\n" +
            "SELECT   COMPANY_ID , LISTAGG(COMPANY_TYPE,',') WITHIN GROUP(ORDER BY COMPANY_TYPE) COMPANY_TYPE FROM(\n" +
            "SELECT DISTINCT B.COMPANY_ID AS COMPANY_ID, LKP1.SECURITY_TYPE AS COMPANY_TYPE FROM CS_PORTAL.SECURITY A\n" +
            "INNER JOIN    CS_PORTAL.COMPY_BASICINFO B\n" +
            "ON    A.COMPANY_ID = B.COMPANY_ID AND B.IS_DEL=0\n" +
            "INNER JOIN (SELECT CONSTANT_ID AS SECURITY_TYPE_ID, CONSTANT_NM AS SECURITY_TYPE FROM CS_PORTAL.LKP_CHARCODE WHERE CONSTANT_TYPE = 401 AND ISDEL = 0) LKP1\n" +
            "ON A.SECURITY_TYPE_ID = LKP1.SECURITY_TYPE_ID\n" +
            "WHERE A.ISDEL=0 AND  LKP1.SECURITY_TYPE IN ('A股', 'B股', 'H股', '三板股') AND A.LIST_ST IN (0,3) AND B.IS_DEL = 0 AND B.COMPANY_ST = 1\n" +
            "UNION\n" +
            "SELECT DISTINCT  B.COMPANY_ID,  '发债企业' COMPANY_TYPE FROM CS_PORTAL.SECURITY A\n" +
            "INNER JOIN CS_PORTAL.COMPY_BASICINFO B\n" +
            "ON A.COMPANY_ID= B.COMPANY_ID AND B.IS_DEL=0\n" +
            "INNER JOIN CS_PORTAL.BOND_BASICINFO C\n" +
            "ON A.SECINNER_ID = C.SECINNER_ID AND C.ISDEL=0\n" +
            "WHERE   A.ISDEL = 0 AND B.COMPANY_ST = 1 AND B.COUNTRY = 'CN'\n" +
            "UNION\n" +
            "SELECT DISTINCT B.COMPANY_ID AS COMPANY_ID, '老三版' COMPANY_TYPE FROM CS_PORTAL.SECURITY A\n" +
            "INNER JOIN    CS_PORTAL.COMPY_BASICINFO B\n" +
            "ON A.COMPANY_ID = B.COMPANY_ID AND B.IS_DEL=0\n" +
            "INNER JOIN (SELECT CONSTANT_ID AS SECURITY_TYPE_ID, CONSTANT_NM AS SECURITY_TYPE FROM CS_PORTAL.LKP_CHARCODE WHERE CONSTANT_TYPE = 401 AND ISDEL = 0) LKP1\n" +
            "ON A.SECURITY_TYPE_ID = LKP1.SECURITY_TYPE_ID\n" +
             "WHERE A.ISDEL=0 AND  LKP1.SECURITY_TYPE = '三板股' AND A.TRD_MARKET_ID = 5673 AND A.LIST_ST IN (0,3) AND B.IS_DEL = 0 AND B.COMPANY_ST = 1 \n"+
            "UNION\n" +
            "SELECT DISTINCT B.COMPANY_ID,  '私募企业' COMPANY_TYPE\n" +
            "FROM CS_PORTAL.PFCOMPY_BASICINFO A\n" +
            "INNER JOIN CS_PORTAL.COMPY_BASICINFO B\n" +
             "ON A.COMPANY_ID = B.COMPANY_ID AND A.ISDEL=0" +
             ")FF\n" +
            "GROUP BY COMPANY_ID \n" +
            "\") YIELD row WITH row as LINE\n" +
            "MATCH (C:COMPANY)\n" +
            "    WHERE C.COMPANY_ID  = LINE.COMPANY_ID\n" +
            "    WITH C,SPLIT(LINE.COMPANY_TYPE,',') AS A\n" +
            "      SET C.COMPANY_TYPE_LIST = A;";


    private final static String DELETE_SECURITY_CODE_PROPERTY =
            "\n// 删除公开企业证券代码\n" +
            "MATCH (A:COMPANY) WHERE EXISTS(A.SECURITY_CD)\n" +
                    "SET A.SECURITY_CD = NULL ;";

    private final static String ADD_SECURITY_CODE_PROPERTY =
            "\n// 导入公开企业证券代码\n" +
            "WITH '{jdbc_url}' AS url\n" +
            "CALL apoc.load.jdbc(url,\"\n" +
            "SELECT  A.COMPANY_ID COMPANY_ID,LISTAGG(C.SECURITY_SNM||':'||C.SECURITY_CD,',') WITHIN GROUP(ORDER BY LKP2.SECURITY_TYPE) SECURITY_CD\n" +
                    "FROM CS_PORTAL.COMPY_BASICINFO A\n" +
                    "    JOIN CS_PORTAL.COMPY_SECURITY_XW B ON A.COMPANY_ID=B.COMPANY_ID\n" +
                    "    JOIN CS_PORTAL.SECURITY C ON B.SECINNER_ID=C.SECINNER_ID AND C.ISDEL=0\n" +
                    "    LEFT JOIN (SELECT CONSTANT_ID AS SECURITY_TYPE_ID, CONSTANT_NM AS SECURITY_TYPE FROM CS_PORTAL.LKP_CHARCODE WHERE CONSTANT_TYPE = 401 AND ISDEL = 0) LKP2\n" +
                    "                     ON C.SECURITY_TYPE_ID = LKP2.SECURITY_TYPE_ID\n" +
                    "WHERE LKP2.SECURITY_TYPE IN ('A股', 'B股','H股','三板股') AND C.LIST_ST IN (0,3) AND A.IS_DEL = 0 AND A.COMPANY_ST = 1 AND A.COUNTRY = 'CN'\n" +
                    "GROUP BY A.COMPANY_ID" +
                    "\") YIELD row WITH row as LINE\n" +
                    "WHERE ( LINE.COMPANY_ID IS NOT NULL AND NOT LINE.COMPANY_ID = '' )\n" +
                    "    MATCH (A:COMPANY{COMPANY_ID:toString(LINE.COMPANY_ID)})\n" +
                    "    // CALL apoc.date.formatDefault(timestamp()+8*60*60*1000,'ms') yield value  as timestamp\n" +
                    "    SET\n" +
                    "        A.SECURITY_CD = toString(LINE.SECURITY_CD),\n" +
                    "        A.IS_LISTED = '1';";

    private final static String DELETE_PUBLIC_RISK_LIST_PROPERTY =
            "\n// 删除风险属性 \n" +
            "MATCH (C:COMPANY) WHERE EXISTS(C.RISK_LIST) AND EXISTS(C.COMPANY_TYPE_LIST) AND ANY(ELEM IN ['A股','B股','H股','三板股','发债企业'] WHERE ELEM IN C.COMPANY_TYPE_LIST ) \n" +
            "WITH C \n" +
            "   SET C.RISK_LIST = NULL;";

    private final static String ADD_PUBLIC_RISK_LIST_PROPERTY =
            "\n// 添加公开企业风险属性 \n" +
            "WITH '{jdbc_url}' AS url\n" +
            "CALL apoc.load.jdbc(url,\"\n" +
            "SELECT DECODE( C.COMPANY_ID,NULL,D.COMPANY_ID,C.COMPANY_ID) AS COMPANY_ID,C.BOND_VIOLATION||C.ANNOUNCE_ALARM||D.COMPY_WARNINGS AS WARNING_LABEL FROM \n" +
            "( SELECT DECODE(A.COMPANY_ID,NULL,B.COMPANY_ID,A.COMPANY_ID) AS COMPANY_ID, DECODE(A.COMPANY_ID,NULL,NULL,27||',') AS BOND_VIOLATION,DECODE(B.COMPANY_ID,NULL,NULL,26||',') AS ANNOUNCE_ALARM   FROM (SELECT DISTINCT COMPANY_ID FROM CS_PORTAL.VW_BOND_VIOLATION) A\n" +
            "FULL JOIN (SELECT DISTINCT COMPANY_ID FROM CS_PORTAL.COMPY_ANNOUNCE_ALARM) B\n" +
            "ON A.COMPANY_ID = B.COMPANY_ID ) C\n" +
            "FULL JOIN (SELECT COMPANY_ID,WM_CONCAT(TYPE_ID) AS COMPY_WARNINGS \n" +
            "FROM (\n" +
            "SELECT DISTINCT COMPANY_ID,\n" +
            "CASE \n" +
            "WHEN TYPE_ID = 10 OR TYPE_ID = 12 THEN 21\n" +
            "WHEN TYPE_ID = 101 OR TYPE_ID = 102 OR TYPE_ID = 103 OR TYPE_ID = 104 OR TYPE_ID = 105 THEN 22\n" +
            "WHEN TYPE_ID = 106 OR TYPE_ID = 107 THEN 23\n" +
            "WHEN TYPE_ID = 108 THEN 24\n" +
            "WHEN TYPE_ID = 109 OR TYPE_ID = 110  THEN 25\n" +
            "END AS TYPE_ID\n" +
            "FROM CS_PORTAL.VW_COMPY_WARNINGS) GROUP BY COMPANY_ID ) D\n" +
            "ON C.COMPANY_ID = D.COMPANY_ID " +
            "\") YIELD row WITH row as LINE\n" +
            "MATCH (C:COMPANY) WHERE C.COMPANY_ID  = LINE.COMPANY_ID \n" +
            "WITH C,SPLIT(LINE.WARNING_LABEL,',') AS A \n" +
            "   SET C.RISK_LIST = A;";

    private final static String DELETE_WORKER_RELATION_FROM_MANAGELEVEL =
            "\n// 删除历史高管 \n" +
            "WITH '{jdbc_url}' AS url\n" +
            "CALL apoc.load.jdbc(url,\"\n" +
            "SELECT DISTINCT A.COMPANY_ID\n" +
            " FROM CS_PORTAL.COMPY_MANAGELEVEL A\n" +
            "LEFT JOIN CS_PORTAL.LKP_CHARCODE B ON B.CONSTANT_ID = A.HIGHEST_DEGREE AND B.CONSTANT_TYPE = '17' AND B.ISDEL = 0\n" +
            "LEFT JOIN CS_PORTAL.LKP_CHARCODE C ON C.CONSTANT_ID = A.PSTN_CD AND C.CONSTANT_TYPE = '6' AND C.ISDEL = 0\n" +
            "INNER JOIN ( SELECT  COMPANY_ID,MAX(BOARD_SESSION) BOARD_SESSION FROM CS_PORTAL.COMPY_MANAGELEVEL\n" +
            "WHERE ISDEL = 0 AND STATUS = 2 GROUP BY COMPANY_ID  ) D ON  A.BOARD_SESSION = D.BOARD_SESSION  AND A.COMPANY_ID = D.COMPANY_ID\n" +
            "AND A.ISDEL = 0 AND A.STATUS = 2\n" +
            " {condition}   -- AND A.COMPANY_ID = 513847\n" +
            "\") YIELD row WITH row as LINE\n" +
            "MATCH (C:COMPANY{COMPANY_ID:LINE.COMPANY_ID})  \n" +
            "// 只对公开企业补充\n" +
            "WHERE EXISTS(C.COMPANY_TYPE_LIST) AND ANY(ELEM IN ['A股','B股','H股','三板股'] WHERE ELEM IN C.COMPANY_TYPE_LIST )   \n" +
            "MATCH (C)<-[R:WORK]-() WHERE NOT R.POSITION = '法定代表人'  \n" +
            "   DELETE R;\n";

    private final static String ADD_WORKER_RELATION_FROM_MANAGELEVEL =
            "\n// 更新公众企业高管关系 \n" +
            "WITH '{jdbc_url}' AS url\n" +
            "CALL apoc.load.jdbc(url,\"\n" +
            "SELECT A.COMPANY_ID,SRC_PERSON_CD AS PERSON_ID,DECODE(C.CONSTANT_NM, NULL, '董监高', C.CONSTANT_NM)  AS POSITION, A.PERSON_NM ,\n" +
            "A.BIRTH_YEAR,\n" +
            "A.BIRTH_MONTH,\n" +
            "A.SRC_PERSON_CD,\n" +
            "TO_CHAR(A.START_DT,'YYYY-MM-DD HH24:MI:SS' ) START_DT,\n" +
            "TO_CHAR(A.NOTICE_DT, 'YYYY-MM-DD HH24:MI:SS') NOTICE_DT,\n" +
            "A.ISDEL AS IS_DELETED,\n" +
            "TO_CHAR(A.UPDT_DT,'YYYY-MM-DD HH24:MI:SS' ) UPDT_DT,\n" +
            " DECODE(A.SEX, 0, '男', 1, '女', 2, '未知') AS SEX,\n" +
            " B.CONSTANT_NM AS HIGHEST_DEGREE\n" +
            " FROM CS_PORTAL.COMPY_MANAGELEVEL A\n" +
            "LEFT JOIN CS_PORTAL.LKP_CHARCODE B ON B.CONSTANT_ID = A.HIGHEST_DEGREE AND B.CONSTANT_TYPE = '17' AND B.ISDEL = 0\n" +
            "LEFT JOIN CS_PORTAL.LKP_CHARCODE C ON C.CONSTANT_ID = A.PSTN_CD AND C.CONSTANT_TYPE = '6' AND C.ISDEL = 0\n" +
            "INNER JOIN ( SELECT  COMPANY_ID,MAX(BOARD_SESSION) BOARD_SESSION FROM CS_PORTAL.COMPY_MANAGELEVEL\n" +
            "WHERE ISDEL = 0 AND STATUS = 2 GROUP BY COMPANY_ID  ) D ON  A.BOARD_SESSION = D.BOARD_SESSION  AND A.COMPANY_ID = D.COMPANY_ID\n" +
            "AND A.ISDEL = 0 AND A.STATUS = 2\n" +
            "{condition}    -- AND A.COMPANY_ID = 513847\n" +
            "\") YIELD row WITH row as LINE\n" +
            "WHERE ( LINE.PERSON_ID IS NOT NULL AND NOT LINE.PERSON_ID = '' )\n" +
            "    AND ( LINE.COMPANY_ID IS NOT NULL AND NOT LINE.COMPANY_ID = '' )\n" +
            "    WITH apoc.date.format(timestamp()+8*60*60*1000,\"ms\",\"yyyy-MM-dd HH:mm:ss\") AS TIME_STAMP,LINE\n" +
            "    MATCH (C:COMPANY{COMPANY_ID:LINE.COMPANY_ID}) WHERE   EXISTS(C.COMPANY_TYPE_LIST) AND ANY(ELEM IN ['A股','B股','H股','三板股'] WHERE ELEM IN C.COMPANY_TYPE_LIST )  \n" +
            "    // 只对公开企业补充\n" +
            "    // WHERE (NOT S.SHA_INFO_COMPLETE = '1' OR NOT EXISTS(S.SHA_INFO_COMPLETE))  AND (NOT S.COMPANY_TYPE ='1' OR NOT EXISTS(S.COMPANY_TYPE))\n" +
            "    WITH C,LINE,TIME_STAMP\n" +
            "        MERGE (P:PERSON{PERSON_ID:LINE.COMPANY_ID+LINE.PERSON_NM})\n" +
            "            SET\n" +
            "                P.SOURCE= 'COMPY_MANAGELEVEL',\n" +
            "                P.TIME_STAMP = TIME_STAMP,\n" +
            "                P.SRC_PERSON_CD = LINE.SRC_PERSON_CD,\n" +
            "                P.PERSON_NM = LINE.PERSON_NM \n" +
            "        WITH C,LINE,TIME_STAMP,P\n" +
            "        MERGE (P)-[r:WORK{POSITION:LINE.POSITION}]->(C);\n" ;


    public final static String DELETE_TOP10SHAREHOLDER_RELATION =
            "\n// 更新 公众企业前十大股东 信息 \n" +
            "WITH '{jdbc_url}' AS url\n" +
            "CALL apoc.load.jdbc(url,\"\n" +
            "SELECT DISTINCT COMPANY_ID\n" +
            "    -- LATEST_END_DT,COMPANY_ID, TO_CHAR(NOTICE_DT,'YYYY-MM-DD HH24:MI:SS')NOTICE_DT,RANK,SHARE_TYPE,SHAREHD_ID,SHAREHD_ID_N,SHAREHDNAME,SHAREHD_TYPEID,SHAREHD_RATIO,CONSTANT_NM,TO_CHAR(UPDT_DT,'YYYY-MM-DD HH24:MI:SS' )UPDT_DT,ISDEL AS IS_DEL\n" +
            "    FROM\n" +
            "        (\n" +
            "            SELECT\n" +
            "                LATEST_END_DT,\n" +
            "                B.ISDEL,\n" +
            "                COMPANY_ID,\n" +
            "                NOTICE_DT,\n" +
            "                RANK,\n" +
            "                SHARE_TYPE,\n" +
            "                SHAREHD_ID,\n" +
            "                CASE\n" +
            "                    WHEN SHAREHD_ID IS NULL\n" +
            "                    AND C.CONSTANT_NM = '个人'\n" +
            "                    THEN COMPANY_ID||SHAREHDNAME\n" +
            "                    WHEN SHAREHD_ID IS NULL\n" +
            "                    AND NOT C.CONSTANT_NM = '个人'\n" +
            "                    THEN SHAREHDNAME\n" +
            "                    ELSE SHAREHD_ID\n" +
            "                END SHAREHD_ID_N,\n" +
            "                SHAREHDNAME,\n" +
            "                SHAREHD_TYPEID,\n" +
            "                SHAREHD_RATIO,\n" +
            "                B.UPDT_DT,\n" +
            "                C.CONSTANT_NM\n" +
            "            FROM\n" +
            "                (\n" +
            "                    SELECT\n" +
            "                        -- MAX(NOTICE_DT) OVER (PARTITION BY A.COMPANY_ID,RANK ORDER BY END_DT DESC) AS\n" +
            "                        -- LATEST_NOTICE_DT,\n" +
            "                        MAX(A.END_DT) OVER (PARTITION BY A.COMPANY_ID) AS LATEST_END_DT,\n" +
            "                        A.END_DT,\n" +
            "                        A.COMPANY_ID,\n" +
            "                        A.NOTICE_DT,\n" +
            "                        A.RANK,\n" +
            "                        A.SHARE_TYPE,\n" +
            "                        DECODE(A.SHAREHD_ID, NULL,F.SRC_PERSON_CD ,A.SHAREHD_ID) SHAREHD_ID,\n" +
            "                        A.SHAREHDNAME,\n" +
            "                        A.SHAREHD_TYPEID,\n" +
            "                        A.SHAREHD_RATIO,\n" +
            "                        A.ISDEL,\n" +
            "                        A.UPDT_DT\n" +
            "                    FROM\n" +
            "                        CS_PORTAL.COMPY_SHAREHOLDER A\n" +
            "                    LEFT JOIN (\n" +
            "                            SELECT DISTINCT\n" +
            "                                COMPANY_ID,\n" +
            "                                PERSON_NM,\n" +
            "                                SRC_PERSON_CD\n" +
            "                            FROM\n" +
            "                                CS_PORTAL.COMPY_MANAGELEVEL) F\n" +
            "                        -- CS_PORTAL.COMPY_MANAGELEVEL) F\n" +
            "                    ON\n" +
            "                        A.COMPANY_ID||A.SHAREHDNAME = F.COMPANY_ID||F.PERSON_NM\n" +
            "                    WHERE\n" +
            "                        RANK IS NOT NULL\n" +
            "                        -- AND TO_CHAR(A.UPDT_DT,'YYYY-MM-DD') < TO_CHAR(SYSDATE,'YYYY-MM-DD')\n" +
            "                -- AND TO_CHAR(A.UPDT_DT,'YYYY-MM-DD') >= TO_CHAR(SYSDATE-1,'YYYY-MM-DD')\n" +
            "                )B\n" +
            "            INNER JOIN\n" +
            "                CS_PORTAL.LKP_CHARCODE C\n" +
            "            ON\n" +
            "                B.SHAREHD_TYPEID = C.CONSTANT_ID\n" +
            "            AND C.CONSTANT_TYPE = 13\n" +
            "            WHERE\n" +
            "                -- LATEST_NOTICE_DT = NOTICE_DT\n" +
            "                LATEST_END_DT = END_DT\n" +
            "            --AND NOTICE_DT >= TO_DATE('2014-12-31','YYYY-MM-DD')\n" +
            "            AND RANK <11\n" +
            "            --WHERE ROWNUM < 1000\n" +
            "            )  {condition} \n" +
            "\") YIELD row WITH row as LINE\n" +
            " WHERE ( LINE.COMPANY_ID IS NOT NULL AND NOT LINE.COMPANY_ID = '' )\n" +
            "    //AND ( LINE.SHAREHD_ID IS NOT NULL AND NOT LINE.SHAREHD_ID = '' )\n" +
            "    MATCH (C:COMPANY{COMPANY_ID:toString(LINE.COMPANY_ID)})\n" +
            "    WHERE  EXISTS(C.COMPANY_TYPE_LIST) AND ANY(ELEM IN ['A股','B股','H股','三板股'] WHERE ELEM IN C.COMPANY_TYPE_LIST ) \n" +
            "    MATCH ()-[R:INVEST]->(C)\n" +
            "    DELETE R; \n";

    private final static String ADD_TOP10SHAREHOLDER=
            "\n// 更新 前十大股东 信息  \n" +
            "WITH '{jdbc_url}' AS url \n" +
            "CALL apoc.load.jdbc(url,\" \n" +
            "SELECT LATEST_END_DT,COMPANY_ID, TO_CHAR(NOTICE_DT,'YYYY-MM-DD HH24:MI:SS')NOTICE_DT,RANK,SHARE_TYPE,SHAREHD_ID,SHAREHD_ID_N,SHAREHDNAME,SHAREHD_TYPEID,SHAREHD_RATIO,CONSTANT_NM,TO_CHAR(UPDT_DT,'YYYY-MM-DD HH24:MI:SS' )UPDT_DT,ISDEL AS IS_DEL \n" +
            "    FROM \n" +
            "        ( \n" +
            "            SELECT \n" +
            "                LATEST_END_DT, \n" +
            "                B.ISDEL, \n" +
            "                COMPANY_ID, \n" +
            "                NOTICE_DT, \n" +
            "                RANK, \n" +
            "                SHARE_TYPE, \n" +
            "                SHAREHD_ID, \n" +
            "                CASE \n" +
            "                    WHEN SHAREHD_ID IS NULL \n" +
            "                    AND C.CONSTANT_NM = '个人' \n" +
            "                    THEN COMPANY_ID||SHAREHDNAME \n" +
            "                    WHEN SHAREHD_ID IS NULL \n" +
            "                    AND NOT C.CONSTANT_NM = '个人' \n" +
            "                    THEN SHAREHDNAME \n" +
            "                    ELSE SHAREHD_ID \n" +
            "                END SHAREHD_ID_N, \n" +
            "                SHAREHDNAME, \n" +
            "                SHAREHD_TYPEID, \n" +
            "                SHAREHD_RATIO, \n" +
            "                B.UPDT_DT, \n" +
            "                C.CONSTANT_NM \n" +
            "            FROM \n" +
            "                ( \n" +
            "                    SELECT \n" +
            "                        -- MAX(NOTICE_DT) OVER (PARTITION BY A.COMPANY_ID,RANK ORDER BY END_DT DESC) AS \n" +
            "                        -- LATEST_NOTICE_DT, \n" +
            "                        MAX(A.END_DT) OVER (PARTITION BY A.COMPANY_ID) AS LATEST_END_DT, \n" +
            "                        A.END_DT, \n" +
            "                        A.COMPANY_ID, \n" +
            "                        A.NOTICE_DT, \n" +
            "                        A.RANK, \n" +
            "                        A.SHARE_TYPE, \n" +
            "                        DECODE(A.SHAREHD_ID, NULL,F.SRC_PERSON_CD ,A.SHAREHD_ID) SHAREHD_ID, \n" +
            "                        A.SHAREHDNAME, \n" +
            "                        A.SHAREHD_TYPEID, \n" +
            "                        A.SHAREHD_RATIO, \n" +
            "                        A.ISDEL, \n" +
            "                        A.UPDT_DT \n" +
            "                    FROM \n" +
            "                        CS_PORTAL.COMPY_SHAREHOLDER A \n" +
            "                    LEFT JOIN ( \n" +
            "                            SELECT DISTINCT \n" +
            "                                COMPANY_ID, \n" +
            "                                PERSON_NM, \n" +
            "                                SRC_PERSON_CD \n" +
            "                            FROM \n" +
            "                                CS_PORTAL.COMPY_MANAGELEVEL) F \n" +
            "                        -- CS_PORTAL.COMPY_MANAGELEVEL) F \n" +
            "                    ON \n" +
            "                        A.COMPANY_ID||A.SHAREHDNAME = F.COMPANY_ID||F.PERSON_NM \n" +
            "                    WHERE \n" +
            "                        RANK IS NOT NULL \n" +
            "                        -- AND TO_CHAR(A.UPDT_DT,'YYYY-MM-DD') < TO_CHAR(SYSDATE,'YYYY-MM-DD') \n" +
            "                -- AND TO_CHAR(A.UPDT_DT,'YYYY-MM-DD') >= TO_CHAR(SYSDATE-1,'YYYY-MM-DD') \n" +
            "                )B \n" +
            "            INNER JOIN \n" +
            "                CS_PORTAL.LKP_CHARCODE C \n" +
            "            ON \n" +
            "                B.SHAREHD_TYPEID = C.CONSTANT_ID \n" +
            "            AND C.CONSTANT_TYPE = 13 \n" +
            "            WHERE \n" +
            "                -- LATEST_NOTICE_DT = NOTICE_DT \n" +
            "                LATEST_END_DT = END_DT \n" +
            "            --AND NOTICE_DT >= TO_DATE('2014-12-31','YYYY-MM-DD') \n" +
            "            AND RANK <11 \n" +
            "            --WHERE ROWNUM < 1000 \n" +
            "            )        {condition} \n" +
            "\") YIELD row WITH row as LINE \n" +
            "MATCH (A:COMPANY{COMPANY_ID:LINE.COMPANY_ID}) WHERE EXISTS(A.COMPANY_TYPE_LIST) AND ANY(ELEM IN ['A股','B股','H股','三板股'] WHERE ELEM IN A.COMPANY_TYPE_LIST ) \n" +
            "OPTIONAL MATCH  (C:COMPANY{COMPANY_ID:LINE.SHAREHD_ID_N}) WHERE NOT LINE.CONSTANT_NM = '个人' \n" +
            "OPTIONAL MATCH  (S:SECURITY{SECINNER_ID:LINE.SHAREHD_ID_N}) WHERE NOT LINE.CONSTANT_NM = '个人' \n" +
            "FOREACH(ELEM IN CASE WHEN C IS NOT NULL AND NOT LINE.CONSTANT_NM IN ['企业年金','证券投资基金', '信托计划', '基金资产管理计划', '集合理财计划','全国社保基金','保险产品','个人' ] THEN ['1'] ELSE [] END | \n" +
            "    MERGE (C)-[R:INVEST]->(A) \n" +
            "    SET \n" +
            "        R.SHA_RATIO=toString(LINE.SHAREHD_RATIO) \n" +
            "    ) \n" +
            "FOREACH(ELEM IN CASE WHEN S IS NOT NULL AND  LINE.CONSTANT_NM IN ['企业年金','证券投资基金', '信托计划', '基金资产管理计划', '集合理财计划','全国社保基金','保险产品' ] THEN ['1'] ELSE [] END | \n" +
            "    MERGE (S)-[R:INVEST]->(A) \n" +
            "    SET \n" +
            "        R.SHA_RATIO=toString(LINE.SHAREHD_RATIO) \n" +
            "    ) \n" +
            "FOREACH(ELEM IN CASE WHEN C IS  NULL AND S IS NULL THEN ['1'] ELSE [] END | \n" +
            "    MERGE (P:PERSON{PERSON_ID:LINE.COMPANY_ID+LINE.SHAREHDNAME}) \n" +
            "       ON CREATE SET P.PERSON_NM = LINE.SHAREHDNAME \n" +
            "    MERGE (P)-[R:INVEST]->(A) \n" +
            "    SET \n" +
            "        R.SHA_RATIO=toString(LINE.SHAREHD_RATIO) \n" +
            "    ); \n";


    private final static String DELETE_CONTROL_RELATION =
            "\n// 删除控制人信息 \n" +
            "MATCH ()-[R:CONTROLLER]->(A:COMPANY) \n " +
            "WHERE  EXISTS(A.COMPANY_TYPE_LIST) AND ANY(ELEM IN ['A股','B股','H股','三板股'] WHERE ELEM IN A.COMPANY_TYPE_LIST ) \n" +
            "DELETE R; ";

    private final static String CREATE_RELATION_AFFIL =
            "\n// 添加控制人信息 \n" +
            "WITH '{jdbc_url}' AS url \n" +
            "CALL apoc.load.jdbc(url,\" \n" +
            "SELECT  COMPANY_ID, AFFIL_PARTY,AFFIL_PARTY_ID,\n" +
            "    RELATION_TYPE,INO_SHA_RATIO,TO_CHAR(RPT_DT, 'YYYY-MM-DD HH24:MI:SS') RPT_DT,ISDEL AS IS_DEL,TO_CHAR(LATEST_RPT_DT, 'YYYY-MM-DD HH24:MI:SS')LATEST_RPT_DT,TO_CHAR(UPDT_DT,\n" +
            "    'YYYY-MM-DD HH24:MI:SS') UPDT_DT  FROM (SELECT MAX(RPT_DT) OVER(PARTITION BY COMPANY_ID ) LATEST_RPT_DT ,T.* FROM (\n" +
            "SELECT B.CONSTANT_NM,A.*,B.CONSTANT_NM AS RELATION_TYPE FROM CS_PORTAL.COMPY_AFFILPARTY A  LEFT JOIN\n" +
            "                    CS_PORTAL.LKP_CHARCODE B\n" +
            "                ON\n" +
            "                    A.RELATION_TYPE_ID = B.CONSTANT_ID WHERE (\n" +
            "                        B.CONSTANT_NM='实际控制人'\n" +
            "                    OR  B.CONSTANT_NM='最终控制方'\n" +
            "                    OR  B.CONSTANT_NM='控股股东')\n" +
            "                    -- AND TO_CHAR(A.UPDT_DT,'YYYY-MM-DD') < TO_CHAR(SYSDATE,'YYYY-MM-DD')\n" +
            "                    -- AND TO_CHAR(A.UPDT_DT,'YYYY-MM-DD') >= TO_CHAR(SYSDATE-1,'YYYY-MM-DD')\n" +
            "    ) T )WHERE RPT_DT =LATEST_RPT_DT\n" +
            "\") YIELD row WITH row as LINE\n" +
            "WHERE ( LINE.COMPANY_ID IS NOT NULL AND NOT LINE.COMPANY_ID = '' )\n" +
            "    // AND LINE.AFFIL_PARTY_ID IS   NULL \n" +
            "    AND NOT LINE.AFFIL_PARTY = '无'\n" +
            "WITH apoc.date.format(timestamp()+8*60*60*1000,\"ms\",\"yyyy-MM-dd HH:mm:ss\") AS TIME_STAMP,LINE\n" +
            "MATCH (C:COMPANY{COMPANY_ID:toString(LINE.COMPANY_ID)}) WHERE  EXISTS(C.COMPANY_TYPE_LIST) AND ANY(ELEM IN ['A股','B股','H股','三板股'] WHERE ELEM IN C.COMPANY_TYPE_LIST )\n" +
            "WITH LINE, C,TIME_STAMP\n" +
            "OPTIONAL MATCH (B:COMPANY{COMPANY_ID:toString(LINE.AFFIL_PARTY_ID)})\n" +
            "FOREACH(ELEM IN CASE WHEN B IS NOT NULL THEN [1] ELSE [] END |\n" +
            "    MERGE (B)-[R:CONTROLLER{RELATION_TYPE:toString(LINE.RELATION_TYPE)}]->(C)\n" +
            "    ON CREATE SET\n" +
            "        R.SOURCE= 'COMPY_AFFILPARTY',\n" +
            "        R.IS_DEL=toString(LINE.IS_DEL)\n" +
            "        )\n" +
            "WITH TIME_STAMP,LINE,C\n" +
            "FOREACH(ELEM IN CASE WHEN (LINE.AFFIL_PARTY_ID IS NULL OR LINE.AFFIL_PARTY_ID ='') AND NOT LINE.AFFIL_PARTY = '无' THEN ['1'] ELSE [] END | \n" +
            "     MERGE (B:PERSON{PERSON_ID:LINE.COMPANY_ID+toString(LINE.AFFIL_PARTY)})\n" +
            "        ON CREATE SET\n" +
            "            B.PERSON_NM = toString(LINE.AFFIL_PARTY),\n" +
            "            B.SOURCE= 'COMPY_AFFILPARTY',\n" +
            "            B.TIME_STAMP = TIME_STAMP\n" +
            "     MERGE (B)-[r:CONTROLLER{RELATION_TYPE:toString(LINE.RELATION_TYPE)}]->(C)\n" +
            "        ON CREATE SET\n" +
            "        r.SOURCE= 'COMPY_AFFILPARTY',\n" +
            "        r.IS_DEL=toString(LINE.IS_DEL));";

    private final static String CREATE_RELATION_FAMILY =
            "\n// 创建亲属关系\n" +
            "WITH '{jdbc_url}' AS url \n"+
            "CALL apoc.load.jdbc(url,\" \n"+
            "SELECT  COMPANY_ID,SHAREHD_NM,PERSON_NM,POSITION,CONSTANT_NM,ISDEL AS IS_DEL  FROM (SELECT \n"+
            "        DISTINCT \n"+
            "        COMPANY_ID , --公司代码 \n"+
            "        --NOTICE_DT , --公告日期 \n"+
            "        --CHANGE_DT , --变动日期 \n"+
            "        --SHAREHD_ID , --持股人代码 \n"+
            "        SHAREHD_NM , --持股人 \n"+
            "        PERSON_NM , --高管姓名 \n"+
            "        POSITION , --高管职务 \n"+
            "        --RELATION_CD , --与高管关系 \n"+
            "        B.CONSTANT_NM, --高管关系 \n"+
            "        --BECHANGE_NUM , --变动前持股数 \n"+
            "        --AFCHANGE_NUM , --变动后持股数 \n"+
            "        --CHANGE_NUM , --本次变动数 \n"+
            "        --AVG_PRICE , --成交均价 \n"+
            "        --CHANGE_RATE , --变动比例 \n"+
            "        --CHANGE_REASON , --变动原因 \n"+
            "        --IS_SHORT_TRADE , --是否短线交易 \n"+
            "        --DATA_SRC , --信息来源 \n"+
            "        --REMARK , --备注 \n"+
            "        --SRC_PERSON_CD , --高管代码 \n"+
            "        A.ISDEL --是否删除 \n"+
            "        FROM CS_PORTAL.COMPY_MGRRELHOLDINGS A \n"+
            "        LEFT JOIN CS_PORTAL.LKP_NUMBCODE B \n"+
            "        ON A.RELATION_CD = B.CONSTANT_CD \n"+
            "        WHERE CONSTANT_TYPE = 45 /*AND SHAREHD_NM = PERSON_NM*/ ) \n"+
            "\") YIELD row WITH row as LINE \n"+
            " WHERE (LINE.COMPANY_ID IS NOT NULL AND NOT LINE.COMPANY_ID = '' ) \n"+
            "        AND NOT ( LINE.SHAREHD_NM IS NULL OR LINE.PERSON_NM IS NULL) \n"+
            "        AND NOT LINE.CONSTANT_NM ='其他组织' \n"+
            "        // WITH apoc.date.format(timestamp()+8*60*60*1000,\"ms\",\"yyyy-MM-dd HH:mm:ss\") AS TIME_STAMP,LINE \n"+
            "        MATCH (C:COMPANY{COMPANY_ID:toString(LINE.COMPANY_ID)}) \n"+
            "        MERGE (P1:PERSON{PERSON_ID:toString(LINE.COMPANY_ID)+toString(LINE.SHAREHD_NM)}) \n"+
            "        ON CREATE SET \n"+
            "            P1.PERSON_NM = toString(LINE.SHAREHD_NM) \n"+
            "            // P1.SOURCE= 'COMPY_MGRRELHOLDINGS'  \n"+
            "        MERGE (P2:PERSON{PERSON_ID:toString(LINE.COMPANY_ID)+toString(LINE.PERSON_NM)}) \n"+
            "        ON CREATE SET \n"+
            "            P2.PERSON_NM = toString(LINE.PERSON_NM) \n"+
            "            // P2.SOURCE= 'COMPY_MGRRELHOLDINGS'  \n"+
            "        MERGE (P1)-[R:RELATIVE{RELATION_TYPE:toString(LINE.CONSTANT_NM)}]->(P2) \n"+
            "         ; \n";


    private final static String DELETE_RELATION_GUARANTEE =
            "\n// 删除担保关系\n" +
            "MATCH (:COMPANY)-[G:GUARANTEE]->(:COMPANY) \n" +
            "DELETE G;\n";

    private final static String CREATE_RELATION_GUARANTEE =
            "\n// 创建担保关系\n" +
            "WITH '{jdbc_url}' AS url \n" +
            "CALL apoc.load.jdbc(url,\" \n" +
            "SELECT GUAR_COMPANY_ID,GUAR_COMPANY_NM,BUAR_COMPANY_ID,\n" +
            "    BUAR_COMPANY_NM,IS_RLTRADE,TO_CHAR(TRADE_DT,'YYYY-MM-DD HH24:MI:SS')TRADE_DT,GUAR_DEADLINE,\n" +
            "    TO_CHAR(GUAR_START_DT,'YYYY-MM-DD HH24:MI:SS') GUAR_START_DT,\n" +
            "    TO_CHAR(GUAR_END_DT,'YYYY-MM-DD HH24:MI:SS') GUAR_END_DT,GUAR_AMT,CURRENCY,GUAR_METHOD,IS_DELETED AS IS_DEL,\n" +
            "    TO_CHAR(UPDT_DT,'YYYY-MM-DD HH24:MI:SS')UPDT_DT\n" +
            "FROM\n" +
            "    (\n" +
            "        SELECT\n" +
            "            B.COMPANY_ID AS GUAR_COMPANY_ID,\n" +
            "            A.GUAR_COMPANY_NM,\n" +
            "            C.COMPANY_ID AS BUAR_COMPANY_ID,\n" +
            "            A.BUAR_COMPANY_NM,\n" +
            "            A.IS_RLTRADE,\n" +
            "            A.TRADE_DT,\n" +
            "            A.GUAR_DEADLINE,\n" +
            "            --TO_CHAR(A.GUAR_DEADLINE,'YYYY-MM-DD HH24:MI:SS') AS GUAR_DEADLINE,\n" +
            "            A.GUAR_START_DT,\n" +
            "            -- TO_CHAR(A.GUAR_START_DT,'YYYY-MM-DD HH24:MI:SS') AS GUAR_START_DT,\n" +
            "            A.GUAR_END_DT,\n" +
            "            -- TO_CHAR(A.GUAR_END_DT,'YYYY-MM-DD HH24:MI:SS') AS GUAR_END_DT,\n" +
            "            A.GUAR_AMT,\n" +
            "            A.CURRENCY,\n" +
            "            A.GUAR_METHOD ,\n" +
            "            A.ISDEL AS IS_DELETED,\n" +
            "            A.UPDT_DT\n" +
            "        FROM\n" +
            "            CS_PORTAL.COMPY_GUARANTEE A\n" +
            "        LEFT JOIN\n" +
            "            CS_PORTAL.COMPY_BASICINFO B\n" +
            "        ON\n" +
            "            A.GUAR_COMPANY_NM = B.COMPANY_NM\n" +
            "        LEFT JOIN\n" +
            "            CS_PORTAL.COMPY_BASICINFO C\n" +
            "        ON\n" +
            "            A.BUAR_COMPANY_NM = C.COMPANY_NM\n" +
            "        WHERE\n" +
            "            TO_CHAR(GUAR_END_DT,'YYYY-MM-DD ') > TO_CHAR(SYSDATE,'YYYY-MM-DD ')\n" +
            "            -- AND TO_CHAR(A.UPDT_DT,'YYYY-MM-DD') < TO_CHAR(SYSDATE,'YYYY-MM-DD')\n" +
            "            -- AND TO_CHAR(A.UPDT_DT,'YYYY-MM-DD') >= TO_CHAR(SYSDATE-1,'YYYY-MM-DD')\n" +
            "            --AND ROWNUM < 1000\n" +
            "        -- AND TO_CHAR(A.UPDT_DT,'YYYY-MM-DD') < TO_CHAR(SYSDATE,'YYYY-MM-DD')\n" +
            "        -- AND TO_CHAR(A.UPDT_DT,'YYYY-MM-DD') >= TO_CHAR(SYSDATE-1,'YYYY-MM-DD')\n" +
            "        )C \n" +
            "\") YIELD row WITH row as LINE\n" +
            "WHERE  ( LINE.GUAR_COMPANY_NM IS NOT NULL AND NOT LINE.GUAR_COMPANY_NM = '' )\n" +
            "    AND ( LINE.BUAR_COMPANY_NM IS NOT NULL AND NOT LINE.BUAR_COMPANY_NM = '' )\n" +
            "    AND NOT (LINE.GUAR_AMT IS NULL OR LINE.GUAR_AMT = '') \n" +
            " WITH LINE.GUAR_COMPANY_ID AS GUAR_COMPANY_ID,LINE.GUAR_AMT AS GUAR_AMT,LINE.GUAR_COMPANY_NM AS GUAR_COMPANY_NM ,LINE.BUAR_COMPANY_ID AS BUAR_COMPANY_ID, LINE.BUAR_COMPANY_NM AS BUAR_COMPANY_NM , apoc.date.format(timestamp()+8*60*60*1000,\"ms\",\"yyyy-MM-dd HH:mm:ss\") AS TIME_STAMP,LINE\n" +
            "MATCH (A:COMPANY{COMPANY_ID:LINE.GUAR_COMPANY_ID})\n" +
            "MATCH (B:COMPANY{COMPANY_ID:LINE.BUAR_COMPANY_ID}) \n" +
            "WITH TIME_STAMP,A,B,COLLECT({GUAR_AMT:GUAR_AMT,TRADE_DT:LINE.TRADE_DT, GUAR_DEADLINE:LINE.GUAR_DEADLINE,IS_RLTRADE:LINE.IS_RLTRADE,GUAR_END_DT:LINE.GUAR_END_DT,GUAR_START_DT:toString(LINE.GUAR_START_DT) }) AS GUAR_INFO\n" +
            "MERGE (A)-[R:GUARANTEE]->(B)\n" +
            "    SET R.GUAR_INFO =  [ELEM IN GUAR_INFO|apoc.convert.toJson(ELEM)],\n" +
            "        R.TIME_STAMP= TIME_STAMP;";

    public final static String UPDATE_GUARANTEE_TOTAL =
            "MATCH (A:COMPANY)-[r:`GUARANTEE`]->(B:COMPANY)  \n" +
            "WITH A,B,SUM(toFloat(r.GUAR_AMT)) AS S_GUAR_AMT,apoc.date.format(timestamp()+8*60*60*1000,\"ms\",\"yyyy-MM-dd HH:mm:ss\") AS TIME_STAMP\n" +
            "MERGE (A)-[R:`GUARANTEE_TOTAL`]->(B)\n" +
            "    SET\n" +
            "    R.TOTAL_GUAR_AMT = S_GUAR_AMT,\n" +
            "    R.TIME_STAMP = TIME_STAMP\n" +
            "    ;";


    private final static String DELETE_CUST_SUPPLIER_RELATION =
            "\n// 删除已有的托管人管理人关系 \n " +
                    "MATCH (:COMPANY)-[r:CUSTOMER|SUPPLIER]->(:COMPANY) \n" +
                    "DELETE r;";



    private final static String CREATE_RELATION_CUSTOMER =
            "\n//添加主要客户信息\n" +
            "WITH '{jdbc_url}' AS url\n" +
            "CALL apoc.load.jdbc(url,\"\n" +
            "SELECT COMPANY_ID,TO_CHAR(RPT_DT,'yyyy-mm-dd HH24:MI:SS')RPT_DT,CUSTOMER_ID,CUSTOMER_NM,TO_CHAR(START_DT,'yyyy-mm-dd HH24:MI:SS')START_DT,AMT,PCT_REVENUE_SUM,RELATIONSHIP,ISDEL AS IS_DEL,TO_CHAR(LATEST_RPT_DT,'yyyy-mm-dd HH24:MI:SS')LATEST_RPT_DT\n" +
            "FROM\n" +
            "    ( SELECT t.*,\n" +
            "             MAX(RPT_DT) over(partition BY COMPANY_ID ORDER BY RPT_DT DESC )  LATEST_RPT_DT\n" +
            "        FROM ( SELECT\n" +
            "                    COMPANY_ID,\n" +
            "                    RPT_DT,\n" +
            "                    CUSTOMER_ID,\n" +
            "                    CUSTOMER_NM ,\n" +
            "                    START_DT,\n" +
            "                    PCT_REVENUE_SUM,\n" +
            "                    AMT,\n" +
            "                    RELATIONSHIP,\n" +
            "                    ISDEL\n" +
            "                FROM CS_PORTAL.COMPY_TOP5CUST ) t ) m\n" +
            "WHERE\n" +
            "    LATEST_RPT_DT = RPT_DT\n" +
            "    --AND RPT_DT >= TO_DATE('2014-12-31','YYYY-MM-DD')\n" +
            "   -- ORDER BY COMPANY_ID\n" +
            "\") YIELD row WITH row as LINE\n" +
            "WHERE (LINE.COMPANY_ID IS NOT NULL AND NOT LINE.COMPANY_ID = '' )\n" +
            "    AND (LINE.CUSTOMER_ID IS NOT NULL AND NOT LINE.CUSTOMER_ID = '')\n" +
            "    WITH apoc.date.format(timestamp()+8*60*60*1000,\"ms\",\"yyyy-MM-dd HH:mm:ss\") AS TIME_STAMP,LINE\n" +
            "    MATCH (A:COMPANY{COMPANY_ID:toString(LINE.COMPANY_ID)})\n" +
            "    MATCH (B:COMPANY{COMPANY_ID:toString(LINE.CUSTOMER_ID)})\n" +
            "    MERGE (B)-[r:CUSTOMER]->(A)\n" +
            "    SET\n" +
            "\n" +
            "        r.RELATION_TYPE='主要客户',\n" +
            "        r.RPT_DT=toString(LINE.RPT_DT),\n" +
            "        r.START_DT=toString(LINE.START_DT),\n" +
            "        r.AMT=toString(LINE.AMT),\n" +
            "        r.SOURCE= 'COMPY_TOP5CUST',\n" +
            "        r.TIME_STAMP = TIME_STAMP,\n" +
            "        r.UPDT_DT = toString(LINE.UPDT_DT),\n" +
            "        r.IS_DEL=toString(LINE.IS_DEL)\n" +
            "    ;";

    private final static String CREATE_RELATION_SUPPLIER =
            "\n//主要供应商\n" +
            "WITH '{jdbc_url}' AS url\n" +
            "CALL apoc.load.jdbc(url,\"\n" +
            "SELECT COMPANY_ID,TO_CHAR(RPT_DT,'yyyy-mm-dd HH24:MI:SS')RPT_DT,SUPPLIER_ID,SUPPLIER_NM,TO_CHAR(START_DT,'yyyy-mm-dd HH24:MI:SS')START_DT,RELATIONSHIP,PCT_SUPPLY_SUM,AMT,ISDEL AS IS_DEL,TO_CHAR(LATEST_RPT_DT,'yyyy-mm-dd HH24:MI:SS')LATEST_RPT_DT\n" +
            "FROM\n" +
            "    (\n" +
            "        SELECT\n" +
            "            t.*,\n" +
            "             MAX(RPT_DT) over(partition BY COMPANY_ID ORDER BY RPT_DT DESC ) LATEST_RPT_DT\n" +
            "        FROM\n" +
            "            (\n" +
            "                SELECT\n" +
            "                    COMPANY_ID,\n" +
            "                    RPT_DT ,\n" +
            "                    SUPPLIER_ID,\n" +
            "                    SUPPLIER_NM,\n" +
            "                    START_DT,\n" +
            "                    RELATIONSHIP,\n" +
            "                    AMT,\n" +
            "                    PCT_SUPPLY_SUM,\n" +
            "                    ISDEL\n" +
            "                FROM\n" +
            "                    CS_PORTAL.COMPY_TOP5SUPP\n" +
            ") t ) m WHERE LATEST_RPT_DT =  RPT_DT\n" +
            "\") YIELD row WITH row as LINE\n" +
            "WHERE (LINE.COMPANY_ID IS NOT NULL AND NOT LINE.COMPANY_ID = '' )\n" +
            "    AND ( LINE.SUPPLIER_ID IS NOT NULL AND NOT LINE.SUPPLIER_ID = '' )\n" +
            "    WITH apoc.date.format(timestamp()+8*60*60*1000,\"ms\",\"yyyy-MM-dd HH:mm:ss\") AS TIME_STAMP,LINE\n" +
            "    MATCH (A:COMPANY{COMPANY_ID:toString(LINE.COMPANY_ID)})\n" +
            "    MATCH (B:COMPANY{COMPANY_ID:toString(LINE.SUPPLIER_ID)})\n" +
            "    MERGE (B)-[R:SUPPLIER]->(A)\n" +
            "    SET\n" +
            "        R.RELATION_TYPE='主要供应商',\n" +
            "        R.RPT_DT=toString(LINE.RPT_DT),\n" +
            "        R.START_DT=toString(LINE.START_DT),\n" +
            "        R.AMT=toString(LINE.AMT),\n" +
            "        R.SOURCE= 'COMPY_TOP5SUPP',\n" +
            "        R.TIME_STAMP = TIME_STAMP,\n" +
            "        // R.created_time = toString(timestamp()),\n" +
            "        R.UPDT_DT = toString(LINE.UPDT_DT),\n" +
            "        R.IS_DEL = toString(LINE.IS_DEL)\n" +
            "    ;";

    private final static String CLEAR_COMPANY_WARNING_NUM =
            "\n// 清除预警数据\n" +
            "MATCH  (C:COMPANY) WHERE EXISTS(C.WARNING_NUM) \n" +
            "   SET C.WARNING_NUM = NULL;";

    private final static String ADD_COMPANY_WARNING_NUM =
            "\n// 更新预警数据\n" +
            "WITH '{jdbc_url}' AS url\n" +
            "CALL apoc.load.jdbc(url,\"\n" +
            "    SELECT COMPANY_ID,SUM(WARNING_ANNOUNCE_ALARM_NUM) AS WARNING_NUM FROM(SELECT COMPANY_ID,COUNT(*) AS WARNING_ANNOUNCE_ALARM_NUM " +
                    "FROM CS_PORTAL.VW_COMPY_WARNINGS WHERE TYPE_ID NOT IN(10,12,107) " +
                    "GROUP BY COMPANY_ID " +
                    "UNION " +
                    "SELECT A.COMPANY_ID,COUNT(*) AS WARNING_ANNOUNCE_ALARM_NUM " +
                    "FROM CS_PORTAL.COMPY_ANNOUNCE_ALARM A INNER JOIN CS_PORTAL.LKP_ALARM_KEYWORD C ON A.ALARM_KEYWORD_CD = C.ALARM_KEYWORD_CD AND " +
                    "C.SECOND_TYPE IN ('违法违规','法律诉讼','破产重整','审计风险','评级调整风险','偿付风险','失信','担保方代偿能力风险') " +
                    "WHERE NOTICE_DT >= ADD_MONTHS(SYSDATE, -12) GROUP BY COMPANY_ID ) " +
                    "GROUP BY COMPANY_ID\n" +
            "    \")yield row WITH row AS  LINE\n" +
            "MATCH (C:COMPANY{COMPANY_ID:toString(LINE.COMPANY_ID)})\n" +
            "SET C.WARNING_NUM = toInt(LINE.WARNING_NUM)\n" +
            ";";

}
