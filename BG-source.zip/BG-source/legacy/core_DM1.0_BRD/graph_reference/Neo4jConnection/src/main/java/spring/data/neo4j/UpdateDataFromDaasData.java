package spring.data.neo4j;

import org.neo4j.driver.v1.StatementResult;
import org.neo4j.ogm.response.model.QueryStatisticsModel;
import spring.data.neo4j.neo4jConnector.Neo4jAccess;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/**
 * Created by wuchenglong on 2018/2/5.
 */

public class UpdateDataFromDaasData {

    private static String URL = "WITH 'http://10.100.46.15:7070/enterprise/info/%s' AS url \n" ;

    private static String DELETE_OLD_REL =
            "// 基本信息\n " +
                    "// 删除已有的关系 \n " +
                    "CALL apoc.load.json(url) YIELD value AS JSON \n" +
                    "WITH JSON.DATA.BASIC.ITEM AS LINE,apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP \n" +
                    "// RETURN LINE;\n" +
                    "MATCH (C:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(LINE.ENTNAME,'（','(') ,'）',')'))})-[R]-() \n" +
                    "DELETE R \n";


    private static String UPDATE_BASICINFO =
            "// 基本信息 \n " +
                    "CALL apoc.load.json(url) YIELD value AS JSON  \n " +
                    "WITH JSON.DATA.BASIC.ITEM AS LINE,apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP  \n " +
                    "MERGE (C:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(LINE.ENTNAME,'（','(') ,'）',')'))}) \n " +
                    "ON CREATE SET  \n " +
                    "C.COMPANY_NM = LINE.ENTNAME, \n " +
                    "C.COMPANY_ID = LINE.ENTNAME, \n " +
                    "C.SOURCE = 'DAAS_BASIC' \n " +
                    "// 法人代表是企业 \n " +
                    "FOREACH(ignoreMe IN CASE WHEN LENGTH(LINE.FRNAME)> 5 THEN [1] ELSE [] END |   \n " +
                    "    MERGE (S:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(LINE.FRNAME,'（','(') ,'）',')'))}) \n " +
                    "            ON CREATE SET \n " +
                    "                S.SOURCE = 'DAAS_BASIC', \n " +
                    "                S.TIME_STAMP = TIME_STAMP,  \n " +
                    "                S.COMPANY_ID = TOSTRING(REPLACE(REPLACE(LINE.FRNAME,'（','(') ,'）',')')) \n " +
                    "    MERGE (C:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(LINE.ENTNAME,'（','(') ,'）',')'))}) \n " +
                    "    MERGE (S)-[R:WORK{POSITION:'法定代表人'}]->(C) \n " +
                    "        ON CREATE SET   \n " +
                    "            R.SOURCE = 'DAAS_BASIC', \n " +
                    "            R.TIME_STAMP = TIME_STAMP \n " +
                    "         ) \n " +
                    "//   ----------法定代表人是自然人-并且自然人Node不存在 ---------- \n " +
                    "WITH LINE, TIME_STAMP, CASE WHEN NOT LENGTH(LINE.FRNAME)> 5 AND NOT (LINE.FRNAME IS NULL OR LINE.FRNAME  = ''  OR LINE.FRNAME  = 'None') AND NOT (:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(LINE.ENTNAME,'（','(') ,'）',')'))})-[]-(:PERSON{PERSON_NM:TOSTRING(LINE.FRNAME)}) THEN [1] ELSE [] END AS PERSON_ANAME \n " +
                    "FOREACH(ignoreMe IN PERSON_ANAME |  \n " +
                    "MERGE (S:PERSON{PERSON_ID:TOSTRING(REPLACE(REPLACE(LINE.ENTNAME,'（','(') ,'）',')'))+TOSTRING(LINE.FRNAME)}) \n " +
                    "    ON CREATE SET \n " +
                    "        S.SOURCE = 'DAAS_BASIC', \n " +
                    "        S.TIME_STAMP = TIME_STAMP,  \n " +
                    "        S.PERSON_NM = TOSTRING(LINE.FRNAME) \n " +
                    "MERGE (C:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(LINE.ENTNAME,'（','(') ,'）',')'))}) \n " +
                    "MERGE (S)-[R:WORK{POSITION:'法定代表人'}]->(C) \n " +
                    "    ON CREATE SET   \n " +
                    "        R.SOURCE = 'DAAS_BASIC', \n " +
                    "        R.TIME_STAMP = TIME_STAMP \n " +
                    "         ) \n " +
                    "// 法定代表人是自然人-并且自然人Node存在 \n " +
                    "WITH LINE, TIME_STAMP, CASE WHEN NOT LENGTH(LINE.FRNAME)> 5 AND NOT (LINE.FRNAME IS NULL OR LINE.FRNAME  = ''  OR LINE.FRNAME  = 'None' ) AND (:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(LINE.ENTNAME,'（','(') ,'）',')'))})-[]-(:PERSON{PERSON_NM:TOSTRING(LINE.FRNAME)}) THEN [1] ELSE [] END AS PERSON_ANAME \n " +
                    "MATCH  (C:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(LINE.ENTNAME,'（','(') ,'）',')'))})  \n " +
                    "MATCH (C)-[]-(S:PERSON{PERSON_NM:TOSTRING(LINE.FRNAME)}) \n " +
                    "MERGE (S)-[R:WORK{POSITION:'法定代表人'}]->(C) \n " +
                    "    ON CREATE SET   \n " +
                    "        R.SOURCE = 'DAAS_BASIC', \n " +
                    "        R.TIME_STAMP = TIME_STAMP \n " +
                    "        ; \n " ;

    private static String UPDATE_SHAINFO =
            "// 股东信息 \n" +
                    "CALL apoc.load.json(url) YIELD value AS JSON  \n" +
                    "WITH JSON,JSON.DATA.BASIC.ITEM.ENTNAME AS COMPANY_NM, CASE WHEN LENGTH(JSON.DATA.SHAREHOLDER) > 0 THEN   [ELEM IN JSON.DATA.SHAREHOLDER.ITEM | ELEM]  ELSE [] END AS SHAREHOLDERS,apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP  \n" +
                    "UNWIND SHAREHOLDERS AS LINE \n" +
                    "FOREACH(ignoreMe IN CASE WHEN LENGTH(LINE.SHANAME) > 5  THEN ['COMPANY'] ELSE [] END  |  \n" +
                    "    MERGE (S:COMPANY{COMPANY_NM:REPLACE(REPLACE(LINE.SHANAME,'（','(') ,'）',')')}) \n" +
                    "        ON CREATE SET \n" +
                    "            S.SOURCE = 'DAAS_SHAREHOLDER', \n" +
                    "            S.TIME_STAMP = TIME_STAMP,  \n" +
                    "            S.COMPANY_ID = REPLACE(REPLACE(LINE.SHANAME,'（','(') ,'）',')')   \n" +
                    "    MERGE (C:COMPANY{COMPANY_NM:REPLACE(REPLACE(COMPANY_NM,'（','(') ,'）',')')}) \n" +
                    "    MERGE (S)-[R:INVEST]->(C) \n" +
                    "        ON CREATE SET \n" +
                    "            R.SOURCE = 'DAAS_SHAREHOLDER',   \n" +
                    "            R.SHA_RATIO = LINE.FUNDEDRATIO, \n" +
                    "            R.TIME_STAMP = TIME_STAMP \n" +
                    "            ) \n" +
                    "// 企业股东是自然人- 不存在 \n" +
                    "WITH COMPANY_NM,LINE, TIME_STAMP, CASE WHEN NOT LENGTH(LINE.SHANAME) > 5  AND NOT (:COMPANY{COMPANY_NM:REPLACE(REPLACE(COMPANY_NM,'（','(') ,'）',')')})-[]-(:PERSON{PERSON_NM:TOSTRING(LINE.SHANAME)}) THEN ['PERSON'] ELSE [] END AS PERSON_NAME \n" +
                    "FOREACH(ignoreMe IN PERSON_NAME |  \n" +
                    " MERGE (S:PERSON{PERSON_ID:REPLACE(REPLACE(COMPANY_NM,'（','(') ,'）',')')+TOSTRING(LINE.SHANAME)}) \n" +
                    "     ON CREATE SET \n" +
                    "         S.SOURCE = 'DAAS_SHAREHOLDER', \n" +
                    "         S.TIME_STAMP = TIME_STAMP,  \n" +
                    "         S.PERSON_NM = TOSTRING(LINE.SHANAME) \n" +
                    " MERGE (C:COMPANY{COMPANY_NM:REPLACE(REPLACE(COMPANY_NM,'（','(') ,'）',')')}) \n" +
                    " MERGE (S)-[R:INVEST]->(C) \n" +
                    "     ON CREATE SET   \n" +
                    "        R.SOURCE = 'DAAS_SHAREHOLDER', \n" +
                    "        R.SHA_RATIO = LINE.FUNDEDRATIO, \n" +
                    "        R.TIME_STAMP = TIME_STAMP \n" +
                    "         ) \n" +
                    "// 企业股东是自然人- 存在 \n" +
                    "WITH COMPANY_NM,LINE, TIME_STAMP, CASE WHEN NOT LENGTH(LINE.SHANAME) > 5 AND (:COMPANY{COMPANY_NM:REPLACE(REPLACE(COMPANY_NM,'（','(') ,'）',')')})-[]-(:PERSON{PERSON_NM:TOSTRING(LINE.SHANAME)}) THEN ['PERSON'] ELSE [] END AS PERSON_NAME \n" +
                    "UNWIND PERSON_NAME AS PERSON_NAME_ELEM \n" +
                    "MATCH  (C:COMPANY{COMPANY_NM:REPLACE(REPLACE(COMPANY_NM,'（','(') ,'）',')')})  \n" +
                    "MATCH (C)-[]-(S:PERSON{PERSON_NM:TOSTRING(LINE.SHANAME)}) \n" +
                    "MERGE (S)-[R:INVEST]->(C) \n" +
                    "    ON CREATE SET   \n" +
                    "        R.SOURCE = 'DAAS_SHAREHOLDER', \n" +
                    "        R.SHA_RATIO = LINE.FUNDEDRATIO, \n" +
                    "        R.TIME_STAMP = TIME_STAMP;  \n" ;

    private static String UPDATE_PERSONINFO =
            "// 主要人员 \n " +
                    "CALL apoc.load.json(url) YIELD value AS JSON  \n " +
                    "WITH JSON,JSON.DATA.BASIC.ITEM.ENTNAME AS COMPANY_NM, CASE WHEN LENGTH(JSON.DATA.PERSON) > 0 THEN   [ELEM IN JSON.DATA.PERSON.ITEM | ELEM] ELSE [] END AS SHAREHOLDERS,apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP  \n " +
                    "UNWIND SHAREHOLDERS AS LINE  \n " +
                    "WITH COMPANY_NM,LINE, TIME_STAMP, CASE WHEN  NOT (:COMPANY{COMPANY_NM:REPLACE(REPLACE(LINE.KEY,'（','(') ,'）',')')})-[]-(:PERSON{PERSON_NM:TOSTRING(LINE.PERNAME)}) THEN ['PERSON'] ELSE [] END AS PERSON_ANAME \n " +
                    "WHERE NOT LINE.POSITION = '' \n " +
                    "FOREACH(ignoreMe IN PERSON_ANAME |  \n " +
                    "MERGE (S:PERSON{PERSON_ID:REPLACE(REPLACE(COMPANY_NM,'（','(') ,'）',')')+TOSTRING(LINE.PERNAME)}) \n " +
                    "    ON CREATE SET \n " +
                    "        S.SOURCE = 'DAAS_PERSON', \n " +
                    "        S.TIME_STAMP = TIME_STAMP,  \n " +
                    "        S.PERSON_NM = TOSTRING(LINE.PERNAME) \n " +
                    " MERGE (C:COMPANY{COMPANY_NM:REPLACE(REPLACE(COMPANY_NM,'（','(') ,'）',')')}) \n " +
                    " MERGE (S)-[R:WORK{POSITION:LINE.POSITION}]->(C) \n " +
                    "     ON CREATE SET   \n " +
                    "         R.SOURCE = 'DAAS_PERSON',  \n " +
                    "         R.TIME_STAMP = TIME_STAMP \n " +
                    "         ) \n " +
                    "WITH COMPANY_NM,LINE, TIME_STAMP, CASE WHEN  (:COMPANY{COMPANY_NM:REPLACE(REPLACE(COMPANY_NM,'（','(') ,'）',')')})-[]-(:PERSON{PERSON_NM:TOSTRING(LINE.PERNAME)}) THEN ['PERSON'] ELSE [] END AS PERSON_ANAME \n " +
                    "UNWIND PERSON_ANAME AS PERSON_ANAME_ELEM \n " +
                    "MATCH  (C:COMPANY{COMPANY_NM:REPLACE(REPLACE(COMPANY_NM,'（','(') ,'）',')')})  \n " +
                    "MATCH (C)-[]-(S:PERSON{PERSON_NM:TOSTRING(LINE.PERNAME)}) \n " +
                    "MERGE (S)-[R:WORK{POSITION:LINE.POSITION}]->(C) \n " +
                    "    ON CREATE SET   \n " +
                    "        R.SOURCE = 'DAAS_PERSON', \n " +
                    "        R.TIME_STAMP = TIME_STAMP; \n " ;


    private static String UPDATE_INVESTINFO =
            "// 投资信息 \n " +
                    "CALL apoc.load.json(url) YIELD value AS JSON  \n " +
                    "WITH JSON,JSON.DATA.BASIC.ITEM.ENTNAME AS COMPANY_NM, CASE WHEN LENGTH(JSON.DATA.ENTINV) > 0 THEN  [ELEM IN JSON.DATA.ENTINV.ITEM | ELEM] ELSE [] END AS SHAREHOLDERS,apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP  \n " +
                    "UNWIND SHAREHOLDERS AS LINE  \n " +
                    "// RETURN LINE; \n " +
                    "// 对外投资是企业 \n " +
                    "FOREACH(ignoreMe IN CASE WHEN LINE.ENTNAME IS NOT NULL   THEN ['COMPANY'] ELSE [] END  |  \n " +
                    "    MERGE (S:COMPANY{COMPANY_NM:REPLACE(REPLACE(LINE.ENTNAME,'（','(') ,'）',')')}) \n " +
                    "        ON CREATE SET \n " +
                    "            S.SOURCE = 'DAAS_ENTINV', \n " +
                    "            S.TIME_STAMP = TIME_STAMP,  \n " +
                    "            S.COMPANY_ID = REPLACE(REPLACE(LINE.ENTNAME,'（','(') ,'）',')'), \n " +
                    "            S.COMPANY_NM = TOSTRING(LINE.ENTNAME) \n " +
                    "    MERGE (C:COMPANY{COMPANY_NM:REPLACE(REPLACE(COMPANY_NM,'（','(') ,'）',')')}) \n " +
                    "    MERGE (S)<-[R:INVEST]-(C) \n " +
                    "        ON CREATE SET   \n " +
                    "            R.SOURCE = 'DAAS_ENTINV', \n " +
                    "            R.SHA_RATIO = LINE.FUNDEDRATIO, \n " +
                    "            R.TIME_STAMP = TIME_STAMP \n " +
                    "            ); \n " ;


    private static String UPDATE_FRINVESTINFO =
            "// 法定代表人对外投资 \n " +
                    "CALL apoc.load.json(url) YIELD value AS JSON  \n " +
                    "WITH JSON,JSON.DATA.BASIC.ITEM.ENTNAME AS COMPANY_NM, CASE WHEN LENGTH(JSON.DATA.FRINV) > 0 THEN  [ELEM IN JSON.DATA.FRINV.ITEM | ELEM] ELSE [] END AS SHAREHOLDERS,apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP  \n " +
                    "UNWIND SHAREHOLDERS AS LINE  \n " +
                    "MATCH (C:COMPANY{COMPANY_NM:REPLACE(REPLACE(COMPANY_NM,'（','(') ,'）',')')}) \n " +
                    "// 企业股东是企业 \n " +
                    "WITH C,TIME_STAMP,LINE,COMPANY_NM \n " +
                    "MERGE (IC:COMPANY{COMPANY_NM:REPLACE(REPLACE(LINE.ENTNAME,'（','(') ,'）',')')}) \n " +
                    "ON CREATE SET  \n " +
                    "    IC.SOURCE = 'DAAS_FRINV', \n " +
                    "    IC.TIME_STAMP = TIME_STAMP,  \n " +
                    "    IC.COMPANY_ID = REPLACE(REPLACE(LINE.ENTNAME,'（','(') ,'）',')') \n " +
                    "WITH C,TIME_STAMP,LINE,COMPANY_NM,IC \n " +
                    "MATCH (C)-[:WORK{POSITION:'法定代表人'}]-(P) // WHERE P.PERSON_NM = LINE.FRNAME \n " +
                    "MERGE (P)-[R:INVEST]->(IC) \n " +
                    "    ON CREATE SET   \n " +
                    "        R.SOURCE = 'DAAS_FRINV', \n " +
                    "        R.SHA_RATIO = LINE.FUNDEDRATIO, \n " +
                    "        R.TIME_STAMP = TIME_STAMP; \n ";



    private static String UPDATE_FRPOSITION =
            "// 法定代表人对外任职 \n" +
                    "CALL apoc.load.json(url) YIELD value AS JSON  \n" +
                    "WITH JSON,JSON.DATA.BASIC.ITEM.ENTNAME AS COMPANY_NM, CASE WHEN LENGTH(JSON.DATA.FRPOSITION) > 0 THEN  [ELEM IN JSON.DATA.FRPOSITION.ITEM | ELEM] ELSE [] END AS SHAREHOLDERS,apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP  \n" +
                    "UNWIND SHAREHOLDERS AS LINE  \n" +
                    "MATCH (C:COMPANY{COMPANY_NM:REPLACE(REPLACE(COMPANY_NM,'（','(') ,'）',')')}) \n" +
                    "// 企业股东是企业 \n" +
                    "WITH C,TIME_STAMP,LINE,COMPANY_NM \n" +
                    "WHERE NOT LINE.POSITION = '' \n " +
                    "MERGE (IC:COMPANY{COMPANY_NM:REPLACE(REPLACE(LINE.ENTNAME,'（','(') ,'）',')')}) \n" +
                    "ON CREATE SET  \n" +
                    "    IC.SOURCE = 'DAAS_FRPOSITION', \n" +
                    "    IC.TIME_STAMP = TIME_STAMP,  \n" +
                    "    IC.COMPANY_ID = REPLACE(REPLACE(LINE.ENTNAME,'（','(') ,'）',')') \n" +
                    "WITH C,TIME_STAMP,LINE,COMPANY_NM,IC \n" +
                    "MATCH (C)-[]-(P:PERSON) WHERE P.PERSON_NM = LINE.NAME \n" +
                    "MERGE (P)-[R:WORK{POSITION:LINE.POSITION}]->(IC) \n" +
                    "    ON CREATE SET   \n" +
                    "        R.SOURCE = 'DAAS_FRPOSITION',  \n" +
                    "        R.TIME_STAMP = TIME_STAMP; \n" ;


    private static String UPDATE_LABEL =
            "// 基本信息\n " + "// 为新增的企业更新label，例如添加私募label \n " +
                    "CALL apoc.load.json(url) YIELD value AS JSON \n" +
                    "WITH JSON.DATA.BASIC.ITEM AS LINE,apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP \n" +
                    "// RETURN LINE;\n" +
                    "MATCH (C:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(LINE.ENTNAME,'（','(') ,'）',')'))})\n" +
                    "SET C:PFCOMPANY \n";


    private static final Logger logger = LogManager.getLogger(Main.class);
    public static void main(String[] args) {
        try {
            test();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void test() {
        Neo4jAccess neo4jAccess  = new  Neo4jAccess("bolt://localhost:7687","neo4j","abc123");
        neo4jAccess.establishConnection();

        for (String  companyNm:new ArrayList<>(Collections.singletonList("中证信用增进股份有限公司"))){
            // logger.debug(String.format(url,companyNm) + UPDATE_BASICINFO);
            neo4jAccess.session.run(String.format(URL, companyNm) + DELETE_OLD_REL);
            logger.debug("成功删除历史关系。");
            for (String  updateQuery:new ArrayList<>(Arrays.asList(
                    UPDATE_BASICINFO,
                    UPDATE_SHAINFO,
                    UPDATE_PERSONINFO,
                    UPDATE_INVESTINFO,
                    UPDATE_FRPOSITION,
                    UPDATE_FRINVESTINFO))) {
                StatementResult result = neo4jAccess.session.run(String.format(URL, companyNm) + updateQuery);
                QueryStatisticsModel queryStatisticsModel = new QueryStatisticsModel();
                queryStatisticsModel.setProperties_set(result.consume().counters().propertiesSet());
                logger.debug(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet());
            }
            neo4jAccess.session.run(String.format(URL, companyNm) + UPDATE_LABEL);
            logger.debug("成功更新label");
        }

        // 测试更新结果
        // '''MATCH (C:COMPANY{COMPANY_NM:\'深圳市卓悦资本管理有限公司\'})-[R]-() RETURN R;'''
        neo4jAccess.closeConnection();
    }

}
