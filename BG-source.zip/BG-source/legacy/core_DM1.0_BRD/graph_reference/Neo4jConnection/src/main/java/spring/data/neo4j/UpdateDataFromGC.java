package spring.data.neo4j;

import org.apache.commons.lang.text.StrSubstitutor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.ogm.response.model.QueryStatisticsModel;
import spring.data.neo4j.neo4jConnector.Neo4jAccess;
import spring.data.neo4j.oracleConnector.DataCopier;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

/**
 * Created by wuchenglong on 2018/2/5.
 */

public class UpdateDataFromGC {

    private static final Logger logger = LogManager.getLogger(Main.class);
    public static void main(String[] args) {
        try {
            test();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static Connection connectionToOracle() throws Exception {
        DataCopier copier = DataCopier.getInstance("gc.properties");
        Connection  conn = copier.database.openConnection();

        try {
            return conn;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public static void deleteOldRelation(Neo4jAccess neo4jAccess,String company_nm) {
        HashMap<String, String> paraHashMap = new HashMap<String, String>();
        paraHashMap.put("COMPANY_NM", "'"+company_nm+"'");
        StrSubstitutor sub = new StrSubstitutor(paraHashMap);
        String queryString = sub.replace(DELETE_OLD_REL);
        //logger.debug(queryString);

        StatementResult result = neo4jAccess.session.run(queryString);
        logger.debug("成功删除"+company_nm+"历史关系。");
        QueryStatisticsModel queryStatisticsModel = new QueryStatisticsModel();
        queryStatisticsModel.setProperties_set(result.consume().counters().propertiesSet());
        logger.debug(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet());
    }


    public static String companyIsExistFlag(String company_nm)
    {
        Connection conn = null;
        try {
            DataCopier copier = DataCopier.getInstance("gc.properties");
            conn = copier.database.openConnection();
            conn.setAutoCommit(false);
            String query = "SELECT COMPANY_ID,COMPANY_NM FROM CS_GS_DM.VW_COMPY_BASICINFO WHERE COMPANY_NM = '%s' and IS_DEL = 0";
            query = String.format(query,company_nm);
            //logger.debug(queryString);
            PreparedStatement stmt = conn.prepareStatement(query, ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery();
            if (rs.next())
            {
                return rs.getString("COMPANY_ID");
            }
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return null;
    }

    public static void insertCompanyBasicInfo(Neo4jAccess neo4jAccess,String company_id) {
        Connection conn = null;
        try {
            DataCopier copier = DataCopier.getInstance("gc.properties");
            conn = copier.database.openConnection();
            conn.setAutoCommit(false);
            String query = "SELECT COMPANY_NM,COMPANY_ID,LEG_REPRESENT,REG_CAPITAL FROM CS_GS_DM.VW_COMPY_BASICINFO WHERE COMPANY_ID = '%s'";
            query = String.format(query,company_id);
            PreparedStatement stmt = conn.prepareStatement(query, ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery();
            if (rs.next())
            {
                HashMap<String, String> paraHashMap = new HashMap<String, String>();
                paraHashMap.put("COMPANY_NM", "'"+rs.getString("COMPANY_NM")+"'");
                paraHashMap.put("COMPANY_ID", "'"+rs.getString("COMPANY_ID")+"'");
                paraHashMap.put("FRNAME", "'"+rs.getString("LEG_REPRESENT")+"'");
                paraHashMap.put("REG_CAPITAL", "'"+rs.getString("REG_CAPITAL")+"'");
                StrSubstitutor sub = new StrSubstitutor(paraHashMap);
                String queryString = sub.replace(UPDATE_BASICINFO);

                StatementResult result = neo4jAccess.session.run(queryString);
                logger.debug("成功更新基本信息。");
                QueryStatisticsModel queryStatisticsModel = new QueryStatisticsModel();
                queryStatisticsModel.setProperties_set(result.consume().counters().propertiesSet());
                logger.debug(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet());
            }
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

    }


    public static void insertCompanyEmployee(Neo4jAccess neo4jAccess,String company_id,String company_nm) {
        Connection conn = null;
        try {
            DataCopier copier = DataCopier.getInstance("gc.properties");
            conn = copier.database.openConnection();
            conn.setAutoCommit(false);
            String query = "SELECT A.COMPANY_ID,A.PERSON_NM,A.POSITION FROM CS_GS_DM.VW_COMPY_EMPLOYEE_XYGS A WHERE A.COMPANY_ID = %s";
            query = String.format(query,company_id);
            //logger.debug(queryString);
            PreparedStatement stmt = conn.prepareStatement(query, ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery();
            while (rs.next())
            {
                HashMap<String, String> paraHashMap = new HashMap<String, String>();
                paraHashMap.put("COMPANY_NM", "'"+company_nm+"'");
                paraHashMap.put("COMPANY_ID", "'"+rs.getString("COMPANY_ID")+"'");
                paraHashMap.put("EMP_NAME", "'"+rs.getString("PERSON_NM")+"'");
                paraHashMap.put("POSITION", "'"+rs.getString("POSITION")+"'");
                StrSubstitutor sub = new StrSubstitutor(paraHashMap);
                String queryString = sub.replace(UPDATE_PERSONINFO);
                //logger.debug(queryString);

                StatementResult result = neo4jAccess.session.run(queryString);
                logger.debug("成功更新高管信息：" + rs.getString("PERSON_NM"));
                QueryStatisticsModel queryStatisticsModel = new QueryStatisticsModel();
                queryStatisticsModel.setProperties_set(result.consume().counters().propertiesSet());
                logger.debug(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet());
            }
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static void insertCompanyShareholder(Neo4jAccess neo4jAccess,String company_id,String company_nm)
    {
        Connection conn = null;
        try {
            DataCopier copier = DataCopier.getInstance("gc.properties");
            conn = copier.database.openConnection();
            conn.setAutoCommit(false);
            String query = "SELECT A.COMPANY_ID,A.SHAREHD_NAME,A.SHAREHD_TYPE,A.SHAREHD_ID,A.PAID_AMT,B.REG_CAPITAL FROM CS_GS_DM.VW_COMPY_SHAREHDINVEST_XYGS A " +
                    "LEFT JOIN CS_GS_DM.VW_COMPY_BASICINFO B ON A.SHAREHD_ID = B.COMPANY_ID " +
                    "WHERE A.COMPANY_ID = %s";
            query = String.format(query,company_id);
            //logger.debug(queryString);
            PreparedStatement stmt = conn.prepareStatement(query, ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                if (rs.getString("SHAREHD_TYPE").equals("2")) {
                    if (rs.getString("SHAREHD_ID") != null && !rs.getString("SHAREHD_ID").equals("")) {
                        HashMap<String, String> paraHashMap = new HashMap<String, String>();
                        paraHashMap.put("COMPANY_NM", "'"+company_nm+"'");
                        paraHashMap.put("COMPANY_ID", "'"+rs.getString("COMPANY_ID")+"'");
                        paraHashMap.put("SHANAME", "'"+rs.getString("SHAREHD_NAME")+"'");
                        paraHashMap.put("SHA_ID", "'"+rs.getString("SHAREHD_ID")+"'");
                        paraHashMap.put("NUM", "'"+rs.getString("PAID_AMT")+"'");
                        paraHashMap.put("REG_CAPITAL", "'"+rs.getString("REG_CAPITAL")+"'");
                        StrSubstitutor sub = new StrSubstitutor(paraHashMap);
                        String queryString = sub.replace(UPDATE_SHAINFO_COMPANY);
                        //logger.debug(queryString);

                        StatementResult result = neo4jAccess.session.run(queryString);
                        logger.debug("成功更新股东信息："+ rs.getString("SHAREHD_NAME"));
                        QueryStatisticsModel queryStatisticsModel = new QueryStatisticsModel();
                        queryStatisticsModel.setProperties_set(result.consume().counters().propertiesSet());
                        logger.debug(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet());}

                } else if (rs.getString("SHAREHD_TYPE") == "1") {
                    if (rs.getString("SHANAME") != null && !rs.getString("SHANAME").equals("")) {
                        HashMap<String, String> paraHashMap = new HashMap<String, String>();
                        paraHashMap.put("COMPANY_NM", "'"+company_nm+"'");
                        paraHashMap.put("COMPANY_ID", "'"+rs.getString("COMPANY_ID")+"'");
                        paraHashMap.put("SHANAME", "'"+rs.getString("SHAREHD_NAME")+"'");
                        paraHashMap.put("NUM", "'"+rs.getString("PAID_AMT")+"'");
                        StrSubstitutor sub = new StrSubstitutor(paraHashMap);
                        String queryString = sub.replace(UPDATE_SHAINFO_PERSON);
                        //logger.debug(queryString);

                        StatementResult result = neo4jAccess.session.run(queryString);
                        logger.debug("成功更新股东信息："+ rs.getString("SHAREHD_NAME"));
                        QueryStatisticsModel queryStatisticsModel = new QueryStatisticsModel();
                        queryStatisticsModel.setProperties_set(result.consume().counters().propertiesSet());
                        logger.debug(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet());
                    }
                }

            }
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

    }

    public static void insertCompanyInvester(Neo4jAccess neo4jAccess,String company_id,String company_nm) {
        Connection conn = null;
        try {
            DataCopier copier = DataCopier.getInstance("gc.properties");
            conn = copier.database.openConnection();
            conn.setAutoCommit(false);
            String query = "SELECT A.COMPANY_ID,B.COMPANY_NM,A.SHAREHD_ID,A.PAID_AMT,B.REG_CAPITAL FROM CS_GS_DM.VW_COMPY_SHAREHDINVEST_XYGS A " +
                    "INNER JOIN CS_GS_DM.VW_COMPY_BASICINFO B ON A.COMPANY_ID = B.COMPANY_ID  " +
                    "WHERE A.SHAREHD_ID = %s and A.SHAREHD_TYPE = 2 " ;
            query = String.format(query,company_id);
            //logger.debug(queryString);
            PreparedStatement stmt = conn.prepareStatement(query, ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                HashMap<String, String> paraHashMap = new HashMap<String, String>();
                paraHashMap.put("COMPANY_NM", "'"+company_nm+"'");
                paraHashMap.put("COMPANY_ID", "'"+rs.getString("SHAREHD_ID")+"'");
                paraHashMap.put("ENTNAME", "'"+rs.getString("COMPANY_NM")+"'");
                paraHashMap.put("ENT_ID", "'"+rs.getString("COMPANY_ID")+"'");
                paraHashMap.put("NUM", "'"+rs.getString("PAID_AMT")+"'");
                paraHashMap.put("REG_CAPITAL", "'"+rs.getString("REG_CAPITAL")+"'");
                StrSubstitutor sub = new StrSubstitutor(paraHashMap);
                String queryString = sub.replace(UPDATE_INVESTINFO);
                //logger.debug(queryString);

                StatementResult result = neo4jAccess.session.run(queryString);
                logger.debug("成功更新对外投资信息："+ rs.getString("COMPANY_NM"));
                QueryStatisticsModel queryStatisticsModel = new QueryStatisticsModel();
                queryStatisticsModel.setProperties_set(result.consume().counters().propertiesSet());
                logger.debug(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet());
            }
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static void test() {
        String company_nm = "浙江万科南都房地产有限公司";
        Neo4jAccess neo4jAccess  = new  Neo4jAccess("bolt://localhost:7687","neo4j","abc123");
        neo4jAccess.establishConnection();
        String company_id = companyIsExistFlag(company_nm);
        logger.debug(company_id);
        logger.debug(company_nm);
        //根据名称删除历史数据
        if(company_id != null && !company_id.equals("")) {
            deleteOldRelation(neo4jAccess,company_nm);
            insertCompanyBasicInfo(neo4jAccess,company_id);
            insertCompanyEmployee(neo4jAccess,company_id,company_nm);
            insertCompanyShareholder(neo4jAccess,company_id,company_nm);
            insertCompanyInvester(neo4jAccess,company_id,company_nm);
        }
        neo4jAccess.closeConnection();
    }

    private static String DELETE_OLD_REL =
            "// 基本信息，删除已有的关系\n " +
                    "MATCH (C:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')'))})-[R]-() \n" +
                    "DELETE R \n";


    private static String UPDATE_BASICINFO =
            "// 基本信息 \n " +
                    "WITH apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP  \n " +
                    "MERGE (C:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')'))}) \n " +
                    "ON CREATE SET  \n " +
                    "C.COMPANY_NM = ${COMPANY_NM}, \n " +
                    "C.COMPANY_ID = ${COMPANY_ID}, \n " +
                    "C.REG_CAPITAL = ${REG_CAPITAL}, \n " +
                    "C.SOURCE = 'GC_BASIC' \n " +
                    "// 法人代表是企业 \n " +
                    "FOREACH(ignoreMe IN CASE WHEN LENGTH(${FRNAME})> 5 THEN [1] ELSE [] END |   \n " +
                    "    MERGE (S:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(${FRNAME},'（','(') ,'）',')'))}) \n " +
                    "            ON CREATE SET \n " +
                    "                S.SOURCE = 'DAAS_BASIC', \n " +
                    "                S.TIME_STAMP = TIME_STAMP,  \n " +
                    "                S.COMPANY_ID = TOSTRING(REPLACE(REPLACE(${FRNAME},'（','(') ,'）',')')) \n " +
                    "    MERGE (C:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')'))}) \n " +
                    "    MERGE (S)-[R:WORK{POSITION:'法定代表人'}]->(C) \n " +
                    "        ON CREATE SET   \n " +
                    "            R.SOURCE = 'GC_BASIC', \n " +
                    "            R.TIME_STAMP = TIME_STAMP \n " +
                    "         ) \n " +
                    "//   ----------法定代表人是自然人-并且自然人Node不存在 ---------- \n " +
                    "WITH TIME_STAMP, CASE WHEN NOT LENGTH(${FRNAME})> 5 AND NOT (${FRNAME} IS NULL OR ${FRNAME}  = ''  OR ${FRNAME}  = 'None') AND NOT (:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')'))})-[]-(:PERSON{PERSON_NM:TOSTRING(${FRNAME})}) THEN [1] ELSE [] END AS PERSON_ANAME \n " +
                    "FOREACH(ignoreMe IN PERSON_ANAME |  \n " +
                    "MERGE (S:PERSON{PERSON_ID:TOSTRING(REPLACE(REPLACE(${COMPANY_ID},'（','(') ,'）',')'))+TOSTRING(${FRNAME})}) \n " +
                    "    ON CREATE SET \n " +
                    "        S.SOURCE = 'DAAS_BASIC', \n " +
                    "        S.TIME_STAMP = TIME_STAMP,  \n " +
                    "        S.PERSON_NM = TOSTRING(${FRNAME}) \n " +
                    "MERGE (C:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')'))}) \n " +
                    "MERGE (S)-[R:WORK{POSITION:'法定代表人'}]->(C) \n " +
                    "    ON CREATE SET   \n " +
                    "        R.SOURCE = 'GC_BASIC', \n " +
                    "        R.TIME_STAMP = TIME_STAMP \n " +
                    "         ) \n " +
                    "// 法定代表人是自然人-并且自然人Node存在 \n " +
                    "WITH TIME_STAMP, CASE WHEN NOT LENGTH(${FRNAME})> 5 AND NOT (${FRNAME} IS NULL OR ${FRNAME}  = ''  OR ${FRNAME}  = 'None' ) AND (:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')'))})-[]-(:PERSON{PERSON_NM:TOSTRING(${FRNAME})}) THEN [1] ELSE [] END AS PERSON_ANAME \n " +
                    "MATCH  (C:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')'))})  \n " +
                    "MATCH (C)-[]-(S:PERSON{PERSON_NM:TOSTRING(${FRNAME})}) \n " +
                    "MERGE (S)-[R:WORK{POSITION:'法定代表人'}]->(C) \n " +
                    "    ON CREATE SET   \n " +
                    "        R.SOURCE = 'GC_BASIC', \n " +
                    "        R.TIME_STAMP = TIME_STAMP \n " +
                    "        ; \n " ;

    private static String UPDATE_SHAINFO_COMPANY =
                    "WITH apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP  \n" +
                    "FOREACH(ignoreMe IN CASE WHEN LENGTH(${SHANAME}) > 5  THEN ['COMPANY'] ELSE [] END  |  \n" +
                    "    MERGE (S:COMPANY{COMPANY_NM:REPLACE(REPLACE(${SHANAME},'（','(') ,'）',')')}) \n" +
                    "        ON CREATE SET \n" +
                    "            S.SOURCE = 'DAAS_SHAREHOLDER', \n" +
                    "            S.TIME_STAMP = TIME_STAMP,  \n" +
                    "            S.COMPANY_ID = ${SHA_ID},  \n" +
                    "            S.REG_CAPITAL = ${REG_CAPITAL}   \n" +
                    "    MERGE (C:COMPANY{COMPANY_NM:REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')')}) \n" +
                    "    MERGE (S)-[R:INVEST]->(C) \n" +
                    "        ON CREATE SET \n" +
                    "            R.SOURCE = 'GC_SHAREHOLDER',   \n" +
                    "            R.NUM = ${NUM}, \n" +
                    "            R.TIME_STAMP = TIME_STAMP \n" +
                    "            ) \n";


    private static String UPDATE_SHAINFO_PERSON =
                    "// 企业股东是自然人- 不存在 \n" +
                    "WITH apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP, CASE WHEN NOT LENGTH(${SHANAME}) > 5  AND NOT (:COMPANY{COMPANY_NM:REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')')})-[]-(:PERSON{PERSON_NM:TOSTRING(${SHANAME})}) THEN ['PERSON'] ELSE [] END AS PERSON_NAME \n" +
                    "FOREACH(ignoreMe IN PERSON_NAME |  \n" +
                    " MERGE (S:PERSON{PERSON_ID:REPLACE(REPLACE(${COMPANY_ID},'（','(') ,'）',')')+TOSTRING(${SHANAME})}) \n" +
                    "     ON CREATE SET \n" +
                    "         S.SOURCE = 'GC_SHAREHOLDER', \n" +
                    "         S.TIME_STAMP = TIME_STAMP,  \n" +
                    "         S.PERSON_NM = TOSTRING(${SHANAME}) \n" +
                    " MERGE (C:COMPANY{COMPANY_NM:REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')')}) \n" +
                    " MERGE (S)-[R:INVEST]->(C) \n" +
                    "     ON CREATE SET   \n" +
                    "        R.SOURCE = 'GC_SHAREHOLDER', \n" +
                    "        R.NUM = ${NUM}, \n" +
                    "        R.TIME_STAMP = TIME_STAMP \n" +
                    "         ) \n" +
                    "// 企业股东是自然人- 存在 \n" +
                    "WITH  TIME_STAMP, CASE WHEN NOT LENGTH(${SHANAME}) > 5 AND (:COMPANY{COMPANY_NM:REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')')})-[]-(:PERSON{PERSON_NM:TOSTRING(${SHANAME})}) THEN ['PERSON'] ELSE [] END AS PERSON_NAME \n" +
                    "UNWIND PERSON_NAME AS PERSON_NAME_ELEM \n" +
                    "MATCH  (C:COMPANY{COMPANY_NM:REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')')})  \n" +
                    "MATCH (C)-[]-(S:PERSON{PERSON_NM:TOSTRING(${SHANAME})}) \n" +
                    "MERGE (S)-[R:INVEST]->(C) \n" +
                    "    ON CREATE SET   \n" +
                    "        R.SOURCE = 'GC_SHAREHOLDER', \n" +
                    "        R.NUM = ${NUM}, \n" +
                    "        R.TIME_STAMP = TIME_STAMP;  \n" ;


    private static String UPDATE_PERSONINFO =
            "// 主要人员 \n " +
                    "WITH apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP, CASE WHEN  NOT (:COMPANY{COMPANY_NM:REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')')})-[]-(:PERSON{PERSON_NM:TOSTRING(${EMP_NAME})}) THEN ['PERSON'] ELSE [] END AS PERSON_ANAME \n " +
                    "FOREACH(ignoreMe IN PERSON_ANAME |  \n " +
                    "MERGE (S:PERSON{PERSON_ID:REPLACE(REPLACE(${COMPANY_ID},'（','(') ,'）',')')+TOSTRING(${EMP_NAME})}) \n " +
                    "    ON CREATE SET \n " +
                    "        S.SOURCE = 'GC_EMPLOYEE', \n " +
                    "        S.TIME_STAMP = TIME_STAMP,  \n " +
                    "        S.PERSON_NM = TOSTRING(${EMP_NAME}) \n " +
                    " MERGE (C:COMPANY{COMPANY_NM:REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')')}) \n " +
                    " MERGE (S)-[R:WORK{POSITION:${POSITION}}]->(C) \n " +
                    "     ON CREATE SET   \n " +
                    "         R.SOURCE = 'GC_EMPLOYEE',  \n " +
                    "         R.TIME_STAMP = TIME_STAMP \n " +
                    "         ) \n " +
                    "WITH apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP, CASE WHEN  (:COMPANY{COMPANY_NM:REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')')})-[]-(:PERSON{PERSON_NM:TOSTRING(${EMP_NAME})}) THEN ['PERSON'] ELSE [] END AS PERSON_ANAME \n " +
                    "MATCH  (C:COMPANY{COMPANY_NM:REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')')})  \n " +
                    "MATCH (C)-[]-(S:PERSON{PERSON_NM:TOSTRING(${EMP_NAME})}) \n " +
                    "MERGE (S)-[R:WORK{POSITION:${POSITION}}]->(C) \n " +
                    "    ON CREATE SET   \n " +
                    "        R.SOURCE = 'GC_EMPLOYEE', \n " +
                    "        R.TIME_STAMP = TIME_STAMP; \n " ;


    private static String UPDATE_INVESTINFO =
            "// 投资信息 \n " +
                    "// 对外投资是企业 \n " +
                    "WITH apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP \n" +
                    "FOREACH(ignoreMe IN CASE WHEN ${ENTNAME} IS NOT NULL   THEN ['COMPANY'] ELSE [] END  |  \n " +
                    "    MERGE (S:COMPANY{COMPANY_NM:REPLACE(REPLACE(${ENTNAME},'（','(') ,'）',')')}) \n " +
                    "        ON CREATE SET \n " +
                    "            S.SOURCE = 'GC_ENTINV', \n " +
                    "            S.TIME_STAMP = TIME_STAMP,  \n " +
                    "            S.COMPANY_ID = ${ENT_ID}, \n " +
                    "            S.REG_CAPITAL = ${REG_CAPITAL} \n " +
                    "    MERGE (C:COMPANY{COMPANY_NM:REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')')}) \n " +
                    "    MERGE (S)<-[R:INVEST]-(C) \n " +
                    "        ON CREATE SET   \n " +
                    "            R.SOURCE = 'GC_ENTINV', \n " +
                    "            R.NUM = ${NUM}, \n " +
                    "            R.TIME_STAMP = TIME_STAMP \n " +
                    "            ); \n " ;

    private static String UPDATE_LABEL =
            "// 基本信息\n "
                    + "// 为新增的企业更新label，例如添加私募label \n " +
                    "WITH apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP \n" +
                    "MATCH (C:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')'))})\n" +
                    "SET C:PFCOMPANY \n";
}
