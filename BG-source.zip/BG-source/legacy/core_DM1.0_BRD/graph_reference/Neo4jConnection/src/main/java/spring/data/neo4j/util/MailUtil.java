package spring.data.neo4j.util;

import org.junit.Test;
import spring.data.neo4j.config.DbConnectionConfig;

import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;


public class MailUtil {

	public static void sendMail(String subject, String content) {
		try {
			// MailSSLSocketFactory sf = new MailSSLSocketFactory();
	  //       sf.setTrustAllHosts(true);

	        Properties props = new Properties();
	        
	        // props.put("mail.debug", "true");
	        // props.put("mail.smtp.ssl.enable", "true");
	        // props.put("mail.smtp.auth", "true"); 
	        // props.put("mail.smtp.ssl.socketFactory", sf);
	        // props.put("mail.smtp.port", Contants.MAIL_SSL_PORT);
	        // props.put("mail.smtp.socketFactory.port",Contants.MAIL_SSL_PORT);
	        // props.put("mail.transport.protocol",Contants.SSL_PROTOCOL);
	        // props.put("mail.host", Contants.MAIL_HOST);

	        props.setProperty("mail.transport.protocol", "smtp");    // 使用的协议（JavaMail规范要求）
            props.setProperty("mail.host", "mail.chinacscs.com");           // 发件人的邮箱的 SMTP 服务器地址
            props.setProperty("mail.smtp.auth", "true");

            Session mailSession = Session.getInstance(props);
            MimeMessage message = new MimeMessage(mailSession);
            InternetAddress from = new InternetAddress("jobtest@chinacscs.com");
            message.setFrom(from);
            String to[] = {"zhoujr@chinacscs.com","wuchl@chinacscs.com","douchong@chinacscs.com"};//
            InternetAddress[] sendTo = new InternetAddress[to.length];
            for (int i = 0; i < to.length; i++)
            {
                System.out.println("发送到:" + to[i]);
                sendTo[i] = new InternetAddress(to[i]);
            }
            message.setRecipients(MimeMessage.RecipientType.TO, sendTo);
            message.setSubject(subject);
            message.setContent(content, "text/html;charset=UTF-8");

            Transport transport = mailSession.getTransport();
            transport.connect("jobtest@chinacscs.com", "XKFqI9GT");
            transport.sendMessage(message, message.getAllRecipients());//发送邮件,其中第二个参数是所有已设好的收件人地址
            transport.close();

	    } catch (Exception e) {
            e.printStackTrace();
        }
	}


    public static void sendLogEmail(String env,String loninfo) {
        DbConnectionConfig dbConnectionConfig = null;
        String wronglog = "";
        String targetNeo4j = "dbConnectionConfig_test.properties";
        targetNeo4j = UtilConfig.getEnvironment(env);
        wronglog = loninfo;
        try {
            dbConnectionConfig = (DbConnectionConfig) UtilConfig.configFileToBean(
                    targetNeo4j,
                    DbConnectionConfig.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        String jdbc_url = DbConnectionConfig.neo4jUri;
        sendMail(jdbc_url+"出现异常",wronglog);
    }

    public static void main(String[] args) {
        String wronglog = "";
        String targetNeo4jarg = "test";
        if (args.length > 0){
            targetNeo4jarg = args[0];
            wronglog = args[1];
            sendLogEmail(targetNeo4jarg,wronglog);
        }
    }

    @Test
    public void sendMailTest() {
        MailUtil.sendMail("1","2");
    }
}