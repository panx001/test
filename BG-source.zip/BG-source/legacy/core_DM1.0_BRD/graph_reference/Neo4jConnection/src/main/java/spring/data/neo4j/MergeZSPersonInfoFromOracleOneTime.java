package spring.data.neo4j;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;
import spring.data.neo4j.util.UtilConfig;

import java.io.File;


/**
 * Created by chinacscs on 2018/5/2.
 */
public class MergeZSPersonInfoFromOracleOneTime {
    private static final Logger logger = LogManager.getLogger(Main.class);

//    private static String exportSQL ="SELECT COMPANY_ID,BRANCH_COMPANY_ID FROM  CS_CREDIT.VW_COMPY_BRANCH WHERE COMPANY_ID IS NOT NULL AND BRANCH_COMPANY_ID IS NOT NULL";
    private static String exportSQL ="SELECT ZS_PERSON_ID,COMPANY_ID,PERSON_NM FROM CS_SANDBOX.ZS_COMPY_PERSON";

    private static String update_query_forward =
            "USING PERIODIC COMMIT 10000 \n" +
                    "LOAD CSV  \n" +
                    "WITH HEADERS \n" +
                    "FROM 'file:///${csv_url}' AS LINE\n" +
                    "MATCH (c:COMPANY{COMPANY_ID:LINE.COMPANY_ID})\n" +
                    "MATCH (p1:PERSON{PERSON_ID:LINE.COMPANY_ID+LINE.PERSON_NM})\n" +
                    "MERGE (p2:PERSON{PERSON_ID:LINE.ZS_PERSON_ID})\n" +
                    "SET p2.PERSON_NM=LINE.PERSON_NM,p2.SRC_PERSON_CD=p1.SRC_PERSON_CD \n" +
                    "WITH c,p1,p2\n" +
                    "MATCH (c)<-[r1:WORK|INVEST|RELATIVE|CONTROLLER]-(p1)\n" +
                    "FOREACH(ELEM IN CASE WHEN TYPE(r1) = 'WORK' THEN ['1'] ELSE [] END |\n" +
                    "MERGE (c)<-[r2:WORK]-(p2)\n" +
                    "SET r2 += properties(r1)\n" +
                    "DELETE r1\n" +
                    ")\n" +
                    "FOREACH(ELEM IN CASE WHEN TYPE(r1) = 'INVEST' THEN ['1'] ELSE [] END |\n" +
                    "MERGE (c)<-[r2:INVEST]-(p2)\n" +
                    "SET r2 += properties(r1)\n" +
                    "DELETE r1\n" +
                    ")\n" +
                    "FOREACH(ELEM IN CASE WHEN TYPE(r1) = 'RELATIVE' THEN ['1'] ELSE [] END |\n" +
                    "MERGE (c)<-[r2:RELATIVE]-(p2)\n" +
                    "SET r2 += properties(r1)\n" +
                    "DELETE r1\n" +
                    ")\n" +
                    "FOREACH(ELEM IN CASE WHEN TYPE(r1) = 'CONTROLLER' THEN ['1'] ELSE [] END |\n" +
                    "MERGE (c)<-[r2:CONTROLLER]-(p2)\n" +
                    "SET r2 += properties(r1)\n" +
                    "DELETE r1\n" +
                    ")";
    private static String update_query_backward =
            "USING PERIODIC COMMIT 10000 \n" +
                    "LOAD CSV  \n" +
                    "WITH HEADERS \n" +
                    "FROM 'file:///${csv_url}' AS LINE\n" +
                    "MATCH (c:COMPANY{COMPANY_ID:LINE.COMPANY_ID})\n" +
                    "MATCH (p1:PERSON{PERSON_ID:LINE.COMPANY_ID+LINE.PERSON_NM})\n" +
                    "MERGE (p2:PERSON{PERSON_ID:LINE.ZS_PERSON_ID})\n" +
                    "SET p2.PERSON_NM=LINE.PERSON_NM,p2.SRC_PERSON_CD=p1.SRC_PERSON_CD \n" +
                    "WITH c,p1,p2\n" +
                    "MATCH (c)-[r1:RELATIVE]->(p1)\n" +
                    "FOREACH(ELEM IN CASE WHEN TYPE(r1) = 'RELATIVE' THEN ['1'] ELSE [] END |\n" +
                    "MERGE (c)-[r2:RELATIVE]->(p2)\n" +
                    "SET r2 += properties(r1)\n" +
                    "DELETE r1\n" +
                    ")";



    @Test
    public void getZSPersonToCSV() throws Exception {
        File dir = UtilConfig.file("/data/update/" + UtilConfig.getData() + "/mergezscsv");
        UpdatePrivateCompanyFromCsv updatePrivateCompanyFromCsv = new UpdatePrivateCompanyFromCsv();
        updatePrivateCompanyFromCsv.exportDataByQueryToDirFiles(dir,exportSQL,"");
    }

    public void updateCSVToNeo4j(String targetNeo4j) throws Exception {
        File dir = UtilConfig.file("/data/update/" + UtilConfig.getData() + "/mergezscsv");

        String[] array = dir.list();
        if(array==null) {
            return;
        }
        for (String targetCSVDir :array) {
            UtilConfig.loadCSVAndExcute(dir,targetCSVDir,targetNeo4j,update_query_forward);
//            UtilConfig.loadCSVAndExcute(dir,targetCSVDir,targetNeo4j,update_query_backward);
        }
    }


    public static void main(String[] args) throws Exception {
        String targetNeo4j = "dbConnectionConfig_test.properties";
        if(args.length!=0) {
            targetNeo4j = UtilConfig.getEnvironment(args[0]);
            logger.debug(args[0]+":"+targetNeo4j);
        }
        MergeZSPersonInfoFromOracleOneTime mergeZSPersonInfoFromOracleOneTime = new MergeZSPersonInfoFromOracleOneTime();
        mergeZSPersonInfoFromOracleOneTime.getZSPersonToCSV();
        mergeZSPersonInfoFromOracleOneTime.updateCSVToNeo4j(targetNeo4j);
    }
}
