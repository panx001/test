package spring.data.neo4j;


import org.neo4j.driver.v1.StatementResult;
import org.neo4j.ogm.response.model.QueryStatisticsModel;
import spring.data.neo4j.config.DbConnectionConfig;
import spring.data.neo4j.neo4jConnector.Neo4jAccess;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.commons.lang.text.StrSubstitutor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.*;


import spring.data.neo4j.util.UtilCql;
import spring.data.neo4j.util.UtilConfig;

/**
 * Created by wuchenglong on 2018/1/12.
 */

public class Main {
    private static final Logger logger = LogManager.getLogger(Main.class);


    private static void dataUpdate(String dataUpdateType) throws Exception{
        DbConnectionConfig dbConnectionConfig = null;
        try {
            dbConnectionConfig = (DbConnectionConfig) UtilConfig.configFileToBean(
                        "dbConnectionConfig.properties",
                        DbConnectionConfig.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        String jdbc_url = DbConnectionConfig.JdbcUri;
        logger.debug(jdbc_url);
        Neo4jAccess neo4jAccess = new Neo4jAccess(dbConnectionConfig);
        neo4jAccess.establishConnection();
        HashMap<String, String> paraHashMap = new HashMap<String, String>();

        /* 写入Txt文件 */
        File writeName = new File("./increaseUpdate.cql"); // 相对路径，如果没有则要建立一个新的output。txt文件
        logger.debug(writeName.getAbsolutePath());
        logger.debug(writeName.getAbsoluteFile().getAbsolutePath());
        if(writeName.exists()){
            writeName.delete();
            writeName.createNewFile(); // 创建新文件
        }

        BufferedWriter out = new BufferedWriter(new FileWriter(writeName,true));

        for (Map.Entry<String, List<String>> entry : UtilCql.updatePublicCompanyCqlMap.entrySet()) {

            System.out.println("--------------------------");
            System.out.println(entry.getKey());

            paraHashMap.put("jdbc_url", jdbc_url);
            paraHashMap.put("condition", dataUpdateType.equals("total") ? "":String.format(entry.getValue().get(1),dbConnectionConfig.interval_days));
            StrSubstitutor sub = new StrSubstitutor(paraHashMap, "{", "}");
            String queryString = sub.replace(entry.getValue().get(0));

            out.write("RETURN apoc.date.format(timestamp()+8*60*60*1000,\"ms\",\"yyyy-MM-dd HH:mm:ss\") + \"  " + entry.getKey() + " updating!!" + " \" AS  info;\r\n ");
            out.write(queryString + "\r\n"); // \r\n即为换行
            logger.debug(queryString);

            // StatementResult result = neo4jAccess.session.run(queryString);
            // QueryStatisticsModel queryStatisticsModel = new QueryStatisticsModel();
            // queryStatisticsModel.setProperties_set(result.consume().counters().propertiesSet());
            // System.out.println(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet().stream().filter(w->w.getValue() instanceof Integer).filter(w-> (Integer)w.getValue()!=0).collect(Collectors.toList()));

            // System.out.println(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet());

            //StatementResult result = neo4jAccess.session.run(entry.getValue().get(0), Values.parameters("jdbc_url",jdbc_url,"condition",""));
            //StatementResult result = neo4jAccess.session.run(entry.getValue(), Values.parameters("company_nm","wanke","company_id","513847"));

        }

        out.flush(); // 把缓存区内容压入文件
        out.close(); // 最后记得关闭文件

        // if (dataUpdateType.equals("incre")) {
        //     for (Map.Entry<String, List<String>> entry : UtilCql.updatePublicCompanyCqlMap_incre.entrySet()) {
        //
        //         // logger.debug(entry.getKey());
        //         //logger.debug(entry.getValue());
        //
        //         paraHashMap.put("jdbc_url", jdbc_url);
        //         paraHashMap.put("condition", dataUpdateType.equals("total") ? "":String.format(entry.getValue().get(1),dbConnectionConfig.interval_days));
        //         StrSubstitutor sub = new StrSubstitutor(paraHashMap, "{", "}");
        //         String queryString = sub.replace(entry.getValue().get(0));
        //         // System.out.println(queryString);
        //
        //         StatementResult result = neo4jAccess.session.run(queryString);
        //         QueryStatisticsModel queryStatisticsModel = new QueryStatisticsModel();
        //         queryStatisticsModel.setProperties_set(result.consume().counters().propertiesSet());
        //
        //         System.out.println("--------------------------");
        //         System.out.println(entry.getKey());
        //         System.out.println(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet().stream().filter(w->w.getValue() instanceof Integer).filter(w-> (Integer)w.getValue()!=0).collect(Collectors.toList()));
        //         System.out.println(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet());
        //
        //         //StatementResult result = neo4jAccess.session.run(entry.getValue().get(0), Values.parameters("jdbc_url",jdbc_url,"condition",""));
        //         //StatementResult result = neo4jAccess.session.run(entry.getValue(), Values.parameters("company_nm","wanke","company_id","513847"));
        //
        //     }
        // }
        neo4jAccess.closeConnection();

    }

    public static void main(String[] args) throws Exception {
        //dataUpdate("total");
        String dataUpdateType = "total";
        if(args.length!=0) {
            dataUpdateType = args[0];
        }
        logger.debug("公开企业数据更新方式为增量'incre'或全量'total'");
        logger.debug("当前选择的更新模式为:"+dataUpdateType);
        dataUpdate(dataUpdateType);
    }



    public static void test() {
        Neo4jAccess neo4jAccess  = new  Neo4jAccess("bolt://localhost:7687","neo4j","abc123");
        neo4jAccess.establishConnection();

        for (Map.Entry<String,  List<String>> entry : UtilCql.updatePublicCompanyCqlMap.entrySet()) {

            logger.debug(entry.getKey() + "  update");
            StatementResult result = neo4jAccess.session.run( entry.getValue().get(0));
            QueryStatisticsModel queryStatisticsModel = new QueryStatisticsModel();
            queryStatisticsModel.setProperties_set(result.consume().counters().propertiesSet());
            logger.debug(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet());
        }
        neo4jAccess.closeConnection();
    }
}


// // StatementResult result = session.run( "MATCH (a:PERSON)   RETURN a, a.PERSON_NM AS PERSON_NM LIMIT 2 " );
// System.out.println(result.summary().counters());
// System.out.println(new org.apache.commons.beanutils.BeanMap(result.summary()).entrySet());
// System.out.println(result.summary());
//
// QueryStatisticsModel queryStatisticsModel = new QueryStatisticsModel();
// queryStatisticsModel.setProperties_set(result.consume().counters().propertiesSet());
// System.out.println(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet());
// while ( result.hasNext() )
// {
//     Record record = result.next();
//     System.out.println(record);
//     System.out.println(record.get("a").get("PERSON_NM"));
//     System.out.println( record.get( "PERSON_ID" ).asString() + " " + record.get("PERSON_NM").asString() );
// }
