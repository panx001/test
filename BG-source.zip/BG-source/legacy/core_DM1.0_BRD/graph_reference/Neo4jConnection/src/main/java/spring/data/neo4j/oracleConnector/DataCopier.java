package spring.data.neo4j.oracleConnector;

import spring.data.neo4j.config.OracleDbConnectionConfig;
import spring.data.neo4j.util.UtilConfig;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;


/**
 * Created by wuchenglong on 2017/12/21.
 */

public class DataCopier {

    public Database database;

    public static void rollBack(Connection con) {
        try {
            con.rollback();
        } catch (SQLException ex) {
            //Do Nothing
        }
    }

    public DataCopier() {
        this.database = new Database();
    }

    public static DataCopier getInstance(String fileName) throws Exception {
        try {
            UtilConfig.initConfig(fileName, OracleDbConnectionConfig.class);
            DataCopier copier = new DataCopier();

            copier.database.setJdbcDriverClassName(OracleDbConnectionConfig.JdbcDriverClassName);
            copier.database.setJdbcUrl(OracleDbConnectionConfig.JdbcUrl);
            copier.database.setUsername(OracleDbConnectionConfig.Username);
            copier.database.setPassword(OracleDbConnectionConfig.Password);

            return copier;

        } catch (FileNotFoundException e) {
            throw new IllegalArgumentException("unable to locate input-file = " + fileName);
        } catch (IOException e) {
            throw new RuntimeException("unable to close the input stream");
        }

    }

    public String toString() {
        return database.toString();
    }
}