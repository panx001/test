package spring.data.neo4j;

import org.apache.commons.lang.text.StrSubstitutor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.ogm.response.model.QueryStatisticsModel;
import spring.data.neo4j.neo4jConnector.Neo4jAccess;
import spring.data.neo4j.oracleConnector.DataCopier;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

/**
 * Created by wuchenglong on 2018/1/12.
 */

public class UpdatePrivateCompany
{
    private static String interval_days = "1";

    public static void updateCompanyBasicInfo(Neo4jAccess neo4jAccess)
    {
        Connection conn = null;
        try {
            Integer count = 0;
            DataCopier copier = DataCopier.getInstance("gc.properties");
            conn = copier.database.openConnection();
            conn.setAutoCommit(false);
            String query = "SELECT COMPANY_NM,COMPANY_ID,LEG_REPRESENT,REG_CAPITAL FROM CS_CREDIT.COMPY_BASICINFO WHERE UPDT_DT > SYSDATE - %s";
            query = String.format(query,interval_days);
            //logger.debug(queryString);
            PreparedStatement stmt = conn.prepareStatement(query, ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                if(count%1000 == 0) {
                    logger.debug("基本信息已更新"+count+"条");
                }
                HashMap<String, String> paraHashMap = new HashMap<String, String>();
                paraHashMap.put("COMPANY_NM", "'"+rs.getString("COMPANY_NM")+"'");
                paraHashMap.put("COMPANY_ID", "'"+rs.getString("COMPANY_ID")+"'");
                paraHashMap.put("FRNAME", "'"+rs.getString("LEG_REPRESENT")+"'");
                paraHashMap.put("REG_CAPITAL", "'"+rs.getString("REG_CAPITAL")+"'");
                //删除对应法定代表人信息
                StrSubstitutor sub_del = new StrSubstitutor(paraHashMap);
                String queryString_delete = sub_del.replace(DELETE_OLD_FR);
                //更新企业基本信息
                StrSubstitutor sub = new StrSubstitutor(paraHashMap);
                String queryString = sub.replace(UPDATE_BASICINFO);
                //logger.debug(queryString);

                neo4jAccess.session.run(queryString_delete);
                neo4jAccess.session.run(queryString);
                count++;
            }
            logger.debug("成功更新基本信息。");
            conn.close();
        }catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

    }


    public static void updateCompanyEmployee(Neo4jAccess neo4jAccess)
    {
        Connection conn = null;
        try {
            Integer count = 0;
            DataCopier copier = DataCopier.getInstance("gc.properties");
            conn = copier.database.openConnection();
            conn.setAutoCommit(false);
            String query_del = "SELECT DISTINCT A.COMPANY_ID FROM CS_CREDIT.COMPY_EMPLOYEE_XYGS A WHERE A.UPDT_DT > SYSDATE - %s";
            String query = "SELECT A.COMPANY_ID,A.PERSON_NM,A.POSITION FROM CS_CREDIT.COMPY_EMPLOYEE_XYGS A WHERE UPDT_DT > SYSDATE - %s";
            query_del = String.format(query_del,interval_days);
            query = String.format(query,interval_days);
            //logger.debug(queryString);

            PreparedStatement stmt_del = conn.prepareStatement(query_del, ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs_del = stmt_del.executeQuery();
            while (rs_del.next()) {
                //删除对应企业高管信息
                HashMap<String, String> paraHashMap = new HashMap<String, String>();
                paraHashMap.put("COMPANY_ID", "'"+rs_del.getString("COMPANY_ID")+"'");
                StrSubstitutor sub_del = new StrSubstitutor(paraHashMap);
                String queryString_delete = sub_del.replace(DELETE_OLD_EMP);
                neo4jAccess.session.run(queryString_delete);
            }
            logger.debug("成功删除高管信息");

            PreparedStatement stmt = conn.prepareStatement(query, ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                if(count%1000 == 0) {
                    logger.debug("高管信息已更新"+count+"条");
                }
                HashMap<String, String> paraHashMap = new HashMap<String, String>();
                paraHashMap.put("COMPANY_ID", "'"+rs.getString("COMPANY_ID")+"'");
                paraHashMap.put("EMP_NAME", "'"+rs.getString("PERSON_NM")+"'");
                paraHashMap.put("POSITION", "'"+rs.getString("POSITION")+"'");
                //更新企业高管信息
                StrSubstitutor sub = new StrSubstitutor(paraHashMap);
                String queryString = sub.replace(UPDATE_PERSONINFO);
                StatementResult result = neo4jAccess.session.run(queryString);
                logger.debug("成功更新高管信息：" + rs.getString("PERSON_NM"));
                QueryStatisticsModel queryStatisticsModel = new QueryStatisticsModel();
                queryStatisticsModel.setProperties_set(result.consume().counters().propertiesSet());
                logger.debug(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet());
                count++;
            }
            conn.close();
        }catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static void updateCompanyShareholder(Neo4jAccess neo4jAccess) {
        Connection conn = null;
        try {
            Integer count = 0;

            DataCopier copier = DataCopier.getInstance("gc.properties");
            conn = copier.database.openConnection();
            conn.setAutoCommit(false);
            String query_del = "SELECT DISTINCT A.COMPANY_ID FROM CS_GS_DM.VW_COMPY_SHAREHDINVEST_XYGS A WHERE A.UPDT_DT > SYSDATE - %s";
            String query = "SELECT A.COMPANY_ID,A.SHAREHD_NAME,A.SHAREHD_TYPE,A.SHAREHD_ID,A.PAID_AMT,B.REG_CAPITAL FROM CS_CREDIT.COMPY_SHAREHDINVEST_XYGS A " +
                    "LEFT JOIN CS_CREDIT.COMPY_BASICINFO B ON A.SHAREHD_ID = B.COMPANY_ID " +
                    "WHERE A.UPDT_DT > SYSDATE - %s";
            query_del = String.format(query_del,interval_days);
            query = String.format(query,interval_days);
            //logger.debug(queryString);

            PreparedStatement stmt_del = conn.prepareStatement(query_del, ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs_del = stmt_del.executeQuery();
            while (rs_del.next()) {
                //删除对应企业高管信息
                HashMap<String, String> paraHashMap = new HashMap<String, String>();
                paraHashMap.put("COMPANY_ID", "'"+rs_del.getString("COMPANY_ID")+"'");
                StrSubstitutor sub_del = new StrSubstitutor(paraHashMap);
                String queryString_delete = sub_del.replace(DELETE_OLD_SHA);
                neo4jAccess.session.run(queryString_delete);
            }
            logger.debug("成功删除股东信息");


            PreparedStatement stmt = conn.prepareStatement(query, ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                if(count%1000 == 0) {
                    logger.debug("股东信息已更新"+count+"条");
                }
                if (rs.getString("SHAREHD_TYPE").equals("2")) {
                    if (rs.getString("SHAREHD_ID") != null && !rs.getString("SHAREHD_ID").equals("")) {
                        HashMap<String, String> paraHashMap = new HashMap<String, String>();
                        paraHashMap.put("COMPANY_ID", "'"+rs.getString("COMPANY_ID")+"'");
                        paraHashMap.put("SHANAME", "'"+rs.getString("SHAREHD_NAME")+"'");
                        paraHashMap.put("SHA_ID", "'"+rs.getString("SHAREHD_ID")+"'");
                        paraHashMap.put("NUM", "'"+rs.getString("PAID_AMT")+"'");
                        paraHashMap.put("REG_CAPITAL", "'"+rs.getString("REG_CAPITAL")+"'");

                        StrSubstitutor sub = new StrSubstitutor(paraHashMap);
                        String queryString = sub.replace(UPDATE_SHAINFO_COMPANY);
                        //logger.debug(queryString);


                        StatementResult result = neo4jAccess.session.run(queryString);
                        logger.debug("成功更新股东信息："+ rs.getString("SHAREHD_NAME"));
                        QueryStatisticsModel queryStatisticsModel = new QueryStatisticsModel();
                        queryStatisticsModel.setProperties_set(result.consume().counters().propertiesSet());
                        logger.debug(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet());}

                }
                else if (rs.getString("SHAREHD_TYPE") == "1") {
                    if (rs.getString("SHANAME") != null && !rs.getString("SHANAME").equals("")) {
                        HashMap<String, String> paraHashMap = new HashMap<String, String>();
                        paraHashMap.put("COMPANY_ID", "'"+rs.getString("COMPANY_ID")+"'");
                        paraHashMap.put("SHANAME", "'"+rs.getString("SHAREHD_NAME")+"'");
                        paraHashMap.put("NUM", "'"+rs.getString("PAID_AMT")+"'");
                        StrSubstitutor sub = new StrSubstitutor(paraHashMap);
                        String queryString = sub.replace(UPDATE_SHAINFO_PERSON);
                        //logger.debug(queryString);

                        StatementResult result = neo4jAccess.session.run(queryString);
                        logger.debug("成功更新股东信息："+ rs.getString("SHAREHD_NAME"));
                        QueryStatisticsModel queryStatisticsModel = new QueryStatisticsModel();
                        queryStatisticsModel.setProperties_set(result.consume().counters().propertiesSet());
                        logger.debug(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet());
                    }
                }
                count++;
            }
            conn.close();
        }catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

    }

    public static void test()
    {
        Neo4jAccess neo4jAccess  = new  Neo4jAccess("bolt://localhost:7687","neo4j","abc123");
        neo4jAccess.establishConnection();
        updateCompanyBasicInfo(neo4jAccess);
        updateCompanyEmployee(neo4jAccess);
        updateCompanyShareholder(neo4jAccess);
        neo4jAccess.closeConnection();


    }

    private static final Logger logger = LogManager.getLogger(Main.class);
    public static void main(String[] args) {
        try {
            test();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String DELETE_OLD_FR =
            "// 基本信息，删除已有的关系\n " +
                    "MATCH (C:COMPANY{COMPANY_ID:${COMPANY_ID}})<-[R:WORK{POSITION:'法定代表人'}]-() \n" +
                    "DELETE R \n";
    private static String DELETE_OLD_SHA =
            "// 基本信息，删除已有的关系\n " +
                    "MATCH (C:COMPANY{COMPANY_ID:${COMPANY_ID}})<-[R:INVEST]-() \n" +
                    "DELETE R \n";
    private static String DELETE_OLD_EMP =
            "// 基本信息，删除已有的关系\n " +
                    "MATCH (C:COMPANY{COMPANY_ID:${COMPANY_ID}})<-[R:WORK]-() WHERE R.POSITION <> '法定代表人' \n" +
                    "DELETE R \n";
    private static String UPDATE_BASICINFO =
            "// 基本信息 \n " +
                    "WITH apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP  \n " +
                    "MERGE (C:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')'))}) \n " +
                    "ON CREATE SET  \n " +
                    "C.COMPANY_NM = ${COMPANY_NM}, \n " +
                    "C.COMPANY_ID = ${COMPANY_ID}, \n " +
                    "C.REG_CAPITAL = ${REG_CAPITAL}, \n " +
                    "C.SOURCE = 'GC_BASIC' \n " +
                    "// 法人代表是企业 \n " +
                    "FOREACH(ignoreMe IN CASE WHEN LENGTH(${FRNAME})> 5 THEN [1] ELSE [] END |   \n " +
                    "    MERGE (S:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(${FRNAME},'（','(') ,'）',')'))}) \n " +
                    "            ON CREATE SET \n " +
                    "                S.SOURCE = 'DAAS_BASIC', \n " +
                    "                S.TIME_STAMP = TIME_STAMP,  \n " +
                    "                S.COMPANY_ID = TOSTRING(REPLACE(REPLACE(${FRNAME},'（','(') ,'）',')')) \n " +
                    "    MERGE (C:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')'))}) \n " +
                    "    MERGE (S)-[R:WORK{POSITION:'法定代表人'}]->(C) \n " +
                    "        ON CREATE SET   \n " +
                    "            R.SOURCE = 'GC_BASIC', \n " +
                    "            R.TIME_STAMP = TIME_STAMP \n " +
                    "         ) \n " +
                    "//   ----------法定代表人是自然人-并且自然人Node不存在 ---------- \n " +
                    "WITH TIME_STAMP, CASE WHEN NOT LENGTH(${FRNAME})> 5 AND NOT (${FRNAME} IS NULL OR ${FRNAME}  = ''  OR ${FRNAME}  = 'None') AND NOT (:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')'))})-[]-(:PERSON{PERSON_NM:TOSTRING(${FRNAME})}) THEN [1] ELSE [] END AS PERSON_ANAME \n " +
                    "FOREACH(ignoreMe IN PERSON_ANAME |  \n " +
                    "MERGE (S:PERSON{PERSON_ID:TOSTRING(REPLACE(REPLACE(${COMPANY_ID},'（','(') ,'）',')'))+TOSTRING(${FRNAME})}) \n " +
                    "    ON CREATE SET \n " +
                    "        S.SOURCE = 'DAAS_BASIC', \n " +
                    "        S.TIME_STAMP = TIME_STAMP,  \n " +
                    "        S.PERSON_NM = TOSTRING(${FRNAME}) \n " +
                    "MERGE (C:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')'))}) \n " +
                    "MERGE (S)-[R:WORK{POSITION:'法定代表人'}]->(C) \n " +
                    "    ON CREATE SET   \n " +
                    "        R.SOURCE = 'GC_BASIC', \n " +
                    "        R.TIME_STAMP = TIME_STAMP \n " +
                    "         ) \n " +
                    "// 法定代表人是自然人-并且自然人Node存在 \n " +
                    "WITH TIME_STAMP, CASE WHEN NOT LENGTH(${FRNAME})> 5 AND NOT (${FRNAME} IS NULL OR ${FRNAME}  = ''  OR ${FRNAME}  = 'None' ) AND (:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')'))})-[]-(:PERSON{PERSON_NM:TOSTRING(${FRNAME})}) THEN [1] ELSE [] END AS PERSON_ANAME \n " +
                    "MATCH  (C:COMPANY{COMPANY_NM:TOSTRING(REPLACE(REPLACE(${COMPANY_NM},'（','(') ,'）',')'))})  \n " +
                    "MATCH (C)-[]-(S:PERSON{PERSON_NM:TOSTRING(${FRNAME})}) \n " +
                    "MERGE (S)-[R:WORK{POSITION:'法定代表人'}]->(C) \n " +
                    "    ON CREATE SET   \n " +
                    "        R.SOURCE = 'GC_BASIC', \n " +
                    "        R.TIME_STAMP = TIME_STAMP \n " +
                    "        ; \n " ;

    private static String UPDATE_SHAINFO_COMPANY =
            "WITH apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP  \n" +
                    "FOREACH(ignoreMe IN CASE WHEN LENGTH(${SHANAME}) > 5  THEN ['COMPANY'] ELSE [] END  |  \n" +
                    "    MERGE (S:COMPANY{COMPANY_NM:REPLACE(REPLACE(${SHANAME},'（','(') ,'）',')')}) \n" +
                    "        ON CREATE SET \n" +
                    "            S.SOURCE = 'DAAS_SHAREHOLDER', \n" +
                    "            S.TIME_STAMP = TIME_STAMP,  \n" +
                    "            S.COMPANY_ID = ${SHA_ID},  \n" +
                    "            S.REG_CAPITAL = ${REG_CAPITAL}   \n" +
                    "    MERGE (C:COMPANY{COMPANY_ID:${COMPANY_ID}}) \n" +
                    "    MERGE (S)-[R:INVEST]->(C) \n" +
                    "        ON CREATE SET \n" +
                    "            R.SOURCE = 'GC_SHAREHOLDER',   \n" +
                    "            R.NUM = ${NUM}, \n" +
                    "            R.TIME_STAMP = TIME_STAMP \n" +
                    "            ) \n";


    private static String UPDATE_SHAINFO_PERSON =
            "// 企业股东是自然人- 不存在 \n" +
                    "WITH apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP, CASE WHEN NOT LENGTH(${SHANAME}) > 5  AND NOT (:COMPANY{COMPANY_ID:${COMPANY_ID},'（','(') ,'）',')')})-[]-(:PERSON{PERSON_NM:TOSTRING(${SHANAME})}) THEN ['PERSON'] ELSE [] END AS PERSON_NAME \n" +
                    "FOREACH(ignoreMe IN PERSON_NAME |  \n" +
                    " MERGE (S:PERSON{PERSON_ID:REPLACE(REPLACE(${COMPANY_ID},'（','(') ,'）',')')+TOSTRING(${SHANAME})}) \n" +
                    "     ON CREATE SET \n" +
                    "         S.SOURCE = 'DAAS_SHAREHOLDER', \n" +
                    "         S.TIME_STAMP = TIME_STAMP,  \n" +
                    "         S.PERSON_NM = TOSTRING(${SHANAME}) \n" +
                    " MERGE (C:COMPANY{COMPANY_ID:${COMPANY_ID}}) \n" +
                    " MERGE (S)-[R:INVEST]->(C) \n" +
                    "     ON CREATE SET   \n" +
                    "        R.SOURCE = 'GC_SHAREHOLDER', \n" +
                    "        R.NUM = ${NUM}, \n" +
                    "        R.TIME_STAMP = TIME_STAMP \n" +
                    "         ) \n" +
                    "// 企业股东是自然人- 存在 \n" +
                    "WITH  TIME_STAMP, CASE WHEN NOT LENGTH(${SHANAME}) > 5 AND (:COMPANY{COMPANY_ID:${COMPANY_ID}})-[]-(:PERSON{PERSON_NM:TOSTRING(${SHANAME})}) THEN ['PERSON'] ELSE [] END AS PERSON_NAME \n" +
                    "UNWIND PERSON_NAME AS PERSON_NAME_ELEM \n" +
                    "MATCH  (C:COMPANY{COMPANY_ID:${COMPANY_ID}})  \n" +
                    "MATCH (C)-[]-(S:PERSON{PERSON_NM:TOSTRING(${SHANAME})}) \n" +
                    "MERGE (S)-[R:INVEST]->(C) \n" +
                    "    ON CREATE SET   \n" +
                    "        R.SOURCE = 'GC_SHAREHOLDER', \n" +
                    "        R.NUM = ${NUM}, \n" +
                    "        R.TIME_STAMP = TIME_STAMP;  \n" ;


    private static String UPDATE_PERSONINFO =
            "// 主要人员 \n " +
                    "WITH apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP, CASE WHEN  NOT (:COMPANY{COMPANY_ID:${COMPANY_ID}})-[]-(:PERSON{PERSON_NM:TOSTRING(${EMP_NAME})}) THEN ['PERSON'] ELSE [] END AS PERSON_ANAME \n " +
                    "FOREACH(ignoreMe IN PERSON_ANAME |  \n " +
                    "MERGE (S:PERSON{PERSON_ID:REPLACE(REPLACE(${COMPANY_ID},'（','(') ,'）',')')+TOSTRING(${EMP_NAME})}) \n " +
                    "    ON CREATE SET \n " +
                    "        S.SOURCE = 'GC_EMPLOYEE', \n " +
                    "        S.TIME_STAMP = TIME_STAMP,  \n " +
                    "        S.PERSON_NM = TOSTRING(${EMP_NAME}) \n " +
                    " MERGE (C:COMPANY{COMPANY_ID:${COMPANY_ID}}) \n " +
                    " MERGE (S)-[R:WORK{POSITION:${POSITION}}]->(C) \n " +
                    "     ON CREATE SET   \n " +
                    "         R.SOURCE = 'GC_EMPLOYEE',  \n " +
                    "         R.TIME_STAMP = TIME_STAMP \n " +
                    "         ) \n " +
                    "WITH apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP, CASE WHEN  (:COMPANY{COMPANY_ID:${COMPANY_ID}})-[]-(:PERSON{PERSON_NM:TOSTRING(${EMP_NAME})}) THEN ['PERSON'] ELSE [] END AS PERSON_ANAME \n " +
                    "MATCH  (C:COMPANY{COMPANY_ID:${COMPANY_ID}})  \n " +
                    "MATCH (C)-[]-(S:PERSON{PERSON_NM:TOSTRING(${EMP_NAME})}) \n " +
                    "MERGE (S)-[R:WORK{POSITION:${POSITION}}]->(C) \n " +
                    "    ON CREATE SET   \n " +
                    "        R.SOURCE = 'GC_EMPLOYEE', \n " +
                    "        R.TIME_STAMP = TIME_STAMP; \n " ;
}
