package spring.data.neo4j;

import org.junit.Test;
import spring.data.neo4j.config.DbConnectionConfig;
import spring.data.neo4j.util.MailUtil;
import spring.data.neo4j.util.UtilConfig;

import java.io.*;


/**
 * Created by chinacscs on 2018/5/2.
 */
public class UpdateDailyMail {

    public static String readFileByChars(String fileName) {
        StringBuilder result = new StringBuilder();
        try{
            FileInputStream fin = new FileInputStream(fileName);
            InputStreamReader reader = new InputStreamReader(fin);
            BufferedReader buffReader = new BufferedReader(reader);
            String strTmp;
            while((strTmp = buffReader.readLine())!=null){
                result.append(strTmp).append("<br>");
            }
            buffReader.close();
        } catch(Exception e) {
            System.out.print(e);
        }
        return result.toString();
    }

    @Test
    public void readFile() {
        File dir = UtilConfig.file("/data/update/" + UtilConfig.getData() + "/info.log");
        System.out.print(UpdateDailyMail.readFileByChars(dir.getAbsolutePath()));
    }

    public static void main(String[] args) throws Exception {
        //更新环境地址
        DbConnectionConfig dbConnectionConfig = null;
        String targetNeo4j = "dbConnectionConfig_test.properties";
        if(args.length!=0) {
            targetNeo4j = UtilConfig.getEnvironment(args[0]);
        }

        try {
            dbConnectionConfig = (DbConnectionConfig) UtilConfig.configFileToBean(
                    targetNeo4j,
                    DbConnectionConfig.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        String jdbc_url = DbConnectionConfig.neo4jUri;
        //更新内容
        File dir = UtilConfig.file("/data/update/" + UtilConfig.getData() + "/info.log");
//        System.out.print(UpdateDailyMail.readFileByChars(dir.getAbsolutePath()));
        MailUtil.sendMail(jdbc_url+"更新日志", UpdateDailyMail.readFileByChars(dir.getAbsolutePath()));
    }
}
