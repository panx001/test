package spring.data.neo4j;


import org.apache.commons.lang.text.StrSubstitutor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.ogm.response.model.QueryStatisticsModel;
import spring.data.neo4j.config.DbConnectionConfig;
import spring.data.neo4j.neo4jConnector.Neo4jAccess;
import spring.data.neo4j.util.UtilConfig;

import java.io.File;
import java.util.HashMap;
import java.util.stream.Collectors;


/**
 * Created by chinacscs on 2018/5/2.
 */
public class UpdateCompanyBranchRelationFromOracle {
    private static final Logger logger = LogManager.getLogger(Main.class);

//    private static String exportSQL ="SELECT COMPANY_ID,BRANCH_COMPANY_ID FROM  CS_CREDIT.VW_COMPY_BRANCH WHERE COMPANY_ID IS NOT NULL AND BRANCH_COMPANY_ID IS NOT NULL";
    private static String exportSQL ="SELECT COMPANY_ID,BRANCH_ID FROM  CS_GS_DM.VW_COMPY_BRANCH_XYGS WHERE COMPANY_ID IS NOT NULL AND BRANCH_ID IS NOT NULL";

    private static String update_query =
            "USING PERIODIC COMMIT 10000 \n" +
                    "LOAD CSV  \n" +
                    "WITH HEADERS \n" +
                    "FROM 'file:///${csv_url}' AS LINE\n" +
                    " MATCH (C:COMPANY) WHERE C.COMPANY_ID = LINE.COMPANY_ID  \n" +
                    " MATCH (D:COMPANY) WHERE D.COMPANY_ID = LINE.BRANCH_COMPANY_ID  \n" +
                    " MERGE (C)-[:BRANCH]->(D)";



    @Test
    public void getBranchDataToCSV() throws Exception {
        File dir = UtilConfig.file("/data/update/" + UtilConfig.getData() + "/companybranch");
        UpdatePrivateCompanyFromCsv updatePrivateCompanyFromCsv = new UpdatePrivateCompanyFromCsv();
        updatePrivateCompanyFromCsv.exportDataByQueryToDirFiles(dir,exportSQL,"");
    }

    public void updateCSVToNeo4j(String targetNeo4j) throws Exception {
        File dir = UtilConfig.file("/data/update/" + UtilConfig.getData() + "/companybranch");

        String[] array = dir.list();
        if(array==null) {
            return;
        }
        for (String targetCSVDir :array) {
            UtilConfig.loadCSVAndExcute(dir,targetCSVDir,targetNeo4j,update_query);
        }
    }


    public static void main(String[] args) throws Exception {
        String targetNeo4j = "dbConnectionConfig_test.properties";
        if(args.length!=0) {
            targetNeo4j = UtilConfig.getEnvironment(args[0]);
            logger.debug(args[0]+":"+targetNeo4j);
        }
        UpdateCompanyBranchRelationFromOracle updateCompanyBranchRelationFromOracle = new UpdateCompanyBranchRelationFromOracle();
        updateCompanyBranchRelationFromOracle.getBranchDataToCSV();
        updateCompanyBranchRelationFromOracle.updateCSVToNeo4j(targetNeo4j);
    }
}
