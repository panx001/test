package spring.data.neo4j.util;

/**
 * Created by wuchenglong on 2018/3/16.
 */

@SuppressWarnings( "unused")
public class UtilExportSqlImportCql {

    public static String DELETE_OLD_FR =
                    "// 基本信息, 删除已有的关系\n     " +
                    "USING PERIODIC COMMIT 10000 \n" +
                    "LOAD CSV  \n" +
                    "WITH HEADERS \n" +
                    "FROM 'file:///${csv_url}' AS LINE\n" +
                    "WITH LINE  \n" +
                    "MATCH (C:COMPANY{COMPANY_ID:LINE.COMPANY_ID})<-[R:WORK{POSITION:'法定代表人'}]-()" +
                    "WHERE NOT (EXISTS(C.COMPANY_TYPE_LIST) AND ANY(ELEM IN ['A股','B股','H股','三板股'] WHERE ELEM IN C.COMPANY_TYPE_LIST ))\n" +
                    "DELETE R \n";
    public static String DELETE_OLD_SHA_COM =
                    "USING PERIODIC COMMIT 10000 \n" +
                    "LOAD CSV\n" +
                    "    WITH HEADERS\n" +
                    "    FROM 'file:///${csv_url}' AS LINE\n" +
                    "    WITH LINE WHERE LINE.SHAREHD_TYPE = '2'\n" +
                    "MATCH (C:COMPANY{COMPANY_ID:LINE.COMPANY_ID}) WHERE NOT (EXISTS(C.COMPANY_TYPE_LIST) AND ANY(ELEM IN ['A股','B股','H股','三板股'] WHERE ELEM IN C.COMPANY_TYPE_LIST )) \n" +
                    "MATCH (C)<-[R:INVEST]-(:COMPANY{COMPANY_ID:LINE.SHAREHD_ID})\n" +
                    "DELETE R;";
    public static String DELETE_OLD_SHA_PER =
                    "USING PERIODIC COMMIT 10000 \n" +
                    "LOAD CSV\n" +
                    "    WITH HEADERS\n" +
                    "    FROM 'file:///${csv_url}' AS LINE\n" +
                    "    WITH LINE WHERE LINE.SHAREHD_TYPE = '1'\n" +
                    "MATCH (C:COMPANY{COMPANY_ID:LINE.COMPANY_ID}) WHERE NOT (EXISTS(C.COMPANY_TYPE_LIST) AND ANY(ELEM IN ['A股','B股','H股','三板股'] WHERE ELEM IN C.COMPANY_TYPE_LIST )) \n" +
                    "MATCH (C)<-[R:INVEST]-(:PERSON{PERSON_NM:LINE.SHAREHD_NAME})\n" +
                    "DELETE R;";
    public static String DELETE_OLD_EMP =
                    "// 基本信息, 删除已有的关系\n" +
                    "USING PERIODIC COMMIT 10000 \n" +
                    "LOAD CSV  WITH HEADERS  \n" +
                    "FROM 'file:///${csv_url}' AS LINE \n" +
                    "WITH LINE  \n" +
                    "MATCH (C:COMPANY{COMPANY_ID:LINE.COMPANY_ID})\n" +
                    "     WHERE NOT (EXISTS(C.COMPANY_TYPE_LIST) AND ANY(ELEM IN ['A股','B股','H股','三板股'] WHERE ELEM IN C.COMPANY_TYPE_LIST ))\n" +
                    "MATCH (C)<-[R:WORK{POSTION:LINE.POSITION}]-(P:PERSON{PERSON_NM:LINE.PERSON_NM})\n" +
                    "DELETE R ;";



    public static String UPDATE_BASIC_INFO =
                    "// 基本信息 \n" +
                    "USING PERIODIC COMMIT 10000 \n" +
                    "LOAD CSV  \n" +
                    "WITH HEADERS \n" +
                    "FROM 'file:///${csv_url}' AS LINE\n" +
                    "WITH apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP,LINE \n" +
                    "WHERE LINE.COMPANY_ID IS NOT NULL\n" +
                    "MERGE (C:COMPANY{COMPANY_ID:LINE.COMPANY_ID}) \n" +
                    "     SET  \n" +
                    "          C.COMPANY_NM = TOSTRING(REPLACE(REPLACE(LINE.COMPANY_NM,'（','(') ,'）',')')), \n" +
                    "          C.REG_CAPITAL = LINE.REG_CAPITAL, \n" +
                    "          C.STATUS = LINE.CONSTANT_NM, \n" +
                    "          C.ORGNUM = LINE.ORGNUM \n" +
                    "WITH LINE ,TIME_STAMP,C \n" +
                    "     WHERE LINE.LEG_REPRESENT IS NOT NULL AND NOT LINE.LEG_REPRESENT = ''\n" +
                    "//  删除历史的法定代表人关系\n" +
                    "OPTIONAL MATCH (C)<-[R0:WORK{POSITION:'法定代表人'}]-() \n" +
                    "DELETE R0\n" +
                    "WITH LINE ,TIME_STAMP,C \n" +
                    "OPTIONAL MATCH (F:COMPANY{COMPANY_NM:LINE.LEG_REPRESENT})\n" +
                    "// 法人代表是企业\n" +
                    "FOREACH(ignoreMe IN CASE WHEN F IS NOT NULL THEN [1] ELSE [] END |\n" +
                    "     MERGE (F)-[R:WORK{POSITION:'法定代表人'}]->(C) \n" +
                    "        SET   \n" +
                    "            R.TIME_STAMP = TIME_STAMP \n" +
                    "         ) \n" +
                    "// 法人代表是自然人\n" +
                    "FOREACH(ignoreMe IN CASE WHEN F IS  NULL THEN [1] ELSE [] END |  \n" +
                    "     MERGE (S:PERSON{PERSON_ID:LINE.COMPANY_ID+TOSTRING(LINE.LEG_REPRESENT)}) \n" +
                    "      ON CREATE SET \n" +
                    "         S.TIME_STAMP = TIME_STAMP,  \n" +
                    "         S.PERSON_NM = TOSTRING(LINE.LEG_REPRESENT) \n" +
                    "    MERGE (S)-[R:WORK{POSITION:'法定代表人'}]->(C) \n" +
                    "      SET   \n" +
                    "          R.TIME_STAMP = TIME_STAMP \n" +
                    "        ) ;" ;

    public static String UPDATE_SHA_INFO =
                    "USING PERIODIC COMMIT 10000 \n" +
                    "LOAD CSV  WITH HEADERS \n" +
                    "FROM 'file:///${csv_url}' AS LINE\n" +
                    "WITH apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP,LINE \n" +
                    "    WHERE LINE.COMPANY_ID IS NOT NULL AND LINE.SHAREHD_NAME IS NOT NULL\n" +
                    "MATCH (C:COMPANY{COMPANY_ID:LINE.COMPANY_ID}) \n" +
                    "    WHERE NOT (EXISTS(C.COMPANY_TYPE_LIST) AND ANY(ELEM IN ['A股','B股','H股','三板股'] WHERE ELEM IN C.COMPANY_TYPE_LIST ))\n" +
                    "WITH LINE,TIME_STAMP,C\n" +
                    "FOREACH(ignoreMe IN CASE WHEN LINE.SHAREHD_TYPE = '2' AND LINE.SHAREHD_ID IS NOT NULL THEN [1] ELSE [] END |  \n" +
                    "    MERGE (S:COMPANY{COMPANY_ID:LINE.SHAREHD_ID}) \n" +
                    "        ON CREATE SET \n" +
                    "            S.TIME_STAMP = TIME_STAMP,  \n" +
                    "            S.COMPANY_NM = REPLACE(REPLACE(LINE.SHAREHD_NAME,'（','(') ,'）',')'),  \n" +
                    "            S.REG_CAPITAL = LINE.REG_CAPITAL   \n" +
                    "    MERGE (S)-[R:INVEST]->(C) \n" +
                    "        SET \n" +
                    "            R.NUM = LINE.PAID_AMT, \n" +
                    "            R.TIME_STAMP = TIME_STAMP \n" +
                    "            )\n" +
                    "FOREACH(ignoreMe IN CASE WHEN LINE.SHAREHD_TYPE = '1' THEN [1] ELSE [] END |  \n" +
                    "    MERGE (S:PERSON{PERSON_ID:LINE.COMPANY_ID+TOSTRING(LINE.SHAREHD_NAME)}) \n" +
                    "        ON CREATE SET \n" +
                    "            S.TIME_STAMP = TIME_STAMP,  \n" +
                    "            S.PERSON_NM = TOSTRING(LINE.SHAREHD_NAME)   \n" +
                    "    MERGE (S)-[R:INVEST]->(C) \n" +
                    "        SET \n" +
                    "            R.NUM = LINE.PAID_AMT, \n" +
                    "            R.TIME_STAMP = TIME_STAMP \n" +
                    "            );";


    public static String UPDATE_SHAINFO_COM =
                    "USING PERIODIC COMMIT 10000 \n" +
                    "LOAD CSV  WITH HEADERS \n" +
                    "FROM 'file:///${csv_url}' AS LINE\n" +
                    "WITH apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP,LINE \n" +
                    "    WHERE LINE.SHAREHD_TYPE = '2' AND LINE.COMPANY_ID IS NOT NULL AND LINE.SHAREHD_NAME IS NOT NULL\n" +
                    "MATCH (C:COMPANY{COMPANY_ID:LINE.COMPANY_ID}) \n" +
                    "    WHERE NOT (EXISTS(C.COMPANY_TYPE_LIST) AND ANY(ELEM IN ['A股','B股','H股','三板股'] WHERE ELEM IN C.COMPANY_TYPE_LIST ))\n" +
                    "MATCH (S:COMPANY{COMPANY_ID:LINE.SHAREHD_ID}) \n" +
                    "MERGE (S)-[R:INVEST]->(C) \n" +
                    "    SET \n" +
                    "        R.NUM = LINE.PAID_AMT, \n" +
                    "        R.TIME_STAMP = TIME_STAMP;";
    public static String UPDATE_SHAINFO_PER =
            "USING PERIODIC COMMIT 10000 \n" +
            "LOAD CSV  WITH HEADERS \n" +
            "FROM 'file:///${csv_url}' AS LINE\n" +
            "WITH apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP,LINE \n" +
            "    WHERE LINE.SHAREHD_TYPE = '1' AND LINE.COMPANY_ID IS NOT NULL AND LINE.SHAREHD_NAME IS NOT NULL\n" +
            "MATCH (C:COMPANY{COMPANY_ID:LINE.COMPANY_ID}) \n" +
            "    WHERE NOT (EXISTS(C.COMPANY_TYPE_LIST) AND ANY(ELEM IN ['A股','B股','H股','三板股'] WHERE ELEM IN C.COMPANY_TYPE_LIST ))\n" +
            "MERGE (S:PERSON{PERSON_ID:LINE.COMPANY_ID+TOSTRING(LINE.SHAREHD_NAME)}) \n" +
            " ON CREATE SET \n" + "     S.TIME_STAMP = TIME_STAMP,  \n" +
            "     S.PERSON_NM = TOSTRING(LINE.SHAREHD_NAME)\n" +
            "WITH LINE,S,TIME_STAMP\n" +
            "MERGE (S)-[R:INVEST]->(C) \n" +
            "    SET \n" +
            "        R.NUM = LINE.PAID_AMT, \n" +
            "        R.TIME_STAMP = TIME_STAMP;";


    public static String UPDATE_PERSON_INFO =
                    "// 主要人员 \n" +
                    "USING PERIODIC COMMIT 10000 \n" +
                    "LOAD CSV WITH HEADERS \n" +
                    "FROM 'file:///${csv_url}' AS LINE\n" +
                    "WITH LINE,apoc.date.format(timestamp()+8*60*60*100,'ms', 'yyyy-MM-dd HH:mm:ss') as TIME_STAMP\n" +
                    "     WHERE LINE.COMPANY_ID IS NOT NULL AND LINE.POSITION IS NOT NULL \n" +
                    "MATCH (C:COMPANY{COMPANY_ID:LINE.COMPANY_ID}) \n" +
                    "     WHERE NOT (EXISTS(C.COMPANY_TYPE_LIST) AND ANY(ELEM IN ['A股','B股','H股','三板股'] WHERE ELEM IN C.COMPANY_TYPE_LIST ))\n" +
                    "MERGE (S:PERSON{PERSON_ID:LINE.COMPANY_ID+TOSTRING(LINE.PERSON_NM)}) \n" +
                    "    ON CREATE SET \n" +
                    "        S.TIME_STAMP = TIME_STAMP,  \n" +
                    "        S.PERSON_NM = TOSTRING(LINE.PERSON_NM) \n" +
                    "MERGE (S)-[R:WORK{POSITION:LINE.POSITION}]->(C) \n" +
                    "     ON CREATE SET   \n" +
                    "         R.TIME_STAMP = TIME_STAMP ;" ;


    public static String EXPORT_SHA_INFO_DEL =
                    "SELECT\n" +
                    "    A.COMPANY_ID,\n" +
                    "    A.SHAREHD_TYPE,\n" +
                    "    A.SHAREHD_ID,\n" +
                    "    A.SHAREHD_NAME,\n" +
                    "    A.PAID_AMT\n" +
                    "FROM\n" +
                    "    CS_DM.DEL_TYC_COMPY_SHAREHDINVEST A\n" +
                    "WHERE\n" +
                    "    A.UPDT_DT > SYSDATE - %s";
    public static String EXPORT_EMP_INFO_DEL =
                    "SELECT\n" +
                    "    A.COMPANY_ID,\n" +
                    "    A.PERSON_NM,\n" +
                    "    CASE WHEN A.POSITION IS NULL THEN '未知' ELSE A.POSITION END AS POSITION\n" +
                    "FROM\n" +
                    "    CS_DM.DEL_TYC_COMPY_EMPLOYEE A\n" +
                    "WHERE\n" +
                    "    UPDT_DT > SYSDATE - %s";
    public static String EXPORT_EMP_INFO =
                    "SELECT\n" +
                    "    A.COMPANY_ID,\n" +
                    "    A.PERSON_NM,\n" +
                    "    CASE WHEN A.POSITION IS NULL THEN '未知' ELSE A.POSITION END AS POSITION   \n" +
                    "FROM\n" +
                    "    CS_GS_DM.VW_COMPY_EMPLOYEE_XYGS A\n" +
                    "WHERE\n" +
                    "    A.SRC_CD = 'TYCGS'\n" +
                    "AND UPDT_DT > SYSDATE - %s";

    public static String EXPORT_SHA_INFO =
                    "SELECT\n" +
                    "    A.COMPANY_ID,\n" +
                    "    A.SHAREHD_NAME,\n" +
                    "    A.SHAREHD_TYPE,\n" +
                    "    WHEN A.SHAREHD_ID <> -1 THEN TO_CHAR(A.SHAREHD_ID) ELSE TO_CHAR(COMPANY_ID)||SHAREHD_NAME END SHAREHD_ID,\n" +
                    "    A.PAID_AMT,\n" +
                    "    B.REG_CAPITAL\n" +
                    "FROM\n" +
                    "    CS_GS_DM.VW_COMPY_SHAREHDINVEST_XYGS A\n" +
                    "LEFT JOIN\n" +
                    "    CS_GS_DM.VW_COMPY_BASICINFO B\n" +
                    "ON\n" +
                    "    A.SHAREHD_ID = B.COMPANY_ID\n" +
                    "WHERE\n" +
                    "    A.SRC_CD = 'TYCGS AND A.ISDEL = 0'\n" +
                    "AND A.UPDT_DT > SYSDATE - %s";
    public static String EXPORT_BASIC_INFO = "\n"+
                    "SELECT\n" +
                    "    COMPANY_NM,\n" +
                    "    COMPANY_ID,\n" +
                    "    LEG_REPRESENT,\n" +
                    "    REG_CAPITAL,\n" +
                    "    E.CONSTANT_NM,\n" +
                    "    ORGNUM\n" +
                    "FROM\n" +
                    "    CS_GS_DM.VW_COMPY_BASICINFO A\n" +
                    "LEFT JOIN\n" +
                    "    CS_CREDIT.LKP_NUMBCODE E\n" +
                    "ON\n" +
                    "    A.COMPANY_ST = E.CONSTANT_CD\n" +
                    "AND E.CONSTANT_TYPE =3\n" +
                    "WHERE\n" +
                    " A.UPDT_DT > SYSDATE - %s";
}
