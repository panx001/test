package spring.data.neo4j;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.neo4j.driver.v1.Record;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.driver.v1.Value;
import org.neo4j.driver.v1.Values;
import org.neo4j.ogm.response.model.QueryStatisticsModel;
import spring.data.neo4j.config.DbConnectionConfig;
import spring.data.neo4j.neo4jConnector.Neo4jAccess;
import spring.data.neo4j.util.UtilConfig;

import java.util.*;

/**
 * Created by wuchenglong on 2018/1/12.
 */

public class MergeDuplicateNode {
    private static final Logger LOGGER = LogManager.getLogger(MergeDuplicateNode.class);

    private static final HashMap<String, List<String>> mergeType = new HashMap<String, List<String>>() {{
        put("CONTROLLER", Collections.singletonList("RELATION_TYPE"));
        put("CUSTOMER", Collections.singletonList("SOURCE"));
        put("GUARANTEE", Arrays.asList("GUAR_START_DT", "GUAR_AMT", "GUAR_DEADLINE", "GUAR_METHOD"));
        put("GUARANTEE_TOTAL", Collections.singletonList("TOTAL_GUAR_AMT"));
        put("INVEST", Collections.singletonList("SHA_RATIO"));
        put("ISSUE", Collections.singletonList("RELATIONSHIP"));
        put("MANAGER", Collections.singletonList("RELATIONSHIP"));
        put("RELATIVE", Collections.singletonList("RELATION_TYPE"));
        put("SUPPLIER", Collections.singletonList("SOURCE"));
        put("TRUSTEE", Collections.singletonList("RELATIONSHIP"));
        put("WORK", Collections.singletonList("POSITION"));
    }};

    private static void mergeDuplicateNodesWithNodeIds(int nodeToDelId, int nodeToKeppId, Neo4jAccess neo4jAccess) {
        //找到与需要删除节点相关的所有relation
        Boolean delReplaceNodeId = true;
        //合并重复节点
        LOGGER.debug("合并重复节点");
        StatementResult result = neo4jAccess.session.run(" start P=Node({nodeToDelId}) match (P)-[r]-(S) return r, ID(S) as rel_id,ID(startNode(r)) as start_id;", Values.parameters("nodeToDelId", nodeToDelId, "replace_node_id", nodeToKeppId));
        LOGGER.debug("合并节点相关的边");
        for (Record res : result.list()) {
            Value relationshipValue = res.get("r");
            //判断关系方向
            String directionIn = res.get("rel_id").equals(res.get("start_id")) ? "<" : "";
            String directionOut = res.get("rel_id").equals(res.get("start_id")) ? "" : ">";
            //判断环状关系
            Boolean circleFlag = res.get("rel_id").asInt() == nodeToDelId;

            //拼接set属性
            List<String> allPropertySet = new ArrayList<>();
            if (relationshipValue.asRelationship().size() != 0) {
                for (String key : relationshipValue.asRelationship().keys()) {
                    allPropertySet.add("R." + key + "='" + relationshipValue.asRelationship().get(key).asString() + "'");
                }
            }

            String propertySetString = "";
            if (!allPropertySet.isEmpty()) {
                propertySetString += "\n   SET " + String.join(",", allPropertySet);
            }

            //拼接merge属性
            List<String> propertyMerge = new ArrayList<>();
            String mergeString = "";
            if (relationshipValue.asRelationship().size() != 0) {
                for (String key : relationshipValue.asRelationship().keys()) {
                    if (mergeType.get(relationshipValue.asRelationship().type()).contains(key)) {
                        propertyMerge.add(key + ":'" + relationshipValue.asRelationship().get(key).asString() + "'");
                    }

                }
            }
            if (!propertyMerge.isEmpty()) {
                mergeString += "{" + String.join(",", propertyMerge) + "}";
            }
            String baseQueryCql = "\n// -------- \nSTART P1=NODE(%s),P2=NODE(%s) MERGE (P1)%s-[R:%s%s]-%s(P2)";
            String relMergeCql;
            if (circleFlag) {
                LOGGER.debug("环状关系");
                relMergeCql = String.format(baseQueryCql, String.valueOf(nodeToKeppId), String.valueOf(nodeToKeppId), directionIn, relationshipValue.asRelationship().type(), mergeString, directionOut) + propertySetString + "\n// -------- \n";
            } else {
                relMergeCql = String.format(baseQueryCql, String.valueOf(nodeToKeppId), res.get("rel_id"), directionIn, relationshipValue.asRelationship().type(), mergeString, directionOut) + propertySetString + "\n// -------- \n";
            }
            LOGGER.debug(relMergeCql);
            neo4jAccess.session.run(relMergeCql);
        }
        LOGGER.debug("合并节点本身不重复属性");
        Record nodeToDelRecord = neo4jAccess.session.run("start C=Node({nodeToDelId}) RETURN C", Values.parameters("nodeToDelId", nodeToDelId)).list().get(0);
        Record nodeToKeepRecord = neo4jAccess.session.run("start C=Node({replace_node_id}) RETURN C", Values.parameters("replace_node_id", nodeToKeppId)).list().get(0);

        List<String> nodeToKeepProperties = new ArrayList<>();
        List<String> updateNodeInfoProperties = new ArrayList<>();
        String updateNodeInfoCql = "\n// -------- \nSTART R=NODE(%s) \nSET %s; \n// -------- \n";

        Value nodeToDel = nodeToDelRecord.get("C");
        Value nodeToKeep = nodeToKeepRecord.get("C");
        for (String key : nodeToKeep.asNode().keys()) {
            nodeToKeepProperties.add(key);
        }

        for (String label : nodeToDel.asNode().labels()) {
            updateNodeInfoProperties.add("R:" + label);
        }

        for (String key : nodeToDel.asNode().keys()) {
            if (!nodeToKeepProperties.contains(key) && !Arrays.asList("PERSON_ID", "COMPANY_ID", "SECURITY_ID").contains(key)) {
                // 节点的 UNIQUE  Constraints 属性，不会进行更新
                updateNodeInfoProperties.add("R." + key + "='" + nodeToDel.asNode().get(key).asString() + "'");
            }
        }
        System.out.println(String.format(updateNodeInfoCql, nodeToKeppId, String.join(",", updateNodeInfoProperties)));
        neo4jAccess.session.run(String.format(updateNodeInfoCql, nodeToKeppId, String.join(",", updateNodeInfoProperties)));

        LOGGER.debug("删除不需要节点");
        if (delReplaceNodeId) {
             StatementResult delete_relation_result = neo4jAccess.session.run("START P=NODE({nodeToDelId}) MATCH (P)-[R]-()  DELETE R;", Values.parameters("nodeToDelId",nodeToDelId));
             StatementResult delete_node_result = neo4jAccess.session.run("START P=NODE({nodeToDelId}) DELETE P;", Values.parameters("nodeToDelId",nodeToDelId));
             QueryStatisticsModel queryStatisticsModel = new QueryStatisticsModel();
             queryStatisticsModel.setProperties_set(delete_relation_result.consume().counters().propertiesSet());
             LOGGER.debug(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet());
             QueryStatisticsModel queryStatisticsModel2 = new QueryStatisticsModel();
             queryStatisticsModel2.setProperties_set(delete_node_result.consume().counters().propertiesSet());
             LOGGER.debug(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel2).entrySet());
        }
    }

    public static void main(String[] args) {
        test();
    }
    public static void test() {
            //连接数据库
            DbConnectionConfig dbConnectionConfig = null;
            try {
                dbConnectionConfig = (DbConnectionConfig) UtilConfig.configFileToBean("dbConnectionConfig.properties", DbConnectionConfig.class);
            } catch (Exception e) {
                e.printStackTrace();
            }
            Neo4jAccess neo4jAccess = new Neo4jAccess(dbConnectionConfig);
            neo4jAccess.establishConnection();
            mergeDuplicateNodesWithNodeIds(186, 164, neo4jAccess);
            //断开数据库连接
            neo4jAccess.closeConnection();
    }
}


// // StatementResult result = session.run( "MATCH (a:PERSON)   RETURN a, a.PERSON_NM AS PERSON_NM LIMIT 2 " );
// System.out.println(result.summary().counters());
// System.out.println(new org.apache.commons.beanutils.BeanMap(result.summary()).entrySet());
// System.out.println(result.summary());
//
// QueryStatisticsModel queryStatisticsModel = new QueryStatisticsModel();
// queryStatisticsModel.setProperties_set(result.consume().counters().propertiesSet());
// System.out.println(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet());
// while ( result.hasNext() )
// {
//     Record record = result.next();
//     System.out.println(record);
//     System.out.println(record.get("a").get("PERSON_NM"));
//     System.out.println( record.get( "PERSON_ID" ).asString() + " " + record.get("PERSON_NM").asString() );
// }
