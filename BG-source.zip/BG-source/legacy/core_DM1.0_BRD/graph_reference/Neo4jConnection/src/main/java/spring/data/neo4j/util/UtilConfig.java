package spring.data.neo4j.util;

import java.io.File;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
import org.apache.commons.lang.text.StrSubstitutor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.ogm.response.model.QueryStatisticsModel;
import spring.data.neo4j.config.DbConnectionConfig;
import spring.data.neo4j.neo4jConnector.Neo4jAccess;

/**
 * Created by wuchenglong on 2018/1/15.
 */


public class UtilConfig {

    private static final Logger LOGGER = LogManager.getLogger(UtilConfig.class);

    /**
     * 初始化配置文件
     */
    public static void initConfig(String configFileName, Class<?> mappingClass) throws Exception {
        Map<String, String> map = convertToMap(configFileName);
        mapping(map, mappingClass);
        LOGGER.info("Loading config file successfully");
    }

    public static Object configFileToBean(String configFileName, Class<?> mappingClass) throws Exception {
        Map<String, String> map = convertToMap(configFileName);
        return mapping(map, mappingClass);
    }

    public static String getEnvironment(String para) {
        String targetNeo4j;
        switch (para) {
            case "prod":
                targetNeo4j = "dbConnectionConfig.properties";
                break;
            case "uat":
                targetNeo4j = "dbConnectionConfig_uat.properties";
                break;
            default:
                targetNeo4j = "dbConnectionConfig_test.properties";
                break;
        }
        return targetNeo4j;
    }

    private static Map<String, String> convertToMap(String configFileName) throws Exception {
        LOGGER.debug(configFileName);
        Map<String, String> map = new HashMap<>();
        try {
            Properties prop = new Properties();
            prop.load(new InputStreamReader(UtilConfig.class.getClassLoader().getResourceAsStream(configFileName),
                    "utf-8"));
            for (Object k : prop.keySet()) {
                Object v = prop.get(k);
                String key = String.valueOf(k), value = String.valueOf(v);
                map.put(key, value);
            }
        } catch (Exception e) {
            LOGGER.error("Occurring an exception when to execute the method 'convertToMap' for {}", e);
            throw e;
        }
        return map;
    }

    private static Object mapping(Map<String, String> map, Class<?> obj) throws  Exception {
        Object mappingClass = obj.newInstance();

        Field[] fields = obj.getFields();
        for (Field f : fields) {
            String val = map.get(f.getName());
            if (val == null || val.length() == 0) {
                continue;
            }
            if (f.getType() == Integer.class || f.getType() == int.class) {
                f.set(mappingClass, Integer.valueOf(val));
            } else if (f.getType() == Byte.class || f.getType() == byte.class) {
                f.set(mappingClass, Byte.valueOf(val));
            } else if (f.getType() == Long.class || f.getType() == long.class) {
                f.set(mappingClass, Long.valueOf(val));
            } else if (f.getType() == Short.class || f.getType() == short.class) {
                f.set(mappingClass, Short.valueOf(val));
            } else if (f.getType() == String.class) {
                f.set(mappingClass, String.valueOf(val));
            } else if (f.getType() == Double.class || f.getType() == double.class) {
                f.set(mappingClass, Double.valueOf(val));
            } else if (f.getType() == Float.class || f.getType() == float.class) {
                f.set(mappingClass, Float.valueOf(val));
            } else if (f.getType() == Boolean.class || f.getType() == boolean.class) {
                f.set(mappingClass, Boolean.valueOf(val));
            } else if (f.getType() == List.class || f.getType() == ArrayList.class
                    || f.getType() == LinkedList.class) {
                List<String> list = new ArrayList<>();
                Collections.addAll(list, val.split(";"));
                f.set(mappingClass, list);
            } else {
                throw new Exception("unsupported data type");
            }
        }
        return mappingClass;
    }
    public static String getData() {
        SimpleDateFormat df = new SimpleDateFormat("yyyy_MM_dd");
        df.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai"));
        return df.format(new Date());
    }
    public static File file(String section){
        File directory = new File(section);
        boolean dirMk =  directory.mkdirs();
        return directory;
    }

    public static void loadCSVAndExcute(File dir,String targetCSVDir,String targetNeo4j,String update_query){
        HashMap<String, String> paraHashMap = new HashMap<String, String>();
        DbConnectionConfig dbConnectionConfig = null;
        paraHashMap.put("csv_url",new File(dir,targetCSVDir).getAbsolutePath().replace("\\","\\\\"));
        StrSubstitutor sub = new StrSubstitutor(paraHashMap);
        String updateQuery = sub.replace(update_query);
        // logger.debug(updateQuery);
        LOGGER.debug("执行内存清理");
        UtilConfig.exec("sync && echo 1 > /proc/sys/vm/drop_caches");
        UtilConfig.exec("sync && echo 2 > /proc/sys/vm/drop_caches");
        UtilConfig.exec("sync && echo 3 > /proc/sys/vm/drop_caches");
        LOGGER.debug("内存清理完成");
        try {
            dbConnectionConfig = (DbConnectionConfig) UtilConfig.configFileToBean(
                    targetNeo4j,
                    DbConnectionConfig.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try{
            Neo4jAccess neo4jAccess = new Neo4jAccess(dbConnectionConfig);
            neo4jAccess.establishConnection();
            StatementResult result = neo4jAccess.session.run(updateQuery);
            QueryStatisticsModel queryStatisticsModel = new QueryStatisticsModel();
            queryStatisticsModel.setProperties_set(result.consume().counters().propertiesSet());
            LOGGER.debug(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel).entrySet().stream().filter(w -> w.getValue() instanceof Integer).filter(w -> (Integer) w.getValue() != 0).collect(Collectors.toList()));
            neo4jAccess.closeConnection();
        }
        catch (Exception e) {
            LOGGER.debug(e);
        }
        //暂停一分钟以便neo4j处理更新
        LOGGER.debug("睡眠一分钟");
        UtilConfig.exec("sleep 60s");
    }

    public static Object exec(String cmd) {
        try {
            String[] cmdA = { "/bin/sh", "-c", cmd };
            Process process = Runtime.getRuntime().exec(cmdA);
            LineNumberReader br = new LineNumberReader(new InputStreamReader(
                    process.getInputStream()));
            StringBuffer sb = new StringBuffer();
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line);
                sb.append(line).append("\n");
            }
            return sb.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}