package spring.data.neo4j.neo4jConnector;

/**
 * Created by wuchenglong on 2018/1/12.
 */


import org.neo4j.driver.v1.AuthTokens;
import org.neo4j.driver.v1.Driver;
import org.neo4j.driver.v1.GraphDatabase;
import org.neo4j.driver.v1.Session;

public class Neo4jClient
{
    Driver driver;
    Session session;

    public Neo4jClient(){
    }

    public void connect() {
        this.driver = GraphDatabase.driver( "bolt://localhost", AuthTokens.basic( "neo4j", "AllIsGood" ) );
        this.session = driver.session();
        System.out.println("Neo4j successfully dconnected");
    }

    public void disconnect() {
        this.session.close();
        this.driver.close();
        System.out.println("Neo4j successfully disconnected");
    }

}
