package spring.data.neo4j.neo4jConnector;

/**
 * Created by wuchenglong on 2018/1/12.
 */


import org.neo4j.driver.v1.AuthTokens;
import org.neo4j.driver.v1.Driver;
import org.neo4j.driver.v1.GraphDatabase;
import org.neo4j.driver.v1.Session;
import spring.data.neo4j.config.DbConnectionConfig;


public class Neo4jAccess {
    private Driver driver = null;
    public Session session = null;
    private String uri;
    private String user;
    private String password;

    public Neo4jAccess(String uri, String user, String password){
        this.uri = uri;
        this.user = user;
        this.password = password;
    }

    public Neo4jAccess(DbConnectionConfig dbConnectionConfig){
        this.uri = DbConnectionConfig.neo4jUri;
        this.user = DbConnectionConfig.neo4jUserName;
        this.password = DbConnectionConfig.neo4jPassword;
    }

    public void establishConnection() {
        try {
            driver = GraphDatabase.driver(this.uri, AuthTokens.basic(this.user, this.password));
            session = driver.session();
            System.out.println("Successfully connected to Neo4j Database");
        } catch (Exception e) {
            System.out.println("Fail to connect to Neo4j Database");
            e.printStackTrace();
        }
    }

    public void closeConnection() {
        try {
            if (driver != null) {
                driver.close();
            }
            if (session != null) {
                session.close();
            }
            System.out.println("Neo4j successfully disconnected");
        } catch (Exception e) {
            System.out.println("Unable to disconnect Neo4j");
            e.printStackTrace();
        }
    }


    public void operate() {
        establishConnection();
        closeConnection();
    }
}