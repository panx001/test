package spring.data.neo4j.config;

/**
 * Created by wuchenglong on 2017/12/27.
 */
public class OracleDbConnectionConfig {

    public static String  JdbcDriverClassName;
    public static String JdbcUrl;
    public static String  Username;
    public static String  Password;

}
