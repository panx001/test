package spring.data.neo4j;

import org.apache.commons.lang.text.StrSubstitutor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.ogm.response.model.QueryStatisticsModel;
import spring.data.neo4j.config.DbConnectionConfig;
import spring.data.neo4j.neo4jConnector.Neo4jAccess;
import spring.data.neo4j.oracleConnector.DataCopier;
import java.io.File;
import java.io.PrintStream;
import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;

import spring.data.neo4j.util.MailUtil;
import spring.data.neo4j.util.UtilConfig;
import spring.data.neo4j.util.UtilExportSqlImportCql;


/**
 * Created by wuchenglong on 2018/3/16.
 */

public class UpdatePrivateCompanyFromCsv {

    private static Logger logger = LogManager.getLogger(UpdatePrivateCompanyFromCsv.class);


    /*以此按照value的sql查询语句将结果导出key对应的文件夹下面*/
    private static final LinkedHashMap<String, String> DATA_EXPORT_QUERY = new LinkedHashMap<String, String>() {{
        put("companyBasicInfo", UtilExportSqlImportCql.EXPORT_BASIC_INFO);
        put("companyShareholder", UtilExportSqlImportCql.EXPORT_SHA_INFO);
        put("companyShareholderDelete", UtilExportSqlImportCql.EXPORT_SHA_INFO_DEL);
        put("companyEmployee", UtilExportSqlImportCql.EXPORT_EMP_INFO);
        put("companyEmployeeDelete", UtilExportSqlImportCql.EXPORT_EMP_INFO_DEL);
    }};

    /*以此将key对应的文件夹下面的csv文件数据，通过value对应的cypher语句导入到neo4j*/
    private static final LinkedHashMap<String, List<String>> DATA_IMPORT_QUERY = new LinkedHashMap<String, List<String>>() {{
        put("companyBasicInfo", Collections.singletonList(
                // UtilExportSqlImportCql.DELETE_OLD_FR,
                UtilExportSqlImportCql.UPDATE_BASIC_INFO)
        );
        put("companyShareholderDelete", Arrays.asList(
                UtilExportSqlImportCql.DELETE_OLD_SHA_COM,
                UtilExportSqlImportCql.DELETE_OLD_SHA_PER)
        );
        put("companyShareholder", Collections.singletonList(
                UtilExportSqlImportCql.UPDATE_SHA_INFO)
        );
        put("companyEmployeeDelete", Collections.singletonList(
                UtilExportSqlImportCql.DELETE_OLD_EMP)
        );
        put("companyEmployee", Collections.singletonList(
                UtilExportSqlImportCql.UPDATE_PERSON_INFO)
        );
    }};


    static void exportDataByQueryToDirFiles(File dir, String query, String interval_days) throws Exception {
        query = String.format(query,interval_days);
        logger.debug(dir.getAbsolutePath());
        logger.debug(UtilConfig.getData());
        if(dir.list().length>0){   // 如果该文件夹下面已存在文件，则不再导出数据
            logger.debug(dir+" 已经有数据, 不再导出。");
            return;
        }
        exportOracleToCsv(dir,query);
    }

    private static void exportData(String interval_days) throws Exception{
        for (String dirName:DATA_EXPORT_QUERY.keySet()){
            logger.debug(dirName);
            File dir = UtilConfig.file("/data/update/"+UtilConfig.getData() + "/" + dirName);
            exportDataByQueryToDirFiles(dir,String.format(DATA_EXPORT_QUERY.get(dirName),interval_days),interval_days);
        }
    }

    private static void importData(String targetNeo4j) throws Exception{
        for (String dirName:DATA_IMPORT_QUERY.keySet()){
            logger.debug(dirName);
            File dir = UtilConfig.file("/data/update/"+UtilConfig.getData() + "/" + dirName);
            try{
                //执行导入前进行内存清理
                logger.debug("执行内存清理");
                UtilConfig.exec("sync && echo 1 > /proc/sys/vm/drop_caches");
                UtilConfig.exec("sync && echo 2 > /proc/sys/vm/drop_caches");
                UtilConfig.exec("sync && echo 3 > /proc/sys/vm/drop_caches");
                logger.debug("内存清理完成");
                DbConnectionConfig dbConnectionConfig = null;
                try {
                        dbConnectionConfig = (DbConnectionConfig) UtilConfig.configFileToBean(
                                targetNeo4j,
                                DbConnectionConfig.class);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                Neo4jAccess neo4jAccess  = new  Neo4jAccess(dbConnectionConfig);
                neo4jAccess.establishConnection();
                //执行csv导入
                importDataByCypherFromDirFile(dir,DATA_IMPORT_QUERY.get(dirName),neo4jAccess);
                neo4jAccess.closeConnection();
            } catch (Exception e) {
                e.printStackTrace();
            }
            //暂停一分钟以便neo4j处理更新
            logger.debug("睡眠一分钟");
            UtilConfig.exec("sleep 60s");
        }
    }

    private static void importDataByCypherFromDirFile(File dir, List<String> queryList, Neo4jAccess neo4jAccess) throws Exception{
        String[] array = dir.list();
        if(array==null) {
            return;
        }

        for (String csvFile :array) {
            HashMap<String, String> paraHashMap = new HashMap<>();
            paraHashMap.put("csv_url",new File(dir,csvFile).getAbsolutePath().replace("\\","\\\\"));
            StrSubstitutor sub = new StrSubstitutor(paraHashMap);

            for(String query:queryList){
                String updateQuery = sub.replace(query);
                logger.info(csvFile);
//                logger.info(updateQuery);
                StatementResult result_del = neo4jAccess.session.run(updateQuery);
                QueryStatisticsModel queryStatisticsModel_del = new QueryStatisticsModel();
                queryStatisticsModel_del.setProperties_set(result_del.consume().counters().propertiesSet());
                // logger.debug(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel_del).entrySet().stream().filter(w->w.getValue() instanceof Integer).collect(Collectors.toList()));
                logger.debug(new org.apache.commons.beanutils.BeanMap(queryStatisticsModel_del).entrySet().stream().filter(w->w.getValue() instanceof Integer).filter(w-> (Integer)w.getValue()!=0).collect(Collectors.toList()));
                }
        }
    }


    public static void main(String[] args) {
        try {
            String targetNeo4j = "dbConnectionConfig_test.properties";
            if(args.length!=0) {
                targetNeo4j = UtilConfig.getEnvironment(args[0]);
                logger.debug(args[0]+":"+targetNeo4j);
            }
            String interval_days = "1";
            logger.debug("interval_days: "+interval_days);
            exportData(interval_days);
            importData(targetNeo4j);
        } catch (Exception e) {
            MailUtil.sendLogEmail(args[0],"非公开企业增量更新出错:"+e.toString());
            e.printStackTrace();
        }
    }

    public static void exportOracleToCsv(File csvRoute,String query) throws Exception {

        DataCopier copier = DataCopier.getInstance("gc.properties");
        Connection conn = copier.database.openConnection();
        conn.setAutoCommit(false);

        PreparedStatement stmt = conn.prepareStatement(query,ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
        stmt.setFetchSize(50000);
        stmt.setFetchDirection(ResultSet.FETCH_REVERSE);
        ResultSet rs = stmt.executeQuery();

        try {
            PrintStream out = null;
            while(rs.next()){
                if ((rs.getRow()-1)%500000 == 0) {
                    logger.debug("正在导出文件："+rs.getRow()/500000+":"+String.valueOf(rs.getRow()));
                    out = new PrintStream(new File(csvRoute,rs.getRow()/500000+".csv"));
                    //写csv header
                    String resultLine = "";
                    ResultSetMetaData rsmd = rs.getMetaData();
                    int count=rsmd.getColumnCount();
                    for (int i=0;i<count;i++) {
                        resultLine += rsmd.getColumnName(i+1) + ",";
                    }
                    out.println(resultLine.substring(0,resultLine.length()-1));
                }
                String resultLine = "";
                for(int i=1;i<=rs.getMetaData().getColumnCount();i++){
                    resultLine = resultLine + cleanStr(rs.getString(i))+",";
                }
                resultLine = resultLine.substring(0,resultLine.length()-1);
                out.println(resultLine);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static String cleanStr(String str) {
        String result = "";
        if (str != null && !str.equals("")) {
            result ="\""+ str.replace("\"","\"\"").replace("\\","").replace("\r","").replace("\n","").replace("（","(").replace("）",")")+"\"";
        }
        return  result;
    }

}
