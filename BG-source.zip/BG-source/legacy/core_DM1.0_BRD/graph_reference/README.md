# 1. CSCS 知识图谱 Project
* import-tool
* KnowledgeGraphPortal
* Neo4jConnection
* NewsCloud
* update_neo4j_data_newversion

## import-tool
    图数据库初始化数据导出项目，导出csv文件后，执行图数据库初始化流程（目前连接的是上海gc，之后gc到深圳后需要做对应修改）
[图数据库初始化流程](#图数据库初始化流程)
## KnowledgeGraphPortal
    图谱后端接口项目，接口包括：
    1. FindRelevance        风险相关企业（portal1.0使用，2.0后已不使用）
    2. FindThumbnail        缩略图（portal1.0使用，2.0后已不使用）
    3. GetChinaDaasData     取中数数据模块（仍使用）
    4. GetGraph             企业图谱（仍使用）
    5. GetGraphExportData   图谱数据导出（暂不使用，之后可能会用）
    6. GetRelation          找关系（仍使用）
    7. GetShareholder       企业股东接口（前海项目图谱数据整合使用）
    8. GetSuspActController 疑似实控人（仍使用）

## Neo4jConnection  //图数据更新项目
    1. UpdatePrivateCompanyFromCsv 非公开企业数据增量更新（目前由于天眼查删除信息表信息过大，删除记录无法读取，各环境增量更新已暂停）
    2. Main 公开企业数据全量更新，生成cql
    3. MergeDuplicateNode 合并重复节点模块（暂无使用，自然人合并直接使用cypher完成）
    4. MergeZSPersonInfoFromOracleOneTime 中数自然人信息一次性合并到图数据库中
    5. UpdateCompanyBranchRelationFromOracle 补充分支机构信息
    6. UpdateDailyMail 邮件发送功能
    7. UpdateDataFromDaasData 从中数补充某企业数据（暂不使用，特殊情况可能会用到，代码留着）
    8. UpdateDataFromGC 从GC中补充某企业相关数据（暂不使用，特殊情况可能会用到，代码留着）
    9. UpdatePrivateCompany 使用jdbc读取数据直接构造cypher更新语句（可以运行但效率不够，未使用）
    10. UpdatePrivateCompanyRiskLabelFromOracle 从oracle中读取非公开企业风险信息补充到neo4j中
    11. UpdateRiskLabelFromRedis 从redis读取私募风险信息补充到neo4j中

## NewsCloud
    portal使用的词云功能，各文件功能见项目中readme文件

## update_neo4j_data_newversion
    通过python更新neo4j的代码备份（已不使用，但有很多过去的查询逻辑，见项目中readme）

## 数据拉取需求
    产品同学有时会有售前的数据导出测试需求我们配合拉取数据（通常情况会由数据服务组处理这些需求，但是有时候也会需要我们这边帮忙拉企业图谱（一层两层）的数据）
    数据拉取主要可以用两种方式
    1. python脚本拉取（例子在文件夹中）
    2. 使用apoc.export.csv.query命令导出文件，然后将数据文件从服务器拷贝下来（执行的命令可以参考python脚本中的查询命令）

    python_complist.py  拉取符合条件的企业名单样例
    python_shareholder.py   拉取企业股东样例
    python_maxshareholder.py    拉取最大股东样例
    python_function.py  拉取企业一层二层关联企业样例

***
***
***

# 2. 图数据库初始化流程

##   首先通过java脚本从oracle导出数据
	sudo java -jar /home/zhoujr/target/neo4j-import-1.1-SNAPSHOT.jar 2>&1&

##   csv文件导出后，需要对自然人表进行去重
	cd /data/csv/docs/ops
	nohup cat frperson-info.csv employeeperson-info.csv sharehdperson-info.csv | sort | uniq > person-info.csv 2>&1 &
    cat frperson-info.csv employeeperson-info.csv sharehdperson-info.csv | sort | uniq > person-info.csv

<!-- 去掉了产品信息，处理自然人重复问题后，neo4j-admin import的命令修改为：
	/opt/neo4j-enterprise-3.3.0/bin/neo4j-admin import --mode csv --database the_database --nodes:COMPANY "company-info-header.csv,company-info.csv" --nodes:PERSON "sharehdperson-info-header.csv,person-info.csv"   --relationships:INVEST "sharehdperson-relation-header.csv,sharehdperson-relation.csv" --relationships:INVEST "sharehdcomp-relation-header.csv,sharehdcomp-relation.csv" --relationships:WORK "employ-info-header.csv,employ-info.csv,frrelation-info.csv" --ignore-missing-nodes --ignore-duplicate-nodes -->

##    包含产品信息的更新脚本(目前产品信息在过滤以后将非企业部分批量导出，通过csv import更新)：
	/opt/neo4j-enterprise-3.3.0/bin/neo4j-admin import     --mode csv     --database the_database     --nodes:COMPANY "company-info-header.csv,company-info.csv,sharehdcompany-info.csv"     --nodes:PERSON "sharehdperson-info-header.csv,person-info.csv"     --nodes:SECURITY "security-info-header.csv,security-info.csv"     --relationships:ISSUE "issue-info-header.csv,issue-relation.csv"      --relationships:INVEST "sharehdperson-relation-header.csv,sharehdperson-relation.csv"     --relationships:INVEST "sharehdcomp-relation-header.csv,sharehdcomp-relation.csv"     --relationships:WORK "employ-info-header.csv,employ-info.csv,frrelation-info.csv"      --ignore-missing-nodes      --ignore-duplicate-nodes


##   完成导数脚本后，将数据库名字置换为graph.db
    cd /data/databases/databases
    mv the_database graph.db

##  启动neo4j
    /opt/neo4j-enterprise-3.3.0/bin/neo4j start


##   添加索引(索引文件在项目代码中有备份)
    数据库初始化后，执行 neo4j-shell -file /data/create_index.cql

##   数据库预热
    CALL apoc.warmup.run()

## 对于是公司的产品进行节点和关系更新：

// 更新 SECURITY 的COMPANY  LABEL
CALL apoc.load.jdbc('jdbc:oracle:thin:cs_gs_dm/abc123@172.19.6.12:1521/ORCL_DEV',"
SELECT  B.CONSTANT_NM,SECINNER_ID,SECURITY_CD,REPLACE(REPLACE(SECURITY_NM,'）',')'),'（','(') AS SECURITY_NM,COMPANY_ID  FROM cs_CREDIT.SECURITY A  
LEFT JOIN cs_CREDIT.LKP_CHARCODE B ON 
A.SECURITY_TYPE_ID = B.CONSTANT_ID
WHERE B.CONSTANT_NM NOT  IN ('A股','B股','H股','三板股')   
AND  A.ISDEL = 0
AND  (
    A.SECURITY_NM       LIKE '%公司' 
    OR A.SECURITY_NM       LIKE '%有限合伙%'
) -- AND A.SECINNER_ID = '17615085'
 ")yield row 
WITH row as  LINE  
WITH LINE
// LIMIT 2000
// REPLACE(REPLACE(COMPANY_NM,\\'）\\',\\')\\'),\\'（\\',\\'(\\')
OPTIONAL MATCH  (A:COMPANY{COMPANY_NM:LINE.SECURITY_NM}) WHERE NOT EXISTS(A.SECINNER_ID)
OPTIONAL MATCH  (S:SECURITY{SECINNER_ID:LINE.SECINNER_ID})
WITH LINE, COLLECT(A) AS A_LIST,COLLECT(S) AS S_LIST
WITH LINE ,A_LIST[0] AS A, S_LIST[0] AS S 
// S 存在不更新
FOREACH(LINE_ELEM IN CASE WHEN S IS NOT NULL THEN [] ELSE [] END | 
    SET 
        S:SECURITY,
        S.SOURCE = 'TEST',
        S.SECURITY_NM = LINE.SECURITY_NM  
        ) 
// S 不存在，且没有匹配到A
FOREACH(LINE_ELEM IN CASE WHEN S IS NOT NULL THEN [] ELSE CASE WHEN A IS NULL THEN [LINE] ELSE [] END END | 
    CREATE (C:SECURITY{SECINNER_ID:LINE.SECINNER_ID})
    SET 
        C.SOURCE = 'TEST',
        C.SECURITY_NM = LINE.SECURITY_NM  
        ) 
// S 不存在，匹配到A
FOREACH(LINE_ELEM IN CASE WHEN S IS NOT NULL THEN [] ELSE CASE WHEN A IS NOT NULL THEN [LINE] ELSE [] END END | 
    SET 
        A:SECURITY,
        A.SECINNER_ID = LINE.SECINNER_ID,
        A.SOURCE = 'TEST',
        A.SECURITY_NM = LINE.SECURITY_NM
        );



CALL apoc.load.jdbc('jdbc:oracle:thin:cs_gs_dm/abc123@172.19.6.12:1521/ORCL_DEV',"
SELECT  SECINNER_ID,COMPANY_ID  FROM cs_CREDIT.SECURITY A  
LEFT JOIN cs_CREDIT.LKP_CHARCODE B ON 
A.SECURITY_TYPE_ID = B.CONSTANT_ID
WHERE B.CONSTANT_NM NOT  IN ('A股','B股','H股','三板股')   
AND  A.ISDEL = 0
AND  (
    A.SECURITY_NM       LIKE '%公司' 
    OR A.SECURITY_NM       LIKE '%有限合伙%'
) -- AND A.SECINNER_ID = '17615085'
 ")yield row 
WITH row as  LINE 
WHERE ( LINE.SECINNER_ID IS NOT NULL AND NOT LINE.SECINNER_ID = '' )
    AND ( LINE.COMPANY_ID IS NOT NULL AND NOT LINE.COMPANY_ID = '' )
// CALL apoc.date.formatDefault(timestamp()+8*60*60*1000,'ms') yield value  as TIME_STAMP
MATCH (S:SECURITY{SECINNER_ID:toString(LINE.SECINNER_ID)})
MATCH (C:COMPANY{COMPANY_ID:toString(LINE.COMPANY_ID)})
MERGE(C)-[F:ISSUE{RELATIONSHIP:'发行'}]->(S) ;

## 初始化信息刷新——公开企业信息全量刷新(每日定时，初始化时执行)
    /opt/neo4j-enterprise-3.3.0/bin/neo4j-shell -host 10.100.45.35 -port 1337 -file /home/zhoujr/increaseUpdate.cql

## 初始化信息刷新——风险标签刷新（每日定时，初始化时执行）
    cd /home/zhoujr/target && java -cp  Neo4jConnection-1.1-SNAPSHOT.jar spring.data.neo4j.UpdateRiskLabelFromRedis test
    cd /home/zhoujr/target && java -cp  Neo4jConnection-1.1-SNAPSHOT.jar spring.data.neo4j.UpdatePrivateCompanyRiskLabelFromOracle test

## 初始化信息刷新——分支机构数据刷新（目前初始化时执行一次，以后每日增量（由于之前该表不更新，之前定时任务没有跑起来））
    cd /home/zhoujr/target && java -cp  Neo4jConnection-1.1-SNAPSHOT.jar spring.data.neo4j.UpdateCompanyBranchRelationFromOracle test

## neo4j导出数据初始化流程完毕

***
***
***
# 3. 项目中的一些其他配置文件信息
## cypher-refcard-3.2.pdf
    cypher语法卡片（重要！），大部分cypher基础语法都可以在其中找到。
## cypher有意思的命令合集.md
    从neo4j官方apoc文档中摘取出来的一些算法及功能备份

## haproxy配置文档.md
    生产集群的haproxy配置信息备份
### haproxy重启
 ```bash
vi /usr/local/haproxy/example_config.conf

验证conf
sudo /usr/local/haproxy/sbin/haproxy -f /usr/local/haproxy/example_config.conf -c
```
### 启动

```bash
sudo /usr/local/haproxy/sbin/haproxy -f /usr/local/haproxy/example_config.conf 
```
### 杀掉进程（注意！修改ha配置文件重启前记得将之前的ha进程kill掉，否则导致接口有时能用有时无法使用）

```bash
# killall haproxy
ps aux | grep -ie haproxy | grep -v grep | awk '{print $2}' | xargs kill -9
```

## supervisor 配置信息
    10.100.47.11:9001 user/123
    10.100.45.15:9001 user/123
    supervisord -c /etc/supervisord.conf
    supervisorctl reload

## Json2neo4j_new.cql  前海项目专用cql整理
    (1)通过中数提供的数据处理成的csv文件初始化图数据库
    (2)建索引
    (3)通过企业名称及统一社会信用代码补充company_id
    (4)没股东企业补全股东（暂不执行）
    (5)读取前海的企业列表，导出相应企业json文件（之后shawn这边定时任务会去拉数据）（目前这一步骤每天执行一次）

## 实际控制人算法.cql
    (1)受益所有人查询代码备份（目前未使用）
    (2)实际控制人查询代码备份（目前KGPortal项目中已经有了相应模块）

## 一些其他命令参考
### 服务器间数据备份命令    
    scp -r appadmin@10.100.47.21:/data/databases/databases/graph.db /data/databases/databases/graph.db2

### neo4j增量更新定时任务（公开企业全量刷新，非公开增量更新，风险信息刷新） crontab.sh
#### 公开企业全量更新命令
    java -jar /home/zhoujr/target_import/Neo4jConnection-1.1-SNAPSHOT.jar 
    执行完上述命令后会生成一个increaseUpdate.cql文件
    每天早上进行公开企业全量更新
    /opt/neo4j-enterprise-3.3.0/bin/neo4j-shell -host 10.100.45.35 -port 1337 -file /home/zhoujr/increaseUpdate.cql >>  "/data/update/`date +%Y_%m_%d`/info.log"
    
    //另，生产环境需要判断判断当前服务器是否是master节点（暂不使用，目前保证21服务器为主节点，所有更新均在10.100.47.21上进行），见10.100.47.21 crontab -l
    server1=`curl http://10.100.47.21:7474/db/manage/server/ha/master`
    server2=`curl http://10.100.47.19:7474/db/manage/server/ha/master`
    server3=`curl http://10.100.47.20:7474/db/manage/server/ha/master`
    target="10.100.47.21"
    case $server1 in
        true) target="10.100.47.21";;
    esac
    case $server2 in
        true) target="10.100.47.19";;
    esac
    case $server3 in
        true) $target="10.100.47.20";;
    esac
    echo "增量更新目标 $target" >>  "/data/update/`date +%Y_%m_%d`/info.log"
    /opt/neo4j-enterprise-3.3.0/bin/neo4j-shell -host $target -port 1337 -file /home/zhoujr/increaseUpdate.cql >>  "/data/update/`date +%Y_%m_%d`/info.log"

#### 非公开企业增量更新命令
    cd /home/zhoujr/target && java -cp  Neo4jConnection-1.1-SNAPSHOT.jar spring.data.neo4j.UpdatePrivateCompanyFromCsv test  >>  "/data/update/`date +%Y_%m_%d`/info.log"

#### 从redis更新公开企业风险标签
    cd /home/zhoujr/target && java -cp  Neo4jConnection-1.1-SNAPSHOT.jar spring.data.neo4j.UpdateRiskLabelFromRedis test  >>  "/data/update/`date +%Y_%m_%d`/info.log"

#### 从oracle更新非公开企业风险标签
    cd /home/zhoujr/target && java -cp  Neo4jConnection-1.1-SNAPSHOT.jar spring.data.neo4j.UpdatePrivateCompanyRiskLabelFromOracle test  >>  "/data/update/`date +%Y_%m_%d`/info.log"

#### 从oracle更新分支机构信息（由于该表不经常更新，因此只需要初始化以后更新一次）
    cd /home/zhoujr/target && java -cp  Neo4jConnection-1.1-SNAPSHOT.jar spring.data.neo4j.UpdateCompanyBranchRelationFromOracle test

#### log存放位置（每日增量更新的数据也在这个位置）
    /data/update/`date +%Y_%m_%d`/info.log


## Neo4j相关服务涉及到的端口

    10.100.xx.xx:7474/7475/7687    neo4j数据库 http/https/bolt端口

    10.100.45.15:7077  uat-jar

    10.100.47.11:6474  prod-slave（生产neo4j集群从节点）
    10.100.47.11:6475  prod-master（生产neo4j集群主节点）
    10.100.47.11:5474  uat-slave（目前uat只有一台服务器，暂无主从配置）
    10.100.47.11:5475  uat-master（目前uat只有一台服务器，暂无主从配置）
    
    10.100.47.11:7077  prod-jar

    10.100.45.15:50000  ha  admin/admin
    10.100.47.11:50000  ha  admin/admin

    10.100.45.15:9001   supervisor  user/123
    10.100.47.11:9001   supervisor  user/123

## 定时任务备份
```bash
#! /bin/sh

today=`date +%Y_%m_%d`
delete_day=`date -d '-30 day' +%Y_%m_%d`
echo $today
mkdir "/data/update/$today" -p
rm -rf "/data/update/$delete_day"

start="`date '+%Y-%m-%d %H:%M:%S'` 非公开企业增量更新开始"
echo $start  >>  "/data/update/`date +%Y_%m_%d`/info.log"
#cd /home/zhoujr/target && java -cp  Neo4jConnection-1.1-SNAPSHOT.jar spring.data.neo4j.UpdatePrivateCompanyFromCsv test  >>  "/data/update/`date +%Y_%m_%d`/info.log"

echo "`date '+%Y-%m-%d %H:%M:%S'` 增量更新结束" >>  "/data/update/`date +%Y_%m_%d`/info.log"
#/opt/neo4j-enterprise-3.3.0/bin/neo4j-shell -host 10.100.45.35 -port 1337 -file /home/zhoujr/increaseUpdate.cql >>  "/data/update/`date +%Y_%m_%d`/info.log"
echo "`date '+%Y-%m-%d %H:%M:%S'` 公开企业全量更新结束" >>  "/data/update/`date +%Y_%m_%d`/info.log"

cd /home/zhoujr/target && java -cp  Neo4jConnection-1.1-SNAPSHOT.jar spring.data.neo4j.UpdateRiskLabelFromRedis test  >>  "/data/update/`date +%Y_%m_%d`/info.log"
echo "`date '+%Y-%m-%d %H:%M:%S'` 公开企业风险信息更新结束" >>  "/data/update/`date +%Y_%m_%d`/info.log"
cd /home/zhoujr/target && java -cp  Neo4jConnection-1.1-SNAPSHOT.jar spring.data.neo4j.UpdatePrivateCompanyRiskLabelFromOracle test  >>  "/data/update/`date +%Y_%m_%d`/info.log"
echo "`date '+%Y-%m-%d %H:%M:%S'` 非公开企业风险信息更新结束" >>  "/data/update/`date +%Y_%m_%d`/info.log"
cd /home/zhoujr/target && java -cp  Neo4jConnection-1.1-SNAPSHOT.jar spring.data.neo4j.UpdateDailyMail test
echo "`date '+%Y-%m-%d %H:%M:%S'` 发送邮件完成" >>  "/data/update/`date +%Y_%m_%d`/info.log"

```



## Neo4j需要的conf额外配置项
    dbms.security.procedures.unrestricted=apoc.* 
    dbms.security.procedures.whitelist=apoc.*
    apoc.export.file.enabled=true
    apoc.import.file.enabled=true
    dbms.shell.enabled=true