java -cp  Neo4jConnection-1.1-SNAPSHOT.jar spring.data.neo4j.UpdateRiskLabelFromRedis test
java -cp  Neo4jConnection-1.1-SNAPSHOT.jar spring.data.neo4j.UpdatePrivateCompanyRiskLabelFromOracle test
java -cp  Neo4jConnection-1.1-SNAPSHOT.jar spring.data.neo4j.UpdateCompanyBranchRelationFromOracle test
