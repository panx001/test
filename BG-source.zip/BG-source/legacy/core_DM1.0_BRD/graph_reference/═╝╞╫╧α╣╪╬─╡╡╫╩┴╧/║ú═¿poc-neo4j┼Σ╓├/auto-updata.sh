./neo4j-enterprise-3.3.0/bin/neo4j-shell -file ./create_index.cql
./neo4j-enterprise-3.3.0/bin/neo4j-shell -file ./mergeSecurityCompany.cql
./neo4j-enterprise-3.3.0/bin/neo4j-shell -file ./increaseUpdate.cql
