# Neo4j从入门到放弃
## Neo4j简介
### 什么是Neo4j
    Neo4j最早的产品发布于2010年2月，java（Apache Lucene），开源（商用授权 GPLv3;AGPLv3）
    Neo4j、Cypher、APOC名字来源都是黑客帝国
    图数据库一直是NoSQL领域非常重要的分支，Neo4j可以说是图数据库的绝对领导者。
    #22	  Overall
    #1	  Graph DBMS
    https://db-engines.com/en/system/Neo4j
    图数据库流行度并不算太高，主要原因是目前大部份问题可以采用关系型数据库或大数据方案解决，图数据库更擅长描述基于关联关系的场景应用。
    提供了一套类似sql的图查询语言cypher，已经慢慢成为图查询语言的通过标准。
    依赖内存（集群每台数据库都有一份完整的数据）
    支持一些图结构相关算法
    
    neo4j的数据长什么样？
    1. 实体（节点）
    2. 关系（边）（连接两个节点，有向）
    3. 属性（索引、约束、复合索引）
    4. 标签（节点分组、加速索引）

    优点：
    1.高效的图遍历
    2.可视化友好（自带可视化工具）
    3.支持ACID事务
    4.支持高可用、热备份、具有高可扩展性


### Neo4j企业版（政府版）与社区版区别
    https://blog.csdn.net/graphway/article/details/78969482


## Neo4j适用场景
<!-- ### Neo4j与关系型数据库的区别
                关系型数据库                                    neo4j
存储形式        行列表                                          图形存储结构
数据建模        数据库范式                                      节点-边（没有表结构依赖）
查询性能        长于单表查询，多表查询性能依赖于join的数量和深度    长于关系查询
查询语言        sql                                             cypher -->
    大量的多表查询(关联企业查询,展示时风险信息的调取)
    关联关系挖掘（节点重要性、关键节点，关键边）
    多跳关系发现    

    典型领域:语义网，关联数据（交易欺诈）、基因分析、深度推荐

## Cypher查询语句入门
    常用命令:CREATE,MATCH,RETUEN,WHERE,DELETE(节点关系),REMOVE(属性标签),SET,ORDER BY,WITH,UNION....
    Neo4j使用CQL“CREATE”命令
    创建节点、关系、标签
    CREATE (:PERSON{PERSON_NM:'某人',PERSON_ID:'001'})
    CREATE (:COMPANY:PFCOMPANY{COMPANY_NM:'某公司'})

    MATCH
    从数据库获取有关节点和属性的数据
    从数据库获取有关节点，关系和属性的数据
    RETURN
    返回MATCH的结果
    MATCH(C) RETURN C
    MATCH(C:COMPANY) RETURN C.COMPANY_NM

    WHERE CREATE(RELATION)
    MATCH(P:PERSON) WHERE P.PERSON_NM = '某人'
    MATCH(C:COMPANY) WHERE C.COMPANY_NM = '某公司'
    CREATE(P)-[:WORK{POSITION:'董事长'}]->(C)

    WITH
    MATCH(P:PERSON) WHERE P.PERSON_NM = '某人'
    MATCH(C:COMPANY) WHERE C.COMPANY_NM = '某公司'
    WITH P.PERSON_NM AS NAME
    RETURN NAME,C

    DELETE(当节点上还有关系依赖时，无法删除节点，detach delete)
    MATCH(P:PERSON) WHERE P.PERSON_NM = '某人'
    DELETE P
    
    SET/REMOVE(操作属性)
    
    MERGE(MATCH不到就CREATE)
    MERGE(C:COMPANY{COMPANY_NM:'另一家企业'}) 
    MERGE(P:PERSON{PERSON_NM:'某人'}) 
    MERGE(P)-[R:WORK{POSITION:'董事'}]->(C)
    RETURN R

    MATCH P = AllShortestPaths((A:COMPANY{COMPANY_NM:'某公司'})-[:INVEST|WORK*..7]-(B:COMPANY{COMPANY_NM:'另一家企业'})) RETURN P
    图数据库中的ID唯一

    索引简历
    CREATE CONSTRAINT ON (P:PERSON) ASSERT P.PERSON_ID IS UNIQUE;
    CREATE INDEX ON :COMPANY(COMPANY_NM)
    :schema

    加载csv
    LOAD CSV WITH HEADERS FROM "http://data.neo4j.com/northwind/products.csv" AS row
    CREATE (n:Product)
    SET n = row,
    n.unitPrice = toFloat(row.unitPrice),
    n.unitsInStock = toInteger(row.unitsInStock), n.unitsOnOrder = toInteger(row.unitsOnOrder),
    n.reorderLevel = toInteger(row.reorderLevel), n.discontinued = (row.discontinued <> "0")

    调用jdbc直连数据库
    WITH 'jdbc:oracle:thin:cs_portal/RGDU2Csp@10.100.47.14:1521:orclp' AS url
    CALL apoc.load.jdbc(url,"
        SELECT COMPANY_ID,SUM(WARNING_ANNOUNCE_ALARM_NUM) AS WARNING_NUM FROM(SELECT COMPANY_ID,COUNT(*) AS WARNING_ANNOUNCE_ALARM_NUM FROM CS_PORTAL.VW_COMPY_WARNINGS WHERE TYPE_ID NOT IN(10,12,107) GROUP BY COMPANY_ID UNION SELECT A.COMPANY_ID,COUNT(*) AS WARNING_ANNOUNCE_ALARM_NUM FROM CS_PORTAL.COMPY_ANNOUNCE_ALARM A INNER JOIN CS_PORTAL.LKP_ALARM_KEYWORD C ON A.ALARM_KEYWORD_CD = C.ALARM_KEYWORD_CD AND C.SECOND_TYPE IN ('违法违规','法律诉讼','破产重整','审计风险','评级调整风险','偿付风险','失信','担保方代偿能力风险') WHERE NOTICE_DT >= ADD_MONTHS(SYSDATE, -12) GROUP BY COMPANY_ID ) GROUP BY COMPANY_ID
    ")yield row WITH row AS  LINE
    MATCH (C:COMPANY{COMPANY_ID:toString(LINE.COMPANY_ID)})
    SET C.WARNING_NUM = toInt(LINE.WARNING_NUM)

    apoc，插件，用户自定义程序，有些功能不能通过cypher比较方便的去实现。可以通过java实现部署到neo4j中，然后通过cypher调用。
    https://neo4j-contrib.github.io/neo4j-apoc-procedures/

    
## neo4j在预鉴中的应用


    主要涉及功能：
    1. 企业关联图谱（私募图谱、人行图谱、金控图谱）(标签的作用)
    2. 找关系（演示一波）图：预鉴找关系 方哥震哥，刘德华案例，  以及找关系的同时，需要调出该节点是否具有风险
    3. 风险筛查的小接口

    
    统计时间: 
    2018年05月08日
    生产图数据库10.100.47.21
    图数据库中数据类型：
    一、节点类型（共177484823）：
    1.	PFCOMPANY   私募机构			共23869个节点
    2.	SECURITY      产品				共1279396个节点
    3.	PERSON       自然人				共120346443个节点
    4.	PFUND        私募基金产品		共90803个节点
    5.	COMPANY     企业				共55884336个节点
    其中PFCOMPANY为COMPANY类型的子集，PFUND为SECURITY的子集。

    二、关系类型（共248169226）：
    1.	CONTROLLER           	控制人关系					共44076条关系
    2.	INVEST          			股权投资（股东、对外投资）	共80098742条关系
    3.	WORK					任职关系					共166537426条关系
    4.	GUARANTEE         		担保关系					共5058条关系
    5.	ISSUE                   	产品发行					共1279386条关系
    6.	RELATIVE					亲属关系					共19089条关系
    7.	SUPPLIER               	主要供应商					共9551条关系
    8.	CUSTOMER          		主要客户					共15576条关系
    9.	TRUSTEE                	私募产品托管人				共68454条关系
    10.	MANAGER 				私募产品管理人				共91868条关系

    三、节点与边的关系枚举
    1.	(:COMPANY)-[:ISSUE]->(:SECURITY|COMPANY)
    企业发行产品
    数据来源：CS_PORTAL.SECURITY

    2.	(:COMPANY)-[: TRUSTEE]->(: SECURITY|PFUND)  注：PFUND为SECURITY子集
    企业托管私募基金产品
    数据来源：CS_PORTAL.PFUND_PUBLICINFO

    3.	(:COMPANY)-[: MANAGER]->(: SECURITY|PFUND)  注：PFUND为SECURITY子集
    企业管理私募基金产品，理论上此处企业应为私募机构（PFCOMPAMY）
    数据来源：CS_PORTAL.PFUND_PUBLICINFO

    4.	(:COMPANY)-[:CUSTOMER]->(:COMPANY)
    企业主要客户
    数据来源：CS_PORTAL.COMPY_TOP5CUST

    5.	(:COMPANY)-[: SUPPLIER]->(:COMPANY)
    企业主要供应商
    数据来源：CS_PORTAL.COMPY_TOP5SUPP

    6.	(:COMPANY)-[: GUARANTEE| GUARANTEE_TOTAL]->(:COMPANY)
    企业担保|担保汇总（担保总额求和）关系              注：存在自担保的情况
    数据来源：CS_PORTAL.COMPY_GUARANTEE

    7.	(:COMPANY|PERSON|SECURITY)-[: INVEST]->(:COMPANY)
    企业股权关系，企业的股东类型包括企业（COMPANY）、自然人（PERSOM）、产品（SECURITY）
    数据来源：天眼查股东关系表、CS_PORTAL.COMPY_SHAREHOLDER、ORACLE_GRAPHDB_TRANS.SCOMPY_BASICINFO（子公司表）

    8.	(:COMPANY|PERSON|SECURITY)-[: CONTROLLER]->(:COMPANY)
    企业控制人关系
    数据来源：CS_PORTAL.COMPY_AFFILPARTY，通过INVEST比例超过50%计算得到

    9.	(:PERSON)-[: WORK]->(:COMPANY)
    企业高管，任职关系
    数据来源：天眼查高管表，CS_PORTAL. COMPY_BASICINFO（抽取法定代表人信息），CS_PORTAL.COMPY_MANAGELEVEL

    10.	(:PERSON)-[:RELATIVE]->(: PERSON)
    自然人亲属关系
    数据来源：COMPY_MGRRELHOLDINGS

```

```
    数据流图 ppt
    
    集群架构图 ppt

    配置文件
    dbms.security.procedures.unrestricted=apoc.*
    apoc.export.file.enabled=true
    dbms.directories.plugins=plugins
    dbms.backup.enabled=true
    #dbms.memory.heap.initial_size=512m
    #dbms.memory.heap.max_size=512m
    #dbms.memory.pagecache.size=10g
    dbms.connector.bolt.listen_address=0.0.0.0:7687
    dbms.connector.http.listen_address=0.0.0.0:7474
    dbms.connector.https.listen_address=:7473
    dbms.threads.worker_count=40

    HA configuration
    dbms.mode=HA
    ha.server_id=1
    ha.initial_hosts=10.100.47.21:5001,10.100.47.19:5001,10.100.47.20:5001
    ha.host.coordination=10.100.47.21:5001
    ha.pull_interval=600//集群同步时间
    
    
    
    更新流程：
    1. 数据初始化neo4j-import
        /opt/neo4j-enterprise-3.3.0/bin/neo4j-admin import 
        --mode csv --database the_database 
        --nodes:COMPANY "company-info-header.csv,company-info.csv" 
        --nodes:PERSON "sharehdperson-info-header.csv,person-info.csv" 
        --nodes:SECURITY "security-info-header.csv,security-info.csv" 
        --relationships:ISSUE "issue-info-header.csv,issue-relation.csv"  
        --relationships:INVEST "sharehdperson-relation-header.csv,sharehdperson-relation.csv" 
        --relationships:INVEST "sharehdcomp-relation-header.csv,sharehdcomp-relation.csv" 
        --relationships:WORK "employ-info-header.csv,employ-info.csv,frrelation-info.csv" 
        --ignore-missing-nodes 
        --ignore-duplicate-nodes
        索引添加后记得等到:schema（index online）

    2. 后续增量更新（数据更新的几种方式，jdbc/load csv/neo4j-shell...json/rdf...）Conditional conversions can be achieved with CASE
    
    数据导入
    https://neo4j.com/developer/guide-import-csv/
    数据导出
    https://neo4j.com/developer/kb/export-sub-graph-to-cypher-and-import/


    
# 一些参考资料
## neo4j下载
    https://neo4j.com/download/?ref=hro
    http://we-yun.com/download/neo4j-releases/
## neo4j开发手册与操作手册
    https://neo4j.com/docs/
## Cypher语法介绍
    https://neo4j.com/docs/cypher-refcard/current/
    https://www.w3cschool.cn/neo4j/neo4j_cql_introduction.html
## APOC文档
    https://neo4j-contrib.github.io/neo4j-apoc-procedures/
## 一些资料
    https://blog.csdn.net/graphway
    https://neo4j.com/developer/kb/export-sub-graph-to-cypher-and-import/（数据部分导出）
## 数据导入
    https://neo4j.com/developer/guide-import-csv/
## 数据导出
    https://neo4j.com/developer/kb/export-sub-graph-to-cypher-and-import/
