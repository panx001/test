package com.cscs.graph_api.Entity;

import com.cscs.graph_api.Util.Base64;
import com.cscs.graph_api.Util.String2MD5;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by wuchenglong on 16/12/14.
 */


@SuppressWarnings("unused")
public class RelationNode {

    private Object nexus;
    private String name;
    private String id;
    private String linkedId;
    private String createdId;
    private String nodeType;
    private String securityCode;
    // @JsonIgnore
    private Map<String, String> typeMap = new HashMap<String, String>() {{
        put("Company", "c-");
        put("PERSON", "p-");
        put("SECURITY", "c-");
    }};

    private final static List<String> NODE_STATUS = Arrays.asList("吊销", "注销", "吊销未注销");

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLinkedId() {
        return linkedId;
    }

    public void setLinkedId(String linkdId) {
        this.linkedId = linkedId;
    }

    public String getCreatedId() {
        return createdId;
    }

    public void setCreatedId(String createdId) {
        this.createdId = createdId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        this.createdId = Base64.encode(name);
    }

    public String getNodeType() {
        return nodeType;
    }

    public void setNodeType(String nodeType) {
        this.nodeType = nodeType;
    }

    public Object getNexus() {
        return nexus;
    }

    public void setNexus(Object nexus) {
        this.nexus = nexus;
    }

    public String getSecurityCode() {
        return securityCode;
    }

    public void setSecurityCode(String securityCode) {
        this.securityCode = securityCode;
    }

    public RelationNode(Object nexus, String name, String createdId, String nodeType) {
        //先将name加密，然后再md5
        this.id = typeMap.getOrDefault(nodeType, "u-") + String2MD5.md5(Base64.encode(name));
        this.nexus = nexus;
        this.name = name;
        this.nodeType = nodeType;
        this.createdId = Base64.encode(name);
    }


    @Override
    public String toString() {
        return "id: " + this.id + "  nexus: " + this.nexus + "  name:  " + this.name + "  createdId:  " + this.createdId;
    }
}
