package com.cscs.graph_api.domain;

import com.cscs.graph_api.Util.UseFulFunc;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.collections.list.SetUniqueList;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by wuchenglong on 2018/1/9.
 */

@SuppressWarnings("unused")
public class ResultReturnCollection {

    private static Logger logger = LogManager.getLogger(ResultReturnCollection.class);

    @JsonProperty("BasicInfo")
    private NodeShowBasicInfo nodeShowBasicInfo;
    @JsonProperty("EntityList")
    private List<NodeShow> nodeShowsUniqueList = SetUniqueList.decorate(new ArrayList<NodeShow>());
    @JsonProperty("RelationList")
    private List<RelationShipShow> relationShipShowUniqueList = SetUniqueList.decorate(new ArrayList<RelationShipShow>());

    @JsonIgnore
    private HashMap<String, NodeShow> nodeShowHashMap = new HashMap<>();
    @JsonIgnore
    private HashMap<String, RelationShipShow> relationShipShowHashMap = new HashMap<>();

    @JsonIgnore
    private HashMap<String, String> keep_path = new HashMap<>();

    public ResultReturnCollection() {

    }

    public void setKeep_path(HashMap<String, String> keep_path) {
        this.keep_path = keep_path;
    }

    public HashMap<String, String> getKeep_path() {
        return keep_path;
    }


    public void setNodeShowHashMap(HashMap<String, NodeShow> nodeShowHashMap) {
        this.nodeShowHashMap = nodeShowHashMap;
    }

    public HashMap<String, NodeShow> getNodeShowHashMap() {
        return nodeShowHashMap;
    }

    public HashMap<String, RelationShipShow> getRelationShipShowHashMap() {
        return relationShipShowHashMap;
    }

    public void setRelationShipShowHashMap(HashMap<String, RelationShipShow> relationShipShowHashMap) {
        this.relationShipShowHashMap = relationShipShowHashMap;
    }

    public void setNodeShowBasicInfo(NodeShowBasicInfo nodeShowBasicInfo) {
        this.nodeShowBasicInfo = nodeShowBasicInfo;
    }

    public NodeShowBasicInfo getNodeShowBasicInfo() {
        return nodeShowBasicInfo;
    }

    public void setNodeShowsUniqueList(List<NodeShow> nodeShowsUniqueList) {
        this.nodeShowsUniqueList = nodeShowsUniqueList;
    }

    public List<NodeShow> getNodeShowsUniqueList() {
        return nodeShowsUniqueList;
    }

    public void setRelationShipShowUniqueList(List<RelationShipShow> relationShipShowUniqueList) {
        this.relationShipShowUniqueList = relationShipShowUniqueList;
    }

    public List<RelationShipShow> getRelationShipShowUniqueList() {
        return relationShipShowUniqueList;
    }

    public void add(NodeShow nodeShow) {
        if (!this.nodeShowHashMap.containsKey(nodeShow.getId())) {
            this.nodeShowHashMap.put(nodeShow.getId(), nodeShow);
        }
    }

    public void add(RelationShipShow relationShipShow) {
        if (!this.keep_path.containsKey(relationShipShow.getPath_id()) && relationShipShow.getPath_type().size() > 0) {
            this.keep_path.put(relationShipShow.getPath_id(), relationShipShow.getPath_type().get(0));
        }
        if (!this.relationShipShowHashMap.containsKey(relationShipShow.getId())) {
            this.relationShipShowHashMap.put(relationShipShow.getId(), relationShipShow);
        } else {
            if (relationShipShow.getPath_type().size() > 0 && this.keep_path.containsValue(relationShipShow.getPath_type().get(0))) {
                this.relationShipShowHashMap.get(relationShipShow.getId()).updatePathType(relationShipShow.getPath_type());
            }
            if (relationShipShow.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("WORK", "0"))) {
                this.relationShipShowHashMap.get(relationShipShow.getId()).updateNexus(relationShipShow.getNexus());
            }
        }
    }

    public void add(ResultReturn resultReturn) {
        this.add(resultReturn.getStartNodeShow());
        this.add(resultReturn.getEndNodeShow());
        this.add(resultReturn.getRelationShipShow());
    }

    public void updateElemtList() {
        for (Object o1 : nodeShowHashMap.entrySet()) {
            Map.Entry entry = (Map.Entry) o1;
            nodeShowsUniqueList.add((NodeShow) (entry.getValue()));
        }

        for (Object o : relationShipShowHashMap.entrySet()) {
            Map.Entry entry = (Map.Entry) o;
            relationShipShowUniqueList.add((RelationShipShow) entry.getValue());
        }
    }

}
