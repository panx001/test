package com.cscs.graph_api;

import org.neo4j.driver.v1.AuthTokens;
import org.neo4j.driver.v1.Config;
import org.neo4j.driver.v1.Driver;
import org.neo4j.driver.v1.GraphDatabase;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EntityScan("com.cscs.graph_api.domain")
public class GraphApiApplication {

    @Value("${blotUri}")
    private String uri;

    @Value("${spring.data.neo4j.username}")
    private String username;

    @Value("${spring.data.neo4j.password}")
    private String password;

    public static void main(String[] args) {
        SpringApplication.run(GraphApiApplication.class, args);
    }

    /**
     * 图数据库驱动模式
     *
     * @return
     */
    @Bean
    public Driver neo4jDriver() {
        Config noSSL = Config.build().withEncryptionLevel(Config.EncryptionLevel.NONE).toConfig();
        return GraphDatabase.driver(uri, AuthTokens.basic(username,password), noSSL);
    }
}
