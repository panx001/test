package com.cscs.graph_api.mapper;

import com.cscs.graph_api.domain.DaasMainPersonNode;
import com.cscs.graph_api.domain.NodeShow;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

/**
 * Created by wuchenglong on 2018/1/10.
 */

@Mapper
public interface DaasMainPersonNodeMapper {
    DaasMainPersonNodeMapper MAPPER = Mappers.getMapper(DaasMainPersonNodeMapper.class);

    @Mappings({
            @Mapping(target = "suggestedLabel", constant = "PERSON"),
            @Mapping(source = "PERNAME", target = "name"),
            @Mapping(source = "LINK_ID", target = "link_id"),
    })
    NodeShow QueryResultToNodeShow(DaasMainPersonNode daasFrpositionNode);

    @InheritInverseConfiguration
    DaasMainPersonNode NodeShowToQueryResult(NodeShow nodeShow);

}
