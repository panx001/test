package com.cscs.graph_api.controller;

/**
 * Created by wuchenglong on 2018/1/3.
 */


import com.cscs.graph_api.repositories.ObjectRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.neo4j.ogm.response.model.QueryResultModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping(value = "/chart/shareholder")
public class GetShareholder {

    private static Logger logger = LogManager.getLogger(GetShareholder.class);

    @Autowired
    ObjectRepository objectRepository;


    @RequestMapping(value = "/company_id", method = RequestMethod.GET)
    private List<Map<String, Object>> getShareholder(@RequestParam String company_id) throws Exception {
        List<Map<String, Object>> shareHolderResult = new ArrayList<>();
        try {
            QueryResultModel companyNode = objectRepository.getCompanyShareholder(company_id);
            for (Map<String, Object> obj : companyNode) {
                Map<String, Object> nodeinfo = (Map<String, Object>) obj.get("resultinfo");
                shareHolderResult.add(nodeinfo);
            }
        } catch (Exception e) {
            return null;
        }
        return shareHolderResult;
    }
}
