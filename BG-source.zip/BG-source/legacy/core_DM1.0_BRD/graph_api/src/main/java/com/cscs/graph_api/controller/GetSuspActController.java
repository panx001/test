package com.cscs.graph_api.controller;

/**
 * Created by wuchenglong on 2018/1/3.
 */


import com.cscs.graph_api.Util.ConnectionToPortal;
import com.cscs.graph_api.Util.UseFulFunc;
import com.cscs.graph_api.domain.NodeShowBasicInfo;
import com.cscs.graph_api.domain.ResultReturn;
import com.cscs.graph_api.domain.ResultReturnCollection;
import com.cscs.graph_api.mapper.QueryResultMapper;
import com.cscs.graph_api.repositories.ObjectRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.neo4j.driver.internal.util.Iterables;
import org.neo4j.ogm.response.model.QueryResultModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
// import org.springframework.data.neo4j.repository.support.Neo4jTemplate;

@CrossOrigin
@RestController
@RequestMapping(value = "/chart/suspectactualcontroller")
public class GetSuspActController {

    private static Logger logger = LogManager.getLogger(GetSuspActController.class);

    @Autowired
    ObjectRepository objectRepository;

    //@RequestMapping(value = "/basicInfo/neo4j", method = RequestMethod.GET)
    private NodeShowBasicInfo getBasicInfoNodeFromNeo4jByCompanyId(@RequestParam String companyId) throws Exception {
        NodeShowBasicInfo nodeShowBasicInfo = new NodeShowBasicInfo();
        QueryResultModel companyNode = objectRepository.getCompanyBasicInfoByCompanyId(companyId);

        Connection conn = null;
        try {
            ConnectionToPortal connectionToPortal = new ConnectionToPortal();
            conn = connectionToPortal.connectionToPortal();
            conn.setAutoCommit(false);
            String queryString = connectionToPortal.getBasicInfoQueryByCompanyId(companyId);
            //logger.debug(queryString);
            PreparedStatement stmt = conn.prepareStatement(queryString, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                nodeShowBasicInfo = basicInfoUpdataFromORACLE(rs, companyNode, nodeShowBasicInfo);
            } else {
                nodeShowBasicInfo = basicInfoUpdataFromNeo4j(companyNode, nodeShowBasicInfo);
            }
            conn.close();
        } catch (Exception e) {
            nodeShowBasicInfo = basicInfoUpdataFromNeo4j(companyNode, nodeShowBasicInfo);
            e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }

            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return nodeShowBasicInfo;
    }

    private NodeShowBasicInfo basicInfoUpdataFromNeo4j(QueryResultModel companyNode, NodeShowBasicInfo nodeShowBasicInfo) throws SQLException {
        for (Map<String, Object> basicResult : companyNode) {
            Map<String, Object> result = (Map<String, Object>) basicResult.get("BasicInfo");
            nodeShowBasicInfo = QueryResultMapper.MapBasicInfoNodeShowMapper(result);
            nodeShowBasicInfo.infoUpdate();
        }
        return nodeShowBasicInfo;
    }

    private NodeShowBasicInfo basicInfoUpdataFromORACLE(ResultSet rs, QueryResultModel companyNode, NodeShowBasicInfo nodeShowBasicInfo) throws SQLException {
        for (Map<String, Object> basicResult : companyNode) {
            Map<String, Object> result = (Map<String, Object>) basicResult.get("BasicInfo");
            result.put("FOUND_DT", rs.getString("FOUND_DT"));
            result.put("LEG_REPRESENT", rs.getString("LEG_REPRESENT"));
            result.put("RATING_CURRENT", rs.getString("RATING"));
            result.put("REG_ADDR", rs.getString("REG_ADDR"));
            result.put("REG_CAPITAL", rs.getString("REG_CAPITAL"));
            nodeShowBasicInfo = QueryResultMapper.MapBasicInfoNodeShowMapper(result);
            nodeShowBasicInfo.infoUpdate();
        }
        return nodeShowBasicInfo;
    }

    private ResultReturnCollection getSuspActControllerFromNeo4jByCompanyId(@RequestParam String companyId) throws Exception {
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        QueryResultModel companyNode;
        QueryResultModel typeflag = objectRepository.JudgeCompanyTpye(companyId);
        if (Iterables.asList(typeflag.queryResults()).isEmpty()) {
            companyNode = objectRepository.getSuspActControllerByCompanyId(companyId);
        } else {
            companyNode = objectRepository.getActControllerByCompanyId(companyId);
        }
        int count = 0;
        for (Map<String, Object> result : companyNode) {
            ResultReturn resultReturn = new ResultReturn(
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("sourceNodeInfo")),
                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) result.get("relationInfo")),
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("targetNodeInfo")));
            resultReturnCollection.add(resultReturn);
            count = count + 1;
        }
        logger.debug(count);
        logger.debug(resultReturnCollection.getNodeShowHashMap().size());
        logger.debug(resultReturnCollection.getRelationShipShowHashMap().size());
        resultReturnCollection.setNodeShowBasicInfo(getBasicInfoNodeFromNeo4jByCompanyId(companyId));
        resultReturnCollection.updateElemtList();
        logger.debug(resultReturnCollection.getNodeShowsUniqueList().size());
        logger.debug(resultReturnCollection.getRelationShipShowUniqueList().size());
        return resultReturnCollection;
    }

    //返回疑似/实际控制人名称，上市返回实际控制人，非上市返回疑似实际控制人
    @RequestMapping(value = "/actcontrollername/company_id", method = RequestMethod.GET)
    private List<Map<String, Object>> GetSuspectActualControllerName(@RequestParam String link_id) throws Exception {
        List<Map<String, Object>> shareHolderResult = new ArrayList<>();
        try {
            QueryResultModel typeflag = objectRepository.JudgeCompanyTpye(link_id);
            if (Iterables.asList(typeflag.queryResults()).isEmpty()) {
                QueryResultModel companyNode = objectRepository.getSuspActControllerNameByCompanyId(link_id);
                for (Map<String, Object> obj : companyNode) {
                    Map<String, Object> nodeinfo = (Map<String, Object>) obj.get("resultinfo");
                    shareHolderResult.add(nodeinfo);
                }
            } else {
                QueryResultModel companyNode = objectRepository.getActControllerNameByCompanyId(link_id);
                for (Map<String, Object> obj : companyNode) {
                    Map<String, Object> nodeinfo = (Map<String, Object>) obj.get("resultinfo");
                    shareHolderResult.add(nodeinfo);
                }
            }

        } catch (Exception e) {
            logger.debug(e);
            return shareHolderResult;
        }
        return shareHolderResult;
    }

    //返回疑似/实际控制人图谱，上市返回实际控制人，非上市返回疑似实际控制人
    @RequestMapping(value = "/actcontroller/company_id", method = RequestMethod.GET)
    private ResultReturnCollection GetSuspectActualController(@RequestParam String link_id) throws Exception {
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        return getGraphFunction(link_id, resultReturnCollection);
    }

    private ResultReturnCollection getGraphFunction(String link_id, ResultReturnCollection resultReturnCollection) throws Exception {
        if (UseFulFunc.isNumeric(link_id)) {
            resultReturnCollection = getSuspActControllerFromNeo4jByCompanyId(link_id);
        }
        if (resultReturnCollection.getRelationShipShowUniqueList() != null && resultReturnCollection.getNodeShowsUniqueList() != null && resultReturnCollection.getRelationShipShowUniqueList().isEmpty() && resultReturnCollection.getNodeShowsUniqueList().isEmpty()) {
            resultReturnCollection.setNodeShowBasicInfo(null);
        }
        return resultReturnCollection;
    }
}
