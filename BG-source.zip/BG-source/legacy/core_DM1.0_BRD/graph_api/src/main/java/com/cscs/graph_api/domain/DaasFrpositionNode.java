package com.cscs.graph_api.domain;

/**
 * Created by wuchenglong on 2018/1/10.
 */

@SuppressWarnings("unused")
public class DaasFrpositionNode {

    private String ENTSTATUS;
    // private String LEREPSIGN;
    // private String NAME;
    private String POSITION;
    private String ENTNAME;


    public DaasFrpositionNode() {
    }

    public void setENTNAME(String ENTNAME) {
        this.ENTNAME = ENTNAME;
    }

    public String getENTNAME() {
        return ENTNAME;
    }

    public void setENTSTATUS(String ENTSTATUS) {
        this.ENTSTATUS = ENTSTATUS;
    }

    public String getENTSTATUS() {
        return ENTSTATUS;
    }

    public void setPOSITION(String POSITION) {
        this.POSITION = POSITION;
    }

    public String getPOSITION() {
        return POSITION;
    }
}
