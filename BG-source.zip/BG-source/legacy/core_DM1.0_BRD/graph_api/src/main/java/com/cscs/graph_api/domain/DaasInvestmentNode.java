package com.cscs.graph_api.domain;

/**
 * Created by wuchenglong on 2018/1/10.
 */

@SuppressWarnings("unused")
public class DaasInvestmentNode {
    private String ENTSTATUS;  // 企业状态
    private String FUNDEDRATIO; // 投资比例
    private String ENTNAME;   // 投资名称

    public DaasInvestmentNode() {
    }

    public void setENTNAME(String ENTNAME) {
        this.ENTNAME = ENTNAME;
    }

    public String getENTNAME() {
        return ENTNAME;
    }

    public void setENTSTATUS(String ENTSTATUS) {
        this.ENTSTATUS = ENTSTATUS;
    }

    public String getENTSTATUS() {
        return ENTSTATUS;
    }

    public void setFUNDEDRATIO(String FUNDEDRATIO) {
        this.FUNDEDRATIO = FUNDEDRATIO;
    }

    public String getFUNDEDRATIO() {
        return FUNDEDRATIO;
    }
}

