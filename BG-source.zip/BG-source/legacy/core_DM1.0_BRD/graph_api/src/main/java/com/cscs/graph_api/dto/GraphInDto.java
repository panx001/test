package com.cscs.graph_api.dto;

public class GraphInDto {
    public String companyNm;
    public Long  companyId;
    public int level;
    //INVEST    |WORK     |CONTROLLER  |GUARANTEE |ISSUE    |RELATIVE |SUPPLIER   |CUSTOMER |TRUSTEE        |MANAGER       |BRANCH
    //股权投资 |任职关系 |控制人关系   |担保关系  |产品发行 |亲属关系 |主要供应商 |主要客户 |私募产品托管人 |私募产品管理人|分支关系
    public String relation;

    public String getCompanyNm() {
        return companyNm;
    }

    public void setCompanyNm(String companyNm) {
        this.companyNm = companyNm;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public String getRelation() {
        return relation;
    }

    public void setRelation(String relation) {
        this.relation = relation;
    }
}
