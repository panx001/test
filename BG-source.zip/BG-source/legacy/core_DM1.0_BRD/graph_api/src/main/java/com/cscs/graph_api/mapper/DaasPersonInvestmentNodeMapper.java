package com.cscs.graph_api.mapper;

import com.cscs.graph_api.domain.DaasPersonInvestmentNode;
import com.cscs.graph_api.domain.NodeShow;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

/**
 * Created by wuchenglong on 2018/1/10.
 */

@Mapper
public interface DaasPersonInvestmentNodeMapper {

    DaasPersonInvestmentNodeMapper MAPPER = Mappers.getMapper(DaasPersonInvestmentNodeMapper.class);

    @Mappings({
            @Mapping(target = "suggestedLabel", constant = "COMPANY"),
            @Mapping(source = "ENTNAME", target = "name"),
//            @Mapping(source = "ENTSTATUS", target = "name"),
    })
    NodeShow QueryResultToNodeShow(DaasPersonInvestmentNode daasFrinvestmentNode);

    @InheritInverseConfiguration
    DaasPersonInvestmentNode NodeShowToQueryResult(NodeShow nodeShow);


}
