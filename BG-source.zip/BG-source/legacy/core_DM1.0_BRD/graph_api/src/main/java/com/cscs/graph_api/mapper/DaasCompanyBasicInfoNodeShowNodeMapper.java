package com.cscs.graph_api.mapper;

import com.cscs.graph_api.domain.DaasCompanyBasicInfoNode;
import com.cscs.graph_api.domain.NodeShow;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

/**
 * Created by wuchenglong on 2018/1/11.
 */

@Mapper
public interface DaasCompanyBasicInfoNodeShowNodeMapper {

    DaasCompanyBasicInfoNodeShowNodeMapper MAPPER = Mappers.getMapper(DaasCompanyBasicInfoNodeShowNodeMapper.class);

    @Mappings({
            @Mapping(target = "suggestedLabel", constant = "COMPANY"),
            @Mapping(source = "ENTNAME", target = "name"),
            @Mapping(source = "REGCAP", target = "reg_capital"),
    })
    NodeShow QueryResultToNodeShow(DaasCompanyBasicInfoNode nodeQueryResult);

    @InheritInverseConfiguration
    DaasCompanyBasicInfoNode NodeShowToQueryResult(NodeShow nodeShow);

}
