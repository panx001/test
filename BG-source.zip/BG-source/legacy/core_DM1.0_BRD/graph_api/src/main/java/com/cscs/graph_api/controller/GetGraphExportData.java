package com.cscs.graph_api.controller;

/**
 * Created by wuchenglong on 2018/1/3.
 */


import com.cscs.graph_api.repositories.ObjectRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.neo4j.ogm.response.model.QueryResultModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping(value = "/chart/exportdata")
public class GetGraphExportData {

    private static Logger logger = LogManager.getLogger(GetGraphExportData.class);

    @Autowired
    ObjectRepository objectRepository;


    @RequestMapping(value = "/company_id", method = RequestMethod.GET)
    private Map<String, Object> getGraphExportData(@RequestParam String company_id) throws Exception {
        Map<String, Object> shareHolderResult = new HashMap<>();
        try {
            QueryResultModel companyInfo = objectRepository.getCompanyInfo(company_id);
            QueryResultModel companyShaInfo = objectRepository.getCompanyShaInfo(company_id);
            QueryResultModel shaShaInfo = objectRepository.getCompanyShaShaInfo(company_id);
            QueryResultModel shaInvestInfo = objectRepository.getCompanyShaInvestInfo(company_id);
            QueryResultModel investInfo = objectRepository.getCompanyInvestInfo(company_id);
            QueryResultModel workInfo = objectRepository.getCompanyWorkInfo(company_id);
            QueryResultModel supplierInfo = objectRepository.getCompanySupplierInfo(company_id);
            QueryResultModel supplierShaInfo = objectRepository.getCompanySupplierShaInfo(company_id);
            QueryResultModel supplierInvestInfo = objectRepository.getCompanySupplierInvestInfo(company_id);
            QueryResultModel supplierWorkInfo = objectRepository.getCompanySupplierWorkInfo(company_id);
            QueryResultModel customerInfo = objectRepository.getCompanyCustomerInfo(company_id);
            QueryResultModel customerShaInfo = objectRepository.getCompanyCustomerShaInfo(company_id);
            QueryResultModel customerInvestInfo = objectRepository.getCompanyCustomerInvestInfo(company_id);
            QueryResultModel customerWorkInfo = objectRepository.getCompanyCustomerWorkInfo(company_id);
            setReturnResult(shareHolderResult, "companyInfo", companyInfo);
            setReturnResult(shareHolderResult, "companyShaInfo", companyShaInfo);
            setReturnResult(shareHolderResult, "shaShaInfo", shaShaInfo);
            setReturnResult(shareHolderResult, "shaInvestInfo", shaInvestInfo);
            setReturnResult(shareHolderResult, "investInfo", investInfo);
            setReturnResult(shareHolderResult, "workInfo", workInfo);
            setReturnResult(shareHolderResult, "supplierInfo", supplierInfo);
            setReturnResult(shareHolderResult, "supplierShaInfo", supplierShaInfo);
            setReturnResult(shareHolderResult, "supplierInvestInfo", supplierInvestInfo);
            setReturnResult(shareHolderResult, "supplierWorkInfo", supplierWorkInfo);
            setReturnResult(shareHolderResult, "customerInfo", customerInfo);
            setReturnResult(shareHolderResult, "customerShaInfo", customerShaInfo);
            setReturnResult(shareHolderResult, "customerInvestInfo", customerInvestInfo);
            setReturnResult(shareHolderResult, "customerWorkInfo", customerWorkInfo);

        } catch (Exception e) {
            return null;
        }
        return shareHolderResult;
    }

    private void setReturnResult(Map<String, Object> shareHolderResult, String key, QueryResultModel queryresult) {
        List<Map<String, Object>> resutValue = new ArrayList<>();
        for (Map<String, Object> obj : queryresult) {
            resutValue.add((Map<String, Object>) obj.get("RESULT"));
        }
        shareHolderResult.put(key, resutValue);
    }
}
