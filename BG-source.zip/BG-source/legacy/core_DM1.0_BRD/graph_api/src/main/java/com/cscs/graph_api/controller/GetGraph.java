package com.cscs.graph_api.controller;

/**
 * Created by wuchenglong on 2018/1/3.
 */


import com.cscs.graph_api.Util.ConnectionToPortal;
import com.cscs.graph_api.Util.UseFulFunc;
import com.cscs.graph_api.domain.NodeShowBasicInfo;
import com.cscs.graph_api.domain.ResultReturn;
import com.cscs.graph_api.domain.ResultReturnCollection;
import com.cscs.graph_api.dto.GraphInDto;
import com.cscs.graph_api.mapper.QueryResultMapper;
import com.cscs.graph_api.repositories.ObjectRepository;
import net.sf.json.JSONObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import org.neo4j.driver.v1.*;
import org.neo4j.driver.v1.types.Node;
import org.neo4j.driver.v1.types.Relationship;
import org.neo4j.ogm.response.model.QueryResultModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map;
// import org.springframework.data.neo4j.repository.support.Neo4jTemplate;

@CrossOrigin
@RestController
@RequestMapping(value = "/chart/pfcompany")
public class GetGraph {

    private static Logger logger = LogManager.getLogger(GetGraph.class);

    @Autowired
    ObjectRepository objectRepository;

    @Resource
    Driver driver;

    @RequestMapping(value="/test",method =RequestMethod.POST )
    private void getinfo(@RequestBody GraphInDto inDto){
        try (Session session = driver.session()) {
            StringBuilder cypher = new StringBuilder();
            boolean chkCondetion = false;
//            if(inDto.getCompanyId() == 0L && Strings.isBlank(inDto.getCompanyNm())) return null;
            cypher.append("MATCH P = (A:COMPANY{");
            if (inDto.getCompanyId() != 0L) cypher.append("COMPANY_ID:'"+ inDto.getCompanyId()+"'");
            if (chkCondetion) cypher.append(",");
            if (!Strings.isBlank(inDto.getCompanyNm())) cypher.append("COMPANY_NM:'"+ inDto.getCompanyNm()+"'");
            cypher.append("}) - [:" + inDto.relation + "*.."+ inDto.level + "] -(B) return P");

            StatementResult result = session.run(cypher.toString());
            while (result.hasNext()) {
                Record record = result.next();
//                Object iat = record.values().get(0).asPath().nodes();
                Iterator iat =  record.values().get(0).asPath().nodes().iterator();
                while(iat.hasNext()) {
                    Node a  = (Node) iat.next();
                    System.out.println(a.get("COMPANY_ID"));
                }
                Iterator iat2 =  record.values().get(0).asPath().relationships().iterator();
                if(iat2.hasNext()){
                    Relationship ship = (Relationship)iat2.next();
                    System.out.println(ship.type());
                }
            }
            System.out.println(result);
        }
    }



    //@RequestMapping(value = "/basicInfo/neo4j", method = RequestMethod.GET)
    private NodeShowBasicInfo getBasicInfoNodeFromNeo4jByCompanyNm(@RequestParam String companyNm) throws Exception {
        NodeShowBasicInfo nodeShowBasicInfo = new NodeShowBasicInfo();
        QueryResultModel companyNode = objectRepository.getCompanyBasicInfoByCompanyNm(companyNm);
        Connection conn = null;
        try {
            ConnectionToPortal connectionToPortal = new ConnectionToPortal();
            conn = connectionToPortal.connectionToPortal();
            conn.setAutoCommit(false);
            String queryString = connectionToPortal.getBasicInfoQueryByCompanyNm(companyNm);
            //logger.debug(queryString);
            PreparedStatement stmt = conn.prepareStatement(queryString, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                nodeShowBasicInfo = basicInfoUpdataFromORACLE(rs, companyNode, nodeShowBasicInfo);
            } else {
                nodeShowBasicInfo = basicInfoUpdataFromNeo4j(companyNode, nodeShowBasicInfo);
            }
            conn.close();
        } catch (Exception e) {
            nodeShowBasicInfo = basicInfoUpdataFromNeo4j(companyNode, nodeShowBasicInfo);
            e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
//                ex.printStackTrace();
            }
        }
        return nodeShowBasicInfo;
    }

    private NodeShowBasicInfo getSecurityBasicInfoFromNeo4jBySecurityId(@RequestParam String securityId) throws Exception {
        NodeShowBasicInfo nodeShowBasicInfo = new NodeShowBasicInfo();
        QueryResultModel companyNode = objectRepository.getSecurityBasicInfoBySecurityId(securityId);
        for (Map<String, Object> basicResult : companyNode) {
            Map<String, Object> result = (Map<String, Object>) basicResult.get("BasicInfo");
            nodeShowBasicInfo = QueryResultMapper.MapSecurityBasicInfoShowMapper(result);
            nodeShowBasicInfo.infoUpdate();
        }
        return nodeShowBasicInfo;
    }


    private NodeShowBasicInfo getBasicInfoNodeFromNeo4jByCompanyId(@RequestParam String companyId) throws Exception {
        NodeShowBasicInfo nodeShowBasicInfo = new NodeShowBasicInfo();
        QueryResultModel companyNode = objectRepository.getCompanyBasicInfoByCompanyId(companyId);

        Connection conn = null;
        try {
            ConnectionToPortal connectionToPortal = new ConnectionToPortal();
            conn = connectionToPortal.connectionToPortal();
            conn.setAutoCommit(false);
            String queryString = connectionToPortal.getBasicInfoQueryByCompanyId(companyId);
            //logger.debug(queryString);
            PreparedStatement stmt = conn.prepareStatement(queryString, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                nodeShowBasicInfo = basicInfoUpdataFromORACLE(rs, companyNode, nodeShowBasicInfo);
            } else {
                nodeShowBasicInfo = basicInfoUpdataFromNeo4j(companyNode, nodeShowBasicInfo);
            }
            conn.close();
        } catch (Exception e) {
            nodeShowBasicInfo = basicInfoUpdataFromNeo4j(companyNode, nodeShowBasicInfo);
            e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }

            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return nodeShowBasicInfo;
    }

    private NodeShowBasicInfo getPersonBasicInfoNodeFromNeo4jByCompanyNmAndPersonNm(@RequestParam String companyNm, @RequestParam String personNm) throws Exception {
        NodeShowBasicInfo nodeShowBasicInfo = new NodeShowBasicInfo();
        QueryResultModel companyNode = objectRepository.getPersonBasicInfoByCompanyNmAndPersonNm(companyNm, personNm);
        for (Map<String, Object> basicResult : companyNode) {
            Map<String, Object> result = (Map<String, Object>) basicResult.get("BasicInfo");
            nodeShowBasicInfo = QueryResultMapper.MapPersonBasicInfoShowMapper(result);
            nodeShowBasicInfo.infoUpdate();
        }
        return nodeShowBasicInfo;
    }


    private NodeShowBasicInfo basicInfoUpdataFromNeo4j(QueryResultModel companyNode, NodeShowBasicInfo nodeShowBasicInfo) throws SQLException {
        for (Map<String, Object> basicResult : companyNode) {
            Map<String, Object> result = (Map<String, Object>) basicResult.get("BasicInfo");
            nodeShowBasicInfo = QueryResultMapper.MapBasicInfoNodeShowMapper(result);
            nodeShowBasicInfo.infoUpdate();
        }
        return nodeShowBasicInfo;
    }

    private NodeShowBasicInfo basicInfoUpdataFromORACLE(ResultSet rs, QueryResultModel companyNode, NodeShowBasicInfo nodeShowBasicInfo) throws SQLException {
        for (Map<String, Object> basicResult : companyNode) {
            Map<String, Object> result = (Map<String, Object>) basicResult.get("BasicInfo");
            result.put("FOUND_DT", rs.getString("FOUND_DT"));
            result.put("LEG_REPRESENT", rs.getString("LEG_REPRESENT"));
            result.put("RATING_CURRENT", rs.getString("RATING"));
            result.put("REG_ADDR", rs.getString("REG_ADDR"));
            result.put("REG_CAPITAL", rs.getString("REG_CAPITAL"));
            nodeShowBasicInfo = QueryResultMapper.MapBasicInfoNodeShowMapper(result);
            nodeShowBasicInfo.infoUpdate();
        }
        return nodeShowBasicInfo;
    }

    //    @RequestMapping(value = "/basicInfo/daas", method = RequestMethod.GET)
    private NodeShowBasicInfo getBasicInfoNodeFromDaas(JSONObject jsonObject) throws Exception {
        NodeShowBasicInfo nodeShowBasicInfo = new NodeShowBasicInfo();
//        JSONObject jsonObject =  GetChinaDaasData.downLoadChinaDaasDataByCompanyNm(companyNm);
        nodeShowBasicInfo = GetChinaDaasData.getBasicInfoOfJson(jsonObject);
        logger.debug(new org.apache.commons.beanutils.BeanMap(nodeShowBasicInfo).entrySet());
        nodeShowBasicInfo.infoUpdate();
        return nodeShowBasicInfo;
    }

    private NodeShowBasicInfo getBasicInfoPersonFromDaas(JSONObject jsonObject) throws Exception {
        NodeShowBasicInfo nodeShowBasicInfo = new NodeShowBasicInfo();
        nodeShowBasicInfo = GetChinaDaasData.getPersonBasicInfoOfJson(jsonObject);
        logger.debug(new org.apache.commons.beanutils.BeanMap(nodeShowBasicInfo).entrySet());
        nodeShowBasicInfo.infoUpdate();
        return nodeShowBasicInfo;
    }


    @RequestMapping(value = "/twolayerBycompanyNm", method = RequestMethod.GET)
    private ResultReturnCollection getTwoLayerRelatedNodeFromNeo4jByCompanyNm(@RequestParam String companyNm, boolean typeFlag) throws Exception {
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        QueryResultModel companyNode;
        companyNode = objectRepository.getTwoLayerGraphByCompanyNm(companyNm);
        int count = 0;
        for (Map<String, Object> result : companyNode) {
            ResultReturn resultReturn = new ResultReturn(
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("sourceNodeInfo")),
                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) result.get("relationInfo")),
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("targetNodeInfo")));
            resultReturnCollection.add(resultReturn);
            count = count + 1;
        }
        logger.debug(count);
        logger.debug(resultReturnCollection.getNodeShowHashMap().size());
        logger.debug(resultReturnCollection.getRelationShipShowHashMap().size());
        resultReturnCollection.setNodeShowBasicInfo(getBasicInfoNodeFromNeo4jByCompanyNm(companyNm));
        resultReturnCollection.updateElemtList();
        logger.debug(resultReturnCollection.getNodeShowsUniqueList().size());
        logger.debug(resultReturnCollection.getRelationShipShowUniqueList().size());
        return resultReturnCollection;
    }

    @RequestMapping(value = "/twolayerBycompanyId", method = RequestMethod.GET)
    private ResultReturnCollection getTwoLayerRelatedNodeFromNeo4jByCompanyId(@RequestParam String companyId, boolean typeFlag) throws Exception {
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        QueryResultModel companyNode;
        companyNode = objectRepository.getTwoLayerGraphByCompanyId(companyId);
        int count = 0;
        for (Map<String, Object> result : companyNode) {
            ResultReturn resultReturn = new ResultReturn(
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("sourceNodeInfo")),
                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) result.get("relationInfo")),
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("targetNodeInfo")));
            resultReturnCollection.add(resultReturn);
            count = count + 1;
        }
        logger.debug(count);
        logger.debug(resultReturnCollection.getNodeShowHashMap().size());
        logger.debug(resultReturnCollection.getRelationShipShowHashMap().size());
        resultReturnCollection.setNodeShowBasicInfo(getBasicInfoNodeFromNeo4jByCompanyId(companyId));
        resultReturnCollection.updateElemtList();
        logger.debug(resultReturnCollection.getNodeShowsUniqueList().size());
        logger.debug(resultReturnCollection.getRelationShipShowUniqueList().size());
        return resultReturnCollection;
    }

    @RequestMapping(value = "/neo4jBycompanyNm", method = RequestMethod.GET)
    private ResultReturnCollection getRelatedNodeFromNeo4jByCompanyNm(@RequestParam String companyNm, boolean typeFlag) throws Exception {
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        QueryResultModel companyNode;
        if (typeFlag) {
            companyNode = objectRepository.getByCompanyNm(companyNm);
        } else {
            companyNode = objectRepository.getByCompanyNmWithoutManager(companyNm);
        }
        QueryResultModel companyNodeSupplierCustomer = objectRepository.getSupplierCustomerByCompanyNm(companyNm);
        QueryResultModel companyNodeGuarantee = objectRepository.getGuaranteeByCompanyNm(companyNm);

        int count = 0;
        for (Map<String, Object> result : companyNode) {
            ResultReturn resultReturn = new ResultReturn(
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("sourceNodeInfo")),
                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) result.get("relationInfo")),
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("targetNodeInfo")));
            resultReturnCollection.add(resultReturn);
            count = count + 1;
        }
        for (Map<String, Object> result : companyNodeSupplierCustomer) {
            ResultReturn resultReturn = new ResultReturn(
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("sourceNodeInfo")),
                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) result.get("relationInfo")),
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("targetNodeInfo")));
            resultReturnCollection.add(resultReturn);
            count = count + 1;
        }
        for (Map<String, Object> result : companyNodeGuarantee) {
            ResultReturn resultReturn = new ResultReturn(
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("sourceNodeInfo")),
                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) result.get("relationInfo")),
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("targetNodeInfo")));
            resultReturnCollection.add(resultReturn);
            count = count + 1;
        }
        logger.debug(count);
        logger.debug(resultReturnCollection.getNodeShowHashMap().size());
        logger.debug(resultReturnCollection.getRelationShipShowHashMap().size());
        resultReturnCollection.setNodeShowBasicInfo(getBasicInfoNodeFromNeo4jByCompanyNm(companyNm));
        resultReturnCollection.updateElemtList();
        logger.debug(resultReturnCollection.getNodeShowsUniqueList().size());
        logger.debug(resultReturnCollection.getRelationShipShowUniqueList().size());
        return resultReturnCollection;
    }

    @RequestMapping(value = "/neo4jBysecurityId", method = RequestMethod.GET)
    private ResultReturnCollection getSecurityInfoFromNeo4jBysecurityid(@RequestParam String securityId) throws Exception {
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        QueryResultModel companyNode = objectRepository.getBySecurityId(securityId);
        int count = 0;
        for (Map<String, Object> result : companyNode) {
            ResultReturn resultReturn = new ResultReturn(
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("sourceNodeInfo")),
                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) result.get("relationInfo")),
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("targetNodeInfo")));
            resultReturnCollection.add(resultReturn);
            count = count + 1;
        }
        logger.debug(count);
        logger.debug(resultReturnCollection.getNodeShowHashMap().size());
        logger.debug(resultReturnCollection.getRelationShipShowHashMap().size());
        resultReturnCollection.setNodeShowBasicInfo(getSecurityBasicInfoFromNeo4jBySecurityId(securityId));
        resultReturnCollection.updateElemtList();
        logger.debug(resultReturnCollection.getNodeShowsUniqueList().size());
        logger.debug(resultReturnCollection.getRelationShipShowUniqueList().size());
        return resultReturnCollection;
    }

    @RequestMapping(value = "/neo4jBycompanyId", method = RequestMethod.GET)
    private ResultReturnCollection getRelatedNodeFromNeo4jByCompanyId(@RequestParam String companyId, boolean typeFlag) throws Exception {
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        QueryResultModel companyNode;
        if (typeFlag) {
            companyNode = objectRepository.getByCompanyId(companyId);
        } else {
            companyNode = objectRepository.getByCompanyIdWithoutManager(companyId);
        }
        QueryResultModel companyNodeSupplierCustomer = objectRepository.getSupplierCustomerByCompanyId(companyId);
        QueryResultModel companyNodeGuarantee = objectRepository.getGuaranteeByCompanyId(companyId);

        int count = 0;
        for (Map<String, Object> result : companyNode) {
            ResultReturn resultReturn = new ResultReturn(
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("sourceNodeInfo")),
                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) result.get("relationInfo")),
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("targetNodeInfo")));
            resultReturnCollection.add(resultReturn);
            count = count + 1;
        }
        for (Map<String, Object> result : companyNodeSupplierCustomer) {
            ResultReturn resultReturn = new ResultReturn(
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("sourceNodeInfo")),
                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) result.get("relationInfo")),
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("targetNodeInfo")));
            resultReturnCollection.add(resultReturn);
            count = count + 1;
        }
        for (Map<String, Object> result : companyNodeGuarantee) {
            ResultReturn resultReturn = new ResultReturn(
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("sourceNodeInfo")),
                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) result.get("relationInfo")),
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("targetNodeInfo")));
            resultReturnCollection.add(resultReturn);
            count = count + 1;
        }
        logger.debug(count);
        logger.debug(resultReturnCollection.getNodeShowHashMap().size());
        logger.debug(resultReturnCollection.getRelationShipShowHashMap().size());
        resultReturnCollection.setNodeShowBasicInfo(getBasicInfoNodeFromNeo4jByCompanyId(companyId));
        resultReturnCollection.updateElemtList();
        logger.debug(resultReturnCollection.getNodeShowsUniqueList().size());
        logger.debug(resultReturnCollection.getRelationShipShowUniqueList().size());
        return resultReturnCollection;
    }

    @RequestMapping(value = "/daas", method = RequestMethod.GET)
    private ResultReturnCollection getRelatedNodeFromDaas(@RequestParam String companyNm) throws Exception {
        if (UseFulFunc.isNumeric(companyNm)) {
            companyNm = objectRepository.getCompanyNmByCompanyId(companyNm);
        }
        JSONObject jsonObject = GetChinaDaasData.downLoadChinaDaasDataByCompanyNm(companyNm);
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        try {
            resultReturnCollection = GetChinaDaasData.getRelationOfJson(jsonObject);
//        resultReturnCollection.setNodeShowBasicInfo(getBasicInfoNodeFromDaas(companyNm));
            resultReturnCollection.setNodeShowBasicInfo(getBasicInfoNodeFromDaas(jsonObject));
            resultReturnCollection.updateElemtList();
            return resultReturnCollection;
        } catch (Exception e) {
            resultReturnCollection.setNodeShowBasicInfo(null);
            resultReturnCollection.setNodeShowsUniqueList(null);
            resultReturnCollection.setRelationShipShowUniqueList(null);
            return resultReturnCollection;
        }

    }

    @RequestMapping(value = "/daas/person", method = RequestMethod.GET)
    private ResultReturnCollection getRelatedPersonFromDaas(@RequestParam String companyNm, @RequestParam String personNm) throws Exception {
        JSONObject jsonObject = GetChinaDaasData.downLoadChinaDaasDataByCompanyNmPersonNm(companyNm, personNm);
        logger.debug(jsonObject);
        JSONObject basicInfo = new JSONObject();
        basicInfo.put("ENTNAME", companyNm);
        basicInfo.put("RYNAME", personNm);
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        try {
            resultReturnCollection = GetChinaDaasData.getPersonRelationOfJson(jsonObject, basicInfo);
            logger.debug(resultReturnCollection);
            //        resultReturnCollection.setNodeShowBasicInfo(getBasicInfoNodeFromDaas(companyNm));
            resultReturnCollection.setNodeShowBasicInfo(getBasicInfoPersonFromDaas(basicInfo));
            resultReturnCollection.updateElemtList();
            return resultReturnCollection;
        } catch (Exception e) {
            logger.debug(e);
            resultReturnCollection.setNodeShowBasicInfo(null);
            resultReturnCollection.setNodeShowsUniqueList(null);
            resultReturnCollection.setRelationShipShowUniqueList(null);
            return resultReturnCollection;
        }
    }

    private ResultReturnCollection getRelatedPersonFromNeo4j(@RequestParam String companyNm, @RequestParam String personNm) throws Exception {
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        int count = 0;
        QueryResultModel InfoNode = objectRepository.getPersonInfoByCompanyNmAndPersonNm(companyNm, personNm);

        for (Map<String, Object> result : InfoNode) {
            ResultReturn resultReturn = new ResultReturn(
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("sourceNodeInfo")),
                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) result.get("relationInfo")),
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("targetNodeInfo")));
            resultReturnCollection.add(resultReturn);
            count = count + 1;
        }
        logger.debug(count);
        logger.debug(resultReturnCollection.getNodeShowHashMap().size());
        logger.debug(resultReturnCollection.getRelationShipShowHashMap().size());
        resultReturnCollection.setNodeShowBasicInfo(getPersonBasicInfoNodeFromNeo4jByCompanyNmAndPersonNm(companyNm, personNm));
        resultReturnCollection.updateElemtList();
        logger.debug(resultReturnCollection.getNodeShowsUniqueList().size());
        logger.debug(resultReturnCollection.getRelationShipShowUniqueList().size());
        return resultReturnCollection;
    }


    @RequestMapping(value = "/company/company_id", method = RequestMethod.GET)
    private ResultReturnCollection getGraphWithoutManager(@RequestParam String link_id, @RequestParam(value = "label", defaultValue = "1") String label) throws Exception {
        boolean typeflag = false;
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        return getGraphFunction(link_id, label, resultReturnCollection, typeflag);
    }

    @RequestMapping(value = "/affiliatedparty/company_id", method = RequestMethod.GET)
    private ResultReturnCollection getGraph(@RequestParam String link_id, @RequestParam(value = "label", defaultValue = "1") String label) throws Exception {
        boolean typeflag = true;
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        return getGraphFunction(link_id, label, resultReturnCollection, typeflag);
    }

    @RequestMapping(value = "/companytwolayer/company_id", method = RequestMethod.GET)
    private ResultReturnCollection getTwoLayerGraph(@RequestParam String link_id, @RequestParam(value = "label", defaultValue = "1") String label) throws Exception {
        boolean typeflag = true;
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        return getTwoLayerGraphFunction(link_id, label, resultReturnCollection, typeflag);
    }

    private ResultReturnCollection getGraphFunction(String link_id, String label, ResultReturnCollection resultReturnCollection, boolean typeflag) throws Exception {
        if (label.equals("1")) {
            if (UseFulFunc.isNumeric(link_id)) {
                resultReturnCollection = getRelatedNodeFromNeo4jByCompanyId(link_id, typeflag);
            } else {
                link_id = com.cscs.graph_api.Util.Base64.decode(link_id.replace("（", "(").replace("）", ")"));
                resultReturnCollection = getRelatedNodeFromNeo4jByCompanyNm(link_id, typeflag);
            }
            if ((resultReturnCollection.getRelationShipShowUniqueList() == null || resultReturnCollection.getRelationShipShowUniqueList().isEmpty()) && (resultReturnCollection.getNodeShowsUniqueList() == null || resultReturnCollection.getNodeShowsUniqueList().isEmpty())) {
                resultReturnCollection = getRelatedNodeFromDaas(link_id);
            }
        } else if (label.equals("2")) {
            link_id = com.cscs.graph_api.Util.Base64.decode(link_id).replace("（", "(").replace("）", ")");
            String[] splitresult = link_id.split("&&");
            if (splitresult.length == 2) {
                String company_nm = splitresult[0];
                String person_nm = splitresult[1];
                resultReturnCollection = getRelatedPersonFromDaas(company_nm, person_nm);
//                resultReturnCollection = getRelatedPersonFromNeo4j(company_nm,person_nm);
//                if((resultReturnCollection.getRelationShipShowUniqueList()==null||resultReturnCollection.getRelationShipShowUniqueList().isEmpty()) && (resultReturnCollection.getNodeShowsUniqueList()==null||resultReturnCollection.getNodeShowsUniqueList().isEmpty())) {
//                    resultReturnCollection = getRelatedPersonFromDaas(company_nm,person_nm);
//                }
            }
        } else if (label.equals("3")) {
            resultReturnCollection = getSecurityInfoFromNeo4jBysecurityid(link_id);
        }
        if (resultReturnCollection.getRelationShipShowUniqueList() != null && resultReturnCollection.getNodeShowsUniqueList() != null && resultReturnCollection.getRelationShipShowUniqueList().isEmpty() && resultReturnCollection.getNodeShowsUniqueList().isEmpty()) {
            resultReturnCollection.setNodeShowBasicInfo(null);
        }
        return resultReturnCollection;
    }

    private ResultReturnCollection getTwoLayerGraphFunction(String link_id, String label, ResultReturnCollection resultReturnCollection, boolean typeflag) throws Exception {
        if (label.equals("1")) {
            if (UseFulFunc.isNumeric(link_id)) {
                resultReturnCollection = getTwoLayerRelatedNodeFromNeo4jByCompanyId(link_id, typeflag);
            } else {
                link_id = com.cscs.graph_api.Util.Base64.decode(link_id.replace("（", "(").replace("）", ")"));
                resultReturnCollection = getTwoLayerRelatedNodeFromNeo4jByCompanyNm(link_id, typeflag);
            }
        }
        if (resultReturnCollection.getRelationShipShowUniqueList() != null && resultReturnCollection.getNodeShowsUniqueList() != null && resultReturnCollection.getRelationShipShowUniqueList().isEmpty() && resultReturnCollection.getNodeShowsUniqueList().isEmpty()) {
            resultReturnCollection.setNodeShowBasicInfo(null);
        }
        return resultReturnCollection;
    }


}
