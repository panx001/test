package com.cscs.graph_api.domain;

import java.util.ArrayList;

/**
 * Created by wuchenglong on 2018/1/10.
 */

@SuppressWarnings("unused")
public class NodeQueryBasicInfoResult {

    private ArrayList<String> LABELS;
    private String COMPANY_ID;
    private String COMPANY_NM;
    private String SECURITY_NM;
    private String SECURITY_ID;
    private String PERSON_NM;
    private String PERSON_ID;
    private Object COMPANY_TYPE_LIST;
    private String COMPANY_TYPE;
    private String REG_CAPITAL;
    private String LEG_REPRESENT;
    private String REG_ADDR;
    private String FOUND_DT;
    private String LEG_PRESENT;
    private String SECURITY_CODE;
    private String COMPANY_STATUS;
    private ArrayList<Object> RISK_LIST;  // 风险标签

    public NodeQueryBasicInfoResult() {

    }

    public void setREG_ADDR(String REG_ADDR) {
        this.REG_ADDR = REG_ADDR;
    }

    public String getREG_ADDR() {
        return REG_ADDR;
    }

    public void setFOUND_DT(String FOUND_DT) {
        this.FOUND_DT = FOUND_DT;
    }

    public String getFOUND_DT() {
        return FOUND_DT;
    }

    public void setLEG_PRESENT(String LEG_PRESENT) {
        this.LEG_PRESENT = LEG_PRESENT;
    }

    public String getLEG_PRESENT() {
        return LEG_PRESENT;
    }

    public void setSECURITY_CODE(String SECURITY_CODE) {
        this.SECURITY_CODE = SECURITY_CODE;
    }

    public String getSECURITY_CODE() {
        return SECURITY_CODE;
    }

    public void setCOMPANY_STATUS(String COMPANY_STATUS) {
        this.COMPANY_STATUS = COMPANY_STATUS;
    }

    public String getCOMPANY_STATUS() {
        return COMPANY_STATUS;
    }

    public void setCOMPANY_TYPE(String COMPANY_TYPE) {
        this.COMPANY_TYPE = COMPANY_TYPE;
    }

    public String getCOMPANY_TYPE() {
        return COMPANY_TYPE;
    }

    public void setCOMPANY_TYPE_LIST(Object COMPANY_TYPE_LIST) {
        this.COMPANY_TYPE_LIST = COMPANY_TYPE_LIST;
    }

    public Object getCOMPANY_TYPE_LIST() {
        return COMPANY_TYPE_LIST;
    }

    public void setLABELS(ArrayList<String> LABELS) {
        this.LABELS = LABELS;
    }

    public ArrayList<String> getLABELS() {
        return LABELS;
    }

    public void setCOMPANY_ID(String COMPANY_ID) {
        this.COMPANY_ID = COMPANY_ID;
    }

    public String getCOMPANY_ID() {
        return COMPANY_ID;
    }

    public void setCOMPANY_NM(String COMPANY_NM) {
        this.COMPANY_NM = COMPANY_NM;
    }

    public String getCOMPANY_NM() {
        return COMPANY_NM;
    }

    public void setPERSON_ID(String PERSON_ID) {
        this.PERSON_ID = PERSON_ID;
    }

    public String getPERSON_ID() {
        return PERSON_ID;
    }

    public void setPERSON_NM(String PERSON_NM) {
        this.PERSON_NM = PERSON_NM;
    }

    public String getPERSON_NM() {
        return PERSON_NM;
    }

    public void setREG_CAPITAL(String REG_CAPITAL) {
        this.REG_CAPITAL = REG_CAPITAL;
    }

    public String getREG_CAPITAL() {
        return REG_CAPITAL;
    }

    public void setRISK_LIST(ArrayList<Object> RISK_LIST) {
        this.RISK_LIST = RISK_LIST;
    }

    public ArrayList<Object> getRISK_LIST() {
        return RISK_LIST;
    }

    public String getSECURITY_NM() {
        return SECURITY_NM;
    }

    public void setSECURITY_NM(String SECURITY_NM) {
        this.SECURITY_NM = SECURITY_NM;
    }

    public String getSECURITY_ID() {
        return SECURITY_ID;
    }

    public void setSECURITY_ID(String SECURITY_ID) {
        this.SECURITY_ID = SECURITY_ID;
    }

    public String getLEG_REPRESENT() {
        return LEG_REPRESENT;
    }

    public void setLEG_REPRESENT(String LEG_REPRESENT) {
        this.LEG_REPRESENT = LEG_REPRESENT;
    }
}
