package com.cscs.graph_api.mapper;

import com.cscs.graph_api.domain.DaasCompanyBasicInfoNode;
import com.cscs.graph_api.domain.NodeShowBasicInfo;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

/**
 * Created by wuchenglong on 2018/1/10.
 */
@Mapper
public interface DaasCompanyBasicInfoNodeMapper {

    DaasCompanyBasicInfoNodeMapper MAPPER = Mappers.getMapper(DaasCompanyBasicInfoNodeMapper.class);

    @Mappings({
            @Mapping(target = "suggestedLabel", constant = "COMPANY"),
            @Mapping(source = "ENTNAME", target = "name"),
            @Mapping(source = "ESDATE", target = "found_dt"),
            @Mapping(source = "DOM", target = "reg_addr"),
            @Mapping(source = "REGCAP", target = "reg_capital"),
    })
    NodeShowBasicInfo QueryResultToNodeShow(DaasCompanyBasicInfoNode nodeQueryResult);

    @InheritInverseConfiguration
    DaasCompanyBasicInfoNode NodeShowToQueryResult(NodeShowBasicInfo nodeShow);

}
