package com.cscs.graph_api.domain;

/**
 * Created by wuchenglong on 2018/1/10.
 */


@SuppressWarnings("unused")
public class DaasCompanyBasicInfoNode {

    private String ENTSTATUS;  // 企业状态
    private String FRNAME; // 法人
    private String REGCAP; // 注册资本
    private String ESDATE; // 成立时间
    private String ENTNAME; // 企业名称
    private String DOM; // 注册地址

    public DaasCompanyBasicInfoNode() {

    }

    public void setENTNAME(String ENTNAME) {
        this.ENTNAME = ENTNAME;
    }

    public String getENTNAME() {
        return ENTNAME;
    }

    public void setENTSTATUS(String ENTSTATUS) {
        this.ENTSTATUS = ENTSTATUS;
    }

    public String getENTSTATUS() {
        return ENTSTATUS;
    }

    public void setESDATE(String ESDATE) {
        this.ESDATE = ESDATE;
    }

    public String getESDATE() {
        return ESDATE;
    }

    public void setFRNAME(String FRNAME) {
        this.FRNAME = FRNAME;
    }

    public String getFRNAME() {
        return FRNAME;
    }

    public void setREGCAP(String REGCAP) {
        this.REGCAP = REGCAP;
    }

    public String getREGCAP() {
        return REGCAP;
    }

    public void setDOM(String DOM) {
        this.DOM = DOM;
    }

    public String getDOM() {
        return DOM;
    }
}
