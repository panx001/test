package com.cscs.graph_api.mapper;

import com.cscs.graph_api.domain.NodeQueryBasicInfoResult;
import com.cscs.graph_api.domain.NodeShowBasicInfo;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

/**
 * Created by wuchenglong on 2018/1/10.
 */

@Mapper
public interface NodeSecurityBasicInfoMapper {
    NodeSecurityBasicInfoMapper MAPPER = Mappers.getMapper(NodeSecurityBasicInfoMapper.class);

    @Mappings({
            @Mapping(target = "suggestedLabel", constant = "SECURITY"),
            @Mapping(source = "SECURITY_NM", target = "name"),
            @Mapping(source = "SECURITY_ID", target = "company_id"),
            @Mapping(source = "LABELS", target = "labels"),
    })
    NodeShowBasicInfo QueryResultToNodeShow(NodeQueryBasicInfoResult nodeQueryResult);

    @InheritInverseConfiguration
    NodeQueryBasicInfoResult NodeShowToQueryResult(NodeShowBasicInfo nodeShow);

}
