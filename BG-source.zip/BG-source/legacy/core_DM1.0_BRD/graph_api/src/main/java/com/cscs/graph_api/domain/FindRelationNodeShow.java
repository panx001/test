package com.cscs.graph_api.domain;

import com.cscs.graph_api.Util.Base64;
import com.cscs.graph_api.Util.String2MD5;
import com.cscs.graph_api.Util.UseFulFunc;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.stream.Collectors;

/**
 * Created by wuchenglong on 2018/1/7.
 */

@SuppressWarnings("unused")
public class FindRelationNodeShow {

    private static Logger logger = LogManager.getLogger(FindRelationNodeShow.class);

    private String id;
    @JsonProperty("type")
    private String suggestedLabel;
    @JsonIgnore
    private ArrayList<String> labels = new ArrayList<>();
    //@JsonProperty("nexus")
    private String description;
    private String name;
    //    @JsonIgnore
    private String company_id;
    @JsonIgnore
    private ArrayList<String> company_type;
    @JsonIgnore
    private String link_id;
    @JsonIgnore
    private ArrayList<Object> risk_list;
    @JsonIgnore
    private String reg_capital;

    public FindRelationNodeShow() {
    }

    public void infoUpdate() {
        //System.out.println(this.name);
//        if (this.name.equals("上海伍翎投资中心(有限合伙)"))
//        {
//            System.out.println(this.name);
//        }
        this.name = this.name == null ? "" : this.name;
        //this.id =  UseFulFunc.NODE_LABEL_MAP_ID.getOrDefault(this.suggestedLabel,"None")+this.company_id==null?this.name:this.company_id;
        this.id = String2MD5.md5(this.name);
        this.description = this.id;
        this.suggestedLabel = UseFulFunc.NODE_LABEL_MAP.getOrDefault(this.suggestedLabel, "None");
        this.link_id = (this.company_id != null) ? this.company_id : Base64.encode(this.name);//&& this.company_type.equals("1")
        //stream.collect(Collectors.toCollection(ArrayList::new));
        if (this.labels != null && !this.labels.isEmpty()) {
            this.labels = this.labels.stream().map(x -> UseFulFunc.NODE_LABEL_MAP.getOrDefault(x, "None")).collect(Collectors.toCollection(ArrayList::new));
        } else {
            this.labels.add(getSuggestedLabel());
        }

    }

    public void setCompany_id(String company_id) {
        this.company_id = company_id;
    }

    public String getCompany_id() {
        return company_id;
    }

    public void setCompany_type(ArrayList<String> company_type) {
        this.company_type = company_type;
    }

    public ArrayList<String> getCompany_type() {
        return company_type;
    }

    public void setLink_id(String link_id) {
        this.link_id = link_id;
    }

    public String getLink_id() {
        return link_id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setSuggestedLabel(String suggestedLabel) {
        this.suggestedLabel = suggestedLabel;
    }

    public String getSuggestedLabel() {
        return suggestedLabel;
    }

    public void setLabels(ArrayList<String> labels) {
        this.labels = labels;
    }

    public ArrayList<String> getLabels() {
        return labels;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setReg_capital(String reg_capital) {
        this.reg_capital = reg_capital;
    }

    public String getReg_capital() {
        return reg_capital;
    }

    public void setRisk_list(ArrayList<Object> risk_list) {
        this.risk_list = risk_list;
    }

    public ArrayList<Object> getRisk_list() {
        return risk_list;
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof FindRelationNodeShow)) {
            return false;
        }
        FindRelationNodeShow nodeShow = (FindRelationNodeShow) obj;
        return nodeShow.getName().equals(this.name);
    }

    @Override
    public int hashCode() {
        return 123;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
