package com.cscs.graph_api.domain;


import com.cscs.graph_api.Util.UseFulFunc;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.collections.list.SetUniqueList;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang.StringUtils;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by wuchenglong on 2018/1/8.
 */

@SuppressWarnings("unused")
public class RelationShipShow {

    private String id;
    @JsonProperty("relation_type")
    private String type;
    private Object nexus;
    private String source_id;
    private String target_id;
    private List<String> path_type = new ArrayList<>();

    @JsonIgnore
    private String invest_sha_ratio;
    @JsonIgnore
    private String invest_num;
    @JsonIgnore
    private String work_position;
    @JsonIgnore
    private String sc_relation_type;
    @JsonIgnore
    private String path_id;
    @JsonIgnore
    private String guar_info;


    public RelationShipShow() {
    }

    public RelationShipShow(JSONObject jsonObject, String relationSource) {
        if (relationSource.equals("ENTINV")) {
            this.invest_sha_ratio = jsonObject.get("FUNDEDRATIO").toString();
            this.type = "INVEST";
        }
        if (relationSource.equals("PERSON")) {
            this.work_position = jsonObject.get("POSITION").toString();
            this.type = "WORK";
        }
        if (relationSource.equals("SHAREHOLDER")) {
            this.invest_sha_ratio = jsonObject.get("FUNDEDRATIO").toString();
            this.type = "INVEST";
        }
        if (relationSource.equals("FRINV")) {
            this.invest_sha_ratio = jsonObject.get("FUNDEDRATIO").toString();
            this.type = "INVEST";
        }
        if (relationSource.equals("FRPOSITION")) {
            this.work_position = jsonObject.get("POSITION").toString();
            this.type = "WORK";
        }
        if (relationSource.equals("RYPOSSHA")) {
            this.invest_sha_ratio = jsonObject.get("FUNDEDRATIO").toString();
            this.type = "INVEST";
        }
        if (relationSource.equals("RYPOSFR")) {
            this.work_position = "法定代表人";
            this.type = "WORK";
        }
        if (relationSource.equals("RYPOSPER")) {
            this.work_position = jsonObject.get("POSITION").toString().equals("") ? "高管" : jsonObject.get("POSITION").toString();
            this.type = "WORK";
        }
    }

    public void infoUpdate() {
        this.id = this.source_id + "-" + this.type + "-" + this.target_id;

        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("INVEST", "0"))) {
            DecimalFormat df = new DecimalFormat("0.##");
            Float sha_ratio = Float.parseFloat(df.format(Float.parseFloat(this.invest_sha_ratio.toString().replace("%", ""))));
            //this.nexus = Float.parseFloat(df.format(Float.parseFloat(this.invest_sha_ratio.toString().replace("%",""))));
            this.nexus = this.invest_sha_ratio != null && (sha_ratio <= 100) ? sha_ratio : 0;
            return;
        }
        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("WORK", "0"))) {
            this.nexus = this.work_position;
            return;
        }
        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("ISSUE", "0"))) {
            this.nexus = "发行";
            return;
        }
        //以下四类关系应该在图谱中不出现，只出现在找关系中
        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("BRANCH", "0"))) {
            this.nexus = "分支机构";
            return;
        }
        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("CLASSMATESUS", "0"))) {
            this.nexus = "疑似同学";
            return;
        }
        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("ADDRESSSIM", "0"))) {
            this.nexus = "相似地址";
            return;
        }
        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("COLLEAGUESUS", "0"))) {
            this.nexus = "疑似同事";
            return;
        }
        //控制人关系只出现在疑似/实际控制人接口中
        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("CONTROLLER", "0"))) {
            this.nexus = "控股";
            return;
        }

        //私募相关关系
        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("MANAGER", "0"))) {
            this.nexus = "管理方";
            return;
        }
        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("TRUSTEE", "0"))) {
            this.nexus = "托管方";
            return;
        }
        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("RELATIVE", "0"))) {
            this.nexus = this.sc_relation_type;
            return;
        }
        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("GUARANTEE", "0"))) {
            if (this.guar_info != null) {
                JSONArray jsonArray = JSONArray.fromObject(this.guar_info);
                JSONArray results = new JSONArray();
                for (int i = 0; i < jsonArray.size(); i++) {
                    HashedMap result = new HashedMap();
                    result.put("money", jsonArray.getJSONObject(i).getString("GUAR_AMT"));
                    result.put("guar_end_date", jsonArray.getJSONObject(i).getString("GUAR_END_DT"));
                    results.add(result);
                }
                this.nexus = results;
            } else {
                this.nexus = "担保";
            }
            return;
        }
        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("SUPPLIER", "0")) ||
                this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("CUSTOMER", "0"))
                ) {
            this.nexus = this.sc_relation_type;
            return;
        }
    }

    public void setPath_type(List<String> path_type) {
        this.path_type = path_type;
    }

    public List<String> getPath_type() {
        return path_type;
    }

    public void setSource_id(String source_id) {
        this.source_id = source_id;
    }

    public String getSource_id() {
        return source_id;
    }

    public void setTarget_id(String target_id) {
        this.target_id = target_id;
    }

    public String getTarget_id() {
        return target_id;
    }

    public void updateNexus(Object nexus) {
        List<String> nexus_tmp = SetUniqueList.decorate(new ArrayList<String>());
        nexus_tmp.addAll(Arrays.asList(this.nexus.toString().split("、|,|，")));
        nexus_tmp.addAll(Arrays.asList(nexus.toString().split("、|,|，")));
        this.setNexus(StringUtils.join(nexus_tmp.stream().filter(s -> !s.equals("")).collect(Collectors.toList()), "、"));
    }

    public boolean ifNexusExist(Object nexus) {
        List<String> nexus_tmp = SetUniqueList.decorate(new ArrayList<String>());
        nexus_tmp.addAll(Arrays.asList(this.nexus.toString().split("、|,|，")));
        return nexus_tmp.get(0).equals(nexus.toString());
    }

    public void updatePathType(List<String> pathType) {
        this.path_type.addAll(pathType);
        this.path_type = SetUniqueList.decorate(this.path_type);
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setInvest_num(String invest_num) {
        this.invest_num = invest_num;
    }

    public String getInvest_num() {
        return invest_num;
    }

    public void setWork_position(String work_position) {
        this.work_position = work_position;
    }

    public String getWork_position() {
        return work_position;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setInvest_sha_ratio(String invest_sha_ratio) {
        this.invest_sha_ratio = invest_sha_ratio;
    }

    public String getInvest_sha_ratio() {
        return invest_sha_ratio;
    }

    public void setNexus(Object nexus) {
        this.nexus = nexus;
    }

    public Object getNexus() {
        return nexus;
    }

    public void setSc_relation_type(String sc_relation_type) {
        this.sc_relation_type = sc_relation_type;
    }

    public String getSc_relation_type() {
        return sc_relation_type;
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof RelationShipShow)) {
            return false;
        }
        RelationShipShow relationShipShow = (RelationShipShow) obj;
        return (relationShipShow.getSource_id().equals(this.source_id) && relationShipShow.getTarget_id().equals(this.target_id)) && relationShipShow.getType().equals(this.getType());
    }

    @Override
    public int hashCode() {
        return (this.source_id + this.target_id).hashCode();
    }

    public String getPath_id() {
        return path_id;
    }

    public void setPath_id(String path_id) {
        this.path_id = path_id;
    }

    public String getGuar_info() {
        return guar_info;
    }

    public void setGuar_info(String guar_info) {
        this.guar_info = guar_info;
    }
}
