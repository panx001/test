package com.cscs.graph_api.mapper;

import com.cscs.graph_api.domain.NodeQueryBasicInfoResult;
import com.cscs.graph_api.domain.NodeShowBasicInfo;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

/**
 * Created by wuchenglong on 2018/1/10.
 */

@Mapper
public interface NodePersonBasicInfoMapper {
    NodePersonBasicInfoMapper MAPPER = Mappers.getMapper(NodePersonBasicInfoMapper.class);

    @Mappings({
            @Mapping(target = "suggestedLabel", constant = "PERSON"),
            @Mapping(source = "PERSON_NM", target = "name"),
            @Mapping(source = "PERSON_ID", target = "company_id"),
            @Mapping(source = "LABELS", target = "labels"),
    })
    NodeShowBasicInfo QueryResultToNodeShow(NodeQueryBasicInfoResult nodeQueryResult);

    @InheritInverseConfiguration
    NodeQueryBasicInfoResult NodeShowToQueryResult(NodeShowBasicInfo nodeShow);

}
