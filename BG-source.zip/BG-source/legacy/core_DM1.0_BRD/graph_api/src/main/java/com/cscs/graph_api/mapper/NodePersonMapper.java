package com.cscs.graph_api.mapper;

/**
 * Created by wuchenglong on 2018/1/8.
 */


import com.cscs.graph_api.domain.FindRelationNodeShow;
import com.cscs.graph_api.domain.NodeQueryResult;
import com.cscs.graph_api.domain.NodeShow;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;


@SuppressWarnings("unused")
@Mapper
public interface NodePersonMapper {

    NodePersonMapper MAPPER = Mappers.getMapper(NodePersonMapper.class);

    @Mappings({
            @Mapping(target = "suggestedLabel", constant = "PERSON"),
            @Mapping(source = "PERSON_NM", target = "name"),
            @Mapping(source = "LINK_ID", target = "link_id"),
            @Mapping(target = "risk_list", ignore = true),
            @Mapping(target = "company_type", ignore = true),
            @Mapping(source = "LABELS", target = "labels")
    })
    NodeShow QueryResultToNodeShow(NodeQueryResult nodeQueryResult);

    @Mappings({
            @Mapping(target = "suggestedLabel", constant = "PERSON"),
            @Mapping(source = "PERSON_NM", target = "name"),
            @Mapping(source = "LINK_ID", target = "link_id"),
            @Mapping(target = "risk_list", ignore = true),
            @Mapping(target = "company_type", ignore = true),
            @Mapping(source = "LABELS", target = "labels")
    })
    FindRelationNodeShow QueryResultToFindRelationNodeShow(NodeQueryResult nodeQueryResult);

    @InheritInverseConfiguration
    NodeQueryResult NodeShowToQueryResult(NodeShow nodeShow);

    @InheritInverseConfiguration
    NodeQueryResult FindRelationNodeShowToQueryResult(FindRelationNodeShow nodeShow);
}
