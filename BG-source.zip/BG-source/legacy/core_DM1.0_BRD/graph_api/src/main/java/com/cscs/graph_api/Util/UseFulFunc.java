package com.cscs.graph_api.Util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by wuchenglong on 16/12/15.
 */

public class UseFulFunc {

    public final static Map<String, String> NODE_LABEL_MAP_ID = new HashMap<String, String>() {{
        put("COMPANY", "c");
        put("PERSON", "p");
        put("SECURITY", "c");
    }};

    public final static HashMap<String, String> NODE_LABEL_MAP = new HashMap<String, String>() {{
        put("COMPANY", "1"); // 一般企业
        put("PERSON", "2"); // 自然人
        put("SECURITY", "3"); // 金融产品
        put("PFUND", "4");//私募基金产品
        put("PFCOMPANY", "5"); // 私募机构
    }};

    public final static HashMap<String, String> NODE_TYPE_MAP = new HashMap<String, String>() {{
        put("A股", "A"); // A股 企业
        put("B股", "B"); // B股 企业
        put("H股", "H"); // H股 企业
        put("发债企业", "F");//发债 企业
        put("私募企业", "P");//发债 企业
        put("三板股", "3");//新三板 企业
        put("老三版", "O");//老三版 企业
    }};

    public final static HashMap<String, String> RELATION_TYPE_MAP = new HashMap<String, String>() {{
        put("INVEST", "1");// 投资关系
        put("WORK", "2");// 任职关系
        put("CUSTOMER", "3");// 主要客户关系
        put("SUPPLIER", "4");// 主要供应商关系
        put("GUARANTEE", "5");// 担保关系
        put("MANAGER", "6");// 基金管理人关系
        put("RELATIVE", "7");// 亲戚关系
        put("CONTROLLER", "8");// 股权控制关系
        put("ISSUE", "9");// 产品发行关系
        put("GUARANTEE_TOTAL", "10");// 有效担保汇总
        put("TRUSTEE", "11");// 产品托管关系
        put("APPOINT", "12");// 法人委派关系
        put("BRANCH", "13");// 分支机构关系
        put("ADDRESSSIM", "14");// 相似地址关系
        put("CLASSMATESUS", "15");// 疑似同学关系
        put("COLLEAGUESUS", "16");// 疑似同事关系
    }};

    private static Logger logger = LogManager.getLogger(UseFulFunc.class);

    public static boolean isNumeric(String str) {
        Pattern pattern = Pattern.compile("[0-9]*");
        return pattern.matcher(str).matches();
    }

    public static String floatFormat(String a) {
        try {
            String str = "0";
            int n = 0;
            String result = "#0.00";
            Pattern pattern = Pattern.compile("\\.(\\d+)$");
            Matcher matcher = pattern.matcher(a);
            if (matcher.find()) {
                n = Math.max(Math.min(matcher.group(1).length() - 2, 2), 0);
            }
            for (int i = 0; i < n; i++) {
                result = result.concat(str);
            }
            Double b = Double.valueOf(a);
            DecimalFormat df = new DecimalFormat(result);
            return df.format(b).toString() + "%";
        } catch (Exception e) {
            return a;
        }
    }


    public static String objToString(Object obj) {
        String nexus;
        try {
            if (obj instanceof String) {
                nexus = UseFulFunc.floatFormat((String) obj);
            } else if (obj instanceof Double) {
                nexus = UseFulFunc.floatFormat(Double.toString((Double) obj));
            } else if (obj instanceof Integer) {
                nexus = UseFulFunc.floatFormat(Integer.toString((Integer) obj));
            } else {
                nexus = UseFulFunc.floatFormat((String) obj);
            }
        } catch (Exception e) {
            nexus = "";
        }
        return nexus;
    }

    public static boolean isDoubleValue(Object a) {
        try {
            Double.valueOf((String) a);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean is_iid(String string_to_test) {
        // 正则表达式规则
        // String regEx = "^(\\d{6})(18|19|20)?(\\d{2})([01]\\d)([0123]\\d)(\\d{3})(\\d|X|x)?$";
        String regEx = "^[\\da-zA-Z]\\d+[\\da-zA-Z]?$";
        // 编译正则表达式
        Pattern pattern = Pattern.compile(regEx);
        // 忽略大小写的写法
        // Pattern pat = Pattern.compile(regEx, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(string_to_test);
        // 查找字符串中是否有匹配正则表达式的字符/字符串
        return matcher.find();
    }

}
