package com.cscs.graph_api.domain;

import java.util.ArrayList;

/**
 * Created by wuchenglong on 2018/1/9.
 */

@SuppressWarnings("unused")
public class RelationQueryResult {

    private Long id;
    private String TYPE;  // 关系类型
    private String INVEST_SHA_RATIO;  // 投资比例
    private String INVEST_NUM;  // 投资金额
    private String WORK_POSITION;  // 任职职位
    private String SC_RELATION_TYPE;  // 供应商 主要客户 类型
    private ArrayList<String> PATH_TYPE; // 路径业务含义
    private String PATH_ID; // 路径类型识别号
    private String GUAR_INFO; // 担保信息内容
    //Set<Person> set = new HashSet<Person>();


    public void setPATH_TYPE(ArrayList<String> PATH_TYPE) {
        this.PATH_TYPE = PATH_TYPE;
    }

    public ArrayList<String> getPATH_TYPE() {
        return PATH_TYPE;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setTYPE(String TYPE) {
        this.TYPE = TYPE;
    }

    public String getTYPE() {
        return TYPE;
    }

    public void setINVEST_SHA_RATIO(String INVEST_SHA_RATIO) {
        this.INVEST_SHA_RATIO = INVEST_SHA_RATIO;
    }

    public String getINVEST_SHA_RATIO() {
        return INVEST_SHA_RATIO;
    }

    public void setWORK_POSITION(String WORK_POSITION) {
        this.WORK_POSITION = WORK_POSITION;
    }

    public String getWORK_POSITION() {
        return WORK_POSITION;
    }

    public void setINVEST_NUM(String INVEST_NUM) {
        this.INVEST_NUM = INVEST_NUM;
    }

    public String getINVEST_NUM() {
        return INVEST_NUM;
    }

    public void setSC_RELATION_TYPE(String SC_RELATION_TYPE) {
        this.SC_RELATION_TYPE = SC_RELATION_TYPE;
    }

    public String getSC_RELATION_TYPE() {
        return SC_RELATION_TYPE;
    }

    public String getPATH_ID() {
        return PATH_ID;
    }

    public void setPATH_ID(String PATH_ID) {
        this.PATH_ID = PATH_ID;
    }

    public String getGUAR_INFO() {
        return GUAR_INFO;
    }

    public void setGUAR_INFO(String GUAR_INFO) {
        this.GUAR_INFO = GUAR_INFO;
    }
}
