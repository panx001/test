package com.cscs.graph_api.mapper;

import com.cscs.graph_api.Util.Map2Obj;
import com.cscs.graph_api.Util.PersonCompanyNameJudgement;
import com.cscs.graph_api.domain.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Map;

/**
 * Created by wuchenglong on 2018/1/9.
 */

public class QueryResultMapper {
    private static Logger logger = LogManager.getLogger(QueryResultMapper.class);

    public QueryResultMapper() {
    }

    public static NodeShow DaasMapBasicInfoNodeShowToNodeShowMapper(Map<String, Object> map) {
        try {
            return DaasCompanyBasicInfoNodeShowNodeMapper.MAPPER.QueryResultToNodeShow(
                    (DaasCompanyBasicInfoNode) Map2Obj.map2Obj(map, DaasCompanyBasicInfoNode.class));
        } catch (Exception e) {
            return new NodeShow();
        }
    }

    public static NodeShow DaasMapPersonBasicInfoNodeShowToPersonNodeShowMapper(Map<String, Object> map) {
        try {
            return DaasPersonBasicInfoNodeShowNodeMapper.MAPPER.QueryResultToNodeShow(
                    (DaasPersonBasicInfoNode) Map2Obj.map2Obj(map, DaasPersonBasicInfoNode.class));
        } catch (Exception e) {
            return new NodeShow();
        }
    }


    public static NodeShowBasicInfo DaasMapBasicInfoNodeShowMapper(Map<String, Object> map) {
        try {
            // logger.debug(new org.apache.commons.beanutils.BeanMap(Map2Obj.map2Obj(map, DaasCompanyBasicInfoNode.class)).entrySet());
            return DaasCompanyBasicInfoNodeMapper.MAPPER.QueryResultToNodeShow(
                    (DaasCompanyBasicInfoNode) Map2Obj.map2Obj(map, DaasCompanyBasicInfoNode.class));
        } catch (Exception e) {
            logger.debug(e);
            return new NodeShowBasicInfo();
        }
    }

    public static NodeShowBasicInfo DaasMapPersonBasicInfoNodeShowMapper(Map<String, Object> map) {
        try {
            // logger.debug(new org.apache.commons.beanutils.BeanMap(Map2Obj.map2Obj(map, DaasCompanyBasicInfoNode.class)).entrySet());
            return DaasPersonBasicInfoNodeMapper.MAPPER.QueryResultToNodeShow(
                    (DaasPersonBasicInfoNode) Map2Obj.map2Obj(map, DaasPersonBasicInfoNode.class));
        } catch (Exception e) {
            logger.debug(e);
            return new NodeShowBasicInfo();
        }
    }

    public static NodeShowBasicInfo MapBasicInfoNodeShowMapper(Map<String, Object> map) {
        try {
            // System.out.println(new org.apache.commons.beanutils.BeanMap((NodeQueryResult) Map2Obj.map2Obj(map, NodeQueryResult.class)).entrySet());
            return NodeCompanyBasicInfoMapper.MAPPER.QueryResultToNodeShow(
                    (NodeQueryBasicInfoResult) Map2Obj.map2Obj(map, NodeQueryBasicInfoResult.class));
        } catch (Exception e) {
            logger.debug(e);
            return new NodeShowBasicInfo();
        }
    }

    public static NodeShowBasicInfo MapSecurityBasicInfoShowMapper(Map<String, Object> map) {
        try {
            // System.out.println(new org.apache.commons.beanutils.BeanMap((NodeQueryResult) Map2Obj.map2Obj(map, NodeQueryResult.class)).entrySet());
            return NodeSecurityBasicInfoMapper.MAPPER.QueryResultToNodeShow(
                    (NodeQueryBasicInfoResult) Map2Obj.map2Obj(map, NodeQueryBasicInfoResult.class));
        } catch (Exception e) {
            logger.debug(e);
            return new NodeShowBasicInfo();
        }
    }

    public static NodeShowBasicInfo MapPersonBasicInfoShowMapper(Map<String, Object> map) {
        try {
            // System.out.println(new org.apache.commons.beanutils.BeanMap((NodeQueryResult) Map2Obj.map2Obj(map, NodeQueryResult.class)).entrySet());
            return NodePersonBasicInfoMapper.MAPPER.QueryResultToNodeShow(
                    (NodeQueryBasicInfoResult) Map2Obj.map2Obj(map, NodeQueryBasicInfoResult.class));
        } catch (Exception e) {
            logger.debug(e);
            return new NodeShowBasicInfo();
        }
    }

    public static NodeShow MapNodeShowMapper(Map<String, Object> map) {
        try {
            return NodeQueryResultNodeShowMapper((NodeQueryResult) Map2Obj.map2Obj(map, NodeQueryResult.class));
        } catch (Exception e) {
            //System.out.print(e);
            return new NodeShow();
        }
    }

    public static FindRelationNodeShow MapFindRelationNodeShowMapper(Map<String, Object> map) {
        try {
            return NodeQueryResultFindRelationNodeShowMapper((NodeQueryResult) Map2Obj.map2Obj(map, NodeQueryResult.class));
        } catch (Exception e) {
            //System.out.print(e);
            return new FindRelationNodeShow();
        }
    }


    private static NodeShow NodeQueryResultNodeShowMapper(NodeQueryResult nodeQueryResult) {

        if (nodeQueryResult.getLABELS().contains("SECURITY")) {
            return NodeSecurityMapper.MAPPER.QueryResultToNodeShow(nodeQueryResult);
        } else if (nodeQueryResult.getLABELS().contains("COMPANY")) {
            return NodeCompanyMapper.MAPPER.QueryResultToNodeShow(nodeQueryResult);
        } else if (nodeQueryResult.getLABELS().contains("PERSON")) {
            return NodePersonMapper.MAPPER.QueryResultToNodeShow(nodeQueryResult);
        } else {
            return new NodeShow();
        }
    }

    private static FindRelationNodeShow NodeQueryResultFindRelationNodeShowMapper(NodeQueryResult nodeQueryResult) {

        if (nodeQueryResult.getLABELS().contains("SECURITY")) {
            return NodeSecurityMapper.MAPPER.QueryResultToFindRelationNodeShow(nodeQueryResult);
        } else if (nodeQueryResult.getLABELS().contains("COMPANY")) {
            return NodeCompanyMapper.MAPPER.QueryResultToFindRelationNodeShow(nodeQueryResult);
        } else if (nodeQueryResult.getLABELS().contains("PERSON")) {
            return NodePersonMapper.MAPPER.QueryResultToFindRelationNodeShow(nodeQueryResult);
        } else {
            return new FindRelationNodeShow();
        }
    }

    public static RelationShipShow MapRelationShipShowMapper(Map<String, Object> map) {
        try {
            return RelationQueryResultRelationShipShowMapper(
                    (RelationQueryResult) Map2Obj.map2Obj(map, RelationQueryResult.class));
        } catch (Exception e) {
            return new RelationShipShow();
        }
    }

    public static FindRelationRelationShipShow MapFindRelationRelationShipShowwMapper(Map<String, Object> map) {
        try {
            return RelationQueryResultFindRelationRelationShipShowMapper(
                    (RelationQueryResult) Map2Obj.map2Obj(map, RelationQueryResult.class));
        } catch (Exception e) {
            return new FindRelationRelationShipShow();
        }
    }

    private static RelationShipShow RelationQueryResultRelationShipShowMapper(RelationQueryResult relationQueryResult) {
        return RelationMapper.MAPPER.QueryMapToRelationShipShow(relationQueryResult);
    }

    private static FindRelationRelationShipShow RelationQueryResultFindRelationRelationShipShowMapper(RelationQueryResult relationQueryResult) {
        return RelationMapper.MAPPER.QueryMapToFindRelationRelationShipShow(relationQueryResult);
    }

    public static NodeShow DaasMapNodeShowMapper(Map<String, Object> map, String mapType, String companyNm) {
        try {
            if (mapType.equals("ENTINV")) {
                return DaasInvestmentNodeMapper.MAPPER.QueryResultToNodeShow(
                        (DaasInvestmentNode) Map2Obj.map2Obj(map, DaasInvestmentNode.class));
            }
            if (mapType.equals("PERSON")) {
                map.put("LINK_ID", companyNm + "&&" + map.get("PERNAME").toString());
                return DaasMainPersonNodeMapper.MAPPER.QueryResultToNodeShow(
                        (DaasMainPersonNode) Map2Obj.map2Obj(map, DaasMainPersonNode.class));
            }
            if (mapType.equals("SHAREHOLDER")) {
                if (PersonCompanyNameJudgement.isPersonName(map.get("SHANAME").toString())) {
                    map.put("LINK_ID", companyNm + "&&" + map.get("SHANAME").toString());
                    return DaasPersonShareHolderNodeMapper.MAPPER.QueryResultToNodeShow(
                            (DaasShareHolderNode) Map2Obj.map2Obj(map, DaasShareHolderNode.class));
                } else {
                    return DaasCompanyShareHolderNodeMapper.MAPPER.QueryResultToNodeShow(
                            (DaasShareHolderNode) Map2Obj.map2Obj(map, DaasShareHolderNode.class));
                }
            }
            if (mapType.equals("FRINV")) {
                return DaasFrinvestmentNodeMapper.MAPPER.QueryResultToNodeShow(
                        (DaasFrinvestmentNode) Map2Obj.map2Obj(map, DaasFrinvestmentNode.class));
            }
            if (mapType.equals("FRPOSITION")) {
                return DaasFrpositionNodeMapper.MAPPER.QueryResultToNodeShow(
                        (DaasFrpositionNode) Map2Obj.map2Obj(map, DaasFrpositionNode.class));
            }
            if (mapType.equals("RYPOSSHA")) {
                return DaasPersonInvestmentNodeMapper.MAPPER.QueryResultToNodeShow(
                        (DaasPersonInvestmentNode) Map2Obj.map2Obj(map, DaasPersonInvestmentNode.class));
            }
            if (mapType.equals("RYPOSFR")) {
                return DaasPersonPositionNodeMapper.MAPPER.QueryResultToNodeShow(
                        (DaasPersonPositionNode) Map2Obj.map2Obj(map, DaasPersonPositionNode.class));
            }
            if (mapType.equals("RYPOSPER")) {
                return DaasPersonPositionNodeMapper.MAPPER.QueryResultToNodeShow(
                        (DaasPersonPositionNode) Map2Obj.map2Obj(map, DaasPersonPositionNode.class));
            }
            return new NodeShow();
        } catch (Exception e) {
            logger.debug(e);
            return new NodeShow();
        }
    }

}
