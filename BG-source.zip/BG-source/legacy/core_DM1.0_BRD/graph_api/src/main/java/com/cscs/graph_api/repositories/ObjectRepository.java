package com.cscs.graph_api.repositories;

/**
 * Created by wuchenglong on 2018/1/3.
 */

import org.neo4j.ogm.response.model.QueryResultModel;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import java.util.List;
import java.util.Map;

// import org.springframework.data.neo4j.repository.GraphRepository;


@RepositoryRestResource(collectionResourceRel = "object", path = "object")
public interface ObjectRepository extends Neo4jRepository<Object, Long> {
    String relationType = "INVEST|MANAGER";//|ISSUE
    String relationTypeWithoutManager = "INVEST";//|ISSUE
    String relationTypeSecurity = "INVEST|MANAGER|TRUSTEE";//|ISSUE
    String relationTypeAll = "INVEST|WORK|GUARANTEE|MANAGER|RELATIVE|TRUSTEE|SUPPLIER|CUSTOMER|CONTROLLER|ISSUE";//|ISSUE
    String relationTypeRelation = "INVEST|WORK|GUARANTEE|MANAGER|RELATIVE|SUPPLIER|CUSTOMER|BRANCH";//|ISSUE
    String relationTypeRelationWithSuspect = "INVEST|WORK|GUARANTEE|MANAGER|RELATIVE|SUPPLIER|CUSTOMER|BRANCH|ADDRESSSIM|CLASSMATESUS|COLLEAGUESUS";//|ISSUE
    String relationTypeRelationForCompanyPerson = "INVEST|WORK|BRANCH";//|ISSUE
    String relationTypeIn = "SUPPLIER|CUSTOMER|WORK";//|ISSUE
    String relationTypeOut = "GUARANTEE";//|ISSUE
    String relationTypeTwoLayer = "INVEST|WORK|GUARANTEE|SUPPLIER|CUSTOMER";//|ISSUE


    //    String typeCondition = " WHERE EXISTS(A.COMPANY_TYPE_LIST) AND ANY(ELEM IN ['A股','B股','H股','三板股'] WHERE ELEM IN A.COMPANY_TYPE_LIST ) ";//|ISSUE
    String typeCondition = " ";
    String getRelationQuery = "WITH P, [n IN NODES(P)| SIZE([m IN FILTER(f IN NODES(P) WHERE ID(f)=ID(n))])] AS nodeIdCount  WHERE ALL(x IN nodeIdCount WHERE x<2)  \n" +
            "WITH P LIMIT 20  \n" +
            "WITH collect(P) as PS \n" +
            "UNWIND range(0, SIZE(PS)-1) as pos \n" +
            "UNWIND  relationships(PS[pos]) AS R \n" +
            "WITH toString(pos) as linenum,REDUCE(s=\"\",y IN EXTRACT(x IN RELATIONSHIPS(PS[pos]) | CASE WHEN STARTNODE(x).SECINNER_ID IS NOT NULL THEN STARTNODE(x).SECINNER_ID WHEN STARTNODE(x).COMPANY_ID IS NOT NULL THEN STARTNODE(x).COMPANY_ID ELSE STARTNODE(x).PERSON_ID END +TYPE(x)+ CASE WHEN ENDNODE(x).SECINNER_ID IS NOT NULL THEN ENDNODE(x).SECINNER_ID WHEN ENDNODE(x).COMPANY_ID IS NOT NULL THEN ENDNODE(x).COMPANY_ID ELSE ENDNODE(x).PERSON_ID END )|s+y ) as pathkey, startNode(R) AS sourceNodeInfo , R AS relationInfo, endNode(R) AS targetNodeInfo \n" +
            "OPTIONAL MATCH (targetNodeInfo)<-[r:INVEST]-()\n" +
            "WITH linenum,pathkey,sourceNodeInfo,relationInfo,targetNodeInfo,CASE WHEN ALL(x IN collect(r)  WHERE EXISTS(x.NUM) and x.NUM <> '0') THEN sum(ToFloat(r.NUM))  ELSE targetNodeInfo.REG_CAPITAL END AS REG_CAPITAL \n" +
            "RETURN  \n" +
            "{COMPANY_ID:sourceNodeInfo.COMPANY_ID,COMPANY_TYPE:sourceNodeInfo.COMPANY_TYPE_LIST,RISK_LIST:sourceNodeInfo.RISK_LIST,REG_CAPITAL:sourceNodeInfo.REG_CAPITAL,COMPANY_NM:sourceNodeInfo.COMPANY_NM,PERSON_NM:sourceNodeInfo.PERSON_NM,SECURITY_NM:sourceNodeInfo.SECURITY_NM,SECURITY_ID:sourceNodeInfo.SECINNER_ID,LABELS:Labels(sourceNodeInfo)} AS  sourceNodeInfo , \n" +
            "{PATH_TYPE:[linenum],TYPE:TYPE(relationInfo)," +
            "INVEST_SHA_RATIO: CASE WHEN relationInfo.SHA_RATIO IS NOT NULL THEN tofloat(relationInfo.SHA_RATIO) WHEN relationInfo.SHA_RATIO IS NULL AND relationInfo.NUM IS NOT NULL AND apoc.cscs.getRegCapital(relationInfo) <> 0 THEN tofloat(relationInfo.NUM)/apoc.cscs.getRegCapital(relationInfo)*100 ELSE 0 END" +
            ",WORK_POSITION:relationInfo.POSITION,SC_RELATION_TYPE:relationInfo.RELATION_TYPE,INVEST_NUM:relationInfo.NUM,PATH_ID:pathkey} AS relationInfo, \n" +
            "{COMPANY_ID:targetNodeInfo.COMPANY_ID,COMPANY_TYPE:targetNodeInfo.COMPANY_TYPE_LIST,RISK_LIST:targetNodeInfo.RISK_LIST,REG_CAPITAL:targetNodeInfo.REG_CAPITAL,COMPANY_NM:targetNodeInfo.COMPANY_NM,PERSON_NM:targetNodeInfo.PERSON_NM,SECURITY_NM:targetNodeInfo.SECURITY_NM,SECURITY_ID:targetNodeInfo.SECINNER_ID,LABELS:Labels(targetNodeInfo)} AS targetNodeInfo \n" +
            ";";
    String getRelationQueryWithSuspect = "WITH P, [n IN NODES(P)| SIZE([m IN FILTER(f IN NODES(P) WHERE ID(f)=ID(n))])] AS nodeIdCount  WHERE ALL(x IN nodeIdCount WHERE x<2) WITH P,[n IN relationships(P)| SIZE([m IN FILTER(f IN relationships(P) WHERE type(f)=type(n) and type(n) in ['ADDRESSSIM','CLASSMATESUS','COLLEAGUESUS'])])] AS relationtypeCount WHERE ALL(x IN relationtypeCount WHERE x<2)   \n" +
            "WITH P LIMIT 20  \n" +
            "WITH collect(P) as PS \n" +
            "UNWIND range(0, SIZE(PS)-1) as pos \n" +
            "UNWIND  relationships(PS[pos]) AS R \n" +
            "WITH toString(pos+100) as linenum,REDUCE(s=\"\",y IN EXTRACT(x IN RELATIONSHIPS(PS[pos]) | CASE WHEN STARTNODE(x).SECINNER_ID IS NOT NULL THEN STARTNODE(x).SECINNER_ID WHEN STARTNODE(x).COMPANY_ID IS NOT NULL THEN STARTNODE(x).COMPANY_ID ELSE STARTNODE(x).PERSON_ID END +TYPE(x)+ CASE WHEN ENDNODE(x).SECINNER_ID IS NOT NULL THEN ENDNODE(x).SECINNER_ID WHEN ENDNODE(x).COMPANY_ID IS NOT NULL THEN ENDNODE(x).COMPANY_ID ELSE ENDNODE(x).PERSON_ID END )|s+y ) as pathkey, startNode(R) AS sourceNodeInfo , R AS relationInfo, endNode(R) AS targetNodeInfo \n" +
            "OPTIONAL MATCH (targetNodeInfo)<-[r:INVEST]-()\n" +
            "WITH linenum,pathkey,sourceNodeInfo,relationInfo,targetNodeInfo,CASE WHEN ALL(x IN collect(r)  WHERE EXISTS(x.NUM) and x.NUM <> '0') THEN sum(ToFloat(r.NUM))  ELSE targetNodeInfo.REG_CAPITAL END AS REG_CAPITAL \n" +
            "RETURN  \n" +
            "{COMPANY_ID:sourceNodeInfo.COMPANY_ID,COMPANY_TYPE:sourceNodeInfo.COMPANY_TYPE_LIST,RISK_LIST:sourceNodeInfo.RISK_LIST,REG_CAPITAL:sourceNodeInfo.REG_CAPITAL,COMPANY_NM:sourceNodeInfo.COMPANY_NM,PERSON_NM:sourceNodeInfo.PERSON_NM,SECURITY_NM:sourceNodeInfo.SECURITY_NM,SECURITY_ID:sourceNodeInfo.SECINNER_ID,LABELS:Labels(sourceNodeInfo)} AS  sourceNodeInfo , \n" +
            "{PATH_TYPE:[linenum],TYPE:TYPE(relationInfo)," +
            "INVEST_SHA_RATIO: CASE WHEN relationInfo.SHA_RATIO IS NOT NULL THEN tofloat(relationInfo.SHA_RATIO) WHEN relationInfo.SHA_RATIO IS NULL AND relationInfo.NUM IS NOT NULL AND apoc.cscs.getRegCapital(relationInfo) <> 0 THEN tofloat(relationInfo.NUM)/apoc.cscs.getRegCapital(relationInfo)*100 ELSE 0 END" +
            ",WORK_POSITION:relationInfo.POSITION,SC_RELATION_TYPE:relationInfo.RELATION_TYPE,INVEST_NUM:relationInfo.NUM,PATH_ID:pathkey} AS relationInfo, \n" +
            "{COMPANY_ID:targetNodeInfo.COMPANY_ID,COMPANY_TYPE:targetNodeInfo.COMPANY_TYPE_LIST,RISK_LIST:targetNodeInfo.RISK_LIST,REG_CAPITAL:targetNodeInfo.REG_CAPITAL,COMPANY_NM:targetNodeInfo.COMPANY_NM,PERSON_NM:targetNodeInfo.PERSON_NM,SECURITY_NM:targetNodeInfo.SECURITY_NM,SECURITY_ID:targetNodeInfo.SECINNER_ID,LABELS:Labels(targetNodeInfo)} AS targetNodeInfo \n" +
            ";";

    String getRelationForCompanyPersonQuery = "WITH P LIMIT 20 \n" +
            "WITH collect(P) as PS \n" +
            "UNWIND range(0, SIZE(PS)-1) as pos \n" +
            "UNWIND  relationships(PS[pos]) AS R \n" +
            "WITH toString(pos) as linenum,REDUCE(s=\"\",y IN EXTRACT(x IN RELATIONSHIPS(PS[pos]) | CASE WHEN STARTNODE(x).SECINNER_ID IS NOT NULL THEN STARTNODE(x).SECINNER_ID WHEN STARTNODE(x).COMPANY_ID IS NOT NULL THEN STARTNODE(x).COMPANY_ID ELSE STARTNODE(x).PERSON_ID END +TYPE(x)+ CASE WHEN ENDNODE(x).SECINNER_ID IS NOT NULL THEN ENDNODE(x).SECINNER_ID WHEN ENDNODE(x).COMPANY_ID IS NOT NULL THEN ENDNODE(x).COMPANY_ID ELSE ENDNODE(x).PERSON_ID END )|s+y ) as pathkey, startNode(R) AS sourceNodeInfo , R AS relationInfo, endNode(R) AS targetNodeInfo \n" +
            "OPTIONAL MATCH (targetNodeInfo)<-[r:INVEST]-()\n" +
            "WITH linenum,pathkey,sourceNodeInfo,relationInfo,targetNodeInfo,CASE WHEN ALL(x IN collect(r)  WHERE EXISTS(x.NUM) and x.NUM <> '0') THEN sum(ToFloat(r.NUM))  ELSE targetNodeInfo.REG_CAPITAL END AS REG_CAPITAL \n" +
            "RETURN  \n" +
            "{COMPANY_ID:sourceNodeInfo.COMPANY_ID,COMPANY_TYPE:sourceNodeInfo.COMPANY_TYPE_LIST,RISK_LIST:sourceNodeInfo.RISK_LIST,REG_CAPITAL:sourceNodeInfo.REG_CAPITAL,COMPANY_NM:sourceNodeInfo.COMPANY_NM,PERSON_NM:sourceNodeInfo.PERSON_NM,SECURITY_NM:sourceNodeInfo.SECURITY_NM,SECURITY_ID:sourceNodeInfo.SECINNER_ID,LABELS:Labels(sourceNodeInfo)} AS  sourceNodeInfo , \n" +
            "{PATH_TYPE:[linenum],TYPE:TYPE(relationInfo)," +
            "INVEST_SHA_RATIO: CASE WHEN relationInfo.SHA_RATIO IS NOT NULL THEN tofloat(relationInfo.SHA_RATIO) WHEN relationInfo.SHA_RATIO IS NULL AND relationInfo.NUM IS NOT NULL AND apoc.cscs.getRegCapital(relationInfo) <> 0 THEN tofloat(relationInfo.NUM)/apoc.cscs.getRegCapital(relationInfo)*100 ELSE 0 END" +
            ",WORK_POSITION:relationInfo.POSITION,SC_RELATION_TYPE:relationInfo.RELATION_TYPE,INVEST_NUM:relationInfo.NUM,PATH_ID:pathkey} AS relationInfo, \n" +
            "{COMPANY_ID:targetNodeInfo.COMPANY_ID,COMPANY_TYPE:targetNodeInfo.COMPANY_TYPE_LIST,RISK_LIST:targetNodeInfo.RISK_LIST,REG_CAPITAL:targetNodeInfo.REG_CAPITAL,COMPANY_NM:targetNodeInfo.COMPANY_NM,PERSON_NM:targetNodeInfo.PERSON_NM,SECURITY_NM:targetNodeInfo.SECURITY_NM,SECURITY_ID:targetNodeInfo.SECINNER_ID,LABELS:Labels(targetNodeInfo)} AS targetNodeInfo \n" +
            ";";

    String getCompanyQuery = //"WHERE B:COMPANY OR B:PERSON OR B:SECURITY \n" +
            "UNWIND  relationships(P) AS R \n" +
                    "WITH startNode(R) AS sourceNodeInfo , R AS relationInfo, endNode(R) AS targetNodeInfo \n" +
                    "OPTIONAL MATCH (targetNodeInfo)<-[r:INVEST]-()\n" +
                    "WITH sourceNodeInfo,relationInfo,targetNodeInfo,CASE WHEN ALL(x IN collect(r)  WHERE EXISTS(x.NUM) and x.NUM <> '0') THEN sum(ToFloat(r.NUM))  ELSE targetNodeInfo.REG_CAPITAL END AS REG_CAPITAL \n" +
                    "RETURN \n" +
                    "{COMPANY_ID:sourceNodeInfo.COMPANY_ID,COMPANY_TYPE:sourceNodeInfo.COMPANY_TYPE_LIST,RISK_LIST:sourceNodeInfo.RISK_LIST,REG_CAPITAL:sourceNodeInfo.REG_CAPITAL,COMPANY_NM:sourceNodeInfo.COMPANY_NM,LINK_ID:CASE WHEN 'PERSON' IN LABELS(sourceNodeInfo) THEN targetNodeInfo.COMPANY_NM +\"&&\"+ sourceNodeInfo.PERSON_NM ELSE sourceNodeInfo.COMPANY_NM END,PERSON_NM:sourceNodeInfo.PERSON_NM,SECURITY_NM:sourceNodeInfo.SECURITY_NM,SECURITY_ID:sourceNodeInfo.SECINNER_ID,LABELS:Labels(sourceNodeInfo)} AS  sourceNodeInfo , \n" +
                    "{PATH_TYPE:['1'],TYPE:TYPE(relationInfo)," +
                    "INVEST_SHA_RATIO: CASE WHEN relationInfo.SHA_RATIO IS NOT NULL THEN tofloat(relationInfo.SHA_RATIO) WHEN relationInfo.SHA_RATIO IS NULL AND relationInfo.NUM IS NOT NULL AND apoc.cscs.getRegCapital(relationInfo) <> 0 THEN tofloat(relationInfo.NUM)/apoc.cscs.getRegCapital(relationInfo)*100 ELSE 0 END" +
                    ",WORK_POSITION:relationInfo.POSITION,SC_RELATION_TYPE:relationInfo.RELATION_TYPE,INVEST_NUM:relationInfo.NUM,GUAR_INFO:relationInfo.GUAR_INFO} AS relationInfo,  \n" +
                    "{COMPANY_ID:targetNodeInfo.COMPANY_ID,COMPANY_TYPE:targetNodeInfo.COMPANY_TYPE_LIST,RISK_LIST:targetNodeInfo.RISK_LIST,REG_CAPITAL:targetNodeInfo.REG_CAPITAL,COMPANY_NM:targetNodeInfo.COMPANY_NM,LINK_ID:CASE WHEN 'PERSON' IN LABELS(targetNodeInfo) THEN sourceNodeInfo.COMPANY_NM +\"&&\"+ targetNodeInfo.PERSON_NM ELSE targetNodeInfo.COMPANY_NM END,PERSON_NM:targetNodeInfo.PERSON_NM,SECURITY_NM:targetNodeInfo.SECURITY_NM,SECURITY_ID:targetNodeInfo.SECINNER_ID,LABELS:Labels(targetNodeInfo)} AS targetNodeInfo \n" +
                    ";";
    // @Query("MATCH (A:COMPANY)-[R]-() WHERE A.COMPANY_ID = {companyId} WITH A,R   RETURN A,R;")
    // @Query("MATCH P = (A:COMPANY)-[R]-() WITH [R IN RELS(P)| {s:startNode(R),r:R,e:endNode(R)}] AS RELS_RESULT RETURN RELS_RESULT;")
    // @Query("MATCH P = (A:COMPANY)-[]-() \n" + "UNWIND  RELS(P) AS R \n" + "RETURN startNode(R) AS sourceNodeInfo , R AS relationInfo, endNode(R) AS targetNodeInfo LIMIT 3;")
//    @Query("MATCH P = (A:PERSON{PERSON_NM:'王石'})-[]-() \n" + "UNWIND  RELS(P) AS R \n" + "RETURN startNode(R) AS sourceNodeInfo , R AS relationInfo, endNode(R) AS targetNodeInfo LIMIT 3;")

    @Query("MATCH (C:COMPANY{COMPANY_NM:{companyNm}})-[]-(A:PERSON{PERSON_NM:{personNm}}) MATCH P = (A)-[]-(B) " + typeCondition + getCompanyQuery)
    QueryResultModel getPersonInfoByCompanyNmAndPersonNm(@Param("companyNm") String companyNm, @Param("personNm") String personNm);

    @Query("MATCH P = (A:COMPANY{COMPANY_ID:{companyId}})-[:" + relationType + "]-(B) " + typeCondition + getCompanyQuery)
    QueryResultModel getByCompanyId(@Param("companyId") String companyId);

    @Query("MATCH P = (A:COMPANY{COMPANY_ID:{companyId}})<-[:" + relationTypeIn + "]-(B) " + typeCondition + getCompanyQuery)
    QueryResultModel getSupplierCustomerByCompanyId(@Param("companyId") String companyId);

    @Query("MATCH P = (A:COMPANY{COMPANY_ID:{companyId}})-[:" + relationTypeOut + "]->(B) " + typeCondition + getCompanyQuery)
    QueryResultModel getGuaranteeByCompanyId(@Param("companyId") String companyId);

    @Query("MATCH P = (A:COMPANY{COMPANY_ID:{companyId}})-[:" + relationTypeWithoutManager + "]-(B) " + typeCondition + getCompanyQuery)
    QueryResultModel getByCompanyIdWithoutManager(@Param("companyId") String companyId);

    // @Query("MATCH P = (A:PERSON{PERSON_NM:{personNm}})-[]-() \n" + "UNWIND  RELS(P) AS R \n" + "RETURN startNode(R) AS sourceNodeInfo , R AS relationInfo, endNode(R) AS targetNodeInfo LIMIT 100;")
    // @Query("MATCH P = (A:COMPANY{COMPANY_NM:{personNm}})-[:INVEST]-() \n" + "UNWIND  RELS(P) AS R \n" + "RETURN startNode(R) AS sourceNodeInfo , R AS relationInfo, endNode(R) AS targetNodeInfo ;")
    @Query("MATCH P = (A:COMPANY{COMPANY_NM:{companyNm}})-[:" + relationType + "]-(B) " + typeCondition + getCompanyQuery)
    QueryResultModel getByCompanyNm(@Param("companyNm") String companyNm);

    @Query("MATCH P = (A:COMPANY{COMPANY_NM:{companyNm}})-[:" + relationTypeTwoLayer + "*..2]-(B) " + typeCondition + getCompanyQuery)
    QueryResultModel getTwoLayerGraphByCompanyNm(@Param("companyNm") String companyNm);

    @Query("MATCH P = (A:COMPANY{COMPANY_ID:{companyId}})-[:" + relationTypeTwoLayer + "*..2]-(B) " + typeCondition + getCompanyQuery)
    QueryResultModel getTwoLayerGraphByCompanyId(@Param("companyId") String companyId);

    @Query("MATCH P = (A:COMPANY{COMPANY_NM:{companyNm}})<-[:" + relationTypeIn + "]-(B) " + typeCondition + getCompanyQuery)
    QueryResultModel getSupplierCustomerByCompanyNm(@Param("companyNm") String companyNm);

    @Query("MATCH P = (A:COMPANY{COMPANY_NM:{companyNm}})-[:" + relationTypeOut + "]->(B) " + typeCondition + getCompanyQuery)
    QueryResultModel getGuaranteeByCompanyNm(@Param("companyNm") String companyNm);

    @Query("MATCH P = (A:COMPANY{COMPANY_NM:{companyNm}})-[:" + relationTypeWithoutManager + "]-(B) " + typeCondition + getCompanyQuery)
    QueryResultModel getByCompanyNmWithoutManager(@Param("companyNm") String companyNm);

    @Query("MATCH P = (A:SECURITY{SECINNER_ID:{secinnerId}})-[:" + relationTypeSecurity + "]-(B) " + typeCondition + getCompanyQuery)
    QueryResultModel getBySecurityId(@Param("secinnerId") String secinnerId);

    @Query("MATCH P = (A:COMPANY{COMPANY_NM:{companyNm1}})-[:" + relationTypeRelation + "*..3]-(B:COMPANY{COMPANY_NM:{companyNm2}}) " + getRelationQuery)
    QueryResultModel getCompanyWithCompanyPathByName(@Param("companyNm1") String companyNm1, @Param("companyNm2") String companyNm2);

    @Query("MATCH P = (A:COMPANY{COMPANY_ID:{companyId}})-[:" + relationTypeRelation + "*..3]-(B:COMPANY{COMPANY_NM:{companyNm}}) " + getRelationQuery)
    QueryResultModel getCompanyWithCompanyPathByNameId(@Param("companyId") String companyId, @Param("companyNm") String companyNm);

    @Query("MATCH P = (A:COMPANY{COMPANY_ID:{companyId1}})-[:" + relationTypeRelation + "*..3]-(B:COMPANY{COMPANY_ID:{companyId2}}) " + getRelationQuery)
    QueryResultModel getCompanyWithCompanyPathId(@Param("companyId1") String companyId1, @Param("companyId2") String companyId2);

    @Query("MATCH (A:COMPANY{COMPANY_NM:{companyNm}}) WITH A MATCH P = (A)-[:" + relationTypeRelationForCompanyPerson + "*..2]-(B:PERSON{PERSON_NM:{personnm}}) " + getRelationForCompanyPersonQuery)
    QueryResultModel getCompanyWithPersonPathByNameId(@Param("companyNm") String companyNm, @Param("personnm") String personnm);

    @Query("MATCH P = (A:COMPANY{COMPANY_ID:{companyId}})-[:" + relationTypeRelationForCompanyPerson + "*..2]-(B:PERSON{PERSON_NM:{personnm}}) " + getRelationForCompanyPersonQuery)
    QueryResultModel getCompanyWithPersonPathId(@Param("companyId") String companyId, @Param("personnm") String personnm);

    @Query("MATCH P = (A:PERSON{PERSON_NM:{personnm1}})-[:" + relationTypeRelation + "*..3]-(B:PERSON{PERSON_NM:{personnm2}}) " + getRelationQuery)
    QueryResultModel getPeronWithPersonPathId(@Param("personnm1") String personnm1, @Param("personnm2") String personnm2);


    //三跳全路径找不到的情况下，查询七跳最短路径
    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_NM:{companyNm1}})-[:" + relationTypeRelation + "*..7]-(B:COMPANY{COMPANY_NM:{companyNm2}})) " + getRelationQuery)
    QueryResultModel getCompanyWithCompanyShortestPathByName(@Param("companyNm1") String companyNm1, @Param("companyNm2") String companyNm2);

    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_ID:{companyId}})-[:" + relationTypeRelation + "*..7]-(B:COMPANY{COMPANY_NM:{companyNm}})) " + getRelationQuery)
    QueryResultModel getCompanyWithCompanyShortestPathByNameId(@Param("companyId") String companyId, @Param("companyNm") String companyNm);

    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_ID:{companyId1}})-[:" + relationTypeRelation + "*..7]-(B:COMPANY{COMPANY_ID:{companyId2}})) " + getRelationQuery)
    QueryResultModel getCompanyWithCompanyShortestPathId(@Param("companyId1") String companyId1, @Param("companyId2") String companyId2);

    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_NM:{companyNm}})-[:" + relationTypeRelation + "*..7]-(B:PERSON{PERSON_NM:{personnm}})) " + getRelationQuery)
    QueryResultModel getCompanyWithPersonShortestPathByNameId(@Param("companyNm") String companyNm, @Param("personnm") String personnm);

    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_ID:{companyId}})-[:" + relationTypeRelation + "*..7]-(B:PERSON{PERSON_NM:{personnm}})) " + getRelationQuery)
    QueryResultModel getCompanyWithPersonShortestPathId(@Param("companyId") String companyId, @Param("personnm") String personnm);

    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_ID:{personnm1}})-[:" + relationTypeRelation + "*..7]-(B:PERSON{PERSON_NM:{personnm2}})) " + getRelationQuery)
    QueryResultModel getPeronWithPersonShortestPathId(@Param("personnm1") String personnm1, @Param("personnm2") String personnm2);


    //疑似关系最短路径
    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_NM:{companyNm1}})-[:" + relationTypeRelationWithSuspect + "*..7]-(B:COMPANY{COMPANY_NM:{companyNm2}})) " + getRelationQueryWithSuspect)
    QueryResultModel getSuspectrelationCompanyWithCompanyShortestPathByName(@Param("companyNm1") String companyNm1, @Param("companyNm2") String companyNm2, @Param("layernum") String layernum);

    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_NM:{companyNm1}})-[:" + relationTypeRelationWithSuspect + "*..3]-(B:COMPANY{COMPANY_NM:{companyNm2}})) " + getRelationQueryWithSuspect)
    QueryResultModel getThreeLayerSuspectrelationCompanyWithCompanyShortestPathByName(@Param("companyNm1") String companyNm1, @Param("companyNm2") String companyNm2, @Param("layernum") String layernum);


    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_ID:{companyId}})-[:" + relationTypeRelationWithSuspect + "*..7]-(B:COMPANY{COMPANY_NM:{companyNm}})) " + getRelationQueryWithSuspect)
    QueryResultModel getSuspectrelationCompanyWithCompanyShortestPathByNameId(@Param("companyId") String companyId, @Param("companyNm") String companyNm, @Param("layernum") String layernum);

    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_ID:{companyId}})-[:" + relationTypeRelationWithSuspect + "*..3]-(B:COMPANY{COMPANY_NM:{companyNm}})) " + getRelationQueryWithSuspect)
    QueryResultModel getThreeLayerSuspectrelationCompanyWithCompanyShortestPathByNameId(@Param("companyId") String companyId, @Param("companyNm") String companyNm, @Param("layernum") String layernum);

    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_ID:{companyId1}})-[:" + relationTypeRelationWithSuspect + "*..7]-(B:COMPANY{COMPANY_ID:{companyId2}})) " + getRelationQueryWithSuspect)
    QueryResultModel getSuspectrelationCompanyWithCompanyShortestPathId(@Param("companyId1") String companyId1, @Param("companyId2") String companyId2, @Param("layernum") String layernum);

    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_ID:{companyId1}})-[:" + relationTypeRelationWithSuspect + "*..3]-(B:COMPANY{COMPANY_ID:{companyId2}})) " + getRelationQueryWithSuspect)
    QueryResultModel getThreeLayerSuspectrelationCompanyWithCompanyShortestPathId(@Param("companyId1") String companyId1, @Param("companyId2") String companyId2, @Param("layernum") String layernum);

    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_NM:{companyNm}})-[:" + relationTypeRelationWithSuspect + "*..7]-(B:PERSON{PERSON_NM:{personnm}})) " + getRelationQueryWithSuspect)
    QueryResultModel getSuspectrelationCompanyWithPersonShortestPathByNameId(@Param("companyNm") String companyNm, @Param("personnm") String personnm, @Param("layernum") String layernum);

    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_NM:{companyNm}})-[:" + relationTypeRelationWithSuspect + "*..3]-(B:PERSON{PERSON_NM:{personnm}})) " + getRelationQueryWithSuspect)
    QueryResultModel getThreeLayerSuspectrelationCompanyWithPersonShortestPathByNameId(@Param("companyNm") String companyNm, @Param("personnm") String personnm, @Param("layernum") String layernum);

    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_ID:{companyId}})-[:" + relationTypeRelationWithSuspect + "*..7]-(B:PERSON{PERSON_NM:{personnm}})) " + getRelationQueryWithSuspect)
    QueryResultModel getSuspectrelationCompanyWithPersonShortestPathId(@Param("companyId") String companyId, @Param("personnm") String personnm, @Param("layernum") String layernum);

    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_ID:{companyId}})-[:" + relationTypeRelationWithSuspect + "*..3]-(B:PERSON{PERSON_NM:{personnm}})) " + getRelationQueryWithSuspect)
    QueryResultModel getThreeLayerSuspectrelationCompanyWithPersonShortestPathId(@Param("companyId") String companyId, @Param("personnm") String personnm, @Param("layernum") String layernum);

    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_ID:{personnm1}})-[:" + relationTypeRelationWithSuspect + "*..7]-(B:PERSON{PERSON_NM:{personnm2}})) " + getRelationQueryWithSuspect)
    QueryResultModel getSuspectrelationPeronWithPersonShortestPathId(@Param("personnm1") String personnm1, @Param("personnm2") String personnm2, @Param("layernum") String layernum);

    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_ID:{personnm1}})-[:" + relationTypeRelationWithSuspect + "*..3]-(B:PERSON{PERSON_NM:{personnm2}})) " + getRelationQueryWithSuspect)
    QueryResultModel getThreeLayerSuspectrelationPeronWithPersonShortestPathId(@Param("personnm1") String personnm1, @Param("personnm2") String personnm2, @Param("layernum") String layernum);

    String getCompanyBasicinfo = "WITH A LIMIT 1 " +
            "RETURN " +
            "{" +
            "COMPANY_TYPE_LIST:A.COMPANY_TYPE_LIST," +
            "COMPANY_TYPE:A.COMPANY_TYPE," +
            "RISK_LIST:A.RISK_LIST," +
            "REG_CAPITAL:A.REG_CAPITAL," +
            "COMPANY_NM:A.COMPANY_NM," +
            "COMPANY_ID:A.COMPANY_ID," +
            "COMPANY_STATUS:A.STATUS," +
            "SECURITY_NM:A.SECURITY_NM," +
            "SECURITY_ID:A.SECINNER_ID," +
            "PERSON_NM:A.PERSON_NM," +
            "PERSON_ID:A.PERSON_ID," +
            "REG_CAPITAL:A.REG_CAPITAL," +
            "REG_ADDR:A.REG_ADDR," +
            "LEG_PRESENT:A.LEG_PRESENT," +
            "LABELS:Labels(A)} AS BasicInfo ;";

    @Query("MATCH (A:COMPANY{COMPANY_NM:{companyNm}}) " + getCompanyBasicinfo)
    QueryResultModel getCompanyBasicInfoByCompanyNm(@Param("companyNm") String companyNm);

    @Query("MATCH (A:COMPANY{COMPANY_ID:{companyId}}) " + getCompanyBasicinfo)
    QueryResultModel getCompanyBasicInfoByCompanyId(@Param("companyId") String companyId);

    @Query("MATCH (A:SECURITY{SECINNER_ID:{secinnerId}}) " + getCompanyBasicinfo)
    QueryResultModel getSecurityBasicInfoBySecurityId(@Param("secinnerId") String secinnerId);

    @Query("MATCH (C:COMPANY{COMPANY_NM:{companyNm}})-[]-(A:PERSON{PERSON_NM:{personNm}}) " + getCompanyBasicinfo)
    QueryResultModel getPersonBasicInfoByCompanyNmAndPersonNm(@Param("companyNm") String companyNm, @Param("personNm") String personNm);

    @Query("MATCH (A:COMPANY) WHERE A.COMPANY_ID = {companyId} WITH A LIMIT 1  RETURN A;")
    QueryResultModel getByCompanyId2(@Param("companyId") String companyId);

    @Query("MATCH (A:COMPANY) WHERE A.COMPANY_ID = {companyId} RETURN A.COMPANY_NM LIMIT 1;")
    String getCompanyNmByCompanyId(@Param("companyId") String companyId);

    //关联预警
    @Query("MATCH (self:COMPANY)<-[R:CONTROLLER]-(c:COMPANY) WHERE R.RELATION_TYPE='控股股东' AND c.WARNING_NUM>0 AND self.COMPANY_ID IN SPLIT({company_id},',') RETURN  {COMPANY_ID:self.COMPANY_ID} AS cid, {COMPANY_ID:c.COMPANY_ID,WARNING_NUM:c.WARNING_NUM} as c UNION MATCH (self:COMPANY)-[R:GUARANTEE]->(c:COMPANY) WHERE c.WARNING_NUM>0 AND self.COMPANY_ID IN SPLIT({company_id},',') RETURN  {COMPANY_ID:self.COMPANY_ID} AS cid, {COMPANY_ID:c.COMPANY_ID,WARNING_NUM:c.WARNING_NUM} as c UNION MATCH (self:COMPANY)-[R:CONTROLLER]->(c:COMPANY) WHERE R.RELATION_TYPE='控股股东' AND c.warning_num>0 AND self.COMPANY_ID in SPLIT({company_id},',') return  {COMPANY_ID:self.COMPANY_ID} AS cid, {COMPANY_ID:c.COMPANY_ID,WARNING_NUM:c.WARNING_NUM} as c UNION match (self:COMPANY)-[R:CUSTOMER]->(c:COMPANY) WHERE c.WARNING_NUM>0 AND self.COMPANY_ID IN SPLIT({company_id},',') RETURN {COMPANY_ID:self.COMPANY_ID} AS cid, {COMPANY_ID:c.COMPANY_ID,WARNING_NUM:c.WARNING_NUM} as c")
    QueryResultModel getHighRelevanceCompany(@Param("company_id") String company_id);//@Param("company_id") String company_id

    @Query("MATCH (self:COMPANY)<-[R:INVEST]-(c:COMPANY) WHERE  NOT (self:COMPANY)<-[:CONTROLLER]-(c:COMPANY) and c.WARNING_NUM>0  AND self.COMPANY_ID IN SPLIT({company_id},',') RETURN  {COMPANY_ID:self.COMPANY_ID} AS cid, {COMPANY_ID:c.COMPANY_ID,WARNING_NUM:c.WARNING_NUM} as c UNION MATCH (self:COMPANY)-[R:INVEST]->(c:COMPANY) WHERE NOT (self:COMPANY)-[:CONTROLLER]->(c:COMPANY) AND c.WARNING_NUM>0  AND self.COMPANY_ID IN SPLIT({company_id},',') RETURN  {COMPANY_ID:self.COMPANY_ID} AS cid, {COMPANY_ID:c.COMPANY_ID,WARNING_NUM:c.WARNING_NUM} as c UNION MATCH (self:COMPANY)<-[R:GUARANTEE]-(c:COMPANY) WHERE c.WARNING_NUM>0  AND self.COMPANY_ID IN SPLIT({company_id},',') RETURN  {COMPANY_ID:self.COMPANY_ID} AS cid, {COMPANY_ID:c.COMPANY_ID,WARNING_NUM:c.WARNING_NUM} as c UNION MATCH (self:COMPANY)<-[R:WORK]-(p:PERSON) where R.POSITION='法定代表人'  AND self.COMPANY_ID IN SPLIT({company_id},',') WITH self,p MATCH (p)-[S:INVEST]->(c:COMPANY) WHERE c.WARNING_NUM>0 RETURN  {COMPANY_ID:self.COMPANY_ID} AS cid, {COMPANY_ID:c.COMPANY_ID,WARNING_NUM:c.WARNING_NUM} as c UNION MATCH (self:COMPANY)-[W1:WORK]-(p:PERSON)- [W2:WORK]-(c:COMPANY) WHERE (W1.POSITION='法定代表人' OR W1.POSITION='董事长' OR W1.POSITION='执行董事' ) AND (W2.POSITION='法定代表人' OR W2.POSITION='董事长' OR W2.POSITION='执行董事' ) AND c.COMPANY_ID<>self.COMPANY_ID AND c.WARNING_NUM>0  AND self.COMPANY_ID IN SPLIT({company_id},',') RETURN  {COMPANY_ID:self.COMPANY_ID} AS cid, {COMPANY_ID:c.COMPANY_ID,WARNING_NUM:c.WARNING_NUM} as c  UNION MATCH (self:COMPANY)<-[MS1:CONTROLLER]-(p:PERSON) WHERE MS1.RELATION_TYPE='实际控制人' AND self.COMPANY_ID IN SPLIT({company_id},',') WITH self,p MATCH (c:COMPANY)<-[MS2:CONTROLLER]-(p:PERSON) WHERE MS2.RELATION_TYPE='实际控制人' AND c.COMPANY_ID<>self.COMPANY_ID and c.WARNING_NUM>0 RETURN {COMPANY_ID:self.COMPANY_ID} AS cid, {COMPANY_ID:c.COMPANY_ID,WARNING_NUM:c.WARNING_NUM} as c")
    QueryResultModel getMidRelevanceCompany(@Param("company_id") String company_id);//@Param("company_id") String company_id

    @Query("MATCH (self:COMPANY)-[re:INVEST|WORK|CUSTOMER|SUPPLIER|GUARANTEE*..2]-(c:COMPANY) WHERE c.WARNING_NUM>25  AND self.COMPANY_ID IN SPLIT({company_id},',') RETURN DISTINCT {COMPANY_ID:self.COMPANY_ID} AS cid, {COMPANY_ID:c.COMPANY_ID,WARNING_NUM:c.WARNING_NUM} as c ORDER BY c.WARNING_NUM DESC")
//limit 30
    QueryResultModel getLowRelevanceCompany(@Param("company_id") String company_id);

    @Query("MATCH (c:COMPANY) WHERE c.WARNING_NUM>0  AND c.COMPANY_ID IN SPLIT({company_id},',') RETURN {COMPANY_ID:c.COMPANY_ID} AS cid, {COMPANY_ID:c.COMPANY_ID,WARNING_NUM:c.WARNING_NUM} as c")
    QueryResultModel getThisCompany(@Param("company_id") String company_id);


    //缩略图
    @Query("MATCH (A1)-[S:INVEST]->(C:COMPANY{COMPANY_NM:{company_name}})  WHERE NOT S.IS_DEL='1' OR NOT EXISTS(S.IS_DEL)     WITH COUNT(DISTINCT A1) AS 股东 RETURN 股东;")
    List<Map<String, Object>> getGudongCount(@Param("company_name") String company_name);

    @Query("MATCH (A1)-[S:WORK]->(C:COMPANY{COMPANY_NM:{company_name}})  WHERE NOT S.IS_DEL='1' OR NOT EXISTS(S.IS_DEL)      WITH COUNT(DISTINCT A1) AS 高管 RETURN 高管;")
    List<Map<String, Object>> getGaoguanCount(@Param("company_name") String company_name);

    @Query("MATCH (A1)<-[S:INVEST]-(C:COMPANY{COMPANY_NM:{company_name}})  WHERE NOT S.IS_DEL='1' OR NOT EXISTS(S.IS_DEL)    WITH COUNT(DISTINCT A1) AS 对外投资 RETURN 对外投资;")
    List<Map<String, Object>> getTouziCount(@Param("company_name") String company_name);

    @Query("MATCH (A1)<-[S:GUARANTEE]-(C:COMPANY{COMPANY_NM:{company_name}})  WHERE NOT S.IS_DEL='1' OR NOT EXISTS(S.IS_DEL)      WITH COUNT(DISTINCT A1) AS 对外担保 RETURN 对外担保;")
    List<Map<String, Object>> getDanbaoCount(@Param("company_name") String company_name);

    @Query("MATCH (C:COMPANY) WHERE C.COMPANY_NM={company_name}   RETURN C.COMPANY_NM;")
    List<Map<String, Object>> getByCompanyName(@Param("company_name") String company_name);


    //股东查询
    @Query("MATCH (c:COMPANY)<-[r:INVEST]-(d) WHERE c.COMPANY_ID = {company_id}  RETURN {NODE_TYPE:CASE WHEN 'COMPANY' in LABELS(d) THEN '1' WHEN 'PERSON' in LABELS(d) THEN  '2' ELSE '3' END,ID:CASE WHEN d.COMPANY_ID is not null THEN d.COMPANY_ID WHEN d.PERSON_ID is not null THEN d.PERSON_ID ELSE d.SECINNER_ID END,NAME:CASE WHEN d.COMPANY_NM is not null THEN d.COMPANY_NM WHEN d.PERSON_NM is not null THEN d.PERSON_NM ELSE d.SECURITY_NM END,REG_CAPITAL:d.REG_CAPITAL,SHA_RATIO: CASE WHEN r.SHA_RATIO IS NOT NULL THEN tofloat(r.SHA_RATIO)*0.01 WHEN r.SHA_RATIO IS NULL AND r.NUM IS NOT NULL AND apoc.cscs.getRegCapital(r) <> 0 THEN tofloat(r.NUM)/apoc.cscs.getRegCapital(r) ELSE 0 END} AS resultinfo")
    QueryResultModel getCompanyShareholder(@Param("company_id") String company_id);

    //疑似实际控制人图谱
    @Query("MATCH (C:COMPANY{COMPANY_ID:{company_id}})<-[R:INVEST]-(P) WITH C,P AS CC1 ORDER BY tofloat(coalesce(R.SHA_RATIO, 0)),tofloat(coalesce(R.NUM, 0)) DESC LIMIT 2  MATCH (C)<-[:INVEST]-(CC1)<-[:INVEST*0..4]-(P) WHERE P:PERSON OR (P)-[:CONTROLLER{RELATION_TYPE:'实际控制人'}]->(:COMPANY) OR NOT (P)<-[:INVEST]-() WITH DISTINCT C,P MATCH path = (P)-[:INVEST*..5]->(C) WITH C,P,COLLECT([p in rels(path)|CASE WHEN p.SHA_RATIO IS NOT NULL THEN tofloat(p.SHA_RATIO)*0.01 WHEN p.SHA_RATIO IS NULL AND p.NUM IS NOT NULL AND apoc.cscs.getRegCapital(p) <> 0 THEN tofloat(p.NUM)/apoc.cscs.getRegCapital(p) ELSE 0 END]) AS paths,COLLECT([p in rels(path)|startNode(p).COMPANY_NM]) AS pathsNm CALL apoc.cscs.filterPaths(paths) yield path WITH C,P,COLLECT(path) AS paths,pathsNm UNWIND  RANGE(0,LENGTH(paths)-1) AS pathsindex  UNWIND RANGE(0,LENGTH(paths[pathsindex])-1) as valuesIndex  WITH C,P, pathsindex,paths[pathsindex] AS values,apoc.agg.product(paths[pathsindex][valuesIndex]) as p ,paths as pathValue,pathsNm WITH C,P,pathValue,COLLECT(p) AS pValues,pathsNm WITH C,P, CASE WHEN 'COMPANY' IN LABELS(P) THEN P.COMPANY_NM ELSE P.PERSON_NM  END AS CONTROLLER_NM ,pathValue,pValues,apoc.coll.sum(pValues) AS totalValue,pathsNm with C,collect({CONTROLLER_NM:CONTROLLER_NM ,totalValue:toString(totalValue)}) as resultlist CALL apoc.cscs.chooseActualController(resultlist) yield controllernm WITH C,controllernm MATCH CP = (P)-[:INVEST|CONTROLLER*..5]->(C) where P.COMPANY_NM = controllernm or P.PERSON_NM = controllernm with CP as P " + getCompanyQuery)
    QueryResultModel getSuspActControllerByCompanyId(@Param("company_id") String company_id);

    @Query("MATCH (C:COMPANY{COMPANY_ID:{company_id}})<-[:CONTROLLER{RELATION_TYPE:'实际控制人'}]-(P) WITH C,CASE WHEN 'COMPANY' IN LABELS(P) THEN P.COMPANY_NM ELSE P.PERSON_NM END as controllernm MATCH CP = (P)-[:INVEST|CONTROLLER*..5]->(C) where P.COMPANY_NM = controllernm or P.PERSON_NM = controllernm with CP as P " + getCompanyQuery)
    QueryResultModel getActControllerByCompanyId(@Param("company_id") String company_id);

    //判断是否是公开企业，是的话直接取实际控制人，不是的话取疑似实际控制人
    @Query("MATCH (A:COMPANY{COMPANY_ID:{company_id}}) WHERE EXISTS(A.COMPANY_TYPE_LIST) AND ANY(ELEM IN ['A股','B股','H股','三板股'] WHERE ELEM IN A.COMPANY_TYPE_LIST ) RETURN 1 LIMIT 1")
    QueryResultModel JudgeCompanyTpye(@Param("company_id") String company_id);

    //疑似实际控制人名称（展台字段展示接口）
    @Query("MATCH (C:COMPANY{COMPANY_ID:{company_id}})<-[R:INVEST]-(P) WITH C,P AS CC1 ORDER BY tofloat(coalesce(R.SHA_RATIO, 0)),tofloat(coalesce(R.NUM, 0)) DESC LIMIT 2  MATCH (C)<-[:INVEST]-(CC1)<-[:INVEST*0..4]-(P) WHERE P:PERSON OR (P)-[:CONTROLLER{RELATION_TYPE:'实际控制人'}]->(:COMPANY) OR NOT (P)<-[:INVEST]-() WITH DISTINCT C,P MATCH path = (P)-[:INVEST*..5]->(C) WITH C,P,COLLECT([p in rels(path)|CASE WHEN p.SHA_RATIO IS NOT NULL THEN tofloat(p.SHA_RATIO)*0.01 WHEN p.SHA_RATIO IS NULL AND p.NUM IS NOT NULL AND apoc.cscs.getRegCapital(p) <> 0 THEN tofloat(p.NUM)/apoc.cscs.getRegCapital(p) ELSE 0 END]) AS paths,COLLECT([p in rels(path)|startNode(p).COMPANY_NM]) AS pathsNm CALL apoc.cscs.filterPaths(paths) yield path WITH C,P,COLLECT(path) AS paths,pathsNm UNWIND  RANGE(0,LENGTH(paths)-1) AS pathsindex  UNWIND RANGE(0,LENGTH(paths[pathsindex])-1) as valuesIndex  WITH C,P, pathsindex,paths[pathsindex] AS values,apoc.agg.product(paths[pathsindex][valuesIndex]) as p ,paths as pathValue,pathsNm WITH C,P,pathValue,COLLECT(p) AS pValues,pathsNm WITH C,P, CASE WHEN 'COMPANY' IN LABELS(P) THEN P.COMPANY_NM ELSE P.PERSON_NM  END AS CONTROLLER_NM ,pathValue,pValues,apoc.coll.sum(pValues) AS totalValue,pathsNm with C,collect({CONTROLLER_NM:CONTROLLER_NM ,totalValue:toString(totalValue)}) as resultlist CALL apoc.cscs.chooseActualController(resultlist) yield controllernm return {controllernm:controllernm} as resultinfo ")
    QueryResultModel getSuspActControllerNameByCompanyId(@Param("company_id") String company_id);

    //上市企业实际控制人
    @Query("MATCH (C:COMPANY{COMPANY_ID:{company_id}})<-[:CONTROLLER{RELATION_TYPE:'实际控制人'}]-(P) RETURN {controllernm:CASE WHEN 'COMPANY' IN LABELS(P) THEN P.COMPANY_NM ELSE P.PERSON_NM END} as resultinfo ")
    QueryResultModel getActControllerNameByCompanyId(@Param("company_id") String company_id);

    //图谱导出execl数据查询Cypher
    //企业名称及企业类型
    @Query("MATCH (C:COMPANY) WHERE C.COMPANY_ID = {company_id} RETURN {COMPANY_NM:C.COMPANY_ID,COMPANY_NM:C.COMPANY_NM,COMPANY_TYPE:CASE WHEN EXISTS(C.COMPANY_TYPE_LIST) AND ANY(ELEM IN ['A股','B股','H股','三板股'] WHERE ELEM IN C.COMPANY_TYPE_LIST) THEN 1 ELSE 0 END} AS RESULT")
    QueryResultModel getCompanyInfo(@Param("company_id") String company_id);

    //股东一层及二层股东/对外投资
    @Query("MATCH (C:COMPANY)<-[R:INVEST]-(D) WHERE C.COMPANY_ID = {company_id}\n" + onelayerShaResult)
    QueryResultModel getCompanyShaInfo(@Param("company_id") String company_id);

    @Query("MATCH (C:COMPANY)<-[R:INVEST]-(D)<-[R2:INVEST]-(E) WHERE C.COMPANY_ID = {company_id}\n" + twolayerShaResult)
    QueryResultModel getCompanyShaShaInfo(@Param("company_id") String company_id);

    @Query("MATCH (C:COMPANY)<-[R:INVEST]-(D)-[R2:INVEST]->(E) WHERE C.COMPANY_ID = {company_id}\n" + twolayerShaResult)
    QueryResultModel getCompanyShaInvestInfo(@Param("company_id") String company_id);

    //对外投资一层
    @Query("MATCH (C:COMPANY)-[R:INVEST]->(D) WHERE C.COMPANY_ID = {company_id}\n" + onelayerShaResult)
    QueryResultModel getCompanyInvestInfo(@Param("company_id") String company_id);

    //一层高管，高管二层暂无
    @Query("MATCH (C:COMPANY)<-[R:WORK]-(D) WHERE C.COMPANY_ID = {company_id}\n WITH C.COMPANY_NM AS COMPANY_NM,apoc.cscs.getName(D) AS ONELAYERNAME,COLLECT(R.POSITION) AS POSITION RETURN {ONELAYERNAME:ONELAYERNAME,POSTION:substring(REDUCE(s = \"\", x IN POSITION | s + x + ','),0,SIZE(REDUCE(s = \"\", x IN POSITION | s + x + ','))-1)} AS RESULT")
//COMPANY_NM:COMPANY_NM,
    QueryResultModel getCompanyWorkInfo(@Param("company_id") String company_id);

    //一层供应商及二层股东/对外投资
    @Query("MATCH (C:COMPANY)<-[R:SUPPLIER]-(D) WHERE C.COMPANY_ID = {company_id}" + onelayerCustSuppSHAResult)
    QueryResultModel getCompanySupplierInfo(@Param("company_id") String company_id);

    @Query("MATCH (C:COMPANY)<-[R:SUPPLIER]-(D)<-[R2:INVEST]-(E) WHERE C.COMPANY_ID = {company_id}" + twolayerShaResult)
    QueryResultModel getCompanySupplierShaInfo(@Param("company_id") String company_id);

    @Query("MATCH (C:COMPANY)<-[R:SUPPLIER]-(D)-[R2:INVEST]->(E) WHERE C.COMPANY_ID = {company_id}" + twolayerShaResult)
    QueryResultModel getCompanySupplierInvestInfo(@Param("company_id") String company_id);

    @Query("MATCH (C:COMPANY)<-[R:SUPPLIER]-(D)<-[R2:WORK]-(E) WHERE C.COMPANY_ID = {company_id}" + onelayerCustSuppWORKResult)
    QueryResultModel getCompanySupplierWorkInfo(@Param("company_id") String company_id);

    //一层客户及二层股东/对外投资
    @Query("MATCH (C:COMPANY)<-[R:CUSTOMER]-(D) WHERE C.COMPANY_ID = {company_id}" + onelayerCustSuppSHAResult)
    QueryResultModel getCompanyCustomerInfo(@Param("company_id") String company_id);

    @Query("MATCH (C:COMPANY)<-[R:CUSTOMER]-(D)<-[R2:INVEST]-(E) WHERE C.COMPANY_ID = {company_id}" + twolayerShaResult)
    QueryResultModel getCompanyCustomerShaInfo(@Param("company_id") String company_id);

    @Query("MATCH (C:COMPANY)<-[R:CUSTOMER]-(D)-[R2:INVEST]->(E) WHERE C.COMPANY_ID = {company_id}" + twolayerShaResult)
    QueryResultModel getCompanyCustomerInvestInfo(@Param("company_id") String company_id);

    @Query("MATCH (C:COMPANY)<-[R:CUSTOMER]-(D)<-[R2:WORK]-(E) WHERE C.COMPANY_ID = {company_id}" + onelayerCustSuppWORKResult)
    QueryResultModel getCompanyCustomerWorkInfo(@Param("company_id") String company_id);

    String onelayerShaResult = "WITH C.COMPANY_NM AS COMPANY_NM,apoc.cscs.getName(D) AS ONELAYERNAME,CASE WHEN R.SHA_RATIO IS NOT NULL THEN tofloat(R.SHA_RATIO)*0.01 WHEN R.SHA_RATIO IS NULL AND R.NUM IS NOT NULL AND apoc.cscs.getRegCapital(R) <> 0 THEN tofloat(R.NUM)/apoc.cscs.getRegCapital(R) ELSE 0 END AS SHARATIO RETURN {ONELAYERNAME:ONELAYERNAME,SHARATIO:apoc.number.format(SHARATIO*100, '##0.00')+'%'} AS RESULT";//COMPANY_NM:COMPANY_NM,
    String twolayerShaResult = "WITH C.COMPANY_NM AS COMPANY_NM,apoc.cscs.getName(D) AS ONELAYERNAME,apoc.cscs.getName(E) AS TWOLAYERNAME,CASE WHEN R2.SHA_RATIO IS NOT NULL THEN tofloat(R2.SHA_RATIO)*0.01 WHEN R2.SHA_RATIO IS NULL AND R2.NUM IS NOT NULL AND apoc.cscs.getRegCapital(R2) <> 0 THEN tofloat(R2.NUM)/apoc.cscs.getRegCapital(R2) ELSE 0 END AS SHARATIO RETURN {ONELAYERNAME:ONELAYERNAME,TWOLAYERNAME:TWOLAYERNAME,SHARATIO:apoc.number.format(SHARATIO*100, '##0.00')+'%'} AS RESULT";//COMPANY_NM:COMPANY_NM,
    String onelayerCustSuppSHAResult = "WITH C.COMPANY_NM AS COMPANY_NM,apoc.cscs.getName(D) AS ONELAYERNAME,R.RPT_DT AS RPT_DT,R.AMT AS AMT RETURN {ONELAYERNAME:ONELAYERNAME,RPT_DT:RPT_DT,AMT:AMT} AS RESULT";//COMPANY_NM:COMPANY_NM,
    String onelayerCustSuppWORKResult = "WITH C.COMPANY_NM AS COMPANY_NM,apoc.cscs.getName(D) AS ONELAYERNAME,apoc.cscs.getName(E) AS TWOLAYERNAME,COLLECT(R2.POSITION) AS POSITION RETURN {ONELAYERNAME:ONELAYERNAME,TWOLAYERNAME:TWOLAYERNAME,POSTION:substring(REDUCE(s = \"\", x IN POSITION | s + x + ','),0,SIZE(REDUCE(s = \"\", x IN POSITION | s + x + ','))-1)} AS RESULT";

}