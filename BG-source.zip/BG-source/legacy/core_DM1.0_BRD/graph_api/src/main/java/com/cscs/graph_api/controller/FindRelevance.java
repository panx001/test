package com.cscs.graph_api.controller;

/**
 * Created by zjr on 2017/4/12.
 */

import com.cscs.graph_api.repositories.ObjectRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.neo4j.ogm.response.model.QueryResultModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;


@CrossOrigin
@RestController
@RequestMapping(value = "/chart/FindRelevance")
public class FindRelevance {
    private static Logger logger = LogManager.getLogger(FindRelevance.class);
    @Autowired
    ObjectRepository objectRepository;

    @RequestMapping(value = "/getAllRelevanceCompanyPost", method = RequestMethod.POST)
    private Map getAllRelevanceCompanyPost(@RequestBody String companyidlist) {
        Map result = new LinkedHashMap();
        String[] comtemp = companyidlist.split("=");
        String companyid = comtemp[1].replace("%2C", ",").toString();
        Map thisresult = getThisCompany(companyid);
        Map highresult = getHighRelevanceCompany(companyid);
        Map midresult = getMidRelevanceCompany(companyid);
        Map lowresult = getLowRelevanceCompany(companyid);

        logger.debug("----warning----");

        for (Object highentry : highresult.entrySet()) {
            Map.Entry<String, Map<String, String>> highentrymap = (Map.Entry<String, Map<String, String>>) highentry;
            try {
                Map tempmidmap = (Map) midresult.get(highentrymap.getKey());
                for (Map.Entry<String, String> temphighmap : highentrymap.getValue().entrySet()) {
                    if (tempmidmap != null) {
                        tempmidmap.remove(temphighmap.getKey());
                    }
                }
                if (tempmidmap != null) {
                    if (tempmidmap.size() != 0) {
                        midresult.put(highentrymap.getKey(), tempmidmap);
                    } else {
                        midresult.remove(highentrymap.getKey());
                    }
                }
            } catch (Exception e) {
            }
        }
        for (Object highentry : highresult.entrySet()) {
            Map.Entry<String, Map<String, String>> highentrymap = (Map.Entry<String, Map<String, String>>) highentry;
            try {
                Map templowmap = (Map) lowresult.get(highentrymap.getKey());
                for (Map.Entry<String, String> temphighmap : highentrymap.getValue().entrySet()) {
                    if (templowmap != null) {
                        templowmap.remove(temphighmap.getKey());
                    }
                }
                if (templowmap != null) {
                    if (templowmap.size() != 0) {
                        lowresult.put(highentrymap.getKey(), templowmap);
                    } else {
                        lowresult.remove(highentrymap.getKey());
                    }
                }

            } catch (Exception e) {
            }
        }
        for (Object midentry : midresult.entrySet()) {
            Map.Entry<String, Map<String, String>> midentrymap = (Map.Entry<String, Map<String, String>>) midentry;
            Map templowmap = (Map) lowresult.get(midentrymap.getKey());
            for (Map.Entry<String, String> tempmidmap : midentrymap.getValue().entrySet()) {
                if (templowmap != null) {
                    templowmap.remove(tempmidmap.getKey());
                }
            }
            if (templowmap != null) {
                if (templowmap.size() != 0) {
                    lowresult.put(midentrymap.getKey(), templowmap);
                } else {
                    lowresult.remove(midentrymap.getKey());
                }
            }
        }
        for (Object thisentry : thisresult.entrySet()) {
            Map.Entry<String, Map<String, String>> thisentrymap = (Map.Entry<String, Map<String, String>>) thisentry;
            Map templowmap = (Map) lowresult.get(thisentrymap.getKey());
            for (Map.Entry<String, String> tempthismap : thisentrymap.getValue().entrySet()) {
                if (templowmap != null) {
                    templowmap.remove(tempthismap.getKey());
                }
            }
            if (templowmap != null) {
                if (templowmap.size() != 0) {
                    lowresult.put(thisentrymap.getKey(), templowmap);
                } else {
                    lowresult.remove(thisentrymap.getKey());
                }
            }
        }
        for (Object thisentry : thisresult.entrySet()) {
            Map.Entry<String, Map<String, String>> thisentrymap = (Map.Entry<String, Map<String, String>>) thisentry;
            Map tempmidmap = (Map) midresult.get(thisentrymap.getKey());
            for (Map.Entry<String, String> tempthismap : thisentrymap.getValue().entrySet()) {
                if (tempmidmap != null) {
                    tempmidmap.remove(tempthismap.getKey());
                }
            }
            if (tempmidmap != null) {
                if (tempmidmap.size() != 0) {
                    midresult.put(thisentrymap.getKey(), tempmidmap);
                } else {
                    midresult.remove(thisentrymap.getKey());
                }
            }
        }

        for (Object highentry : highresult.entrySet()) {
            Map.Entry<String, Map<String, String>> highentrymap = (Map.Entry<String, Map<String, String>>) highentry;
            Map<String, String> temphighgmap = highentrymap.getValue();
            temphighgmap = sortByValue(temphighgmap);
            highresult.put(highentrymap.getKey(), temphighgmap);
        }
        for (Object midentry : midresult.entrySet()) {
            Map.Entry<String, Map<String, String>> midentrymap = (Map.Entry<String, Map<String, String>>) midentry;
            Map<String, String> tempmidmap = midentrymap.getValue();
            tempmidmap = sortByValue(tempmidmap);
            midresult.put(midentrymap.getKey(), tempmidmap);
        }
        for (Object lowentry : lowresult.entrySet()) {
            Map.Entry<String, Map<String, String>> lowentrymap = (Map.Entry<String, Map<String, String>>) lowentry;
            Map<String, String> templowmap = lowentrymap.getValue();
            templowmap = sortByValue(templowmap);
            lowresult.put(lowentrymap.getKey(), templowmap);
        }


        for (Object thisentry : thisresult.entrySet()) {
            Map.Entry<String, Map<String, String>> thisentrymap = (Map.Entry<String, Map<String, String>>) thisentry;
            Map<String, Map<String, String>> tempmap = new LinkedHashMap();
            tempmap.put("this", thisentrymap.getValue());
            thisresult.put(thisentrymap.getKey(), tempmap);
        }
        for (Object highentry : highresult.entrySet()) {
            Map.Entry<String, Map<String, String>> highentrymap = (Map.Entry<String, Map<String, String>>) highentry;
            Map<String, Map<String, String>> tempmap = new LinkedHashMap();
            tempmap.put("hc", highentrymap.getValue());
            highresult.put(highentrymap.getKey(), tempmap);
        }
        for (Object midentry : midresult.entrySet()) {
            Map.Entry<String, Map<String, String>> midentrymap = (Map.Entry<String, Map<String, String>>) midentry;
            Map<String, Map<String, String>> tempmap = new LinkedHashMap();
            tempmap.put("mc", midentrymap.getValue());
            midresult.put(midentrymap.getKey(), tempmap);
        }
        for (Object lowentry : lowresult.entrySet()) {
            Map.Entry<String, Map<String, String>> lowentrymap = (Map.Entry<String, Map<String, String>>) lowentry;
            Map<String, Map<String, String>> tempmap = new LinkedHashMap();
            tempmap.put("lc", lowentrymap.getValue());
            lowresult.put(lowentrymap.getKey(), tempmap);
        }

        for (String comid : companyid.split(",")) {
            Map<String, Map<String, String>> mapTemp = new LinkedHashMap<>();
            result.put(comid, mapTemp);
        }


        for (Object resultentry : result.entrySet()) {
            Map.Entry<String, Map<String, Map<String, String>>> resultentrymap = (Map.Entry<String, Map<String, Map<String, String>>>) resultentry;

            Map<String, Map<String, String>> thistempresult = (Map<String, Map<String, String>>) thisresult.get(resultentrymap.getKey());
            try {
                resultentrymap.getValue().putAll(thistempresult);
            } catch (Exception e) {
            }
            Map<String, Map<String, String>> hightempmap = (Map<String, Map<String, String>>) highresult.get(resultentrymap.getKey());
            try {
                resultentrymap.getValue().putAll(hightempmap);
            } catch (Exception e) {
            }
            Map<String, Map<String, String>> midtempmap = (Map<String, Map<String, String>>) midresult.get(resultentrymap.getKey());
            try {
                resultentrymap.getValue().putAll(midtempmap);
            } catch (Exception e) {
            }
            Map<String, Map<String, String>> lowtempmap = (Map<String, Map<String, String>>) lowresult.get(resultentrymap.getKey());
            try {
                resultentrymap.getValue().putAll(lowtempmap);
            } catch (Exception e) {
            }


        }
        return result;
    }

    @RequestMapping(value = "/getAllRelevanceCompany/{companyid}", method = RequestMethod.GET)
    private Map getAllRelevanceCompany(@PathVariable String companyid) {
        Map result = new LinkedHashMap();
        Map highresult = new LinkedHashMap();
        Map midresult = new LinkedHashMap();
        Map lowresult = new LinkedHashMap();
        Map thisresult = new LinkedHashMap();
        thisresult = getThisCompany(companyid);
        highresult = getHighRelevanceCompany(companyid);
        midresult = getMidRelevanceCompany(companyid);
        lowresult = getLowRelevanceCompany(companyid);

        logger.debug("----warning----");

        for (Object highentry : highresult.entrySet()) {
            Map.Entry<String, Map<String, String>> highentrymap = (Map.Entry<String, Map<String, String>>) highentry;
            try {
                Map tempmidmap = (Map) midresult.get(highentrymap.getKey());
                for (Map.Entry<String, String> temphighmap : highentrymap.getValue().entrySet()) {
                    if (tempmidmap != null) {
                        tempmidmap.remove(temphighmap.getKey());
                    }
                }
                if (tempmidmap != null) {
                    if (tempmidmap.size() != 0) {
                        midresult.put(highentrymap.getKey(), tempmidmap);
                    } else {
                        midresult.remove(highentrymap.getKey());
                    }
                }
            } catch (Exception e) {
            }
        }
        for (Object highentry : highresult.entrySet()) {
            Map.Entry<String, Map<String, String>> highentrymap = (Map.Entry<String, Map<String, String>>) highentry;
            try {
                Map templowmap = (Map) lowresult.get(highentrymap.getKey());
                for (Map.Entry<String, String> temphighmap : highentrymap.getValue().entrySet()) {
                    if (templowmap != null) {
                        templowmap.remove(temphighmap.getKey());
                    }
                }
                if (templowmap != null) {
                    if (templowmap.size() != 0) {
                        lowresult.put(highentrymap.getKey(), templowmap);
                    } else {
                        lowresult.remove(highentrymap.getKey());
                    }
                }

            } catch (Exception e) {
            }
        }
        for (Object midentry : midresult.entrySet()) {
            Map.Entry<String, Map<String, String>> midentrymap = (Map.Entry<String, Map<String, String>>) midentry;
            Map templowmap = (Map) lowresult.get(midentrymap.getKey());
            for (Map.Entry<String, String> tempmidmap : midentrymap.getValue().entrySet()) {
                if (templowmap != null) {
                    templowmap.remove(tempmidmap.getKey());
                }
            }
            if (templowmap != null) {
                if (templowmap.size() != 0) {
                    lowresult.put(midentrymap.getKey(), templowmap);
                } else {
                    lowresult.remove(midentrymap.getKey());
                }
            }
        }
        for (Object thisentry : thisresult.entrySet()) {
            Map.Entry<String, Map<String, String>> thisentrymap = (Map.Entry<String, Map<String, String>>) thisentry;
            Map templowmap = (Map) lowresult.get(thisentrymap.getKey());
            for (Map.Entry<String, String> tempthismap : thisentrymap.getValue().entrySet()) {
                if (templowmap != null) {
                    templowmap.remove(tempthismap.getKey());
                }
            }
            if (templowmap != null) {
                if (templowmap.size() != 0) {
                    lowresult.put(thisentrymap.getKey(), templowmap);
                } else {
                    lowresult.remove(thisentrymap.getKey());
                }
            }
        }
        for (Object thisentry : thisresult.entrySet()) {
            Map.Entry<String, Map<String, String>> thisentrymap = (Map.Entry<String, Map<String, String>>) thisentry;
            Map tempmidmap = (Map) midresult.get(thisentrymap.getKey());
            for (Map.Entry<String, String> tempthismap : thisentrymap.getValue().entrySet()) {
                if (tempmidmap != null) {
                    tempmidmap.remove(tempthismap.getKey());
                }
            }
            if (tempmidmap != null) {
                if (tempmidmap.size() != 0) {
                    midresult.put(thisentrymap.getKey(), tempmidmap);
                } else {
                    midresult.remove(thisentrymap.getKey());
                }
            }
        }
        //        for (Object highentry : highresult.entrySet()) {
        //            Map.Entry<String,String> highentrymap = (Map.Entry<String,String>) highentry;
        //            lowresult.remove(highentrymap.getKey());
        //        }
        //        for (Object midentry : midresult.entrySet())
        //        {
        //            Map.Entry<String,String> midentrymap = (Map.Entry<String,String>) midentry;
        //            lowresult.remove(midentrymap.getKey());
        //        }
        for (Object highentry : highresult.entrySet()) {
            Map.Entry<String, Map<String, String>> highentrymap = (Map.Entry<String, Map<String, String>>) highentry;
            Map<String, String> temphighgmap = highentrymap.getValue();
            temphighgmap = sortByValue(temphighgmap);
            highresult.put(highentrymap.getKey(), temphighgmap);
        }
        for (Object midentry : midresult.entrySet()) {
            Map.Entry<String, Map<String, String>> midentrymap = (Map.Entry<String, Map<String, String>>) midentry;
            Map<String, String> tempmidmap = midentrymap.getValue();
            tempmidmap = sortByValue(tempmidmap);
            midresult.put(midentrymap.getKey(), tempmidmap);
        }
        for (Object lowentry : lowresult.entrySet()) {
            Map.Entry<String, Map<String, String>> lowentrymap = (Map.Entry<String, Map<String, String>>) lowentry;
            Map<String, String> templowmap = lowentrymap.getValue();
            templowmap = sortByValue(templowmap);
            lowresult.put(lowentrymap.getKey(), templowmap);
        }


        for (Object thisentry : thisresult.entrySet()) {
            Map.Entry<String, Map<String, String>> thisentrymap = (Map.Entry<String, Map<String, String>>) thisentry;
            Map<String, Map<String, String>> tempmap = new LinkedHashMap();
            tempmap.put("this", thisentrymap.getValue());
            thisresult.put(thisentrymap.getKey(), tempmap);
        }
        for (Object highentry : highresult.entrySet()) {
            Map.Entry<String, Map<String, String>> highentrymap = (Map.Entry<String, Map<String, String>>) highentry;
            Map<String, Map<String, String>> tempmap = new LinkedHashMap();
            tempmap.put("hc", highentrymap.getValue());
            highresult.put(highentrymap.getKey(), tempmap);
        }
        for (Object midentry : midresult.entrySet()) {
            Map.Entry<String, Map<String, String>> midentrymap = (Map.Entry<String, Map<String, String>>) midentry;
            Map<String, Map<String, String>> tempmap = new LinkedHashMap();
            tempmap.put("mc", midentrymap.getValue());
            midresult.put(midentrymap.getKey(), tempmap);
        }
        for (Object lowentry : lowresult.entrySet()) {
            Map.Entry<String, Map<String, String>> lowentrymap = (Map.Entry<String, Map<String, String>>) lowentry;
            Map<String, Map<String, String>> tempmap = new LinkedHashMap();
            tempmap.put("lc", lowentrymap.getValue());
            lowresult.put(lowentrymap.getKey(), tempmap);
        }

        for (String comid : companyid.split(",")) {
            Map<String, Map<String, String>> mapTemp = new LinkedHashMap<>();
            result.put(comid, mapTemp);
        }


        for (Object resultentry : result.entrySet()) {
            Map.Entry<String, Map<String, Map<String, String>>> resultentrymap = (Map.Entry<String, Map<String, Map<String, String>>>) resultentry;

            Map<String, Map<String, String>> thistempresult = (Map<String, Map<String, String>>) thisresult.get(resultentrymap.getKey());
            try {
                resultentrymap.getValue().putAll(thistempresult);
            } catch (Exception e) {
            }
            Map<String, Map<String, String>> hightempmap = (Map<String, Map<String, String>>) highresult.get(resultentrymap.getKey());
            try {
                resultentrymap.getValue().putAll(hightempmap);
            } catch (Exception e) {
            }
            Map<String, Map<String, String>> midtempmap = (Map<String, Map<String, String>>) midresult.get(resultentrymap.getKey());
            try {
                resultentrymap.getValue().putAll(midtempmap);
            } catch (Exception e) {
            }
            Map<String, Map<String, String>> lowtempmap = (Map<String, Map<String, String>>) lowresult.get(resultentrymap.getKey());
            try {
                resultentrymap.getValue().putAll(lowtempmap);
            } catch (Exception e) {
            }


        }
        return result;
    }

    private Map getThisCompany(@PathVariable String companyid) {
        Map result = new LinkedHashMap();
        QueryResultModel companyNode = objectRepository.getThisCompany(companyid);
        int count = 0;

        for (Map<String, Object> obj : companyNode) {
            Map<String, Object> cid = (Map<String, Object>) obj.get("cid");
            Map<String, Object> comp = (Map<String, Object>) obj.get("c");
            Map companyidresult = new LinkedHashMap();
            companyidresult.put(comp.get("COMPANY_ID"), comp.get("WARNING_NUM"));
            result.put(cid.get("COMPANY_ID"), companyidresult);
            count++;
        }
        logger.debug("被关注企业预警共" + count + "条");
        return result;
    }

    @RequestMapping(value = "/getHighRelevanceCompany/{companyid}", method = RequestMethod.GET)
    private Map getHighRelevanceCompany(@PathVariable String companyid) {

        Map result = new LinkedHashMap();

        QueryResultModel companyNode = objectRepository.getHighRelevanceCompany(companyid);
        int count = 0;
        for (Map<String, Object> obj : companyNode) {
            Map<String, Object> cid = (Map<String, Object>) obj.get("cid");
            Map<String, Object> comp = (Map<String, Object>) obj.get("c");
            Map companyidresult = new LinkedHashMap();
            if (!result.containsKey(cid.get("COMPANY_ID"))) {
                companyidresult.put(comp.get("COMPANY_ID"), comp.get("WARNING_NUM"));
                result.put(cid.get("COMPANY_ID"), companyidresult);
            } else {
                companyidresult = (HashMap) result.get(cid.get("COMPANY_ID"));
                companyidresult.put(comp.get("COMPANY_ID"), comp.get("WARNING_NUM"));
                result.put(cid.get("COMPANY_ID"), companyidresult);
            }
            count++;
        }
        logger.debug("高度关联共" + count + "条");
        return result;
    }

    @RequestMapping(value = "/getMidRelevanceCompany/{companyid}", method = RequestMethod.GET)
    private Map getMidRelevanceCompany(@PathVariable String companyid) {
        //        Map result = new LinkedHashMap();
        Map result = new LinkedHashMap();

        logger.debug(companyid);

        QueryResultModel companyNode = objectRepository.getMidRelevanceCompany(companyid);
        int count = 0;
        for (Map<String, Object> obj : companyNode) {
            Map<String, Object> cid = (Map<String, Object>) obj.get("cid");
            Map<String, Object> comp = (Map<String, Object>) obj.get("c");
            if (!result.containsKey(cid.get("COMPANY_ID"))) {
                Map companyidresult = new LinkedHashMap();
                companyidresult.put(comp.get("COMPANY_ID"), comp.get("WARNING_NUM"));
                result.put(cid.get("COMPANY_ID"), companyidresult);
            } else {
                HashMap tempmap = new HashMap();
                tempmap = (HashMap) result.get(cid.get("COMPANY_ID"));
                tempmap.put(comp.get("COMPANY_ID"), comp.get("WARNING_NUM"));
                result.put(cid.get("COMPANY_ID"), tempmap);
            }
            count++;
        }
        logger.debug("中度关联共" + count + "条");
        //        result.put("midrelevancecompany",resultOfType);
        return result;
    }


    @RequestMapping(value = "/getLowRelevanceCompany/{companyid}", method = RequestMethod.GET)
    private Map getLowRelevanceCompany(@PathVariable String companyid) {
        //        Map result = new LinkedHashMap();
        Map result = new LinkedHashMap();

        QueryResultModel companyNode = objectRepository.getLowRelevanceCompany(companyid);
        int count = 0;
        for (Map<String, Object> obj : companyNode) {
            Map<String, Object> cid = (Map<String, Object>) obj.get("cid");
            Map<String, Object> comp = (Map<String, Object>) obj.get("c");
            if (!result.containsKey(cid.get("COMPANY_ID"))) {
                Map companyidresult = new LinkedHashMap();
                companyidresult.put(comp.get("COMPANY_ID"), comp.get("WARNING_NUM"));
                result.put(cid.get("COMPANY_ID"), companyidresult);
            } else {
                HashMap tempmap = new HashMap();
                tempmap = (HashMap) result.get(cid.get("COMPANY_ID"));
                tempmap.put(comp.get("COMPANY_ID"), comp.get("WARNING_NUM"));
                result.put(cid.get("COMPANY_ID"), tempmap);
            }
            count++;
        }
        logger.debug("低度关联共" + count + "条");
        return result;
    }


    public static <K, V extends Comparable<? super V>> Map<K, V>
    sortByValue(Map<K, V> map) {
        List<Map.Entry<K, V>> list =
                new LinkedList<Map.Entry<K, V>>(map.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<K, V>>() {
            public int compare(Map.Entry<K, V> o1, Map.Entry<K, V> o2) {
                return (o2.getValue()).compareTo(o1.getValue());
            }
        });

        Map<K, V> result = new LinkedHashMap<K, V>();
        for (Map.Entry<K, V> entry : list) {
            result.put(entry.getKey(), entry.getValue());
        }
        return result;
    }
}
