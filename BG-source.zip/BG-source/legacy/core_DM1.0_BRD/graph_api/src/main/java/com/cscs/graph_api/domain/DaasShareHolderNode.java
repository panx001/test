package com.cscs.graph_api.domain;

/**
 * Created by wuchenglong on 2018/1/10.
 */

@SuppressWarnings("unused")
public class DaasShareHolderNode {

    private String FUNDEDRATIO; // 投资比例
    private String SHANAME; // 股东名称
    private String LINK_ID;  //用于名称匹配的id

    public DaasShareHolderNode() {
    }

    public void setSHANAME(String SHANAME) {
        this.SHANAME = SHANAME;
    }

    public String getSHANAME() {
        return SHANAME;
    }

    public void setFUNDEDRATIO(String FUNDEDRATIO) {
        this.FUNDEDRATIO = FUNDEDRATIO;
    }

    public String getFUNDEDRATIO() {
        return FUNDEDRATIO;
    }


    public String getLINK_ID() {
        return LINK_ID;
    }

    public void setLINK_ID(String LINK_ID) {
        this.LINK_ID = LINK_ID;
    }
}
