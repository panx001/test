# 1.3.3 (2019.04.27)

### Feature

* 增加batchSize配置项

### BugFix

* fix autoupdate.sh 问题


# 1.3.2 (2019.04.25)

### Feature

* 增加PID文件判断进程有没有在执行
* 增加shell启动脚本
* 修复邮件功能，提供邮件配置项

### BugFix

* fix写neo4j metadata文件名没有写入

# 1.3.1 (2019.04.24)

### Performance Improvements

* 更改cypher使用apoc.periodic.iterate来加载csv
* 去除文件加载中间间隔1分钟的逻辑

### Feature

* 更新完成后写neo4j metadata


