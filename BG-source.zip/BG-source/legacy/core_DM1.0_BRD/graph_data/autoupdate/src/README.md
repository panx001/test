# 自动更新和初始化说明文档
图谱更新包含两个部分：初始化和自动更新。

## 初始化前提条件：

1. 创建input文件夹，input目录下的文件已经按要求组织好：
    mount 或 sftp手动拉取 或 rsync(找IT配置)获取output/neo4j_csv 到你创建的input/neo4j_csv。
          （neo4j_csv初始化csv和增量csv都在neo4j_csv下，初始化的是最早的一批csv。要初始化的数据是按文件名日期来做判断的。）
    neo4j_csv文件目前在
2. neo4j_csv已经有数据，初始化程序不负责数据传输、同步问题。

## 初始化部分：
初始化会生成需要使用的neo4j代码finalCommand.txt，然后检查并执行里面的代码。同时产生一个initCsvList.txt用于防止增量更新的时候再去读取已经初始化的数据。
### 初始化方式（初始化需要按如下流程手动处理）：
1. 执行 java -cp /home/mohr/autoupdate-1.3-jar-with-dependencies.jar Init /app/input/ false false
    然后检查 /your_path/input 目录下是否生成有 headers文件夹、commandFirst.txt、commandSecond.txt、initCsvList.txt

2. 执行 /your_path/input/commandFirst.txt 里的命令,等待各个进程done

3. neo4j stop

4. rm -rf 旧的 graph.db
  图谱的配置文件在conf/neo4j.conf

  配置以下：

  #dbms.directories.import=import（意思就是用#把这一行注释掉）

  dbms.connectors.default_listen_address=0.0.0.0 （意思是这一行不要注释掉了）

  dbms.tx_log.rotation.retention_policy=3 days （意思是transaction保留3天）

  128g
  dbms.memory.heap.initial_size=25g
  dbms.memory.heap.max_size=25g
  dbms.memory.pagecache.size=60g
  64g
  dbms.memory.heap.initial_size=15g
  dbms.memory.heap.max_size=15g
  dbms.memory.pagecache.size=30g

  

  

5. 人工检查并执行 /your_path/input/commandSecond.txt

6. neo4j start

7. 进入neo4j-shell 创建索引。建议前四行指令一个一个执行，不要用-file的方法，否则图谱容易崩。
  CREATE CONSTRAINT ON (C:COMPANY) ASSERT C.COMPANY_ID IS UNIQUE;
  CREATE CONSTRAINT ON (S:SECURITY) ASSERT S.SECINNER_ID IS UNIQUE;
  CREATE CONSTRAINT ON (S:PFUND) ASSERT S.SECINNER_ID IS UNIQUE;
  CREATE CONSTRAINT ON (P:PERSON) ASSERT P.PERSON_ID IS UNIQUE;
  CREATE INDEX ON :PERSON(PERSON_NM);
  CREATE INDEX ON :SECURITY(SECURITY_NM);
  CREATE INDEX ON :PFUND(SECURITY_NM);
  CREATE INDEX ON :COMPANY(SECURITY_CD);
  CREATE INDEX ON :COMPANY(COMPANY_NM);
  CREATE INDEX ON :PFCOMPANY(COMPANY_ID);
  CREATE INDEX ON :PFCOMPANY(REG_CD);

8. 执行以下语句
  OPTIONAL MATCH (c:COMPANY) where c.COMPANY_ID in ['company_id','sharehd_id']
  OPTIONAL MATCH (p:PERSON) where p.PERSON_ID in ['person_id']
  DETACH DELETE c
  DETACH DELETE p;

9. 跑日常自动更新脚本：
  编写crontab进行周期性执行以下命令

       initTimeStamp = args[4];
       neo4jUser = args[5];
       neo4jPW = args[6];
  nohup java -cp /data/autoupdate/autoupdate.jar  -Dfile.encoding=utf-8 Update /data/input/neo4j_csv  /data/input/neo4j_csv  /data/input/neo4j_work  bolt://localhost:7687 20190319193620 neo4j neo4j jobtest@chinacscs.com mohr@chinacscs.com mail.chinacscs.com XKFqI9GT &

  java -cp /data/autoupdate/autoupdate.jar -Dfile.encoding=utf-8  Update /data/input/neo4j_csv  /data/input/neo4j_csv  /data/input/neo4j_work  bolt://localhost:7687 20190319193620 neo4j neo4j jobtest@chinacscs.com mohr@chinacscs.com mail.chinacscs.com XKFqI9GT

10. 完成

## 自动更新部分
TODO 详细下个版本再添加
1. neo4j_csv已经mount就不用额外操作。
2. crontab 需要根据需要自己启动

java -cp /home/mohr/autoupdate.jar Update /app/input bolt://localhost:7687 20190319193620 monitor Neo4j jobtest@chinacscs.com mohr@chinacscs.com mail.chinacscs.com XKFqI9GT

### portal需要注意
1. 发行关系 issue的relationship都是发行，不再给property key

### 备忘录
如果股东中出现产品被标记为person，检查l_security_sharehd,最终要追溯到数据平台



# todo 报错：

可能是对应的cql不存在
p_pfcompany_20190208120145.csv 的cql找不到
l_controller_20190127120322.csv
n_person_executive_20190131234352.csv
compy_warnings2_20190126142715.csv

可能需要手动修复因为n_security 过大的问题。必须加一个csv文件过大的防护，避免图谱服务器崩溃