package helper;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.io.File;
import java.nio.file.Paths;
import java.util.Properties;

public class Email {
    String from ;
    String mailHost ;
    String mailPassWord ;
    String emailContext ;
    String logsPath ;
    String attachmentCsvFileName="";
    String attachmentLogFileName="" ;
    String mailTitle;
    String[] to;
    Properties properties;
    javax.mail.Session session;
    public Email(String mailContent){
        properties = System.getProperties();
        String strto = properties.getProperty("app.mail.to");
        to = strto == null ? new String[]{} : strto.split(",");
        from = properties.getProperty("mail.user");
        mailPassWord = properties.getProperty("mail.password");
        mailTitle = properties.getProperty("app.mail.title");
        setEmailContext(mailContent);
    }
    public void setAttachmentCsvFileName(String attachmentCsvFileName){
        this.attachmentCsvFileName = Paths.get(logsPath,attachmentCsvFileName).toAbsolutePath().toString();
    }
    public void setAttachmentLogFileName(String attachmentLogFileName){
        this.attachmentLogFileName = Paths.get(logsPath,attachmentLogFileName).toAbsolutePath().toString();
    }
    public void setEmailContext(String context){
        this.emailContext = context;
    }


    public void send() {

            session = javax.mail.Session.getDefaultInstance(properties);

            try {
                MimeMessage message = new MimeMessage(session);
                message.setFrom(new InternetAddress(from));
                InternetAddress[] sendTo = new InternetAddress[to.length];

                for(int i = 0; i < to.length; ++i) {
                    sendTo[i] = new InternetAddress(to[i]);
                }

                message.addRecipients(Message.RecipientType.TO, sendTo);
                message.setSubject(mailTitle);
                BodyPart messageBodyPart = new MimeBodyPart();
                messageBodyPart.setText(emailContext);
                Multipart multipart = new MimeMultipart();
                multipart.addBodyPart(messageBodyPart);
                FileDataSource source;
                if (fileIsExists(attachmentCsvFileName)) {
                    messageBodyPart = new MimeBodyPart();
                    source = new FileDataSource(attachmentCsvFileName);
                    messageBodyPart.setDataHandler(new DataHandler(source));
                    messageBodyPart.setFileName(attachmentCsvFileName);
                    multipart.addBodyPart(messageBodyPart);
                }

                if (fileIsExists(attachmentLogFileName)) {
                    messageBodyPart = new MimeBodyPart();
                    source = new FileDataSource(attachmentLogFileName);
                    messageBodyPart.setDataHandler(new DataHandler(source));
                    messageBodyPart.setFileName(attachmentLogFileName);
                    multipart.addBodyPart(messageBodyPart);
                }

                message.setContent(multipart, "text/html;charset=UTF-8");
                Transport transport = session.getTransport();
                // transport.connect("jobtest@chinacscs.com", "XKFqI9GT");
                transport.connect(from, mailPassWord);
                transport.sendMessage(message, message.getAllRecipients());
                transport.close();
            } catch (MessagingException e) {
                e.printStackTrace();
            }
    }
    private boolean fileIsExists(String strFile) {
        try {
            File f=new File(strFile);
            if(!f.exists()) {
                return false;
            }
        }
        catch (Exception e) {
            return false;
        }
        return true;
    }
}
