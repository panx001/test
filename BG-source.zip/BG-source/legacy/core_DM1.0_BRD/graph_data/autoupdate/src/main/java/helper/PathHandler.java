package helper;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

/**
 * 用于定义目录结构，处理所有路径问题
 * */
public class PathHandler {

    private Map<String, Path> pathMap = new HashMap<String, Path>();
    private Path localNeo4jCsvDir;
    private Path sftpLogsDir;
    private String csvDirNeo4j;

    /**
     * @param csvDirSftp
     * 本地的csv文件目录地址。即该调度程序所在服务器的csv目录。
     * 如果该程序与neo4j在一个服务器上，该路径就是neo4j要读取的csv目录。
     * @param csvDirNeo4j
     *  neo4j要读取的csv目录的路径
     * @param workSpace
     * 本地log存放地址
     * */
    public PathHandler(String csvDirSftp, String csvDirNeo4j, String workSpace){
        this.csvDirNeo4j = csvDirNeo4j;
        localNeo4jCsvDir = Paths.get(csvDirSftp);
        sftpLogsDir = Paths.get(workSpace);
        Path updateFinish = Paths.get(workSpace, "update_finish");

        Path ins = Paths.get(localNeo4jCsvDir.toAbsolutePath().toString(), "ins");
        Path del = Paths.get(localNeo4jCsvDir.toAbsolutePath().toString(), "del");
        Path finish = Paths.get(localNeo4jCsvDir.toAbsolutePath().toString(), "finish");

        if (!localNeo4jCsvDir.toFile().isDirectory()) {
            throw new IllegalStateException(
                    "调度端 neo4j_csv 目录不存在" + localNeo4jCsvDir.toAbsolutePath().toString());
        } else {
            this.pathMap.put("sftpNeo4jCsvDir", localNeo4jCsvDir);
        }
        if (!sftpLogsDir.toFile().exists()) {
            this.pathMap.put("initCsvList",
                    Paths.get(sftpLogsDir.toAbsolutePath().toString(), "initCsvList.txt"));
            if (!sftpLogsDir.toFile().mkdirs()) {
                throw new IllegalStateException("创建neo4j的updateWorkDir目录失败");
            }
        }
        if (!updateFinish.toFile().exists()) {
            if (!updateFinish.toFile().mkdirs()) {
                throw new IllegalStateException("创建updateFinish目录失败");
            }
        }

        this.pathMap.put("ins", ins);
        this.pathMap.put("del", del);
        this.pathMap.put("finish", finish);
        this.pathMap.put("updateFinish", updateFinish);
        this.pathMap.put("sftpLogsDir", sftpLogsDir);
    }

    /**
     * @param fileName
     * sftpNeo4jCsvDir ins del finish 等等
     * @return
     * 返回一个绝对路径，这里路径是对应的本地路径。
     * @see #getPathOnNeo4jServer(String)
     * */
    public String getAbsPath(String fileName) {
        return this.pathMap.get(fileName).toAbsolutePath().toString();
    }
    /**
     * @param absPathOnSftpServer
     * @return
     * 返回neo4j服务器上的对应文件的绝对地址
     * 这个方法主要用来在调度程序（本程序）和neo4j没有在一个服务器上的时候，
     * csv文件路径需要映射。
     * */
    public String getPathOnNeo4jServer(String absPathOnSftpServer) {
        return absPathOnSftpServer
                .replace(localNeo4jCsvDir.toAbsolutePath().toString(), this.csvDirNeo4j)
                .replace("\\", "/");
    }
    public Path getPath(String fileName) {
        try {
            return this.pathMap.get(fileName);
        } catch (Exception e) {
            return null;
        }
    }
}
