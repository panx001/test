import java.io.File;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import helper.FileReaderWriter;
import helper.HeaderMapper;
import helper.PathHandler;

/**
 *
 * @author mohr@chinacscs.com
 * @date 2018 Dec. 15
 */

public class Init {
    public static void main(String[] args) throws Exception {

        SimpleDateFormat ft = new SimpleDateFormat("yyyyMMddhhmmss");
        String localAndNeo4jCsvDir; // input/neo4j_csv
        String neo4jWork;
        if (args.length > 0) {
            localAndNeo4jCsvDir = args[0];
            neo4jWork = args[1];

        } else {
            localAndNeo4jCsvDir = "D:\\gitprojects\\transmission-client\\workspace\\neo4j_csv";
            neo4jWork = "D:\\gitprojects\\transmission-client\\workspace\\neo4j_work";
        }
        Logger logger = Logger.getLogger("load." + ft.format(new Date()) + ".log");

        StringBuilder finalCommand = (new StringBuilder()).append("neo4j-admin import");
        StringBuilder sedCommand = new StringBuilder();
        PathHandler pathHandler = new PathHandler(localAndNeo4jCsvDir, localAndNeo4jCsvDir, neo4jWork);
        String headerDir = Paths.get(pathHandler.getAbsPath("sftpLogsDir"), "headers").toAbsolutePath().toString();
        FileReaderWriter.writeHeaderFiles(headerDir);

        Set<String> csvInitNames = HeaderMapper.header.keySet();
        List<CsvFile> tobeUpdatedCsv = new ArrayList<CsvFile>();

        String[] insertDirs = (String[]) Objects.requireNonNull(pathHandler.getPath("ins").toFile().list());

        for (String dirName : insertDirs) {
            if (csvInitNames.contains(dirName)) {
                File eachCsvDir = Paths.get(pathHandler.getAbsPath("ins"), dirName).toFile();
                if (!eachCsvDir.isDirectory()) {
                    break;
                }
                Set<CsvFile> candidateCsvFile = new HashSet<>();
                String[] csvFileInside = (String[]) Objects.requireNonNull(eachCsvDir.list());

                for (String csvFileName : csvFileInside) {
                    try {
                        String absPathOnNeo4jAndLocal = Paths.get(eachCsvDir.toString(), csvFileName).toAbsolutePath()
                                .toString();
                        CsvFile temp = new CsvFile(absPathOnNeo4jAndLocal, absPathOnNeo4jAndLocal, csvFileName, true,
                                true);
                        candidateCsvFile.add(temp);
                    } catch (Exception e) {
                        logger.log(Level.INFO,
                                "处理csv文件出错，可能读到了临时文件，将抛弃此文件：" + csvFileName + ",java报错为" + e.getMessage());
                    }
                }

                if (candidateCsvFile.size() > 0) {
                    tobeUpdatedCsv.add(Collections.min(candidateCsvFile));
                } else {
                    throw new Exception("没有找到要更初始化的csv文件，请检查文件存放位置");
                }
            }
        }

        logger.log(Level.INFO,
                "tobeUpdatedCsv:" + tobeUpdatedCsv.stream().map(e -> e.fileName).collect(Collectors.toList()));

        Collections.sort(tobeUpdatedCsv);

        for (CsvFile csvFile : tobeUpdatedCsv) {
            String HeaderAbsPath = Paths.get(headerDir, csvFile.fileType + ".csv").toAbsolutePath().toString();
            finalCommand.append(" --").append(csvFile.nodeOrRelation + ":" + csvFile.type).append(" ").append("\"")
                    .append(HeaderAbsPath).append(",").append(csvFile.absPath).append("\"");
            sedCommand.append("sed '1d' ").append(csvFile.absPath).append(" > ")
                    .append(Paths.get(localAndNeo4jCsvDir, csvFile.fileName)).append(" &").append("\n");
        }

        finalCommand.append(" --ignore-missing-nodes").append(" --ignore-duplicate-nodes")
                .append(" --multiline-fields=true").append(" --ignore-extra-columns=true");
        System.out.println(finalCommand.toString());
        FileReaderWriter.write(
                Paths.get(pathHandler.getAbsPath("sftpLogsDir"), "commandFirst.txt").toAbsolutePath().toString(),
                sedCommand.toString());
        FileReaderWriter.write(
                Paths.get(pathHandler.getAbsPath("sftpLogsDir"), "commandSecond.txt").toAbsolutePath().toString(),
                finalCommand.toString());
        FileReaderWriter.write(
                Paths.get(pathHandler.getAbsPath("sftpLogsDir"), "initCsvList.txt").toAbsolutePath().toString(),
                tobeUpdatedCsv.stream().map(csvFile -> csvFile.fileName)
                        .collect(Collectors.joining(System.getProperty("line.separator"))));
    }
}
