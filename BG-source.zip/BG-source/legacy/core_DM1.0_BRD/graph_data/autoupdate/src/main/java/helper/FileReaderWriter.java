package helper;

import com.csvreader.CsvReader;

import java.io.*;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;


public class FileReaderWriter {
    public static ArrayList<String> read(String path){
        ArrayList<String> resultArray = new ArrayList<String>();
        try{
            BufferedReader bufferedReader = new BufferedReader(new FileReader(path));
            String eachLine = null;
            while ((eachLine = bufferedReader.readLine())!=null){
                resultArray.add(eachLine);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return resultArray;
    }

    public static String readFirstLine(String path) throws Exception{
        CsvReader csvReader = new CsvReader(path);
        csvReader.readRecord();
        return csvReader.getRawRecord();
    }

    public static ArrayList<String> readCsv(String path) throws Exception{
        ArrayList<String> resultArray = new ArrayList<String>();
        try {
            CsvReader csvReader = new CsvReader(path);
            while (csvReader.readRecord()){
                resultArray.add(csvReader.getRawRecord());
            }
        }catch (Exception e){
            throw new Exception();
        }
        return resultArray;
    }

    public static void write(String path,String oneline){
        try {
            File file = new File(path);
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(path));
            bufferedWriter.write(oneline);
            bufferedWriter.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void writeHeaderFiles(String headerDir) throws Exception {
        File dir = new File(headerDir);
        String key;
        Path tempPath;
        File temp;
        FileWriter fw;
        BufferedWriter bw;
        if (!dir.exists()) {
            if (!dir.mkdirs()) {
                throw new Exception("创建header目录失败");
            }
        }
        for(Map.Entry<String,String> entry : HeaderMapper.header.entrySet()){
            temp = new File(dir.getAbsolutePath(),entry.getKey()+".csv");
            fw = new FileWriter(temp);
            bw = new BufferedWriter(fw);
            bw.write((String) entry.getValue());
            bw.close();
            fw.close();
        }
    }
}
