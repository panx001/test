import helper.CqlManager;

public class TestConnection {
    public static void main(String[] args) throws Exception {
        /*
         * String str = "\"华林路第三\\\"居委会\\被服加\\\"工门市部\",\"注销,吊销\""; // String str2 =
         * "华林路第三\\\"居委会\\被服加\\\"工门市部"; System.out.println("原始  "+str);
         * System.out.println("新的  "+str.replace("\\\"","\"\"").replace("\r","").replace
         * ("\n","").replace("（","(").replace("）",")")); //
         * System.out.println(str2.replace("\"","\"\"")); // result ="\""+
         * str.replace("\"","\"\"").replace("\\","").replace("\r","").replace("\
         * n","").replace("（","(").replace("）",")")+"\"";
         * 
         */
        /*
         * for(String line: FileReaderWriter.read(
         * "D:\\projects\\core_DM1.0_BRD-graph_data\\graph_data\\autoupdate\\src\\main\\java\\test.csv"
         * )){ System.out.println(line); }
         */
        String type = "n_company";
        System.out.println(CqlManager.getCql(type, 4000,
                "/app/transmission-client/workspace/neo4j_csv/del" + "/" + type + "/", true));
        // System.out.println("USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS
        // FROM 'file://csv_file_path' AS LINE\nMATCH
        // (c:COMPANY{COMPANY_ID:LINE.company_id}) <-[w:INVEST]-
        // (p:COMPANY{COMPANY_ID:LINE.SHACOMP_ID})\nDELETE w");

        // System.out.println(FileReaderWriter.readFirstLine("D:\\存贮数据\\BG项目图谱自动更新数据备份\\旧数据\\compy_basicinfo\\compy_basicinfo_20181224221400.csv"));
    }
}
