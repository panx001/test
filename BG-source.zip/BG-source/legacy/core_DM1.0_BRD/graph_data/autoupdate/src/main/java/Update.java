import java.nio.file.Paths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import helper.Email;

public class Update {

    private final static Logger log = LoggerFactory.getLogger(Update.class);

    /**
     */
    public static void main(String[] args) {
        try {
            String appHome = System.getProperty("APP_HOME");
            if (appHome == null) {
                appHome = ".";
            }
            PidFile.create(Paths.get(appHome, "autoupdate.pid"), true);

            if (args.length > 0) {
                GraphLoadService graphLoadService = new GraphLoadService(args);
                graphLoadService.loadGraphFile();
            } else {
                String localGraphCsvDir = "D:\\gitprojects\\transmission-client\\workspace\\neo4j_csv";
                String neo4jServerCsvDir = "D:\\gitprojects\\transmission-client\\workspace\\neo4j_csv";
                String updateWorkDir = "D:\\gitprojects\\transmission-client\\workspace\\neo4j_work";
                String uri = "bolt://10.100.45.43:7687";
                String initTimeStamp = "20190325000000";
                String neo4jUser = "monitor";
                String neo4jPW = "Neo4j";
                String[] defaultArgs = new String[] { localGraphCsvDir, neo4jServerCsvDir, updateWorkDir, uri,
                        initTimeStamp, neo4jUser, neo4jPW };
                GraphLoadService graphLoadService = new GraphLoadService(defaultArgs);
                graphLoadService.loadGraphFile();
                System.out.println("end");
            }
            /*
             * else { inputPathStr = "D:\\存贮数据\\input"; // inputPathStr = "/app/input"; uri
             * = "bolt://10.100.45.43:7687"; neo4jUser = "monitor"; neo4jPW = "Neo4j"; from
             * = "jobtest@chinacscs.com"; emailReceiverList = "mohr@chinacscs.com"; mailHost
             * = "mail.chinacscs.com"; mailPW = "XKFqI9GT"; }
             */
            System.out.println("end");

        } catch (Exception e) {
            log.error("未知的错误：", e);
        }
    }
}
