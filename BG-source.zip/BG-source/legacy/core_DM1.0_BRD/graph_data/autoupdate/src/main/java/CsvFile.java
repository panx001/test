import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import helper.CqlManager;
import helper.HeaderMapper;

/**
 * @author mohr
 */
public class CsvFile implements Comparable<CsvFile> {

    /**
     * 绝对路径 完整的文件名字n_company2019xxxxxxxx.csv 文件类型n_company 对应要执行的cql 14位的时间戳
     */
    private final String HighestPriorityFile = "n_company_security";
    final char RELATION_SIGN = 'l';
    public String type;
    public String header;
    public String nodeOrRelation;
    public String absPath;
    public String sftpCsvPath;
    String fileName;
    public String fileType;
    private List<String> emailCsvHeader;
    String cql;
    private String pattern = "(.*)_(\\d{14})";
    private String time;
    String updateResult;
    boolean isInsert;
    private boolean isInit;
    private Pattern r = Pattern.compile(pattern);
    Map<String, String> resultMap;

    CsvFile(String sftpCsvPath, String absPath, String fileName, boolean isInsert, boolean isInit) throws Exception {
        this.sftpCsvPath = sftpCsvPath;
        this.absPath = absPath;
        this.isInsert = isInsert;
        this.isInit = isInit;

        this.fileName = fileName;
        Matcher m = r.matcher(this.fileName);
        this.emailCsvHeader = Arrays.asList(
                "csv_file_name,cql_name,lines_of_csv,nodes,relationships,labels,start_time,end_time".split(","));

        if (m.find()) {
            try {
                this.fileType = m.group(1);
                if (this.isInit) {
                    String nodeRelationType = (String) HeaderMapper.nodeLabelRelationType.get(this.fileType);
                    this.nodeOrRelation = nodeRelationType.split(",")[0];
                    this.type = nodeRelationType.split(",")[1];
                    this.header = (String) HeaderMapper.header.get(this.fileType);
                } else {
                    try {
                        this.cql = CqlManager.getCql(this.fileType, 4000, this.absPath, this.isInsert);
                    } catch (Exception e) {
                        throw new Exception(e.getMessage() + "（获取cql出错，可能是对应的cql不存在）");
                    }
                }
                this.time = m.group(2);
            } catch (Exception e) {
                throw new Exception(
                        e.getMessage() + "（获取header,node relation type出错" + this.fileName + " " + e.getMessage());
            }
            this.resultMap = new HashMap<String, String>();
            this.resultMap.put("csv_name", CsvFile.this.fileName);
            this.resultMap.put("cql_name", this.fileType);
            this.resultMap.put("lines_of_csv", "unknown");
            this.resultMap.put("updated_num", "unknown");
            this.resultMap.put("start_time", "unknown");
            this.resultMap.put("end_time", "unknown");
        } else {
            throw new Exception("csv文件名字格式不规范，将抛弃" + absPath);
        }
    }

    public void updateCql(long commitNum, long skipLines, long limitLines) {
        this.cql = CqlManager.getCql(this.fileType, commitNum, this.absPath, this.isInsert, skipLines, limitLines);
        if (skipLines < 0 && limitLines < 0) {
            this.cql = CqlManager.getCql(this.fileType, commitNum, this.absPath, this.isInsert);
        }
    }

    String getResultMapValueAsLine() {
        return (String) this.emailCsvHeader.stream().map((key) -> {
            return (String) this.resultMap.get(key);
        }).collect(Collectors.joining(","));
    }

    boolean isInRange(String start, String end) {
        return this.time.compareToIgnoreCase(start) > 0 && this.time.compareToIgnoreCase(end) <= 0;
    }

    @Override
    public int compareTo(CsvFile o) {

        // 先删后增
        if (this.isInsert && !o.isInsert) {
            return 1;
        } else if (!this.isInsert && o.isInsert) {
            return -1;
        }
        // n_company_security 优先更新
        if (HighestPriorityFile.equals(this.fileType) && !HighestPriorityFile.equals(o.fileType)) {
            return -1;
        } else if (!HighestPriorityFile.equals(this.fileType) && HighestPriorityFile.equals(o.fileType)) {
            return 1;
        }

        // 按从小到大，n,p排在前面，l排在后面，time小的在前面。
        if (this.fileType.charAt(0) == o.fileType.charAt(0)) {
            return this.time.compareTo(o.time);
        } else if (this.fileType.charAt(0) == RELATION_SIGN) {
            return 1;
        } else {
            return -1;
        }
    }
}
