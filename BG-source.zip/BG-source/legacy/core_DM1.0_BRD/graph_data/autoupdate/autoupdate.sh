#! /bin/bash

# 写pid防止重复运行
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
PIDFILE=$DIR/autoupdate.pid
if [ -f $PIDFILE ]
then
  PID=$(cat $PIDFILE)
  ps -p $PID > /dev/null 2>&1
  if [ $? -eq 0 ]
  then
    echo "Process already running"
    exit 1
  fi
fi

# run autoupdate
# jar包路径
jarfile=$DIR/autoupdate-1.3.3-jar-with-dependencies.jar
# 本地csv存放路径
localDir=/data/input/neo4j_csv
# Server端csv路径，供LOAD CSV使用
serverDir=/data/input/neo4j_csv
# updated文件存放路径
workDir=/data/input/neo4j_work
# neo4j的地址
neo4jUri=bolt://localhost:7687
# neo4j用户名
neo4jUser=neo4j
# neo4j密码
neo4jPassword=neo4j
# 上次加载时间，在这个时间之前的finish文件会忽略
loadedTime=20190319193620
# 邮件主题
emailTitle=中信图谱更新日志
# 要发送的人，以逗号分隔
emailTo=xugq@chinacscs.com,xyz@163.com
# batchSize 设定执行batch的大小，默认5000
batchSize=10000

nohup java -cp $jarfile -DAPP_HOME=$DIR -Dorg.slf4j.simpleLogger.showDateTime=true \
 -Dorg.slf4j.simpleLogger.logFile=$DIR/autoupdate.log \
 -Dfile.encoding=utf-8 \
 -Dbatch.size=$batchSize \
 -Dapp.mail.title=$emailTitle \
 -Dapp.mail.to=$emailTo -Dmail.host=mail.chinacscs.com -Dmail.smtp.auth=true \
 -Dmail.user=dataservice@chinacscs.com -Dmail.password=1qaz@WSX -Dmail.transport.protocol=smtp \
  Update $localDir  $serverDir  $workDir $neo4jUri $loadedTime $neo4jUser $neo4jPassword  > /dev/null 2>&1 &

