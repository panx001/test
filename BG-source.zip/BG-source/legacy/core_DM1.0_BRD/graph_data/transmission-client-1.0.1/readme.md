# 增量更新程序部署
v1.0.1

该版本核心逻辑不变（仍然是1.0版本）
## 主要提升
1. 旧的文件传输可能抛异常，新的有优化（@江杰维护的）
2. 可以定时汇报状态：
1.0.0版本只会在更新完成或者出现异常的时候发送邮件，但是图谱更新如果停止了就不知道什么状态了。


## 程序压缩包获取
1. 进入到项目根目录，执行打包命令:
install -Dmaven.test.skip=true -Puat
或者
install -Dmaven.test.skip=true -Psit

2. 到该项目根目录/target下拷贝transmission-client.zip到服务器

## 程序安装启动
1. 将transmission-client.zip拷贝到安装目录
2. 执行unzip transmission-client.zip解压缩命令
3. 进入到 安装目录/ transmission-client 目录下
4. 创建 安装目录/ transmission-client/meta目录，(存放程序处理元信息)
5. 创建 安装目录/ transmission-client/workspace目录,(存放远程下载文件)
6. 修改 安装目录/ transmission-client/config/application.properties文件中需要修改的对应配置项
7. 修改 安装目录/ transmission-client/config/logback-custom.xml日志配置
8. 确认和调整 安装目录/ transmission-client/bin/service.sh脚本jvm 相关配置项
9.
   如果更新程序与图谱运行服务器没有在一个服务器上：
            通过mount让图谱服务器的neo4j_csv文件夹与本地的neo4j_csv文件夹保持一致。换言之，${app.graphload.neo4jServerCsvDir} 要与${app.download.localGraphDir}的内容一致。
            mount文件夹不要删除，可能犯的错误是部署新的程序时将neo4j_csv文件夹删了又新建。
   如果更新程序与图谱运行服务器在一个服务器上：
            注意application.properties的本地neo4j_csv与图谱服务器neo4j_csv路径一致
10. 在 安装目录/ transmission-client 目录下，执行./bin/service.sh start 启动系统 (可能需要sudo su -)
11. 验证 同步作业是否正常运行:
tail -f 查看log是否正常。

## 程序停止

1. 执行./bin/service.sh stop
2. 如果停不下来可以 netstat -tunlp | grep 8080 找到占用的PID然后kill

## v1.0.1 异常处理方式

遇到异常不能自动恢复在修复问题后，从邮件里找到task id 和batch id 执行两个命令来改变任务状态
curl -X PUT \
  'http://(server ip):8080/tasks/(task id)/status?status=LOCK' \
  -H 'Postman-Token: 2d4bcb0e-e8b5-4609-9d84-44fa2aa921c0' \
  -H 'cache-control: no-cache'
curl -X PUT \
  'http://(server ip):8080/tasks/(task id)/status?status=LOCK' \
  -H 'Postman-Token: ba509678-515d-4e49-a7cf-78faf440291b' \
  -H 'cache-control: no-cache'

例如：
curl -X PUT \
  'http://10.100.44.77:8080/tasks/1113635595638276096/status?status=LOCK' \
  -H 'Postman-Token: 2d4bcb0e-e8b5-4609-9d84-44fa2aa921c0' \
  -H 'cache-control: no-cache'

curl -X PUT \
  'http://10.100.44.77:8080/batchs/1113447523042721792/status?status=LOCK' \
  -H 'Postman-Token: ba509678-515d-4e49-a7cf-78faf440291b' \
  -H 'cache-control: no-cache'

## 账号密码以及服务器信息

标准产品相关：
**10.100.45.42服务器** 的图谱账号是neo4j  密码是neo4j 图谱部署在/app/neo4japp/neo4j-enterprise-3.5.1 更新程序部署在/app/transmission-client 管理员权限 appadmin AppNsr@2018#
**10.100.45.43服务器** 的图谱账号是neo4j  密码是temp 图谱部署在/app/neo4j/neo4j-enterprise-3.5.1 更新程序部署在/app/transmission-client 管理员权限 appadmin AppNsr@2018#

证监会项目：
**10.100.44.77** 更新调度程序。程序安装目录/app/transmission-client/ （/app/test_by_mohaoran/transmission-client）
**10.100.45.51** 图谱neo4j服务器/opt/neo4j52/neo4j-community-3.5.2  管理员权限 appadmin CscsApp@2019#1

