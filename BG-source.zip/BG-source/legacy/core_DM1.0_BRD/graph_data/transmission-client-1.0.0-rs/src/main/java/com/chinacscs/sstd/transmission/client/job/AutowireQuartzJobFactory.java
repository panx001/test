//package com.chinacscs.sstd.transmission.client.job;
//
//import org.quartz.spi.TriggerFiredBundle;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
//import org.springframework.scheduling.quartz.AdaptableJobFactory;
//import org.springframework.stereotype.Component;
//import org.springframework.util.ReflectionUtils;
//
//import com.chinacscs.sstd.transmission.client.entity.JobConfig;
//
///**
// * @author: liusong
// * @date: 2018年12月20日
// * @email: 359852326@qq.com
// * @version:
// * @describe: //TODO
// */
//@Component
//public class AutowireQuartzJobFactory extends AdaptableJobFactory {
//
//	@Autowired
//	private AutowireCapableBeanFactory capableBeanFactory;
//	
////	@Autowired
////	private ConfigurableApplicationContext configurableApplicationContext;
//
//	@Override
//	protected Object createJobInstance(TriggerFiredBundle bundle) throws Exception {
//		JobConfig jobConfig = (JobConfig) bundle.getJobDetail().getJobDataMap()
//				.get(QuartzSchedulerFactory.JOB_CONFIG_KEY);
//		Class<?> clz = Class.forName(jobConfig.getClassName());
//		Object jobInstance = ReflectionUtils.accessibleConstructor(clz, JobConfig.class)
//				.newInstance(jobConfig);
//		capableBeanFactory.autowireBean(jobInstance);
//		return jobInstance;
//	}
//}
