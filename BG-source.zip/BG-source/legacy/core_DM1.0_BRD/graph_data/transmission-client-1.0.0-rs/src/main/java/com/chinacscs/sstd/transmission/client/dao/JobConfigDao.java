package com.chinacscs.sstd.transmission.client.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.chinacscs.platform.commons.dao.BaseDao;
import com.chinacscs.sstd.transmission.client.entity.JobConfig;

/**
 * @author:  liusong
 * @date:    2019年2月14日
 * @email:   359852326@qq.com
 * @version: 
 * @describe: //TODO
 */
@Mapper
public interface JobConfigDao extends BaseDao<JobConfig>{

	JobConfig getByName(String name);
	
	List<JobConfig> listAll();
	
	int deleteByName(String name);
	
	int deleteAll();
}
