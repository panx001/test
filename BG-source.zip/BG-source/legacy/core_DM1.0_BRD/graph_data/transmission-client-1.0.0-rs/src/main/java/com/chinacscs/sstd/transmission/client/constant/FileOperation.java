package com.chinacscs.sstd.transmission.client.constant;


/**
 * @author:  liusong
 * @date:    2019年2月18日
 * @email:   359852326@qq.com
 * @version: 
 * @describe: //TODO
 */
public enum FileOperation {

	/**更新插入**/
	UPSERT,
	
	/**删除**/
	DEL;
}
