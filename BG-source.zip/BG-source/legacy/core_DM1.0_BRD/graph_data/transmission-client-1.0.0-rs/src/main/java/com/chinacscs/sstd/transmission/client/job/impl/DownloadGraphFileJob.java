package com.chinacscs.sstd.transmission.client.job.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.chinacscs.sstd.transmission.client.download.DownloadService;
import com.chinacscs.sstd.transmission.client.entity.JobConfig;
import com.chinacscs.sstd.transmission.client.job.AbstractWorker;

/**
 * @author: liusong
 * @date: 2019年2月15日
 * @email: 359852326@qq.com
 * @version:
 * @describe: 下载图谱文件
 */
public class DownloadGraphFileJob extends AbstractWorker {
	@Autowired
	private DownloadService syncService;

	public DownloadGraphFileJob(JobConfig jobConfig) {
		super(jobConfig);
	}

	@Override
	protected void doExecute() throws Exception {
		syncService.downloadGraphFile();
	}
}