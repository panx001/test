package com.chinacscs.sstd.transmission.client.util;


/**
 * @author:  liusong
 * @date:    2019年2月21日
 * @email:   359852326@qq.com
 * @version: 
 * @describe: //TODO
 */
public interface DatetimeFormats {

	String yyyyMMddhhmmssSSS="yyyyMMddhhmmssSSS";
}
