package com.chinacscs.sstd.transmission.client.component;

/**
 * @param
 * @author jiangjie
 * @return
 * @date 2019/2/16 12:35
 * @description TODO
 */
public interface EmailService {

	/**
	 * 发送简单邮件
	 * 
	 * @param sendTo
	 *            收件人地址
	 * @param subject
	 *            邮件标题
	 * @param content
	 *            邮件内容
	 * @param cc
	 *            抄送人地址
	 */
	void sendSimpleMail(String sendTo, String subject, String content, String... cc);

	/**
	 * send email, never throwing an exception
	 * @param sendTo  目标邮箱地址
	 * @param subject 主题
	 * @param content 内容
	 */
	void sendQuietly(String subject, String content);
	
	/**
	 * send email, never throwing an exception
	 * @param sendTo  目标邮箱地址
	 * @param subject 主题
	 * @param content 内容
	 */
	void sendQuietly(String sendTo, String subject, String content);
}
