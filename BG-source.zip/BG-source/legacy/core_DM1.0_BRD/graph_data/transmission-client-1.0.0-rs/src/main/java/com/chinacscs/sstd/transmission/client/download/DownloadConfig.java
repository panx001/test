package com.chinacscs.sstd.transmission.client.download;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import lombok.Data;

/**
 * @author flackyang
 * @date 2019/2/15 15:59
 * @description TODO @copyright(c) chinacscs all rights reserved
 */
@Component
@ConfigurationProperties(prefix = "app.download")
@Data
public class DownloadConfig {

	private String sftpHost;

    private Integer sftpPort;

    private String sftpUser;

    private String sftpPassword;

    private String sftpGsDir;

    private String sftpGraphDir;

    private String localGsDir;

    private String localGraphDir;

    private String sendTo;

    private String dataDirName;

    private String metaDirName;
    
    private String insertDirName;
    
    private String deleteDirName;
    
    private String finishDirName;
}
