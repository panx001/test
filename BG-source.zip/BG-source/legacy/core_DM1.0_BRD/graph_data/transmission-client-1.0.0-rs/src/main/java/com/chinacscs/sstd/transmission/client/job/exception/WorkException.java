package com.chinacscs.sstd.transmission.client.job.exception;

/**
 * @author: liusong
 * @date: 2019年3月1日
 * @email: 359852326@qq.com
 * @version:
 * @describe: //TODO
 */
@SuppressWarnings("serial")
public class WorkException extends RuntimeException {

	public WorkException() {
		super();
	}

	public WorkException(String message) {
		super(message);
	}

	public WorkException(Throwable cause) {
		super(cause);
	}

	public WorkException(String message, Throwable cause) {
		super(message, cause);
	}
}