package com.chinacscs.sstd.transmission.client.job;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;

import com.chinacscs.sstd.transmission.client.entity.JobConfig;

/**
 * @author: liusong
 * @date: 2019年2月17日
 * @email: 359852326@qq.com
 * @version:
 * @describe: //TODO
 */
@Component
public class WorkerFactory {

	final static Logger log = LoggerFactory.getLogger(WorkerFactory.class);

	@Autowired
	private AutowireCapableBeanFactory capableBeanFactory;

	// @Autowired
	// private ConfigurableApplicationContext configurableApplicationContext;

	@SuppressWarnings("unchecked")
	public Worker createWorker(JobConfig jobConfig) throws Exception {
		Class<Worker> clz = (Class<Worker>) Class.forName(jobConfig.getClassName());
		Worker worker = ReflectionUtils.accessibleConstructor(clz, JobConfig.class)
				.newInstance(jobConfig);
		capableBeanFactory.autowireBean(worker);
		return worker;
	}
}
