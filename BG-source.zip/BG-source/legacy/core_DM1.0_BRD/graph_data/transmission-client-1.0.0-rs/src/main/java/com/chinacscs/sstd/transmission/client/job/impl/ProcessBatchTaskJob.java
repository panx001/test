package com.chinacscs.sstd.transmission.client.job.impl;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.elasticsearch.action.DocWriteResponse.Result;
import org.elasticsearch.action.delete.DeleteRequest;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.xcontent.XContentType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.chinacscs.platform.commons.util.JsonUtils;
import com.chinacscs.sstd.transmission.client.component.EmailService;
import com.chinacscs.sstd.transmission.client.constant.BatchStatus;
import com.chinacscs.sstd.transmission.client.constant.BatchTaskStatus;
import com.chinacscs.sstd.transmission.client.constant.FileOperation;
import com.chinacscs.sstd.transmission.client.dao.BatchDao;
import com.chinacscs.sstd.transmission.client.dao.BatchTaskDao;
import com.chinacscs.sstd.transmission.client.entity.Batch;
import com.chinacscs.sstd.transmission.client.entity.BatchTask;
import com.chinacscs.sstd.transmission.client.entity.JobConfig;
import com.chinacscs.sstd.transmission.client.job.AbstractWorker;
import com.chinacscs.sstd.transmission.client.job.exception.WorkException;

import lombok.extern.slf4j.Slf4j;

/**
 * @author: liusong
 * @date: 2019年2月14日
 * @email: 359852326@qq.com
 * @version:
 * @describe: 处理data目录数据文件job
 */
@Slf4j
public class ProcessBatchTaskJob extends AbstractWorker {

	private final static String DEFAULT_INDEX_TYPE = "doc";

	@Value("${app.job.processBatchTaskJob.lockMaxSize:500}")
	private int lockMaxSize;

	@Autowired
	private BatchDao batchDao;

	@Autowired
	private BatchTaskDao batchTaskDao;

	@Autowired
	private RestHighLevelClient restHighLevelClient;

	private final static int SEND_RETRY_COUNT_MAX = 3;

	private final static long DEFAULT_REST_TIME = 3000L;

	private static Map<Long, BatchTask> lockSet = new ConcurrentHashMap<>();

	private static volatile Batch globalCurrentBatch;

	public ProcessBatchTaskJob(JobConfig jobConfig) {
		super(jobConfig);
	}

	@Override
	protected void doExecute() throws Exception {
		BatchTask currentBatchTask = checkAndlookupBatchTask(batchDao, batchTaskDao,
				getEmailService());
		if (null != currentBatchTask) {
			log.info(String.format("Start process Batch[%s]'s task[%s]",
					globalCurrentBatch.getCode(), currentBatchTask.getFileName()));
			BatchTask finalCurrentBatchTask = currentBatchTask;
			DataProcess dataProcess = buildDataProcess(finalCurrentBatchTask);
			try {
				LineIterator lineIterator = FileUtils
						.lineIterator(new File(finalCurrentBatchTask.getFilePath()), "utf-8");
				AtomicInteger readLineIndex = new AtomicInteger(-1);
				lineIterator.forEachRemaining(dataJson -> {
					if (getStatus() == Status.STOP) {
						throw new StopException();
					}
					int doLines = finalCurrentBatchTask.getLockOffset()
							+ finalCurrentBatchTask.getLockLength();
					if (readLineIndex.incrementAndGet() >= doLines) {
						Map<String, Object> data = JsonUtils.jsonToMap(dataJson);
						int sendRetryCount = 0;
						while (sendRetryCount++ < SEND_RETRY_COUNT_MAX)
							try {
								dataProcess.process(finalCurrentBatchTask, data);
								break;
							} catch (IOException exception) {
								log.error(String.format(
										"Exceptional process line[%s] of batch[%s]'s task[%s]",
										dataJson, globalCurrentBatch.getCode(),
										currentBatchTask.getFileName()), exception);
								if (sendRetryCount == SEND_RETRY_COUNT_MAX) {
									throw new StopException();
								} else {
									try {
										Thread.sleep(DEFAULT_REST_TIME);
									} catch (InterruptedException e) {
										// 忽略异常
									}
								}
							} catch (Exception exception) {
								throw new RuntimeException(String.format(
										"Exceptional process line[%s] of batch[%s]'s task[%s]",
										dataJson, globalCurrentBatch.getCode(),
										currentBatchTask.getFileName()), exception);
							}
						finalCurrentBatchTask
								.setLockLength(finalCurrentBatchTask.getLockLength() + 1);
						if (finalCurrentBatchTask.getLockLength() >= lockMaxSize
								|| !lineIterator.hasNext()) {
							finalCurrentBatchTask
									.setLockOffset(finalCurrentBatchTask.getLockOffset()
											+ finalCurrentBatchTask.getLockLength());
							finalCurrentBatchTask.setLockLength(0);
							batchTaskDao.updateLockOffsetAndLength(finalCurrentBatchTask.getId(),
									finalCurrentBatchTask.getLockOffset(),
									finalCurrentBatchTask.getLockLength());
							log.info(String.format(
									"Successful process %s lines of Batch[%s]'s task[%s]",
									finalCurrentBatchTask.getLockOffset(),
									globalCurrentBatch.getCode(), currentBatchTask.getFileName()));
						}
					}
				});
				batchTaskDao.updateStatus(finalCurrentBatchTask.getId(), BatchTaskStatus.FINISH);
				log.info(String.format("Successful process Batch[%s]'s task[%s]",
						globalCurrentBatch.getCode(), currentBatchTask.getFileName()));
			} catch (StopException exception) {
				log.info("The current worker[{}] has been call stop", getName());
			} catch (Exception exception) {
				StringBuilder errorMsgBd = new StringBuilder();
				String titile = String.format("Exceptional process Batch[%s]'s task[%s]",
						globalCurrentBatch.getCode(), currentBatchTask.getFileName());
				errorMsgBd.append(titile).append("\n");
				errorMsgBd.append("------------------error msg----------------------").append("\n");
				String stackTraceMsg = ExceptionUtils.getStackTrace(exception);
				errorMsgBd.append(stackTraceMsg);
				String errorMsg = errorMsgBd.toString();
				batchTaskDao.updateStatusAndErrorMsg(finalCurrentBatchTask.getId(),
						BatchTaskStatus.ERROR, errorMsg);
				throw new WorkException(errorMsg, exception);
			} finally {
				lockSet.remove(finalCurrentBatchTask.getId());
			}
		}
	}

	class StopException extends RuntimeException {

		/**
		 * 
		 */
		private static final long serialVersionUID = -7787535726246197156L;

	}
	private synchronized static BatchTask checkAndlookupBatchTask(BatchDao batchDao,
			BatchTaskDao batchTaskDao, EmailService emailService) {
		Batch currentBatch = batchDao.getEarliestByStatus(BatchStatus.TASK_LOCK);
		if (null == currentBatch) {
			log.info("There is not Batch need to be processed");
			return null;
		}
		if (null == globalCurrentBatch) {
			globalCurrentBatch = currentBatch;
		} else if (!globalCurrentBatch.getId().equals(currentBatch.getId())) {
			return null;
		}
		BatchTask errorBatchTask = batchTaskDao
				.getEarliestByBatchCodeAndStatus(currentBatch.getCode(), BatchTaskStatus.ERROR);
		if (null != errorBatchTask) {
			String title = String.format(
					"There is error Batch[%s]'s task[%s] that please first check its related file[%s]",
					currentBatch.getCode(), errorBatchTask.getId(), errorBatchTask.getFileName());
			log.warn(title);
			if (0 == errorBatchTask.getNoticeCount()) {
				emailService.sendQuietly(title, errorBatchTask.getErrorMsg());
				batchTaskDao.updateNoticeCount(errorBatchTask.getId(),
						errorBatchTask.getNoticeCount() + 1);
			}
			return null;
		}
		List<BatchTask> lockBatchTasks = batchTaskDao
				.listByBatchCodeAndStatus(currentBatch.getCode(), BatchTaskStatus.LOCK);
		for (BatchTask item : lockBatchTasks) {
			// 有MetaFile正在处理，为了保证数据一致性，不能支持并发，也不需要支持并发
			if (!lockSet.containsKey(item.getId())) {
				// 有可能是系统异常中断导致,需要重新修正状态
				batchTaskDao.updateStatus(item.getId(), BatchTaskStatus.NEW);
			}
		}
		List<BatchTask> newBatchTasks = batchTaskDao
				.listByBatchCodeAndStatus(currentBatch.getCode(), BatchTaskStatus.NEW);
		if (null == newBatchTasks || newBatchTasks.isEmpty()) {
			List<BatchTask> checkBatchTasks = batchTaskDao.listByBatchCode(currentBatch.getCode());
			boolean isAllFinish = true;
			for (BatchTask item : checkBatchTasks) {
				if (BatchTaskStatus.FINISH != item.getStatus()) {
					isAllFinish = false;
					break;
				}
			}
			if (isAllFinish) {
				batchDao.updateStatus(currentBatch.getId(), BatchStatus.FINISH);
				String msg = String.format(
						"Successful process %s tasks of batch[%s] and this batch's task is all finished",
						checkBatchTasks.size(), globalCurrentBatch.getCode());
				globalCurrentBatch = null;
				log.info(msg);
			}
			return null;
		}
		BatchTask currentBatchTask = newBatchTasks.get(0);
		batchTaskDao.updateStatus(currentBatchTask.getId(), BatchTaskStatus.LOCK);
		lockSet.put(currentBatchTask.getId(), currentBatchTask);
		return currentBatchTask;
	}

	private DataProcess buildDataProcess(BatchTask dataFile) {
		DataProcess dataProcess = null;
		if (FileOperation.UPSERT == dataFile.getOperation()) {
			dataProcess = this::doProcessForAdd;
		} else {
			dataProcess = this::doProcessForDel;
		}
		return dataProcess;
	}

	private void doProcessForAdd(BatchTask dataFile, Map<String, Object> source)
			throws IOException {
		Map<String, Object> data = convert(source, dataFile.getTableName());
		String id = (String) data.get("id");
		IndexRequest indexRequest = new IndexRequest(dataFile.getTableName(), DEFAULT_INDEX_TYPE);
		indexRequest.id(id);
		indexRequest.source(JsonUtils.toJsonString(data), XContentType.JSON);
		IndexResponse indexResponse = restHighLevelClient.index(indexRequest,
				RequestOptions.DEFAULT);
		Result code = indexResponse.getResult();
		if (Result.CREATED == code) {
			log.debug(String.format("Successful add data[%s] to the type[%s] of index[%s]", id,
					DEFAULT_INDEX_TYPE, dataFile.getTableName()));
		} else if (Result.UPDATED == code) {
			log.debug(String.format("Successful update data[%s] to the type[%s] of index[%s]", id,
					DEFAULT_INDEX_TYPE, dataFile.getTableName()));
		} else {
			throw new RuntimeException(
					String.format("Failed to add data[%s] to the type[%s] of index[%s]", id,
							DEFAULT_INDEX_TYPE, dataFile.getTableName()));
		}
	}

	private void doProcessForDel(BatchTask dataFile, Map<String, Object> source)
			throws IOException {
		Map<String, Object> data = convert(source, dataFile.getTableName());
		String id = (String) data.get("id");
		DeleteRequest deleteRequest = new DeleteRequest(dataFile.getTableName(), "doc", id);
		DeleteResponse deleteResponse = restHighLevelClient.delete(deleteRequest,
				RequestOptions.DEFAULT);
		if (Result.DELETED != deleteResponse.getResult()
				&& Result.NOT_FOUND != deleteResponse.getResult()) {
			throw new RuntimeException(
					String.format("Failed to delete data[%s] from the type[%s] of index[%s]", id,
							DEFAULT_INDEX_TYPE, dataFile.getTableName()));
		}
		log.debug(String.format("Successful delete data[%s] from the type[%s] of index[%s]", id,
				DEFAULT_INDEX_TYPE, dataFile.getTableName()));
	}

	private Map<String, Object> convert(Map<String, Object> source, String tableName) {
		switch (tableName) {
			case "company_risk_search" :
				source.put("id", source.get("risk_id"));
				break;
			case "company_credit_search" :
				source.put("id", source.get("credit_id"));
				break;
			default :
				source.put("id", source.get("company_id"));
				break;
		}
		return source;
	}

	@FunctionalInterface
	interface DataProcess {
		void process(BatchTask dataFile, Map<String, Object> data) throws IOException;
	}
}
