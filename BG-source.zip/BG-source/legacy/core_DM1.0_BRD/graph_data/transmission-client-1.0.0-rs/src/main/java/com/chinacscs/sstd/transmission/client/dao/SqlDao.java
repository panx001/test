package com.chinacscs.sstd.transmission.client.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

/**
 * @author: liusong
 * @date: 2018年12月27日
 * @email: 359852326@qq.com
 * @version:
 * @describe: //TODO
 */
@Mapper
public interface SqlDao {

	@Update("${script}")
	int execute(@Param("script") String script);
}
