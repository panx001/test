package com.chinacscs.sstd.transmission.client.graphload;

import com.chinacscs.sstd.transmission.client.component.EmailService;
import com.chinacscs.sstd.transmission.client.download.DownloadConfig;
import org.apache.commons.io.FileUtils;
import org.neo4j.driver.v1.AuthTokens;
import org.neo4j.driver.v1.Driver;
import org.neo4j.driver.v1.GraphDatabase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author flackyang
 * @date 2019/2/19 15:53
 * @description TODO
 * @copyright(c) chinacscs all rights reserved
 */
@Service
public class GraphLoadService {
    private final static Logger log = LoggerFactory.getLogger(GraphLoadService.class);
    @Value("${app.download.localGraphDir}")
    private String localGraphCsvDir;
    @Value("${app.graphload.neo4jServerCsvDir}")
    private String neo4jServerCsvDir;
    @Value("${app.graphload.updateWorkDir}")
    private String updateWorkDir;
    @Value("${app.graphload.uri}")
    private String uri;
    @Value("${app.graphload.timestamp}")
    private String initTimeStamp;
    @Value("${app.graphload.neo4jUser}")
    private String neo4jUser;
    @Value("${app.graphload.neo4jPwd}")
    private String neo4jPW;
    @Autowired
    private EmailService emailService;
    @Autowired
    private DownloadConfig syncConfig;

    public void loadGraphFile(){

//        SimpleDateFormat ft = new SimpleDateFormat("yyyyMMddhhmmss");
        String sep = ";";
        PathHandler pathHandler = null;
        try{
            pathHandler = new PathHandler(localGraphCsvDir,neo4jServerCsvDir, updateWorkDir);
        }catch (IllegalStateException exception){
            log.warn(exception.getMessage());
            return;
        }

        Path sftpLogsDir = pathHandler.getPath("sftpLogsDir");
        Path updateFinish = pathHandler.getPath("updateFinish");
        Path ins =pathHandler.getPath("ins");
        Path del = pathHandler.getPath("del");
        Path finish = pathHandler.getPath("finish");
        Path initCsvList = pathHandler.getPath("initCsvList");
        StringBuilder emailContextBuilder = new StringBuilder();

        List<String> initPart = new ArrayList<>();
        try{
            if(initCsvList!=null){
                initPart = FileUtils.readLines(initCsvList.toFile(),"utf-8");
            }
        }catch (Exception e){
            log.info("initPart获取失败");
        }


        if (!sftpLogsDir.toFile().exists()) {
            if (!sftpLogsDir.toFile().mkdirs()) {
                log.info("请手动创建update_logs文件夹");
            }
        }

        //计算本次更新范围
        List<String> downloadFinishDates;
        List<String> updateFinishDates;
        downloadFinishDates = Arrays.stream(Objects.requireNonNull(finish.toFile().list())).map(name -> name.replace("download.", "").replace(".finish", "").replace("finish.", "")).collect(Collectors.toList());

        try {
            updateFinishDates = Arrays.stream(updateFinish.toFile().list()).map(name -> name.replace("finish.", "")).collect(Collectors.toList());
            if (updateFinishDates.size()==0){
                updateFinishDates.add(initTimeStamp);
            }
        } catch (Exception e) {
            log.info(e.getMessage());
            updateFinishDates = new ArrayList<String>();
            updateFinishDates.add("19000000000000");
        }

        String maxUpdateFinish;
        String maxDownloadFinish;
        String minDownloadAfterUpdate;
        try {
            maxDownloadFinish = (String) downloadFinishDates.stream().max(String::compareToIgnoreCase).get();
            maxUpdateFinish = (String) updateFinishDates.stream().max(String::compareToIgnoreCase).get();
            if(maxDownloadFinish.compareTo(maxUpdateFinish)<=0){
                log.info("没有需要更新的文件："+maxUpdateFinish+""+maxDownloadFinish);
                return;
            }
            minDownloadAfterUpdate = downloadFinishDates.stream().filter(e->e.compareTo(maxUpdateFinish)>0).min(String::compareToIgnoreCase).get();
            log.info("最近一次完整下载csv文件时间:" + maxDownloadFinish + "最近一批更新时间"+minDownloadAfterUpdate+"\n上次更新图谱时间:" + maxUpdateFinish);
        } catch (Exception e) {
            log.error( "获取上次更新时间出错:", e.getMessage());
            return;
        }

        //将最小未更新时间赋值给最大下载时间戳
        maxDownloadFinish = minDownloadAfterUpdate;

        log.info("更新时间段从" + maxUpdateFinish + "至" + maxDownloadFinish + "(含)");
        emailContextBuilder.append("更新时间段从" + maxUpdateFinish + "至" + maxDownloadFinish + "(含)\n");
        List<CsvFile> tobeUpdatedCsv = new ArrayList<>();
        String[] insDirList = (String[]) Objects.requireNonNull(ins.toFile().list());
        String[] delDirList = (String[]) Objects.requireNonNull(del.toFile().list());

        for (String dirName : insDirList) {
            File eachCsvDir = Paths.get(ins.toAbsolutePath().toString(), dirName).toFile();
            if (!eachCsvDir.isDirectory()) {
                break;
            }
            /*至少存在初始化的文件，所以不能为空*/
            for (String s : eachCsvDir.list()) {
                try {
                    String sftpCsvPath = Paths.get(eachCsvDir.getAbsolutePath(), s).toAbsolutePath().toString();
                    File sftpCsvFile = new File(sftpCsvPath);
                    CsvFile neo4jCsvFile;
                    if(sftpCsvFile.exists()){
                        neo4jCsvFile = new CsvFile(sftpCsvPath,pathHandler.getPathOnNeo4jServer(sftpCsvPath),sftpCsvFile.getName(), true, false);
                        if (neo4jCsvFile.isInRange(maxUpdateFinish, maxDownloadFinish) && !initPart.contains(neo4jCsvFile.fileName)) {
                            tobeUpdatedCsv.add(neo4jCsvFile);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    log.error(e.toString());
                }
            }
        }
        for (String dirName : delDirList) {
            File eachCsvDir = Paths.get(del.toAbsolutePath().toString(), dirName).toFile();
            if (!eachCsvDir.isDirectory()) {
                break;
            }
            // 可以没有要删除的csv
            for (String s : eachCsvDir.list()) {
                try {
                    String sftpCsvPath = Paths.get(eachCsvDir.getAbsolutePath(), s).toAbsolutePath().toString();
                    File sftpCsvFile = new File(sftpCsvPath);
                    CsvFile neo4jCsvFile;
                    if(sftpCsvFile.exists()){
                        neo4jCsvFile = new CsvFile(sftpCsvPath,pathHandler.getPathOnNeo4jServer(sftpCsvPath),sftpCsvFile.getName(), false, false);
                        if (neo4jCsvFile.isInRange(maxUpdateFinish, maxDownloadFinish) && !initPart.contains(neo4jCsvFile.fileName)) {
                            tobeUpdatedCsv.add(neo4jCsvFile);
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage());
                }
            }
        }

        if(tobeUpdatedCsv.size()==0){
            log.info("没有要更新的文件");
            File updateFinishTime = new File(updateFinish.toAbsolutePath().toString(), "finish." + maxDownloadFinish);
            if (!updateFinishTime.exists()) {
                try {
                    updateFinishTime.createNewFile();
                } catch (Exception e) {
                    log.error(e.getMessage() + "创建更新完成时间戳失败，必须成功");
                }
            }
            return;
        }
        Collections.sort(tobeUpdatedCsv);

        log.info(tobeUpdatedCsv.stream().map(i -> i.fileName + " " + i.isInsert + " ").collect(Collectors.joining("\n")));

        Driver driver = GraphDatabase.driver(uri, AuthTokens.basic(neo4jUser, neo4jPW));
        try {
            UpdateExecute updateExecute = UpdateExecute.getInstance(pathHandler);

            if (updateExecute.run(tobeUpdatedCsv, driver, log, 4000, 400000)) {
                File updateFinishTime = new File(updateFinish.toAbsolutePath().toString(), "finish." + maxDownloadFinish);
                if (!updateFinishTime.exists()) {
                    try {
                        updateFinishTime.createNewFile();
                    } catch (Exception e) {
                        log.error(e.getMessage() + "创建更新完成时间戳失败，必须成功");
                    }
                }
                StringBuilder sb = new StringBuilder();
                for (CsvFile csvFile : tobeUpdatedCsv) {
                    sb.append(csvFile.fileName + ": " + csvFile.updateResult + "\n" + csvFile.getResultMapValueAsLine() + "\n");
                }
                emailService.sendSimpleMail(syncConfig.getSendTo(),"增量更新成功",sb.toString());
            } else {
                StringBuilder sb = new StringBuilder();
                for (CsvFile csvFile : tobeUpdatedCsv) {
                    sb.append(csvFile.fileName + ": " + csvFile.updateResult + "\n" + csvFile.getResultMapValueAsLine() + "\n");
                }
                emailService.sendSimpleMail(syncConfig.getSendTo(), "增量更新图谱预警", sb.toString());
            }
        }
        finally {
            driver.close();
        }

    }
}
