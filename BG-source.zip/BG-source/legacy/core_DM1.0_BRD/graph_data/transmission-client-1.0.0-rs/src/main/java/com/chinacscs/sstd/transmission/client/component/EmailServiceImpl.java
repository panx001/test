package com.chinacscs.sstd.transmission.client.component;

import lombok.extern.slf4j.Slf4j;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

/**
 * @param
 * @author jiangjie
 * @return
 * @date 2019/2/16 12:36
 * @description TODO
 */
@Service
@Slf4j
public class EmailServiceImpl implements EmailService {

	@Value("${app.admin.email.address}")
	private String adminEmailAddr;
	
	private String mainAdminEmailAddr;
	
	private String[] ccAdminEmailAddrs;

	@Value("${spring.mail.username}")
	private String sendFrom;

	@Autowired
	private JavaMailSender mailSender;

	static {
		System.setProperty("mail.mime.splitlongparameters", "false");
	}

	@PostConstruct
	private void init() {
		String[] temp=StringUtils.split(adminEmailAddr, ";");
		mainAdminEmailAddr=temp[0];
		if(temp.length>1) {
			ccAdminEmailAddrs=new String[temp.length-1];
			for(int i=1;i<temp.length;i++) {
				ccAdminEmailAddrs[i-1]=temp[i];
			}
		}
	}
	
	@Override
	public void sendSimpleMail(String sendTo, String subject, String content, String... cc) {
		try {
			SimpleMailMessage message = new SimpleMailMessage();
			message.setFrom(sendFrom);
			message.setTo(sendTo);
			message.setSubject(subject);
			message.setText(content);
			message.setCc(cc);
			mailSender.send(message);
		} catch (Exception e) {
			log.error("邮件发送失败", e);
		}
	}

	@Override
	public void sendQuietly(String subject, String content) {
		try {
			SimpleMailMessage message = new SimpleMailMessage();
			message.setFrom(sendFrom);
			message.setTo(mainAdminEmailAddr);
			if(null!=ccAdminEmailAddrs) {
				message.setCc(ccAdminEmailAddrs);
			}
			message.setSubject(subject);
			message.setText(content);
			mailSender.send(message);
		} catch (Exception exception) {
			log.error(String.format("Exceptional send email[%s] to target[%s]", subject,
					adminEmailAddr), exception);
		}
	}

	@Override
	public void sendQuietly(String sendTo, String subject, String content) {
		try {
			SimpleMailMessage message = new SimpleMailMessage();
			message.setFrom(sendFrom);
			message.setTo(sendTo);
			message.setSubject(subject);
			message.setText(content);
			mailSender.send(message);
		} catch (Exception exception) {
			log.error(String.format("Exceptional send email[%s] to target[%s]", subject, sendTo),
					exception);
		}
	}
}
