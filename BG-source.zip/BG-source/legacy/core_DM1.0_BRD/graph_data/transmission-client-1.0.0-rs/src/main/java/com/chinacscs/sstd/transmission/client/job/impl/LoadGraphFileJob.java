package com.chinacscs.sstd.transmission.client.job.impl;

import com.chinacscs.sstd.transmission.client.entity.JobConfig;
import com.chinacscs.sstd.transmission.client.graphload.GraphLoadService;
import com.chinacscs.sstd.transmission.client.job.AbstractWorker;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author flackyang
 * @date 2019/2/19 16:52
 * @description 图谱文件加载job
 * @copyright(c) chinacscs all rights reserved
 */
@Slf4j
public class LoadGraphFileJob extends AbstractWorker {

    @Autowired
    private GraphLoadService graphLoadService;

    public LoadGraphFileJob(JobConfig jobConfig) {
        super(jobConfig);
    }

    @Override
    protected void doExecute() throws Exception {
        log.info("开始进行图谱文件的加载");
        graphLoadService.loadGraphFile();
        log.info("图谱文件加载完成");
    }
}
