package com.chinacscs.sstd.transmission.client.config;

import com.chinacscs.platform.commons.component.IdGenerator;
import com.chinacscs.platform.commons.component.LocalSnowflakeIdGenerator;
import com.chinacscs.platform.commons.dao.interceptor.IdGeneratorMybatisInterceptor;
//import com.chinacscs.sstd.transmission.client.component.RestHighLevelClientFactory;

import java.io.File;
import java.util.UUID;

import javax.annotation.PostConstruct;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

/**
 * @author: liusong
 * @date: 2019年2月19日
 * @email: 359852326@qq.com
 * @version:
 * @describe: //TODO
 */
@Configuration
public class AppConfig {

	/** 系统启动uuid **/
	public static final String SYSTEM_UUID = UUID.randomUUID().toString();

	@Value("${app.workspace.path}")
	private String workspacePath;
	
/*	@Value("${app.es.addrs}")
	private String esAddrsStr;*/

	@Autowired
	private IdGenerator globalIdGenerator;
	
	@PostConstruct
	private void init() throws Exception {
		FileUtils.forceMkdir(new File(workspacePath));
	}

/*	@Bean(destroyMethod = "close")
	public RestHighLevelClient initRestHighLevelClient() {
		String[] esAddrs = StringUtils.split(esAddrsStr, ";");
		HttpHost[] httpHosts = new HttpHost[esAddrs.length];
		for (int i = 0; i < esAddrs.length; i++) {
			String esAddr = esAddrs[i];
			String[] temp = StringUtils.split(esAddr, ":");
			httpHosts[i] = new HttpHost(temp[0], Integer.valueOf(temp[1]));
		}
		return RestHighLevelClientFactory.build(httpHosts);
	}*/

	@Bean(initMethod = "init", destroyMethod = "close")
	public IdGenerator initGlobalIdGenerator() {
		return new LocalSnowflakeIdGenerator();
	}

	@Bean
	public IdGeneratorMybatisInterceptor initGlobalIDMybatisInterceptor() {
		return new IdGeneratorMybatisInterceptor(globalIdGenerator);
	}
	
	@Bean
	public RestTemplate initRestTemplate() {
		return new RestTemplate();
	}
}
