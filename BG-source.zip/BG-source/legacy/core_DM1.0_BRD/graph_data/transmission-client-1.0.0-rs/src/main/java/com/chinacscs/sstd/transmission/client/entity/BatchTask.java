package com.chinacscs.sstd.transmission.client.entity;

import com.chinacscs.platform.commons.entity.BaseEntity;
import com.chinacscs.sstd.transmission.client.constant.BatchTaskStatus;
import com.chinacscs.sstd.transmission.client.constant.DataProtocol;
import com.chinacscs.sstd.transmission.client.constant.FileOperation;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @author:  liusong
 * @date:    2019年2月15日
 * @email:   359852326@qq.com
 * @version: 
 * @describe: //TODO
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class BatchTask extends BaseEntity{
	
	/**批次code**/
	private Long batchCode;
	
	/**顺序号**/
	private Integer seq;
	
	/**状态**/
	private BatchTaskStatus status;
	
	/**批文件名**/
	private String fileName;
	
	/**批文件路径**/
	private String filePath;
	
	private String tableName;
	
	private DataProtocol dataProtocol;
	
	private FileOperation operation;
	
	private Integer lockOffset;
	
	private Integer lockLength;
	
	/**时间戳**/
	private Long timestamp;
	
	/**异常通知次数**/
	private Integer noticeCount;
	
	/**异常消息**/
	private String errorMsg;
}
