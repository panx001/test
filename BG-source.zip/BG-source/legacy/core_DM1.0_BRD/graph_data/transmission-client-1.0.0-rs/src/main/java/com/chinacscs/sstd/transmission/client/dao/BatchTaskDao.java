package com.chinacscs.sstd.transmission.client.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.chinacscs.platform.commons.dao.BaseDao;
import com.chinacscs.sstd.transmission.client.constant.BatchTaskStatus;
import com.chinacscs.sstd.transmission.client.entity.BatchTask;
/**
 * @author: liusong
 * @date: 2019年2月15日
 * @email: 359852326@qq.com
 * @version:
 * @describe: //TODO
 */
@Mapper
public interface BatchTaskDao extends BaseDao<BatchTask> {

	BatchTask getByFileName(String fileName);

	BatchTask getEarliestByBatchCodeAndStatus(@Param("batchCode") Long batchCode,
			@Param("status") BatchTaskStatus status);

	List<BatchTask> listByBatchCode(Long batchCode);

	List<BatchTask> listByBatchCodeAndStatus(@Param("batchCode") Long batchCode,
			@Param("status") BatchTaskStatus status);

	int addAll(List<BatchTask> dataFiles);

	int updateStatus(@Param("id") Long id, @Param("status") BatchTaskStatus status);
	
	int updateStatusAndErrorMsg(@Param("id") Long id, @Param("status") BatchTaskStatus status,
			@Param("errorMsg") String errorMsg);

	int updateLockOffsetAndLength(@Param("id") Long id, @Param("lockOffset") Integer lockOffset,
			@Param("lockLength") Integer lockLength);

	int updateNoticeCount(@Param("id") Long id, @Param("noticeCount") Integer noticeCount);
}
