package com.chinacscs.sstd.transmission.client.config;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.FileCopyUtils;

import com.chinacscs.sstd.transmission.client.dao.JobConfigDao;
import com.chinacscs.sstd.transmission.client.dao.SqlDao;
import com.chinacscs.sstd.transmission.client.entity.JobConfig;

import lombok.Cleanup;
import lombok.extern.slf4j.Slf4j;

/**
 * @author: liusong
 * @date: 2019年2月19日
 * @email: 359852326@qq.com
 * @version:
 * @describe: 需要单独初始化配置
 */
@Configuration
@Slf4j
public class DbInitConfig implements InitializingBean {

	private final static String SQLITE_SCHEM_FILE = "sqlite_schem.sql";

	@Value("${app.job.cleanBatch.cronScript:0 0 1 * * ?}")
	private String cleanBatchCronScript;

	@Value("${app.job.processBatchTask.Parallel:false}")
	private boolean processBatchTaskParallel;

	@Value("${app.download.gs.cronScript}")
	private String gsDownloadCronScript;

	@Value("${app.download.graph.cronScript}")
	private String graphDownloadCronScript;

	@Autowired
	private DbInitConfig dbConfig;

	@Autowired
	private SqlDao sqlDao;

	@Autowired
	private JobConfigDao jobDao;

	@Override
	public void afterPropertiesSet() throws Exception {
		dbConfig.initDbSchem();
		dbConfig.initData();
	}

	@Transactional
	public void initDbSchem() throws Exception {
		log.info("start execute sqliteSchemScirpt");
		ClassPathResource resource = new ClassPathResource(SQLITE_SCHEM_FILE);
		@Cleanup
		InputStream inputStream = resource.getInputStream();
		byte[] bytes = FileCopyUtils.copyToByteArray(inputStream);
		String sqliteSchemScirptText = new String(bytes, "utf-8");
		String[] sqliteSchemScirpts = StringUtils.split(sqliteSchemScirptText, ";");
		for (String sqliteSchemScirpt : sqliteSchemScirpts) {
			sqlDao.execute(sqliteSchemScirpt);
		}
		log.info("end execute sqliteSchemScirpt");
	}

	@Transactional
	public void initData() {
		List<JobConfig> seedJobs = buildSeedJobs();
		jobDao.deleteAll();
		for (JobConfig seedJob : seedJobs) {
			jobDao.add(seedJob);
		}
	}

	private List<JobConfig> buildSeedJobs() {
		List<JobConfig> seedJobs = new ArrayList<>();
		JobConfig seedJob = null;
		 
/*		seedJob = new JobConfig();
		seedJob.setName("download-gs");
		seedJob.setCronScript(gsDownloadCronScript);
		seedJob.setClassName("com.chinacscs.sstd.transmission.client.job.impl.DownloadGsFileJob");
		seedJob.setParallel(false);
		seedJobs.add(seedJob);*/

		seedJob = new JobConfig();
		seedJob.setName("download-graph");
		seedJob.setCronScript(graphDownloadCronScript);
		seedJob.setClassName(
				"com.chinacscs.sstd.transmission.client.job.impl.DownloadGraphFileJob");
		seedJob.setParallel(false);
		seedJobs.add(seedJob);
		
		seedJob = new JobConfig();
		seedJob.setName("listen-batch");
		seedJob.setCronScript("*/30 * * * * ?");
		seedJob.setClassName("com.chinacscs.sstd.transmission.client.job.impl.ListenBatchJob");
		seedJob.setParallel(false);
		seedJobs.add(seedJob);

		seedJob = new JobConfig();
		seedJob.setName("listen-batch-task");
		seedJob.setCronScript("*/30 * * * * ?");
		seedJob.setClassName("com.chinacscs.sstd.transmission.client.job.impl.ListenBatchTaskJob");
		seedJob.setParallel(false);
		seedJobs.add(seedJob);

//		seedJob = new JobConfig();
//		seedJob.setName("process-batch-task");
//		seedJob.setCronScript("*/30 * * * * ?");
//		seedJob.setClassName("com.chinacscs.sstd.transmission.client.job.impl.ProcessBatchTaskJob");
//		seedJob.setParallel(processBatchTaskParallel);
//		seedJobs.add(seedJob);

/*		seedJob = new JobConfig();
		seedJob.setName("clean-batch");
		seedJob.setCronScript(cleanBatchCronScript);
		seedJob.setClassName("com.chinacscs.sstd.transmission.client.job.impl.CleanBatchJob");
		seedJob.setParallel(false);
		seedJobs.add(seedJob);*/
		
		seedJob = new JobConfig();
		seedJob.setName("load-graph-file");
		seedJob.setCronScript("*/30 * * * * ?");
		seedJob.setClassName("com.chinacscs.sstd.transmission.client.job.impl.LoadGraphFileJob");
		seedJob.setParallel(false);
		seedJobs.add(seedJob);
		return seedJobs;
	}
}