package com.chinacscs.sstd.transmission.client.service;

import java.io.File;
import java.util.Collections;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.chinacscs.sstd.transmission.client.constant.BatchTaskStatus;
import com.chinacscs.sstd.transmission.client.dao.BatchDao;
import com.chinacscs.sstd.transmission.client.dao.BatchTaskDao;
import com.chinacscs.sstd.transmission.client.entity.Batch;
import com.chinacscs.sstd.transmission.client.entity.BatchTask;

/**
 * @author: liusong
 * @date: 2019年2月18日
 * @email: 359852326@qq.com
 * @version:
 * @describe: //TODO
 */
@RestController
public class BatchService {

	@Autowired
	private BatchDao batchDao;

	@Autowired
	private BatchTaskDao batchTaskDao;

	@GetMapping(value = "/batchs")
	public List<Batch> listBatch() {
		return batchDao.listAll();
	}

	@GetMapping(value = "/batchs/{id}")
	public Batch getBatch(@PathVariable("id") Long id) {
		return batchDao.get(id);
	}

	@GetMapping(value = "/batchs/{id}/tasks")
	public List<BatchTask> listTasks(@PathVariable("id") Long id) {
		Batch batch = batchDao.get(id);
		if (null == batch) {
			return Collections.emptyList();
		}
		return batchTaskDao.listByBatchCode(batch.getCode());
	}

	@PutMapping(value = "/tasks/{id}/status")
	public void updateTaskStatus(@PathVariable("id") Long id,
			@RequestParam("status") String status) {
		batchTaskDao.updateStatus(id, BatchTaskStatus.valueOf(status));
	}

	@Transactional
	@DeleteMapping(value = "/batchs/{id}")
	public void delBatch(@PathVariable("id") Long id) {
		Batch batch = batchDao.get(id);
		if (null != batch) {
			List<BatchTask> tasks = batchTaskDao.listByBatchCode(batch.getCode());
			for (BatchTask task : tasks) {
				FileUtils.deleteQuietly(new File(task.getFilePath()));
				batchTaskDao.delete(task.getId());
			}
			FileUtils.deleteQuietly(new File(batch.getFilePath()));
			batchDao.delete(batch.getId());
		}
	}
	
	@Transactional
	@DeleteMapping(value = "/tasks/{id}")
	public void delBatchTask(@PathVariable("id") Long id) {
		BatchTask task=batchTaskDao.get(id);
		if(null!=task) {
			FileUtils.deleteQuietly(new File(task.getFilePath()));
			batchTaskDao.delete(task.getId());
		}
	}
}
