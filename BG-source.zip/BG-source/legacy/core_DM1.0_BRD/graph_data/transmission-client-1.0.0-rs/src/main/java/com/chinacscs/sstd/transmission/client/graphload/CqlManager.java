package com.chinacscs.sstd.transmission.client.graphload;

import java.util.HashMap;
import java.util.Map;

/**
 * 用于记录cypher语句 以及获取需要的cypher
 */
public class CqlManager {

        public static String getCql(String key, long commitNum, String csvFilePath, boolean isAdding) {
                return (isAdding ? cqlInsMapper : cqlDelMapper).get(key).replace("commitNum", "" + commitNum)
                                .replace("csv_file_path", csvFilePath).replace("skipAndLimit", "");
        }

        /**
         * @param key         cypher类型，如n_company
         * @param commitNum   PERIODIC COMMIT 的数值
         * @param csvFilePath csv路径（neo4j服务器上的csv路径）
         * @param isAdding    是否为调取cqlInsMapper
         * @param skipLines   用于加载大文件skip文件前面的多少行
         * @param limitLines  用于限制一个session的行数，应该要大于commitNum
         */
        public static String getCql(String key, long commitNum, String csvFilePath, boolean isAdding, long skipLines,
                        long limitLines) {
                return (isAdding ? cqlInsMapper : cqlDelMapper).get(key).replace("commitNum", "" + commitNum)
                                .replace("csv_file_path", csvFilePath)
                                .replace("skipAndLimit", "SKIP " + skipLines + " LIMIT " + limitLines);
        }

        public static String getCql(String key, long commitNum, String csvFilePath, String fileType, String host,
                        boolean isAdding) {
                return (isAdding ? cqlInsMapper : cqlDelMapper).get(key).replace("commitNum", "" + commitNum)
                                .replace("csv_file_path", csvFilePath);
        }

        /** 增加 */
        private static Map<String, String> cqlInsMapper = new HashMap<String, String>() {
                /**
                 */
                private static final long serialVersionUID = -3326425814829334679L;

                {
                        this.put("n_company", N_COMPANY_INS);
                        this.put("n_person_all", BASIC_PERSON_NODE_INSERT);
                        this.put("n_company_security", N_COMPANY_SECURITY_INS);
                        this.put("n_security", N_SECURITY_INS);
                        this.put("n_company_sharehd", N_COMPANY_SHAREHD_INS);
                        this.put("l_work_leg", L_WORK_LEG_INS);
                        this.put("l_work_pleg", BASIC_WORK_RELATION_INSERT);
                        this.put("l_work_executive", L_WORK_EXECUTIVE_INS);
                        this.put("l_managelevel", L_MANAGELEVEL_INS);
                        this.put("l_person_sharehd", L_PERSON_SHAREHD_INS);
                        this.put("l_company_sharehd", L_COMPANY_SHAREHD_INS);
                        this.put("l_security_sharehd", L_SECURITY_SHAREHD_INS);
                        this.put("l_branch", L_BRANCH_INS);
                        this.put("l_pfund", L_PFUND_INS);
                        this.put("p_pfcompany", P_PFCOMPANY_INS);
                        this.put("l_controller", L_CONTROLLER_INS);
                        this.put("l_relatives", L_RELATIVES_INS);
                        this.put("l_guarantee", L_GUARANTEE_INS);
                        this.put("l_issue", L_ISSUE_INS);
                        this.put("l_customer", L_CUSTOMER_INS);
                        this.put("l_supplier", L_SUPPLIER_INS);
                        this.put("p_company", P_COMPANY_INS);
                        this.put("compy_warnings1", COMPY_WARNINGS1_INS);
                        this.put("compy_warnings2", COMPY_WARNINGS2_INS);
                }
        };

        /** 删除 */
        private static Map<String, String> cqlDelMapper = new HashMap<String, String>() {
                /**
                 * 需要谨慎删除
                 */
                private static final long serialVersionUID = -2289563968160160862L;

                {
                        this.put("n_company", N_COMPANY_DEL);
                        this.put("n_person_all", BASIC_PERSON_NODE_DELET);
                        this.put("n_security", RETURN_NULL);
                        this.put("n_company_sharehd", N_COMPANY_SHAREHD_DEL);
                        this.put("n_company_security", N_COMPANY_SECURITY_DEL);
                        this.put("l_work_leg", BASIC_WORK_RELATION_DELET);
                        this.put("l_work_pleg", BASIC_WORK_RELATION_DELET);
                        this.put("l_work_executive", BASIC_WORK_RELATION_DELET);
                        this.put("l_managelevel", L_MANAGELEVEL_DEL);
                        this.put("l_person_sharehd", L_PERSON_SHAREHD_DEL);
                        this.put("l_company_sharehd", L_COMPANY_SHAREHD_DEL);
                        this.put("l_branch", L_BRANCH_DEL);
                        this.put("l_pfund", L_PFUND_DEL);
                        this.put("l_security_sharehd", L_SECURITY_SHAREHD_DEL);
                        this.put("l_relatives", L_RELATIVE_DEL);
                        this.put("l_guarantee", L_GUARANTEE_DEL);
                        this.put("l_issue", L_ISSUE_DEL);
                        this.put("l_customer", L_CUSTOMER_DEL);
                        this.put("l_supplier", L_SUPPLIER_DEL);
                        this.put("l_controller", L_CONTROLLER_DEL);
                        this.put("p_company", P_COMPANY_DEL);
                        this.put("p_pfcompany", P_PFCOMPANY_DEL);
                        this.put("compy_warnings1", RETURN_NULL);
                        this.put("compy_warnings2", RETURN_NULL);
                }
        };

        private static final String BASIC_PERSON_NODE_INSERT = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n" + "MERGE (p:PERSON{PERSON_ID:LINE.person_id})\n"
                        + "   ON CREATE SET p.PERSON_NM=LINE.person_nm";
        private static final String BASIC_WORK_RELATION_INSERT = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "WHERE LINE.position IS NOT NULL AND NOT LINE.position = ''\n"
                        + "MATCH (c:COMPANY{COMPANY_ID:LINE.company_id})\n"
                        + "MATCH (p:PERSON{PERSON_ID:LINE.person_id})\n"
                        + "   MERGE (p) -[w:WORK{POSITION:LINE.position}]-> (c)\n";

        private static final String L_BRANCH_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n" + "MATCH (c:COMPANY{COMPANY_ID:LINE.company_id})\n"
                        + "MATCH (p:COMPANY{COMPANY_ID:LINE.branch_id})\n" + "   MERGE (p) <-[w:BRANCH]- (c)\n";

        private static final String L_WORK_EXECUTIVE_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "WHERE LINE.position IS NOT NULL AND NOT LINE.position = ''\n"
                        + "MATCH (c:COMPANY{COMPANY_ID:LINE.company_id})\n"
                        + "MATCH (p:PERSON{PERSON_ID:LINE.person_id})\n"
                        + "   MERGE (p) -[w:WORK{POSITION:LINE.position,R_TYPE:LINE.r_type}]-> (c)";

        /** 版本1.1：这个代码是如果缺自然人就添加上去，已id为准，所以快，一个职位就有一个work线 */
        private static final String L_MANAGELEVEL_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "WHERE LINE.position IS NOT NULL AND NOT LINE.position = ''\n"
                        + "MATCH (c:COMPANY{COMPANY_ID:LINE.company_id})\n"
                        + "MERGE (p:PERSON{PERSON_ID:LINE.person_id})\n"
                        + "ON CREATE SET p.PERSON_ID=LINE.person_id,p.PERSON_NM=LINE.person_nm\n"
                        + "MERGE (p) -[w:WORK{POSITION:LINE.position}]-> (c)" + "SET w.R_TYPE=LINE.r_type";

        private static final String L_WORK_LEG_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "WHERE LINE.position IS NOT NULL AND NOT LINE.position = ''\n"
                        + "MATCH (c:COMPANY{COMPANY_ID:LINE.company_id})\n" +
                        /* 法人实控人关系，所以是COMPANY_ID */
                        "MATCH (p:COMPANY{COMPANY_ID:LINE.person_id})\n"
                        + "MERGE (p) -[w:WORK{POSITION:LINE.position}]-> (c)";

        private static final String L_ISSUE_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n" + "MATCH (c:COMPANY{COMPANY_ID:LINE.company_id})\n"
                        + "MATCH (s:SECURITY{SECINNER_ID:LINE.secinner_id})\n" + "MERGE (c) -[:ISSUE]-> (s)";

        private static final String COMPY_WARNINGS2_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "MATCH (C:COMPANY) WHERE C.COMPANY_ID  = LINE.company_id \n"
                        + "WITH C,SPLIT(LINE.warning_label,',') AS A \n" + "   SET C.RISK_LIST = A;";
        private static final String COMPY_WARNINGS1_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n" + "MATCH (C:COMPANY{COMPANY_ID:toString(LINE.company_id)})\n"
                        + "SET C.WARNING_NUM = toInt(LINE.warning_num)";

        private static final String L_CUSTOMER_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "WHERE (LINE.company_id IS NOT NULL AND NOT LINE.company_id = '' )\n"
                        + "    MATCH (A:COMPANY{COMPANY_ID:toString(LINE.company_id)})\n"
                        + "    FOREACH(ele IN CASE WHEN LINE.customer_id IS NULL OR LINE.customer_id = '' THEN [1] ELSE [] END |\n"
                        + "    MERGE (B:COMPANY{COMPANY_ID:LINE.company_id+LINE.customer_nm})\n"
                        + "    SET B.COMPANY_NM = LINE.customer_nm\n" + "    MERGE (B)-[r:CUSTOMER]->(A)\n"
                        + "    SET\n" + "        r.RELATION_TYPE='主要客户',\n"
                        + "        r.RPT_DT=toString(LINE.rpt_dt),\n" + "        r.START_DT=toString(LINE.start_dt),\n"
                        + "        r.RPT_DT = toString(LINE.rpt_dt),\n" + "        r.IS_DEL=toString(LINE.is_del)\n"
                        + "    )\n"
                        + "    FOREACH(ele IN CASE WHEN LINE.customer_id IS NULL OR LINE.customer_id = '' THEN [] ELSE [1] END |\n"
                        + "    MERGE (B:COMPANY{COMPANY_ID:LINE.customer_id})\n"
                        + "    SET B.COMPANY_NM = LINE.customer_nm\n" + "    MERGE (B)-[r:CUSTOMER]->(A)\n"
                        + "    SET\n" + "        r.RELATION_TYPE='主要客户',\n"
                        + "        r.RPT_DT=toString(LINE.rpt_dt),\n" + "        r.START_DT=toString(LINE.start_dt),\n"
                        + "        r.RPT_DT = toString(LINE.rpt_dt),\n" + "        r.IS_DEL=toString(LINE.is_del))";

        private static final String L_SUPPLIER_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "WHERE (LINE.company_id IS NOT NULL AND NOT LINE.company_id = '' )\n"
                        + "    WITH apoc.date.format(timestamp()+8*60*60*1000,\"ms\",\"yyyy-MM-dd HH:mm:ss\") AS TIME_STAMP,LINE\n"
                        + "    MATCH (A:COMPANY{COMPANY_ID:toString(LINE.company_id)})\n"
                        + "    FOREACH(ele IN CASE WHEN LINE.supplier_id IS NULL THEN [1] ELSE [] END |\n"
                        + "    MERGE (B:COMPANY{COMPANY_ID:LINE.company_id+LINE.supplier_nm})\n"
                        + "    SET B.COMPANY_NM = LINE.supplier_nm\n" + "MERGE (B)-[R:SUPPLIER]->(A)\n" + "    SET\n"
                        + "        R.RELATION_TYPE='主要供应商',\n" + "        R.RPT_DT=toString(LINE.rpt_dt),\n"
                        + "        R.START_DT=toString(LINE.start_dt),\n" + "        R.TIME_STAMP = TIME_STAMP,\n"
                        + "        R.RPT_DT = toString(LINE.rpt_dt),\n" + "        R.IS_DEL = toString(LINE.is_del)\n"
                        + "    )\n" + "    FOREACH(ele IN CASE WHEN LINE.supplier_id IS NULL THEN [] ELSE [1] END |\n"
                        + "    MERGE (B:COMPANY{COMPANY_ID:LINE.supplier_id})\n"
                        + "ON CREATE SET B.COMPANY_NM = LINE.supplier_nm\n" + "MERGE (B)-[R:SUPPLIER]->(A)\n"
                        + "    SET\n" + "        R.RELATION_TYPE='主要供应商',\n"
                        + "        R.RPT_DT=toString(LINE.rpt_dt),\n" + "        R.START_DT=toString(LINE.start_dt),\n"
                        + "        R.TIME_STAMP = TIME_STAMP,\n" + "        R.RPT_DT = toString(LINE.rpt_dt),\n"
                        + "        R.IS_DEL = toString(LINE.is_del)\n" + "    )";

        private static final String L_RELATIVES_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + " WHERE NOT ( LINE.sharehd_id IS NULL OR LINE.person_id IS NULL) \n"
                        + "        AND NOT LINE.constant_nm ='其他组织'\n" + "        AND NOT LINE.constant_nm ='受控法人'\n"
                        + "MATCH (P1:PERSON{PERSON_ID:LINE.sharehd_id})\n"
                        + "MATCH (P2:PERSON{PERSON_ID:LINE.person_id})\n"
                        + "        MERGE (P1)-[R:RELATIVE{RELATION_TYPE:toString(LINE.constant_nm)}]->(P2)\n";

        private static final String P_COMPANY_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n" + "MATCH (C:COMPANY)\n"
                        + "    WHERE C.COMPANY_ID  = LINE.company_id\n"
                        + "    WITH C,SPLIT(LINE.company_type,',') AS A\n"
                        + "      SET C.COMPANY_TYPE_LIST = apoc.coll.toSet(A)\n";

        private static final String P_PFCOMPANY_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "WHERE ( LINE.company_id IS NOT NULL AND NOT LINE.company_id = '' )\n"
                        + "OPTIONAL MATCH  (A:COMPANY{COMPANY_ID:LINE.company_id}) \n"
                        + "OPTIONAL MATCH  (PF:PFCOMPANY{COMPANY_ID:LINE.company_id}) \n"
                        + "FOREACH(ELEM IN CASE WHEN PF IS NOT NULL AND ( LINE.is_revoke = '1') THEN ['1'] ELSE [] END |\n"
                        + "    REMOVE PF:PFCOMPANY\n" + "    SET \n" + "    PF.ORG_FORM = NULL,\n"
                        + "    PF.IS_REVOKE =  NULL,\n" + "    PF.REG_DT = NULL,\n" + "    PF.REG_CD = NULL\n"
                        + "    )\n"
                        + "FOREACH(ELEM IN CASE WHEN PF IS NOT NULL AND NOT ( LINE.is_revoke = '1') THEN ['1'] ELSE [] END |\n"
                        + "    SET\n" + "        PF.ORG_FORM = LINE.org_form,\n"
                        + "        PF.IS_REVOKE = LINE.is_revoke,\n" + "        PF.REG_DT = LINE.reg_dt,\n"
                        + "        PF.REG_CD = LINE.reg_cd\n" + "    )\n"
                        + "FOREACH(ELEM IN CASE WHEN PF IS NULL AND A IS NOT NULL AND NOT ( LINE.is_revoke = '1') THEN ['1'] ELSE [] END |\n"
                        + "    SET\n" + "        A:PFCOMPANY,\n" + "        A.ORG_FORM = LINE.org_form,\n"
                        + "        A.IS_REVOKE = LINE.is_revoke,\n" + "        A.REG_DT = LINE.reg_dt,\n"
                        + "        A.REG_CD = LINE.reg_cd\n" + "    );";

        private static final String N_COMPANY_SHAREHD_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "WHERE (LINE.sharehd_id IS NOT NULL AND NOT LINE.sharehd_id = '')\n"
                        + "MERGE (c:COMPANY{COMPANY_ID:LINE.sharehd_id}) \n" + "SET c.COMPANY_NM=LINE.sharehd_name";
        private static final String N_COMPANY_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n" + "MERGE (c:COMPANY{COMPANY_ID:LINE.company_id}) \n"
                        + "SET c.COMPANY_NM=LINE.company_nm,\n" + "    c.ORGNUM=LINE.orgnum,\n"
                        + "    c.STATUS=LINE.status,\n" + "    c.REG_CAPITAL = LINE.reg_capital";

        private static final String L_PFUND_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "WHERE ( LINE.secinner_id IS NOT NULL AND NOT LINE.secinner_id = '' )\n"
                        + "    AND ( LINE.manager_id IS NOT NULL AND NOT LINE.manager_id = '' )\n"
                        + "    WITH apoc.date.format(timestamp()+8*60*60*1000,\"ms\",\"yyyy-MM-dd HH:mm:ss\") AS TIME_STAMP,LINE\n"
                        + "    MATCH (S:SECURITY{SECINNER_ID:toString(LINE.secinner_id)})\n" + "    SET\n"
                        + "        S:PFUND,\n" + "        S.STATUS = LINE.status\n" + "    WITH S,TIME_STAMP, LINE\n"
                        + "    MATCH (C:COMPANY{COMPANY_ID:toString(LINE.manager_id)})\n"
                        + "    MERGE(C)-[F:MANAGER{RELATIONSHIP:'管理人'}]->(S)\n" + "    ON CREATE SET\n"
                        + "        F.SOURCE = 'PFUND_PUBLICINFO',\n" + "        F.TIME_STAMP = TIME_STAMP\n"
                        + "    WITH S,LINE,TIME_STAMP\n"
                        + "    MATCH (T:COMPANY{COMPANY_ID:toString(LINE.trustee_id)})\n"
                        + "    MERGE(T)-[TR:TRUSTEE{RELATIONSHIP:'托管方'}]->(S)\n" + "    ON CREATE SET\n"
                        + "        TR.SOURCE = 'PFUND_PUBLICINFO',\n" + "        TR.TIME_STAMP = TIME_STAMP";

        private static final String N_SECURITY_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "OPTIONAL MATCH  (S:SECURITY{SECINNER_ID:LINE.secinner_id})\n"
                        + "WITH LINE,COLLECT(S) AS S_LIST\n" + "WITH LINE ,S_LIST[0] AS S \n"
                        + "FOREACH(LINE_ELEM IN CASE WHEN S IS NOT NULL THEN [] ELSE [1] END | \n"
                        + "    CREATE (C:SECURITY{SECINNER_ID:LINE.secinner_id})\n"
                        + "    SET C.SECURITY_NM = LINE.security_nm  \n" + "    SET C.SECURITY_CD=LINE.security_cd\n"
                        + "    SET C.SECURITY_TYPE = LINE.type\n" + "        );";

        /**
         * 需要先批量更新 企业，然后更新企业产品，最后更新纯产品 注意 企业产品 必须要先更新：
         */
        private static final String N_COMPANY_SECURITY_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "OPTIONAL MATCH  (A:COMPANY{COMPANY_ID:LINE.company_id}) WHERE NOT EXISTS(A.SECINNER_ID)\n"
                        + "OPTIONAL MATCH  (S:SECURITY{SECINNER_ID:LINE.secinner_id})\n"
                        + "WITH LINE, COLLECT(A) AS A_LIST,COLLECT(S) AS S_LIST\n"
                        + "WITH LINE ,A_LIST[0] AS A, S_LIST[0] AS S \n" + "// S 不存在，且没有匹配到A\n"
                        + "FOREACH(LINE_ELEM IN CASE WHEN S IS NOT NULL THEN [] ELSE CASE WHEN A IS NULL THEN [1] ELSE [] END END | \n"
                        + "    CREATE (C:SECURITY{SECINNER_ID:LINE.secinner_id})\n" + "    SET \n"
                        + "        C.SECURITY_NM = LINE.security_nm  \n" + "        ) \n" + "// S 不存在，匹配到A\n"
                        + "FOREACH(LINE_ELEM IN CASE WHEN S IS NOT NULL THEN [] ELSE CASE WHEN A IS NOT NULL THEN [1] ELSE [] END END | \n"
                        + "    SET \n" + "        A:SECURITY,\n" + "        A.SECINNER_ID = LINE.secinner_id,\n"
                        + "        A.SECURITY_NM = LINE.security_nm\n" + "        );";

        private static final String L_SECURITY_SHAREHD_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n" + "MATCH (A:COMPANY{COMPANY_ID:LINE.company_id})\n"
                        + "MATCH (S:SECURITY{SECINNER_ID:LINE.sharehd_id})\n" + "MERGE (S)-[R:INVEST]->(A) \n"
                        + "    SET R.SHA_RATIO=toString(LINE.sharehd_ratio)\n"
                        + "    SET R.NUM=toString(LINE.subscribed_capital_amt)";

        private static final String L_PERSON_SHAREHD_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n" + "MATCH (c:COMPANY{COMPANY_ID:LINE.company_id})\n"
                        + "MATCH (p:PERSON{PERSON_ID:LINE.person_id})\n" + "MERGE (p) -[w:INVEST]-> (c)\n"
                        + "   SET w.NUM = LINE.subscribed_capital_amt\n" + "   SET w.SHA_RATIO = LINE.sharehd_ratio";
        private static final String L_COMPANY_SHAREHD_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n" + "MATCH (c:COMPANY{COMPANY_ID:LINE.company_id})\n"
                        + "MATCH (p:COMPANY{COMPANY_ID:LINE.sharehd_id})\n" + "MERGE (p) -[w:INVEST]-> (c)\n"
                        + "   SET w.NUM = LINE.subscribed_capital_amt\n" + "   SET w.SHA_RATIO = LINE.sharehd_ratio";

        private static final String L_GUARANTEE_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "WHERE ( LINE.guar_company_id IS NOT NULL AND NOT LINE.guar_company_nm = '' )\n"
                        + "MATCH (A:COMPANY{COMPANY_ID:LINE.guar_company_id})\n"
                        + "WITH LINE,A,COLLECT({GUAR_AMT:LINE.guar_amt,TRADE_DT:LINE.trade_dt,GUAR_DEADLINE:LINE.guar_deadline,GUAR_END_DT:toString(LINE.guar_end_dt),GUAR_START_DT:toString(LINE.guar_start_dt) }) AS GUAR_INFO\n"
                        + "FOREACH (ele IN CASE WHEN LINE.buar_company_id IS NULL OR LINE.buar_company_id='' THEN [1] ELSE [] END |\n"
                        + "MERGE (B:COMPANY{COMPANY_ID:LINE.guar_company_id+LINE.buar_company_nm})\n"
                        + "SET B.COMPANY_NM = LINE.buar_company_nm\n" + "MERGE (A)-[R:GUARANTEE]->(B)\n"
                        + "    SET R.GUAR_INFO = [ELEM IN GUAR_INFO|apoc.convert.toJson(ELEM)]\n" + ") \n"
                        + "FOREACH (ele IN CASE WHEN LINE.buar_company_id IS NULL OR LINE.buar_company_id='' THEN [] ELSE [1] END |\n"
                        + "MERGE (B2:COMPANY{COMPANY_ID:LINE.buar_company_id})\n"
                        + "    SET B2.COMPANY_NM = LINE.buar_company_nm\n" + "MERGE (A)-[R:GUARANTEE]->(B2)\n"
                        + "    SET R.GUAR_INFO = [ELEM IN GUAR_INFO|apoc.convert.toJson(ELEM)]\n" + ")";

        /** 版本2 有的自然人在n_person_all里面没有 */
        private static final String L_CONTROLLER_INS = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "WHERE ( LINE.company_id IS NOT NULL AND NOT LINE.company_id = '' )\n"
                        + "    AND NOT LINE.affil_party = '无'\n" + "WITH LINE\n"
                        + "MATCH (C:COMPANY{COMPANY_ID:toString(LINE.company_id)})\n" + "WITH LINE, C\n"
                        + "OPTIONAL MATCH (B:COMPANY{COMPANY_ID:toString(LINE.affil_party_id),COMPANY_NM:toString(LINE.affil_party)})\n"
                        + "FOREACH(ELEM IN CASE WHEN B IS NOT NULL THEN [1] ELSE [] END |\n"
                        + "    MERGE (B)-[R:CONTROLLER{RELATION_TYPE:toString(LINE.relation_type)}]->(C)\n"
                        + "    ON CREATE SET\n" + "        R.SOURCE= 'COMPY_AFFILPARTY',\n"
                        + "        R.SHA_RATIO=toString(LINE.ino_sha_ratio)\n" + "        )\n" + "WITH LINE,C\n"
                        + "WHERE size(toString(LINE.affil_party)) < 5\n"
                        + "MERGE (P:PERSON{PERSON_ID:toString(LINE.affil_party_id)})\n"
                        + "ON CREATE SET P.PERSON_NM=toString(LINE.affil_party)\n"
                        + "MERGE (P)-[R:CONTROLLER{RELATION_TYPE:toString(LINE.relation_type)}]->(C)";

        /** 数据删除 */
        private static final String RETURN_NULL = "RETURN NULL";
        private static final String N_COMPANY_DEL = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n" + "MATCH (c:COMPANY{COMPANY_ID:LINE.company_id})\n"
                        + "DETACH DELETE c";
        private static final String BASIC_PERSON_NODE_DELET = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n" + "MATCH (p:PERSON{PERSON_ID:LINE.person_id})\n"
                        + "DETACH DELETE p";

        private static final String BASIC_WORK_RELATION_DELET = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "MATCH (c:COMPANY{COMPANY_ID:LINE.company_id}) <-[w:WORK{POSITION:LINE.position}]- (p:PERSON{PERSON_ID:LINE.person_id})\n"
                        + "DELETE w";

        private static final String P_PFCOMPANY_DEL = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "WHERE ( LINE.company_id IS NOT NULL AND NOT LINE.company_id = '' )\n"
                        + "MATCH  (PF:PFCOMPANY{COMPANY_ID:LINE.company_id}) \n" + "    REMOVE PF:PFCOMPANY\n"
                        + "    SET \n" + "    PF.ORG_FORM = NULL,\n" + "    PF.IS_REVOKE =  NULL,\n"
                        + "    PF.REG_DT = NULL,\n" + "    PF.REG_CD = NULL";

        private static final String L_SECURITY_SHAREHD_DEL = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "MATCH (c:COMPANY{COMPANY_ID:LINE.company_id}) <-[w:INVEST]- (p:COMPANY{COMPANY_ID:LINE.sharehd_id})\n"
                        + "DELETE w";
        private static final String L_COMPANY_SHAREHD_DEL = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "MATCH (c:COMPANY{COMPANY_ID:LINE.company_id}) <-[w:INVEST]- (p:COMPANY{COMPANY_ID:LINE.sharehd_id})\n"
                        + "DELETE w";
        private static final String P_COMPANY_DEL = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n" + "MATCH (n:COMPANY{COMPANY_ID:LINE.company_id})\n"
                        + "WITH n, SPLIT(LINE.company_type,',') AS tobeRemoved\n"
                        + "SET n.COMPANY_TYPE_LIST = apoc.coll.removeAll(n.COMPANY_TYPE_LIST,tobeRemoved)";
        private static final String L_CONTROLLER_DEL = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "WHERE ( LINE.company_id IS NOT NULL AND NOT LINE.company_id = '' ) AND NOT LINE.affil_party = '无'\n"
                        + "WITH LINE\n" + "MATCH (C:COMPANY{COMPANY_ID:toString(LINE.company_id)})\n" + "WITH LINE, C\n"
                        + "OPTIONAL MATCH (B:COMPANY{COMPANY_ID:toString(LINE.affil_party_id),COMPANY_NM:toString(LINE.affil_party)})\n"
                        + "FOREACH(ELEM IN CASE WHEN B IS NOT NULL THEN [1] ELSE [] END |\n"
                        + "    MERGE (B)-[R:CONTROLLER{RELATION_TYPE:toString(LINE.relation_type)}]->(C)\n"
                        + "       DELETE R)\n" + "WITH LINE,C\n" + "WHERE size(toString(LINE.affil_party)) < 5\n"
                        + "MATCH (P:PERSON{PERSON_ID:toString(LINE.affil_party_id)})\n"
                        + "   WHERE P.PERSON_NM=toString(LINE.affil_party)\n" + "WITH LINE,C,P\n"
                        + "MATCH (P)-[R:CONTROLLER{RELATION_TYPE:toString(LINE.relation_type)}]->(C)\n" + "DELETE R";
        private static final String N_COMPANY_SECURITY_DEL = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n" + "MATCH (A:COMPANY{COMPANY_ID:LINE.company_id})\n"
                        + "DETACH DELETE A";
        private static final String L_RELATIVE_DEL = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "MATCH (P1:PERSON{PERSON_ID:toString(LINE.sharehd_id)})-[R:RELATIVE{RELATION_TYPE:toString(LINE.constant_nm)}]-(P2:PERSON{PERSON_ID:toString(LINE.person_id)})\n"
                        + "DELETE R";
        private static final String L_PFUND_DEL = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "WHERE ( LINE.secinner_id IS NOT NULL AND NOT LINE.secinner_id = '' )\n"
                        + "    AND ( LINE.manager_id IS NOT NULL AND NOT LINE.manager_id = '' )\n"
                        + "    MATCH (S:SECURITY{SECINNER_ID:LINE.secinner_id})<-[F:MANAGER]-(C:COMPANY{COMPANY_ID:LINE.manager_id})\n"
                        + "    DELETE F";
        private static final String L_MANAGELEVEL_DEL = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "MATCH (c:COMPANY{COMPANY_ID:LINE.company_id}) <-[w:WORK{POSITION:LINE.position}]- (p:PERSON{PERSON_ID:LINE.person_id})\n"
                        + "DELETE w";
        private static final String N_SECURITY_DEL = "RETURN NULL";

        private static final String N_COMPANY_SHAREHD_DEL = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n" + "MATCH (C:COMPANY{COMPANY_ID:LINE.sharehd_id})\n"
                        + "DETACH DELETE C";

        private static final String L_PERSON_SHAREHD_DEL = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "MATCH (c:COMPANY{COMPANY_ID:LINE.company_id}) <-[w:INVEST]- (p:PERSON{PERSON_ID:LINE.person_id})\n"
                        + "DELETE w";
        private static final String L_BRANCH_DEL = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "MATCH (c:COMPANY{COMPANY_ID:LINE.company_id}) -[w:BRANCH]-> (p:COMPANY{COMPANY_ID:LINE.branch_id})\n"
                        + "DELETE w";
        private static final String L_GUARANTEE_DEL = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "MATCH (:COMPANY{COMPANY_ID:LINE.guar_company_id})-[G:GUARANTEE]->(:COMPANY{COMPANY_ID:LINE.buar_company_id})\n"
                        + "DELETE G;";
        private static final String L_ISSUE_DEL = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "MATCH (c:COMPANY{COMPANY_ID:LINE.company_id}) -[r:ISSUE]-> (s:SECURITY{SECINNER_ID:LINE.secinner_id})\n"
                        + "DELETE r";
        private static final String L_CUSTOMER_DEL = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "WHERE (LINE.company_id IS NOT NULL AND NOT LINE.company_id = '' )\n"
                        + "    AND (LINE.customer_id IS NOT NULL AND NOT LINE.customer_id = '')\n"
                        + "    MATCH (B:COMPANY{COMPANY_ID:toString(LINE.customer_id)})-[r:CUSTOMER]->(A:COMPANY{COMPANY_ID:toString(LINE.company_id)})\n"
                        + "    DELETE r";
        private static final String L_SUPPLIER_DEL = "USING PERIODIC COMMIT commitNum\nLOAD CSV WITH HEADERS FROM 'file://csv_file_path' AS LINE\n"
                        + "WITH LINE\n" + "skipAndLimit\n"
                        + "WHERE (LINE.company_id IS NOT NULL AND NOT LINE.company_id = '' )\n"
                        + "    AND ( LINE.supplier_id IS NOT NULL AND NOT LINE.supplier_id = '' )\n"
                        + "    MATCH (B:COMPANY{COMPANY_ID:toString(LINE.supplier_id)})-[R:SUPPLIER]->(A:COMPANY{COMPANY_ID:toString(LINE.company_id)})\n"
                        + "    DELETE R\n";
}
