package com.chinacscs.sstd.transmission.client.graphload;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class PathHandler {

	private Map<String, Path> pathMap = new HashMap<String, Path>();
	private Path localNeo4jCsvDir;
	private Path sftpLogsDir;
	private String csvDirNeo4j;

	public PathHandler(String csvDirSftp, String csvDirNeo4j, String logs){
		this.csvDirNeo4j = csvDirNeo4j;
		localNeo4jCsvDir = Paths.get(csvDirSftp);
		sftpLogsDir = Paths.get(logs);
		Path updateFinish = Paths.get(logs, "update_finish");

		Path ins = Paths.get(localNeo4jCsvDir.toAbsolutePath().toString(), "ins");
		Path del = Paths.get(localNeo4jCsvDir.toAbsolutePath().toString(), "del");
		Path finish = Paths.get(localNeo4jCsvDir.toAbsolutePath().toString(), "finish");

		if (!localNeo4jCsvDir.toFile().isDirectory()) {
			throw new IllegalStateException(
					"调度端 neo4j_csv 目录不存在" + localNeo4jCsvDir.toAbsolutePath().toString());
		} else {
			this.pathMap.put("sftpNeo4jCsvDir", localNeo4jCsvDir);
		}
		if (!sftpLogsDir.toFile().exists()) {
			this.pathMap.put("initCsvList",
					Paths.get(sftpLogsDir.toAbsolutePath().toString(), "initCsvList.txt"));
			if (!sftpLogsDir.toFile().mkdirs()) {
				throw new IllegalStateException("创建neo4j的updateWorkDir目录失败");
			}
		}
		if (!updateFinish.toFile().exists()) {
			if (!updateFinish.toFile().mkdirs()) {
				throw new IllegalStateException("创建updateFinish目录失败");
			}
		}

		this.pathMap.put("ins", ins);
		this.pathMap.put("del", del);
		this.pathMap.put("finish", finish);
		this.pathMap.put("updateFinish", updateFinish);
		this.pathMap.put("sftpLogsDir", sftpLogsDir);
	}

	public String getAbsPath(String fileName) {
		return this.pathMap.get(fileName).toAbsolutePath().toString();
	}
	String getPathOnNeo4jServer(String absPathOnSftpServer) {
		return absPathOnSftpServer
				.replace(localNeo4jCsvDir.toAbsolutePath().toString(), this.csvDirNeo4j)
				.replace("\\", "/");
	}
	Path getPath(String fileName) {
		try {
			return this.pathMap.get(fileName);
		} catch (Exception e) {
			return null;
		}
	}
}
