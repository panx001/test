CREATE TABLE IF NOT EXISTS `job_config`(
	id           INTEGER      PRIMARY KEY,
	name         CHAR(50)     NOT NULL unique,
	cron_script  CHAR(100)    NOT NULL,
	class_name   CHAR(100)    NOT NULL,
	parallel     INTEGER      default 0,
	version      INTEGER      default 0
);

CREATE TABLE IF NOT EXISTS `batch`(
	id           INTEGER      PRIMARY KEY,
	code         INTEGER      NOT NULL unique,
	status       CHAR(20)     NOT NULL,
	file_name    CHAR(50)     NOT NULL,
	file_path    CHAR(200)    NOT NULL,
	`timestamp`  INTEGER      NOT NULL,
	notice_count INTEGER      default 0,
	error_msg	 CHAR(500)   default '',
	version      INTEGER      default 0
);
    					
CREATE TABLE IF NOT EXISTS `batch_task`(
	id            INTEGER      PRIMARY KEY,
	batch_code    INTEGER      NOT NULL,
	seq           INTEGER      NOT NULL,
	status        CHAR(20)     NOT NULL,
	file_name     CHAR(50)     NOT NULL unique,
	file_path     CHAR(100)    NOT NULL,
	table_name    CHAR(100)    NOT NULL,
	data_protocol CHAR(20)     NOT NULL,
	operation     CHAR(20)     NOT NULL,
	lock_offset   INTEGER      NOT NULL,
    lock_length   INTEGER      NOT NULL,
    `timestamp`   INTEGER      NOT NULL,
    notice_count  INTEGER      default 0,
    error_msg	  CHAR(500)    default '',
	version       INTEGER      default 0
);