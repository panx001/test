package com.chinacscs.sstd.transmission.client.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.chinacscs.platform.commons.dao.BaseDao;
import com.chinacscs.sstd.transmission.client.constant.BatchStatus;
import com.chinacscs.sstd.transmission.client.entity.Batch;

/**
 * @author: liusong
 * @date: 2019年2月15日
 * @email: 359852326@qq.com
 * @version:
 * @describe: //TODO
 */
@Mapper
public interface BatchDao extends BaseDao<Batch> {

	int addAll(List<Batch> batchs);

	Batch getByFileName(String fileName);

	Batch getEarliestByStatus(BatchStatus status);

	Batch getLastByStatus(BatchStatus status);
	
	List<Batch> listAll();
	
	List<Batch> listByStatus(BatchStatus status);
	
	List<Batch> listBeforeTimestamp(Long timestamp);

	int updateStatus(@Param("id") Long id, @Param("status") BatchStatus status);
	
	int updateNoticeCount(@Param("id") Long id, @Param("noticeCount") Integer noticeCount);
	
	int updateStatusAndErrorMsg(@Param("id") Long id, @Param("status") BatchStatus status,
			@Param("errorMsg") String errorMsg);
}
