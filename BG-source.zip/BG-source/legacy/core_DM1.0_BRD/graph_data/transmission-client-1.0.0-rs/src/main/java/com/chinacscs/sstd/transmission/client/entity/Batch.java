package com.chinacscs.sstd.transmission.client.entity;

import com.chinacscs.platform.commons.entity.BaseEntity;
import com.chinacscs.sstd.transmission.client.constant.BatchStatus;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @author: liusong
 * @date: 2019年2月15日
 * @email: 359852326@qq.com
 * @version:
 * @describe: //TODO
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class Batch extends BaseEntity{

	/**编码:唯一的**/
	private Long code;
	
	/**状态**/
	private BatchStatus status;
	
	/**批文件名**/
	private String fileName;
	
	/**批文件路径**/
	private String filePath;
	
	/**时间戳**/
	private Long timestamp;
	
	/**异常通知次数**/
	private Integer noticeCount;
	
	/**异常消息**/
	private String errorMsg;
}
