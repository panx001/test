package com.chinacscs.sstd.transmission.client.job.impl;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.chinacscs.sstd.transmission.client.component.EmailService;
import com.chinacscs.sstd.transmission.client.constant.BatchStatus;
import com.chinacscs.sstd.transmission.client.constant.BatchTaskStatus;
import com.chinacscs.sstd.transmission.client.constant.DataProtocol;
import com.chinacscs.sstd.transmission.client.constant.FileOperation;
import com.chinacscs.sstd.transmission.client.dao.BatchTaskDao;
import com.chinacscs.sstd.transmission.client.dao.BatchDao;
import com.chinacscs.sstd.transmission.client.entity.BatchTask;
import com.chinacscs.sstd.transmission.client.entity.JobConfig;
import com.chinacscs.sstd.transmission.client.entity.Batch;
import com.chinacscs.sstd.transmission.client.job.AbstractWorker;
import com.chinacscs.sstd.transmission.client.job.exception.WorkException;

import lombok.extern.slf4j.Slf4j;

/**
 * @author: liusong
 * @date: 2019年2月14日
 * @email: 359852326@qq.com
 * @version:
 * @describe: 处理meta目录finish后缀文件job
 */
@Slf4j
public class ListenBatchTaskJob extends AbstractWorker {

	@Value("${app.job.listenBatchTask.path}")
	private String filesDirPath;

	@Autowired
	private BatchDao batchDao;

	@Autowired
	private BatchTaskDao batchTaskDao;

	private static Map<Long, Batch> runningCache = new ConcurrentHashMap<>();

	public ListenBatchTaskJob(JobConfig jobConfig) {
		super(jobConfig);
	}

	@Override
	protected void doExecute() {
		File batchTaskFileDir = new File(filesDirPath);
		if (!batchTaskFileDir.exists() || !batchTaskFileDir.isDirectory()) {
			log.warn("The path[{}] does not exist or is not a directory", filesDirPath);
			return;
		}
		Batch currentBatch = checkAndlookupBatch(batchDao, getEmailService());
		if (null != currentBatch) {
			Batch lastFinisBatch = batchDao.getLastByStatus(BatchStatus.FINISH);
			long lastFinishTimestamp = null == lastFinisBatch ? 0l : lastFinisBatch.getTimestamp();
			AtomicInteger seq = new AtomicInteger(0);
			log.info(String.format("Start process Batch[%s]", currentBatch.getCode()));
			try {
				List<BatchTask> newBatchTasks = Stream.of(batchTaskFileDir.listFiles())
						.filter(file -> null == batchTaskDao.getByFileName(file.getName()))
						.map(file -> createBatchTask(currentBatch, file))
						.filter(item -> item.getTimestamp() > lastFinishTimestamp
								&& item.getTimestamp() <= currentBatch.getTimestamp())
						.sorted((bt1, bt2) -> comparatorBatchTask(bt1, bt2)).map(item -> {
							item.setSeq(seq.getAndIncrement());
							return item;
						}).collect(Collectors.toList());
				checkResult(new File(filesDirPath).list(), newBatchTasks);
				if (!newBatchTasks.isEmpty()) {
					batchTaskDao.addAll(newBatchTasks);
					for (BatchTask item : newBatchTasks) {
						log.info(String.format(
								"Successful Listened BatchTask's related file[%s] and add BatchTask[%s]",
								item.getFileName(), item.getId()));
					}
				}
				batchDao.updateStatus(currentBatch.getId(), BatchStatus.TASK_LOCK);
				log.info(String.format("Successful process Batch[%s]", currentBatch.getCode()));
			} catch (Exception exception) {
				StringBuilder errorMsgBd = new StringBuilder();
				String titile = String.format("Exceptional process Batch[%s]",
						currentBatch.getCode());
				errorMsgBd.append(titile).append("\n");
				errorMsgBd.append("----------------source file list-----------------").append("\n");
				for (String fileName : batchTaskFileDir.list()) {
					errorMsgBd.append(fileName).append("\n");
				}
				errorMsgBd.append("------------------error msg----------------------").append("\n");
				String stackTraceMsg = ExceptionUtils.getStackTrace(exception);
				errorMsgBd.append(stackTraceMsg);
				String errorMsg = errorMsgBd.toString();
				batchDao.updateStatusAndErrorMsg(currentBatch.getId(), BatchStatus.ERROR, errorMsg);
				throw new WorkException(errorMsg, exception);
			} finally {
				runningCache.remove(currentBatch.getId());
			}
		}
	}

	private synchronized static Batch checkAndlookupBatch(BatchDao batchDao,
			EmailService emailService) {
		Batch taskLockBatch = batchDao.getEarliestByStatus(BatchStatus.TASK_LOCK);
		if (null != taskLockBatch) {
			log.warn(String.format("There is Batch[%s] to be processing and This run is cancelled",
					taskLockBatch.getCode()));
			return null;
		}
		Batch errorBatch = batchDao.getEarliestByStatus(BatchStatus.ERROR);
		if (null != errorBatch) {
			String title = String.format(
					"There is exceptional Batch[%s] that please first check its related file[%s]",
					errorBatch.getCode(), errorBatch.getFileName());
			log.warn(title);
			if (0 == errorBatch.getNoticeCount()) {
				emailService.sendQuietly(title, errorBatch.getErrorMsg());
				batchDao.updateNoticeCount(errorBatch.getId(), errorBatch.getNoticeCount() + 1);
			}
			return null;
		}
		List<Batch> lockBatchs = batchDao.listByStatus(BatchStatus.SELF_LOCK);
		for (Batch lockBatch : lockBatchs) {
			// 有batch正在处理，为了保证数据一致性，不能支持并发，也不需要支持并发
			if (runningCache.containsKey(lockBatch.getId())) {
				log.warn(String.format(
						"There is Batch[%s] to be processing and This run is cancelled",
						lockBatch.getCode()));
				return null;
			} else {
				// 有可能是系统异常中断导致,需要重新修正状态
				batchDao.updateStatus(lockBatch.getId(), BatchStatus.NEW);
			}
		}
		Batch currentBatch = batchDao.getEarliestByStatus(BatchStatus.NEW);
		if (null == currentBatch) {
			log.info("There is not new Batch need to be processed");
		} else {
			batchDao.updateStatus(currentBatch.getId(), BatchStatus.SELF_LOCK);
			runningCache.put(currentBatch.getId(), currentBatch);
		}
		return currentBatch;
	}

	private BatchTask createBatchTask(Batch batch, File file) {
		String[] metaInfos = StringUtils.split(file.getName(), ".");
		BatchTask newBatchTask = new BatchTask();
		newBatchTask.setBatchCode(batch.getCode());
		newBatchTask.setStatus(BatchTaskStatus.NEW);
		newBatchTask.setFileName(file.getName());
		newBatchTask.setFilePath(file.getPath());
		newBatchTask.setTableName(metaInfos[0]);
		newBatchTask.setDataProtocol(DataProtocol.valueOf(metaInfos[1].toUpperCase()));
		newBatchTask.setOperation(FileOperation.valueOf(metaInfos[2].toUpperCase()));
		newBatchTask.setTimestamp(Long.valueOf(metaInfos[3]));
		newBatchTask.setLockOffset(0);
		newBatchTask.setLockLength(0);
		return newBatchTask;
	}

	private static int comparatorBatchTask(BatchTask bt1, BatchTask bt2) {
		if (bt1.getTimestamp().equals(bt2.getTimestamp())) {
			if (FileOperation.UPSERT == bt1.getOperation()
					&& FileOperation.DEL == bt2.getOperation()) {
				return -1;
			} else if (FileOperation.DEL == bt1.getOperation()
					&& FileOperation.UPSERT == bt2.getOperation()) {
				return 1;
			} else {
				return bt1.getFileName().compareTo(bt2.getFileName());
			}
		} else {
			return bt1.getTimestamp().compareTo(bt2.getTimestamp());
		}
	}

	protected static void checkResult(String[] fileNames, List<BatchTask> batchTasks) {
		log.info("-----------------------source list-----------------------");
		for (String fileName : fileNames) {
			log.info(fileName);
		}
		log.info("-----------------------result list-----------------------");
		batchTasks.forEach(item -> log.info(item.getFileName()));
	}
}
