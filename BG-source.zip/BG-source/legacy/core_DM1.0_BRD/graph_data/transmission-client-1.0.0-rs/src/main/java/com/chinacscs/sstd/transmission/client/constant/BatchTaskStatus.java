package com.chinacscs.sstd.transmission.client.constant;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedJdbcTypes;
import org.apache.ibatis.type.MappedTypes;

/**
 * @author: liusong
 * @date: 2019年2月14日
 * @email: 359852326@qq.com
 * @version:
 * @describe: //TODO
 */
public enum BatchTaskStatus {

	/** 新的 **/
	NEW,

	/** 锁定 **/
	LOCK,

	/** 异常 **/
	ERROR,

	/** 完成 **/
	FINISH;

	private final static Set<String> names;

	static {
		names = new HashSet<>(BatchTaskStatus.values().length);
		for (BatchTaskStatus item : BatchTaskStatus.values()) {
			names.add(item.name());
		}
	}

	public static boolean validate(String value) {
		return names.contains(value);
	}

	@MappedTypes(value = BatchTaskStatus.class)
	@MappedJdbcTypes(value = {JdbcType.VARCHAR, JdbcType.CHAR})
	public static class Handler extends BaseTypeHandler<BatchTaskStatus> {

		@Override
		public void setNonNullParameter(PreparedStatement ps, int i, BatchTaskStatus parameter,
				JdbcType jdbcType) throws SQLException {
			ps.setString(i, parameter.name());
		}

		@Override
		public BatchTaskStatus getNullableResult(ResultSet rs, String columnName) throws SQLException {
			String value = rs.getString(columnName);
			return BatchTaskStatus.valueOf(value);
		}

		@Override
		public BatchTaskStatus getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
			String value = rs.getString(columnIndex);
			return BatchTaskStatus.valueOf(value);
		}

		@Override
		public BatchTaskStatus getNullableResult(CallableStatement cs, int columnIndex)
				throws SQLException {
			String value = cs.getString(columnIndex);
			return BatchTaskStatus.valueOf(value);
		}
	}
}
