package com.chinacscs.sstd.transmission.client.graphload;

import org.neo4j.driver.v1.Driver;
import org.neo4j.driver.v1.Session;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.driver.v1.summary.SummaryCounters;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.slf4j.Logger;

import java.util.stream.Collectors;

public class UpdateExecute {

    private static final SimpleDateFormat ft = new SimpleDateFormat("yyyyMMddhhmmss");

    PathHandler pathHandler;


    private UpdateExecute(PathHandler pathHandler) {
        this.pathHandler = pathHandler;
    }

    public static UpdateExecute getInstance(PathHandler pathHandler) {
        return new UpdateExecute(pathHandler);
    }

    public void setPathHandler(PathHandler pathHandler){
        this.pathHandler = pathHandler;
    }

    public boolean run(List<CsvFile> tobeUpdatedCsv, Driver driver, Logger logger,int commitNum,long limitLines) {
        ArrayList<String> linesForCsvLog = new ArrayList<>(tobeUpdatedCsv.size() + 1);
        linesForCsvLog.add("csv_file_name,cql_name,lines_of_csv,nodes,relationships,labels,start_time,end_time");
        boolean allSuccess = true;
        try{
            for (Iterator<CsvFile> iterator = tobeUpdatedCsv.iterator(); iterator.hasNext();) {
                // 读行数，for更新范围
                CsvFile csvFile = (CsvFile) iterator.next();
                logger.info("开始更新" + csvFile.fileName);
                csvFile.resultMap.put("start_time", ft.format(new Date()));
                if(!this.runForEachCsv(csvFile,driver,logger,commitNum,limitLines)){
                    allSuccess = false;
                }
                linesForCsvLog.add(csvFile.getResultMapValueAsLine());
            }

        }finally {
            driver.close();
        }

        String startTimeUpdateLog;
        if (tobeUpdatedCsv.size() > 0) {
            startTimeUpdateLog = "本次更新的csv按顺序依次为:\n" + (String) tobeUpdatedCsv.stream().map((i) -> {
                return i.fileName + " " + i.isInsert + " " + i.updateResult;
            }).collect(Collectors.joining("\n"));
            logger.info(startTimeUpdateLog);
        } else {
            logger.info("没有需要更新的csv文件");
            return true;
        }
        return allSuccess;
    }
    public boolean runForEachCsv(CsvFile csvFile,Driver driver, Logger logger,int commitNum,long limitLines){
        logger.info("开始更新" + csvFile.fileName);
        csvFile.resultMap.put("start_time", ft.format(new Date()));

        long lines = 0;
        try {
            Path csvFilePath = Paths.get(csvFile.sftpCsvPath);
            lines = Files.lines(csvFilePath).count();
        }catch (IOException e){
            logger.warn("读取csv文件行数异常:"+e.getMessage());
            return false;
        }

        long rounds = lines/limitLines+1;
        for(int i=0;i<rounds;i++){
            Session session = driver.session();
            long skipLines = i*limitLines;
            if(rounds==1){
                csvFile.updateCql(commitNum,-1,-1);
            }else {
                csvFile.updateCql(commitNum,skipLines,limitLines);
            }
            logger.info(csvFile.cql);
            try {
                StatementResult result = session.run(csvFile.cql);
                SummaryCounters couters = result.consume().counters();
                csvFile.resultMap.put("nodes", couters.nodesCreated() + "added " + couters.nodesDeleted() + "deleted");
                csvFile.resultMap.put("relationships", couters.relationshipsCreated() + "added " + couters.relationshipsDeleted() + "deleted");
                csvFile.resultMap.put("labels", couters.labelsAdded() + "added " + couters.labelsRemoved() + "removed");
                logger.info(csvFile.getResultMapValueAsLine());
                csvFile.resultMap.put("end_time", ft.format(new Date()));
                csvFile.updateResult = "成功Success";
            } catch (Exception e) {
                logger.error( "更新" + csvFile.fileName + "出错" + e.getMessage());
                csvFile.updateResult = "失败Fail";
                return false;
            }finally {
                session.close();
            }
            if(rounds>1){
                try{
                    Thread.sleep(1000 * 60);
                }catch (Exception e){
                    logger.warn("更新间歇1分钟异常:"+e.getMessage());
                }
            }
        }

        return true;
    }
}
