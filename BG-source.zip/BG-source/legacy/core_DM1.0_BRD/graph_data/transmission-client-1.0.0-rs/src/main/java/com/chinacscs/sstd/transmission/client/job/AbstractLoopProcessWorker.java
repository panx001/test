package com.chinacscs.sstd.transmission.client.job;

import java.util.Objects;

import com.chinacscs.sstd.transmission.client.entity.JobConfig;

/**
 * @author:  liusong
 * @date:    2019年2月28日
 * @email:   359852326@qq.com
 * @version: 
 * @describe: //TODO
 */
public abstract class AbstractLoopProcessWorker<T> extends AbstractWorker{

	public AbstractLoopProcessWorker(JobConfig jobConfig) {
		super(jobConfig);
	}

	@Override
	protected final void doExecute() throws Exception {
		Consumer<T> consumer=newConsumer();
		Objects.requireNonNull(consumer);
		while(true) {
			if(Status.STARTED==getStatus()) {
				T data=produce();
				consumer.consume(data);
			}else if(Status.STOP==getStatus()) {
				break;
			}else if(Status.FINISH==getStatus()) {
				break;
			}
		}
	}

	protected abstract T produce();
	
	protected abstract Consumer<T> newConsumer();
	
	@FunctionalInterface
	public interface Consumer<T>{
		void consume(T data);
	}
}
