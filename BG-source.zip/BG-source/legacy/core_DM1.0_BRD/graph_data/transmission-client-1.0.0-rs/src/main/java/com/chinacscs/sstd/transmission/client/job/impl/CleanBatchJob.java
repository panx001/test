package com.chinacscs.sstd.transmission.client.job.impl;

import java.io.File;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.chinacscs.sstd.transmission.client.constant.BatchStatus;
import com.chinacscs.sstd.transmission.client.dao.BatchDao;
import com.chinacscs.sstd.transmission.client.dao.BatchTaskDao;
import com.chinacscs.sstd.transmission.client.entity.Batch;
import com.chinacscs.sstd.transmission.client.entity.BatchTask;
import com.chinacscs.sstd.transmission.client.entity.JobConfig;
import com.chinacscs.sstd.transmission.client.job.AbstractWorker;
import com.chinacscs.sstd.transmission.client.util.DatetimeFormats;

import lombok.extern.slf4j.Slf4j;

/**
 * @author: liusong
 * @date: 2019年2月21日
 * @email: 359852326@qq.com
 * @version:
 * @describe: 清理batch定时job
 */
@Slf4j
public class CleanBatchJob extends AbstractWorker {

	/** 清理多少天以前的数据:默认15天以前 **/
	@Value("${app.job.cleanBatch.beforeDays:15}")
	private int beforeDays;

	@Autowired
	private BatchDao batchDao;

	@Autowired
	private BatchTaskDao batchTaskDao;

	public CleanBatchJob(JobConfig jobConfig) {
		super(jobConfig);
	}

	@Override
	protected void doExecute() throws Exception {
		Batch lastFinishBatch = batchDao.getLastByStatus(BatchStatus.FINISH);
		if (null == lastFinishBatch) {
			log.debug("There is not Batch need to clean");
			return;
		}
		Date lastFinishDate = DateUtils.parseDate(String.valueOf(lastFinishBatch.getTimestamp()),
				new String[]{DatetimeFormats.yyyyMMddhhmmssSSS});
		Date deadlineDate = DateUtils.addDays(lastFinishDate, -beforeDays);
		String deadlineStr = DateFormatUtils.format(deadlineDate,
				DatetimeFormats.yyyyMMddhhmmssSSS);
		long deadline = Long.valueOf(deadlineStr);
		List<Batch> cleanBatchs = batchDao.listBeforeTimestamp(deadline);
		if (null == cleanBatchs || cleanBatchs.isEmpty()) {
			log.debug("There is not Batch need to clean");
			return;
		}
		for (Batch cleanBatch : cleanBatchs) {
			List<BatchTask> batchTasks = batchTaskDao.listByBatchCode(cleanBatch.getCode());
			for (BatchTask batchTask : batchTasks) {
				FileUtils.deleteQuietly(new File(batchTask.getFilePath()));
				batchTaskDao.delete(batchTask.getId());
				log.info(String.format(
						"Successful clean Batch[%s]'s Task[%s] and delete its related file[%s]",
						cleanBatch.getCode(), batchTask.getId(), batchTask.getFilePath()));
			}
			FileUtils.deleteQuietly(new File(cleanBatch.getFilePath()));
			batchDao.delete(cleanBatch.getId());
			log.info(String.format("Successful clean Batch[%s] and delete its related file[%s]",
					cleanBatch.getCode(), cleanBatch.getFilePath()));
		}
	}

}
