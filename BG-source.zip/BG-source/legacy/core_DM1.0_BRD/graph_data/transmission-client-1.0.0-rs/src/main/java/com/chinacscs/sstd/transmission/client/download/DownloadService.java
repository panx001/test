package com.chinacscs.sstd.transmission.client.download;

import com.jcraft.jsch.ChannelSftp;

/**
 * @author jiangjie
 * @date 2019/2/15 10:51
 * @description TODO
 * @copyright chinacscs all rights reserved
 */
public interface DownloadService {
	/**
	 * 获取客户端本地的finish文件最大时间戳
	 *
	 * @param fileDir 客户端缓存的目录，如：hbase_json，neo4j_csv
	 * @return
	 */
	Long getMaxLocalFinishTime(String fileDir) throws Exception;

	/**
	 * 
	 * 获取sftp的finish文件最大时间戳
	 * 
	 * @param fileDir     sftp数据目录
	 * @param channelSftp
	 * @return
	 * @throws Exception
	 */
	Long getMaxSftpFinishTime(String fileDir, ChannelSftp channelSftp) throws Exception;

	/**
	 * 下载工商文件
	 *
	 * @param remoteDir 远程目录
	 * @param localDir  本地目录
	 */
	void downloadGsFile(String remoteDir, String localDir);

	/**
	 * 下载图谱文件
	 *
	 * @param remoteDir 远程目录
	 * @param localDir  本地目录
	 */
	void downloadGraphFile(String remoteDir, String localDir);

	/**
	 * 下载工商数据文件
	 */
	void downloadGsFile();

	/**
	 * 下载图谱数据文件
	 */
	void downloadGraphFile();
}