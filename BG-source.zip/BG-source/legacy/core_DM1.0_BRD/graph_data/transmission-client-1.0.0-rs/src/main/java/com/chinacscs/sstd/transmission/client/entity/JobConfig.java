package com.chinacscs.sstd.transmission.client.entity;

import com.chinacscs.platform.commons.entity.BaseEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @author:  liusong
 * @date:    2019年2月14日
 * @email:   359852326@qq.com
 * @version: 
 * @describe: //TODO
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class JobConfig extends BaseEntity{

	private String name;
	
	/** 时间触发表达式 **/
	private String cronScript;

	/** class名称 **/
	private String className;
	
	/** 能否并行 **/
	private Boolean parallel;
}
