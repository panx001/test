package com.chinacscs.sstd.transmission.client.job;

import java.util.Properties;

import org.quartz.impl.StdSchedulerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.stereotype.Component;

/**
 * @author: liusong
 * @date: 2019年2月20日
 * @email: 359852326@qq.com
 * @version:
 * @describe: //TODO
 */
@Component
public class QuartSchedulerFactory {

	/** 作业调度线程数-默认值:5 **/
	@Value("${app.job.thread.size:5}")
	private int jobThreadSize;
	
	@Bean
	public SchedulerFactoryBean initSchedulerFactoryBean() {
		Properties props = new Properties();
		props.put(StdSchedulerFactory.PROP_SCHED_INSTANCE_NAME, "DefaultQuartzScheduler");
		props.put(StdSchedulerFactory.PROP_SCHED_RMI_EXPORT, false);
		props.put(StdSchedulerFactory.PROP_SCHED_RMI_PROXY, false);
		props.put(StdSchedulerFactory.PROP_SCHED_WRAP_JOB_IN_USER_TX, false);
		props.put(StdSchedulerFactory.PROP_THREAD_POOL_CLASS, "org.quartz.simpl.SimpleThreadPool");
		/** org.quartz.threadPool下的所有配置必须字符类型，否则识别不了 **/
		props.put("org.quartz.threadPool.threadCount", String.valueOf(jobThreadSize));
		props.put("org.quartz.threadPool.threadPriority", "5");
		props.put("org.quartz.threadPool.threadsInheritContextClassLoaderOfInitializingThread",
				String.valueOf(true));
		/** org.quartz.threadPool下的所有配置必须字符类型，否则识别不了 **/
		SchedulerFactoryBean schedulerFactoryBean = new SchedulerFactoryBean();
		schedulerFactoryBean.setQuartzProperties(props);
		return schedulerFactoryBean;
	}
}
