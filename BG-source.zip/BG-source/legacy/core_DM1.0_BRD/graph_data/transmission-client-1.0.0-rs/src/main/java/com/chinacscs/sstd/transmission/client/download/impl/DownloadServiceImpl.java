package com.chinacscs.sstd.transmission.client.download.impl;

import com.chinacscs.sstd.transmission.client.component.EmailService;
import com.chinacscs.sstd.transmission.client.download.DownloadConfig;
import com.chinacscs.sstd.transmission.client.download.DownloadService;
import com.chinacscs.sstd.transmission.client.util.SftpUtils;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.SftpException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

/**
 * @author jiangjie
 * @date 2019/2/15 10:52
 * @description TODO
 * @copyright chinacscs all rights reserved
 */
@Service
@Slf4j
public class DownloadServiceImpl implements DownloadService {
    private static final long DEFAULT_MAX_FINISH_TIME = 20190227000000L;

    @Autowired
    private DownloadConfig syncConfig;
    @Autowired
    private EmailService emailService;

    private ChannelSftp getChannelSftp() throws Exception {
        ChannelSftp channelSftp = SftpUtils.getConnectionByPassword(syncConfig.getSftpUser(),
                syncConfig.getSftpPassword(), syncConfig.getSftpHost(), syncConfig.getSftpPort());
        log.info("远程SFTP连接成功!");
        return channelSftp;
    }

    private void closeChannel(ChannelSftp channelSftp) throws Exception {
        SftpUtils.close(channelSftp);
        log.info("已断开sftp连接");
    }

    @Override
    public Long getMaxLocalFinishTime(String fileDir) throws Exception {
        File file = FileUtils.getFile(fileDir);
        FileUtils.forceMkdir(file);
        return Arrays.stream(file.listFiles((dir, name) -> name.startsWith("finish.") || name.endsWith(".finish")))
                .map(File::getName).map(fileName -> fileName.replaceAll("\\.*finish\\.*", ""))
                .mapToLong(Long::parseLong).max().orElse(DEFAULT_MAX_FINISH_TIME);
    }

    @Override
    @SuppressWarnings("unchecked")
    public Long getMaxSftpFinishTime(String fileDir, ChannelSftp channelSftp) throws Exception {
        Long maxSftpFinishTimestamp = ((List<String>) (channelSftp.ls(fileDir).stream().map(Object::toString)
                .collect(Collectors.toList()))).stream()
                .filter(info -> info.matches(".*finish\\..*") || info.matches(".*\\.finish"))
                .map(info -> info.split(" +")[8]).map(fileName -> fileName.replaceAll("\\.*finish\\.*", ""))
                .mapToLong(Long::parseLong).max().orElse(DEFAULT_MAX_FINISH_TIME);
        return maxSftpFinishTimestamp;
    }

    @Override
    @SuppressWarnings("unchecked")
    public void downloadGsFile(String remoteDir, String localDir) {
        try {
            log.info("开始本批次工商数据文件下载");
            // 获取SFTP连接
            ChannelSftp channelSftp = getChannelSftp();
            try {
                // 找出本地已下载的最新finish文件时间戳
                String localFinishDir = String.join("/", localDir, syncConfig.getMetaDirName());
                Long maxDownloadedFinishTimestamp = getMaxLocalFinishTime(localFinishDir);
                log.info("本地已下载的最新finish文件时间戳：{}", maxDownloadedFinishTimestamp);
                // 找出sftp目录中最新finish文件时间戳
                String sftpFinishDir = String.join("/", remoteDir, syncConfig.getMetaDirName());
                Long maxSftpFinishTimestamp = getMaxSftpFinishTime(sftpFinishDir, channelSftp);
                log.info("sftp目录中最新finish文件时间戳：{}", maxSftpFinishTimestamp);
                // 如果sftp上没有比已下载文件更新的文件，直接返回
                if (maxDownloadedFinishTimestamp >= maxSftpFinishTimestamp) {
                    log.warn("远程sftp不存在新的需要下载的文件，本次下载任务退出........");
                    return;
                }
                // 开始下载所有数据文件
                AtomicBoolean allFilePull = new AtomicBoolean(true);
                String sftpDataDir = String.join("/", remoteDir, syncConfig.getDataDirName());
                String localDataDir = String.join("/", localDir, syncConfig.getDataDirName());
                FileUtils.forceMkdir(new File(localDataDir));
                log.info("开始下载远程目录：{} 下的文件", sftpDataDir);
                List<String> fileNames = ((List<String>) (channelSftp.ls(sftpDataDir).stream().map(Object::toString)
                        .collect(Collectors.toList())));
                fileNames.stream().filter(fileName -> fileName.matches(".*[json|csv]\\..*"))
                        .map(fileName -> fileName.split(" +")[8]).filter(fileName -> {
                    Long dataFileExportTime = Long.parseLong(fileName.substring(fileName.lastIndexOf(".") + 1));
                    return dataFileExportTime > maxDownloadedFinishTimestamp
                            && dataFileExportTime <= maxSftpFinishTimestamp;
                }).sorted((o1, o2) -> {
                    Long timestamp1 = Long.valueOf(o1.substring(o1.lastIndexOf(".") + 1));
                    Long timestamp2 = Long.valueOf(o2.substring(o2.lastIndexOf(".") + 1));
                    return timestamp1.compareTo(timestamp2);
                }).forEach(fileName -> {
                    String srcPath = String.join("/", sftpDataDir, fileName);
                    String distPath = String.join("/", localDataDir, fileName);
                    try {
                        channelSftp.get(srcPath, distPath, null, ChannelSftp.RESUME);
                        log.info("已成功将{}下载至{}", srcPath, distPath);
                    } catch (SftpException e) {
                        log.error("{}下载出错", srcPath, e);
                        allFilePull.set(false);
                    }
                });
                // 下载数据文件完成后下载所有finish文件
                if (allFilePull.get()) {
                    log.info("开始下载远程目录：{} 下的文件", sftpFinishDir);
                    ((List<String>) (channelSftp.ls(sftpFinishDir).stream().map(Object::toString)
                            .collect(Collectors.toList())))
                            .stream()
                            .filter(fileName -> fileName.matches(".*finish\\..*")
                                    || fileName.matches(".*\\.finish"))
                            .map(fileName -> fileName.split(" +")[8]).filter(fileName -> {
                        Long finishFileExportTime = Long
                                .parseLong(fileName.substring(fileName.lastIndexOf(".") + 1));
                        return finishFileExportTime > maxDownloadedFinishTimestamp
                                && finishFileExportTime <= maxSftpFinishTimestamp;
                    }).sorted((o1, o2) -> {
                        Long timestamp1 = Long.parseLong(o1.substring(o1.lastIndexOf(".") + 1));
                        Long timestamp2 = Long.parseLong(o2.substring(o2.lastIndexOf(".") + 1));
                        return timestamp1.compareTo(timestamp2);
                    }).forEach(fileName -> {
                        String srcPath = String.join("/", sftpFinishDir, fileName);
                        String distPath = String.join("/", localFinishDir, fileName);
                        try {
                            channelSftp.get(srcPath, distPath);
                            log.info("已成功将{}下载至{}", srcPath, distPath);
                        } catch (SftpException e) {
                            log.error("{}下载出错", srcPath, e);
                        }
                    });
                } else {
                    // 发送预警邮件
                    emailService.sendSimpleMail(syncConfig.getSendTo(), "数据传输工具预警", "本批次工商数据文件未全部下载");
                }
                log.info("远程目录:{} 本批次工商数据文件下载完成！", remoteDir);
            } catch (Exception e) {
                log.error("下载工商数据文件出错", e);
                // 发送预警邮件
                emailService.sendSimpleMail(syncConfig.getSendTo(), "数据传输工具预警", "下载工商数据文件出错");
            } finally {
                try {
                    if (channelSftp != null) {
                        closeChannel(channelSftp);
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error("获取SFTP连接失败", e);
            // 发送预警邮件
            emailService.sendSimpleMail(syncConfig.getSendTo(), "数据传输工具预警", "获取SFTP连接失败");
        }
    }

    @Override
    public void downloadGraphFile(String remoteDir, String localDir) {
        try {
            log.info("开始本批次图谱数据文件下载");
            // 获取SFTP连接
            ChannelSftp channelSftp = getChannelSftp();
            try {
                // 找出本地已下载的最新finish文件时间戳
                String localFinishDir = String.join("/", localDir, syncConfig.getFinishDirName());
                Long maxDownloadedFinishTimestamp = getMaxLocalFinishTime(localFinishDir);
                log.info("本地已下载的最新finish文件时间戳：{}", maxDownloadedFinishTimestamp);
                // 找出sftp目录中最新finish文件时间戳
                String sftpFinishDir = String.join("/", remoteDir, syncConfig.getFinishDirName());
                Long maxSftpFinishTimestamp = getMaxSftpFinishTime(sftpFinishDir, channelSftp);
                log.info("sftp目录中最新finish文件时间戳：{}", maxSftpFinishTimestamp);
                // 如果sftp上没有比已下载文件更新的文件，直接返回
                if (maxDownloadedFinishTimestamp >= maxSftpFinishTimestamp) {
                    log.warn("远程sftp不存在新的需要下载的文件，本次下载任务退出........");
                    return;
                }
                // 开始下载所有数据文件
                AtomicBoolean allFilePull = new AtomicBoolean(true);
                String sftpInsertDataDir = String.join("/", remoteDir, syncConfig.getInsertDirName());
                String sftpDeleteDataDir = String.join("/", remoteDir, syncConfig.getDeleteDirName());
                String localInsertDataDir = String.join("/", localDir, syncConfig.getInsertDirName());
                String localDeleteDataDir = String.join("/", localDir, syncConfig.getDeleteDirName());
                FileUtils.forceMkdir(new File(localInsertDataDir));
                FileUtils.forceMkdir(new File(localDeleteDataDir));
                downloadRemoteGraphFiles(channelSftp, sftpInsertDataDir, localInsertDataDir,
                        maxDownloadedFinishTimestamp, maxSftpFinishTimestamp, allFilePull);
                downloadRemoteGraphFiles(channelSftp, sftpDeleteDataDir, localDeleteDataDir,
                        maxDownloadedFinishTimestamp, maxSftpFinishTimestamp, allFilePull);
                // 下载数据文件完成后下载所有finish文件
                if (allFilePull.get()) {
                    log.info("开始下载远程目录：{} 下的文件", sftpFinishDir);
                    lsRemoteDir(channelSftp, sftpFinishDir).stream()
                            .filter(fileName -> fileName.matches(".*finish\\..*") || fileName.matches(".*\\.finish"))
                            .map(fileName -> fileName.split(" +")[8]).filter(fileName -> {
                        Long finishFileExportTime = Long
                                .parseLong(fileName.substring(fileName.lastIndexOf(".") + 1));
                        return finishFileExportTime > maxDownloadedFinishTimestamp
                                && finishFileExportTime <= maxSftpFinishTimestamp;
                    }).sorted((o1, o2) -> {
                        Long timestamp1 = Long.parseLong(o1.substring(o1.lastIndexOf(".") + 1));
                        Long timestamp2 = Long.parseLong(o2.substring(o2.lastIndexOf(".") + 1));
                        return timestamp1.compareTo(timestamp2);
                    }).forEach(fileName -> {
                        String srcPath = String.join("/", sftpFinishDir, fileName);
                        String distPath = String.join("/", localFinishDir, fileName);
                        try {
                            channelSftp.get(srcPath, distPath);
                            log.info("已成功将{}下载至{}", srcPath, distPath);
                        } catch (SftpException e) {
                            log.error("{}下载出错", srcPath, e);
                        }
                    });
                } else {
                    // 发送预警邮件
                    emailService.sendSimpleMail(syncConfig.getSendTo(), "数据传输工具预警", "本批次图谱数据文件未全部下载");
                }
                log.info("远程目录:{} 本批次图谱数据文件下载完成！", remoteDir);
            } catch (Exception e) {
                log.error("下载图谱数据文件出错", e);
                // 发送预警邮件
                emailService.sendSimpleMail(syncConfig.getSendTo(), "数据传输工具预警", "下载图谱数据文件出错");
            } finally {
                try {
                    if (channelSftp != null) {
                        closeChannel(channelSftp);
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error("获取SFTP连接失败", e);
            // 发送预警邮件
            emailService.sendSimpleMail(syncConfig.getSendTo(), "数据传输工具预警", "获取SFTP连接失败");
        }
    }

    private void downloadRemoteGraphFiles(ChannelSftp channelSftp, String remoteDir, String localDir,
                                          Long maxDownloadedFinishTimestamp, Long maxSftpFinishTimestamp, AtomicBoolean allFilePull)
            throws Exception {
        log.info("开始下载图谱远程目录：{} 下的文件", remoteDir);
        List<String> fileNames = lsRemoteDir(channelSftp, remoteDir);
        // 遍历d开头并且不以.结尾的表名称文件夹
        fileNames.stream().filter(fileName -> fileName.startsWith("d") && !fileName.endsWith("."))
                .map(fileName -> fileName.split(" +")[8]).forEach(tableName -> {
            String remoteTableDir = String.join("/", remoteDir, tableName);
            String localTableDir = String.join("/", localDir, tableName);
            try {
                List<String> remoteTableFileNames = lsRemoteDir(channelSftp, remoteTableDir);
                // 遍历-开头的数据文件
                remoteTableFileNames.stream().filter(fileName -> fileName.startsWith("-") && fileName.endsWith(".csv"))
                        .map(fileName -> fileName.split(" +")[8]).filter(fileName -> {
                    Long dataFileExportTime = Long.parseLong(fileName
                            .substring(fileName.lastIndexOf("_") + 1, fileName.lastIndexOf(".")));
                    return dataFileExportTime > maxDownloadedFinishTimestamp
                            && dataFileExportTime <= maxSftpFinishTimestamp;
                }).sorted((o1, o2) -> {
                    Long timestamp1 = Long
                            .valueOf(o1.substring(o1.lastIndexOf("_") + 1, o1.lastIndexOf(".")));
                    Long timestamp2 = Long
                            .valueOf(o2.substring(o2.lastIndexOf("_") + 1, o2.lastIndexOf(".")));
                    return timestamp1.compareTo(timestamp2);
                }).forEach(fileName -> {
                    String srcPath = String.join("/", remoteTableDir, fileName);
                    try {
                        FileUtils.forceMkdir(new File(localTableDir));
                        String distPath = String.join("/", localTableDir, fileName);
                        channelSftp.get(srcPath, distPath, null, ChannelSftp.RESUME);
                        log.info("已成功将{}下载至{}", srcPath, distPath);
                    } catch (Exception e) {
                        log.error("{}下载出错", srcPath, e);
                        allFilePull.set(false);
                    }
                });
            } catch (Exception e) {
                log.error(e.getMessage(), e);
                throw new RuntimeException("下载图谱数据文件出错");
            }
        });
    }

    @SuppressWarnings("unchecked")
    private List<String> lsRemoteDir(ChannelSftp channelSftp, String remoteDir) throws Exception {
        return (List<String>) channelSftp.ls(remoteDir).stream().map(Object::toString).collect(Collectors.toList());
    }

    @Override
    public void downloadGsFile() {
        downloadGsFile(syncConfig.getSftpGsDir(), syncConfig.getLocalGsDir());
    }

    @Override
    public void downloadGraphFile() {
        downloadGraphFile(syncConfig.getSftpGraphDir(), syncConfig.getLocalGraphDir());
    }

}