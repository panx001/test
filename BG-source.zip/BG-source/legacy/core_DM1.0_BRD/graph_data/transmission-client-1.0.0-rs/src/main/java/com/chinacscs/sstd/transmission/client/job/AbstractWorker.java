package com.chinacscs.sstd.transmission.client.job;

import java.util.UUID;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

import org.springframework.beans.factory.annotation.Autowired;

import com.chinacscs.sstd.transmission.client.component.EmailService;
import com.chinacscs.sstd.transmission.client.entity.JobConfig;
import com.chinacscs.sstd.transmission.client.job.exception.WorkException;

import lombok.extern.slf4j.Slf4j;

/**
 * @author: liusong
 * @date: 2019年2月15日
 * @email: 359852326@qq.com
 * @version:
 * @describe: //TODO
 */
@Slf4j
public abstract class AbstractWorker implements Worker {

	private final static AtomicReferenceFieldUpdater<AbstractWorker, Status> status = AtomicReferenceFieldUpdater
			.newUpdater(AbstractWorker.class, Status.class, "statusValue");

	private String name;

	private volatile Status statusValue = Status.READY;

	private JobConfig jobConfig;

	@Autowired
	private JobSchedule jobSchedule;

	@Autowired
	private EmailService emailService;

	public AbstractWorker(JobConfig jobConfig) {
		this.name = UUID.randomUUID().toString();
		this.jobConfig = jobConfig;
	}

	@Override
	public final void start() {
		if (status.compareAndSet(this, Status.READY, Status.STARTED)) {
			String namePre = Thread.currentThread().getName();
			Thread.currentThread().setName(namePre + "-job[" + jobConfig.getName() + "]");
			try {
				doExecute();
				if (Status.STOP == getStatus()) {
					status.compareAndSet(this, Status.STOP, Status.STOPED);
					log.info("The current worker[{}] has been call stop", getName());
				} else {
					status.compareAndSet(this, Status.STARTED, Status.FINISHED);
					log.info("The current worker[{}] has been call finish", getName());
				}
			} catch (WorkException exception) {
				status.compareAndSet(this, Status.STARTED, Status.ERROR_END);
				log.error(String.format("Happen error when execute job[%s]", jobConfig.getName()),
						exception);
			} catch (Exception exception) {
				status.compareAndSet(this, Status.STARTED, Status.ERROR_END);
				log.error(String.format("Unknow error when execute job[%s]", jobConfig.getName()),
						exception);
			} finally {
				Thread.currentThread().setName(namePre);
			}
		}
	}

	@Override
	public final void stop() {
		if (status.compareAndSet(this, Status.STARTED, Status.STOP)) {
			log.info("Already call worker[{}] stop", getName());
		}
	}

	protected abstract void doExecute() throws Exception;

	@Autowired
	public Status getStatus() {
		return statusValue;
	}

	@Autowired
	public String getName() {
		return name;
	}

	@Autowired
	public JobConfig getJobConfig() {
		return jobConfig;
	}

	protected JobSchedule getJobSchedule() {
		return jobSchedule;
	}

	protected EmailService getEmailService() {
		return emailService;
	}
}
