package com.chinacscs.sstd.transmission.client.job;

import com.chinacscs.sstd.transmission.client.entity.JobConfig;

/**
 * @author:  liusong
 * @date:    2019年2月17日
 * @email:   359852326@qq.com
 * @version: 
 * @describe: //TODO
 */
public interface Worker {

	String getName();
	
	Status getStatus();
	
	void start()throws Exception;
	
	void stop();
	
	JobConfig getJobConfig();
	
	enum Status{
		/**准备好**/
		READY,
				
		/**已经开始**/
		STARTED,
		
//		/**暂停**/
//		SUSPEND,
//		
//		/**已经暂停**/
//		SUSPENDED,
		
		/**停止**/
		STOP,
		
		/**已经停止**/
		STOPED,
		
		/**错误结束**/
		ERROR_END,
		
		/**完成**/
		FINISH,
		
		/**完成**/
		FINISHED;
	}
}
