package com.chinacscs.sstd.transmission.client.util;

import java.util.Objects;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

/**
 * @author: jiangjie
 * @date: 2019年2月15日
 * @email: 359852326@qq.com
 * @version:
 * @describe: sftp工具类
 */
public class SftpUtils {

	/**默认打开连接超时:6秒**/
	final static int DEFAULT_TIMEOUT = 10000;

	public static ChannelSftp getConnectionByPassword(String userName, String password, String host,
			Integer port) throws JSchException {
		JSch jSch = new JSch();
		Session sshSession = jSch.getSession(userName, host, port);
		sshSession.setPassword(password);
		sshSession.setConfig("StrictHostKeyChecking", "no");
		//sshSession.setTimeout(DEFAULT_TIMEOUT);
		sshSession.connect();
		ChannelSftp channelSftp = (ChannelSftp) sshSession.openChannel("sftp");
		//channelSftp.connect(DEFAULT_TIMEOUT);
		channelSftp.connect();
		return channelSftp;
	}
	
	public static ChannelSftp getConnectionByKey(String username, String prvkey, String host, Integer port) throws JSchException {
        JSch jSch = new JSch();
        jSch.addIdentity(prvkey);
        Session sshSession = jSch.getSession(username, host, port);
        sshSession.setConfig("StrictHostKeyChecking", "no");
        sshSession.setConfig("ServerAliveInterval", "30");
        sshSession.connect();
        ChannelSftp sftp = (ChannelSftp) sshSession.openChannel("sftp");
        sftp.connect();
        return sftp;
    }

	public static void close(ChannelSftp channelSftp) throws JSchException {
		Objects.requireNonNull(channelSftp);
		channelSftp.disconnect();
		channelSftp.getSession().disconnect();
	}
}
