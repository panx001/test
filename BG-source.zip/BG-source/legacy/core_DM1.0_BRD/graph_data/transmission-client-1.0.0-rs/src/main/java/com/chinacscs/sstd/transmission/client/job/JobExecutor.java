//package com.chinacscs.sstd.transmission.client.job;
//
//import java.util.concurrent.ConcurrentHashMap;
//import java.util.concurrent.ExecutorService;
//import java.util.concurrent.Executors;
//import java.util.concurrent.LinkedBlockingQueue;
//import java.util.concurrent.ScheduledExecutorService;
//import java.util.concurrent.ThreadPoolExecutor;
//import java.util.concurrent.TimeUnit;
//import java.util.concurrent.atomic.AtomicInteger;
//
//import javax.annotation.PreDestroy;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.InitializingBean;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import com.chinacscs.sstd.transmission.client.entity.JobConfig;
//
///**
// * @author: liusong
// * @date: 2019年2月17日
// * @email: 359852326@qq.com
// * @version:
// * @describe: //TODO
// */
//@Component
//public class JobExecutor implements InitializingBean {
//
//	final static Logger log = LoggerFactory.getLogger(JobExecutor.class);
//
//	private static final String MAINTAIN_THREAD_NAME_PRE = "maintain-thread-";
//
//	private static final String WOKR_THREAD_NAME_PRE = "work-thread-";
//
//	private static AtomicInteger maintainTheadIndex = new AtomicInteger(0);
//
//	private static AtomicInteger workTheadIndex = new AtomicInteger(0);
//
//	private ScheduledExecutorService maintainThreadPool;
//
//	private ExecutorService workThreadPool;
//
//	private ConcurrentHashMap<String, Worker> workerMap = new ConcurrentHashMap<>();
//
//	private LinkedBlockingQueue<Worker> endWorkerQueue = new LinkedBlockingQueue<>();
//
//	@Autowired
//	private WorkerFactory workerFactory;
//
//	@Autowired
//	private JobSchedule jobSchedule;
//
//	@Override
//	public void afterPropertiesSet() throws Exception {
//		maintainThreadPool = Executors.newScheduledThreadPool(4, this::maintainThreadFactory);
//		workThreadPool = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS,
//				new LinkedBlockingQueue<Runnable>(), this::workThreadFactory);
//		maintainThreadPool.execute(this::reportEndJobWorker);
//	}
//
//	private void reportEndJobWorker() {
//		while (true) {
//			Worker endWorker = null;
//			try {
//				endWorker = endWorkerQueue.take();
//			} catch (InterruptedException e) {
//				// 忽略
//			}
//			if (null != endWorker) {
//				try {
//					jobSchedule.endJobWorker(endWorker.getJobConfig().getName(),
//							endWorker.getName());
//				} catch (Exception exception) {
//					log.error(
//							String.format("report job[]'s worker[] is end error",
//									endWorker.getJobConfig().getName(), endWorker.getName()),
//							exception);
//				}
//			}
//		}
//	}
//
//	private Thread maintainThreadFactory(Runnable run) {
//		Thread thread = new Thread(run,
//				MAINTAIN_THREAD_NAME_PRE + maintainTheadIndex.getAndIncrement() + "-");
//		thread.setDaemon(false);
//		return thread;
//	}
//
//	private Thread workThreadFactory(Runnable run) {
//		Thread thread = new Thread(run,
//				WOKR_THREAD_NAME_PRE + workTheadIndex.getAndIncrement() + "-");
//		thread.setDaemon(false);
//		return thread;
//	}
//
//	public String submit(JobConfig jobConfig) {
//		String workerName = null;
//		Worker worker;
//		try {
//			worker = workerFactory.createWorker(jobConfig);
//			workerName = worker.getName();
//			workerMap.put(workerName, worker);
//		} catch (Exception exception) {
//			log.error(String.format("Create job[%s]'s worker[%s] error", jobConfig.getName(),
//					jobConfig.getClassName()), exception);
//		}
//		return workerName;
//	}
//
//	public void confirm(String workerName) {
//		Worker worker = workerMap.get(workerName);
//		if (null != worker) {
//			workThreadPool.execute(() -> {
//				try {
//					worker.start();
//				} catch (Exception exception) {
//					log.error(String.format("The job[%s]'s worker[%s] execute error",
//							worker.getJobConfig().getName(), worker.getJobConfig().getClassName()),
//							exception);
//				} finally {
//					endWorkerQueue.add(worker);
//				}
//			});
//		}
//	}
//
//	@PreDestroy
//	public void shutdown() {
//		if (null != workThreadPool) {
//			workThreadPool.shutdown();
//		}
//	}
//}
