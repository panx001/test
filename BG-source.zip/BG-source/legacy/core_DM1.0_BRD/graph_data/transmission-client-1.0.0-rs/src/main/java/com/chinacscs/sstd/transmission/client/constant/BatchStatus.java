package com.chinacscs.sstd.transmission.client.constant;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedJdbcTypes;
import org.apache.ibatis.type.MappedTypes;

/**
 * @author: liusong
 * @date: 2019年2月14日
 * @email: 359852326@qq.com
 * @version:
 * @describe: //TODO
 */
public enum BatchStatus {

	/** 新的 **/
	NEW,

	/** 自身锁定 **/
	SELF_LOCK,
	
	/** 子任务锁定 **/
	TASK_LOCK,

	/** 异常 **/
	ERROR,

	/** 完成 **/
	FINISH;

	private final static Set<String> names;

	static {
		names = new HashSet<>(BatchStatus.values().length);
		for (BatchStatus item : BatchStatus.values()) {
			names.add(item.name());
		}
	}

	public static boolean validate(String value) {
		return names.contains(value);
	}

	@MappedTypes(value = BatchStatus.class)
	@MappedJdbcTypes(value = {JdbcType.VARCHAR, JdbcType.CHAR})
	public static class Handler extends BaseTypeHandler<BatchStatus> {

		@Override
		public void setNonNullParameter(PreparedStatement ps, int i, BatchStatus parameter,
				JdbcType jdbcType) throws SQLException {
			ps.setString(i, parameter.name());
		}

		@Override
		public BatchStatus getNullableResult(ResultSet rs, String columnName) throws SQLException {
			String value = rs.getString(columnName);
			return BatchStatus.valueOf(value);
		}

		@Override
		public BatchStatus getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
			String value = rs.getString(columnIndex);
			return BatchStatus.valueOf(value);
		}

		@Override
		public BatchStatus getNullableResult(CallableStatement cs, int columnIndex)
				throws SQLException {
			String value = cs.getString(columnIndex);
			return BatchStatus.valueOf(value);
		}
	}
}
