package com.chinacscs.sstd.transmission.client.job;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import org.quartz.CronScheduleBuilder;
import org.quartz.Job;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.SmartLifecycle;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.stereotype.Component;

import com.chinacscs.platform.commons.exception.SystemAppException;
import com.chinacscs.platform.commons.util.ValidateUitls;
import com.chinacscs.sstd.transmission.client.dao.JobConfigDao;
import com.chinacscs.sstd.transmission.client.entity.JobConfig;

/**
 * @author: liusong
 * @date: 2018年12月19日
 * @email: 359852326@qq.com
 * @version:
 * @describe:
 */
@Component
public class JobSchedule implements InitializingBean, SmartLifecycle {

	final static Logger log = LoggerFactory.getLogger(JobSchedule.class);

	public static final String JOB_CONFIG_KEY = "job_config";

	public static final String JOB_SCHEDULE_KEY = "job_schedule";

	private final static String DEFAULT_JOB_GROUP = "group";

	private static final String WOKRER_THREAD_NAME_PRE = "worker-thread-";

	private static AtomicInteger workerTheadIndex = new AtomicInteger(0);

	@Value("${app.job.worker.thread.size}")
	private int workerThreadSize;

	private ConcurrentHashMap<String, JobConfig> runningJobMap = new ConcurrentHashMap<>();

	private ConcurrentHashMap<String, Worker> workerMap = new ConcurrentHashMap<>();

	private Scheduler scheduler;

	private ExecutorService workThreadPool;

	@Autowired
	private SchedulerFactoryBean schedulerFactoryBean;

	@Autowired
	private WorkerFactory workerFactory;

	@Autowired
	private JobConfigDao jobConfigDao;

	private AtomicBoolean status = new AtomicBoolean(false);

	@Override
	public void afterPropertiesSet() throws Exception {
		this.scheduler = schedulerFactoryBean.getScheduler();
		this.workThreadPool = new ThreadPoolExecutor(workerThreadSize, workerThreadSize, 0L,
				TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(),
				this::workThreadFactory);
	}

	@Override
	public void start() {
		status.set(true);
		List<JobConfig> list = jobConfigDao.listAll();
		for (JobConfig jobConfig : list) {
			joinTrigger(jobConfig);
		}
	}

	private Thread workThreadFactory(Runnable run) {
		String name = WOKRER_THREAD_NAME_PRE + workerTheadIndex.getAndIncrement() + "-";
		Thread thread = new Thread(run, name);
		thread.setDaemon(false);
		return thread;
	}

	public synchronized Boolean trigger(Long jobId) {
		checkStatus();
		JobConfig jobConfig = ValidateUitls.nonnull(jobConfigDao.get(jobId),
				String.format("The job[%s] is illegal", jobId));
		JobKey jobKey = buildJobKey(jobConfig);
		try {
			scheduler.triggerJob(jobKey);
		} catch (SchedulerException exception) {
			throw new SystemAppException(
					String.format("The jobDeploy[%s] fire trigger error", jobId), exception);
		}
		return true;
	}

	private boolean joinTrigger(JobConfig jobConfig) {
		JobKey jobKey = buildJobKey(jobConfig);
		try {
			synchronized (scheduler) {
				if (!scheduler.checkExists(jobKey)) {
					TriggerBuilder<Trigger> triggerBuilder = TriggerBuilder.newTrigger();
					CronScheduleBuilder cronScheduleBuilder = CronScheduleBuilder
							.cronSchedule(jobConfig.getCronScript());
					triggerBuilder.withSchedule(cronScheduleBuilder);
					triggerBuilder.startNow();
					Trigger trigger = triggerBuilder.build();
					JobBuilder jobBuilder = JobBuilder.newJob(ScheduledJob.class);
					jobBuilder.withIdentity(jobKey);
					JobDataMap newJobDataMap = new JobDataMap();
					newJobDataMap.put(JOB_CONFIG_KEY, jobConfig);
					newJobDataMap.put(JOB_SCHEDULE_KEY, JobSchedule.this);
					jobBuilder.usingJobData(newJobDataMap);
					JobDetail jobDetail = jobBuilder.build();
					return null != scheduler.scheduleJob(jobDetail, trigger);
				}
			}
		} catch (Exception exception) {
			throw new SystemAppException(exception);
		}
		return false;
	}

	private static JobKey buildJobKey(JobConfig jobConfig) {
		return new JobKey(jobConfig.getName(), DEFAULT_JOB_GROUP);
	}

	public synchronized void execute(String jobName) {
		checkStatus();
		JobConfig jobConfig = jobConfigDao.getByName(jobName);
		if (null != jobConfig) {
			JobKey jobKey = buildJobKey(jobConfig);
			try {
				scheduler.triggerJob(jobKey);
			} catch (SchedulerException exception) {
				throw new SystemAppException(exception);
			}
		}
	}

	private synchronized void doExecute(JobConfig jobConfig) {
		checkStatus();
		Objects.requireNonNull(jobConfig);
		if (jobIsRunning(jobConfig.getName()) && !jobConfig.getParallel()) {
			log.info(String.format("The job[%s] is running and will not shedule",
					jobConfig.getName()));
			return;
		}
		Worker worker;
		try {
			worker = workerFactory.createWorker(jobConfig);
		} catch (Exception exception) {
			log.error(String.format("Create job[%s]'s worker[%s] error", jobConfig.getName(),
					jobConfig.getClassName()), exception);
			return;
		}
		runningJobMap.put(jobConfig.getName(), jobConfig);
		workerMap.put(worker.getName(), worker);
		workThreadPool.execute(() -> {
			try {
				worker.start();
			} catch (Exception exception) {
				log.error(String.format("The job[%s]'s worker[%s] execute error",
						worker.getJobConfig().getName(), worker.getJobConfig().getClassName()),
						exception);
			} finally {
				workerMap.remove(worker.getName());
				runningJobMap.remove(jobConfig.getName());
			}
		});
	}

	public synchronized boolean jobIsRunning(String jobName) {
		return runningJobMap.containsKey(jobName);
	}

	private void checkStatus() {
		if (!isRunning()) {
			throw new IllegalStateException();
		}
	}

	@Override
	public synchronized boolean isRunning() {
		return status.get();
	}

	@Override
	public synchronized void stop() {
		status.set(false);
		workerMap.values().forEach(item -> {
			item.stop();
		});
		log.info("Start waiting for all worker is stoped");
		while (true) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// 忽略
			}
			if (workerMap.isEmpty()) {
				break;
			}
		}
		log.info("The all worker is stoped");
		if (null != workThreadPool) {
			workThreadPool.shutdown();
		}
	}

	public static class ScheduledJob implements Job {

		@Override
		public void execute(JobExecutionContext context) throws JobExecutionException {
			JobSchedule jobManager = (JobSchedule) context.getJobDetail().getJobDataMap()
					.get(JOB_SCHEDULE_KEY);
			JobConfig jobConfig = (JobConfig) context.getJobDetail().getJobDataMap()
					.get(JOB_CONFIG_KEY);
			jobManager.doExecute(jobConfig);
		}
	}
}
