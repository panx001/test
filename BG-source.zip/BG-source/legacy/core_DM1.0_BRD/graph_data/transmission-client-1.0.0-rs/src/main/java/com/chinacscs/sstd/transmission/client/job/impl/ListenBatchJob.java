package com.chinacscs.sstd.transmission.client.job.impl;

import java.io.File;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.chinacscs.sstd.transmission.client.constant.BatchStatus;
import com.chinacscs.sstd.transmission.client.dao.BatchDao;
import com.chinacscs.sstd.transmission.client.entity.JobConfig;
import com.chinacscs.sstd.transmission.client.entity.Batch;
import com.chinacscs.sstd.transmission.client.job.AbstractWorker;

import lombok.extern.slf4j.Slf4j;

/**
 * @author: liusong
 * @date: 2019年2月14日
 * @email: 359852326@qq.com
 * @version:
 * @describe: 监听meta目录finish后缀文件job
 */
@Slf4j
public class ListenBatchJob extends AbstractWorker {

	private final static String FILE_NAME_FIX_PREFIX = "finish.";

	@Value("${app.job.listenBatch.path}")
	private String filesDirPath;

	@Autowired
	private BatchDao batchDao;

	public ListenBatchJob(JobConfig jobConfig) {
		super(jobConfig);
	}

	@Override
	protected void doExecute() {
		File batchFileDir = new File(filesDirPath);
		if (!batchFileDir.exists()||!batchFileDir.isDirectory()) {
			log.warn("The path[{}] does not exist or is not a directory", filesDirPath);
			return;
		}
		List<Batch> newBatchs = Stream.of(batchFileDir.listFiles())
				.filter(file -> StringUtils.startsWith(file.getName(), FILE_NAME_FIX_PREFIX)
						&& null == batchDao.getByFileName(file.getName()))
				.map(file -> createBatch(file))
				/** 文件名(20190215120000500)比较器 **/
				.sorted((b1, b2) -> b1.getTimestamp().compareTo(b2.getTimestamp()))
				.collect(Collectors.toList());
		if (null == newBatchs || newBatchs.isEmpty()) {
			log.info("There is not Batch's related file need to be listened");
		} else {
			batchDao.addAll(newBatchs);
			for (Batch newBatch : newBatchs) {
				log.info(String.format(
						"Successful Listened Batch's related file[%s] and add Batch[%s]",
						newBatch.getFileName(), newBatch.getCode()));
			}
		}
	}

	private static Batch createBatch(File file) {
		String timestampStr = StringUtils.remove(file.getName(), FILE_NAME_FIX_PREFIX);
		Long timestamp = Long.valueOf(timestampStr);
		Batch batch = new Batch();
		batch.setCode(timestamp);
		batch.setStatus(BatchStatus.NEW);
		batch.setFileName(file.getName());
		batch.setFilePath(file.getPath());
		batch.setTimestamp(timestamp);
		return batch;
	}
}
