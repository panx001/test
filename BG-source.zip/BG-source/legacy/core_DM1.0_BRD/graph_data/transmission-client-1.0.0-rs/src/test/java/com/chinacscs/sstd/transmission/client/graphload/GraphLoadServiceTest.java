package com.chinacscs.sstd.transmission.client.graphload;

import com.chinacscs.sstd.transmission.client.BaseTest;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author flackyang
 * @date 2019/2/19 17:05
 * @description TODO
 * @copyright(c) chinacscs all rights reserved
 */
public class GraphLoadServiceTest extends BaseTest {

    @Autowired
    private GraphLoadService graphLoadService;

    @Test
    public void loadGraphFile() throws Exception {
        //TODO 开始进行图谱文件的加载
        graphLoadService.loadGraphFile();
    }
}