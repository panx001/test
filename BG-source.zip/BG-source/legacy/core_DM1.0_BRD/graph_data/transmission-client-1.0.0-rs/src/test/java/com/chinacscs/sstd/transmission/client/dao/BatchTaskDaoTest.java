package com.chinacscs.sstd.transmission.client.dao;

import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.chinacscs.sstd.transmission.client.BaseTest;
import com.chinacscs.sstd.transmission.client.constant.BatchTaskStatus;
import com.chinacscs.sstd.transmission.client.constant.DataProtocol;
import com.chinacscs.sstd.transmission.client.constant.FileOperation;
import com.chinacscs.sstd.transmission.client.entity.BatchTask;
import com.chinacscs.sstd.transmission.client.util.DatetimeFormats;

/**
 * @author: liusong
 * @date: 2019年2月14日
 * @email: 359852326@qq.com
 * @version:
 * @describe: //TODO
 */
public class BatchTaskDaoTest extends BaseTest {

	@Autowired
	BatchTaskDao batchTaskDao;

	@Test
	public void testCurd() {
		BatchTask batchTask = new BatchTask();
		batchTask.setBatchCode(20190225010000000l);
		batchTask.setSeq(1);
		batchTask.setStatus(BatchTaskStatus.NEW);
		batchTask.setFileName("name");
		batchTask.setFilePath("path");
		batchTask.setTableName("tableName");
		batchTask.setDataProtocol(DataProtocol.JSON);
		batchTask.setOperation(FileOperation.UPSERT);
		batchTask.setLockOffset(0);
		batchTask.setLockLength(1);
		batchTask.setTimestamp(20190225010000000l);
		String timestampStr=DateFormatUtils.format(new Date(), DatetimeFormats.yyyyMMddhhmmssSSS);
		batchTask.setTimestamp(Long.valueOf(timestampStr));
		int result = batchTaskDao.add(batchTask);
		batchTask.setId(null);
		result = batchTaskDao.add(batchTask);
		checkOk(result);

		batchTask = batchTaskDao.get(batchTask.getId());
		assertNotNull(batchTask);

		batchTask = batchTaskDao.getByFileName(batchTask.getFileName());
		assertNotNull(batchTask);

		result = batchTaskDao.delete(batchTask.getId());
		checkOk(result);
	}
}
