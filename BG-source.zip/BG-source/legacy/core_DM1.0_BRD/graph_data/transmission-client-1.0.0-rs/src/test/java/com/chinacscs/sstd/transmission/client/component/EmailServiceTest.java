package com.chinacscs.sstd.transmission.client.component;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.chinacscs.sstd.transmission.client.BaseTest;

/**
 * @author:  liusong
 * @date:    2019年2月22日
 * @email:   359852326@qq.com
 * @version: 
 * @describe: //TODO
 */
public class EmailServiceTest extends BaseTest{

	@Autowired
	EmailService emailService;
	
	@Test
	public void testSendQuietly() {
		String sendTo="liusong@chinacscs.com";
		String subject="测试邮件";
		String content="测试邮件"; 
		emailService.sendSimpleMail(sendTo, subject, content);
	}
}
