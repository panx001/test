package com.chinacscs.sstd.transmission.client.dao;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.chinacscs.sstd.transmission.client.BaseTest;
import com.chinacscs.sstd.transmission.client.dao.JobConfigDao;
import com.chinacscs.sstd.transmission.client.entity.JobConfig;

/**
 * @author: liusong
 * @date: 2019年2月14日
 * @email: 359852326@qq.com
 * @version:
 * @describe: //TODO
 */
public class JobConfigDaoTest extends BaseTest {

	@Autowired
	JobConfigDao jobConfigDao;

	@Test
	public void testCurd() {
		JobConfig job = new JobConfig();
		job.setName("test");
		job.setCronScript("0 0 1 * * ?");
		job.setClassName("com.chinacscs.sstd.dataimport.job.impl.MetaFileJob");
		int result = jobConfigDao.add(job);
		checkOk(result);
		JobConfig getJob = jobConfigDao.get(job.getId());
		assertNotNull(getJob);
		result = jobConfigDao.delete(getJob.getId());
		checkOk(result);
	}
}
