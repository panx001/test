package com.chinacscs.sstd.transmission.client.dao;

import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.chinacscs.sstd.transmission.client.BaseTest;
import com.chinacscs.sstd.transmission.client.constant.BatchStatus;
import com.chinacscs.sstd.transmission.client.dao.BatchDao;
import com.chinacscs.sstd.transmission.client.entity.Batch;
import com.chinacscs.sstd.transmission.client.util.DatetimeFormats;

/**
 * @author: liusong
 * @date: 2019年2月14日
 * @email: 359852326@qq.com
 * @version:
 * @describe: //TODO
 */
public class BatchDaoTest extends BaseTest {

	@Autowired
	BatchDao batchDao;

	@Test
	public void testCurd() {
		Batch batch = new Batch();
		batch.setFileName("name");
		batch.setFilePath("path");
		batch.setStatus(BatchStatus.NEW);
		String timestampStr=DateFormatUtils.format(new Date(), DatetimeFormats.yyyyMMddhhmmssSSS);
		batch.setTimestamp(Long.valueOf(timestampStr));
		int result = batchDao.add(batch);
		batch.setId(null);
		result = batchDao.add(batch);
		checkOk(result);

		batch = batchDao.get(batch.getId());
		assertNotNull(batch);

		batch = batchDao.getByFileName(batch.getFileName());
		assertNotNull(batch);

		result = batchDao.delete(batch.getId());
		checkOk(result);
	}
}
