package com.chinacscs.sstd.transmission.client.component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.chinacscs.platform.commons.util.JsonUtils;

/**
 * @author: liusong
 * @date: 2019年2月26日
 * @email: 359852326@qq.com
 * @version:
 * @describe: //TODO
 */
public class EsIndexSettingTools {

	static RestTemplate restTemplate = new RestTemplate();

	static String esUrl = "http://10.100.44.72:9200";

	public static void main(String[] args) {
		adjustReplicas(0);
	}

	public static void adjustReplicas(int replicas) {
		List<String> indexNames = loadIndexNames();
		MultiValueMap<String, String> headers = new HttpHeaders();
		headers.put("Content-Type", Arrays.asList("application/json"));
		for (String indexName : indexNames) {
			String url = esUrl + "/" + indexName + "/_settings";
			Map<String, Object> request = new HashMap<String, Object>();
			request.put("number_of_replicas", replicas);
			HttpEntity<String> httpEntity = new HttpEntity<>(JsonUtils.toJsonString(request),
					headers);
			restTemplate.put(url, httpEntity);
		}
	}

	public static List<String> loadIndexNames() {
		String url = esUrl + "/_cat/indices?v&h=i";
		String linesStr = restTemplate.getForObject(url, String.class);
		String[] lines = StringUtils.split(linesStr, "\n");
		List<String> indexNames = null;
		if (lines.length > 1) {
			indexNames = new ArrayList<>(lines.length - 1);
			for (int i = 1; i < lines.length; i++) {
				indexNames.add(lines[i]);
			}
		} else {
			indexNames = Collections.emptyList();
		}
		return indexNames;
	}
}
