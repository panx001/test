package com.chinacscs.sstd.transmission.client;

import org.junit.Test;

/**
*@author:MG01867
*@date:2018年6月15日
*@E-mail:359852326@qq.com
*@version:
*@describe //TODO
*/
public class StartUpTest extends BaseTest {
	
	@Test
	public synchronized void testMain() throws InterruptedException {
		this.wait();
	}
}