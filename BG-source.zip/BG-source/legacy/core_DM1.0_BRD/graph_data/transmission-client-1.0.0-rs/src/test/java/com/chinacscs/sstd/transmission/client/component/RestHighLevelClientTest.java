//package com.chinacscs.sstd.transmission.client.component;
//
//import java.io.IOException;
//import java.util.HashMap;
//import java.util.Map;
//
//import org.apache.commons.io.FileUtils;
//import org.apache.commons.io.LineIterator;
//import org.apache.commons.lang3.math.NumberUtils;
//import org.elasticsearch.action.DocWriteResponse.Result;
//import org.elasticsearch.action.delete.DeleteRequest;
//import org.elasticsearch.action.delete.DeleteResponse;
//import org.elasticsearch.action.search.SearchRequest;
//import org.elasticsearch.client.RequestOptions;
//import org.elasticsearch.client.RestHighLevelClient;
//import org.elasticsearch.script.ScriptType;
//import org.elasticsearch.script.mustache.SearchTemplateRequest;
//import org.elasticsearch.script.mustache.SearchTemplateResponse;
//import org.elasticsearch.search.SearchHit;
//import org.elasticsearch.search.SearchHits;
//import org.junit.Test;
//import org.springframework.util.ResourceUtils;
//
//import com.chinacscs.platform.commons.util.JsonUtils;
//
///**
// * @author: liusong
// * @date: 2019年2月19日
// * @email: 359852326@qq.com
// * @version:
// * @describe: //TODO
// */
//public class RestHighLevelClientTest {
//
//	private RestHighLevelClient restHighLevelClient;
//
//	@Test
//	public void test1() throws IOException {
//		String searchTemplate = FileUtils
//				.readFileToString(ResourceUtils.getFile("classpath:company_search.json"), "utf-8");
//		LineIterator lineIterator = FileUtils.lineIterator(
//				ResourceUtils.getFile("classpath:bond_cashhist.json.upsert.20190215120000000"),
//				"utf-8");
//		lineIterator.forEachRemaining(dataJson -> {
//			Map<String, Object> data = JsonUtils.jsonToMap(dataJson);
//			String companyId = (String) data.get("company_id");
//			Map<String, Object> scriptParams = new HashMap<>();
//			scriptParams.put("company_id", companyId);
//			SearchRequest searchRequest = new SearchRequest("bond_cashhist");
//			SearchTemplateRequest request = new SearchTemplateRequest(searchRequest);
//			request.setScriptType(ScriptType.INLINE);
//			request.setScript(searchTemplate);
//			request.setScriptParams(scriptParams);
//			SearchTemplateResponse response;
//			try {
//				response = restHighLevelClient.searchTemplate(request, RequestOptions.DEFAULT);
//				SearchHits searchHits = response.getResponse().getHits();
//				if (searchHits.totalHits == 1) {
//					return;
//				}
//				for (SearchHit searchHit : searchHits) {
//					String id = searchHit.getId();
//					if (!NumberUtils.isDigits(id)) {
//						DeleteRequest deleteRequest = new DeleteRequest("bond_cashhist", "doc", id);
//						DeleteResponse deleteResponse = null;
//						try {
//							deleteResponse = restHighLevelClient.delete(deleteRequest,
//									RequestOptions.DEFAULT);
//						} catch (IOException exception) {
//							throw new RuntimeException(exception);
//						}
//						if (Result.DELETED != deleteResponse.getResult()
//								&& Result.NOT_FOUND != deleteResponse.getResult()) {
//							throw new RuntimeException(String.format(
//									"Failed to delete data[%s] from the type[%s] of index[%s]", id,
//									"doc", "bond_cashhist"));
//						}
//						System.out.println("删除脏数据:" + id);
//					}
//				}
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		});
//	}
//}
