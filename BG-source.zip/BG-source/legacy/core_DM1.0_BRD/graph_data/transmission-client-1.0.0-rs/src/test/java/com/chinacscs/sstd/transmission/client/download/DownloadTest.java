package com.chinacscs.sstd.transmission.client.download;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.chinacscs.sstd.transmission.client.BaseTest;
import com.chinacscs.sstd.transmission.client.download.DownloadConfig;
import com.chinacscs.sstd.transmission.client.download.DownloadService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DownloadTest extends BaseTest {

	@Autowired
	private DownloadConfig syncConfig;
	@Autowired
	private DownloadService syncService;

	@Test
	public void testSyncConfig() {
		log.info("sftp配置信息：{}", syncConfig);
	}

	@Test
	public void testDownloadGs() {
		syncService.downloadGsFile();
	}

	@Test
	public void testDownloadGraph() {
		syncService.downloadGraphFile();
	}
}
