# 增量更新程序部署
1.0.0版本是目前（2019年4月9日）实际部署的版本。


## 程序压缩包获取
1. 进入到项目根目录，执行打包命令:
install -Dmaven.test.skip=true -Puat
或者
install -Dmaven.test.skip=true -Psit

2. 到该项目根目录/target下拷贝transmission-client.zip到服务器

## 程序安装启动
1. 将transmission-client.zip拷贝到安装目录
2. 执行unzip transmission-client.zip解压缩命令
3. 进入到 安装目录/ transmission-client 目录下
4. 创建 安装目录/ transmission-client/meta目录，(存放程序处理元信息)
5. 创建 安装目录/ transmission-client/workspace目录,(存放远程下载文件)
6. 修改 安装目录/ transmission-client/config/application.properties文件中需要修改的对应配置项
7. 修改 安装目录/ transmission-client/config/logback-custom.xml日志配置
8. 确认和调整 安装目录/ transmission-client/bin/service.sh脚本jvm 相关配置项
9.
   如果更新程序与图谱运行服务器没有在一个服务器上：
            通过mount让图谱服务器的neo4j_csv文件夹与本地的neo4j_csv文件夹保持一致。换言之，${app.graphload.neo4jServerCsvDir} 要与${app.download.localGraphDir}的内容一致。
            mount文件夹不要删除，可能犯的错误是部署新的程序时将neo4j_csv文件夹删了又新建。
   如果更新程序与图谱运行服务器在一个服务器上：
            注意application.properties的本地neo4j_csv与图谱服务器neo4j_csv路径一致
10. 在 安装目录/ transmission-client 目录下，执行./bin/service.sh start 启动系统 (可能需要sudo su -)
11. 验证 同步作业是否正常运行:
tail -f 查看log是否正常。

## 程序停止

1. 执行./bin/service.sh stop
2. 如果停不下来可以 netstat -tunlp | grep 8080 找到占用的PID然后kill

## 账号密码以及服务器信息

标准产品相关：
**10.100.45.42服务器** 的图谱账号是neo4j  密码是neo4j 图谱部署在/app/neo4japp/neo4j-enterprise-3.5.1 更新程序部署在/app/transmission-client 管理员权限 appadmin AppNsr@2018#
**10.100.45.43服务器** 的图谱账号是neo4j  密码是temp 图谱部署在/app/neo4j/neo4j-enterprise-3.5.1 更新程序部署在/app/transmission-client 管理员权限 appadmin AppNsr@2018#

证监会项目：
**10.100.44.77** 更新调度程序。程序安装目录/app/transmission-client/ （/app/test_by_mohaoran/transmission-client）appadmin CscsApp@2019#1
**10.100.45.51** 图谱neo4j服务器/opt/neo4j52/neo4j-community-3.5.2  管理员权限 appadmin CscsApp@2019#1

#sftp服务器地址
app.download.sftpHost=10.100.47.34
#sftp端口号
app.download.sftpPort=10010
#sftp账号
app.download.sftpUser=csrc
#sftp密码
app.download.sftpPassword=Csrc#Cscs@2019
#sftp存放工商数据的文件夹
app.download.sftpGsDir=/csrc/hbase_json
#sftp存放图谱数据的文件夹
app.download.sftpGraphDir=/cscs/neo4j_csv

sftp -P 10010 csrc@10.100.47.34