import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.io.*;
import java.util.Arrays;
import java.util.List;

public class CsvFormat {
    //neo4j执行
    //neo4j-admin import --mode=csv --database graph2.db --nodes /data/output/company.csv --nodes /data/output/person.csv --relationships /data/output/relation.csv
    //neo4j-admin import --mode=csv --database graph8.db --nodes /data/output/company.csv --nodes /data/output/security.csv  --nodes /data/output/person.csv --relationships /data/output/personRelationCompany.csv --relationships /data/output/companyRelationCompany.csv  --relationships /data/output/companyRelationSecurity.csv --relationships /data/output/securityRelationCompany.csv
    //--ignore-duplicate-nodes=true
    //--ignore-missing-nodes
    private static String[] COMPANY_COLUMN = {"COMPANY_NM", "ORGNUM", "ORG_FORM", "REG_CAPITAL", "REG_CD", "REG_DT", "STATUS", "SECINNER_ID", "SECURITY_CD", "SECURITY_NM", "SECURITY_TYPE"};
    private static String[] RELATION_COLUMN = {"RELATION_TYPE", "SHA_RATIO", "NUM", "POSITION"};

    private static String inputNodeFile = "";
    private static String inputRelFile = "";
    private static String outputFile = "";
    private static String outputCompnyFile = "";
    private static String outputSecurityFile = "";
    private static String outputPersonFile = "";
    private static String outputPersonRelationCompanyFile = "";
    private static String outputPersonRelationSecurityFile = "";
    private static String outputCompanyRelationSecurityFile = "";
    private static String outputSecurityRelationCompanyFile = "";
    private static String outputCompanyRelationCompanyFile = "";

    private static int sz = 20 * 1024 * 1024;
    private static int writeSize = 20000;

    //参数1：文件路径
    //参数2：是否执行检查(true:执行)
    //参数3：读取内存(默认20M)
    //参数4：生成文件写入条数（默认20000）
    public static void main(String arg[]) throws Exception {
        if (arg.length == 0) {
            System.out.println("path null!!!");
            return;
        }
        if (arg.length == 3) sz = Integer.valueOf(arg[2]) * 1024 * 1024;
        if (arg.length == 4) writeSize = Integer.valueOf(arg[3]);

        String path = arg[0].toString();
        inputNodeFile = path + "/node.csv";
        inputRelFile = path + "/relation.csv";
        outputFile = path + "/output";
        outputCompnyFile = path + "/output/company.csv";
        outputSecurityFile = path + "/output/security.csv";
        outputPersonFile = path + "/output/person.csv";
        outputPersonRelationCompanyFile = path + "/output/personRelationCompany.csv";
        outputPersonRelationSecurityFile = path + "/output/personRelationSecurity.csv";
        outputCompanyRelationCompanyFile = path + "/output/companyRelationCompany.csv";
        outputCompanyRelationSecurityFile = path + "/output/companyRelationSecurity.csv";
        outputSecurityRelationCompanyFile = path + "/output/securityRelationCompany.csv";

        if (arg.length > 2) {
            if (arg[1].toString().equalsIgnoreCase("true")) {
                checkFile();
                System.out.println("relation file check end!!!");
                return;
            }
        }

        File relationFile = new File(inputRelFile);
        File nodeFile = new File(inputNodeFile);
        File outFile = new File(outputFile);
        if (outFile.exists()) {
            for (File child : outFile.listFiles()) child.delete();
            outFile.delete();
        }
        outFile.mkdir();

        if (nodeFile.exists()) {
            NodeThread node = new NodeThread();
            node.start();
//            readNodeFile();
        } else {
            System.out.println("node is not exist!!!");
        }

        if (relationFile.exists()) {
            relationThread relation = new relationThread();
            relation.start();
//            readRelationFile();
        } else {
            System.out.println("relation is not exist!!!");
        }
    }

    private static void checkFile() {
        try (
                BufferedInputStream reader = new BufferedInputStream(new FileInputStream(inputRelFile));
                BufferedReader br = new BufferedReader((new InputStreamReader(reader, "utf-8")), sz);
        ) {
            String line;
            br.readLine();//读取文件标题
            int i = 1;
            while ((line = br.readLine()) != null) {
                i++;
                List item = Arrays.asList(line.replaceAll(",\"\"", ",\"null\"").replaceAll("|", "").replaceAll("\",\"", "\"|\"").replaceAll("\"", "").split("\\|"));
                if (item.size() != 9) {
                    System.out.println("relationLine:" + i);
                    continue;
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.toString());
        }
    }

    private static class NodeThread extends Thread {
        @Override
        public void run() {
            readNodeFile();
            System.out.println("node end!!!");
        }
    }

    private static class relationThread extends Thread {
        @Override
        public void run() {
            readRelationFile();
            System.out.println("relation end!!!");
        }
    }

    private static void readNodeFile() {
        JSONArray companyList = new JSONArray();
        JSONArray securityList = new JSONArray();
        JSONArray personList = new JSONArray();
        try (
                BufferedInputStream reader = new BufferedInputStream(new FileInputStream(inputNodeFile));
                BufferedReader br = new BufferedReader((new InputStreamReader(reader, "utf-8")), sz);
        ) {
            String line;
            br.readLine();//读取文件头行
            int i = 1;
            while ((line = br.readLine()) != null) {
                try {
                    i++;
                    line = line.replaceAll("\\\\n", "").replaceAll("\"\"", "\"").replace("\"{", "{").replace("}\"", "}");
                    JSONObject node = JSONObject.parseObject(line);
                    if (node.get("labels").toString().contains("PERSON")) {
                        personList.add(setPerson(node));
                    } else if (node.get("labels").toString().contains("COMPANY")) {
                        companyList.add(setCompany(node));
                    } else {
                        securityList.add(setSecurity(node));
                    }
                } catch (Exception ex) {
                    System.out.println("nodeLine:" + i);
                    continue;
                }

                if (companyList.size() > writeSize) {
                    WriteNodeThread t1 = new WriteNodeThread(companyList, 1);
                    t1.run();
                    companyList.clear();
                }

                if (securityList.size() > writeSize) {
                    WriteNodeThread t1 = new WriteNodeThread(securityList, 2);
                    t1.run();
                    securityList.clear();
                }

                if (personList.size() > writeSize) {
                    WriteNodeThread t1 = new WriteNodeThread(personList, 3);
                    t1.run();
                    personList.clear();
                }
            }
            //企业节点文件生成
            if (companyList.size() > 0) {
                WriteNodeThread t1 = new WriteNodeThread(companyList, 1);
                t1.run();
            }

            //产品节点文件生成
            if (securityList.size() > 0) {
                WriteNodeThread t1 = new WriteNodeThread(securityList, 2);
                t1.run();
            }

            //自然人节点生成
            if (personList.size() > 0) {
                WriteNodeThread t1 = new WriteNodeThread(personList, 3);
                t1.run();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void readRelationFile() {

        JSONArray personRelationCompanyList = new JSONArray();
        JSONArray personRelationSecurityList = new JSONArray();
        JSONArray companyRelationCompanyList = new JSONArray();
        JSONArray companyRelationSecurityList = new JSONArray();
        JSONArray securityRelationCompanyList = new JSONArray();
        try (
                BufferedInputStream reader = new BufferedInputStream(new FileInputStream(inputRelFile));
                BufferedReader br = new BufferedReader((new InputStreamReader(reader, "utf-8")), sz);
        ) {
            String line;
            br.readLine();//读取文件头行
            int i = 1;
            while ((line = br.readLine()) != null) {
                try {
                    i++;
                    List item = Arrays.asList(line.replaceAll(",\"\"", ",\"null\"").replaceAll("|", "").replaceAll("\",\"", "\"|\"").replaceAll("\"", "").split("\\|"));
                    if (item.size() != 9) {
                        System.out.println("relationLine:" + i);
                        continue;
                    }
                    if (item.get(0).toString().equals("1") && item.get(2).toString().equals("2")) {
                        personRelationCompanyList.add(setRelation(item));
                    } else if (item.get(0).toString().equals("1") && item.get(2).toString().equals("3")) {
                        personRelationSecurityList.add(setRelation(item));
                    } else if (item.get(0).toString().equals("2") && item.get(2).toString().equals("2")) {
                        companyRelationCompanyList.add(setRelation(item));
                    } else if (item.get(0).toString().equals("2") && item.get(2).toString().equals("3")) {
                        companyRelationSecurityList.add(setRelation(item));
                    } else if (item.get(0).toString().equals("3") && item.get(2).toString().equals("2")) {
                        securityRelationCompanyList.add(setRelation(item));
                    } else{
                        System.out.println(i);
                    }
                } catch (Exception ex) {
                    System.out.println("relationLine:" + i);
                    continue;
                }

                if (personRelationCompanyList.size() > writeSize) {
                    WriteRelationThread t1 = new WriteRelationThread(personRelationCompanyList, 1);
                    t1.run();
                    personRelationCompanyList.clear();
                }
                if (personRelationSecurityList.size() > writeSize) {
                    WriteRelationThread t1 = new WriteRelationThread(personRelationSecurityList, 2);
                    t1.run();
                    personRelationSecurityList.clear();
                }
                if (companyRelationCompanyList.size() > writeSize) {
                    WriteRelationThread t1 = new WriteRelationThread(companyRelationCompanyList, 3);
                    t1.run();
                    companyRelationCompanyList.clear();
                }
                if (companyRelationSecurityList.size() > writeSize) {
                    WriteRelationThread t1 = new WriteRelationThread(companyRelationSecurityList, 4);
                    t1.run();
                    companyRelationSecurityList.clear();
                }
                if (securityRelationCompanyList.size() > writeSize) {
                    WriteRelationThread t1 = new WriteRelationThread(securityRelationCompanyList, 5);
                    t1.run();
                    securityRelationCompanyList.clear();
                }
            }
            //关联关系生成
            if (personRelationCompanyList.size() > 0) {
                WriteRelationThread t1 = new WriteRelationThread(personRelationCompanyList, 1);
                t1.run();
                personRelationCompanyList.clear();
            }
            if (personRelationSecurityList.size() > 0) {
                WriteRelationThread t1 = new WriteRelationThread(personRelationSecurityList, 2);
                t1.run();
                personRelationSecurityList.clear();
            }
            if (companyRelationCompanyList.size() > 0) {
                WriteRelationThread t1 = new WriteRelationThread(companyRelationCompanyList, 3);
                t1.run();
                companyRelationCompanyList.clear();
            }
            if (companyRelationSecurityList.size() > 0) {
                WriteRelationThread t1 = new WriteRelationThread(companyRelationSecurityList, 4);
                t1.run();
                companyRelationSecurityList.clear();
            }
            if (securityRelationCompanyList.size() > 0) {
                WriteRelationThread t1 = new WriteRelationThread(securityRelationCompanyList, 5);
                t1.run();
                securityRelationCompanyList.clear();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class WriteNodeThread implements Runnable {
        JSONArray list;
        int type;

        public WriteNodeThread(JSONArray inputList, int type) {
            this.list = inputList;
            this.type = type;
        }

        @Override
        public void run() {
            if (type == 1) {
                writeCompanyNodeFile(list);
            } else if (type == 2) {
                writeSecurityNodeFile(list);
            } else if (type == 3) {
                writePersonNodeFile(list);
            }
        }
    }

    private static class WriteRelationThread implements Runnable {
        JSONArray list;
        int type;

        public WriteRelationThread(JSONArray inputList, int type) {
            this.list = inputList;
            this.type = type;
        }

        @Override
        public void run() {
            writeRelationFile(list, type);
        }
    }

    private static JSONObject setCompany(JSONObject item) {
        JSONObject content = new JSONObject();
        content.put("lables", item.get("labels").toString().replaceAll(",", ";").replace("[", "").replace("]", "").replaceAll("\"", ""));
        JSONObject properties = item.getJSONObject("properties");
        content.put("COMPANY_ID", properties.get("COMPANY_ID") == null ? repalceValue(properties.get("SECINNER_ID").toString()) : repalceValue(properties.get("COMPANY_ID").toString()));
        content.put("COMPANY_NM", properties.get("COMPANY_NM") == null ? null : repalceValue(properties.get("COMPANY_NM").toString()));
        if (properties.containsKey("COMPANY_TYPE_LIST")) {
            content.put("COMPANY_TYPE_LIST", properties.get("COMPANY_TYPE_LIST").toString().replaceAll(",", ";").replace("[", "").replace("]", "").replaceAll("\"", ""));
        }

        content.put("ORGNUM", properties.get("ORGNUM"));
        content.put("ORG_FORM", properties.get("ORG_FORM"));
        content.put("IS_REVOKE", properties.get("IS_REVOKE"));
        content.put("STATUS", properties.get("STATUS") == null ? null : repalceValue(properties.get("STATUS").toString()));
        content.put("IS_LISTED", properties.get("IS_LISTED"));

        content.put("REG_CAPITAL", properties.get("REG_CAPITAL"));
        content.put("REG_CD", properties.get("REG_CD"));
        content.put("REG_DT", properties.get("REG_DT"));

//        content.put("SOURCE", properties.get("SOURCE"));
//        content.put("RISK_LIST", properties.get("RISK_LIST").toString().replaceAll(",",";").replace("[","").replace("]","").replaceAll("\"\"","\""));

        //产品
        content.put("SECINNER_ID", properties.get("SECINNER_ID") == null ? null : repalceValue(properties.get("SECINNER_ID").toString()));
        content.put("SECURITY_CD", properties.get("SECURITY_CD") == null ? null : repalceValue(properties.get("SECURITY_CD").toString()));
        content.put("SECURITY_NM", properties.get("SECURITY_NM") == null ? null : repalceValue(properties.get("SECURITY_NM").toString()));
        content.put("SECURITY_TYPE", properties.get("SECURITY_TYPE"));
        return content;
    }

    private static JSONObject setSecurity(JSONObject item) {
        JSONObject content = new JSONObject();
        content.put("lables", item.get("labels").toString().replaceAll(",", ";").replace("[", "").replace("]", "").replaceAll("\"", ""));
        JSONObject properties = item.getJSONObject("properties");

        //产品
        content.put("SECINNER_ID", properties.get("SECINNER_ID") == null ? null : repalceValue(properties.get("SECINNER_ID").toString()));
        content.put("SECURITY_CD", properties.get("SECURITY_CD") == null ? null : repalceValue(properties.get("SECURITY_CD").toString()));
        content.put("SECURITY_NM", properties.get("SECURITY_NM") == null ? null : repalceValue(properties.get("SECURITY_NM").toString()));
        content.put("SECURITY_TYPE", properties.get("SECURITY_TYPE"));
        return content;
    }

    private static JSONObject setPerson(JSONObject item) {
        JSONObject content = new JSONObject();
        content.put("lables", item.get("labels").toString().replaceAll(",", ";").replace("[", "").replace("]", "").replaceAll("\"", ""));
        JSONObject properties = item.getJSONObject("properties");
        content.put("PERSON_ID", properties.get("PERSON_ID") == null ? null : repalceValue(properties.get("PERSON_ID").toString()));
        content.put("PERSON_NM", properties.get("PERSON_NM") == null ? null : repalceValue(properties.get("PERSON_NM").toString()));
        return content;
    }

    private static JSONObject setRelation(List item) throws Exception {
        JSONObject content = new JSONObject();
        content.put("START_ID", repalceValue(item.get(1).toString()));
        content.put("END_ID", repalceValue(item.get(3).toString()));
        content.put("TYPE", "null".equals(item.get(4)) ? null : repalceValue(item.get(4).toString()));
        //管理
        content.put("POSITION", "null".equals(item.get(5)) ? null : repalceValue(item.get(5).toString()));

        //投资
        content.put("RELATION_TYPE", "null".equals(item.get(6)) ? null : repalceValue(item.get(6).toString()));
        content.put("SHA_RATIO", "null".equals(item.get(7)) ? null : repalceValue(item.get(7).toString()));
        content.put("NUM", "null".equals(item.get(8)) ? null : repalceValue(item.get(8).toString()));
        return content;
    }

    private static void writeCompanyNodeFile(JSONArray companyList) {
        try {
            File file = new File(outputCompnyFile);
            boolean exists = false;
            if (!file.exists()) {
                file.createNewFile();
            } else {
                exists = true;
            }
            try (FileOutputStream fos = new FileOutputStream(outputCompnyFile, true);
                 OutputStreamWriter out = new OutputStreamWriter(fos, "UTF-8");
            ) {
                if (!exists)
                    out.write("COMPANY_ID:ID(COMPANY_ID),:LABEL,COMPANY_NM,ORGNUM,ORG_FORM,REG_CAPITAL,REG_CD,REG_DT,STATUS,SECINNER_ID,SECURITY_CD,SECURITY_NM,SECURITY_TYPE,COMPANY_TYPE_LIST:string[]\r\n");
                for (Object tmp : companyList) {
                    JSONObject content = JSONObject.parseObject(tmp.toString());
                    StringBuilder sb = new StringBuilder();
                    sb.append("\"").append(content.get("COMPANY_ID")).append("\"").append(",");
                    sb.append(content.get("lables"));
                    sb.append(setLine(content, COMPANY_COLUMN)).append(",");
                    if (content.containsKey("COMPANY_TYPE_LIST")) {
                        sb.append(content.get("COMPANY_TYPE_LIST").toString().replace("\\[", "").replace("\\]", "").replaceAll(",", ";").replaceAll("\"", ""));
                    }
                    sb.append("\r\n");
                    out.write(sb.toString());
                    out.flush(); // 把缓存区内容压入文件
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void writeSecurityNodeFile(JSONArray companyList) {
        try {
            File file = new File(outputSecurityFile);
            boolean exists = false;
            if (!file.exists()) {
                file.createNewFile();
            } else {
                exists = true;
            }
            try (FileOutputStream fos = new FileOutputStream(outputSecurityFile, true);
                 OutputStreamWriter out = new OutputStreamWriter(fos, "UTF-8");
            ) {
                if (!exists) out.write("SECINNER_ID:ID(SECINNER_ID),:LABEL,SECURITY_CD,SECURITY_NM,SECURITY_TYPE\r\n");
                for (Object tmp : companyList) {
                    JSONObject content = JSONObject.parseObject(tmp.toString());
                    StringBuilder sb = new StringBuilder();
                    sb.append("\"").append(content.get("SECINNER_ID")).append("\"").append(",");
                    sb.append(content.get("lables")).append(",");
                    sb.append(content.get("SECURITY_CD")).append(",");
                    sb.append(content.get("SECURITY_NM")).append(",");
                    sb.append(content.get("SECURITY_TYPE")).append("\r\n");
                    out.write(sb.toString());
                    out.flush(); // 把缓存区内容压入文件
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void writePersonNodeFile(JSONArray personList) {
        try {
            File file = new File(outputPersonFile);
            boolean exists = false;
            if (!file.exists()) {
                file.createNewFile();
            } else {
                exists = true;
            }
            try (FileOutputStream fos = new FileOutputStream(outputPersonFile, exists);
                 OutputStreamWriter out = new OutputStreamWriter(fos, "UTF-8");
            ) {
                if (!exists) out.write("PERSON_ID:ID(PERSON_ID),:LABEL,PERSON_NM\r\n");
                for (Object tmp : personList) {
                    JSONObject content = JSONObject.parseObject(tmp.toString());
                    StringBuilder sb = new StringBuilder();
                    sb.append("\"").append(content.get("PERSON_ID")).append("\"").append(",");
                    sb.append(content.get("lables"));
                    if (content.containsKey("PERSON_NM")) {
                        sb.append(",").append("\"").append(content.get("PERSON_NM")).append("\"\r\n");
                    } else {
                        sb.append(",\r\n");
                    }
                    out.write(sb.toString());
                    out.flush(); // 把缓存区内容压入文件
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void writeRelationFile(JSONArray relationList, int type) {
        try {
            String path = "";
            if (1 == type) {
                path = outputPersonRelationCompanyFile;
            } else if (2 == type) {
                path = outputPersonRelationSecurityFile;
            } else if (3 == type) {
                path = outputCompanyRelationCompanyFile;
            } else if (4 == type) {
                path = outputCompanyRelationSecurityFile;
            } else if (5 == type) {
                path = outputSecurityRelationCompanyFile;
            }

            File file = new File(path);
            boolean exists = false;
            if (!file.exists()) {
                file.createNewFile(); // 创建新文件,有同名的文件的话直接覆盖
            } else {
                exists = true;
            }
            try (FileOutputStream fos = new FileOutputStream(path, exists);
                 OutputStreamWriter out = new OutputStreamWriter(fos, "UTF-8");
            ) {
                if (!exists) {
                    if (1 == type) {
                        out.write(":START_ID(PERSON_ID),:TYPE,:END_ID(COMPANY_ID),RELATION_TYPE,SHA_RATIO,NUM,POSITION\r\n");
                    } else if (2 == type) {
                        out.write(":START_ID(PERSON_ID),:TYPE,:END_ID(SECINNER_ID),RELATION_TYPE,SHA_RATIO,NUM,POSITION\r\n");
                    } else if (3 == type) {
                        out.write(":START_ID(COMPANY_ID),:TYPE,:END_ID(COMPANY_ID),RELATION_TYPE,SHA_RATIO,NUM,POSITION\r\n");
                    } else if (4 == type) {
                        out.write(":START_ID(COMPANY_ID),:TYPE,:END_ID(SECINNER_ID),RELATION_TYPE,SHA_RATIO,NUM,POSITION\r\n");
                    } else if (5 == type) {
                        out.write(":START_ID(SECINNER_ID),:TYPE,:END_ID(COMPANY_ID),RELATION_TYPE,SHA_RATIO,NUM,POSITION\r\n");
                    }
                }

                for (Object tmp : relationList) {
                    JSONObject content = JSONObject.parseObject(tmp.toString());
                    StringBuilder sb = new StringBuilder();
                    sb.append("\"").append(content.get("START_ID")).append("\"").append(",");
                    sb.append("\"").append(content.get("TYPE")).append("\",");
                    sb.append("\"").append(content.get("END_ID")).append("\"");
                    sb.append(setLine(content, RELATION_COLUMN)).append("\r\n");
                    out.write(sb.toString());
                    out.flush(); // 把缓存区内容压入文件
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String setLine(JSONObject content, String[] columList) {
        StringBuilder sb = new StringBuilder();
        for (String column : columList) {
            if (content.containsKey(column)) {
                sb.append(",").append("\"").append(content.get(column).toString().replaceAll(",", "")).append("\"");
            } else {
                sb.append(",");
            }
        }
        return sb.toString();
    }

    private static String repalceValue(String value) {
        return value.replaceAll(",", " ").replaceAll("\"", "");
    }
}