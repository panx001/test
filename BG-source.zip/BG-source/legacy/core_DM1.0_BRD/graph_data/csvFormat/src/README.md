#子图生成流程
##标记(core)

##1.打标签
USING PERIODIC COMMIT 2000
LOAD CSV FROM 'file:////company.csv' AS LINE
match (c:COMPANY{COMPANY_ID:LINE[0]})-[r:INVEST|WORK|ISSUE|TRUSTEE|MANAGER*..3]-(d) 
set c:core,d:core;

##2.生成标签文件导出
###2.1 输出节点文件
CALL apoc.export.csv.query("match (n:core) return n","/data/node.csv",{});

###2.2 输出关系文件
CALL apoc.export.csv.query("
match (c:core)-[r:INVEST|WORK|ISSUE|TRUSTEE|MANAGER]->(d:core) 
with r,startnode(r) as start,endnode(r) as end
with r,
case WHEN start.PERSON_ID is NOT null then 1 WHEN start.COMPANY_ID is NOT null then 2 ELSE 3 end as startLabel,
case WHEN end.PERSON_ID is NOT null then 1 WHEN end.COMPANY_ID is NOT null then 2 ELSE 3 end as endLabel,
case WHEN start.PERSON_ID is NOT null then start.PERSON_ID WHEN start.COMPANY_ID is NOT null then start.COMPANY_ID ELSE start.SECINNER_ID end as startId,
case WHEN end.PERSON_ID is NOT null then end.PERSON_ID WHEN end.COMPANY_ID is NOT null then end.COMPANY_ID ELSE end.SECINNER_ID end as endId
return startLabel,startId,endLabel,endId,type(r),r.POSITION,r.RELATION_TYPE,r.SHA_RATIO,r.NUM","/data/relation.csv",{});

##3.CSV文件格式转换
java -jar csvFormat.jar /data

##4.执行子图导入
./neo4j-admin import --mode=csv --database graph10.db --nodes /data/output/company.csv --nodes /data/output/security.csv  --nodes /data/output/person.csv --relationships /data/output/personRelationCompany.csv --relationships /data/output/companyRelationCompany.csv  --relationships /data/output/companyRelationSecurity.csv --relationships /data/output/securityRelationCompany.csv

###--ignore-duplicate-nodes=true(忽视重复节点)
###--ignore-missing-nodes