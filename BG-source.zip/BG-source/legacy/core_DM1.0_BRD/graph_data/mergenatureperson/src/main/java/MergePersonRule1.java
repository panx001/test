import org.neo4j.driver.v1.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import static org.neo4j.driver.v1.Values.parameters;

public class MergePersonRule1 {
    private final static Logger log = LoggerFactory.getLogger(MergePersonRule1.class);
    private static String eachUri = "bolt://10.100.45.35:7687";
    private static String neo4jUser = "neo4j";
    private static String neo4jPW = "neo4j";
    public static void main(String[] args){
        // 已知的自然人id
        String knownId = "35153573";
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Driver driver = GraphDatabase.driver(eachUri, AuthTokens.basic(neo4jUser, neo4jPW));
        mergeAction(br,driver,knownId);
        driver.close();
//        System.out.println(mergeSomePersonNodes);
    }
    private static void mergeAction(BufferedReader bufferedReader,Driver driver,String knownId){

        Session session = driver.session();
        StatementResult statementResult = session.run(findCandidatesIDFromKnownID,parameters("known_person_id", knownId));
        for(Record res:statementResult.list()){
            Value persondID = res.get("set");
            String otherId = persondID.asList().toString().replace("[","").replace("]",":");
            System.out.println(otherId);

            boolean doMerge = false;
            try{
                System.out.println("是否执行合并[Y/N]");
                doMerge = "Y".equalsIgnoreCase(bufferedReader.readLine());
            }catch (IOException e){
                log.info(e.getMessage());
            }

            if(doMerge){
                for( Object eachId:persondID.asList()){
                    StatementResult statementResult1 = session.run(mergeSomePersonNodes,parameters("knownPersonId",knownId,"otherCandidateID",otherId));
                }
            }else {
                System.out.println("没有执行合并");
            }
        }
        session.close();
    }

/*MATCH (knownP:PERSON{PERSON_ID:'35153573'})
WITH SPLIT("35153573, 311332闻掌华, 176587闻掌华, 10268968闻掌华, 192757闻掌华, 117544闻掌华, 180149闻掌华, 11057963闻掌华, 426319闻掌华",", ") as candidate,collect(knownP) as kp
MATCH (Plist:PERSON) where Plist.PERSON_ID in candidate
WITH kp+Plist as res
return res*/

/*MATCH (knownP:PERSON{PERSON_ID:'35153573'})
WITH SPLIT("35153573, 311332闻掌华, 176587闻掌华",", ") as candidate,collect(knownP) as kp
MATCH (Plist:PERSON) where Plist.PERSON_ID in candidate
WITH apoc.coll.toSet(kp+Plist) as res
CALL apoc.refactor.mergeNodes(res,{properties:"discard",mergeRels:true}) yield node
return node*/


    private static String query1 = "match p=(c:COMPANY{COMPANY_NM:'海航集团有限公司'})<-[:INVEST*1..3]-(d)\n" +
            "with nodes(p) as NODE,p\n" +
            "unwind NODE as NODES\n" +
            "with distinct NODES as NODES_NEW\n" +
            "match path_work=(NODES_NEW)<-[rel:WORK]-(f:PERSON)\n" +
            "return path_work,f\n";

    private static String findCandidatesIDFromKnownID = "match (b:PERSON{PERSON_ID:$known_person_id})\n" +
            "match path=(b)-[:INVEST|WORK]->(d:COMPANY)-[:INVEST*0..2]-(e:COMPANY)<-[:INVEST|WORK]-(f:PERSON{PERSON_NM:b.PERSON_NM})\n" +
            "with collect(b.PERSON_ID) as set1,collect(distinct f.PERSON_ID) as set2\n" +
            "with apoc.coll.toSet(set1+set2) as set\n" +
            "return set";

    private static String mergeSomePersonNodes = "MATCH (knownP:PERSON{PERSON_ID:$knownPersonId})\n" +
            "WITH SPLIT($otherCandidateID,\", \") as candidate,collect(knownP) as kp\n" +
            "MATCH (Plist:PERSON) where Plist.PERSON_ID in candidate\n" +
            "WITH apoc.coll.toSet(kp+Plist) as res\n" +
            "CALL apoc.refactor.mergeNodes(res,{properties:\"discard\",mergeRels:true}) yield node\n" +
            "return node";
}
/*MATCH (knownP:PERSON{PERSON_ID:'35153573'})
WITH SPLIT('35153573, 11057963闻掌华',", ") as candidate,collect(knownP) as kp
MATCH (Plist:PERSON) where Plist.PERSON_ID in candidate
WITH apoc.coll.toSet(kp+Plist) as res
CALL apoc.refactor.mergeNodes(res,{properties:"discard",mergeRels:true}) yield node
return node*/