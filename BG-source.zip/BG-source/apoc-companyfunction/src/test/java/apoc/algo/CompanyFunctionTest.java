/*
package apoc.algo;

import apoc.cscs.CompanyFunction;
import apoc.cscs.LoadFileFunction;
import apoc.cscs.XYGSCharCodeMapFunction;
import apoc.util.TestUtil;
import apoc.utils.XYGSCharCodeMap;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Node;
import org.neo4j.test.TestGraphDatabaseFactory;
import java.io.UnsupportedEncodingException;
import java.util.Properties;
import static apoc.cscs.CompanyFunction.sendGet;
import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class CompanyFunctionTest {
    private static GraphDatabaseService db;
    private static final String COMPANIES_QUERY = "CREATE (a:Company {name:'a'})\n" +
            "CREATE (b:COMPANY {name:'b'})\n" +
            "CREATE (c:COMPANY {name:'c'})\n" +
            "CREATE (d:COMPANY {name:'d'})\n" +
            "CREATE (e:COMPANY {name:'e'})\n" +
            "CREATE (f:COMPANY {name:'f'})\n" +
            "CREATE (g:COMPANY {name:'g'})\n" +
            "CREATE (h:COMPANY {name:'h'})\n" +
            "CREATE (i:COMPANY {name:'i'})\n" +
            "CREATE (j:COMPANY {name:'j'})\n" +
            "CREATE (k:COMPANY {name:'k'})\n" +

            "CREATE\n" +
            "  (b)-[:INVEST {SHA_RATIO:0.88}]->(c),\n" +
            "  (c)-[:INVEST {SHA_RATIO:0.81}]->(b),\n" +
            "  (d)-[:INVEST {SHA_RATIO:0.80}]->(a),\n" +
            "  (e)-[:INVEST {SHA_RATIO:0.82}]->(b),\n" +
            "  (e)-[:INVEST {SHA_RATIO:0.83}]->(d),\n" +
            "  (e)-[:INVEST {SHA_RATIO:0.80}]->(f),\n" +
            "  (f)-[:INVEST {SHA_RATIO:0.85}]->(b),\n" +
            "  (f)-[:INVEST {SHA_RATIO:0.80}]->(e),\n" +
            "  (g)-[:INVEST {SHA_RATIO:0.82}]->(b),\n" +
            "  (g)-[:INVEST {SHA_RATIO:0.80}]->(e),\n" +
            "  (h)-[:INVEST {SHA_RATIO:0.80}]->(b),\n" +
            "  (h)-[:INVEST {SHA_RATIO:0.80}]->(e),\n" +
            "  (i)-[:INVEST {SHA_RATIO:0.85}]->(b),\n" +
            "  (i)-[:INVEST {SHA_RATIO:0.80}]->(e),\n" +
            "  (j)-[:INVEST {SHA_RATIO:0.80}]->(e),\n" +
            "  (k)-[:INVEST {SHA_RATIO:0.80}]->(e)\n";


    @Before
    public void setUp() throws Exception {
        db = new TestGraphDatabaseFactory().newImpermanentDatabase();
        TestUtil.registerProcedure(db, CompanyFunction.class);
        TestUtil.registerProcedure(db, LoadFileFunction.class);
        TestUtil.registerProcedure(db, XYGSCharCodeMapFunction.class);
    }

    @After
    public void tearDownDb() {
        db.shutdown();
    }

    @Test//( expected = RuntimeException.class )
    public void getMaxShareHolderTest() {
        db.execute( COMPANIES_QUERY ).close();
        System.out.println(algoShareHolderQuery( "CALL apoc.cscs.getMaxShareHolder(nodes)" ) );
        assertExpectedResult( 50, algoShareHolderQuery( "CALL apoc.cscs.getMaxShareHolder(nodes)" ) );
    }

    @Test
    public void testurl(){
        String url = "http://10.100.48.32:20550/cdi:company_identifier/万科企业股份有限公司/data:company_id";
        String result = sendGet(url);
//        String companyid = "";
//        if (result != null) {
//            result = result.substring(1,result.length()-1);
//            companyid = result.split(":")[1].replace("\"","");
//        }
//        Map<String,String> mapresult = new HashedMap();

        System.out.println(result);
    }

    @Test
    public void getjsonfilelistTest() {
        db.execute( COMPANIES_QUERY ).close();
        System.out.println(algoShareHolderQuery( "CALL apoc.cscs.getjsonfilelist(nodes)" ) );
        assertExpectedResult( 50, algoShareHolderQuery( "CALL apoc.cscs.getjsonfilelist(nodes)" ) );
    }

    @Test
    public void gbk2utf8Test() throws UnsupportedEncodingException {
        Properties initProp = new Properties(System.getProperties());
        System.out.println("当前系统编码:" + initProp.getProperty("file.encoding"));
        System.out.println("当前系统语言:" + initProp.getProperty("user.language"));

        System.out.println(new String(XYGSCharCodeMap.codeMap.get("R").getBytes("GBK"),"utf-8"));
//        System.out.println(XYGSCharCodeMap.codeMap.get("R").getBytes("GBK").length);
//        System.out.println(XYGSCharCodeMap.codeMap.get("R").getBytes("GBK").length);
//        System.out.println(XYGSCharCodeMap.codeMap.get("R").getBytes("GBK").length);
//        System.out.println(XYGSCharCodeMap.codeMap.get("R").getBytes("GBK").length);
//        System.out.println(XYGSCharCodeMap.codeMap.get("R").getBytes("GBK").length);
//        System.out.println(XYGSCharCodeMap.codeMap.get("R").getBytes("ISO-8859-1").length);
//        System.out.println(XYGSCharCodeMap.codeMap.get("R").getBytes("ISO-8859-1").length);
//        System.out.println(XYGSCharCodeMap.codeMap.get("R").getBytes("utf-8").length);
//        System.out.println(XYGSCharCodeMap.codeMap.get("R").getBytes("utf-8").length);
//        System.out.println(new String(XYGSCharCodeMap.codeMap.get("R").getBytes("ISO-8859-1"),"ISO-8859-1"));
//        System.out.println(new String(XYGSCharCodeMap.codeMap.get("R").getBytes("GBK"),"GBK"));
//        System.out.println(new String(XYGSCharCodeMap.codeMap.get("R").getBytes("utf-8"),"utf-8"));
//        System.out.println(new String(XYGSCharCodeMap.codeMap.get("R").getBytes("GBK"),"utf-8"));
//        System.out.println(new String(new String(XYGSCharCodeMap.codeMap.get("R").getBytes("GBK"),"ISO-8859-1").getBytes("ISO-8859-1"),"UTF-8"));
//        System.out.println(new String(XYGSCharCodeMap.codeMap.get("R").getBytes(),"utf-8"));
//        System.out.println(Charset.defaultCharset());
////        System.out.println(new String(XYGSCharCodeMap.industryCode.get("R").getBytes("ISO-8859-1"),"GBK"));
//        System.out.println(new String(XYGSCharCodeMap.industryCode.get("R").getBytes("utf-8"),"utf-8"));
//        System.out.println(new String(XYGSCharCodeMap.industryCode.get("R").getBytes("GBK"),"ISO-8859-1").getBytes("ISO-8859-1"));
//        System.out.println(new String(XYGSCharCodeMap.industryCode.get("R").getBytes("GBK"),"ISO-8859-1"));
//        //System.out.println(convertGBKtoUTF8(XYGSCharCodeMap.industryCode.get("R")).getBytes("utf-8"));
    }

//
//    @Test
//    public void getMapCodeTest() throws IOException {
//        System.out.println(getMapCode("C:\\Users\\chinacscs\\Documents\\WeChat Files\\zhoujieren64\\Files\\codemap.csv","R"));
//    }



    private String algoShareHolderQuery(String algo) {
        return "MATCH (n) WHERE n.name = 'b' " +
                "WITH n AS nodes " +
                algo + " YIELD node,relation,shareholderNode " +
                "RETURN node, relation ";
    }
    private void assertExpectedResult( int expectedResultCount, String query ) {
        TestUtil.testResult( db, query, ( result ) -> {
            for ( int i = 0; i < 1; i++ ) {
                assertThat( result.next().get( "node" ), is( instanceOf( Node.class ) ) );
            }
        } );
    }
}

*/
