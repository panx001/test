/*
package apoc.algo;

import apoc.cscs.Shareholder;
import org.junit.Test;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.factory.GraphDatabaseFactory;
import org.neo4j.kernel.impl.proc.Procedures;
import org.neo4j.kernel.internal.GraphDatabaseAPI;

import java.io.File;

public class ShareholderTest
{
//    // This rule starts a Neo4j instance
//    @Rule
//    public Neo4jRule neo4j = new Neo4jRule()
////            .boltURI("bolt://10.100.45.42:7687")
//            // This is the Procedure we want to test
//            .withProcedure( Shareholder.class );

    @Test
    public void shouldAllowIndexingAndFindingANode() throws Throwable
    {
        GraphDatabaseService graphDb = new GraphDatabaseFactory().newEmbeddedDatabase(new File("E:\\tools\\neo4j-enterprise-3.5.1\\data\\databases\\graph.db\\"));
        System.out.println("Database Load!");
        Procedures proceduresService = ((GraphDatabaseAPI) graphDb).getDependencyResolver().resolveDependency(Procedures.class);
        proceduresService.registerProcedure(Shareholder.class);
        Result aaa = graphDb.execute("MATCH (c:COMPANY{COMPANY_NM:'中证信用增进股份有限公司'}) with c call apoc.cscs.filterShareholders(c,10) yield sharehdId,sharehdName,sharehdType,sumRatio,path return sharehdId,sharehdName,sharehdType,sumRatio,path");
        System.out.println(aaa);
        graphDb.shutdown();
    }
}*/
