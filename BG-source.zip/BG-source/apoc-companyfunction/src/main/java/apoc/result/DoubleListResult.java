package apoc.result;

import java.util.ArrayList;
import java.util.List;

/**
 * @author mh
 * @since 12.05.16
 */
public class DoubleListResult {
    public final List<Double> path;
    public DoubleListResult(List<Double> path) {
        this.path = new ArrayList<>();
        this.path.addAll(path);
    }


}
