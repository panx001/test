package apoc.result;

import java.util.ArrayList;
import java.util.List;

/**
 * @author mh
 * @since 12.05.16
 */
public class ChooseACResult {
    public final String controllernm;
    public final Double tovalue;
    public ChooseACResult(String controllernm,Double tovalue) {
        this.controllernm = controllernm;
        this.tovalue = tovalue;
    }
    public Double getTovalue() {
        return tovalue;
    }

}
