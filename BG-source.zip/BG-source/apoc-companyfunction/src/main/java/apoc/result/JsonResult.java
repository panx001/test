package apoc.result;

/**
 * @author mh
 * @since 12.05.16
 */
public class JsonResult {
    public final String resultstring;

    public JsonResult(String resultstring) {
        this.resultstring = resultstring;
    }
}
