package apoc.result;

import java.util.List;
import java.util.Map;

public class GroupFactionResult {

    public List<Map<String, Object>> path;

    public GroupFactionResult(List<Map<String, Object>> path) {
        this.path = path;
    }

    public List<Map<String, Object>> getPath() {
        return path;
    }

    public void setPath(List<Map<String, Object>> path) {
        this.path = path;
    }
}