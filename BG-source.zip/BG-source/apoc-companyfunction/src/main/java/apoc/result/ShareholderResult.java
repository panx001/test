package apoc.result;

import java.util.List;

/**
 * @author mh
 * @since 12.05.16
 */
public class ShareholderResult {
    public final String sharehdId;
    public final String sharehdName;
    public final String sharehdType;
    public final Double sumRatio;
    public final List<String> path;

    public ShareholderResult(String sharehdId, String sharehdName, String sharehdType, Double sumRatio, List<String> path) {
        this.sharehdId = sharehdId;
        this.sharehdName = sharehdName;
        this.sharehdType = sharehdType;
        this.sumRatio = sumRatio;
        this.path = path;
    }
}
