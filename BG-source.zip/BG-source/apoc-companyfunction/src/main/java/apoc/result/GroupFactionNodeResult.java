package apoc.result;


import org.neo4j.graphdb.Node;

public class GroupFactionNodeResult {

    public Node node;

    public GroupFactionNodeResult(Node node) {
        this.node = node;
    }

    public Node getNode() {
        return node;
    }

    public void setNode(Node node) {
        this.node = node;
    }
}