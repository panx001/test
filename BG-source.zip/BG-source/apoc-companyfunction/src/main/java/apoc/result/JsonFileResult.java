package apoc.result;

/**
 * @author mh
 * @since 12.05.16
 */
public class JsonFileResult {
    public final String filename;
    public JsonFileResult(String filename) {
        this.filename = filename;
    }
}
