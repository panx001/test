package apoc.result;

import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Relationship;

import java.util.List;

/**
 * @author mh
 * @since 12.05.16
 */
public class PathCombineResult {
    public final List<Node> nodeList;
    public final List<Relationship> relationshipList;

    public PathCombineResult(List<Node> nodeList,List<Relationship> relationshipList) {
        this.nodeList = nodeList;
        this.relationshipList = relationshipList;
    }


}
