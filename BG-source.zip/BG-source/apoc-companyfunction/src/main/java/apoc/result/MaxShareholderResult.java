package apoc.result;

import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Relationship;

/**
 * @author mh
 * @since 12.05.16
 */
public class MaxShareholderResult {
    public final Node node;
    public final Relationship relation;
    public final Node shareholderNode;
    public Double shaRatio;

    public MaxShareholderResult(Node node, Relationship relation, Node shareholdNode) {
        this.node = node;
        this.relation = relation;
        this.shareholderNode = shareholdNode;
    }

    public String getStartNodeId(){
        return String.valueOf(this.shareholderNode.getId());
    }
    public String getEndNodeId(){
        return String.valueOf(this.node.getId());
    }

    public Double getRatio() {
        return Double.valueOf(this.relation.getProperty("SHA_RATIO").toString());
    }


    public Double getSha_ratio() {
        return shaRatio;
    }

    public void setSha_ratio(Double shaRatio) {
        this.shaRatio = shaRatio;
    }
}
