package apoc.result;

import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Relationship;

/**
 * @author mh
 * @since 12.05.16
 */
public class BenefitOwnerResult {
    public final String name;
    public final Object reason;
    public BenefitOwnerResult(String name, Object reason) {
        this.name = name;
        this.reason = reason;
    }

}
