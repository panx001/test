package apoc.cscs;

import apoc.result.JsonFileResult;
import apoc.result.JsonResult;
import net.minidev.json.JSONObject;
import org.neo4j.graphdb.*;
import org.neo4j.procedure.*;

import java.io.File;
import java.io.PrintStream;
import java.util.*;
import java.util.stream.Stream;


public class LoadFileFunction {

    @Context
    public GraphDatabaseService db;

    @Procedure("apoc.cscs.getjsonfilelist")
    @Description("CALL apoc.cscs.getjsonfilelist(folder) YIELD filename  ")
    public Stream<JsonFileResult> getjsonfilelist(@Name("folder") String folder) {
        List<JsonFileResult> results = new ArrayList<>();
        File directory = new File(folder);
        String[] array = directory.list();
        for (String file:array) {
            if(file.endsWith(".json")) results.add(new JsonFileResult(file));
        }
        return results.stream();
    }

    @Procedure
    @Description("apoc.cscs.exportjson(file,data) YIELD resultstring - exports json result")
    public Stream<JsonResult> exportjson(@Name("file") String fileName,@Name("data") Map<String,Object> data) throws Exception {
        List<JsonResult> results = new ArrayList<>();
        File jsonfile = new File(fileName);
        PrintStream out = new PrintStream(jsonfile);
        String jsonresult = JSONObject.toJSONString(data);
        out.println(jsonresult);
        results.add(new JsonResult(jsonresult));
        return results.stream();

    }


}
