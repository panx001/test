package apoc.cscs;
import apoc.result.*;
import org.apache.commons.collections.list.SetUniqueList;
import org.neo4j.graphdb.*;
import org.neo4j.procedure.*;
import net.minidev.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;


public class CompanyFunction {

    @Context
    public GraphDatabaseService db;

//  取出所有股东
//    @Procedure("apoc.algo.getshareholder")
//    @Description("CALL apoc.algo.getshareholder(node) YIELD   ")
//    public Stream<TestOutput> getshareholder(
//            @Name("nodes") Node node) {
//        List<TestOutput> result = new ArrayList<>();
//        for(Relationship rel:node.getRelationships(Direction.INCOMING))
//        {
//            if (rel.getType().name().equals("INVEST")){
//                Double ratio = Double.valueOf(rel.getProperty("SHA_RATIO").toString());
//                result.add(new TestOutput(rel.getStartNode().getId(),ratio));
//            }
//        }
//        return result.stream();
//    }

    @UserFunction
    @Description("apoc.cscs.getRegCapital(rel) - return relation target node's RegCapital")
    public Double getRegCapital(@Name("rel") Relationship targetRelation) {
        boolean regFlag = true;
        Double regCapital = 0.0;
        String relType = "INVEST";
        String numPropertyName = "NUM";
        String regCapitalPropertyName = "REG_CAPITAL";

        List<Relationship> results = new ArrayList<>();
        Node targetNode = targetRelation.getEndNode();
         for(Relationship rel:targetNode.getRelationships(Direction.INCOMING)) {
             if (rel.getType().name().equals(relType)){
                 results.add(rel);
             }
         }

         for (Relationship result :results){
             if(result.hasProperty(numPropertyName)){
                 if(Double.valueOf(result.getProperty(numPropertyName).toString()).equals(0D)){
                     regFlag = false;
                 }
                 regCapital=regCapital+Double.valueOf(result.getProperty(numPropertyName).toString());
             } else regFlag = false;
         }
         if(!regFlag) {
             regCapital = targetNode.hasProperty(regCapitalPropertyName) ?
                     Double.valueOf(targetNode.getProperty(regCapitalPropertyName).toString()): 0.0;
         }

        return regCapital;

    }


    @UserFunction
    @Description("apoc.cscs.listProduct(doubleList) - return the product of double list")
    public Double listProduct(@Name("doubleList") List<Double> doubleList) {
        try {
            Double productResult = 1.0;
            for(Double f:doubleList){
                productResult = productResult*f;
            }
            return productResult;
        }catch (Exception e){
            return null;
        }
    }

    @UserFunction
    @Description("apoc.cscs.getJsonCompanyID(companynm) - return company_id by company_nm calling hbase interface")
    public String getJsonCompanyID(@Name("companynm") String companynm) {
        try {
            String url = "http://10.100.48.32:20550/cdi:company_identifier/"+companynm+"/data:company_id";
            String result = sendGet(url);
//            result = result.substring(1,result.length()-1);
//            String companyid = result.split(":")[1].replace("\"","");
//            return  companyid;
            return  result;
        }catch (Exception e){
            return null;
        }
    }

    @UserFunction
    @Description("apoc.cscs.getName(node) - return company_id by company_nm calling hbase interface")
    public String getName(@Name("node") Node node) {
        try {
            String name = node.hasProperty("COMPANY_NM")?node.getProperty("COMPANY_NM").toString():node.hasProperty("PERSON_NM")?node.getProperty("PERSON_NM").toString():node.getProperty("SECURITY_NM").toString();
            return  name;
        }catch (Exception e){
            return null;
        }
    }


    @Procedure("apoc.cscs.getMaxShareHolder")
    @Description("CALL apoc.cscs.getMaxShareHolder(node) YIELD node,relation,shareHoldNode  ")
    public Stream<MaxShareholderResult> getMaxShareHolder(@Name("nodes") Node node) {
        List<MaxShareholderResult> results = new ArrayList<>();
        for(Relationship rel:node.getRelationships(Direction.INCOMING)) {
            if (rel.getType().name().equals("INVEST")){
                results.add(new MaxShareholderResult(node,rel,rel.getStartNode()));
            }
        }
        results = setRelationShaRatio(results);
        if (!results.isEmpty()){
            MaxShareholderResult maxSha = results.stream().max(Comparator.comparing(MaxShareholderResult::getSha_ratio)).get();
            return new ArrayList<MaxShareholderResult>(){{add(maxSha);}}.stream();
        } else {
            return null;
        }
    }

    @Procedure("apoc.cscs.getBenefitOwner")
    @Description("CALL apoc.cscs.getBenefitOwner(node) YIELD name,reason  ")
    public Stream<BenefitOwnerResult> getBenefitOwner(@Name("nodes") Node node) {
        List<BenefitOwnerResult> results = new ArrayList<>();
        String query = "MATCH (C:COMPANY)<-[R:WORK]-(P1:PERSON) WHERE ID(C) = "+String.valueOf(node.getId()) +"\n" +
                "MATCH (C:COMPANY)<-[*..2]-(P1)\n" +
                "WHERE ID(C) = "+String.valueOf(node.getId()) +" AND P1:PERSON OR (P1)-[:CONTROLLER{RELATION_TYPE:'实际控制人'}]-(:COMPANY) OR NOT (P1)<-[:INVEST]-()\n" +
                "//  实际控制人候选集合（自然人或者国资委等）\n" +
                "WITH DISTINCT C,CASE WHEN P1.PERSON_NM IS NOT NULL THEN P1.PERSON_NM WHEN P1.COMPANY_NM IS NOT NULL THEN P1.COMPANY_NM WHEN P1.SECURITY_NM IS NOT NULL THEN P1.SECURITY_NM END AS NAME\n" +
                "MATCH path = (C)<-[:INVEST*..5]-(P) WHERE P.PERSON_NM = NAME or P.COMPANY_NM = NAME or P.SECURITY_NM = NAME\n" +
                "// 实际控制人候选P到C的所有控制路径\n" +
                "WITH CASE WHEN 'COMPANY' IN LABELS(P) THEN P.COMPANY_NM ELSE P.PERSON_NM  END AS CONTROLLER_NM ,COLLECT([p in rels(path)| CASE WHEN p.SHA_RATIO IS NOT NULL THEN tofloat(p.SHA_RATIO)*0.01 WHEN p.SHA_RATIO IS NULL AND p.NUM IS NOT NULL AND apoc.cscs.getRegCapital(p) <> 0 THEN tofloat(p.NUM)/apoc.cscs.getRegCapital(p) ELSE 0 END])  AS paths,COLLECT([p in rels(path)|CASE WHEN startNode(p).COMPANY_NM IS NOT NULL THEN startNode(p).COMPANY_NM ELSE startNode(p).PERSON_NM END]) AS pathsNm\n" +
                "// 实际控制人候选P到C的所有控制路径的持股比例\n" +
                "// WITH CONTROLLER_NM,pathsNm,[path in paths| [value in path| case when toFloat(value) >= 0.5 then 1 else value end ]] AS paths\n" +
                "// 实际控制人候选P到C的所有控制路径的持股比例超过50%则可以是为100%控制 \n" +
                "// 实际控制人候选P到C的各个控制路径持股比例累积\n" +
                "WITH CONTROLLER_NM,paths as pathValue,[path in paths |apoc.cscs.listProduct(path) ] AS pValues,pathsNm\n" +
                "WITH   CONTROLLER_NM ,pathValue,pValues,apoc.coll.sum(pValues) AS totalValue,pathsNm\n" +
                "WHERE totalValue > 0.25\n" +
                "// 实际控制人候选P到C的所有控制路径持股比例累积求和\n" +
                "RETURN CONTROLLER_NM AS NAME ,\n" +
                "//pathValue,\n" +
                "//pValues,\n" +
                "//pathsNm,\n" +
                "apoc.number.format(totalValue*100, '##0.0000')+'%' AS REASON\n" +
                "//toFloat(apoc.number.format(totalValue, '##0.0000')) AS totalValue\n" +
                "ORDER BY REASON DESC\n" +
                "UNION \n" +
                "MATCH (C:COMPANY{COMPANY_NM:'乐视网信息技术(北京)股份有限公司'})<-[R:WORK]-(P1:PERSON)\n" +
                "WHERE ID(C) = "+String.valueOf(node.getId()) +"\n" +
                "WITH  P1.PERSON_NM  AS NAME ,COLLECT(R.POSITION) AS REASON\n" +
                "RETURN NAME,REASON\n" +
                "UNION\n" +
                "MATCH (C:COMPANY{COMPANY_NM:'乐视网信息技术(北京)股份有限公司'})<-[R:CONTROLLER{RELATION_TYPE:'实际控制人'}]-(P1)\n" +
                "WHERE ID(C) = "+String.valueOf(node.getId()) +"\n" +
                "RETURN CASE WHEN P1.PERSON_NM IS NOT NULL THEN P1.PERSON_NM WHEN P1.COMPANY_NM IS NOT NULL THEN P1.COMPANY_NM WHEN P1.SECURITY_NM IS NOT NULL THEN P1.SECURITY_NM END AS NAME,'实际控制人' AS REASON\n" +
                "\n" +
                "\n";
        Result result = db.execute(query);
        if (result.hasNext()) {
            results.add(new BenefitOwnerResult(result.next().get("NAME").toString(),result.next().get("REASON")));
    }
        return results.stream();
    }

    @Procedure("apoc.cscs.filterPaths")
    @Description("CALL apoc.cscs.filterPaths(paths) YIELD path  ")
    public Stream<DoubleListResult> filterPaths(@Name("paths") List<List<Double>> paths) {
        try{
            List<DoubleListResult> results = new ArrayList<>();
            for (List<Double> path:paths) {
                List<Double> pathtemp = path.stream().map(n -> (n>0.5 && n<=1)?1d:n).collect(Collectors.toList());
                results.add(new DoubleListResult(pathtemp));
            }
            return results.stream();
        } catch (Exception e){
            return null;
        }
    }

    //使用可以使用集合加法进行路径集合的合并
    @Procedure("apoc.cscs.pathCombine")
    @Description("CALL apoc.cscs.pathCombine(path1,path2) YIELD nodeList,relationshipList  ")
    public Stream<PathCombineResult> pathCombine(@Name("paths1") List<Path> paths1, @Name("paths2") List<Path> paths2) {
        List<PathCombineResult> results = new ArrayList<>();
        List<Node> nodeUniqueList = SetUniqueList.decorate(new ArrayList<Node>());
        List<Relationship> relationUniqueList = SetUniqueList.decorate(new ArrayList<Relationship>());
        combinePath(nodeUniqueList,relationUniqueList,paths1);
        combinePath(nodeUniqueList,relationUniqueList,paths2);
        results.add(new PathCombineResult(nodeUniqueList,relationUniqueList));
        return results.stream();
    }

    //使用可以使用集合加法进行路径集合的合并
    @Procedure("apoc.cscs.pathCombineTrible")
    @Description("CALL apoc.cscs.pathCombineTrible(path1,path2,path3) YIELD nodeList,relationshipList  ")
    public Stream<PathCombineResult> pathCombineTrible(@Name("paths1") List<Path> paths1, @Name("paths2") List<Path> paths2, @Name("paths3") List<Path> paths3) {
        List<PathCombineResult> results = new ArrayList<>();
        List<Node> nodeUniqueList = SetUniqueList.decorate(new ArrayList<Node>());
        List<Relationship> relationUniqueList = SetUniqueList.decorate(new ArrayList<Relationship>());
        combinePath(nodeUniqueList,relationUniqueList,paths1);
        combinePath(nodeUniqueList,relationUniqueList,paths2);
        combinePath(nodeUniqueList,relationUniqueList,paths3);

//        if (paths3 != null) {
//            nodeUniqueList.addAll(StreamSupport.stream(path3.nodes().spliterator(),false).collect(Collectors.toList()));
//            relationUniqueList.addAll(StreamSupport.stream(path3.relationships().spliterator(),false).collect(Collectors.toList()));
//        }
        results.add(new PathCombineResult(nodeUniqueList,relationUniqueList));
        return results.stream();
    }

    @Procedure("apoc.cscs.chooseActualController")
    @Description("CALL apoc.cscs.chooseActualController(resultlist) YIELD controllernm,tovalue ")
    public Stream<ChooseACResult> chooseActualController(@Name("resultlist")  List<Map<String,String>> resultlist) {
        List<ChooseACResult> results = resultlist.stream().map(mapresult -> new ChooseACResult(mapresult.get("CONTROLLER_NM"), Double.valueOf(mapresult.get("totalValue")))).collect(Collectors.toList());
//        if (results.size() == 2 && results.get(1).getTovalue().equals(results.get(2).getTovalue())) {
//            return null;
//        }
        ChooseACResult result = results.stream().max(Comparator.comparing(ChooseACResult::getTovalue)).get();
        results = results.stream().filter(temp -> temp.getTovalue().equals(result.getTovalue())).collect(Collectors.toList());
        if(result.getTovalue()<0.33){
            return null;
        }
//        List<ChooseACResult> sortresults = results.stream().sorted((p1,p2)->p1.getTovalue().compareTo(p2.getTovalue())).collect(Collectors.toList());
//        if (sortresults.size()>1 ){}
        List<ChooseACResult> finalResults = results;
        return new ArrayList<ChooseACResult>(){{addAll(finalResults);}}.stream();
    }

    private List<MaxShareholderResult>  setRelationShaRatio(List<MaxShareholderResult> results) {
        boolean regFlag = true;
        Double regCapital = 0.0;
        for (MaxShareholderResult result :results){
            if(result.relation.hasProperty("NUM")){
                if(Double.valueOf(result.relation.getProperty("NUM").toString()).equals(0D)) {
                    regFlag = false;
                }
                regCapital=regCapital+Double.valueOf(result.relation.getProperty("NUM").toString());
            }else regFlag = false;
        }
        if(!regFlag) {
            regCapital = results.get(0).node.hasProperty("REG_CAPITAL") ?
                    Double.valueOf(results.get(0).node.getProperty("REG_CAPITAL").toString()): 0.0;
        }
        for (MaxShareholderResult result :results){
            if(result.relation.hasProperty("SHA_RATIO")) {
                result.setSha_ratio(Double.valueOf(result.relation.getProperty("SHA_RATIO").toString())/100);
            } else if (!regCapital.equals(0.0)){
                if(result.relation.hasProperty("NUM")){
                    result.setSha_ratio(Double.valueOf(result.relation.getProperty("NUM").toString())/regCapital);
                }
                else result.setSha_ratio(0.0);
            }
            else result.setSha_ratio(0.0);
        }
        if(results.size() == 1){
            results.get(0).setSha_ratio(1d);
        }
        return results;
    }


//    //测试数据库读写
//    @Procedure(value = "apoc.algo.getmaxshareholderandcreaterelation",mode = Mode.WRITE)
//    @Description("CALL apoc.algo.getmaxshareholderandcreaterelation(node) YIELD node,relation,shareholdnode  ")
//    public Stream<MaxShareholderResult> getmaxshareholderandcreaterelation(@Name("nodes") Node node) {
//        List<MaxShareholderResult> result = new ArrayList<>();
//        for(Relationship rel:node.getRelationships(Direction.INCOMING)) {
//            if (rel.getType().name().equals("INVEST")){
//                result.add(new MaxShareholderResult(node,rel,rel.getStartNode()));
//            }
//        }
//        MaxShareholderResult maxSha = result.stream().max(Comparator.comparing(MaxShareholderResult::getRatio)).get();
//        db.execute(algoQuery(maxSha.getStartNodeId(),maxSha.getEndNodeId())).close();
////        return result.stream().max(Comparator.comparing(TestOutput::getRatio)).get;
//        return new ArrayList<MaxShareholderResult>(){{add(maxSha);}}.stream();
////        return StreamSupport.stream(node.getRelationships(Direction.INCOMING).spliterator(),false).map(relationship ->new TestOutput(relationship.getStartNode().getId()) );
//    }



    private String algoQuery(String startNodeId, String endNodeId) {
        return "MATCH (a:COMPANY) WHERE ID(a)= " +startNodeId+
                " MATCH (b:COMPANY) WHERE ID(b)= " +endNodeId+
                " CREATE\n" +
                "  (a)-[:CONTROLLER {RELATION_TYPE:'CONTROLLER'}]->(b) ";
    }

    private void combinePath(List<Node> nodeUniqueList,List<Relationship> relationUniqueList,List<Path> paths) {
        if (paths != null){
            for (Path path:paths)
            {
                nodeUniqueList.addAll(StreamSupport.stream(path.nodes().spliterator(),false).collect(Collectors.toList()));
                relationUniqueList.addAll(StreamSupport.stream(path.relationships().spliterator(),false).collect(Collectors.toList()));
            }
        }
    }
    public static String sendGet(String url) {
        String result = "";
        BufferedReader in = null;
        try {
            String urlNameString = url;
            URL realUrl = new URL(urlNameString);
            // 打开和URL之间的连接
            URLConnection connection = realUrl.openConnection();
            // 设置通用的请求属性
            connection.setRequestProperty("accept", "application/octet-stream");
//            connection.setRequestProperty("connection", "Keep-Alive");
//            connection.setRequestProperty("user-agent",
//                    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            // 建立实际的连接
            connection.connect();
            // 定义 BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(
                    connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            return null;
        }
        // 使用finally块来关闭输入流
        finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception e2) {
                return null;
            }
        }
        return result;
    }


}
