package apoc.cscs;

import apoc.result.GroupFactionNodeResult;
import apoc.result.GroupFactionResult;
import org.apache.commons.lang3.StringUtils;
import org.neo4j.graphdb.*;
import org.neo4j.procedure.Description;
import org.neo4j.procedure.Mode;
import org.neo4j.procedure.Name;
import org.neo4j.procedure.Procedure;

import java.util.*;
import java.util.stream.Stream;

/**
 * Shareholder
 */
public class GroupFaction {
    // 内地政府名称
    static String[] inlandGoverments = {"人民政府", "中华人民共和国", "委员会", "国有资产监督管理委员会", "证券监督管理委员会", "银行保险监督管理委员会", "国务院", "外交部", "科学技术部", "国家安全部", "司法部", "人力资源和社会保障部", "交通运输部", "国防部", "教育部", "工业和信息化部", "公安部", "民政部", "财政部", "自然资源部",
            "住房和城乡建设部", "水利部", "审计署", "外国专家局", "航天局", "海洋局", "体育总局", "市场监督管理总局", "税务总局", "电视总局", "统计局", "保障局", "新闻出版署", "事务局", "办公室", "新华通讯社", "社会科学院", "发展研究中心", "气象局", "科学院", "工程院", "广播电视总台", "中央党校",
            "信访局", "烟草专卖局", "林业和草原局", "民用航空局", "文物局", "煤矿安全监察局", "粮食和物资储备局", "国防科技工业局", "铁路局", "邮政局", "管理局", "知识产权局"};
    // 非内地政府机构
    static String[] nonInlandGoverments = {"香港中央结算有限公司", "香港中央结算(代理人)有限公司"};
    // 重要职位列表
    static String[] positionArray  = {"法定代表人", "董事长", "副董事长", "董事", "执行董事", "总经理", "副总经理", "经理", "董事长兼总经理", "董事长兼副总经理", "董事长兼经理",
            "副董事长兼总经理", "董事兼总经理", "董事兼经理", "执行董事兼总经理", "执行董事兼经理", "董事会秘书", "财务负责人", "财务总监"};
    private static List<String> positionList = Arrays.asList(positionArray);

    @Procedure(value = "apoc.cscs.findGFMotherNode", mode = Mode.READ)
    @Description("Params: node means start node; Return: value is named node, if do not find record, it will return the start node")
    public Stream<GroupFactionNodeResult> findGFMotherNode(@Name("node") Node node,  @Name(value = "investRatio", defaultValue = "5") Double investRatio) {
        List<GroupFactionNodeResult> result = new ArrayList();
        // 主要用于解决循环持股的关系
        Map<Long, Relationship> pathMap = new HashMap();
        Node motherNode = shareHoldMotherCompany(node, investRatio, pathMap);
        result.add(new GroupFactionNodeResult(motherNode));
        return result.stream();
    }

    @Procedure(value = "apoc.cscs.listGFInvestRelations", mode = Mode.READ)
    @Description("Params: node is start node; level is Number of layers; if returnType is 2 of number, will return child node. if returnType is 3 of number, will return child node and other node; Return: value is named path(startGroupPos, relation, endGroupPos)")
    public Stream<GroupFactionResult> listGFInvestRelations(@Name("node") Node node, @Name("level") Long level, @Name(value = "returnType", defaultValue = "2") Long returnType, @Name(value = "investRatio", defaultValue = "5") Double investRatio) {
        List<GroupFactionResult> result = new ArrayList();
        List<Map<String, Object>> resultList = new ArrayList<>();
        // 主要用于解决循环持股的关系
        Map<Long, Relationship> pathMap = new HashMap();
        Map<Long, Relationship> childPathMap = new HashMap();
        Node motherNode = shareHoldMotherCompany(node, investRatio, pathMap);
        if(returnType == 2) {
            // 子公司
            pathMap.clear();
            shareHoldChildCompany(motherNode, investRatio, childPathMap, pathMap, level, resultList, true);
        } else if(returnType == 3) {
            // 子公司
            pathMap.clear();
            shareHoldChildCompany(motherNode, investRatio, childPathMap, pathMap, level, resultList, true);
            // 其他公司
            pathMap.clear();
            shareHoldOtherCompany(motherNode, investRatio, childPathMap, positionList, pathMap, resultList);
        }
        result.add(new GroupFactionResult(resultList));
        return result.stream();
    }


    /**
     * 寻找集团派系的母公司
     * @param node 遍历的节点
     * @param investRatio 投资比例
     * @param pathMap 寻找集团母公司走的路径集合
     * @return 母节点取开始节点
     */
    private Node shareHoldMotherCompany(Node node, Double investRatio, Map<Long, Relationship> pathMap) {
        Iterable<Relationship> rels = node.getRelationships(RelationshipType.withName("INVEST"), Direction.INCOMING);
        // 寻找多个关系中的最大的控股关系
        if(rels.iterator().hasNext()) {
            Relationship maxRelationship = maxShareHolderRelationship(rels, investRatio);
            // 过滤关系
            if(maxRelationship != null) {
                Node endNode = maxRelationship.getEndNode();
                Node startNode = maxRelationship.getStartNode();
                // 如果母节点是自然人,不在继续穿透
                if (startNode.hasLabel(Label.label("PERSON"))) {
                    return endNode;
                }
                // 如果最大的股东是政府, 选取当前节点
                if (startNode.hasProperty("COMPANY_NM") && isInlandGovermentShareHold(startNode.getProperty("COMPANY_NM").toString())) {
                    return endNode;
                }
                // 如果最大的股东是非内地的政府, 寻找母节点的平级第二大股东关系
                if (startNode.hasProperty("COMPANY_NM") && isNonInLandGovermentShareHold(startNode.getProperty("COMPANY_NM").toString())) {
                    Relationship secondRelationship = secondShareHolderRelationship(rels, investRatio);
                    // 如果没有第二大股东停止向上穿透
                    if(secondRelationship == null) return endNode;
                    // 如果第二大股东是自然人,内地政府, 非内地政府 按照自然人的逻辑, 返回下级公司
                    Node secondStartNode = secondRelationship.getStartNode();
                    if(secondStartNode.hasLabel(Label.label("PERSON")) || (secondStartNode.hasProperty("COMPANY_NM") &&
                            (isInlandGovermentShareHold(secondStartNode.getProperty("COMPANY_NM").toString()) || isNonInLandGovermentShareHold(secondStartNode.getProperty("COMPANY_NM").toString())))) {
                        return secondRelationship.getEndNode();
                    }
                    return secondRelationship.getStartNode();
                }
                // 如果此关系已作为最大关系执行过, 此关系循环关系
                if(pathMap.containsKey(maxRelationship.getId())) {
                    return endNode;
                }
                // 将遍历过的关系放入到关系集合中
                pathMap.put(maxRelationship.getId(), maxRelationship);
                // 递归去寻找
                node = shareHoldMotherCompany(startNode, investRatio, pathMap);
            }
        }
        return node;
    }

    /**
     * 寻找控股的子公司
     * @param motherNode
     * @param investRatio
     * @param pathMap
     * @param level
     */
    private void shareHoldChildCompany(Node motherNode, Double investRatio, Map<Long, Relationship> childPathMap, Map<Long, Relationship> pathMap, Long level, List<Map<String, Object>> childResultList, boolean firstLevelFlag) {
        if(level > 0) {
            // 层数减1
            level--;
            Iterable<Relationship> rels = motherNode.getRelationships(RelationshipType.withName("INVEST"), Direction.OUTGOING);
            // 循环遍历关系
            for (Relationship rel : rels) {
                if(pathMap.containsKey(rel.getId())) {
                    continue;
                }
                Iterable<Relationship> childInvestRels = rel.getEndNode().getRelationships(RelationshipType.withName("INVEST"), Direction.INCOMING);
                List<String> list = listMaxInvestRadioRelationship(childInvestRels, investRatio);
                if(list.contains(String.valueOf(rel.getId()))) {
                    Iterable<Relationship> childRels = rel.getEndNode().getRelationships(RelationshipType.withName("INVEST"), Direction.OUTGOING);
                    if(childRels.iterator().hasNext()) {
                        // 递归
                        shareHoldChildCompany(rel.getEndNode(), investRatio, childPathMap, pathMap, level, childResultList, false);
                    }
                    childPathMap.put(rel.getId(), rel);
                    if(firstLevelFlag) {
                        childResultList.add(relationToMap("母公司", rel, "子公司"));
                    }else {
                        childResultList.add(relationToMap("子公司", rel, "子公司"));
                    }
                }
                // 记录走过的关系,避免重复执行
                pathMap.put(rel.getId(), rel);
            }
        }
    }

    /**
     * 寻找其他公司
     * @param positionList
     */
    private void shareHoldOtherCompany(Node motherNode, Double investRatio, Map<Long, Relationship> childPathMap,
                                       List<String> positionList, Map<Long, Relationship> pathMap, List<Map<String, Object>> resultList) {
        /** 母公司参股的企业 */
        Iterable<Relationship> otherRels = motherNode.getRelationships(RelationshipType.withName("INVEST"), Direction.OUTGOING);
        for (Relationship otherRel : otherRels) {
            if(pathMap.containsKey(otherRel.getId())) {
                continue;
            }
            if(childPathMap.containsKey(otherRel.getId())) {
                continue;
            }
            resultList.add(relationToMap("母公司", otherRel, "其他"));
            pathMap.put(otherRel.getId(), otherRel);
        }

        /** 母公司高管任职的企业 和 控股的企业 */
        holderWorkAndHoldForOtherCompany(motherNode, investRatio, positionList, pathMap, childPathMap, resultList);

        /** 子公司高管任职的企业 和 控股的企业 */
        for (Relationship childRel : childPathMap.values()) {
            holderWorkAndHoldForOtherCompany(childRel.getEndNode(), investRatio,  positionList, pathMap, childPathMap, resultList);
        }
    }

    /**
     *
     * 公司高管控股其他企业和任职的其他企业
     */
    private void holderWorkAndHoldForOtherCompany(Node node, Double investRatio, List<String> positionList, Map<Long, Relationship> pathMap, Map<Long, Relationship> childPathMap, List<Map<String, Object>> resultList) {
        Iterable<Relationship> workRels = node.getRelationships(RelationshipType.withName("WORK"), Direction.INCOMING);
        for (Relationship workRel : workRels) {
            Node workerStartNode = workRel.getStartNode();
            if(workRel.hasProperty("POSITION") && positionList.contains(workRel.getProperty("POSITION").toString())) {
                /** 高管任职的企业 */
                Iterable<Relationship> otherWorkRels = workerStartNode.getRelationships(RelationshipType.withName("WORK"), Direction.OUTGOING);
                for (Relationship otherWorkRel : otherWorkRels) {
                    if(pathMap.containsKey(otherWorkRel.getId())) {
                        continue;
                    }
                    if(childPathMap.containsKey(otherWorkRel.getId())) {
                        continue;
                    }
                    // 在其他公司也任重要职位
                    if(otherWorkRel.hasProperty("POSITION") && positionList.contains(otherWorkRel.getProperty("POSITION").toString())) {
                        resultList.add(relationToMap("其他", otherWorkRel, "其他"));
                        pathMap.put(otherWorkRel.getId(), otherWorkRel);
                    }
                }

                Iterable<Relationship> rels = workerStartNode.getRelationships(RelationshipType.withName("INVEST"), Direction.OUTGOING);
                /** 高管控股的企业（一层） */
                for (Relationship rel : rels) {
                    if(pathMap.containsKey(rel.getId())) {
                        continue;
                    }
                    if(childPathMap.containsKey(rel.getId())) {
                        continue;
                    }
                    // 高管投资的公司的控股关系
                    Iterable<Relationship> shareHoldCompanyInverstedRel = rel.getEndNode().getRelationships(RelationshipType.withName("INVEST"), Direction.INCOMING);
                    // 高管投资的公司的控股关系中的最大的控股
                    List<String> list = listMaxInvestRadioRelationship(shareHoldCompanyInverstedRel, investRatio);
                    if(list.contains(String.valueOf(rel.getId()))) {
                        resultList.add(relationToMap("其他", rel, "其他"));
                    }
                    pathMap.put(rel.getId(), rel);
                }
            }
        }
    }



    /**
     * 多个投资关系中的最大的控股关系, 投资比例相同, 取其中的一个(向上查找)
     * @param rels
     */
    private Relationship maxShareHolderRelationship(Iterable<Relationship> rels, Double investRatio) {
        // 投资比例
        double shaRatio = 0.0;
        // 注册资本
        double regCapital = 0.0;
        Relationship relationship = null;
        for (Relationship rel : rels) {
            double relRaito = (rel.hasProperty("SHA_RATIO") && StringUtils.isNotBlank(rel.getProperty("SHA_RATIO").toString())) ? Double.valueOf(rel.getProperty("SHA_RATIO").toString()) : 0.0;
            // 寻找最大控股公司的母公司
            double startNodeRegCapital = (rel.getStartNode().hasProperty("REG_CAPITAL") && StringUtils.isNotBlank(rel.getStartNode().getProperty("REG_CAPITAL").toString())) ? Double.valueOf(rel.getStartNode().getProperty("REG_CAPITAL").toString()) : 0.0;
            if(relRaito > 50) {
                return rel;
            }
            if ((relRaito > shaRatio) || ((relRaito == shaRatio) && (startNodeRegCapital > regCapital))) {
                relationship = rel;
                shaRatio = relRaito;
                regCapital = startNodeRegCapital;
            }
        }
        if(shaRatio <= investRatio) {
            return null;
        }
        return relationship;
    }

    /**
     * 多个投资关系中的第二大的控股关系
     * @param rels
     * @param investRatio
     */
    private Relationship secondShareHolderRelationship(Iterable<Relationship> rels, Double investRatio) {
        // 投资比例
        double maxShaRatio = 0.0;
        double secondShaRatio = 0.0;
        // 注册资本
        double maxRegCapital = 0.0;
        double secondRegCapital = 0.0;
        Relationship maxRelationship = null;
        Relationship secondRelationship = null;
        for (Relationship rel : rels) {
            double relRaito = (rel.hasProperty("SHA_RATIO") && StringUtils.isNotBlank(rel.getProperty("SHA_RATIO").toString())) ? Double.valueOf(rel.getProperty("SHA_RATIO").toString()) : 0.0;
            // 寻找最大控股公司的母公司
            double startNodeRegCapital = (rel.getStartNode().hasProperty("REG_CAPITAL") && StringUtils.isNotBlank(rel.getStartNode().getProperty("REG_CAPITAL").toString())) ? Double.valueOf(rel.getStartNode().getProperty("REG_CAPITAL").toString()) : 0.0;
            if ((relRaito > maxShaRatio) || ((relRaito == maxShaRatio) && (startNodeRegCapital > maxRegCapital))) {
                secondRelationship = maxRelationship;
                maxRelationship = rel;
                secondShaRatio = maxShaRatio;
                maxShaRatio = relRaito;
                secondRegCapital = maxRegCapital;
                maxRegCapital = startNodeRegCapital;
            }else {
                if ((relRaito > secondShaRatio) || ((relRaito == secondShaRatio) && (startNodeRegCapital > secondRegCapital))) {
                    secondRelationship = rel;
                    secondShaRatio = relRaito;
                    secondRegCapital = startNodeRegCapital;
                }
            }
        }
        if(secondShaRatio <= investRatio) {
            return null;
        }
        return secondRelationship;
    }

    /**
     * 多个投资关系中的最大的控股关系, 如果投资比例有多个, 取多个(向下查找)
     * @param rels
     * @param investRatio
     * @return
     */
    private List<String> listMaxInvestRadioRelationship(Iterable<Relationship> rels, Double investRatio) {
        // 投资比例
        double shaRatio = 0.0;
        String relId = null;
        for (Relationship rel : rels) {
            double relRaito = (rel.hasProperty("SHA_RATIO") && StringUtils.isNotBlank(rel.getProperty("SHA_RATIO").toString())) ? Double.valueOf(rel.getProperty("SHA_RATIO").toString()) : 0.0;
            if(relRaito <= investRatio) continue;
            if(relRaito > 50) {
                List<String> list = new ArrayList();
                list.add(String.valueOf(rel.getId()));
                return list;
            }
            if (relRaito > shaRatio) {
                shaRatio = relRaito;
                relId = String.valueOf(rel.getId());
            } else if (relRaito == shaRatio) {
                relId = relId + "," + rel.getId();
            }
        }
        if(relId == null) {
            return new ArrayList();
        }
        return Arrays.asList(relId.split(","));
    }

    /**
     * 封装关系到map中
     * @param relation
     * @return
     */
    private Map<String, Object> relationToMap(String startGroupPos, Relationship relation, String endGroupPos) {
        Map<String, Object> resultMap = new HashMap(){
            {
                this.put("startGroupPos", startGroupPos);
                this.put("relation", relation);
                this.put("endGroupPos", endGroupPos);
            }
        };
        return resultMap;
    }

    /**
     * 判断该公司是否属于政府单位列表
     * @param name
     * @return
     */
    private boolean isInlandGovermentShareHold(String name) {
        return Arrays.stream(inlandGoverments).anyMatch(s -> name.contains(s));
    }

    /**
     * 判断该公司是否属于政府单位列表
     * @param name
     * @return
     */
    private boolean isNonInLandGovermentShareHold(String name) {
        return Arrays.stream(nonInlandGoverments).anyMatch(s -> name.contains(s));
    }
}