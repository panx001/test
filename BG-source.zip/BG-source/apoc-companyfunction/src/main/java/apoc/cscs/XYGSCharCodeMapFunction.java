package apoc.cscs;

import org.apache.commons.collections.map.HashedMap;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.procedure.*;
import java.io.*;
import java.util.Map;


public class XYGSCharCodeMapFunction {

    @Context
    public GraphDatabaseService db;

//    @UserFunction
//    @Description("apoc.cscs.getPositionByCode(positioncode) - return position by positioncode")
//    public String getPositionByCode(@Name("positioncode") String positioncode) {
//        try {
////            return convertGBKtoUTF8(XYGSCharCodeMap.codeMap.get(positioncode));
//            return XYGSCharCodeMap.codeMap.get(positioncode);
//        }catch (Exception e){
//            return null;
//        }
//    }
//
//    @UserFunction
//    @Description("apoc.cscs.getIndustryByCode(industrycode) - return industry by industrycode")
//    public String getIndustryByCode(@Name("industrycode") String industrycode) {
//        try {
////            return convertGBKtoUTF8(XYGSCharCodeMap.codeMap.get(industrycode));
//            return XYGSCharCodeMap.codeMap.get(industrycode);
//        }catch (Exception e){
//            return null;
//        }
//    }
//
//    @UserFunction
//    @Description("apoc.cscs.getCurrencyByCode(positioncode) - return currency by currencycode")
//    public String getCurrencyByCode(@Name("currencycode") String currencycode) {
//        try {
////            return convertGBKtoUTF8(XYGSCharCodeMap.currencyCode.get(currencycode));
////            return convertGBKtoUTF8(XYGSCharCodeMap.codeMap.get(currencycode));
//            return XYGSCharCodeMap.codeMap.get(currencycode);
//        }catch (Exception e){
//            return null;
//        }
//    }


    //每次使用map需要重新加载
    @UserFunction
    @Description("apoc.cscs.getMapCode(filepath,key) - return value by key loading from file")
    public String getMapCode(@Name("filepath") String filepath,@Name("key") String key) throws IOException {
        try {
            File directory = new File(filepath);
            String inString = "";
            Map<String,String> codeMap = new HashedMap();
            BufferedReader reader = new BufferedReader(new FileReader(directory));
            while((inString = reader.readLine())!= null){
//                System.out.println(inString);
                codeMap.put(inString.split(",")[0],inString.split(",")[1]);
            }
            return codeMap.get(key);
        }catch (Exception e){
            return null;
        }
    }




    //以下两个方法可以将map存在内存中
    @UserFunction
    @Description("apoc.cscs.loadMap(filepath) - return value by key loading from file")
    public Map<String,String> loadMap(@Name("filepath") String filepath) throws IOException {
        try {
            File directory = new File(filepath);
            String inString = "";
            Map<String,String> codeMap = new HashedMap();
            BufferedReader reader = new BufferedReader(new FileReader(directory));
            while((inString = reader.readLine())!= null){
                codeMap.put(inString.split(",")[0],inString.split(",")[1]);
            }
            return codeMap;
        }catch (Exception e){
            return null;
        }
    }
    @UserFunction
    @Description("apoc.cscs.getMap(map,key) - return value by key loading from file")
    public String getMap(@Name("map") Map<String,String> map,@Name("key")String  key) throws IOException {
        try {
            return map.get(key);
        }catch (Exception e){
            return null;
        }
    }

    public static  String convertGBKtoUTF8(String gbkString) throws UnsupportedEncodingException {
        String iso = new String(gbkString.getBytes("GBK"),"ISO-8859-1");
        return new String(gbkString.getBytes("utf-8"),"utf-8");
    }



    public static byte[] getUTF8BytesFromGBKString(String gbkStr) {
        int n = gbkStr.length();
        byte[] utfBytes = new byte[3 * n];
        int k = 0;
        for (int i = 0; i < n; i++) {
            int m = gbkStr.charAt(i);
            if (m < 128 && m >= 0) {
                utfBytes[k++] = (byte) m;
                continue;
            }
            utfBytes[k++] = (byte) (0xe0 | (m >> 12));
            utfBytes[k++] = (byte) (0x80 | ((m >> 6) & 0x3f));
            utfBytes[k++] = (byte) (0x80 | (m & 0x3f));
        }
        if (k < utfBytes.length) {
            byte[] tmp = new byte[k];
            System.arraycopy(utfBytes, 0, tmp, 0, k);
            return tmp;
        }
        return utfBytes;
    }
}
