package apoc.cscs;

import apoc.result.ShareholderResult;
import org.neo4j.graphalgo.impl.util.PathImpl;
import org.neo4j.graphdb.*;
import org.neo4j.procedure.Description;
import org.neo4j.procedure.Mode;
import org.neo4j.procedure.Name;
import org.neo4j.procedure.Procedure;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Shareholder
 */
public class Shareholder {

    @Procedure(value = "apoc.cscs.filterShareholders", mode = Mode.READ)
    @Description("CALL apoc.cscs.filterShareholders(node,filterSharito) YIELD node,relation,shareHoldNod")
    public Stream<ShareholderResult> filterShareholders(@Name("node") Node node, @Name("filterSharito")Double filterSharito)
    {
        List<ShareholderResult> results = new ArrayList<>();
//        List<Path> paths = new ArrayList<Path>();
//        Map<Long,Double> sharehoderMap = new HashMap<>();
//        Map<Long,Double> finalMap = new HashMap<>();
//
//        filterShareholders(node, sharehoderMap, finalMap, paths);
//        System.out.println(node);
//        Map<Long, Double> filterMap = finalMap.entrySet().stream().filter(r -> r.getValue() > filterSharito).collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getValue));
//        Iterable<Long> keys = (Iterable) filterMap.keySet().iterator();
//        for (Long key:keys) {
//            List<String> finalPaths  = new ArrayList<>();
//            filterPath(key,paths, "",finalPaths);
//            Double sumSharito = Double.valueOf(filterMap.get(key.toString()).toString());
//            results.add(new ShareholderDto(key.toString(),"","",sumSharito,finalPaths));
//        }
        return results.stream();
    }

    private void filterPath(Long endNodeId, List<Path> paths, String filterPaths , List<String> finalPaths) {
        List<Path> filterPath  = paths.stream().filter(path -> path.endNode().getId() == endNodeId).collect(Collectors.toList());
        if(filterPath.size() == 0){
            finalPaths.add(filterPaths);
            return;
        }
        for(Path path : filterPath){
            if(path.endNode().hasProperty("PERSON_NM")){
                filterPaths = path.endNode().getProperty("PERSON_NM") + filterPaths;
            } else{
                filterPaths = path.endNode().getProperty("COMPANY_NM") + filterPaths;
            }
            filterPath(path.startNode().getId(),paths,filterPaths,finalPaths);
        }
    }

    private void filterShareholders(Node node, Map sharehoderMap, Map finalMap, List<Path> paths) {
        Iterable<Relationship> rels = node.getRelationships(RelationshipType.withName("INVEST"), Direction.INCOMING);
        if(rels == null){
            finalMap.put(node.getId(),sharehoderMap.get(node.getId()));
            return;
        }
        for(Relationship rel : rels) {
            PathImpl.Builder builder = new PathImpl.Builder(node);
            Path p = builder.push(rel).build();
            Optional<Path> filterPath = paths.stream()
                    .filter(path -> p.startNode() == path.startNode())
                    .filter(path -> p.endNode() == path.endNode())
                    .filter(path -> p.relationships() == path.relationships())
                    .findAny();
            if(filterPath != null){
                continue;
            }
            builder.push(rel).build();

            Double shaRaito = 0.0;
            Long startNodeId = rel.getStartNodeId();
            Long endNodeId = rel.getEndNodeId();
            if(rel.hasProperty("SHA_RATIO")) {
                shaRaito = Double.valueOf(rel.getProperties("SHA_RATIO").toString()) / 100;
            } else if (rel.hasProperty("NUM") && rel.getEndNode().hasProperty("REG_CAPITAL")) {
                Double regCapital = Double.valueOf(rel.getEndNode().getProperty("REG_CAPITAL").toString());
                shaRaito = Double.valueOf(rel.getProperties("NUM").toString()) / regCapital;
            }
            if(sharehoderMap.containsKey(startNodeId)){
                shaRaito = shaRaito * (Double) sharehoderMap.get(startNodeId);
                if(shaRaito != 0.0) sharehoderMap.put(endNodeId,shaRaito);
            } else if(sharehoderMap.containsKey(endNodeId)){
                shaRaito = shaRaito *  (Double) sharehoderMap.get(startNodeId) + (Double)sharehoderMap.get(endNodeId);
                if(shaRaito != 0.0) sharehoderMap.put(endNodeId,shaRaito);
            } else {
                sharehoderMap.put(endNodeId, shaRaito);
            }
            filterShareholders(rel.getStartNode(),sharehoderMap,finalMap,paths);
        }
    }
}