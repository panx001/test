# 图谱更新程序 graph-updater

## Get Started

* maven安装第三方jar 
./mvnw install:install-file -Dfile=lib/chinadaas-data-security-C-1.1.jar \
-DgroupId=chinadaas.data  -DartifactId=security -Dversion=1.1 -Dpackaging=jar

## 程序压缩包获取
图谱产品分为三种: 1. 简版图谱  2. 标准图谱 3. 沙盒图谱, 图谱产品根据cypher目录下的csv.yaml文件区分.
根据产品类型执行下面的不同的打包命令.

## 进入到项目根目录，执行打包命令:
   简版图谱: mvn install -Dmaven.test.skip=true -Psit
   标准图谱: mvn install -Dmaven.test.skip=true -Puat
   沙盒图谱: mvn install -Dmaven.test.skip=true -Pprod

