# 沙盒更新程序部署流程 graph-updater
## Get Started

## 程序安装启动
1. 将graph-updater.zip拷贝到安装目录
2. 执行unzip graph-updater.zip解压缩命令
3. 进入到 安装目录/ graph-updater 目录下
4. 修改 安装目录/ graph-updater/config/application.yaml文件中需要修改的对应配置项
    4.1 邮件配置: 根据客户提供的邮箱信息配置, 邮箱服务器地址(spring.mail.host),发件人用户名(spring.mail.username), 发件人密码(spring.mail.password),  发送主题(app.mail.subject), 
              收件人邮箱(app.mail.to),抄送人邮箱(app.mail.cc).多个收件人和抄送人用逗号分隔, 如果不需要邮箱,可不填这些选项.
        
    4.2 应用配置
        4.2.1 项目安装目录(app.home)配置
        4.2.2 图谱初始化完成时的时间戳(app.updateFrom), 也就是此次部署,程序处理图谱文件的开始时间
        4.2.3 定时任务cron表达式配置(app.cron-expression), 如果设置为空, 默认每15分钟执行一次: 0 0/15 * * * ?
        4.2.4 图谱服务器存放图谱数据的文件夹的绝对路径(app.loadCsvBasePath).
        4.2.5 图谱服务器配置, 图谱地址服务器地址(app.neo4j.uri), 用户名(app.neo4j.user), 密码(app.neo4j.password). 如果用户不需要更新图谱,把更新图谱的开关(app.neo4j.update.enable)改成false, 其他选项不填.
              图谱导入csv 文件方式有http/file两种方式. 如果图谱服务器和增量更新程序在同一台服务出于性能考虑,使用file导入图谱服务器的方式(app.httpLoad.enable: false),如果不在同一台服务器, 使用http方式, 将app.httpLoad.enable: true  
        4.2.6 图谱产品类型(app.graph.product.type), 值为:0: 简版图谱 1: 标准图谱 2: 沙盒图谱. 如果值为2(沙盒图谱)需要修改下面的配置, 如果不是可置为空.
             4.2.6.1 如果产品是沙盒图谱(值为2), 需要用户提供客户身份证列表. 提供方式分为三种(app.sandbox.client.provide.type), 值可以为: 0: csv  1: 接口  2: 数据库. 三种方式都需要客户创建匹配成功记录表.
                    a. 如果app.sandbox.client.provide.type等于0: 客户提供的身份证列表文件的路径配置(app.sandbox.client.idcard.path), 可以根据客户的要求配置. 身份证列表是一个带文件头的csv文件, 文件头可以自定义,每一行记录是一个身份证号.
                          文件名命名格式: 自定义名_14位时间戳.csv. 中证数据和客户提供的身份证匹配成功会写入匹配成功记录表, 客户需要增加的数据库脚本,参考[沙盒身份证列表(csv或接口方式)脚本.sql]
                    b. 如果app.sandbox.client.provide.type等于1: 请求方式get | post, 请求路径: http://ip:51000/gds/client/save?idCard=[{"cardNo": "0000000"},{"cardNo": "0000001}] , 
                       中证数据和客户提供的身份证匹配成功会写入匹配成功记录表, 客户需要增加的数据库脚本,参考[沙盒身份证列表(csv或接口方式)脚本.sql]                                                               
                    c. 如果app.sandbox.client.provide.type 等于2: 沙盒客户提供的身份证号的数据库的连接配置, 数据源类型配置(spring.datasource.client.dataSource), 数据库类型:mysql或者是oracle
                           数据库驱动(spring.datasource.primary.driver-class-name), 数据库用户名(spring.datasource.client.username), 数据库密码(spring.datasource.client.password).
                           客户需要增加的数据库脚本,参考[沙盒身份证列表(读取数据库)脚本.sql]
                           同时提供一个立即执行用户上传身份证任务的taskId的接口: http://ip:51000/gds/client/task/redo?taskId=122332   
                           考虑性能方面,用户可以自选择是否将匹配成功的身份证号删除(app.sandbox.idcard.delete.enable)                                                      
             4.2.6.2 neo4j图库节点属性person_id的配置(app.personId.flag),值为整数:  1 原始的personId 2 中证id  3 中数id
             4.2.6.3 同步工商数据表: 数据源类型配置(spring.datasource.gds.dataSource), 如果客户数据库是mysql数据库值为mysql, 如果客户是oracle数据库值为oracle 
                     数据库驱动(spring.datasource.gds.driver-class-name), 数据库用户名(spring.datasource.gds.username), 数据库密码(spring.datasource.gds.password),
                     工商数据库更新的person_id的配置(app.sandbox.business.data.flag), 值为整数 1 中证(只同步中证id) 2 中证 + 中数(同步中证id和中数id), 如果需要更新中数id, 需要在原表中 ZSZH_ID varchar(512) 字段.
                     具体的sql参考[工商数据表添加中数id列的sql脚本.sql]
                     需要更新工商数据表的编号自定义配置(app.business.update.table.no), 值为正数(例如:1,2,3...), 中间用逗号分隔, 无需要更新表, 可不填此项. 其中工商表编号参考注意事项:[工商表编号]
             4.2.6.4 中数加密的版本号配置(app.encode.version), V是大写                                    
5. 修改 安装目录/ graph-updater/config/logback-custom.xml日志配置
6. 确认和调整 安装目录/ graph-updater/bin/graph-updater-start.sh脚本jvm 相关配置项, JAVA_HOME 服务器上java安装的目录.
7. 执行 ./bin/graph-updater-start.sh脚本(可能需要sudo su -)
8. less 或者 tail -f 查看项目的安装目录下的logs文件夹下的日志, 查看是否正常. 
   如果(app.sandbox.enable配置值为true)也就是程序执行了沙盒逻辑, 查看图谱服务器存放图谱数据的文件夹(app.loadCsvBasePath)目录下的文件
   n_person_all, l_person_sharehd, l_work_executive目录下是否有新文件生成, n_person_all_v3, l_person_sharehd_v2, l_work_executive_v2目录下的文件是否删除了. 同时验证工商数据库 COMPY_EXECUTIVESINFO等表数据是否更新成功.

## 程序停止
   执行 ./bin/graph-updater-stop.sh脚本(可能需要sudo su -)

## 注意事项

   [工商表编号]
         | 编号      |     mysql表名                     |   oracle 表名                    |              
         |----------|-----------------------------------|--------------------------------- |
         | 1        |   COMPY_EXECUTIVESINFO            |  COMPY_EXECUTIVESINFO            |   
         | 2        |   COMPY_SHAREHDINVESTNB_XYGS      |  COMPY_SHAREHDINVESTNB_XYGS      |   
         | 3        |   COMPY_SHAREHDINVESTPUB_XYGS     |  COMPY_SHAREHDINVESTPUB_XYGS     |   
         | 4        |   COMPY_SHAREHDINVEST_XYGS        |  COMPY_SHAREHDINVEST_XYGS        |   
         | 5        |   COMPY_SHAREHOLDERS_OPTIMIZED    |  COMPY_SHAREHOLDERS_OPTIMIZED    |   
         | 6        |   COMPY_TAXOVERDUE_XYGS           |  COMPY_TAXOVERDUE_XYGS           |   
         | 7        |   PFCOMPY_AMACPUNISH              |  PFCOMPY_AMACPUNISH              |   
         | 8        |   COMPY_SHAREHOLDERS_OPTIMIZED_V2 |  COMPY_SHAREHOLDERS_OPTIMIZEDV2  |   
         