--如果需要同步中数id到工商数据，需要增加中数id列。根据客户需求自行选择
    --mysql版本
        ALTER TABLE compy_executivesinfo ADD COLUMN ZSZH_ID varchar(512);
        ALTER TABLE compy_sharehdinvest_xygs ADD COLUMN ZSZH_ID varchar(512);
        ALTER TABLE compy_sharehdinvestnb_xygs ADD COLUMN ZSZH_ID varchar(512);
        ALTER TABLE compy_sharehdinvestpub_xygs ADD COLUMN ZSZH_ID varchar(512);
        ALTER TABLE compy_shareholders_optimized ADD COLUMN ZSZH_ID varchar(512);
        ALTER TABLE compy_shareholders_optimized_v2 ADD COLUMN ZSZH_ID varchar(512);
        ALTER TABLE compy_taxoverdue_xygs ADD COLUMN ZSZH_ID varchar(512);
        ALTER TABLE pfcompy_amacpunish ADD COLUMN ZSZH_ID varchar(512);

    -- oracle版本
        ALTER TABLE compy_executivesinfo ADD ZSZH_ID varchar(512);
        ALTER TABLE compy_sharehdinvest_xygs ADD ZSZH_ID varchar(512);
        ALTER TABLE compy_sharehdinvestnb_xygs ADD ZSZH_ID varchar(512);
        ALTER TABLE compy_sharehdinvestpub_xygs ADD ZSZH_ID varchar(512);
        ALTER TABLE compy_shareholders_optimized ADD ZSZH_ID varchar(512);
        ALTER TABLE compy_shareholders_optimizedv2 ADD ZSZH_ID varchar(512);
        ALTER TABLE compy_taxoverdue_xygs ADD ZSZH_ID varchar(512);
        ALTER TABLE pfcompy_amacpunish ADD ZSZH_ID varchar(512);