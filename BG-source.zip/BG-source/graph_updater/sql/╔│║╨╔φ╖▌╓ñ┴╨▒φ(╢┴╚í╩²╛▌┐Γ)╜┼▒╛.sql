-- mysql
CREATE TABLE client_id_card_info (
  id bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  task_id bigint(20)  COMMENT '处理的任务id',
  card_no varchar(32) COMMENT '身份证号',
  create_time timestamp(6) DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  PRIMARY KEY (id),
  KEY index_card_info_task_id (task_id),
  KEY index_card_info_card_no (card_no)
) DEFAULT CHARSET=utf8 COMMENT '客户身份证列表';

CREATE TABLE client_id_card_match_result(
  id bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  task_id bigint(20)  COMMENT '处理的任务id',
  card_no varchar(32) COMMENT '身份证号',
  match_id bigint(20)  COMMENT '中证id',
  match_value varchar(512) COMMENT '身份证号匹配到结果',
  create_time timestamp(6) DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  PRIMARY KEY (id),
  KEY index_match_result_card_no (card_no)
) DEFAULT CHARSET=utf8 COMMENT '客户身份证号匹配结果表';

CREATE TABLE task_status(
  id bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  task_status int(6)  COMMENT '0,未处理 1, 处理中, 2, 完成',
  task_create_time timestamp(6) DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  PRIMARY KEY (id),
  KEY inx_task_status (task_status)
) DEFAULT CHARSET=utf8 COMMENT '任务处理状态表';


-- oracle
CREATE TABLE client_id_card_info (
   id number(20) NOT NULL ,
   task_id number(20),
   card_no varchar2(32),
   create_time timestamp(6) DEFAULT CURRENT_TIMESTAMP(6),
   PRIMARY KEY (id)
);
-- 创建索引
create Index index_card_info_task_id On client_id_card_info(task_id);
create Index index_index_card_info_card_no On client_id_card_info(card_no);

-- 创建序列化
create sequence SEQ_CLIENT_ID_CARD_INFO_ID;

CREATE TABLE client_id_card_match_result(
  id number(20) NOT NULL ,
  task_id number(20),
  card_no varchar2(32),
  match_id number(20),
  match_value varchar2(512) ,
  create_time timestamp(6) DEFAULT CURRENT_TIMESTAMP(6) ,
  PRIMARY KEY (id)
);
--创建索引
create Index index_match_result_card_no On client_id_card_match_result(card_no);


-- 创建序列化
create sequence SEQ_CARD_MATCH_RESULT_ID;


CREATE TABLE task_status(
  id number(20) NOT NULL,
  task_status number(6),
  task_create_time timestamp(6) DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id)
);

create Index index_task_status On task_status(task_status);

-- 创建序列化
create sequence SEQ_TASK_STATUS_ID;
