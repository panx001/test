package com.chinacscs.bg.graph.updater;

import lombok.Data;

import java.util.List;

/**
 * ChangeSet是一个finish文件到上一个finish文件决定的
 */
@Data
public class ChangeSet {

    Long from;
    Long to;

    List<CsvFile> csvFiles;

    @Override
    public String toString() {
        return String.format("%s - %s", from, to);
    }
}
