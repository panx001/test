package com.chinacscs.bg.graph.updater.job;

import com.chinacscs.bg.graph.updater.service.ChangeSetService;
import lombok.extern.slf4j.Slf4j;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

/**
 * UpdateJob
 */
@Slf4j
@DisallowConcurrentExecution
public class UpdateJob extends QuartzJobBean {

    @Autowired
    private ChangeSetService changeSetService;

    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
        try {
            log.debug("定时任务执行UpdateJob开始时间: " + System.currentTimeMillis());
            // 增量更新程序开
            changeSetService.loadAll();
        } catch (Exception e) {
            log.error("执行UpdateJob时出错", e);
        }
    }

    
}