package com.chinacscs.bg.graph.updater.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

/**
 * des: JdbcTemplate数据源的配置类
 * auth: wangpengchao
 */
@Configuration
public class H2DataSourceConfig {
    @Value("org.h2.Driver")
    private String H2_DRIVER;
    @Value("PBTBIgqeKkxCLHHX1s4+OHk5AFIs1QUAPWyL6+BavXNjry/1XCU9qvLm4fFHfF+TFFDc5sEnswCJqa00fBAgsw==")
    private String H2_URL;
    @Value("TviSij1aO+WBAgutaBED1tpJ8p0piuCVObimPnxzPCoYvD2eMYpi8w==")
    private String H2_USERNMAE;
    @Value("xLWSJd+ZkcVlc1NKLdkpXbBlfSlr1V11QiHMSXJxoswKlhoQel4LhuiS/nhFJHPh")
    private String H2_PASSWORD;

    @Bean(name = "h2DataSource")
    public DataSource h2DataSource() {
        DataSourceBuilder<?> dataSourceBuilder = DataSourceBuilder
                .create()
                .driverClassName(H2_DRIVER)
                .url(JasyptUtil.decyptPwd("PBEWithMD5AndDES", H2_URL))
                .username(JasyptUtil.decyptPwd("PBEWithMD5AndDES", H2_USERNMAE))
                .password(JasyptUtil.decyptPwd("PBEWithMD5AndDES", H2_PASSWORD));
        return dataSourceBuilder.build();
    }

    @Bean(name = "h2JdbcTemplate")
    public JdbcTemplate h2JdbcTemplate(
            @Qualifier("h2DataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }
}
