package com.chinacscs.bg.graph.updater.service;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

/**
 * EmailService
 */
@Service
@Slf4j
public class EmailService {
    @Value("${spring.mail.username:}")
    private String from;
    @Value("${app.mail.subject:}")
    private String subject;
    @Value("${app.mail.to:}")
    private String to;
    @Value("${app.mail.cc:}")
    private String cc;
    

    private final JavaMailSender mailSender;

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    public void send(String content) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(from);
            message.setTo(to.split(","));
            if(StringUtils.isNotBlank(cc)) {
                message.setCc(cc.split(","));
            }
            message.setSubject(subject);
            message.setText(content);
            mailSender.send(message);
        } catch (Exception exception) {
            log.error(String.format("Exceptional send email[%s] to target[%s]", subject, to), exception);
        }
    }

}