package com.chinacscs.bg.graph.updater.sandbox;

import java.util.HashMap;
import java.util.Map;

/**
 * import tool 需要有header
 * 这个方法只用于初始化的
 * */
public class HeaderSandboxMapper {

    public static final Map<String, String> header = new HashMap<String, String>() {
        {
            this.put("n_company", "COMPANY_ID:ID(COMPANY_ID),COMPANY_NM,STATUS,ORGNUM,REG_CAPITAL");
            this.put("n_person_all_v3", "PERSON_ID:ID(PERSON_ID),PERSON_NM");
            this.put("l_work_leg", "PERSON_ID:START_ID(PERSON_ID),COMPANY_ID:END_ID(COMPANY_ID),POSITION");
            this.put("l_work_pleg","PERSON_ID:START_ID(PERSON_ID),COMPANY_ID:END_ID(COMPANY_ID),POSITION");
            this.put("l_work_executive_v2", "PERSON_ID:START_ID(PERSON_ID),COMPANY_ID:END_ID(COMPANY_ID),POSITION,R_TYPE");
            this.put("l_person_sharehd_v2", "PERSON_ID:START_ID(PERSON_ID),COMPANY_ID:END_ID(COMPANY_ID),SHA_RATIO,NUM");
            this.put("n_company_sharehd", "COMPANY_ID:ID(COMPANY_ID),COMPANY_NM");
            //如果 多个sharhd_name 可不可以有办法忽略
            this.put("l_company_sharehd", "SHACOMP_ID:START_ID(COMPANY_ID),COMPANY_ID:END_ID(COMPANY_ID),SHA_RATIO,NUM");
            this.put("l_branch", "COMPANY_ID:START_ID(COMPANY_ID),:END_ID(COMPANY_ID)");
            // n_security 和l_issue 可能这里不能初始化，因为加入企业产品节点后不能做。
            /*                this.put("n_security", "SECINNER_ID:ID(SECINNER_ID),SECURITY_CD,SECURITY_NM,SECURITY_TYPE");*/
            /*                this.put("l_issue",":END_ID(SECINNER_ID),:START_ID(COMPANY_ID)");*/
        }
    };
    public static final Map<String, String> nodeLabelRelationType = new HashMap<String, String>() {
        {
            this.put("n_company", "nodes,COMPANY");
            this.put("n_person_all_v3", "nodes,PERSON");
            this.put("l_work_leg", "relationships,WORK");
            this.put("l_work_pleg", "relationships,WORK");
            this.put("l_work_executive_v2", "relationships,WORK");
            this.put("l_person_sharehd_v2", "relationships,INVEST");
            this.put("n_company_sharehd", "nodes,COMPANY");
            this.put("l_company_sharehd", "relationships,INVEST");
            this.put("l_branch", "relationships,BRANCH");
//                this.put("n_security", "nodes,SECURITY");
//                this.put("l_issue","relationships,ISSUE");
        }
    };

    public HeaderSandboxMapper() {
    }
}
