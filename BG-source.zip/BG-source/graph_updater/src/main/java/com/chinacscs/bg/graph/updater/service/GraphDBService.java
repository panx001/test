package com.chinacscs.bg.graph.updater.service;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

/**
 * GraphDBService
 */
@Service
@Slf4j
public class GraphDBService {

    public void replaceDB(String newDb, String oldDb) {
        JSch jSch = new JSch();
        Session session = null;
        try {
            session = jSch.getSession("xuguoqiang", "localhost", 22);
            session.setConfig("StrictHostKeyChecking", "no");
            session.setPassword("");
            session.connect();

            ChannelExec channelExec = (ChannelExec) session.openChannel("exec");
            // channelExec.setCommand(String.format("changedb %s %s", newDb, oldDb));
            channelExec.setCommand("cd ~/Downloads/neo4j-community-3.5.3/ \n ls \n bin/neo4j stop");
            InputStream in = channelExec.getInputStream();
            OutputStream out = channelExec.getOutputStream();
            channelExec.connect();
            channelExec.setOutputStream(System.out);
            // PrintWriter pw = new PrintWriter(out);
            // pw.write("hostname\n\u001a");
            // channelExec.setErrStream(System.err);
            // channelExec.setOutputStream(System.out);
            // BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            // String line = null;
            
            // while ((line = reader.readLine()) != null) {
            //     System.out.println(line);
            // }
            
            channelExec.disconnect();
            int exitCode = channelExec.getExitStatus();

            log.info("exit code {}", exitCode);
        } catch (JSchException e) {
            log.error("SSH 连接错误", e);
        } catch (IOException e) {
            log.error("IO error", e);
        } finally {
            if (null != session && session.isConnected()) {
                session.disconnect();
            }
        }

    }
}