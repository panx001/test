package com.chinacscs.bg.graph.updater.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

/**
 * des: JdbcTemplate数据源的配置类
 * auth: wangpengchao
 */
@Configuration
@ConditionalOnProperty(name = {"app.graph.product.type"}, havingValue = "2")
public class GdsDataSourceConfig {

    @Value("${spring.datasource.gds.driver-class-name}")
    private String GDS_DRIVER;
    @Value("${spring.datasource.gds.jdbcUrl}")
    private String GDS_URL;
    @Value("${spring.datasource.gds.username}")
    private String GDS_USERNMAE;
    @Value("${spring.datasource.gds.password}")
    private String GDS_PASSWORD;

    @Bean(name = "gdsDataSource")
    public DataSource GdsDataSource() {
        DataSourceBuilder<?> dataSourceBuilder = DataSourceBuilder
                .create()
                .driverClassName(GDS_DRIVER)
                .url(GDS_URL)
                .username(GDS_USERNMAE)
                .password(GDS_PASSWORD);
        return dataSourceBuilder.build();
    }

    @Bean(name = "gdsJdbcTemplate")
    public JdbcTemplate jdbcTemplate(
            @Qualifier("gdsDataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }
}
