package com.chinacscs.bg.graph.updater.config;

import java.util.UUID;

import org.springframework.context.annotation.Configuration;


@Configuration
public class AppConfig {

    /** 系统启动uuid **/
    public static final String SYSTEM_UUID = UUID.randomUUID().toString();
}
