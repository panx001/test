package com.chinacscs.bg.graph.updater.sandbox;

import com.chinacscs.bg.graph.updater.service.GdsSyncService;
import com.chinadaas.custom.ChinaDaasDataEncoder;
import com.csvreader.CsvReader;
import com.csvreader.CsvWriter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class FileChange {

    @Autowired(required = false)
    private DbManager dbManager;
    @Autowired(required = false)
    private GdsSyncService gdsSyncService;
    @Value("${app.personId.flag}")
    private Integer personIdFlag;
    @Value("${app.encode.version}")
    private String encodeVersion;
    @Value("${app.loadCsvBasePath}")
    private String loadCsvBasePath;
    @Value("${app.graph.product.type}")
    private Integer graphType;
    @Value("${app.sandbox.client.provide.type}")
    private Integer clientProvideType;
    @Autowired(required = false)
    @Qualifier("clientJdbcTemplate")
    private JdbcTemplate clientJdbcTemplate;
    @Value("${app.sandbox.business.data.flag}")
    private Integer businessDataFlag;
    @Value("${spring.datasource.client.dataSource}")
    private String clientDataSource;
    @Value("${app.sandbox.idcard.delete.enable}")
    private Boolean idcardDeleteEnable;

    /**
     * 全量识别码入库,并生成新的csv文件
     * @param inFile
     * @return
     * @throws Exception
     */
    public Map<String, Object> personMapperChange(String inFile) throws Exception {
        log.info("正在处理文件: " + inFile);
        String outFile = inFile.replace("n_person_all_v3", "n_person_all");
        FileUtils.forceMkdir(new File(new File(outFile).getParent()));
        CsvReader csvReader = new CsvReader(inFile, ',', Charset.forName("UTF-8"));
        CsvWriter csvWriter = new CsvWriter(outFile, ',', Charset.forName("UTF-8"));

        String outFileDir = FilenameUtils.concat(loadCsvBasePath, "ins");
        String mergeDirPath = FilenameUtils.concat(outFileDir, "n_person_info_merge");
        FileUtils.forceMkdir(new File(mergeDirPath));
        String fileName = new File(inFile).getName();
        String timeStamp = fileName.substring(fileName.lastIndexOf("_") + 1, fileName.lastIndexOf("."));
        String outFileName = "n_person_info_" + timeStamp + ".csv";
        String mergeFilePath = FilenameUtils.concat(mergeDirPath,"merge_" + outFileName);
        CsvWriter mergeCsvWriter = new CsvWriter(mergeFilePath, ',', Charset.forName("UTF-8"));

        Map<String, Object> result = new HashMap<>();
        String[] header = {"person_id", "person_nm"};
        String[] mergeHeader = {"person_id", "merge_person_id"};
        String[] content = new String[2];
        String[] mergeContent = new String[2];
        long count = 0;
        long mergeCount = 0;
        try {
            csvReader.readHeaders();
            while (csvReader.readRecord()) {
                if(count == 0) {
                    csvWriter.writeRecord(header);
                }
                String[] items= csvReader.getValues();
                String personId = items[0];
                if (StringUtils.isNotBlank(items[3])) {
                    List<Map<String, Object>> resultSet = dbManager.personQueryByZszhId(items[3]);
                    if (resultSet != null && resultSet.size() > 0) {
                        if (personIdFlag == 2 && StringUtils.isNotBlank(items[2])) {
                            personId = items[2];
                        } else if (personIdFlag == 3) {
                            personId = items[3];
                        }
                        if(StringUtils.isNotBlank(items[2])) {
                            // 同步中证和中数id
                            gdsSyncService.updateGDS(items[0], items[1], items[2], items[3]);
                        }
                        // 客户身份证来自数据库, 将匹配cardNo
                        if(StringUtils.isNotBlank(items[2])) {
                            String cardNo = resultSet.get(0).get("card_no").toString();
                            String taskId = null;
                            if(clientProvideType == 2) {
                                List<Map<String, Object>> list = clientJdbcTemplate.queryForList(SqlManager.CLIEND_ID_CARD_INFO_BY_CARD_NO_SELECT, cardNo);
                                if(list != null && list.size() > 0) {
                                    taskId = list.get(0).get("task_id").toString();
                                }
                            }
                            insertCardNoMatchResult(cardNo, items[2], items[3], Long.parseLong(taskId));
                        }
                    }
                }

                if(StringUtils.isNotBlank(items[3])) {
                    // 插入全量表
                    log.debug("全量识别码: personId: " + items[0] + "  ,写入全量识别码数据表中");
                    dbManager.batchMapperInsert(items[0], items[1], items[2], items[3]);
                }
                // 生成替换后的节点文件
                content[0] = personId;
                content[1] = items[1];
                log.debug("全量识别码: personId: " + items[0] + "  ,写入到全量文件: " + outFile);
                csvWriter.writeRecord(content);
                count++;
                // 生成需要merge的点
                if(!items[0].equals(personId)) {
                    if(mergeCount == 0) {
                        mergeCsvWriter.writeRecord(mergeHeader);
                    }
                    mergeContent[0] = personId;
                    mergeContent[1] = items[0];
                    log.debug("生成merge节点文件: old节点Id" +  items[0] + "  ; merge节点Id:  " + personId);
                    mergeCsvWriter.writeRecord(mergeContent);
                    mergeCount++;
                }
            }
        }catch (Exception e) {
            log.error(e.getMessage());
            log.error("读取文件错误, 文件是: " + inFile);
            throw e;
        }finally {
            csvReader.close();
            csvWriter.close();
            mergeCsvWriter.close();
        }
        if(mergeCount > 0) {
            result.put("mergeFilePath", mergeFilePath);
        }
        result.put("outFile", outFile);
        // 删除v3文件
        new File(inFile).delete();
        return result;
    }

    /**
     * person_all_v3写入全量识别码
     * @param inFile
     */
    public void personMapToDb(String inFile) throws Exception{
        log.info("正在处理文件: " + inFile);
        CsvReader csvReader = new CsvReader(inFile, ',', Charset.forName("UTF-8"));
        try {
            csvReader.readHeaders();
            while (csvReader.readRecord()) {
                String[] items = csvReader.getValues();
                if(StringUtils.isNotBlank(items[3])) {
                    // 插入全量表
                    log.debug("全量识别码: personId: " + items[0] + "  ,写入全量识别码数据表中");
                    dbManager.batchMapperInsert(items[0], items[1], items[2], items[3]);
                }
            }
        }catch (Exception e) {
            log.error(e.getMessage());
            log.error("读取文件错误, 文件是: " + inFile);
            throw e;
        }finally {
            csvReader.close();
        }
        // 删除v3文件
        new File(inFile).delete();
    }

    /**
     * 客户身份证号列表处理
     * @param inFile
     * @param list
     * @return
     * @throws Exception
     */
    public Map<String, Object> personInfoChange(String inFile, List<String> list, Long taskId) throws Exception {
        Map<String, Object> result = new HashMap<>();
        if(StringUtils.isNotBlank(inFile)) {
            String fileName = new File(inFile).getName();
            String timeStamp = fileName.substring(fileName.lastIndexOf("_") + 1, fileName.lastIndexOf("."));
            result = writePersonInfoCsv(inFile, null, timeStamp, taskId);
        }else if(list != null && list.size() > 0) {
            Date date = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMddHHmmss");
            String timeStamp = sdf.format(date);
            result = writePersonInfoCsv(null, list, timeStamp, taskId);
        }
        return result;
    }

    /**
     * 将用户身份证号列表写csv文件
     * @param list
     * @return
     * @throws Exception
     */
    private Map<String, Object> writePersonInfoCsv(String inFile, List<String> list, String timeStamp, Long taskId) throws Exception{
        String outFileDir = FilenameUtils.concat(loadCsvBasePath, "ins");
        Map<String, Object> result = new HashMap<>();
        String updDirPath = FilenameUtils.concat(outFileDir, "n_person_info_upd");
        String mergeDirPath = FilenameUtils.concat(outFileDir, "n_person_info_merge");
        // 创建文件夹
        FileUtils.forceMkdir(new File(updDirPath));
        FileUtils.forceMkdir(new File(mergeDirPath));
        StringBuilder sb = new StringBuilder();
        sb.append("n_person_info_");
        // 一秒钟可能存在并发,文件可能被覆盖, 故加上毫秒值
        if(StringUtils.isNotBlank(inFile)) {
            sb.append(timeStamp).append(".csv");
        }else {
            if(taskId == null) {
                taskId = System.currentTimeMillis() % 1000;
            }
            sb.append(taskId).append("_").append(timeStamp).append(".csv");
        }
        String outName = sb.toString();
        String updFilePath = FilenameUtils.concat(updDirPath, "upd_" + outName);
        String mergeFilePath = FilenameUtils.concat(mergeDirPath, "merge_" + outName);
        CsvWriter updateCsvWriter = new CsvWriter(updFilePath, ',', Charset.forName("UTF-8"));
        CsvWriter mergeCsvWriter = new CsvWriter(mergeFilePath, ',', Charset.forName("UTF-8"));
        CsvReader csvReader = null;
        try {
            // 写入头
            String[] updateHeader = {"old_person_id", "new_person_id"};
            String[] mergeHeader = {"person_id", "merge_person_id"};
            // 写入正文
            Map<String, Long> countMap = new HashMap<>();
            countMap.put("updateCount", 0L);
            countMap.put("mergeCount", 0L);
            if(StringUtils.isNotBlank(inFile)) {
                log.info("正在处理文件: " + inFile);
                csvReader = new CsvReader(inFile, ',', Charset.forName("UTF-8"));
                csvReader.readHeaders();
                while (csvReader.readRecord()) {
                    String[] items = csvReader.getValues();
                    countMap = writeUpdateAndMergeCsv(items[0], countMap, updateCsvWriter, mergeCsvWriter, updateHeader, mergeHeader, taskId);
                }
            }else if(list != null && list.size() > 0) {
                for (String cardNo : list) {
                    countMap = writeUpdateAndMergeCsv(cardNo, countMap, updateCsvWriter, mergeCsvWriter, updateHeader, mergeHeader, taskId);
                }
            }
            if(countMap.get("updateCount") > 0) {
               result.put("updFilePath", updFilePath);
            }
            if(countMap.get("mergeCount") > 0) {
                result.put("mergeFilePath", mergeFilePath);
            }
        }catch (Exception e) {
            throw e;
        }finally {
            if(csvReader != null) csvReader.close();
            updateCsvWriter.close();
            mergeCsvWriter.close();
        }
        return result;
    }

    /**
     * 根据身份证号生成新的csv文件
     * @param cardNo
     * @param countMap
     * @param updateCsvWriter
     * @param mergeCsvWriter
     * @param updateHeader
     * @param mergeHeader
     * @throws Exception
     */
    private Map<String, Long> writeUpdateAndMergeCsv(String cardNo, Map<String, Long> countMap ,CsvWriter updateCsvWriter, CsvWriter mergeCsvWriter,
                                    String[] updateHeader, String[] mergeHeader, Long taskId) throws Exception {
        log.debug("客户提供的身份证号cardNo: " + cardNo);
        String zszhId = ChinaDaasDataEncoder.encode(cardNo, encodeVersion);
        List<Map<String, Object>> personIfoList = dbManager.personQueryByZszhId(zszhId);
        Long updateCount = countMap.get("updateCount");
        Long mergeCount = countMap.get("mergeCount");
        if(personIfoList != null && personIfoList.size() > 0){
            log.info("该身份证身份证号之前已经匹配过, cardNo: " + cardNo);
        }else {
            String[] updateContent = new String[2];
            String[] mergeContent = new String[2];
            // 写入正文
            List<Map<String, Object>> resultSet = dbManager.mapperByzsId(zszhId);
            for (int i = 0; i < resultSet.size(); i++) {
                Map<String, Object> map = resultSet.get(i);
                String personId = map.get("person_id").toString();
                if(i == 0) {
                    if(updateCount == 0) {
                        // 第一次写的话,会写头
                        updateCsvWriter.writeRecord(updateHeader);
                    }
                    updateContent[0] = personId;
                    if (personIdFlag == 3) {
                        personId = zszhId;
                    } else if (personIdFlag == 2) {
                        personId = map.get("cscs_id").toString();
                    }
                    updateContent[1] = personId;
                    // 写update的csv文件
                    log.debug("update: 身份证号: " + cardNo + " ,被写入到update的csv文件中.");
                    updateCsvWriter.writeRecord(updateContent);
                    updateCount++;
                }else {
                    if(mergeCount == 0) {
                        mergeCsvWriter.writeRecord(mergeHeader);
                    }
                    mergeContent[0] = resultSet.get(0).get("person_id").toString();
                    mergeContent[1] = personId;
                    mergeCsvWriter.writeRecord(mergeContent);                    mergeCount++;
                }
                // 同步工商数据
                gdsSyncService.updateGDS(map.get("person_id").toString(), map.get("person_nm").toString(),
                        map.get("cscs_id").toString(), map.get("zszh_id").toString());
            }
            // 保存客户信息表
            dbManager.personInsert(cardNo, zszhId);
            // 匹配成功结果记录入库
            if(resultSet != null && resultSet.size() > 0) {
                String cscsId = resultSet.get(0).get("cscs_id").toString();
                insertCardNoMatchResult(cardNo, cscsId, zszhId, taskId);
                // 匹配成功结果记录入库
                if(clientProvideType == 2 && resultSet != null && resultSet.size() > 0) {
                    // 匹配成功的身份证号删除
                    if(idcardDeleteEnable) {
                        clientJdbcTemplate.update(SqlManager.CLIEND_ID_CARD_INFO_BY_CARD_NO_DELETE, cardNo);
                    }
                }
            }
        }
            countMap.put("updateCount", updateCount);
            countMap.put("mergeCount", mergeCount);
            return countMap;
    }

    /**
     * 生成的新文件放在新目录下, 将源文件删除
     * @param inFile
     * @param outFile
     * @param indexArray
     * @return
     * @throws Exception
     */
    public void updateCsvColumnsToNewDir(String inFile, String outFile, int[] indexArray) throws Exception {
        log.info("正在处理文件: " + inFile);
        FileUtils.forceMkdir(new File(new File(outFile).getParent()));
        CsvReader csvReader = new CsvReader(inFile, ',', Charset.forName("UTF-8"));
        CsvWriter csvWriter = new CsvWriter(outFile, ',', Charset.forName("UTF-8"));
        try {
            readAndWriteCsv(csvReader, csvWriter, indexArray);
        } catch (Exception ex) {
            log.error("error: 文件生成失败!!" + inFile);
        }finally {
            csvReader.close();
            csvWriter.close();
        }
        // 删除文件
        new File(inFile).delete();
    }

    /**
     * 替换csv文件的列(生成的新文件和原文件在同一目录下,生成后将原文件删除, 新文件重新命名原文件)
     * @param inFile
     * @param indexArray (要替换的多列的索引)
     * @return
     */
    public String updateCsvColumns(String inFile, int[] indexArray) throws Exception{
        log.info("正在处理文件: " + inFile);
        String outFile = inFile.concat(".temp");
        FileUtils.forceMkdir(new File(new File(outFile).getParent()));
        CsvReader csvReader = new CsvReader(inFile, ',', Charset.forName("UTF-8"));
        CsvWriter csvWriter = new CsvWriter(outFile, ',', Charset.forName("UTF-8"));
        try {
            readAndWriteCsv(csvReader, csvWriter, indexArray);
        } catch (Exception ex) {
            // 如果生成文件报错, 删除生成的文件
            FileUtils.forceDelete(new File(outFile));
            log.error("error: 文件转换失败!!" + inFile);
        }finally {
            csvWriter.close();
            csvReader.close();
        }
        // 删除原文件
        new File(inFile).delete();
        // 新文件名更改为原文件名
        new File(outFile).renameTo(new File(inFile));
        return outFile;
    }

    /**
     * 生成新的csv逻辑
     * @param csvReader 读对象
     * @param csvWriter 写对象
     * @param indexArray 要替换的列的索引的数组
     * @throws Exception
     */
    private void readAndWriteCsv(CsvReader csvReader, CsvWriter csvWriter, int[] indexArray) throws Exception{
        long count = 0;
        csvReader.readHeaders();
        while (csvReader.readRecord()) {
            if(count == 0) {
                csvWriter.writeRecord(csvReader.getHeaders());
            }
            String[] items = csvReader.getValues();
            for (int index : indexArray) {
                List<Map<String, Object>> list = dbManager.mapperByPersonId(items[index]);
                if (list != null && list.size() > 0) {
                    Map<String, Object> map = list.get(0);
                    if(graphType == 2) {
                        String zszhId = map.get("zszh_id") != null ? map.get("zszh_id").toString() : null;
                        if (StringUtils.isNotBlank(zszhId)) {
                            List<Map<String, Object>> zszhIdList = dbManager.personQueryByZszhId(zszhId);
                            if (zszhIdList != null && zszhIdList.size() > 0) {
                                if (personIdFlag == 3) {
                                    items[index] = zszhId;
                                } else if (personIdFlag == 2) {
                                    if(map.get("cscs_id") != null)  items[index] = map.get("cscs_id").toString();
                                }
                            }
                        }
                    }else {
                        if (personIdFlag == 3) {
                            if(map.get("zszh_id") != null) items[index] = map.get("zszh_id").toString();
                        } else if (personIdFlag == 2) {
                            if(map.get("cscs_id") != null) items[index] =  map.get("cscs_id").toString();
                        }
                    }
                }
            }
            csvWriter.writeRecord(items);
            count++;
        }
    }

    /**
     * 身份证号匹配结果入库
     * @param cardNo
     * @param cscsId
     * @param zszhId
     * @param taskId
     */
    private void insertCardNoMatchResult(String cardNo, String cscsId, String zszhId, Long taskId) {
        List<Map<String, Object>> list = clientJdbcTemplate.queryForList(SqlManager.CLIEND_ID_CARD_MATCH_RESULT_SELECT, cardNo);
        if(list == null || list.size() == 0) {
            String updateSql = "mysql".equalsIgnoreCase(clientDataSource) ? SqlManager.MYSQL_CLIEND_ID_CARD_MATCH_RESULT_INSERT : SqlManager.ORACLE_CLIEND_ID_CARD_MATCH_RESULT_INSERT;
            if(businessDataFlag == 1) {
                // 匹配中证的id
                clientJdbcTemplate.update(updateSql, taskId, cardNo, cscsId, null);
            }else if(businessDataFlag == 2) {
                // 匹配中证id + 中数id
                clientJdbcTemplate.update(updateSql, taskId, cardNo, cscsId, zszhId);
            }
        }
    }
}
