package com.chinacscs.bg.graph.updater.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.chinacscs.bg.graph.updater.entity.BasicOutDto;
import com.chinacscs.bg.graph.updater.sandbox.DbManager;
import com.chinacscs.bg.graph.updater.service.ChangeSetService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * desc: 工商数据的controller类
 * Author:   wangpengchao
 * Date:     2019/5/7-15:44
 */
@RestController
@RequestMapping(value = "/gds")
@Slf4j
public class GdsSyncController {
    @Autowired
    private ChangeSetService changeSetService;
    @Autowired
    private DbManager dbManager;

    @RequestMapping(value = "/client/save")
    public BasicOutDto saveClientInfo(@RequestParam(value = "idCard") String idCard) {
        BasicOutDto basicOutDto = new BasicOutDto();
        try {
            JSONArray jsonArray = JSONArray.parseArray(idCard);
            List<String> list = new ArrayList<>();
            for (int i = 0; i < jsonArray.size(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String cardNo = jsonObject.get("cardNo").toString();
                list.add(cardNo);
            }

            // 根据用户列表生成新的update和merge的文件
            changeSetService.executePersonInfoFromHttp(null, list);
            log.info("接口获取身份证列表执行完成, idCard: " + idCard);
            basicOutDto.setCode(200);
            basicOutDto.setMsg("操作成功!");
        } catch (Exception e) {
            basicOutDto.setCode(400);
            basicOutDto.setMsg("操作失败!");
            log.error(e.getMessage());
        }
        return basicOutDto;
    }

    @RequestMapping(value = "/client/task/redo")
    public BasicOutDto redoExecuteClientTask(@RequestParam(value = "taskId") Long taskId) {
        BasicOutDto basicOutDto = new BasicOutDto();
        try {
            changeSetService.executePersonInfoFromHttp(taskId, null);
            log.info("从数据库获取身份证列表执行完成, taskId: " + taskId);
            basicOutDto.setCode(200);
            basicOutDto.setMsg("操作成功!");
        } catch (Exception e) {
            basicOutDto.setCode(400);
            basicOutDto.setMsg("操作失败!");
            log.error(e.getMessage());
        }
        return basicOutDto;
    }

    /**
     * 初始化h2数据库的文件
     * @param filePath v3文件路径
     */
    @RequestMapping(value = "/init/full/v3")
    public void redoExecuteClientTask(@RequestParam(value = "filePath", required = false) String filePath) {
        try {
            long startTime = System.currentTimeMillis();
            log.info("全量识别码数据库初始化开始, 开始时间: " + startTime);
            dbManager.initTable(filePath);
            log.info("全量识别码数据库初始化完成, 用时: " + (System.currentTimeMillis() - startTime) + "ms");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}