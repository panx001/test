package com.chinacscs.bg.graph.updater;

import com.chinacscs.bg.graph.updater.entity.CsvConfig;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.neo4j.driver.v1.Statement;

import java.util.HashMap;
import java.util.Map;

/**
 * CsvFile
 */
@Data
@AllArgsConstructor
public class CsvFile {

    CsvConfig config;

    String filePath;

    String serverPath;

    public Statement getStatement(Boolean httpLoad) {
        if(config == null) {
            return null;
        }
        if(StringUtils.isBlank(serverPath)) {
            return null;
        }
        String cypher = "";
        if(httpLoad) {
            cypher = config.getStatement().text().replace("file:///csv_file_path", serverPath);
        } else {
            //windows环境下转义两次路径
            cypher = config.getStatement().text().replace("csv_file_path", filePath.replace("\\", "\\\\\\\\"));
        }
        Map<String, Object> valueMap = new HashMap<>();
        valueMap.put("batchSize", config.batchSize);
        valueMap.put("parallel", config.parallel);
        return new Statement(cypher).withParameters(valueMap);
    }
}