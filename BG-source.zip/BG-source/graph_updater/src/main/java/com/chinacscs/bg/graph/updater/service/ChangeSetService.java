package com.chinacscs.bg.graph.updater.service;

import com.chinacscs.bg.graph.updater.ChangeSet;
import com.chinacscs.bg.graph.updater.CsvFile;
import com.chinacscs.bg.graph.updater.EmailContentBuilder;
import com.chinacscs.bg.graph.updater.entity.CsvConfig;
import com.chinacscs.bg.graph.updater.sandbox.FileChange;
import com.chinacscs.bg.graph.updater.sandbox.SqlManager;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.nio.file.Path;
import java.text.MessageFormat;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.LongStream;
import java.util.stream.Stream;

/**
 * ChangeSetService
 */
@Service
@Slf4j
public class ChangeSetService {

    @Value("${app.loadCsvBasePath}")
    private String loadCsvBasePath;
    @Value("${app.server.loadCsvBasePath}")
    private String severPath;
    @Value("${server.port}")
    private String port;
    @Value("${app.updateFrom}")
    private Long updateFrom;
    @Value("${app.sandbox.client.idcard.path:}")
    private String clientIdCardPath;
    @Value("${app.sandbox.client.provide.type}")
    private Integer clientProvideType;
    @Value("${app.neo4j.update.enable}")
    private boolean neo4jUpdateFlag;
    @Autowired(required = false)
    private FileChange fileChange;
    @Autowired(required = false)
    private CsvLoadService csvLoadService;
    @Autowired
    private EmailService emailService;
    @Autowired(required = false)
    @Qualifier("clientJdbcTemplate")
    private JdbcTemplate clientJdbcTemplate;
    @Value("${app.graph.product.type}")
    private Integer graphType;

    String getLoadedDir() {
        return FilenameUtils.concat(loadCsvBasePath, "loaded");
    }

    public void load(ChangeSet changeSet) throws Exception {
        EmailContentBuilder contentBuilder = new EmailContentBuilder();
        contentBuilder.start(changeSet);
        // 标准图谱和沙盒图谱, 处理csv文件, 简版图谱不处理csv文件
        handleCsv(changeSet, contentBuilder);

        // 是否执行更新neo4j的操作
        if (neo4jUpdateFlag) {
            updateNeo4j(changeSet, contentBuilder);
        }
        // 写已加载的文件
            log.info(MessageFormat.format("=Finish load ChangeSet: {0}", changeSet));
        writeLoadedFile(changeSet.getTo());

        // 发送邮件
        contentBuilder.end(changeSet);
        sendEmail(contentBuilder);
    }

    /**
     * 发送邮件
     */
    private void sendEmail(EmailContentBuilder contentBuilder) {
        try {
            emailService.send(contentBuilder.build());
        } catch (Exception e) {
            log.error("构建邮件失败", e);
        }
    }

    /**
     * 执行更新neo4j
     */
    private void updateNeo4j(ChangeSet changeSet, EmailContentBuilder contentBuilder) throws Exception {
        log.info("更新图谱开始....");
        // 将csv文件排序
        sortCsv(changeSet);
        log.info(MessageFormat.format("=Begin load ChangeSet: {0}", changeSet));
        for (CsvFile csvFile : changeSet.getCsvFiles()) {
            try {
                if (csvFile.getConfig() == null) {
                    log.info("此csv文件没有config, 文件路径是: " + csvFile.getFilePath());
                    continue;
                }
                contentBuilder.start(csvFile);
                log.info(MessageFormat.format("-Begin load csv: {0}", csvFile.getFilePath()));
                log.info("csv detail: ", csvFile);
                csvLoadService.load(csvFile);
                log.info(MessageFormat.format("-Finish load csv: {0}", csvFile.getFilePath()));
                contentBuilder.end(csvFile);
                log.info("更新图谱结束....");
            }catch (Exception e) {
                contentBuilder.end(csvFile);
                log.info("导入文件失败, 失败文件是: " + csvFile.getFilePath());
                emailService.send(contentBuilder.buildErrorEmailMessage(csvFile, e.toString()));
                throw e;
            }
        }
    }

    /**
     * 提供全量识别码处理csv文件
     * @param changeSet
     * @param contentBuilder
     * @throws Exception
     */
    private void handleCsv(ChangeSet changeSet, EmailContentBuilder contentBuilder) throws Exception {
        if (graphType == 1) {
            // 全量识别码入库
            personMapToDb(changeSet);
            // 处理l_relatives 和 l_work_pleg关系
            handleRelativesAndWorkPleg(changeSet);
        }else if(graphType == 2) {
            contentBuilder.startSandbox();
            log.info("沙盒方案执行了....");
            try {
                handleSandbox(changeSet);
            }catch (Exception e) {
                log.info("沙盒方案执行失败....");
                contentBuilder.endSandbox();
                emailService.send(contentBuilder.buildErrorEmailMessage(null, e.toString()));
                throw e;
            }
            log.info("沙盒方案执行结束....");
            contentBuilder.endSandbox();
        }
    }

    /**
     *  处理person_all_v3写入全量识别码(不生成update和merge文件)
     * @param changeSet
     */
    private void personMapToDb(ChangeSet changeSet) throws Exception{
        // n_person_all_v3
        List<CsvFile> personAllV3List = changeSet.getCsvFiles().stream()
                .filter(file -> file.getFilePath().contains("n_person_all_v3")).collect(Collectors.toList());
        // 全量识别码: 生成新的全量识别码的csv文件
        if(personAllV3List != null && personAllV3List.size() > 0) {
            for (CsvFile items : personAllV3List) {
                fileChange.personMapToDb(items.getFilePath());
            }
        }
    }

    /**
     * 处理l_relatives 和 l_work_pleg
     * @param changeSet
     * @throws Exception
     */
    private void handleRelativesAndWorkPleg(ChangeSet changeSet) throws Exception {
        // 处理l_relatives 亲属关系
        updateCsvColumns(changeSet, "l_relatives", new int[]{0, 1});

        // 处理l_work_pleg关系
        updateCsvColumns(changeSet, "l_work_pleg", new int[]{0});
    }

    /**
     * 处理v2版本关系, 并替换原来的文件
     * @param changeSet
     * @param csvFileName
     * @param indexArray
     * @throws Exception
     */
    private void updateCsvColumns(ChangeSet changeSet, String csvFileName, int[] indexArray) throws Exception {
        List<CsvFile> list = changeSet.getCsvFiles().stream()
                .filter(file -> file.getFilePath().contains(csvFileName)).collect(Collectors.toList());
        if(list != null && list.size() > 0) {
            for (CsvFile items : list) {
                fileChange.updateCsvColumns(items.getFilePath(), indexArray);
            }
        }
    }

    /**
     * 处理n_person_all_v3文件
     * @param changeSet
     * @throws Exception
     */
    private void handlePersonAllV3Csv(ChangeSet changeSet) throws Exception{
        List<CsvFile> fileList = changeSet.getCsvFiles();
        // n_person_all_v3
        List<CsvFile> personAllV3List = changeSet.getCsvFiles().stream()
                .filter(file -> file.getFilePath().contains("n_person_all_v3")).collect(Collectors.toList());
        // 全量识别码: 生成新的全量识别码的csv文件
        if(personAllV3List != null && personAllV3List.size() > 0) {
            for (CsvFile items : personAllV3List) {
                Map<String, Object> map = fileChange.personMapperChange(items.getFilePath());
                fileList.remove(items);
                // 新生成的merge文件放入changeSet集合中
                addNewCsvToChangeSet(map, changeSet);
            }
        }
    }

    /**
     * csv排序
     * @param changeSet
     */
    private void sortCsv(ChangeSet changeSet) {
        Collections.sort(changeSet.getCsvFiles(), new Comparator<CsvFile>() {
            public int compare(CsvFile o1, CsvFile o2) {
                int o1Priority = o1.getConfig() != null ? o1.getConfig().priority : 0;
                int o2Priority = o2.getConfig() != null ? o2.getConfig().priority : 0;
                if (o1Priority == o2Priority) {
                    File file1 = new File(o1.getFilePath()).getParentFile();
                    File file2 = new File(o2.getFilePath()).getParentFile();
                    if (file1.toString().equals(file2.toString())) {
                        return (int) (extractTime(o1.getFilePath()) - extractTime(o2.getFilePath()));
                    }
                    return o1Priority - o2Priority;
                }
                return o1Priority - o2Priority;
            }
        });
    }

    /**
     * 加载当前已经有finish文件的所有变更
     *
     * @throws Exception
     */
    public void loadAll() throws Exception {
        long lastFinishTime = getMaxLoadedFromFile();
        long loadedTime = lastFinishTime == 0 ? updateFrom : lastFinishTime;
        LongStream finishes = getFinishTimeNotLoaded(loadedTime).sorted();
        for (long finishTime : finishes.toArray()) {
            ChangeSet changeSet = getChangeSet(loadedTime, finishTime);
            log.info("增量更新程序开始,时间区间是From:" + loadedTime + " ,To: " + finishTime);
            load(changeSet);
            loadedTime = finishTime;
        }
    }

    /**
     * 沙盒处理逻辑
     *
     * @param changeSet
     * @throws Exception
     */
    private void handleSandbox(ChangeSet changeSet) throws Exception {
        // 处理v3文件生成新的文件并写入全量识别码
        handlePersonAllV3Csv(changeSet);
        // 客户信息表: 更新客户信息表并生成update节点和Merge节点的csv文件
        autoHandlePersonInfo(changeSet);
        // 处理 l_person_sharehd_v2文件
        updateCsvColumnsToNewDir(changeSet, "l_person_sharehd_v2", "l_person_sharehd", new int[]{0});
        // 处理 l_work_executive_v2文件
        updateCsvColumnsToNewDir(changeSet, "l_work_executive_v2", "l_work_executive", new int[]{0});
        // 处理 l_manage_level_v2文件
        updateCsvColumnsToNewDir(changeSet, "l_managelevel_v2", "l_managelevel", new int[]{1});
        // 处理l_relatives 和 l_work_pleg关系
        handleRelativesAndWorkPleg(changeSet);
    }

    private void writeLoadedFile(Long loadedTime) throws IOException {
        new File(getLoadedDir(), String.format("%s.finish", loadedTime)).createNewFile();
    }


    /**
     * 处理v2版本关系生成新的不带v2的关系
     * @param changeSet
     * @param oldCsvFileName
     * @param newCsvFileName
     * @param indexArray
     * @throws Exception
     */
    private void updateCsvColumnsToNewDir(ChangeSet changeSet, String oldCsvFileName, String newCsvFileName, int[] indexArray) throws Exception{
        List<CsvFile> fileList = changeSet.getCsvFiles();
        // 处理 l_manage_level_v2文件
        List<CsvFile> list = changeSet.getCsvFiles().stream()
                .filter(file -> file.getFilePath().contains(oldCsvFileName)).collect(Collectors.toList());
        if(list != null && list.size() > 0) {
            for (CsvFile items : list) {
                String inFile = items.getFilePath();
                String outFile = inFile.replace(oldCsvFileName, newCsvFileName);
                fileChange.updateCsvColumnsToNewDir(inFile, outFile, indexArray);
                // 移除v2的csv文件
                fileList.remove(items);
                Map<String, Object> map = new HashMap();
                map.put("outFile", outFile);
                // 生成新的csv文件并放入changeset中
                addNewCsvToChangeSet(map, changeSet);
            }
        }
    }

    /**
     * 根据客户身份证信息生成合并的节点和merge的csv文件(读csv文件)
     * 
     * @param changeSet
     * @return
     * @throws Exception
     */
    public void autoHandlePersonInfo(ChangeSet changeSet) throws Exception {
        if(clientProvideType == 0) {
            Long loadedTime = changeSet.getFrom();
            Long finishTime = changeSet.getTo();
            File clientDir = new File(clientIdCardPath);
            FileUtils.forceMkdir(clientDir);
            List<File> listFiles = getCardNoFileListByNameFlag(loadedTime, finishTime);
            for (File items : listFiles) {
                Map<String, Object> map = fileChange.personInfoChange(items.getAbsolutePath(), null, null);
                // 将生成的update节点和Merge节点的csv文件放入到chageSet中
                addNewCsvToChangeSet(map, changeSet);
                // 将该csv文件名修改为已完成
                writeCsvNameToFinish(clientIdCardPath, items);
                log.info("该客户身份证列表已经生成完成," + items.getPath());
            }
        }else if(clientProvideType == 2) {
            executeClientTask(changeSet, null);
        }
    }

    /**
     *  执行处理客户身份证信息的任务(身份证号来自数据库)
     */
    public void executeClientTask(ChangeSet changeSet, Long taskId)  throws Exception{
        if(taskId != null) {
            writePersonInfoCsvFromDb(changeSet, taskId);
        }else {
            // 查询未处理的的任务列表
            List<Map<String, Object>> unDealTasks = clientJdbcTemplate.queryForList(SqlManager.CLIEND_TASK_STATUS_SELECT, 0);
            for (Map<String, Object> unDealTask : unDealTasks) {
                if(unDealTask.get("id") != null && StringUtils.isNotBlank(unDealTask.get("id").toString())) {
                    taskId = Long.parseLong(unDealTask.get("id").toString());
                    writePersonInfoCsvFromDb(changeSet, taskId);
                }
            }
        }
    }

    /**
     * 从数据库读身份证列表写成新的csv文件放入changeSet中
     * @throws Exception
     */
    private void writePersonInfoCsvFromDb(ChangeSet changeSet, Long taskId) throws Exception{
        // 更改为处理中
        clientJdbcTemplate.update(SqlManager.CLIEND_TASK_STATUS_UPDATE, 1, taskId);
        try {
            List<Map<String, Object>> cardNosList = clientJdbcTemplate.queryForList(SqlManager.CLIEND_ID_CARD_INFO_BY_TASK_ID_SELECT, taskId);
            if(cardNosList != null && cardNosList.size() > 0) {
                List<String> list = new ArrayList<>();
                cardNosList.stream().forEach(map -> list.add(map.get("card_no").toString()));
                Map<String, Object> map = fileChange.personInfoChange(null, list, taskId);
                // 将生成的update节点和Merge节点的csv文件放入到chageSet中
                addNewCsvToChangeSet(map, changeSet);
            }
        }catch (Exception e) {
            log.info("处理客户身份证号信息错误, 任务的taskId是: " +  taskId);
            // 如果处理失败将处理状态改为
            clientJdbcTemplate.update(SqlManager.CLIEND_TASK_STATUS_UPDATE, 0, taskId);
            throw e;
        }
        // 更改为已完成
        clientJdbcTemplate.update(SqlManager.CLIEND_TASK_STATUS_UPDATE, 2, taskId);
    }

    /**
     * 过滤文件
     * 
     * @param fileList
     * @param deleteFileList
     * @throws Exception
     */
    private void filterFile(List<CsvFile> fileList, String[] deleteFileList) throws Exception {
        for (String deleteFile : deleteFileList) {
            fileList.stream().filter(file -> {
                Path path = new File(file.getFilePath()).getParentFile().toPath();
                String dri = path.subpath(path.getNameCount() - 1, path.getNameCount()).toString();
                return deleteFile.equalsIgnoreCase(dri);
            }).forEach(file -> new File(file.getFilePath()).delete());

            fileList.removeIf(file -> {
                Path path = new File(file.getFilePath()).getParentFile().toPath();
                String dri = path.subpath(path.getNameCount() - 1, path.getNameCount()).toString();
                return deleteFile.equalsIgnoreCase(dri);
            });
        }
    }

    /**
     * 沙盒新生成的文件放入到changeSet集合中
     * 
     * @param map
     * @param changeSet
     */
    private void addNewCsvToChangeSet(Map<String, Object> map, ChangeSet changeSet) {
        if (map != null) {
            List<CsvFile> changeCsvFiles = changeSet.getCsvFiles();
            if(changeCsvFiles == null) {
                changeCsvFiles = new ArrayList();
            }
            if (map.get("updFilePath") != null) {
                String updFilePath = map.get("updFilePath").toString();
                if(changeCsvFiles.stream().noneMatch(csvFile -> updFilePath.equals(csvFile.getServerPath()))) {
                    CsvFile updCsvFile = createCsvFile(new File(updFilePath));
                    changeCsvFiles.add(updCsvFile);
                }
            }
            if (map.get("mergeFilePath") != null) {
                String mergeFilePath = map.get("mergeFilePath").toString();
                if(changeCsvFiles.stream().noneMatch(csvFile -> mergeFilePath.equals(csvFile.getServerPath()))) {
                    CsvFile mergeCsvFile = createCsvFile(new File(map.get("mergeFilePath").toString()));
                    changeCsvFiles.add(mergeCsvFile);
                }
            }
            if (map.get("outFile") != null) {
                String outFile = map.get("outFile").toString();
                if(changeCsvFiles.stream().noneMatch(csvFile -> outFile.equals(csvFile.getServerPath()))) {
                    CsvFile mergeCsvFile = createCsvFile(new File(map.get("outFile").toString()));
                    changeCsvFiles.add(mergeCsvFile);
                }
            }
            changeSet.setCsvFiles(changeCsvFiles);
        }
    }

    /**
     * 获取一个ChangeSet
     *
     * @param from 文件最小timestamp
     * @param to   文件最大timestamp
     * @return 包含在from和to之间的ChangeSet
     */
    private ChangeSet getChangeSet(long from, long to) {
        ChangeSet changeSet = new ChangeSet();
        changeSet.setFrom(from);
        changeSet.setTo(to);

        // TODO: pre & post cypher scripts here

        List<CsvFile> files = Stream.of("ins", "del")
                .flatMap(folder -> FileUtils
                        .listFiles(FileUtils.getFile(loadCsvBasePath, folder), new String[] { "csv" }, true).stream())
                .filter(file -> {
                    Long fileTime = extractTime(file.getName());
                    return fileTime > from && fileTime <= to;
                }).filter(file -> file.length() > 0).map(this::createCsvFile).collect(Collectors.toList());
        files.removeAll(Collections.singleton(null));
        changeSet.setCsvFiles(files);
        return changeSet;
    }

    /**
     * 获取身份证号的csv文件列表(根据时间戳筛选)
     *
     * @param from 文件最小timestamp
     * @param to   文件最大timestamp
     * @return 包含在from和to之间的文件列表
     */
    private List<File> getCardNoFileListByTime(Long from, Long to) throws Exception {
        File clientDir = new File(clientIdCardPath);
        FileUtils.forceMkdir(clientDir);
        return Stream.of(clientDir.listFiles()).filter(file -> {
            Long fileTime = extractTime(file.getName());
            return fileTime > from && fileTime <= to;
        }).collect(Collectors.toList());
    }

    /**
     * 获取身份证号的csv文件列表(根据finish完成标志筛选)
     * 
     * @throws Exception
     * @return
     */
    private List<File> getCardNoFileListByNameFlag(Long from, Long to) throws Exception {
        File clientDir = new File(clientIdCardPath);
        FileUtils.forceMkdir(clientDir);
        return Stream.of(clientDir.listFiles((dir, name) -> !name.startsWith("finish_"))).filter(file -> {
            Long fileTime = extractTime(file.getName());
            return fileTime > from && fileTime <= to;
        }).collect(Collectors.toList());
    }

    /**
     * 客户提供的身份证列表文件读完后, 修改为已读文件
     */
    private void writeCsvNameToFinish(String clientFileDir, File file) throws Exception {
        String newFileName = "finish_" + file.getName();
        File newFile = new File(FilenameUtils.concat(clientFileDir, newFileName));
        if (newFile.exists()) {
            FileUtils.forceDelete(newFile);
        }
        FileUtils.moveFile(file, newFile);
    }

    private Long extractTime(String fileName) {
        try {
            return Long.parseLong(fileName.substring(fileName.lastIndexOf("_") + 1, fileName.lastIndexOf(".")));
        } catch (Exception ex) {
            log.debug("忽略文件：{}", fileName);
            return -1L;
        }
    }

    private LongStream getFinishTimeNotLoaded(Long maxLoaded) throws IOException {
        File file = FileUtils.getFile(FilenameUtils.concat(loadCsvBasePath, "finish"));
        FileUtils.forceMkdir(file);
        return Arrays.stream(file.listFiles((dir, name) -> name.startsWith("finish.") || name.endsWith(".finish")))
                .map(File::getName).map(fileName -> fileName.replaceAll("\\.*finish\\.*", ""))
                .mapToLong(Long::parseLong).filter(it -> it > maxLoaded);
    }

    private Long getMaxLoadedFromFile() throws IOException {
        File file = FileUtils.getFile(getLoadedDir());
        FileUtils.forceMkdir(file);
        return Arrays.stream(file.listFiles((dir, name) -> name.startsWith("finish.") || name.endsWith(".finish")))
                .map(File::getName).map(fileName -> fileName.replaceAll("\\.*finish\\.*", ""))
                .mapToLong(Long::parseLong).max().orElse(0);
    }

    /**
     * create csvfile instance
     */
    public CsvFile createCsvFile(File file) {
        Path path = file.toPath();
        CsvConfig config = CsvConfig.get(path.subpath(path.getNameCount() - 3, path.getNameCount() - 1).toString());
        String filePath = file.getAbsolutePath();
        String serverPath = "http://" + getIP() + ":" + port +"/"+ filePath.replace(loadCsvBasePath, severPath).replaceAll("\\\\","/");
        return new CsvFile(config, filePath, serverPath);
    }

    /**
     * 处理客户身份证信息(身份证号列表从数据库库读取的方式)
     * @param taskId
     * @throws Exception
     */
    public void executePersonInfoFromHttp(Long taskId, List<String> list) throws Exception{
        log.info("手动触发获取客户身份证列表");
        if(graphType == 2 && (clientProvideType == 1 || clientProvideType == 2)) {
            ChangeSet changeSet = new ChangeSet();
            changeSet.setCsvFiles(new ArrayList());
            changeSet.setFrom(System.currentTimeMillis());
            if(clientProvideType == 1) {
                Map<String, Object> map = fileChange.personInfoChange(null, list, null);
                addNewCsvToChangeSet(map, changeSet);
            }else if(clientProvideType == 2) {
                executeClientTask(changeSet, taskId);
            }
            changeSet.setTo(System.currentTimeMillis());
            // 是否执行更新neo4j的操作
            if (neo4jUpdateFlag) {
                EmailContentBuilder contentBuilder = new EmailContentBuilder();
                contentBuilder.startSandbox();
                updateNeo4j(changeSet, contentBuilder);
                // 导入成功后删除
                List<CsvFile> csvFiles = changeSet.getCsvFiles();
                for (CsvFile csvFile : csvFiles) {
                    FileUtils.forceDelete(new File(csvFile.getServerPath()));
                }
            }
        }
    }

    private String getIP() {
        try {
            Enumeration<NetworkInterface> allNetInterfaces = NetworkInterface.getNetworkInterfaces();
            while (allNetInterfaces.hasMoreElements()) {
                NetworkInterface netInterface = (NetworkInterface) allNetInterfaces.nextElement();
                Enumeration<InetAddress> addresses = netInterface.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    InetAddress ip = (InetAddress) addresses.nextElement();
                    if (ip != null && ip instanceof Inet4Address
                            && !ip.isLoopbackAddress() //loopback地址即本机地址，IPv4的loopback范围是127.0.0.0 ~ 127.255.255.255
                            && ip.getHostAddress().indexOf(":") == -1) {
                        return ip.getHostAddress();
                    }
                }
            }
        } catch (Exception ex){
        }
        return "0.0.0.0";
    }
}