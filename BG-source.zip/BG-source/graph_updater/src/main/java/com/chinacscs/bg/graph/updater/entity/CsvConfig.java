package com.chinacscs.bg.graph.updater.entity;

import com.chinacscs.bg.graph.updater.graphload.CqlManager;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.neo4j.driver.v1.Statement;
import org.neo4j.driver.v1.Values;
import org.yaml.snakeyaml.Yaml;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * CsvConfig csv加载的配置文件
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CsvConfig {

    /**
     * 去除timestamp的 csv 文件路径
     */
    public String generalPath;

    /**
     * LOAD CSV cypher
     */
    public String cypher;

    public int batchSize;

    public boolean parallel;

    /**
     * 处理的优先级
     */
    public int priority;

    public Statement getStatement() {
        return new Statement(cypher, Values.parameters("batchSize", batchSize, "parallel", parallel));
    }

    public static CsvConfig get(String path) {
        //windows环境路径转换
        return configs.get(path.replace("\\", "/"));
    }

    public static Map<String, CsvConfig> configs;

    static {
        Yaml yaml = new Yaml();
        configs = Stream
                .concat(CqlManager.cqlDelMapper.entrySet().stream().map(it -> new CsvConfig("del/" + it.getKey(), it.getValue(),
                                1000, false, CqlManager.getPriority("del",it.getKey()))),
                        CqlManager.cqlInsMapper.entrySet().stream().map(it -> new CsvConfig("ins/" + it.getKey(), it.getValue(),
                                1000, false, CqlManager.getPriority("ins",it.getKey()))))
                .collect(Collectors.toMap(CsvConfig::getGeneralPath, Function.identity()));
        Path configPath = Paths.get("csv.yaml");
        try {
            if (Files.exists(configPath)) {
                configs = yaml.load(Files.newBufferedReader(configPath));
            } else {
                yaml.dump(configs, Files.newBufferedWriter(configPath, StandardOpenOption.CREATE));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}