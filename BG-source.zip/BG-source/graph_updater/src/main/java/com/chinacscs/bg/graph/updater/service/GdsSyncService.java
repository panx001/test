package com.chinacscs.bg.graph.updater.service;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;

/**
 * desc: GDS数据库更新servcie
 * Author:   wangpengchao
 * Date:     2019/4/22-9:57
 */
@ConditionalOnProperty(name = {"app.graph.product.type"}, havingValue = "2")
public interface GdsSyncService {
    /**
     * 批量更新GDS库中的工商数据
     * @param
     */
    void updateGDS(String personId, String personNm, String cscsId, String zszhId) throws Exception;
}
