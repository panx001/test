package com.chinacscs.bg.graph.updater.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

/**
 * des: JdbcTemplate数据源的配置类
 * auth: wangpengchao
 */
@Configuration
public class ClientDataSourceConfig {

    @Value("${spring.datasource.client.driver-class-name}")
    private String CLIENT_DRIVER;
    @Value("${spring.datasource.client.jdbcUrl}")
    private String CLIENT_URL;
    @Value("${spring.datasource.client.username}")
    private String CLIENT_USERNMAE;
    @Value("${spring.datasource.client.password}")
    private String CLIENT_PASSWORD;

    @Bean(name = "clientDataSource")
    public DataSource ClientDataSource() {
        DataSourceBuilder<?> dataSourceBuilder = DataSourceBuilder
                .create()
                .driverClassName(CLIENT_DRIVER)
                .url(CLIENT_URL)
                .username(CLIENT_USERNMAE)
                .password(CLIENT_PASSWORD);
        return dataSourceBuilder.build();
    }

    @Bean(name = "clientJdbcTemplate")
    public JdbcTemplate jdbcTemplate(
            @Qualifier("clientDataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }
}
