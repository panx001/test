package com.chinacscs.bg.graph.updater;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.LinkedList;

/**
 * EmailContentBuilder 用于构建邮件通知
 */
public class EmailContentBuilder {

    public EmailContentBuilder() {
    }

    private TimedChangeSet timedChangeSet;
    private LinkedList<TimedCsvFile> timedCsvFiles = new LinkedList<>();

    private LocalDateTime sbStart;
    private LocalDateTime sbEnd;
    private boolean sanBoxCalled = false;

    public void start(ChangeSet changeSet) {
        timedChangeSet = new TimedChangeSet();
        timedChangeSet.changeSet = changeSet;
        timedChangeSet.startTime = LocalDateTime.now();
    }

    public void end(ChangeSet changeSet) {
        timedChangeSet.endTime = LocalDateTime.now();
    }

    public void start(CsvFile csvFile) {
        TimedCsvFile t = new TimedCsvFile();
        t.csvFile = csvFile;
        t.startTime = LocalDateTime.now();
        timedCsvFiles.add(t);
    }

    public void end(CsvFile csvFile) {
        timedCsvFiles.getLast().endTime = LocalDateTime.now();
    }

    public void startSandbox() {
        sanBoxCalled = true;
        sbStart = LocalDateTime.now();
    }

    public void endSandbox() {
        sbEnd = LocalDateTime.now();
    }

    public String build() {
        StringBuilder sb = new StringBuilder();

        sb.append("本次更新(").append(timedChangeSet.changeSet.to).append(")").append(", 共 ")
                .append(timedChangeSet.changeSet.csvFiles.size()).append(" 个原始文件. \n").append("开始时间：")
                .append(timedChangeSet.startTime).append("; 结束时间：").append(timedChangeSet.endTime).append("\n");

        if (timedCsvFiles.size() > 0) {
            sb.append("加载CSV文件如下：\n");
            sb.append(String.format("%1$-40s", "文件")).append("开始时间                 ").append("结束时间                 ")
                    .append("用时\n");

            for (TimedCsvFile t : timedCsvFiles) {
                sb.append(String.format("%1$-40s", getShortFile(t.csvFile.filePath)))
                        .append(String.format("%1$-25s", t.startTime)).append(String.format("%1$-25s", t.endTime))
                        .append(Duration.between(t.startTime, t.endTime)).append("\n");
            }
        }

        if (sanBoxCalled) {
            sb.append("沙盒处理 - 开始时间：").append(sbStart).append(" 结束时间：").append(sbEnd).append(" 用时：")
                    .append(Duration.between(sbStart, sbEnd));
        }
        return sb.toString();
    }

    public String buildErrorEmailMessage(CsvFile csvFile, String errorMessage) {
        StringBuilder sb = new StringBuilder();

        if(csvFile != null) {
            sb.append("本次导入csv文件失败(").append("开始时间：")
                    .append(timedChangeSet.startTime).append("; 结束时间：").append(timedChangeSet.endTime).append("\n")
                    .append("失败的文件是: " + csvFile.getFilePath()).append("\n").append("异常信息是: " + errorMessage);
        }
        if (sanBoxCalled) {
            sb.append("沙盒处理失败 - 开始时间：").append(sbStart).append(" 结束时间：").append(sbEnd).append(" 用时：")
                    .append(Duration.between(sbStart, sbEnd)).append("\n")
                    .append("异常信息是: " + errorMessage);
        }
        return sb.toString();
    }

    private String getShortFile(String filePath) {
        Path p = Paths.get(filePath);
        int count = p.getNameCount();
        return String.format("%s/%s", p.subpath(count - 3, count - 2), p.subpath(count - 1, count));
    }

    @Override
    public String toString() {
        return this.build();
    }

    private class TimedChangeSet {
        public LocalDateTime startTime;
        public LocalDateTime endTime;
        public ChangeSet changeSet;
    }

    private class TimedCsvFile {
        public LocalDateTime startTime;
        public LocalDateTime endTime;
        public CsvFile csvFile;
    }

}