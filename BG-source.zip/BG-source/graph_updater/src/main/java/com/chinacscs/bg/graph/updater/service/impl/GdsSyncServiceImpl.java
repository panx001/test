package com.chinacscs.bg.graph.updater.service.impl;

import com.chinacscs.bg.graph.updater.sandbox.SqlManager;
import com.chinacscs.bg.graph.updater.service.GdsSyncService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import javax.annotation.Resource;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * desc: GDS 数据同步impl
 * Author:   wangpengchao
 * Date:     2019/4/22-9:58
 */
@Slf4j
@Service
@ConditionalOnProperty(name = {"app.graph.product.type"}, havingValue = "2")
public class GdsSyncServiceImpl implements GdsSyncService {

    @Resource
    @Qualifier("gdsJdbcTemplate")
    private JdbcTemplate gdsJdbcTemplate;
    @Value("${app.sandbox.business.data.flag}")
    private Integer businessDataFlag;
    @Value("${app.encode.version}")
    private String encodeVersion;
    @Value("${spring.datasource.gds.dataSource}")
    private String gdsDataSource;
    @Value("${app.business.update.table.no:}")
    private String updateTableNo;

    @Override
    public void updateGDS(String personId, String personNm, String cscsId, String zszhId) throws Exception {
        Pattern pattern = Pattern.compile("^\\d+");
        Matcher matcher = pattern.matcher(personId.trim());
        if(matcher.find()) {
            // 开始更新
            String companyId = matcher.group();
            if(StringUtils.isNotBlank(updateTableNo)) {
                // 获取sql的map集合
                Map<String, String> updateSqlMapper = SqlManager.getUpdateSqlMapper(businessDataFlag, gdsDataSource);
                String[] tableNos = updateTableNo.split(",");
                for (String tableNo : tableNos) {
                    String sql = updateSqlMapper.get(tableNo);
                    if(StringUtils.isBlank(sql)) {
                        continue;
                    }
                    // 事务
                    DefaultTransactionDefinition def = new DefaultTransactionDefinition();
                    def.setIsolationLevel(TransactionDefinition.ISOLATION_READ_COMMITTED);
                    def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
                    DataSourceTransactionManager transactionManager = new DataSourceTransactionManager(gdsJdbcTemplate.getDataSource());
                    TransactionStatus status = transactionManager.getTransaction(def);
                    if(businessDataFlag == 1) {
                        // 中证id直接替换personId
                        gdsJdbcTemplate.update(sql, cscsId, companyId, personNm);
                    }else if(businessDataFlag == 2) {
                        // 同步中证和中数id
                        gdsJdbcTemplate.update(sql, cscsId, zszhId, companyId, personNm);
                    }
                    // 持久化所有数据
                    transactionManager.commit(status);
                }
            }
        }
    }
}
