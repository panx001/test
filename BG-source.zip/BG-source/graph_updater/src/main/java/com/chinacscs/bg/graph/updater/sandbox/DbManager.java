package com.chinacscs.bg.graph.updater.sandbox;

import com.chinadaas.custom.ChinaDaasDataEncoder;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * 用于记录H2语句
 * 以及获取需要的SQL
 */
@Slf4j
@Service
public class DbManager {

    @Autowired(required = false)
    @Qualifier("h2JdbcTemplate")
    private JdbcTemplate h2JdbcTemplate;

    @Value("${app.encode.version}")
    private String encodeVersion;

    /**
     * 初始化表
     *
     * @param filePath 全量识别码文件
     * @throws Exception
     */
    public void initTable(String filePath) throws Exception {
        //如果存在USER_INFO表就先删除USER_INFO表
        h2JdbcTemplate.execute("DROP TABLE IF EXISTS PERSON_MAPPER");
        h2JdbcTemplate.execute("DROP TABLE IF EXISTS PERSON_INFO");

        // 初始化全局识别码表
        initTablePersonMapper(filePath);
        // 创建用户身份证表
        createTablePersonInfo();
    }

    /**
     * 初始化全量识别码表
     *
     * @param filePath
     */
    public void initTablePersonMapper(String filePath) {

        // 创建全量识别码表
        if(StringUtils.isNotBlank(filePath)) {
            h2JdbcTemplate.execute("CREATE TABLE PERSON_MAPPER(person_id VARCHAR(300)PRIMARY KEY, person_nm VARCHAR(300), cscs_id VARCHAR(300),  zszh_id  VARCHAR(255)) " +
                    "AS SELECT person_id as person_id , person_nm as person_nm, person_id_cscs as cscs_id,  person_id_zszh as zszh_id FROM CSVREAD('" + filePath +"', null , 'charset=UTF-8') where person_id_zszh is not null");
        }else {
            // 创建全量识别码表
            h2JdbcTemplate.execute("CREATE TABLE PERSON_MAPPER(person_id VARCHAR(300)PRIMARY KEY, person_nm VARCHAR(300), cscs_id VARCHAR(300),  zszh_id  VARCHAR(255))");
        }
        // 创建全量识别码表的索引
        h2JdbcTemplate.execute("CREATE INDEX index_person_mapper_zszh_id ON PERSON_MAPPER(zszh_id)");
    }

    /**
     * 初始化person_info客户信息表
     */
    public void createTablePersonInfo() {
        // 创建表
        h2JdbcTemplate.execute("CREATE TABLE PERSON_INFO( card_no VARCHAR(300) PRIMARY KEY, zszh_id VARCHAR(300))");
        // 创建索引
        h2JdbcTemplate.execute("CREATE INDEX index_person_info_zszh_id ON PERSON_INFO(zszh_id)");
    }

    /**
     * 插入表客户信息表操作
     */
    private void insertPersonInfo(String cardNo) throws Exception {
        String zszhId = ChinaDaasDataEncoder.encode(cardNo, encodeVersion);
        String insertSql = "insert into PERSON_INFO(card_no, zszh_id) VALUES (?, ?)";
        h2JdbcTemplate.update(insertSql, cardNo, zszhId);
    }

    public List<Map<String, Object>> personQueryByZszhId(String zszhId) throws Exception {
        String selectSql = "SELECT * FROM PERSON_INFO WHERE  zszh_id = ?";
        return h2JdbcTemplate.queryForList(selectSql, zszhId);
    }

    public List<Map<String, Object>> personQueryByPersonId(String cardNo) throws Exception {
        String selectSql = "SELECT * FROM PERSON_INFO WHERE card_no = ? ";
        return h2JdbcTemplate.queryForList(selectSql, cardNo);
    }

    public void personInsert(String cardNo, String zszhId) throws Exception {
        String insertSql = "INSERT INTO PERSON_INFO(card_no, zszh_id) VALUES(?, ?)";
        h2JdbcTemplate.update(insertSql, cardNo, zszhId);
    }

    public void mapperInsert(String personId, String personNm, String cscsId, String zszhId) throws Exception {
        String insertSql = "INSERT INTO PERSON_MAPPER(person_id, person_nm, cscs_id, zszh_id) VALUES(?, ?, ?, ?)";
        h2JdbcTemplate.update(insertSql, personId, personNm, cscsId, zszhId);
    }

    public List<Map<String, Object>> mapperByPersonId(String personId) throws Exception{
        String selectSql = "SELECT * FROM PERSON_MAPPER WHERE person_id = ? ";
        return  h2JdbcTemplate.queryForList(selectSql, personId);
    }

    public List<Map<String, Object>> mapperByzsId(String zszhId) throws Exception{
        String selectSql = "SELECT * FROM PERSON_MAPPER WHERE zszh_id = ? ";
        return  h2JdbcTemplate.queryForList(selectSql, zszhId);
    }

    public void mapperUpdate(String personId, String personNm, String cscsId, String zszhId) {
        String updateSql = "update PERSON_MAPPER SET person_nm = ? , cscs_id = ? , zszh_id = ? WHERE person_id = ? ";
        h2JdbcTemplate.update(updateSql, personNm, cscsId, zszhId, personId);
    }

    public void batchMapperInsert(String personId, String personNm, String cscsId, String zszhId) {
        String batchSql = "MERGE INTO PERSON_MAPPER KEY (PERSON_ID) values(?, ?, ?, ?)";
        h2JdbcTemplate.update(batchSql, personId, personNm, cscsId, zszhId);
    }
}
