package com.chinacscs.bg.graph.updater.sandbox;

import java.util.HashMap;
import java.util.Map;

/**
 * sql管理的工具类
 */
public class SqlManager {

    /**
     *
     * @param updateType 1 : 更新中证id   2: 中证 + 中数Id
     * @param dataSource 数据源类型
     * @return
     */
    public static Map<String, String> getUpdateSqlMapper(Integer updateType, String dataSource) {
        Map<String, String> map = new HashMap();
        map.put("1", updateType == 1 ? COMPY_EXECUTIVESINFO_CSCSID_UPDATE : COMPY_EXECUTIVESINFO_CSCSID_ZSZHID_UPDATE);
        map.put("2", updateType == 1 ? COMPY_SHAREHDINVESTNB_XYGS_CSCSID_UPDATE : COMPY_SHAREHDINVESTNB_XYGS_CSCSID_ZSZHID_UPDATE);
        map.put("3", updateType == 1 ? COMPY_SHAREHDINVESTPUB_XYGS_CSCSID_UPDATE : COMPY_SHAREHDINVESTPUB_XYGS_CSCSID_ZSZHID_UPDATE);
        map.put("4", updateType == 1 ? COMPY_SHAREHDINVEST_XYGS_CSCSID_UPDATE : COMPY_SHAREHDINVEST_XYGS_CSCSID_ZSZHID_UPDATE);
        map.put("5", updateType == 1 ? COMPY_SHAREHOLDERS_OPTIMIZED_CSCSID_UPDATE : COMPY_SHAREHOLDERS_OPTIMIZED_CSCSID_ZSZHID_UPDATE);
        map.put("6", updateType == 1 ? COMPY_TAXOVERDUE_XYGS_CSCSID_UPDATE : COMPY_TAXOVERDUE_XYGS_CSCSID_ZSZHID_UPDATE);
        map.put("7", updateType == 1 ? STG_PFCOMPY_AMACPUNISH_CSCSID_UPDATE : STG_PFCOMPY_AMACPUNISH_CSCSID_ZSZHID_UPDATE);
        map.put("8", updateType == 1 ?  ("mysql".equalsIgnoreCase(dataSource) ? MYSQL_COMPY_SHAREHOLDERS_OPTIMIZED_V2_CSCSID_UPDATE : ORACLE_COMPY_SHAREHOLDERS_OPTIMIZEDV2_CSCSID_UPDATE) :
                ("mysql".equalsIgnoreCase(dataSource) ?
                        MYSQL_COMPY_SHAREHOLDERS_OPTIMIZED_V2_CSCSID_ZSZHID_UPDATE : ORACLE_COMPY_SHAREHOLDERS_OPTIMIZEDV2_CSCSID_ZSZHID_UPDATE));
        return map;
    }

/*工商数据同步中证id(cscsId)*/
    // 更新表 COMPY_EXECUTIVESINFO(编号1)
    public static final String COMPY_EXECUTIVESINFO_CSCSID_UPDATE = "UPDATE COMPY_EXECUTIVESINFO SET PERSON_ID = ? WHERE COMPANY_ID = ? AND PERSON_NM = ?";
    // 更新表 COMPY_SHAREHDINVESTNB_XYGS(编号2)
    public static final String  COMPY_SHAREHDINVESTNB_XYGS_CSCSID_UPDATE = "UPDATE COMPY_SHAREHDINVESTNB_XYGS SET PERSON_ID = ? WHERE COMPANY_ID = ? AND sharehd_name = ?";
    // 更新表 COMPY_SHAREHDINVESTPUB_XYGS(编号3)
    public static final String COMPY_SHAREHDINVESTPUB_XYGS_CSCSID_UPDATE = "UPDATE COMPY_SHAREHDINVESTPUB_XYGS SET PERSON_ID = ? WHERE COMPANY_ID = ? AND sharehd_name = ?";
    // 更新表 COMPY_SHAREHDINVEST_XYGS(编号4)
    public static final String COMPY_SHAREHDINVEST_XYGS_CSCSID_UPDATE = "UPDATE COMPY_SHAREHDINVEST_XYGS SET PERSON_ID = ? WHERE COMPANY_ID = ? AND sharehd_name = ?";
    // 更新表 COMPY_SHAREHOLDERS_OPTIMIZED(编号5)
    public static final String COMPY_SHAREHOLDERS_OPTIMIZED_CSCSID_UPDATE = "UPDATE COMPY_SHAREHOLDERS_OPTIMIZED SET PERSON_ID = ? WHERE COMPANY_ID = ? AND sharehd_name = ?";
    // 更新表 COMPY_TAXOVERDUE_XYGS(编号6)
    public static final String COMPY_TAXOVERDUE_XYGS_CSCSID_UPDATE = "UPDATE COMPY_TAXOVERDUE_XYGS SET PERSON_ID = ? WHERE COMPANY_ID = ? AND PERSON_NM = ?";
    // 更新表 STG_PFCOMPY_AMACPUNISH(编号7)
    public static final String STG_PFCOMPY_AMACPUNISH_CSCSID_UPDATE = "UPDATE PFCOMPY_AMACPUNISH SET PERSON_ID = ? WHERE COMPANY_ID = ? AND PERSON_NM = ?";
    // 更新表 COMPY_SHAREHOLDERS_OPTIMIZED_V2(mysql表名 编号8)
    public static final String MYSQL_COMPY_SHAREHOLDERS_OPTIMIZED_V2_CSCSID_UPDATE = "UPDATE COMPY_SHAREHOLDERS_OPTIMIZED_V2 SET PERSON_ID =? WHERE COMPANY_ID = ? AND sharehd_name = ?";
    // 更新表 COMPY_SHAREHOLDERS_OPTIMIZEDV2(oracle的表名 编号8)
    public static final String ORACLE_COMPY_SHAREHOLDERS_OPTIMIZEDV2_CSCSID_UPDATE = "UPDATE COMPY_SHAREHOLDERS_OPTIMIZEDV2 SET PERSON_ID =? WHERE COMPANY_ID = ? AND sharehd_name = ?";


/*工商数据同步中证id( cscsId + zszhId)*/
    // 更新表 COMPY_EXECUTIVESINFO(编号1)
    public static final String COMPY_EXECUTIVESINFO_CSCSID_ZSZHID_UPDATE = "UPDATE COMPY_EXECUTIVESINFO SET PERSON_ID = ?, ZSZH_ID = ? WHERE COMPANY_ID = ? AND PERSON_NM = ?";
    // 更新表 COMPY_SHAREHDINVESTNB_XYGS(编号2)
    public static final String COMPY_SHAREHDINVESTNB_XYGS_CSCSID_ZSZHID_UPDATE = "UPDATE COMPY_SHAREHDINVESTNB_XYGS SET PERSON_ID = ?, ZSZH_ID = ? WHERE COMPANY_ID = ? AND sharehd_name = ?";
    // 更新表 COMPY_SHAREHDINVESTPUB_XYGS(编号3)
    public static final String COMPY_SHAREHDINVESTPUB_XYGS_CSCSID_ZSZHID_UPDATE = "UPDATE COMPY_SHAREHDINVESTPUB_XYGS SET PERSON_ID = ?, ZSZH_ID = ? WHERE COMPANY_ID = ? AND sharehd_name = ?";
    // 更新表 COMPY_SHAREHDINVEST_XYGS(编号4)
    public static final String COMPY_SHAREHDINVEST_XYGS_CSCSID_ZSZHID_UPDATE = "UPDATE COMPY_SHAREHDINVEST_XYGS SET PERSON_ID = ?, ZSZH_ID = ? WHERE COMPANY_ID = ? AND sharehd_name = ?";
    // 更新表 COMPY_SHAREHOLDERS_OPTIMIZED(编号5)
    public static final String COMPY_SHAREHOLDERS_OPTIMIZED_CSCSID_ZSZHID_UPDATE = "UPDATE COMPY_SHAREHOLDERS_OPTIMIZED SET PERSON_ID = ?, ZSZH_ID = ? WHERE COMPANY_ID = ? AND sharehd_name = ?";
    // 更新表 COMPY_TAXOVERDUE_XYGS(编号6)
    public static final String COMPY_TAXOVERDUE_XYGS_CSCSID_ZSZHID_UPDATE = "UPDATE COMPY_TAXOVERDUE_XYGS SET PERSON_ID = ?, ZSZH_ID = ? WHERE COMPANY_ID = ? AND PERSON_NM = ?";
    // 更新表 STG_PFCOMPY_AMACPUNISH(编号7)
    public static final String STG_PFCOMPY_AMACPUNISH_CSCSID_ZSZHID_UPDATE = "UPDATE PFCOMPY_AMACPUNISH SET PERSON_ID = ?, ZSZH_ID = ? WHERE COMPANY_ID = ? AND PERSON_NM = ?";
    // 更新表 COMPY_SHAREHOLDERS_OPTIMIZED_V2(mysql表名 编号8)
    public static final String MYSQL_COMPY_SHAREHOLDERS_OPTIMIZED_V2_CSCSID_ZSZHID_UPDATE = "UPDATE COMPY_SHAREHOLDERS_OPTIMIZED_V2 SET PERSON_ID =?, ZSZH_ID = ? WHERE COMPANY_ID = ? AND sharehd_name = ?";
    // 更新表 COMPY_SHAREHOLDERS_OPTIMIZEDV2(oracle表名 编号8)
    public static final String ORACLE_COMPY_SHAREHOLDERS_OPTIMIZEDV2_CSCSID_ZSZHID_UPDATE = "UPDATE COMPY_SHAREHOLDERS_OPTIMIZEDV2 SET PERSON_ID =?, ZSZH_ID = ? WHERE COMPANY_ID = ? AND sharehd_name = ?";

/*客户身份证号列表*/
    // 根据任务状态查询任务列表(task_status)
    public static final String CLIEND_TASK_STATUS_SELECT = "select * from task_status where task_status = ? ";
    // 更新任务的状态
    public static final String CLIEND_TASK_STATUS_UPDATE = "update task_status set task_status = ? where id = ? ";
    // 根据task_id查询要处理的身份证号列表(client_id_card_info)
    public static final String CLIEND_ID_CARD_INFO_BY_TASK_ID_SELECT = "select * from client_id_card_info where task_id = ? ";
    // 根据cardNo查询要处理的身份证号列表(client_id_card_info)
    public static final String CLIEND_ID_CARD_INFO_BY_CARD_NO_SELECT = "select * from client_id_card_info where card_no = ? order by task_id desc";
    // 插入匹配成功的中证id结果(client_id_card_match_result)(mysql)
    public static final String MYSQL_CLIEND_ID_CARD_MATCH_RESULT_INSERT= "insert into client_id_card_match_result(task_id, card_no, match_id, match_value) values(?, ?, ?, ?) ";
    // 插入匹配成功的中证id结果(client_id_card_match_result)(mysql)
    public static final String ORACLE_CLIEND_ID_CARD_MATCH_RESULT_INSERT= "insert into client_id_card_match_result(id, task_id, card_no, match_id, match_value) values(SEQ_CARD_MATCH_RESULT_ID.NEXTVAL, ?, ?, ?, ?) ";
    // 查询(client_id_card_match_result)
    public static final String CLIEND_ID_CARD_MATCH_RESULT_SELECT= "select  * from client_id_card_match_result where card_no = ?";
    // 根据身份证号删除
    public static final String CLIEND_ID_CARD_INFO_BY_CARD_NO_DELETE = "delete from client_id_card_info where card_no = ? ";
}
