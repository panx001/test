package com.chinacscs.bg.graph.updater.service;

import com.chinacscs.bg.graph.updater.CsvFile;
import lombok.extern.slf4j.Slf4j;
import org.neo4j.driver.v1.AuthTokens;
import org.neo4j.driver.v1.Driver;
import org.neo4j.driver.v1.GraphDatabase;
import org.neo4j.driver.v1.Session;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

/**
 * CsvLoadService
 */
@Service
@Slf4j
@ConditionalOnProperty(name = {"app.neo4j.update.enable"}, havingValue = "true")
public class CsvLoadService {
    @Value("${app.neo4j.uri}")
    public String neo4jUri;
    @Value("${app.neo4j.user}")
    private String neo4jUser;
    @Value("${app.neo4j.password}")
    private String neo4jPW;
    @Value("${app.httpLoad.enable}")
    private boolean httpLoad;

    /**
     * Load CSV file to neo4j
     * @param filePath csv filename includes path to csvRoot
     */
    public void load(CsvFile csv) {
        Driver driver = GraphDatabase.driver(neo4jUri, AuthTokens.basic(neo4jUser, neo4jPW));        
        try (Session session = driver.session()) {
            log.info("正在导入图谱的csv文件是: " + csv.getServerPath() + "; cypher语句: " + csv.getStatement(httpLoad));
            session.run(csv.getStatement(httpLoad));
        }catch (Exception e) {
            log.error("导入图谱出错, " + e);
            throw e;
        }finally {
            driver.close();
        }
    }
}