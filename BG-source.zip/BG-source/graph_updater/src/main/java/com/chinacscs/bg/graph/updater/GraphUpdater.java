package com.chinacscs.bg.graph.updater;

import java.util.Arrays;

import com.chinacscs.bg.graph.updater.job.UpdateJob;
import com.chinacscs.bg.graph.updater.service.ChangeSetService;

import org.quartz.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.ApplicationPidFileWriter;
import org.springframework.context.annotation.Bean;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

/**
 * 程序启动入口类
 */
@SpringBootApplication
@Slf4j
@ComponentScan(value = "com.chinacscs")
public class GraphUpdater extends WebMvcConfigurationSupport implements ApplicationRunner {

    @Autowired
    private ChangeSetService changeSetService;

    @Value("${app.cron-expression:0 0/15 * * * ?}")
    private String cronExpression;

    @Value("${app.server.loadCsvBasePath}")
    private String severPath;

    @Value("${app.loadCsvBasePath}")
    private String loadCsvBasePath;

    @Autowired
    public Scheduler scheduler;

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(GraphUpdater.class);
        app.addListeners(new ApplicationPidFileWriter());
        if (!isServiceMode(args)) {
            app.setWebApplicationType(WebApplicationType.NONE);
        }
        app.run(args);
    }

    private static boolean isServiceMode(String[] args) {
        return Arrays.stream(args).anyMatch(it -> it.equalsIgnoreCase("--service=true"));
    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        if (isServiceMode(args.getSourceArgs())) {
            scheduler.triggerJob(JobKey.jobKey("updateJob"));
            log.info("以service方式形式运行");
            return;
        }
        long startTime = System.currentTimeMillis();
        log.info("以console形式运行开始, " + startTime);
        changeSetService.loadAll();
        scheduler.shutdown();
        log.info("console形式运行结束, 耗时: " + (System.currentTimeMillis() - startTime) + "ms");
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/"+ severPath +"/**").addResourceLocations("file:"+ loadCsvBasePath +"/");
        super.addResourceHandlers(registry);
    }

    @Bean
    public JobDetail updateJobDetail() {
        return JobBuilder.newJob(UpdateJob.class).withIdentity("updateJob").storeDurably().build();
    }

    @Bean
    public Trigger updateJobTrigger() {
        CronScheduleBuilder scheduleBuilder = CronScheduleBuilder.cronSchedule(cronExpression);
        return TriggerBuilder.newTrigger().forJob(updateJobDetail()).withIdentity("updateJobTrigger")
                .withSchedule(scheduleBuilder).build();
    }
}