//package com.chinacscs.bg.graph.updater.sandbox;
//
//import com.chinacscs.bg.graph.updater.entity.Log;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.stereotype.Service;
//import org.springframework.test.context.junit4.SpringRunner;
//
///**
// * @desc:
// * @author: wangpc
// * @date: 2019-07-18 20:12
// */
//@RunWith(SpringRunner.class)
//@SpringBootTest
//@Service
//public class SysLogRecord {
//
//    @Test
//    public void  test() {
//        System.out.println("1321234");
//        int i = 10 / 0;
//    }
//}
