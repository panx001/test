package com.chinacscs.bg.graph.updater.sandbox;

import com.chinacscs.bg.graph.updater.entity.CommandResult;
import com.chinacscs.bg.graph.updater.service.VersionControlService;
import com.chinacscs.bg.graph.updater.utils.CommandUtils;
import com.chinadaas.custom.ChinaDaasDataEncoder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class VersionControlServiceTest {
    @Autowired(required = false)
    private VersionControlService versionControlService;

    @Test
    public void updateProgram() throws Exception{
        versionControlService.updateProgram();
    }

    @Test
    public void checkVersion() throws Exception{
        Long aLong = versionControlService.checkVersion();
        System.out.println(aLong);
    }

    @Test
    public void execShell() throws Exception{
        String win = "D:\\software\\idea\\workspace\\BG-source\\graph_updater\\bin\\graph-updater-auto.sh";
        String lin = "/user/run.sh";
        CommandUtils.exec(win);
    }
}
