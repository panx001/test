package com.chinacscs.bg.graph.updater.sandbox;

import com.chinacscs.bg.graph.updater.annotation.LogAnnotation;
import com.chinacscs.bg.graph.updater.entity.SysLogRecord;
import com.chinacscs.bg.graph.updater.entity.TaskStatus;
import com.chinacscs.bg.graph.updater.mapper.SysLogRecordMapper;
import com.chinacscs.bg.graph.updater.mapper.TaskStatusMapper;
import com.chinacscs.bg.graph.updater.service.DbManager;
import com.chinacscs.bg.graph.updater.service.GdsSyncService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

<<<<<<< Updated upstream
//@RunWith(SpringRunner.class)
//@SpringBootTest
public class DbManagerTest {
    @Autowired(required = false)
    private DbManager dbManager;
    @Test
    public void initTable() {
        try {
            dbManager.initTable(null);
=======
import java.util.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DbManagerTest {
    @Autowired(required = false)
    private DbManager dbManager;
    @Autowired(required = false)
    @Qualifier("h2JdbcTemplate")
    private JdbcTemplate h2JdbcTemplate;
    @Autowired
    private GdsSyncService gdsSyncService;
    @Autowired(required = false)
    private SysLogRecordMapper sysLogRecordMapper;
    @Autowired
    private TaskStatusMapper taskStatusMapper;

    @Test
    public void initTable() {
        try {
            long startTime = System.currentTimeMillis();
//            dbManager.initTable(null);
//            List<Map<String, Object>> mapList = dbManager.mapperListAll();
//            List<Map<String, Object>> mapList = h2JdbcTemplate.queryForList("SELECT * FROM PERSON_INFO");
//            List<Map<String, Object>> mapperList = h2JdbcTemplate.queryForList("SELECT * FROM PERSON_MAPPER");
//            List<Map<String, Object>> List = h2JdbcTemplate.queryForList("SELECT m.person_Id, m.cscs_Id, m.zszh_id FROM PERSON_INFO p LEFT JOIN PERSON_MAPPER m ON p.zszh_id = m.zszh_id");
//            Map<String, Object> matchResult = MatchResultMapUtils.getMatchResult(dbManager, 1, 1);


//            long start = System.currentTimeMillis();
//            System.out.println("开始时间: " + System.currentTimeMillis());
//            List<Map<String, Object>> mapList = h2JdbcTemplate.queryForList("SELECT * FROM PERSON_MAPPER limit 10");
//            System.out.println("数据插入完成,用时: " + (System.currentTimeMillis() - start));


//            int i = 0;
//            boolean flag = true;
//            while (flag) {
//                System.out.println("i: " + i);
//                Map<String, Object> map = new HashMap<>();
//                List<Map<String, Object>> list = new ArrayList<>();
//                int start = i;
//                int end = i + 2000000;
//                List<Map<String, Object>> mapList = h2JdbcTemplate.queryForList("SELECT * FROM PERSON_MAPPER limit ? , ?", start, end);
//                if(mapList == null || mapList.size() == 0) {
//                    flag = false;
//                    continue;
//                }
//                i = end;
//                list.addAll(mapList);
//            }
//            for (int i = 0; i < 100000; i++) {
//                dbManager.batchMapperInsert("id" + i, "name陈庆庆农莎莎6789678" + i, "cscs123456" + i, "中华人民共和国kdkekdnkddkkdjfdajdkajfdja主要是为了测试好的都看得到健康角度看就看看都看你的那颗能看到你到你那ndzszh" + i);
//                h2JdbcTemplate.update("INSERT INTO PERSON_MAPPER(person_id, person_nm, cscs_id, zszh_id) VALUES(?, ?, ?, ?)", "id" + i, "name陈庆庆农莎莎6789678" + i, "cscs123456" + i, "中华人民共和国kdkekdnkddkkdjfdajdkajfdja主要是为了测试好的都看得到健康角度看就看看都看你的那颗能看到你到你那ndzszh" + i);
//            }
    //            List<Map<String, Object>> mapList = h2JdbcTemplate.queryForList("SELECT count(*) FROM PERSON_MAPPER");
    //            System.out.println("结束, 用时: " + (System.currentTimeMillis() - startTime));
    // 插入
//            SysLogRecord sysLogRecord = new SysLogRecord();
//            sysLogRecord.setId(UUID.randomUUID().toString().replaceAll("-", ""));
//            sysLogRecord.setLevels("严重");
//            int insert = sysLogRecordMapper.insert(sysLogRecord);
//            System.out.println(insert);

//            PageHelper.startPage(1, 2);
//            List<TaskStatus> list = taskStatusMapper.listNoMatchAndFailTask();
//            PageInfo<SysLogRecord> pageinfo = new PageInfo(list);
            System.out.println("12345432");
>>>>>>> Stashed changes
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    public static void main(String[] args) {

        try {
            List<Map<String, Object>> list = new ArrayList<>();
            Map<String, Object> m1 = new HashMap();
            m1.put("person_id", "123");
            m1.put("cscs_id", "456");

            Map<String, Object> m2 = new HashMap();
            m2.put("person_id", "1238");
            m2.put("cscs_id", "456");
            list.add(m1);
            list.add(m2);
            Iterator<Map<String, Object>> iterator = list.iterator();
            Map<String, Object> matchResult = new HashMap<>();
            while (iterator.hasNext()) {
                Map<String, Object> map = iterator.next();
                String personId = map.get("person_id").toString();
                String cscsId = map.get("cscs_id").toString();
                System.out.println(personId);
                matchResult.put(personId, cscsId);
                iterator.remove();
            }

            System.out.println("结束......");

//            System.out.println("110101199003078937" + "<--->" + ChinaDaasDataEncoder.encode("110101199003078937", "V1"));
//            System.out.println("11010119900307299X" + "<--->" + ChinaDaasDataEncoder.encode("11010119900307299X", "V1"));
//            System.out.println("110101199003075832" + "<--->" + ChinaDaasDataEncoder.encode("110101199003075832", "V1"));
//            System.out.println("110101199003079710" + "<--->" + ChinaDaasDataEncoder.encode("110101199003079710", "V1"));
//            System.out.println("110101199003070572" + "<--->" + ChinaDaasDataEncoder.encode("110101199003070572", "V1"));
//            System.out.println("110101199003074493" + "<--->" + ChinaDaasDataEncoder.encode("110101199003074493", "V1"));
//            System.out.println("110101199003072594" + "<--->" + ChinaDaasDataEncoder.encode("110101199003072594", "V1"));
//            System.out.println("110101199003070759" + "<--->" + ChinaDaasDataEncoder.encode("110101199003070759", "V1"));
//            System.out.println("110101199003075453" + "<--->" + ChinaDaasDataEncoder.encode("110101199003075453", "V1"));
//            System.out.println("110101199003076819" + "<--->" + ChinaDaasDataEncoder.encode("110101199003076819", "V1"));
//            System.out.println("110101199003078611" + "<--->" + ChinaDaasDataEncoder.encode("110101199003078611", "V1"));
//            System.out.println("110101199003078494" + "<--->" + ChinaDaasDataEncoder.encode("110101199003078494", "V1"));
//            System.out.println("11010119900307985X" + "<--->" + ChinaDaasDataEncoder.encode("11010119900307985X", "V1"));
//            System.out.println("110101199003070038" + "<--->" + ChinaDaasDataEncoder.encode("110101199003070038", "V1"));
//            System.out.println("110101199003072252" + "<--->" + ChinaDaasDataEncoder.encode("110101199003072252", "V1"));
//            System.out.println("11010119900307723X" + "<--->" + ChinaDaasDataEncoder.encode("11010119900307723X", "V1"));
//            System.out.println("110101199003076552" + "<--->" + ChinaDaasDataEncoder.encode("110101199003076552", "V1"));
//            System.out.println("110101199003075699" + "<--->" + ChinaDaasDataEncoder.encode("110101199003075699", "V1"));
//            System.out.println("110101199003070337" + "<--->" + ChinaDaasDataEncoder.encode("110101199003070337", "V1"));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
