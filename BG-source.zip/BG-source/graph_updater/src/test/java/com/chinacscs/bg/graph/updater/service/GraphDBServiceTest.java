package com.chinacscs.bg.graph.updater.service;

import org.junit.Test;

/**
 * GraphDBServiceTest
 */
public class GraphDBServiceTest {

    @Test
    public void replaceDBTest() {

        GraphDBService service = new GraphDBService();
        service.replaceDB("newDb", "oldDb");
    }
}