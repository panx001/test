package com.cscs.graph_api.domain;

import com.cscs.graph_api.Util.UseFulFunc;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Created by wuchenglong on 2018/1/9.
 */

@SuppressWarnings("unused")
public class ResultReturnNew {

    private static Logger logger = LogManager.getLogger(ResultReturnNew.class);

    private InfoShow infoShow;
    private NodeShow startNodeShow;
    private NodeShow endNodeShow;
    private RelationShipShow relationShipShow;

    public ResultReturnNew() {

    }

    public ResultReturnNew(NodeShow startNodeShow, RelationShipShow relationShipShow, NodeShow endNodeShow,InfoShow infoShow) {
        this.startNodeShow = startNodeShow;
        this.startNodeShow.infoUpdate();
        this.endNodeShow = endNodeShow;
        this.endNodeShow.infoUpdate();

        this.infoShow=infoShow;


        this.relationShipShow = relationShipShow;
        this.relationShipShow.setSourceId(this.startNodeShow.getId());
        this.relationShipShow.setTargetId(this.endNodeShow.getId());
        this.relationShipShow.setType(UseFulFunc.RELATION_TYPE_MAP.getOrDefault(this.relationShipShow.getType(), "0"));
        this.relationShipShow.infoUpdate();
    }

    public void setInfoShow(InfoShow infoShow) {
        this.infoShow = infoShow;
    }

    public InfoShow getInfoShow() {
        return infoShow;
    }




    public void setStartNodeShow(NodeShow startNodeShow) {
        this.startNodeShow = startNodeShow;
    }

    public NodeShow getStartNodeShow() {
        return startNodeShow;
    }

    public void setEndNodeShow(NodeShow endNodeShow) {
        this.endNodeShow = endNodeShow;
    }

    public NodeShow getEndNodeShow() {
        return endNodeShow;
    }

    public RelationShipShow getRelationShipShow() {
        return relationShipShow;
    }

    public void setRelationShipShow(RelationShipShow relationShipShow) {
        this.relationShipShow = relationShipShow;
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
