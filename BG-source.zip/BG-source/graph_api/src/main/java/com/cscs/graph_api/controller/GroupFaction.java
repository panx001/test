package com.cscs.graph_api.controller;

import com.cscs.graph_api.Exception.InputException;
import com.cscs.graph_api.domain.ResultReturnCollection;
import com.cscs.graph_api.dto.BasicOutDto;
import com.cscs.graph_api.dto.CompanyCustomerDto;
import com.cscs.graph_api.dto.GroupFactionInDto;
import com.cscs.graph_api.services.GroupFactionServices;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping(value = "/relation")
public class GroupFaction {

    private static Logger logger = LogManager.getLogger(GroupFaction.class);

    @Autowired
    private GroupFactionServices services;

    //集团派系
    @RequestMapping(value = "/searchGroupFaction", method = RequestMethod.POST)
    public BasicOutDto searchGroupFaction(@RequestBody GroupFactionInDto inDto) throws Exception {
        long startTime = System.currentTimeMillis();

        if (inDto.getCompanyId() == null && Strings.isBlank(inDto.getCompanyNm())) throw new InputException();
        if(inDto.layer < 1 || inDto.layer > 10) inDto.layer = 7;

        BasicOutDto outDto = new BasicOutDto();
        ResultReturnCollection resultReturnCollection =  new ResultReturnCollection();

        if (inDto.returnType != 1 && inDto.returnType != 2 && inDto.returnType != 3)
            throw new InputException();


        //返回母公司
        if (inDto.returnType == 1){
            resultReturnCollection =services.searchParentCompany(inDto);
        }
        //返回完整图谱，含主要人员的对外投资任职
        else if (inDto.returnType == 3){
            resultReturnCollection =services.searchGroupFactionAll(inDto);
        }
        //返回母公司及子公司
        else{
            resultReturnCollection =services.searchSubCompany(inDto);
        }

        if (resultReturnCollection.getNodeShowsUniqueList().size() == 0) {
            outDto.setCode(404);
            outDto.setMsg("数据不存在");
        } else {
            outDto.setCode(200);
            outDto.setMsg("成功");
        }
        outDto.setData(resultReturnCollection);
        logger.debug(System.currentTimeMillis() - startTime);
        return outDto;
    }

    /**
     * 统一客户识别接口
     * @param inDto
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/getCustomerIdentify", method = RequestMethod.POST)
    public BasicOutDto getCustomerIdentify(@RequestBody CompanyCustomerDto inDto) throws Exception {
        long startTime = System.currentTimeMillis();

        BasicOutDto outDto = new BasicOutDto();
        CompanyCustomerDto companyCustomerDto = services.getCustomerIdentify(inDto);
        if (companyCustomerDto != null) {
            outDto.setCode(200);
            outDto.setMsg("成功");
            outDto.setData(companyCustomerDto);
        } else {
            outDto.setCode(404);
            outDto.setMsg("数据不存在");
        }
        logger.debug(System.currentTimeMillis() - startTime);
        return outDto;
    }

}
