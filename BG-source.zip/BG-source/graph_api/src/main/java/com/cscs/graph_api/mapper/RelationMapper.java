package com.cscs.graph_api.mapper;

import com.cscs.graph_api.domain.RelationQueryResult;
import com.cscs.graph_api.domain.RelationShipShow;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

/**
 * Created by wuchenglong on 2018/1/9.
 */
@SuppressWarnings("unused")
@Mapper
public interface RelationMapper {

    RelationMapper MAPPER = Mappers.getMapper(RelationMapper.class);

    @Mappings({
            @Mapping(source = "id",target = "id"),
            @Mapping(source = "type", target = "type"),
            @Mapping(source = "workPosition", target = "workPosition"),
            @Mapping(source = "investNum", target = "investNum"),
            @Mapping(source = "investShaRatio", target = "investShaRatio"),
            @Mapping(source = "controllerType", target = "controllerType"),
            @Mapping(source = "relativeType", target = "relativeType")

    })
    RelationShipShow QueryMapToRelationShipShow(RelationQueryResult relationQueryResult);


    @InheritInverseConfiguration
    RelationQueryResult RelationShipShowToQuery(RelationShipShow relationShipShow);
}
