package com.cscs.graph_api.mapper;

/**
 * Created by wuchenglong on 2018/1/8.
 */


//import com.cscs.graph_api.domain.FindRelationNodeShow;

import com.cscs.graph_api.domain.NodeQueryResult;
import com.cscs.graph_api.domain.NodeShow;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;


@SuppressWarnings("unused")
@Mapper
public interface NodePersonMapper {

    NodePersonMapper MAPPER = Mappers.getMapper(NodePersonMapper.class);

    @Mappings({
            @Mapping(target = "type", constant = "PERSON"),
            @Mapping(source = "PERSON_ID", target = "id"),
            @Mapping(source = "PERSON_NM", target = "name")
    })
    NodeShow QueryResultToNodeShow(NodeQueryResult nodeQueryResult);

    @InheritInverseConfiguration
    NodeQueryResult NodeShowToQueryResult(NodeShow nodeShow);
}
