package com.cscs.graph_api.controller;

import com.cscs.graph_api.Exception.InputException;
import com.cscs.graph_api.domain.ResultReturnCollection;
import com.cscs.graph_api.domain.ResultReturnCollectionNew;
import com.cscs.graph_api.dto.BasicInDto;
import com.cscs.graph_api.dto.BasicOutDto;
import com.cscs.graph_api.dto.ControllerInDto;
import com.cscs.graph_api.services.ControllerServices;
import net.sf.json.JSONArray;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.concurrent.TimeoutException;

@CrossOrigin
@RestController
@RequestMapping(value = "/relation")
public class Controller {

    private static Logger logger = LogManager.getLogger(Controller.class);

    @Autowired
    ControllerServices services;

    //返回疑似/实际控制人图谱，上市返回实际控制人，非上市返回疑似实际控制人
    @RequestMapping(value = "/searchController", method = RequestMethod.POST)
    public BasicOutDto searchController(@RequestBody BasicInDto inDto) throws Exception {
        long startTime = System.currentTimeMillis();
        if (inDto.getCompanyId() == null && Strings.isBlank(inDto.getCompanyNm())) throw new InputException();

        BasicOutDto outDto = new BasicOutDto();
        String company = (inDto.getCompanyId() != null) ? inDto.getCompanyId().toString() : inDto.getCompanyNm();

        ResultReturnCollectionNew resultReturnCollectionNew =services.getActController(company);

        if (resultReturnCollectionNew.getNodeShowsUniqueList().size() == 0) {
            outDto.setCode(404);
            outDto.setMsg("数据不存在");
        } else {
            outDto.setCode(200);
            outDto.setMsg("成功");
        }
        outDto.setData(resultReturnCollectionNew);
        logger.debug(System.currentTimeMillis() - startTime);
        return outDto;
    }


    //企业股东筛选
    @RequestMapping(value = "/searchControllerThreshold", method = RequestMethod.POST)
    public BasicOutDto searchControllerThreshold(@RequestBody ControllerInDto inDto) throws Exception {
        long startTime = System.currentTimeMillis();

        if (inDto.getCompanyId() == null && Strings.isBlank(inDto.getCompanyNm())) throw new InputException();
        if (inDto.sumRatio == 0) inDto.setSumRatio(5);
        if (inDto.sumRatio < 5 || inDto.sumRatio > 100) throw new InputException();
        BasicOutDto outDto = new BasicOutDto();

        MyThread t1 = new MyThread(inDto);
        t1.start();

        JSONArray content = new JSONArray();
        try {
            content = services.searchControllerThreshold(inDto);
            if (content.size() == 0) {
                Thread.sleep(2000);
                content = t1.getContent();
            }
        } catch (Exception e) {
            if (e instanceof TimeoutException) {
                content = t1.getContent();
            } else {
                throw e;
            }
        }
        if (content.size() == 0) {
            outDto.setCode(404);
            outDto.setMsg("数据不存在");
        } else {
            outDto.setCode(200);
            outDto.setMsg("成功");
        }
        outDto.setData(content);
        logger.debug(System.currentTimeMillis() - startTime);
        return outDto;
    }

    private class MyThread extends Thread {
        private ControllerInDto inDto;
        private JSONArray content;

        public MyThread(ControllerInDto inDto) {
            this.inDto = inDto;
        }

        public JSONArray getContent() {
            return content;
        }

        @Override
        public void run() {
            try {
                content = services.searchDefaultControllerThreshold(inDto);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}