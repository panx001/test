package com.cscs.graph_api.services.impl;

import com.cscs.graph_api.Util.Constants;
import com.cscs.graph_api.Util.CypherUtil;
import com.cscs.graph_api.Util.Map2Map;
import com.cscs.graph_api.domain.ResultReturn;
import com.cscs.graph_api.domain.ResultReturnCollection;
import com.cscs.graph_api.dto.PersonInDto;
import com.cscs.graph_api.mapper.QueryResultMapper;
import com.cscs.graph_api.services.PersonServices;
import org.apache.logging.log4j.util.Strings;
import org.neo4j.driver.v1.Record;
import org.neo4j.driver.v1.StatementResult;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class PersonServicesImpl implements PersonServices {
    @Override
    public ResultReturnCollection getPerson(PersonInDto inDto) throws Exception {
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();

        StringBuilder cypher = new StringBuilder();
        boolean chkCondetion = false;

        if (inDto.getCompanyId() != null && !Strings.isBlank(inDto.getCompanyNm())) chkCondetion = true;
        if (Strings.isBlank(inDto.getRelations())) inDto.setRelations("INVEST|WORK");

        cypher.append("MATCH path = (c:COMPANY{");
        if (inDto.getCompanyId() != null) cypher.append("COMPANY_ID:'" + inDto.getCompanyId() + "'");
        if (chkCondetion) cypher.append(",");
        if (!Strings.isBlank(inDto.getCompanyNm())) cypher.append("COMPANY_NM:'" + inDto.getCompanyNm() + "'");
        cypher.append("})-[:INVEST*..2]-(:COMPANY)\n");
        cypher.append("UNWIND NODES(path) as nodeList\n");
        cypher.append("WITH DISTINCT nodeList as node\n");
        cypher.append("MATCH P = (p:PERSON{PERSON_NM:'" + inDto.personNm + "'})-[:" + inDto.relations + "]->(node)\n");
        cypher.append(Constants.returnQuery);

        StatementResult result = new CypherUtil().execute(cypher.toString());
        Map<String, Object> sourceNodeInfo = new HashMap<>();
        while (result.hasNext()) {
            Record record = result.next();
            Map<String, Object> copiedMap = Map2Map.copyMap(record.asMap());

            if (sourceNodeInfo.size() == 0) {
                sourceNodeInfo = (Map<String, Object>) copiedMap.get("sourceNodeInfo");
            }
            ResultReturn resultReturn = new ResultReturn(
                    QueryResultMapper.MapNodeShowMapper(sourceNodeInfo),
                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) copiedMap.get("relationInfo")),
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("targetNodeInfo")));
            resultReturnCollection.add(resultReturn);
        }
        resultReturnCollection.updateElemtList();
        return resultReturnCollection;
    }
}
