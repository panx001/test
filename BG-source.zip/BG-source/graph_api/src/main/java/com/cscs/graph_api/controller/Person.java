package com.cscs.graph_api.controller;

import com.cscs.graph_api.Exception.InputException;
import com.cscs.graph_api.domain.ResultReturnCollection;
import com.cscs.graph_api.dto.BasicOutDto;
import com.cscs.graph_api.dto.PersonInDto;
import com.cscs.graph_api.services.PersonServices;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping(value = "/relation")
public class Person {

    private static Logger logger = LogManager.getLogger(Person.class);

    @Autowired
    private PersonServices services;

    @RequestMapping(value = "/searchPerson", method = RequestMethod.POST)
    public BasicOutDto searchPerson(@RequestBody PersonInDto inDto) throws Exception {
        long startTime = System.currentTimeMillis();

        if (inDto.getCompanyId() == null && Strings.isBlank(inDto.getCompanyNm())) throw new InputException();
        if (inDto.getPersonNm() == null) throw new InputException();

        BasicOutDto outDto = new BasicOutDto();
        ResultReturnCollection resultReturnCollection = services.getPerson(inDto);

        if (resultReturnCollection.getNodeShowsUniqueList().size() == 0) {
            outDto.setCode(404);
            outDto.setMsg("数据不存在");
        } else {
            outDto.setCode(200);
            outDto.setMsg("成功");
        }
        outDto.setData(resultReturnCollection);

        logger.debug(System.currentTimeMillis() - startTime);
        return outDto;
    }
}
