
package com.cscs.graph_api.services;

import com.cscs.graph_api.domain.ResultReturnCollection;
import com.cscs.graph_api.dto.CompanyCustomerDto;
import com.cscs.graph_api.dto.GroupFactionInDto;
import org.springframework.cache.annotation.Cacheable;


public interface GroupFactionServices {
    //集团派系 母公司
    @Cacheable(value = "relation", key = "targetClass.getName()+ methodName+#inDto.companyId + #inDto.companyNm + #inDto.layer + #inDto.returnType")
    ResultReturnCollection searchParentCompany(GroupFactionInDto inDto) throws Exception;

    //集团派系 母公司+子公司
    @Cacheable(value = "relation", key = "targetClass.getName()+ methodName+#inDto.companyId + #inDto.companyNm + #inDto.layer + #inDto.returnType")
    ResultReturnCollection searchSubCompany(GroupFactionInDto inDto) throws Exception;

    //集团派系 母公司+子公司+其他公司
    @Cacheable(value = "relation", key = "targetClass.getName()+ methodName+#inDto.companyId + #inDto.companyNm + #inDto.layer + #inDto.returnType")
    ResultReturnCollection searchGroupFactionAll(GroupFactionInDto inDto) throws Exception;

    /**
     * 同一客户识别接口
     * @param inDto
     * @return
     * @throws Exception
     */
    CompanyCustomerDto getCustomerIdentify(CompanyCustomerDto inDto) throws Exception;
}