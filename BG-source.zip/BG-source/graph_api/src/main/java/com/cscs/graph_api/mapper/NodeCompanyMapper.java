package com.cscs.graph_api.mapper;
/**
 * Created by wuchenglong on 2018/1/8.
 */


import com.cscs.graph_api.domain.NodeQueryResult;
import com.cscs.graph_api.domain.NodeShow;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;


@SuppressWarnings("unused")
@Mapper
public interface NodeCompanyMapper {

    NodeCompanyMapper MAPPER = Mappers.getMapper(NodeCompanyMapper.class);

    @Mappings({
            @Mapping(target = "type", constant = "COMPANY"),
            @Mapping(source = "COMPANY_ID", target = "id"),
            @Mapping(source = "COMPANY_NM", target = "name"),
            @Mapping(source = "REG_CAPITAL", target = "reg_capital"),
            @Mapping(source = "IS_LISTED", target = "is_listed"),
            @Mapping(source = "ORGNUM", target = "orgnum"),
            @Mapping(source = "STATUS", target = "status"),
            @Mapping(source = "SECURITY_CD", target = "security_cd"),
            @Mapping(source = "LINK_ID", target = "link_id"),
            @Mapping(source = "LABELS", target = "labels"),
            @Mapping(source = "RISK_LIST", target = "risk_list"),
            @Mapping(source = "COMPANY_TYPE", target = "company_type"),
            @Mapping(source = "GROUPPOS", target = "groupPos")
    })
    NodeShow QueryResultToNodeShow(NodeQueryResult nodeQueryResult);


    @InheritInverseConfiguration
    NodeQueryResult NodeShowToQueryResult(NodeShow nodeShow);

}
