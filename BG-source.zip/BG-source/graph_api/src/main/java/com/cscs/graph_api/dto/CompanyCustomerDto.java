package com.cscs.graph_api.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CompanyCustomerDto implements Serializable{
    /**
     * 统一社会信用代码
     */
    private String creditCode;

    /**
     * 机构名称
     */
    private String companyName;
    /**
     * 企业标识符
     */
    private String companyId;
    /**
     * 清洗后的企业名
     */
    private String clensCompanyNm;
    /**
     * 法定代表人
     */
    private String legalPersonName;
    /**
     * 成立日期
     */
    private String foundDt;
    /**
     * 注册资本
     */
    private String regCapital;
    /**
     * 注册地址
     */
    private String regInstitute;
    /**
     * 工商注册号
     */
    private String blnumb;
    /**
     * 组织机构代码
     */
    private String orgNumber;
    /**
     * 公司状态
     */
    private String companySt;

    /**
     * 查询命中的参数
     */
    private String hitParam;

    public String getCreditCode() {
        return creditCode;
    }

    public void setCreditCode(String creditCode) {
        this.creditCode = creditCode;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getClensCompanyNm() {
        return clensCompanyNm;
    }

    public void setClensCompanyNm(String clensCompanyNm) {
        this.clensCompanyNm = clensCompanyNm;
    }

    public String getLegalPersonName() {
        return legalPersonName;
    }

    public void setLegalPersonName(String legalPersonName) {
        this.legalPersonName = legalPersonName;
    }

    public String getFoundDt() {
        return foundDt;
    }

    public void setFoundDt(String foundDt) {
        this.foundDt = foundDt;
    }

    public String getRegCapital() {
        return regCapital;
    }

    public void setRegCapital(String regCapital) {
        this.regCapital = regCapital;
    }

    public String getRegInstitute() {
        return regInstitute;
    }

    public void setRegInstitute(String regInstitute) {
        this.regInstitute = regInstitute;
    }

    public String getBlnumb() {
        return blnumb;
    }

    public void setBlnumb(String blnumb) {
        this.blnumb = blnumb;
    }

    public String getOrgNumber() {
        return orgNumber;
    }

    public void setOrgNumber(String orgNumber) {
        this.orgNumber = orgNumber;
    }

    public String getCompanySt() {
        return companySt;
    }

    public void setCompanySt(String companySt) {
        this.companySt = companySt;
    }

    public String getHitParam() {
        return hitParam;
    }

    public void setHitParam(String hitParam) {
        this.hitParam = hitParam;
    }
}
