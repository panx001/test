package com.cscs.graph_api.domain;


import com.cscs.graph_api.Util.UseFulFunc;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import net.sf.json.JSONObject;

import java.text.DecimalFormat;
import java.util.Objects;

/**
 * Created by wuchenglong on 2018/1/8.
 */

@SuppressWarnings("unused")
public class RelationShipShow {

    private String id;
    @JsonProperty("relationType")
    private String type;
    private String sourceId;
    private String targetId;

    @JsonIgnore
    private String investShaRatio;
    @JsonIgnore
    private String investNum;
    @JsonIgnore
    private String workPosition;
    @JsonIgnore
    private String controllerType;
    @JsonIgnore
    private String relativeType;


    @JsonProperty("property")
    private JSONObject property = new JSONObject();

    public RelationShipShow() {
    }

    public void infoUpdate() {
        if (this.sourceId == null || this.targetId == null) return;
//        this.id = this.sourceId + "-" + this.type + "-" + this.targetId;

        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("INVEST", "0"))) {
            DecimalFormat df = new DecimalFormat("0.##");
            Float sha_ratio = Float.parseFloat(df.format(Float.parseFloat(this.investShaRatio.toString().replace("%", ""))));
            property.put("investShaRatio", this.investShaRatio != null && (sha_ratio <= 100) ? sha_ratio : 0);
            property.put("investNum", investNum);
            return;
        }
        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("WORK", "0"))) {
            property.put("workPosition", workPosition);
            return;
        }
        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("CONTROLLER", "0"))) {
            property.put("controllerType", controllerType);
            return;
        }
        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("RELATIVE", "0"))) {
            property.put("relativeType", relativeType);
            return;
        }


//        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("ISSUE", "0"))) {
//            this.nexus = "发行";
//            property.put("work_position",work_position);
//            return;
//        }
//        //以下四类关系应该在图谱中不出现，只出现在找关系中
//        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("BRANCH", "0"))) {
//            this.nexus = "分支机构";
//            return;
//        }
//        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("CLASSMATESUS", "0"))) {
//            this.nexus = "疑似同学";
//            return;
//        }
//        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("ADDRESSSIM", "0"))) {
//            this.nexus = "相似地址";
//            return;
//        }
//        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("COLLEAGUESUS", "0"))) {
//            this.nexus = "疑似同事";
//            return;
//        }
//        //控制人关系只出现在疑似/实际控制人接口中
//        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("CONTROLLER", "0"))) {
//            this.nexus = "控股";
//            return;
//        }
//
//        //私募相关关系
//        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("MANAGER", "0"))) {
//            this.nexus = "管理方";
//            return;
//        }
//        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("TRUSTEE", "0"))) {
//            this.nexus = "托管方";
//            return;
//        }
//        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("", "0"))) {
//            this.nexus = this.sc_relation_type;
//            return;
//        }
//        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("GUARANTEE", "0"))) {
//            if (this.guar_info != null) {
//                JSONArray jsonArray = JSONArray.fromObject(this.guar_info);
//                JSONArray results = new JSONArray();
//                for (int i = 0; i < jsonArray.size(); i++) {
//                    HashedMap result = new HashedMap();
//                    result.put("money", jsonArray.getJSONObject(i).getString("GUAR_AMT"));
//                    result.put("guar_end_date", jsonArray.getJSONObject(i).getString("GUAR_END_DT"));
//                    results.add(result);
//                }
//                this.nexus = results;
//            } else {
//                this.nexus = "担保";
//            }
//            return;
//        }
//        if (this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("SUPPLIER", "0")) ||
//                this.getType().equals(UseFulFunc.RELATION_TYPE_MAP.getOrDefault("CUSTOMER", "0"))
//                ) {
//            this.nexus = this.sc_relation_type;
//            return;
//        }
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    public String getTargetId() {
        return targetId;
    }

    public void setTargetId(String targetId) {
        this.targetId = targetId;
    }

    public String getInvestShaRatio() {
        return investShaRatio;
    }

    public void setInvestShaRatio(String investShaRatio) {
        this.investShaRatio = investShaRatio;
    }

    public String getInvestNum() {
        return investNum;
    }

    public void setInvestNum(String investNum) {
        this.investNum = investNum;
    }

    public String getWorkPosition() {
        return workPosition;
    }

    public void setWorkPosition(String workPosition) {
        this.workPosition = workPosition;
    }

    public String getControllerType() {
        return controllerType;
    }

    public void setControllerType(String controllerType) {
        this.controllerType = controllerType;
    }

    public String getRelativeType() {
        return relativeType;
    }

    public void setRelativeType(String relativeType) {
        this.relativeType = relativeType;
    }

    public JSONObject getProperty() {
        return property;
    }

    public void setProperty(JSONObject property) {
        this.property = property;
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RelationShipShow that = (RelationShipShow) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id);
    }
}
