package com.cscs.graph_api.controller;

import com.cscs.graph_api.Exception.InputException;
import com.cscs.graph_api.domain.ResultReturnCollection;
import com.cscs.graph_api.dto.BasicOutDto;
import com.cscs.graph_api.dto.RelationInDto;
import com.cscs.graph_api.services.RelationServices;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping(value = "/relation")
public class Relation {

    private static Logger logger = LogManager.getLogger(Relation.class);

    @Autowired
    private RelationServices services;

    @RequestMapping(value = "/searchRelation", method = RequestMethod.POST)
    public BasicOutDto searchRelationOld(@RequestBody Map inData) throws Exception {
        long startTime = System.currentTimeMillis();

        if (inData.isEmpty() || !inData.containsKey("keyWords")) throw new InputException();
        List<String> keyWordList = (List) inData.get("keyWords");
        if (keyWordList.size() == 0) throw new InputException();
        int index = (keyWordList.size() > 4) ? 4 : keyWordList.size();
        List dataList = keyWordList.subList(0, index);

        String keyword = "";
        for (int i = 0; i < dataList.size(); i++) {
            String label = keyWordList.get(i);
            if (Strings.isBlank(label)) throw new InputException();
            if (!label.substring(0, 1).equalsIgnoreCase("c")
                    && !label.substring(0, 1).equalsIgnoreCase("p")) {
                throw new InputException();
            }
            keyword += label;
        }

        BasicOutDto outDto = new BasicOutDto();
        ResultReturnCollection resultReturnCollection = services.getRelationOld(dataList, keyword);

        if (resultReturnCollection.getNodeShowsUniqueList().size() == 0) {
            outDto.setCode(404);
            outDto.setMsg("数据不存在");
        } else {
            outDto.setCode(200);
            outDto.setMsg("成功");
        }
        outDto.setData(resultReturnCollection);

        logger.debug(System.currentTimeMillis() - startTime);
        return outDto;
    }


    @RequestMapping(value = "/searchRelationV2", method = RequestMethod.POST)
    public BasicOutDto searchRelation(@RequestBody RelationInDto inDto) throws Exception {
        long startTime = System.currentTimeMillis();

        if (inDto.layer == null) inDto.setLayer(3);
        if (inDto.layer < 1 || inDto.layer > 10) throw new InputException();

        if (Strings.isBlank(inDto.getRelations())) inDto.setRelations("INVEST|WORK");


        if (inDto.maxPath == null) inDto.setMaxPath(20);
        if (inDto.maxPath < 1) throw new InputException();

        if (inDto.getKeyWords().size()<=1 || inDto.getKeyWords().size()>4) throw new InputException();


        ArrayList keyWordList = inDto.getKeyWords();

        for (int i = 0; i < keyWordList.size(); i++){
            if (keyWordList.get(i) instanceof java.util.List && ((List) keyWordList.get(i)).size()!=2)
                throw new InputException();
        }

//        ArrayList keyWordList = inDto.getKeyWords();

        BasicOutDto outDto = new BasicOutDto();
        ResultReturnCollection resultReturnCollection;

        if (inDto.layer <=3){
            resultReturnCollection = services.getRelation(inDto);
        } else {
            resultReturnCollection = services.getRelationShortestPath(inDto);
        }

        if (resultReturnCollection.getNodeShowsUniqueList().size() == 0) {
            outDto.setCode(404);
            outDto.setMsg("数据不存在");
        } else {
            outDto.setCode(200);
            outDto.setMsg("成功");
        }
        outDto.setData(resultReturnCollection);

        logger.debug(System.currentTimeMillis() - startTime);
        return outDto;
    }
}
