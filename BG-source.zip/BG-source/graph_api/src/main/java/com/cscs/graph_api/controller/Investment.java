package com.cscs.graph_api.controller;

import com.cscs.graph_api.Exception.InputException;
import com.cscs.graph_api.domain.ResultReturnCollection;
import com.cscs.graph_api.dto.BasicOutDto;
import com.cscs.graph_api.dto.InvestFilterInDto;
import com.cscs.graph_api.dto.InvestmentInDto;
import com.cscs.graph_api.services.InvestmentServices;
import net.sf.json.JSONArray;
import org.apache.commons.lang.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping(value = "/relation")
public class Investment {

    private static Logger logger = LogManager.getLogger(Investment.class);

    @Autowired
    private InvestmentServices services;

    //对外投资和股东查找
    @RequestMapping(value = "/searchInvestment", method = RequestMethod.POST)
    public BasicOutDto searchInvestment(@RequestBody InvestmentInDto inDto) throws Exception {
        long startTime = System.currentTimeMillis();

        if (inDto.getCompanyId() == null && Strings.isBlank(inDto.getCompanyNm())) throw new InputException();
//        if (inDto.getInvestLayer() < 0 || inDto.getShareholderLayer() < -1) throw new InputException();
        if (inDto.getInvestLayer() < 0 || inDto.getShareholderLayer() < 0) throw new InputException();
        if (inDto.shareholderLayer > 5) inDto.shareholderLayer = 1;
        if (inDto.investLayer > 5) inDto.investLayer = 1;

        BasicOutDto outDto = new BasicOutDto();
        ResultReturnCollection resultReturnCollection = services.getShareholderAndInvest(inDto);

        if (resultReturnCollection.getNodeShowsUniqueList().size() == 0) {
            outDto.setCode(404);
            outDto.setMsg("数据不存在");
        } else {
            outDto.setCode(200);
            outDto.setMsg("成功");
        }
        outDto.setData(resultReturnCollection);

        logger.debug(System.currentTimeMillis() - startTime);
        return outDto;
    }


    //对外投资企业筛选
    @RequestMapping(value = "/searchInvestFilter", method = RequestMethod.POST)
    public BasicOutDto searchInvestFilter(@RequestBody InvestFilterInDto inDto) throws Exception {
        long startTime = System.currentTimeMillis();

        if (inDto.getCompanyId() == null && Strings.isBlank(inDto.getCompanyNm()))
            throw new InputException();

        if (inDto.leftBound == null || inDto.rightBound == null)  throw new InputException();
        if (inDto.leftBound < 0 || inDto.leftBound > 100 || inDto.rightBound < 0 || inDto.rightBound > 100)
            throw new InputException();
        if (inDto.leftBound > inDto.rightBound)
            throw new InputException();

        if (inDto.containRB == 0) inDto.setContainRB(0);
        if (inDto.containRB != 0 && inDto.containRB != 1)
            throw new InputException();

        BasicOutDto outDto = new BasicOutDto();
        JSONArray content = new JSONArray();

        if (inDto.containRB == 0) {
            if (inDto.leftBound.equals(inDto.rightBound)) {
                content = services.searchInvestFilterContainRB(inDto);                    //左闭右闭，需要考虑左右边界一致的情况  包含右边界
            } else {
                content = services.searchInvestFilterUnContainRB(inDto);                    // 不包含右边界   不包含右边界
            }
        }

        if (inDto.containRB == 1) {
            content = services.searchInvestFilterContainRB(inDto);                        //左闭右闭    包含右边界
        }

        if (content.size() == 0) {
            outDto.setCode(404);
            outDto.setMsg("数据不存在");
        } else {
            outDto.setCode(200);
            outDto.setMsg("成功");
        }

        outDto.setData(content);
        logger.debug(System.currentTimeMillis() - startTime);
        return outDto;
    }

}
