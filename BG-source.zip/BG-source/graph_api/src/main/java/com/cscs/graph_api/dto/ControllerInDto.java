package com.cscs.graph_api.dto;

public class ControllerInDto extends BasicInDto {

    //累计持股比例返回阈值
    public double sumRatio;

    public double getSumRatio() {
        return sumRatio;
    }

    public void setSumRatio(double sumRatio) {
        this.sumRatio = sumRatio;
    }
}
