package com.cscs.graph_api.services.impl;

import com.cscs.graph_api.Util.Constants;
import com.cscs.graph_api.Util.CypherUtil;
import com.cscs.graph_api.Util.Map2Map;
import com.cscs.graph_api.domain.ResultReturn;
import com.cscs.graph_api.domain.ResultReturnCollection;
import com.cscs.graph_api.dto.InvestFilterInDto;
import com.cscs.graph_api.dto.InvestmentInDto;
import com.cscs.graph_api.mapper.QueryResultMapper;
import com.cscs.graph_api.services.InvestmentServices;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.logging.log4j.util.Strings;
import org.neo4j.driver.v1.Record;
import org.neo4j.driver.v1.StatementResult;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class InvestmentServicesImpl implements InvestmentServices {

    @Override
    public ResultReturnCollection getShareholderAndInvest(InvestmentInDto inDto) throws Exception {
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();

        StringBuilder cypher = new StringBuilder();
        boolean chkCondetion = false;
        if (inDto.getCompanyId() != null && !Strings.isBlank(inDto.getCompanyNm())) chkCondetion = true;

        cypher.append("MATCH p1 = (A1:COMPANY{");
        if (inDto.getCompanyId() != null) cypher.append("COMPANY_ID:'" + inDto.getCompanyId() + "'");
        if (chkCondetion) cypher.append(",");
        if (!Strings.isBlank(inDto.getCompanyNm())) cypher.append("COMPANY_NM:'" + inDto.getCompanyNm() + "'");

        if (inDto.getInvestLayer() == 0 && inDto.getShareholderLayer() == 0) {
            cypher.append("})-[r1:INVEST" + "*..1]-(d1) " + "with p1 AS P\n" + Constants.returnQuery);
        }

        if (inDto.getInvestLayer() != 0 && inDto.getShareholderLayer() == 0) {
            cypher.append("})-[r1:INVEST" + "*.." + inDto.investLayer + "]->(d1) " + "with p1 AS P\n" + Constants.returnQuery);
        }

        if (inDto.getInvestLayer() == 0 && inDto.getShareholderLayer() != 0) {
            if (inDto.getShareholderLayer() == -1) {
                cypher.append("})<-[r1:INVEST" + "*..1]-(d1) " + "with p1 AS P\n" + Constants.returnQuery);
            } else {
                cypher.append("})<-[r1:INVEST" + "*.." + inDto.shareholderLayer + "]-(d1) " + "with p1 AS P\n" + Constants.returnQuery);
            }
        }

        if (inDto.getInvestLayer() != 0 && inDto.getShareholderLayer() != 0) {
            cypher.append("})-[r1:INVEST" + "*.." + inDto.investLayer + "]->(d1) with collect(p1) AS path1 \n");

            if (inDto.getShareholderLayer() == -1) {
                cypher.append("MATCH p2 = (A2:COMPANY{");
                if (inDto.getCompanyId() != null) cypher.append("COMPANY_ID:'" + inDto.getCompanyId() + "'");
                if (chkCondetion) cypher.append(",");
                if (!Strings.isBlank(inDto.getCompanyNm()))
                    cypher.append("COMPANY_NM:'" + inDto.getCompanyNm() + "'");
                cypher.append("})<-[r2:INVEST" + "*..1]-(d2) with path1,collect(p2) AS path2 \n");
                cypher.append("with path1+path2 as path\n" +

                        "unwind path as P\n " + Constants.returnQuery);
            } else {
                cypher.append("MATCH p2 = (A2:COMPANY{");
                if (inDto.getCompanyId() != null) cypher.append("COMPANY_ID:'" + inDto.getCompanyId() + "'");
                if (chkCondetion) cypher.append(",");
                if (!Strings.isBlank(inDto.getCompanyNm()))
                    cypher.append("COMPANY_NM:'" + inDto.getCompanyNm() + "'");
                cypher.append("})<-[r2:INVEST" + "*.." + inDto.shareholderLayer + "]-(d2) with path1,collect(p2) AS path2 \n");
                cypher.append("with path1+path2 as path\n" +
                        "unwind path as P\n " + Constants.returnQuery);
            }
        }

        StatementResult result = new CypherUtil().execute(cypher.toString());
        while (result.hasNext()) {
            Record record = result.next();
            Map<String, Object> copiedMap = Map2Map.copyMap(record.asMap());

            ResultReturn resultReturn = new ResultReturn(
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("sourceNodeInfo")),
                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) copiedMap.get("relationInfo")),
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("targetNodeInfo")));
            resultReturnCollection.add(resultReturn);
        }
        resultReturnCollection.updateElemtList();
        return resultReturnCollection;
    }

    //对外投资筛选接口  不包含右边界
    @Override
    public JSONArray searchInvestFilterUnContainRB(InvestFilterInDto inDto) throws Exception {
        JSONArray contentArray = new JSONArray();
        StringBuilder cypher = new StringBuilder();
        cypher.append("MATCH (C:COMPANY{");
        if (inDto.companyId != null) {
            cypher.append("COMPANY_ID:\"" + inDto.companyId + "\"");
        } else {
            cypher.append("COMPANY_NM:\"" + inDto.companyNm + "\"");
        }
        cypher.append("})-[R:INVEST]->(D)\n");
        cypher.append("where " + inDto.leftBound + "\n" +
                "<=tofloat(R.SHA_RATIO)<" + inDto.rightBound + "\n" +
                "return distinct \n" +
                "      CASE \n" +
                "        WHEN 'COMPANY' IN LABELS(D) \n" +
                "        THEN D.COMPANY_NM \n" +
                "        ELSE D.SECINNER_NM  \n" +
                "        END AS companyName,\n" +
                "      CASE \n" +
                "        WHEN 'COMPANY' IN LABELS(D) \n" +
                "        THEN D.COMPANY_ID \n" +
                "        ELSE D.SECINNER_ID  \n" +
                "        END AS companyId,\n" +
                "CASE WHEN 'COMPANY' IN LABELS(D) THEN D.REG_CAPITAL END AS regCapital,\n" +
                "CASE WHEN 'COMPANY' IN LABELS(D) THEN D.STATUS END AS status,\n" +
                "CASE WHEN 'COMPANY' IN LABELS(D) THEN D.ORGNUM END AS orgnum,\n" +
                "        tofloat(R.SHA_RATIO) as investRatio order by investRatio desc");

        StatementResult result = new CypherUtil().execute(cypher.toString());
        while (result.hasNext()) {
            JSONObject content = addInvestFilter(result.next());
            contentArray.add(content);
        }
        return contentArray;
    }

    //对外投资筛选接口  包含右边界
    @Override
    public JSONArray searchInvestFilterContainRB(InvestFilterInDto inDto) throws Exception {
        JSONArray contentArray = new JSONArray();
        StringBuilder cypher = new StringBuilder();
        cypher.append("MATCH (C:COMPANY{");
        if (inDto.companyId != null) {
            cypher.append("COMPANY_ID:\"" + inDto.companyId + "\"");
        } else {
            cypher.append("COMPANY_NM:\"" + inDto.companyNm + "\"");
        }
        cypher.append("})-[R:INVEST]->(D)\n");
        cypher.append("where " + inDto.leftBound + "\n" +
                "<=tofloat(R.SHA_RATIO)<=" + inDto.rightBound + "\n" +
                "return distinct \n" +
                "      CASE \n" +
                "        WHEN 'COMPANY' IN LABELS(D) \n" +
                "        THEN D.COMPANY_NM \n" +
                "        ELSE D.SECINNER_NM  \n" +
                "        END AS companyName,\n" +
                "      CASE \n" +
                "        WHEN 'COMPANY' IN LABELS(D) \n" +
                "        THEN D.COMPANY_ID \n" +
                "        ELSE D.SECINNER_ID  \n" +
                "        END AS companyId,\n" +
                "CASE WHEN 'COMPANY' IN LABELS(D) THEN D.REG_CAPITAL END AS regCapital,\n" +
                "CASE WHEN 'COMPANY' IN LABELS(D) THEN D.STATUS END AS status,\n" +
                "CASE WHEN 'COMPANY' IN LABELS(D) THEN D.ORGNUM END AS orgnum,\n" +
                "        tofloat(R.SHA_RATIO) as investRatio order by investRatio desc");

        StatementResult result = new CypherUtil().execute(cypher.toString());
        while (result.hasNext()) {
            JSONObject content = addInvestFilter(result.next());
            contentArray.add(content);
        }
        return contentArray;
    }


    private JSONObject addInvestFilter(Record record) {
        JSONObject content = new JSONObject();
        Map item = record.asMap();
        content.put("companyName", item.get("companyName"));
        content.put("companyId", item.get("companyId"));
        content.put("investRatio", item.get("investRatio"));
        content.put("regCapital", item.get("regCapital"));
        content.put("status", item.get("status"));
        content.put("orgnum", item.get("orgnum"));
        return content;
    }

}
