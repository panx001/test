package com.cscs.graph_api.mapper;

import com.cscs.graph_api.Util.Map2Obj;
import com.cscs.graph_api.domain.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.sound.sampled.Line;
import java.util.Map;

/**
 * Created by wuchenglong on 2018/1/9.
 */
public class QueryResultMapper {
    private static Logger logger = LogManager.getLogger(QueryResultMapper.class);

    public QueryResultMapper() {
    }

    public static NodeShow MapNodeShowMapper(Map<String, Object> map) {
        try {
            if(map.size() == 0) return new NodeShow();
            return NodeQueryResultNodeShowMapper((NodeQueryResult) Map2Obj.map2Obj(map, NodeQueryResult.class));
        } catch (Exception e) {
            return new NodeShow();
        }
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    private static NodeShow NodeQueryResultNodeShowMapper(NodeQueryResult nodeQueryResult) {
        if (nodeQueryResult.getCOMPANY_NM() != null) {
            return NodeCompanyMapper.MAPPER.QueryResultToNodeShow(nodeQueryResult);
        } else if (nodeQueryResult.getSECURITY_ID() != null) {
            return NodeSecurityMapper.MAPPER.QueryResultToNodeShow(nodeQueryResult);
        } else if (nodeQueryResult.getPERSON_ID() != null) {
            return NodePersonMapper.MAPPER.QueryResultToNodeShow(nodeQueryResult);
        } else {
            return new NodeShow();
        }
    }

    //info mapper
    public static InfoShow MapInfoShowMapper(Map<String, Object> map) {
        try {
            return InfoQueryResultInfoShowMapper((InfoQueryResult) Map2Obj.map2Obj(map,InfoQueryResult.class));
        } catch (Exception e) {
            return new InfoShow();
        }
    }


    private static InfoShow InfoQueryResultInfoShowMapper(InfoQueryResult infoQueryResult) {
        if (infoQueryResult.getCONTROLLER_ID() != null) {
            return InfoMapper.MAPPER.QueryResultToInfoShow(infoQueryResult);
        } else {
            return new InfoShow();
        }
    }


    public static RelationShipShow MapRelationShipShowMapper(Map<String, Object> map) {
        try {
            if(map.size() == 0) return new RelationShipShow();
            return ResultRelationShipShowMapper(
                    (RelationQueryResult) Map2Obj.map2Obj(map, RelationQueryResult.class));
        } catch (Exception e) {
            return new RelationShipShow();
        }
    }

    private static RelationShipShow ResultRelationShipShowMapper(RelationQueryResult relationQueryResult) {
        return RelationMapper.MAPPER.QueryMapToRelationShipShow(relationQueryResult);
    }
}
