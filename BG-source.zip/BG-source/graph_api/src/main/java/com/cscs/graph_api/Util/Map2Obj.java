package com.cscs.graph_api.Util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by wuchenglong on 2018/1/8.
 */

@SuppressWarnings("unused")
public class Map2Obj {
    private static Logger logger = LogManager.getLogger(Map2Obj.class);

    public static Object mapToObject(Map<String, Object> map, Class<?> beanClass)
            throws Exception {
        if (map == null)
            return null;
        Object obj = beanClass.newInstance();
        org.apache.commons.beanutils.BeanUtils.populate(obj, map);
        return obj;
    }


    public static Object map2Obj(Map<String, Object> map, Class<?> beanClass) throws Exception {
        if (map == null || map.size() <= 0)
            return null;
        Object obj = beanClass.newInstance();
        //获取关联的所有类，本类以及所有父类
        boolean ret = true;
        Class oo = obj.getClass();
        List<Class> clazzs = new ArrayList<Class>();
        while (ret) {
            clazzs.add(oo);
            oo = oo.getSuperclass();
            if (oo == null || oo == Object.class)
                break;
        }

        for (int i = 0; i < clazzs.size(); i++) {
            Field[] fields = clazzs.get(i).getDeclaredFields();
            for (Field field : fields) {
                int mod = field.getModifiers();
                if (Modifier.isStatic(mod) || Modifier.isFinal(mod)) {
                    continue;
                }
                String fieldName = field.getName();

                if (!map.containsKey(fieldName) || map.get(fieldName) == null) {
                    continue;
                }
                //由字符串转换回对象对应的类型
                if (field != null) {
                    field.setAccessible(true);
                    String name = field.getType().getName();
                    // logger.debug(name);
                    // logger.debug(fieldName);
                    // logger.debug(map.get(fieldName));
                    switch (name) {
                        case "java.lang.String":
                            //字段需要public 修饰
                            field.set(obj, map.get(fieldName).toString());
                            break;
                        case "int":
                        case "java.lang.Integer":
                            field.set(obj, Integer.parseInt(map.get(fieldName).toString()));
                            break;
                        case "boolean":
                        case "java.lang.Boolean":
                            field.set(obj, Boolean.parseBoolean(map.get(fieldName).toString()));
                            break;
                        case "long":
                        case "java.lang.Long":
                            field.set(obj, Long.parseLong(map.get(fieldName).toString()));
                            break;
                        case "double":
                        case "java.lang.Double":
                            field.set(obj, Double.parseDouble(map.get(fieldName).toString()));
                            break;
                        default:
                            //字段是个对象，递归
                            field.set(obj, map.get(field.getName()));
                    }

                }
            }
        }
        return obj;
    }


    // public static Object map2Obj1(Map<String, Object> value, Class<?> beanClass) {
    //     logger.debug(1111);
    //     if (beanClass == null) {
    //         return null;
    //     }
    //     logger.debug(1111);
    //     // 获取实体类的所有属性，返回Field数组
    //     Field[] fields = beanClass.getFields();
    //     for (Field field : fields) {
    //         logger.debug(field);
    //         logger.debug(field.getName());
    //     }
    //     logger.debug(1111);
    //     Object obj = null;
    //     try {
    //         obj = beanClass.newInstance();
    //         for (Field field : fields) {
    //             String fieldName = field.getName();
    //             logger.debug(fieldName);
    //             if (!value.containsKey(fieldName)){
    //                 logger.debug(fieldName + "  not contains ");
    //                 continue;
    //             }
    //             field.setAccessible(true);
    //             String name = field.getType().getName();
    //             logger.debug(name + " : "+fieldName);
    //             switch (name){
    //                 case "java.lang.String":
    //                     //字段需要public 修饰
    //                     field.set(obj,(String)value.get(fieldName));
    //                     break;
    //                 case "int":
    //                 case "java.lang.Integer":
    //                     field.setInt(obj,(Integer)value.get(fieldName));
    //                     break;
    //                 case "boolean":
    //                 case "java.lang.Boolean":
    //                     field.setBoolean(obj,(Boolean)value.get(fieldName));
    //                     break;
    //                 case "long":
    //                 case "java.lang.Long":
    //                     field.setLong(obj,(Long)value.get(fieldName));
    //                     break;
    //                 case "double":
    //                 case "java.lang.Double":
    //                     field.setDouble(obj,(Double) value.get(fieldName));
    //                     break;
    //                 default:
    //                     //字段是个对象，递归
    //                     field.set(obj, value.get(field.getName()));
    //             }
    //         }
    //     } catch (Exception e) {
    //         logger.debug(e);
    //     }
    //     return obj;
    // }
}
