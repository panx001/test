package com.cscs.graph_api.repositories;

/**
 * Created by wuchenglong on 2018/1/3.
 */

import com.cscs.graph_api.Util.Constants;
import org.neo4j.ogm.response.model.QueryResultModel;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "object", path = "object")
public interface ControllerRepository extends Neo4jRepository<Object, Long> {

    //判断是否是公开企业，是的话直接取实际控制人，不是的话取疑似实际控制人  通过公司ID
    @Query("MATCH (A:COMPANY{COMPANY_ID:{company_id}}) " +
            "<-[r:CONTROLLER{RELATION_TYPE:'实际控制人'}]-(d) where exists(d.PERSON_NM) or exists(d.COMPANY_NM) return 1 limit 1")
    QueryResultModel JudgeCompanyTpye(@Param("company_id") String company_id);

    //疑似实际控制人图谱
    @Query("MATCH (C:COMPANY{COMPANY_ID:{company_id}})<-[R:INVEST]-(P) " +
            "WITH C,P AS CC1 ORDER BY tofloat(coalesce(R.SHA_RATIO, 0)) DESC , tofloat(coalesce(R.NUM, 0)) DESC LIMIT 5  " +
            "MATCH (C)<-[:INVEST]-(CC1)<-[:INVEST*0..4]-(P) " +
            "WHERE P:PERSON OR (P)-[:CONTROLLER{RELATION_TYPE:'实际控制人'}]->(:COMPANY) OR NOT (P)<-[:INVEST]-() " +
            "WITH DISTINCT C,P MATCH path = (P)-[:INVEST*..5]->(C) " +
            "WITH C,P,COLLECT([p in rels(path)|CASE WHEN p.SHA_RATIO IS NOT NULL THEN tofloat(p.SHA_RATIO)*0.01 " +
            "WHEN p.SHA_RATIO IS NULL AND p.NUM IS NOT NULL AND apoc.cscs.getRegCapital(p) <> 0 THEN tofloat(p.NUM)/apoc.cscs.getRegCapital(p) ELSE 0 END]) AS paths," +
            "COLLECT([p in rels(path)|startNode(p).COMPANY_NM]) AS pathsNm " +
            "CALL apoc.cscs.filterPaths(paths) yield path WITH C,P,COLLECT(path) AS paths,pathsNm " +
            "UNWIND  RANGE(0,LENGTH(paths)-1) AS pathsindex  UNWIND RANGE(0,LENGTH(paths[pathsindex])-1) as valuesIndex  " +
            "WITH C,P, pathsindex,paths[pathsindex] AS values,apoc.agg.product(paths[pathsindex][valuesIndex]) as p ,paths as pathValue,pathsNm " +
            "WITH C,P,pathValue,COLLECT(p) AS pValues,pathsNm WITH C,P, " +
            "CASE WHEN 'COMPANY' IN LABELS(P) THEN P.COMPANY_NM ELSE P.PERSON_NM  END AS CONTROLLER_NM ,pathValue,pValues," +
            "apoc.coll.sum(pValues) AS totalValue,pathsNm with C,collect({CONTROLLER_NM:CONTROLLER_NM ,totalValue:toString(totalValue)}) as resultlist " +
            "CALL apoc.cscs.chooseActualController(resultlist) yield controllernm WITH C,controllernm " +
            "MATCH CP = (P)-[:INVEST|CONTROLLER*..5]->(C) where P.COMPANY_NM = controllernm or P.PERSON_NM = controllernm with CP as P " + Constants.returnQuery)
    QueryResultModel getSuspActControllerByCompanyId(@Param("company_id") String company_id);

    //直接取实际控制人
    @Query("MATCH (C:COMPANY{COMPANY_ID:{company_id}})<-[:CONTROLLER{RELATION_TYPE:'实际控制人'}]-(P) " +
            "WITH C,CASE WHEN 'COMPANY' IN LABELS(P) THEN P.COMPANY_NM ELSE P.PERSON_NM END as controllernm " +
            "MATCH CP = (P)-[:INVEST|CONTROLLER*..5]->(C) where P.COMPANY_NM = controllernm or P.PERSON_NM = controllernm with CP as P " + Constants.returnQuery)
    QueryResultModel getActControllerByCompanyId(@Param("company_id") String company_id);


    //实控人公示信息添加 通过company_id
    @Query("match path=(A:COMPANY{COMPANY_ID:{company_id}})<-[r:CONTROLLER{RELATION_TYPE:'实际控制人'}]-(d)\n" +
            "with case WHEN 'COMPANY' IN LABELS(d) THEN d.COMPANY_NM ELSE d.PERSON_NM END AS NAME,case WHEN 'COMPANY' IN LABELS(d) THEN d.COMPANY_ID ELSE d.PERSON_ID END AS ID\n" +
            "return {CONTROLLER_ID:ID,CONTROLLER_NAME:NAME,CONTROLLER_TYPE:'公示'} as output")
    QueryResultModel addActControllerInfoByCompanyId(@Param("company_id") String company_id);

    //疑似控制人疑似信息添加 通过company_id
    @Query("MATCH (C:COMPANY{COMPANY_ID:{company_id}})<-[R:INVEST]-(P) \n" +
            "WITH C,\n" +
            "    P AS CC1 ORDER BY tofloat(coalesce(R.SHA_RATIO, 0)) DESC ,        //降序 R.SHA_RATIO\n" +
            "    tofloat(coalesce(R.NUM, 0)) DESC LIMIT 5        //认缴降序 R.NUM  \n" +
            "MATCH (C)<-[:INVEST]-(CC1)<-[:INVEST*0..4]-(P) \n" +
            "WHERE P:PERSON OR (P)-[:CONTROLLER{RELATION_TYPE:'实际控制人'}]->(:COMPANY) OR NOT (P)<-[:INVEST]-() \n" +
            "WITH DISTINCT C,P \n" +
            "MATCH path = (P)-[:INVEST*..5]->(C) \n" +
            "WITH C,P,\n" +
            "    COLLECT([p in rels(path)|\n" +
            "        CASE \n" +
            "            WHEN p.SHA_RATIO IS NOT NULL \n" +
            "            THEN tofloat(p.SHA_RATIO)*0.01 \n" +
            "            WHEN p.SHA_RATIO IS NULL AND p.NUM IS NOT NULL AND apoc.cscs.getRegCapital(p) <> 0 \n" +
            "            THEN tofloat(p.NUM)/apoc.cscs.getRegCapital(p) \n" +
            "            ELSE 0 \n" +
            "            END]) AS paths,             //每条路径计算持股比例\n" +
            "    COLLECT([p in rels(path)|startNode(p).COMPANY_NM]) AS pathsNm              //路径开始节点的name集合  \n" +
            "CALL apoc.cscs.filterPaths(paths) yield path                //对持股路径中持股比例大于50%的关系做100%处理\n" +
            "WITH C,P,\n" +
            "    COLLECT(path) AS paths,\n" +
            "    pathsNm \n" +
            "UNWIND  RANGE(0,LENGTH(paths)-1) AS pathsindex  \n" +
            "UNWIND RANGE(0,LENGTH(paths[pathsindex])-1) as valuesIndex              //循环列表[[0.1,0.2],[0.3],[0.8]]  \n" +
            "WITH C,P, pathsindex,\n" +
            "    paths[pathsindex] AS values,\n" +
            "    apoc.agg.product(paths[pathsindex][valuesIndex]) as p,\n" +
            "    paths as pathValue,\n" +
            "    pathsNm \n" +
            "WITH C,P,pathValue,\n" +
            "    COLLECT(p) AS pValues,\n" +
            "    pathsNm \n" +
            "WITH C,P, \n" +
            "    CASE \n" +
            "        WHEN 'COMPANY' IN LABELS(P) \n" +
            "        THEN P.COMPANY_NM \n" +
            "        ELSE P.PERSON_NM  \n" +
            "        END AS CONTROLLER_NM,\n" +
            "    CASE\n" +
            "        WHEN 'COMPANY' IN LABELS(P)\n" +
            "        THEN P.COMPANY_ID\n" +
            "        ELSE P.PERSON_ID\n" +
            "        END AS CONTROLLER_ID,\n" +
            "pathValue,pValues,apoc.coll.sum(pValues) AS totalValue,pathsNm\n" +
            "WHERE totalValue >=0.33\n" +
            "with CONTROLLER_NM,CONTROLLER_ID\n" +
            "return {CONTROLLER_ID:CONTROLLER_ID,CONTROLLER_NAME:CONTROLLER_NM,CONTROLLER_TYPE:'疑似'} as output")
    QueryResultModel addSuspActControllerInfoByCompanyId(@Param("company_id") String company_id);



    //判断是否是公开企业，是的话直接取实际控制人，不是的话取疑似实际控制人 通过公司NAME
    @Query("MATCH (A:COMPANY{COMPANY_NM:{company_nm}}) " +
            "<-[r:CONTROLLER{RELATION_TYPE:'实际控制人'}]-(d) where exists(d.PERSON_NM) or exists(d.COMPANY_NM) return 1 limit 1")
    QueryResultModel JudgeCompanyTpyeByNm(@Param("company_nm") String company_nm);

    //疑似实际控制人图谱
    @Query("MATCH (C:COMPANY{COMPANY_NM:{company_nm}})<-[R:INVEST]-(P) " +
            "WITH C,P AS CC1 ORDER BY tofloat(coalesce(R.SHA_RATIO, 0)) DESC , tofloat(coalesce(R.NUM, 0)) DESC LIMIT 5 " +
            "MATCH (C)<-[:INVEST]-(CC1)<-[:INVEST*0..4]-(P) " +
            "WHERE P:PERSON OR (P)-[:CONTROLLER{RELATION_TYPE:'实际控制人'}]->(:COMPANY) OR NOT (P)<-[:INVEST]-() " +
            "WITH DISTINCT C,P MATCH path = (P)-[:INVEST*..5]->(C) " +
            "WITH C,P,COLLECT([p in rels(path)|CASE WHEN p.SHA_RATIO IS NOT NULL THEN tofloat(p.SHA_RATIO)*0.01 " +
            "WHEN p.SHA_RATIO IS NULL AND p.NUM IS NOT NULL AND apoc.cscs.getRegCapital(p) <> 0 THEN tofloat(p.NUM)/apoc.cscs.getRegCapital(p) ELSE 0 END]) AS paths," +
            "COLLECT([p in rels(path)|startNode(p).COMPANY_NM]) AS pathsNm " +
            "CALL apoc.cscs.filterPaths(paths) yield path WITH C,P,COLLECT(path) AS paths,pathsNm " +
            "UNWIND  RANGE(0,LENGTH(paths)-1) AS pathsindex  UNWIND RANGE(0,LENGTH(paths[pathsindex])-1) as valuesIndex  " +
            "WITH C,P, pathsindex,paths[pathsindex] AS values,apoc.agg.product(paths[pathsindex][valuesIndex]) as p ,paths as pathValue,pathsNm " +
            "WITH C,P,pathValue,COLLECT(p) AS pValues,pathsNm WITH C,P, " +
            "CASE WHEN 'COMPANY' IN LABELS(P) THEN P.COMPANY_NM ELSE P.PERSON_NM  END AS CONTROLLER_NM ,pathValue,pValues," +
            "apoc.coll.sum(pValues) AS totalValue,pathsNm with C,collect({CONTROLLER_NM:CONTROLLER_NM ,totalValue:toString(totalValue)}) as resultlist " +
            "CALL apoc.cscs.chooseActualController(resultlist) yield controllernm WITH C,controllernm " +
            "MATCH CP = (P)-[:INVEST|CONTROLLER*..5]->(C) where P.COMPANY_NM = controllernm or P.PERSON_NM = controllernm with CP as P " + Constants.returnQuery)
    QueryResultModel getSuspActControllerByCompanyNm(@Param("company_nm") String company_nm);

    //直接取实际控制人
    @Query("MATCH (C:COMPANY{COMPANY_NM:{company_nm}})<-[:CONTROLLER{RELATION_TYPE:'实际控制人'}]-(P) " +
            "WITH C,CASE WHEN 'COMPANY' IN LABELS(P) THEN P.COMPANY_NM ELSE P.PERSON_NM END as controllernm " +
            "MATCH CP = (P)-[:INVEST|CONTROLLER*..5]->(C) where P.COMPANY_NM = controllernm or P.PERSON_NM = controllernm with CP as P " + Constants.returnQuery)
    QueryResultModel getActControllerByCompanyNm(@Param("company_nm") String company_nm);


    //实控人公示信息添加 通过company_nm
    @Query("match path=(A:COMPANY{COMPANY_NM:{company_nm}})<-[r:CONTROLLER{RELATION_TYPE:'实际控制人'}]-(d)\n" +
            "with case WHEN 'COMPANY' IN LABELS(d) THEN d.COMPANY_NM ELSE d.PERSON_NM END AS NAME,case WHEN 'COMPANY' IN LABELS(d) THEN d.COMPANY_ID ELSE d.PERSON_ID END AS ID\n" +
            "return {CONTROLLER_ID:ID,CONTROLLER_NAME:NAME,CONTROLLER_TYPE:'公示'} as output")
    QueryResultModel addActControllerInfoByCompanyNm(@Param("company_nm") String company_nm);

    //疑似控制人疑似信息添加 通过company_nm
    @Query("MATCH (C:COMPANY{COMPANY_NM:{company_nm}})<-[R:INVEST]-(P) \n" +
            "WITH C,\n" +
            "    P AS CC1 ORDER BY tofloat(coalesce(R.SHA_RATIO, 0)) DESC ,        //降序 R.SHA_RATIO\n" +
            "    tofloat(coalesce(R.NUM, 0)) DESC LIMIT 5        //认缴降序 R.NUM  \n" +
            "MATCH (C)<-[:INVEST]-(CC1)<-[:INVEST*0..4]-(P) \n" +
            "WHERE P:PERSON OR (P)-[:CONTROLLER{RELATION_TYPE:'实际控制人'}]->(:COMPANY) OR NOT (P)<-[:INVEST]-() \n" +
            "WITH DISTINCT C,P \n" +
            "MATCH path = (P)-[:INVEST*..5]->(C) \n" +
            "WITH C,P,\n" +
            "    COLLECT([p in rels(path)|\n" +
            "        CASE \n" +
            "            WHEN p.SHA_RATIO IS NOT NULL \n" +
            "            THEN tofloat(p.SHA_RATIO)*0.01 \n" +
            "            WHEN p.SHA_RATIO IS NULL AND p.NUM IS NOT NULL AND apoc.cscs.getRegCapital(p) <> 0 \n" +
            "            THEN tofloat(p.NUM)/apoc.cscs.getRegCapital(p) \n" +
            "            ELSE 0 \n" +
            "            END]) AS paths,             //每条路径计算持股比例\n" +
            "    COLLECT([p in rels(path)|startNode(p).COMPANY_NM]) AS pathsNm              //路径开始节点的name集合  \n" +
            "CALL apoc.cscs.filterPaths(paths) yield path                //对持股路径中持股比例大于50%的关系做100%处理\n" +
            "WITH C,P,\n" +
            "    COLLECT(path) AS paths,\n" +
            "    pathsNm \n" +
            "UNWIND  RANGE(0,LENGTH(paths)-1) AS pathsindex  \n" +
            "UNWIND RANGE(0,LENGTH(paths[pathsindex])-1) as valuesIndex              //循环列表[[0.1,0.2],[0.3],[0.8]]  \n" +
            "WITH C,P, pathsindex,\n" +
            "    paths[pathsindex] AS values,\n" +
            "    apoc.agg.product(paths[pathsindex][valuesIndex]) as p,\n" +
            "    paths as pathValue,\n" +
            "    pathsNm \n" +
            "WITH C,P,pathValue,\n" +
            "    COLLECT(p) AS pValues,\n" +
            "    pathsNm \n" +
            "WITH C,P, \n" +
            "    CASE \n" +
            "        WHEN 'COMPANY' IN LABELS(P) \n" +
            "        THEN P.COMPANY_NM \n" +
            "        ELSE P.PERSON_NM  \n" +
            "        END AS CONTROLLER_NM,\n" +
            "    CASE\n" +
            "        WHEN 'COMPANY' IN LABELS(P)\n" +
            "        THEN P.COMPANY_ID\n" +
            "        ELSE P.PERSON_ID\n" +
            "        END AS CONTROLLER_ID,\n" +
            "pathValue,pValues,apoc.coll.sum(pValues) AS totalValue,pathsNm\n" +
            "WHERE totalValue >=0.33\n" +
            "with CONTROLLER_NM,CONTROLLER_ID\n" +
            "return {CONTROLLER_ID:CONTROLLER_ID,CONTROLLER_NAME:CONTROLLER_NM,CONTROLLER_TYPE:'疑似'} as output")
    QueryResultModel addSuspActControllerInfoByCompanyNm(@Param("company_nm") String company_nm);



    //输出json文件 添加是否披露信息
    // 1.通过公司ID
    //疑似实际控制人图谱
    @Query("MATCH (C:COMPANY{COMPANY_ID:{company_id}})<-[R:INVEST]-(P) \n" +
            "WITH C,\n" +
            "    P AS CC1 ORDER BY tofloat(coalesce(R.SHA_RATIO, 0)) DESC ,        //降序 R.SHA_RATIO\n" +
            "    tofloat(coalesce(R.NUM, 0)) DESC LIMIT 5        //认缴降序 R.NUM  \n" +
            "MATCH (C)<-[:INVEST]-(CC1)<-[:INVEST*0..4]-(P) \n" +
            "WHERE P:PERSON OR (P)-[:CONTROLLER{RELATION_TYPE:'实际控制人'}]->(:COMPANY) OR NOT (P)<-[:INVEST]-() \n" +
            "WITH DISTINCT C,P \n" +
            "MATCH path = (P)-[:INVEST*..5]->(C) \n" +
            "WITH C,P,\n" +
            "    COLLECT([p in rels(path)|\n" +
            "        CASE \n" +
            "            WHEN p.SHA_RATIO IS NOT NULL \n" +
            "            THEN tofloat(p.SHA_RATIO)*0.01 \n" +
            "            WHEN p.SHA_RATIO IS NULL AND p.NUM IS NOT NULL AND apoc.cscs.getRegCapital(p) <> 0 \n" +
            "            THEN tofloat(p.NUM)/apoc.cscs.getRegCapital(p) \n" +
            "            ELSE 0 \n" +
            "            END]) AS paths,             //每条路径计算持股比例\n" +
            "    COLLECT([p in rels(path)|startNode(p).COMPANY_NM]) AS pathsNm              //路径开始节点的name集合  \n" +
            "CALL apoc.cscs.filterPaths(paths) yield path                //对持股路径中持股比例大于50%的关系做100%处理\n" +
            "WITH C,P,\n" +
            "    COLLECT(path) AS paths,\n" +
            "    pathsNm \n" +
            "UNWIND  RANGE(0,LENGTH(paths)-1) AS pathsindex  \n" +
            "UNWIND RANGE(0,LENGTH(paths[pathsindex])-1) as valuesIndex              //循环列表[[0.1,0.2],[0.3],[0.8]]  \n" +
            "WITH C,P, pathsindex,\n" +
            "    paths[pathsindex] AS values,\n" +
            "    apoc.agg.product(paths[pathsindex][valuesIndex]) as p,\n" +
            "    paths as pathValue,\n" +
            "    pathsNm \n" +
            "WITH C,P,pathValue,\n" +
            "    COLLECT(p) AS pValues,\n" +
            "    pathsNm \n" +
            "WITH C,P, \n" +
            "    CASE \n" +
            "        WHEN 'COMPANY' IN LABELS(P) \n" +
            "        THEN P.COMPANY_NM \n" +
            "        ELSE P.PERSON_NM  \n" +
            "        END AS CONTROLLER_NM,\n" +
            "    CASE\n" +
            "        WHEN 'COMPANY' IN LABELS(P)\n" +
            "        THEN P.COMPANY_ID\n" +
            "        ELSE P.PERSON_ID\n" +
            "        END AS CONTROLLER_ID,\n" +
            "    pathValue,pValues,apoc.coll.sum(pValues) AS totalValue,pathsNm\n" +
            "WHERE totalValue >=0.33   \n" +
            "MATCH CP = (P)-[:INVEST|CONTROLLER*..5]->(C) \n" +
            "where P.COMPANY_NM = CONTROLLER_NM or P.PERSON_NM = CONTROLLER_NM \n" +
            "with CP as P ,CONTROLLER_NM,CONTROLLER_ID\n" +
            "UNWIND  relationships(P) AS R \n" +
            "WITH startNode(R) AS sourceNodeInfo , R AS relationInfo, endNode(R) AS targetNodeInfo ,CONTROLLER_NM,CONTROLLER_ID\n" +
            "RETURN {COMPANY_ID:sourceNodeInfo.COMPANY_ID,COMPANY_TYPE:sourceNodeInfo.COMPANY_TYPE_LIST,\n" +
            "RISK_LIST:sourceNodeInfo.RISK_LIST,REG_CAPITAL:sourceNodeInfo.REG_CAPITAL, \n" +
            "ORGNUM:sourceNodeInfo.ORGNUM,STATUS:sourceNodeInfo.STATUS,\n" +
            "COMPANY_NM:sourceNodeInfo.COMPANY_NM,\n" +
            "PERSON_ID:sourceNodeInfo.PERSON_ID,PERSON_NM:sourceNodeInfo.PERSON_NM, \n" +
            "SECURITY_NM:sourceNodeInfo.SECURITY_NM,SECURITY_ID:sourceNodeInfo.SECINNER_ID,\n" +
            "LABELS:Labels(sourceNodeInfo)} AS sourceNodeInfo,\n" +
            "{id:ID(relationInfo),type:TYPE(relationInfo),investShaRatio:CASE WHEN relationInfo.SHA_RATIO IS NOT NULL THEN tofloat(relationInfo.SHA_RATIO)\n" +
            "ELSE 0 END,workPosition:relationInfo.POSITION,SC_RELATION_TYPE:relationInfo.RELATION_TYPE,\n" +
            "investNum:relationInfo.NUM, GUAR_INFO:relationInfo.GUAR_INFO,controllerType:relationInfo.RELATION_TYPE,relativeType:relationInfo.RELATION_TYPE} AS relationInfo,\n" +
            "{COMPANY_ID:targetNodeInfo.COMPANY_ID,COMPANY_TYPE:targetNodeInfo.COMPANY_TYPE_LIST,\n" +
            "RISK_LIST:targetNodeInfo.RISK_LIST,REG_CAPITAL:targetNodeInfo.REG_CAPITAL,\n" +
            "ORGNUM:targetNodeInfo.ORGNUM,STATUS:targetNodeInfo.STATUS,\n" +
            "COMPANY_NM:targetNodeInfo.COMPANY_NM,\n" +
            "PERSON_ID:targetNodeInfo.PERSON_ID,PERSON_NM:targetNodeInfo.PERSON_NM, \n" +
            "SECURITY_NM:targetNodeInfo.SECURITY_NM,SECURITY_ID:targetNodeInfo.SECINNER_ID,\n" +
            "LABELS:Labels(targetNodeInfo)} AS targetNodeInfo,\n" +
            "{CONTROLLER_ID:CONTROLLER_ID,CONTROLLER_NAME:CONTROLLER_NM,CONTROLLER_TYPE:'疑似'} as output")
    QueryResultModel getSuspActControllerByCompanyIdNew(@Param("company_id") String company_id);

    //直接取实际控制人
    @Query("MATCH (C:COMPANY{COMPANY_ID:{company_id}})<-[:CONTROLLER{RELATION_TYPE:'实际控制人'}]-(d) \n" +
            "with C,case WHEN 'COMPANY' IN LABELS(d) THEN d.COMPANY_NM ELSE d.PERSON_NM END AS CONTROLLER_NM,case WHEN 'COMPANY' IN LABELS(d) THEN d.COMPANY_ID ELSE d.PERSON_ID END AS CONTROLLER_ID\n" +
            "MATCH CP = (P)-[:INVEST|CONTROLLER*..5]->(C)            //从P到C可能存在多条路径\n" +
            "where P.COMPANY_NM = CONTROLLER_NM or P.PERSON_NM = CONTROLLER_NM \n" +
            "with CP as P,CONTROLLER_ID,CONTROLLER_NM            //P 路径 \n" +
            "UNWIND  relationships(P) AS R           //解路径 \n" +
            "WITH startNode(R) AS sourceNodeInfo , R AS relationInfo, endNode(R) AS targetNodeInfo ,CONTROLLER_NM,CONTROLLER_ID\n" +
            "RETURN {COMPANY_ID:sourceNodeInfo.COMPANY_ID,COMPANY_TYPE:sourceNodeInfo.COMPANY_TYPE_LIST,\n" +
            "RISK_LIST:sourceNodeInfo.RISK_LIST,REG_CAPITAL:sourceNodeInfo.REG_CAPITAL, \n" +
            "ORGNUM:sourceNodeInfo.ORGNUM,STATUS:sourceNodeInfo.STATUS,\n" +
            "COMPANY_NM:sourceNodeInfo.COMPANY_NM,\n" +
            "PERSON_ID:sourceNodeInfo.PERSON_ID,PERSON_NM:sourceNodeInfo.PERSON_NM, \n" +
            "SECURITY_NM:sourceNodeInfo.SECURITY_NM,SECURITY_ID:sourceNodeInfo.SECINNER_ID,\n" +
            "LABELS:Labels(sourceNodeInfo)} AS sourceNodeInfo,\n" +
            "{id:ID(relationInfo),type:TYPE(relationInfo),investShaRatio:CASE WHEN relationInfo.SHA_RATIO IS NOT NULL THEN tofloat(relationInfo.SHA_RATIO)\n" +
            "ELSE 0 END,workPosition:relationInfo.POSITION,SC_RELATION_TYPE:relationInfo.RELATION_TYPE,\n" +
            "investNum:relationInfo.NUM, GUAR_INFO:relationInfo.GUAR_INFO,controllerType:relationInfo.RELATION_TYPE,relativeType:relationInfo.RELATION_TYPE} AS relationInfo,\n" +
            "{COMPANY_ID:targetNodeInfo.COMPANY_ID,COMPANY_TYPE:targetNodeInfo.COMPANY_TYPE_LIST,\n" +
            "RISK_LIST:targetNodeInfo.RISK_LIST,REG_CAPITAL:targetNodeInfo.REG_CAPITAL,\n" +
            "ORGNUM:targetNodeInfo.ORGNUM,STATUS:targetNodeInfo.STATUS,\n" +
            "COMPANY_NM:targetNodeInfo.COMPANY_NM,\n" +
            "PERSON_ID:targetNodeInfo.PERSON_ID,PERSON_NM:targetNodeInfo.PERSON_NM, \n" +
            "SECURITY_NM:targetNodeInfo.SECURITY_NM,SECURITY_ID:targetNodeInfo.SECINNER_ID,\n" +
            "LABELS:Labels(targetNodeInfo)} AS targetNodeInfo,\n" +
            "{CONTROLLER_ID:CONTROLLER_ID,CONTROLLER_NAME:CONTROLLER_NM,CONTROLLER_TYPE:'公示'} as output")
    QueryResultModel getActControllerByCompanyIdNew(@Param("company_id") String company_id);


    // 2.通过公司NAME
    //疑似实际控制人图谱
    @Query("MATCH (C:COMPANY{COMPANY_NM:{company_nm}})<-[R:INVEST]-(P) \n" +
            "WITH C,\n" +
            "    P AS CC1 ORDER BY tofloat(coalesce(R.SHA_RATIO, 0)) DESC ,        //降序 R.SHA_RATIO\n" +
            "    tofloat(coalesce(R.NUM, 0)) DESC LIMIT 5        //认缴降序 R.NUM  \n" +
            "MATCH (C)<-[:INVEST]-(CC1)<-[:INVEST*0..4]-(P) \n" +
            "WHERE P:PERSON OR (P)-[:CONTROLLER{RELATION_TYPE:'实际控制人'}]->(:COMPANY) OR NOT (P)<-[:INVEST]-() \n" +
            "WITH DISTINCT C,P \n" +
            "MATCH path = (P)-[:INVEST*..5]->(C) \n" +
            "WITH C,P,\n" +
            "    COLLECT([p in rels(path)|\n" +
            "        CASE \n" +
            "            WHEN p.SHA_RATIO IS NOT NULL \n" +
            "            THEN tofloat(p.SHA_RATIO)*0.01 \n" +
            "            WHEN p.SHA_RATIO IS NULL AND p.NUM IS NOT NULL AND apoc.cscs.getRegCapital(p) <> 0 \n" +
            "            THEN tofloat(p.NUM)/apoc.cscs.getRegCapital(p) \n" +
            "            ELSE 0 \n" +
            "            END]) AS paths,             //每条路径计算持股比例\n" +
            "    COLLECT([p in rels(path)|startNode(p).COMPANY_NM]) AS pathsNm              //路径开始节点的name集合  \n" +
            "CALL apoc.cscs.filterPaths(paths) yield path                //对持股路径中持股比例大于50%的关系做100%处理\n" +
            "WITH C,P,\n" +
            "    COLLECT(path) AS paths,\n" +
            "    pathsNm \n" +
            "UNWIND  RANGE(0,LENGTH(paths)-1) AS pathsindex  \n" +
            "UNWIND RANGE(0,LENGTH(paths[pathsindex])-1) as valuesIndex              //循环列表[[0.1,0.2],[0.3],[0.8]]  \n" +
            "WITH C,P, pathsindex,\n" +
            "    paths[pathsindex] AS values,\n" +
            "    apoc.agg.product(paths[pathsindex][valuesIndex]) as p,\n" +
            "    paths as pathValue,\n" +
            "    pathsNm \n" +
            "WITH C,P,pathValue,\n" +
            "    COLLECT(p) AS pValues,\n" +
            "    pathsNm \n" +
            "WITH C,P, \n" +
            "    CASE \n" +
            "        WHEN 'COMPANY' IN LABELS(P) \n" +
            "        THEN P.COMPANY_NM \n" +
            "        ELSE P.PERSON_NM  \n" +
            "        END AS CONTROLLER_NM,\n" +
            "    CASE\n" +
            "        WHEN 'COMPANY' IN LABELS(P)\n" +
            "        THEN P.COMPANY_ID\n" +
            "        ELSE P.PERSON_ID\n" +
            "        END AS CONTROLLER_ID,\n" +
            "    pathValue,pValues,apoc.coll.sum(pValues) AS totalValue,pathsNm\n" +
            "WHERE totalValue >=0.33   \n" +
            "MATCH CP = (P)-[:INVEST|CONTROLLER*..5]->(C) \n" +
            "where P.COMPANY_NM = CONTROLLER_NM or P.PERSON_NM = CONTROLLER_NM \n" +
            "with CP as P ,CONTROLLER_NM,CONTROLLER_ID\n" +
            "UNWIND  relationships(P) AS R \n" +
            "WITH startNode(R) AS sourceNodeInfo , R AS relationInfo, endNode(R) AS targetNodeInfo ,CONTROLLER_NM,CONTROLLER_ID\n" +
            "RETURN {COMPANY_ID:sourceNodeInfo.COMPANY_ID,COMPANY_TYPE:sourceNodeInfo.COMPANY_TYPE_LIST,\n" +
            "RISK_LIST:sourceNodeInfo.RISK_LIST,REG_CAPITAL:sourceNodeInfo.REG_CAPITAL, \n" +
            "ORGNUM:sourceNodeInfo.ORGNUM,STATUS:sourceNodeInfo.STATUS,\n" +
            "COMPANY_NM:sourceNodeInfo.COMPANY_NM,\n" +
            "PERSON_ID:sourceNodeInfo.PERSON_ID,PERSON_NM:sourceNodeInfo.PERSON_NM, \n" +
            "SECURITY_NM:sourceNodeInfo.SECURITY_NM,SECURITY_ID:sourceNodeInfo.SECINNER_ID,\n" +
            "LABELS:Labels(sourceNodeInfo)} AS sourceNodeInfo,\n" +
            "{id:ID(relationInfo),type:TYPE(relationInfo),investShaRatio:CASE WHEN relationInfo.SHA_RATIO IS NOT NULL THEN tofloat(relationInfo.SHA_RATIO)\n" +
            "ELSE 0 END,workPosition:relationInfo.POSITION,SC_RELATION_TYPE:relationInfo.RELATION_TYPE,\n" +
            "investNum:relationInfo.NUM, GUAR_INFO:relationInfo.GUAR_INFO,controllerType:relationInfo.RELATION_TYPE,relativeType:relationInfo.RELATION_TYPE} AS relationInfo,\n" +
            "{COMPANY_ID:targetNodeInfo.COMPANY_ID,COMPANY_TYPE:targetNodeInfo.COMPANY_TYPE_LIST,\n" +
            "RISK_LIST:targetNodeInfo.RISK_LIST,REG_CAPITAL:targetNodeInfo.REG_CAPITAL,\n" +
            "ORGNUM:targetNodeInfo.ORGNUM,STATUS:targetNodeInfo.STATUS,\n" +
            "COMPANY_NM:targetNodeInfo.COMPANY_NM,\n" +
            "PERSON_ID:targetNodeInfo.PERSON_ID,PERSON_NM:targetNodeInfo.PERSON_NM, \n" +
            "SECURITY_NM:targetNodeInfo.SECURITY_NM,SECURITY_ID:targetNodeInfo.SECINNER_ID,\n" +
            "LABELS:Labels(targetNodeInfo)} AS targetNodeInfo,\n" +
            "{CONTROLLER_ID:CONTROLLER_ID,CONTROLLER_NAME:CONTROLLER_NM,CONTROLLER_TYPE:'疑似'} as output")
    QueryResultModel getSuspActControllerByCompanyNmNew(@Param("company_nm") String company_nm);

    //直接取实际控制人
    @Query("MATCH (C:COMPANY{COMPANY_NM:{company_nm}})<-[:CONTROLLER{RELATION_TYPE:'实际控制人'}]-(d) \n" +
            "with C,case WHEN 'COMPANY' IN LABELS(d) THEN d.COMPANY_NM ELSE d.PERSON_NM END AS CONTROLLER_NM,case WHEN 'COMPANY' IN LABELS(d) THEN d.COMPANY_ID ELSE d.PERSON_ID END AS CONTROLLER_ID\n" +
            "MATCH CP = (P)-[:INVEST|CONTROLLER*..5]->(C)            //从P到C可能存在多条路径\n" +
            "where P.COMPANY_NM = CONTROLLER_NM or P.PERSON_NM = CONTROLLER_NM \n" +
            "with CP as P,CONTROLLER_ID,CONTROLLER_NM            //P 路径 \n" +
            "UNWIND  relationships(P) AS R           //解路径 \n" +
            "WITH startNode(R) AS sourceNodeInfo , R AS relationInfo, endNode(R) AS targetNodeInfo ,CONTROLLER_NM,CONTROLLER_ID\n" +
            "RETURN {COMPANY_ID:sourceNodeInfo.COMPANY_ID,COMPANY_TYPE:sourceNodeInfo.COMPANY_TYPE_LIST,\n" +
            "RISK_LIST:sourceNodeInfo.RISK_LIST,REG_CAPITAL:sourceNodeInfo.REG_CAPITAL, \n" +
            "ORGNUM:sourceNodeInfo.ORGNUM,STATUS:sourceNodeInfo.STATUS,\n" +
            "COMPANY_NM:sourceNodeInfo.COMPANY_NM,\n" +
            "PERSON_ID:sourceNodeInfo.PERSON_ID,PERSON_NM:sourceNodeInfo.PERSON_NM, \n" +
            "SECURITY_NM:sourceNodeInfo.SECURITY_NM,SECURITY_ID:sourceNodeInfo.SECINNER_ID,\n" +
            "LABELS:Labels(sourceNodeInfo)} AS sourceNodeInfo,\n" +
            "{id:ID(relationInfo),type:TYPE(relationInfo),investShaRatio:CASE WHEN relationInfo.SHA_RATIO IS NOT NULL THEN tofloat(relationInfo.SHA_RATIO)\n" +
            "ELSE 0 END,workPosition:relationInfo.POSITION,SC_RELATION_TYPE:relationInfo.RELATION_TYPE,\n" +
            "investNum:relationInfo.NUM, GUAR_INFO:relationInfo.GUAR_INFO,controllerType:relationInfo.RELATION_TYPE,relativeType:relationInfo.RELATION_TYPE} AS relationInfo,\n" +
            "{COMPANY_ID:targetNodeInfo.COMPANY_ID,COMPANY_TYPE:targetNodeInfo.COMPANY_TYPE_LIST,\n" +
            "RISK_LIST:targetNodeInfo.RISK_LIST,REG_CAPITAL:targetNodeInfo.REG_CAPITAL,\n" +
            "ORGNUM:targetNodeInfo.ORGNUM,STATUS:targetNodeInfo.STATUS,\n" +
            "COMPANY_NM:targetNodeInfo.COMPANY_NM,\n" +
            "PERSON_ID:targetNodeInfo.PERSON_ID,PERSON_NM:targetNodeInfo.PERSON_NM, \n" +
            "SECURITY_NM:targetNodeInfo.SECURITY_NM,SECURITY_ID:targetNodeInfo.SECINNER_ID,\n" +
            "LABELS:Labels(targetNodeInfo)} AS targetNodeInfo,\n" +
            "{CONTROLLER_ID:CONTROLLER_ID,CONTROLLER_NAME:CONTROLLER_NM,CONTROLLER_TYPE:'公示'} as output")
    QueryResultModel getActControllerByCompanyNmNew(@Param("company_nm") String company_nm);

}