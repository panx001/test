package com.cscs.graph_api.Util;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;

/**
 * Created by huchangchun on 2017/4/12.
 */
public class HttpUtil {

    /**
     * 数据组HBase接口通用方法
     *
     * @param url
     * @return
     */
    public static String getHBaseResponse(String url) {
        String data = null;

        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpGet get = new HttpGet(url);
        get.setHeader("Accept", "application/octet-stream");

        try {
            CloseableHttpResponse fuzzyResponse = httpClient.execute(get);
            data = EntityUtils.toString(fuzzyResponse.getEntity(), "utf-8");
        } catch (IOException e) {
            e.printStackTrace();
        }
        if ("".equals(data) || "Not found\r\n".equals(data)) {
            data = null;
        }
        return data;
    }
}
