package com.cscs.graph_api.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

/**
 * des: 数据源的配置类
 * auth: wangpengchao
 */
@Configuration
public class GdsDataSourceConfig {
    @ConfigurationProperties(prefix = "spring.datasource.gds")
    @Bean(name = "gdsDataSource")
    public DataSource GdsDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "gdsJdbcTemplate")
    public JdbcTemplate jdbcTemplate(
            @Qualifier("gdsDataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }
}
