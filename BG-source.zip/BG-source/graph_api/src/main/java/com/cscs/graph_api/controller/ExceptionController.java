package com.cscs.graph_api.controller;


import com.cscs.graph_api.Exception.InputException;
import com.cscs.graph_api.dto.BasicOutDto;
import lombok.extern.slf4j.Slf4j;
import org.neo4j.driver.v1.exceptions.AuthenticationException;
import org.neo4j.driver.v1.exceptions.ServiceUnavailableException;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.NoHandlerFoundException;

import java.util.concurrent.TimeoutException;

@RestControllerAdvice
public class ExceptionController {

    /**
     * 异常处理
     *
     * @return
     */
    @ExceptionHandler({Exception.class})
    public BasicOutDto handException(Exception e) {
        BasicOutDto outDto = new BasicOutDto();
        if (e instanceof InputException || e instanceof HttpMessageNotReadableException) {
            outDto.setCode(400);
            outDto.setMsg("请求参数不正确");
        } else if (e instanceof NoHandlerFoundException) {
            outDto.setCode(401);
            outDto.setMsg("请求地址不正确");
        } else if (e instanceof HttpRequestMethodNotSupportedException) {
            outDto.setCode(405);
            outDto.setMsg("请求方法不支持");
        } else if (e instanceof ServiceUnavailableException || e instanceof AuthenticationException) {
            outDto.setCode(503);
            outDto.setMsg("数据库异常");
        } else if (e instanceof TimeoutException) {
            outDto.setCode(504);
            outDto.setMsg("数据库查询超时");
        } else {
            outDto.setCode(500);
            outDto.setMsg("系统内部错误");
        }
        return outDto;
    }
}
