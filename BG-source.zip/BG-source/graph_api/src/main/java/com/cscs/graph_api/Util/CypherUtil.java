package com.cscs.graph_api.Util;

import org.neo4j.driver.v1.Session;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.driver.v1.exceptions.ServiceUnavailableException;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.*;

@Configuration
public class CypherUtil {

    private ExecutorService executorService = Executors.newSingleThreadExecutor();

    public StatementResult execute(String cypher) throws Exception {
        FutureTask<StatementResult> futureTask = new FutureTask<>(new Callable<StatementResult>() {
            @Override
            public StatementResult call() {
                try (Session session = Constants.driver.session()) {
                    return session.run(cypher);
                }
            }
        });
        try {
            executorService.execute(futureTask);
            return futureTask.get(1, TimeUnit.MINUTES);
        } catch (InterruptedException | ExecutionException | ServiceUnavailableException | TimeoutException e) {
            futureTask.cancel(true);
            throw e;
        }
    }
}