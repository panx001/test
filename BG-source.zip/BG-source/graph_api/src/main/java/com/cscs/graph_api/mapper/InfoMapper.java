package com.cscs.graph_api.mapper;

/**
 * Created by wuchenglong on 2018/1/8.
 */

//import com.cscs.graph_api.domain.FindRelationNodeShow;

import com.cscs.graph_api.domain.InfoQueryResult;
import com.cscs.graph_api.domain.InfoShow;
import com.cscs.graph_api.domain.NodeQueryResult;
import com.cscs.graph_api.domain.NodeShow;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;


@SuppressWarnings("unused")
@Mapper
public interface InfoMapper {

    InfoMapper MAPPER = Mappers.getMapper(InfoMapper.class);

    @Mappings({
            @Mapping(source = "CONTROLLER_ID", target = "id"),
            @Mapping(source = "CONTROLLER_NAME", target = "name"),
            @Mapping(source = "CONTROLLER_TYPE", target = "controllerType")

    })
    InfoShow QueryResultToInfoShow(InfoQueryResult infoQueryResult);

    @InheritInverseConfiguration
    InfoQueryResult InfoShowToQueryResult(InfoShow infoShow);
}
