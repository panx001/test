package com.cscs.graph_api.services.impl;

import com.cscs.graph_api.Util.Constants;
import com.cscs.graph_api.Util.CypherUtil;
import com.cscs.graph_api.Util.Map2Map;
import com.cscs.graph_api.Util.UseFulFunc;
import com.cscs.graph_api.domain.ResultReturn;
import com.cscs.graph_api.domain.ResultReturnCollection;
import com.cscs.graph_api.domain.ResultReturnCollectionNew;
import com.cscs.graph_api.dto.RelationInDto;
import com.cscs.graph_api.mapper.QueryResultMapper;
import com.cscs.graph_api.repositories.RelationRepository;
import com.cscs.graph_api.services.RelationServices;
import org.neo4j.driver.v1.Record;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.ogm.response.model.QueryResultModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Statement;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Arrays;

@Service
public class RelationServicesImpl implements RelationServices {

    private static Logger logger = LogManager.getLogger(RelationServicesImpl.class);

    @Autowired
    RelationRepository repository;


    // 找关系，三层内找所有路径
    public StatementResult getReusltFromC2C(RelationInDto inDto, String ID1, String ID2) throws Exception {
        StringBuilder cypher = new StringBuilder();

        cypher.append("match P=(C1:COMPANY{");
        if (isNumeric(ID1)){
            cypher.append("COMPANY_ID:'"+ ID1 + "'})-[R:" + inDto.relations + "*.." + inDto.layer);
        } else {
            cypher.append("COMPANY_NM:'"+ ID1 + "'})-[R:" + inDto.relations + "*.." + inDto.layer);
        }

        if (isNumeric(ID2)){
            cypher.append("]-(C2:COMPANY{COMPANY_ID:'" + ID2 + "'})\n");
        } else {
            cypher.append("]-(C2:COMPANY{COMPANY_NM:'" + ID2 + "'})\n");
        }
        cypher.append("with P,[n IN NODES(P)| SIZE([m IN FILTER(f IN NODES(P) WHERE ID(f)=ID(n))])] AS nodeIdCount WHERE ALL(x IN nodeIdCount WHERE x<2)\n" +
                "with P ORDER BY LENGTH(P) LIMIT  " + inDto.maxPath + "\n");
        cypher.append(Constants.returnQuery);

//        logger.debug(cypher);
        StatementResult result = new CypherUtil().execute(cypher.toString());

        return result;
    }


    public StatementResult getReusltFromC2P(RelationInDto inDto, String ID1, List IDlist) throws Exception {
        StringBuilder cypher = new StringBuilder();

        if (isNumeric(ID1)){
            cypher.append("match (C1:COMPANY{COMPANY_ID:'" + ID1 + "'})\n" +
                    "with C1\n");
        } else {
            cypher.append("match (C1:COMPANY{COMPANY_NM:'" + ID1 + "'})\n" +
                    "with C1\n");
        }

        if (isNumeric(IDlist.get(0).toString())){
            cypher.append("match (C2:COMPANY{COMPANY_ID:'" + IDlist.get(0) + "'})-[]-(P1:PERSON{");
            if (isNumeric(IDlist.get(1).toString())){
                cypher.append("PERSON_ID:'"+ IDlist.get(1) + "'})\n");
            } else{
                cypher.append("PERSON_NM:'"+ IDlist.get(1) + "'})\n");
            }
        } else {
            cypher.append("match (C2:COMPANY{COMPANY_NM:'" + IDlist.get(0) + "'})-[]-(P1:PERSON{");
            if (isNumeric(IDlist.get(1).toString())){
                cypher.append("PERSON_ID:'"+ IDlist.get(1) + "'})\n");
            } else{
                cypher.append("PERSON_NM:'"+ IDlist.get(1) + "'})\n");
            }
        }

        cypher.append("with distinct P1,C1\n" +
                "match P=(C1)-[R:" + inDto.relations + "*.." + inDto.layer + "]-(P1)\n");
        cypher.append("with P,[n IN NODES(P)| SIZE([m IN FILTER(f IN NODES(P) WHERE ID(f)=ID(n))])] AS nodeIdCount WHERE ALL(x IN nodeIdCount WHERE x<2)\n" +
                "with P ORDER BY LENGTH(P) LIMIT  " + inDto.maxPath + "\n");
        cypher.append(Constants.returnQuery);

//        logger.debug(cypher);
        StatementResult result = new CypherUtil().execute(cypher.toString());

        return result;
    }


    public StatementResult getReusltFromP2C(RelationInDto inDto, String ID1, List IDlist) throws Exception {
        StringBuilder cypher = new StringBuilder();

        if (isNumeric(IDlist.get(0).toString())){
            cypher.append("match (:COMPANY{COMPANY_ID:'" + IDlist.get(0) + "'})-[]-(P1:PERSON{");
            if (isNumeric(IDlist.get(1).toString())){
                cypher.append("PERSON_ID:'"+ IDlist.get(1) + "'})\n");
            } else{
                cypher.append("PERSON_NM:'"+ IDlist.get(1) + "'})\n");
            }
        } else {
            cypher.append("match (:COMPANY{COMPANY_NM:'" + IDlist.get(0) + "'})-[]-(P1:PERSON{");
            if (isNumeric(IDlist.get(1).toString())){
                cypher.append("PERSON_ID:'"+ IDlist.get(1) + "'})\n");
            } else{
                cypher.append("PERSON_NM:'"+ IDlist.get(1) + "'})\n");
            }
        }
        cypher.append("with distinct P1\n");

        if (isNumeric(ID1)){
            cypher.append("match (C1:COMPANY{COMPANY_ID:'" + ID1 + "'})\n");
        } else {
            cypher.append("match (C1:COMPANY{COMPANY_NM:'" + ID1 + "'})\n");
        }

        cypher.append("with C1,P1\n" +
                "match P=(C1)-[R:" + inDto.relations + "*.." + inDto.layer + "]-(P1)\n");
        cypher.append("with P,[n IN NODES(P)| SIZE([m IN FILTER(f IN NODES(P) WHERE ID(f)=ID(n))])] AS nodeIdCount WHERE ALL(x IN nodeIdCount WHERE x<2)\n" +
                "with P ORDER BY LENGTH(P) LIMIT  " + inDto.maxPath + "\n");
        cypher.append(Constants.returnQuery);

//        logger.debug(cypher);
        StatementResult result = new CypherUtil().execute(cypher.toString());

        return result;
    }


    public StatementResult getReusltFromP2P(RelationInDto inDto, List IDlist1, List IDlist2) throws Exception {
        StringBuilder cypher = new StringBuilder();

        if (isNumeric(IDlist1.get(0).toString())){
            cypher.append("match (C1:COMPANY{COMPANY_ID:'" + IDlist1.get(0) + "'})-[]-(P1:PERSON{");
            if (isNumeric(IDlist1.get(1).toString())){
                cypher.append("PERSON_ID:'"+ IDlist1.get(1) + "'})\n");
            } else{
                cypher.append("PERSON_NM:'"+ IDlist1.get(1) + "'})\n");
            }
        } else {
            cypher.append("match (C1:COMPANY{COMPANY_NM:'" + IDlist1.get(0) + "'})-[]-(P1:PERSON{");
            if (isNumeric(IDlist1.get(1).toString())){
                cypher.append("PERSON_ID:'"+ IDlist1.get(1) + "'})\n");
            } else{
                cypher.append("PERSON_NM:'"+ IDlist1.get(1) + "'})\n");
            }
        }
        cypher.append("with distinct P1\n");

        if (isNumeric(IDlist2.get(0).toString())){
            cypher.append("match (C2:COMPANY{COMPANY_ID:'" + IDlist2.get(0) + "'})-[]-(P2:PERSON{");
            if (isNumeric(IDlist2.get(1).toString())){
                cypher.append("PERSON_ID:'"+ IDlist2.get(1) + "'})\n");
            } else{
                cypher.append("PERSON_NM:'"+ IDlist2.get(1) + "'})\n");
            }
        } else {
            cypher.append("match (C2:COMPANY{COMPANY_NM:'" + IDlist2.get(0) + "'})-[]-(P2:PERSON{");
            if (isNumeric(IDlist2.get(1).toString())){
                cypher.append("PERSON_ID:'"+ IDlist2.get(1) + "'})\n");
            } else{
                cypher.append("PERSON_NM:'"+ IDlist2.get(1) + "'})\n");
            }
        }

        cypher.append("with distinct P2,P1\n" +
                "match P=(P1)-[R:" + inDto.relations + "*.." + inDto.layer + "]-(P2)\n");
        cypher.append("with P,[n IN NODES(P)| SIZE([m IN FILTER(f IN NODES(P) WHERE ID(f)=ID(n))])] AS nodeIdCount WHERE ALL(x IN nodeIdCount WHERE x<2)\n" +
                "with P ORDER BY LENGTH(P) LIMIT  " + inDto.maxPath + "\n");
        cypher.append(Constants.returnQuery);

//        logger.debug(cypher);
        StatementResult result = new CypherUtil().execute(cypher.toString());

        return result;
    }


    @Override
    public ResultReturnCollection getRelation(RelationInDto inDto) throws Exception {
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        StatementResult searchresult = null;

        ArrayList keyWordList = inDto.getKeyWords();

        for (int i = 0; i < keyWordList.size(); i++) {
            for (int j = i; j < keyWordList.size(); j++) {
                if (!keyWordList.get(i).toString().equals(keyWordList.get(j).toString())) {

                    // 公司--公司
                    if (keyWordList.get(i) instanceof String && keyWordList.get(j) instanceof String) {

                        searchresult = getReusltFromC2C(inDto, keyWordList.get(i).toString(), keyWordList.get(j).toString());
                    }

                    // 公司--自然人
                    if (keyWordList.get(i) instanceof String && keyWordList.get(j) instanceof java.util.List) {

//                        System.out.println(keyWordList.get(i));
//                        System.out.println(keyWordList.get(j));
//                        System.out.println(keyWordList.get(j).getClass().getName());
                        searchresult = getReusltFromC2P(inDto, keyWordList.get(i).toString(), (List) keyWordList.get(j));
                    }

                    // 自然人--公司
                    if (keyWordList.get(i) instanceof java.util.List && keyWordList.get(j) instanceof String) {

                        searchresult = getReusltFromP2C(inDto, keyWordList.get(j).toString(), (List) keyWordList.get(i));
                    }

                    // 自然人--自然人
                    if (keyWordList.get(i) instanceof java.util.List && keyWordList.get(j) instanceof java.util.List) {

                        searchresult = getReusltFromP2P(inDto, (List) keyWordList.get(i), (List) keyWordList.get(j));
                    }


                    while (searchresult.hasNext()) {
                        Record record = searchresult.next();
                        Map<String, Object> copiedMap = Map2Map.copyMap(record.asMap());

                        ResultReturn resultReturn = new ResultReturn(
                                QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("sourceNodeInfo")),
                                QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) copiedMap.get("relationInfo")),
                                QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("targetNodeInfo")));
                        resultReturnCollection.add(resultReturn);
                    }
                }
            }
        }
        resultReturnCollection.updateElemtList();
        return resultReturnCollection;
    }


    //找关系，三层以上找所有的最短路径
    public StatementResult getReusltFromC2CShortestPath(RelationInDto inDto, String ID1, String ID2) throws Exception {
        StringBuilder cypher = new StringBuilder();

        cypher.append("match P=AllShortestPaths((C1:COMPANY{");
        if (isNumeric(ID1)){
            cypher.append("COMPANY_ID:'"+ ID1 + "'})-[R:" + inDto.relations + "*.." + inDto.layer);
        } else {
            cypher.append("COMPANY_NM:'"+ ID1 + "'})-[R:" + inDto.relations + "*.." + inDto.layer);
        }

        if (isNumeric(ID2)){
            cypher.append("]-(C2:COMPANY{COMPANY_ID:'" + ID2 + "'})\n");
        } else {
            cypher.append("]-(C2:COMPANY{COMPANY_NM:'" + ID2 + "'}))\n");
        }
        cypher.append("with P,[n IN NODES(P)| SIZE([m IN FILTER(f IN NODES(P) WHERE ID(f)=ID(n))])] AS nodeIdCount WHERE ALL(x IN nodeIdCount WHERE x<2)\n" +
                "with P ORDER BY LENGTH(P) LIMIT  " + inDto.maxPath + "\n");
        cypher.append(Constants.returnQuery);

//        logger.debug(cypher);
        StatementResult result = new CypherUtil().execute(cypher.toString());

        return result;
    }


    public StatementResult getReusltFromC2PShortestPath(RelationInDto inDto, String ID1, List IDlist) throws Exception {
        StringBuilder cypher = new StringBuilder();

        if (isNumeric(ID1)){
            cypher.append("match (C1:COMPANY{COMPANY_ID:'" + ID1 + "'})\n" +
                    "with C1\n");
        } else {
            cypher.append("match (C1:COMPANY{COMPANY_NM:'" + ID1 + "'})\n" +
                    "with C1\n");
        }

        if (isNumeric(IDlist.get(0).toString())){
            cypher.append("match (C2:COMPANY{COMPANY_ID:'" + IDlist.get(0) + "'})-[]-(P1:PERSON{");
            if (isNumeric(IDlist.get(1).toString())){
                cypher.append("PERSON_ID:'"+ IDlist.get(1) + "'})\n");
            } else{
                cypher.append("PERSON_NM:'"+ IDlist.get(1) + "'})\n");
            }
        } else {
            cypher.append("match (C2:COMPANY{COMPANY_NM:'" + IDlist.get(0) + "'})-[]-(P1:PERSON{");
            if (isNumeric(IDlist.get(1).toString())){
                cypher.append("PERSON_ID:'"+ IDlist.get(1) + "'})\n");
            } else{
                cypher.append("PERSON_NM:'"+ IDlist.get(1) + "'})\n");
            }
        }

        cypher.append("with distinct P1,C1\n" +
                "match P=AllShortestPaths((C1)-[R:" + inDto.relations + "*.." + inDto.layer + "]-(P1))\n");
        cypher.append("with P,[n IN NODES(P)| SIZE([m IN FILTER(f IN NODES(P) WHERE ID(f)=ID(n))])] AS nodeIdCount WHERE ALL(x IN nodeIdCount WHERE x<2)\n" +
                "with P ORDER BY LENGTH(P) LIMIT  " + inDto.maxPath + "\n");
        cypher.append(Constants.returnQuery);

//        logger.debug(cypher);
        StatementResult result = new CypherUtil().execute(cypher.toString());

        return result;
    }


    public StatementResult getReusltFromP2CShortestPath(RelationInDto inDto, String ID1, List IDlist) throws Exception {
        StringBuilder cypher = new StringBuilder();

        if (isNumeric(IDlist.get(0).toString())){
            cypher.append("match (:COMPANY{COMPANY_ID:'" + IDlist.get(0) + "'})-[]-(P1:PERSON{");
            if (isNumeric(IDlist.get(1).toString())){
                cypher.append("PERSON_ID:'"+ IDlist.get(1) + "'})\n");
            } else{
                cypher.append("PERSON_NM:'"+ IDlist.get(1) + "'})\n");
            }
        } else {
            cypher.append("match (:COMPANY{COMPANY_NM:'" + IDlist.get(0) + "'})-[]-(P1:PERSON{");
            if (isNumeric(IDlist.get(1).toString())){
                cypher.append("PERSON_ID:'"+ IDlist.get(1) + "'})\n");
            } else{
                cypher.append("PERSON_NM:'"+ IDlist.get(1) + "'})\n");
            }
        }
        cypher.append("with distinct P1\n");

        if (isNumeric(ID1)){
            cypher.append("match (C1:COMPANY{COMPANY_ID:'" + ID1 + "'})\n");
        } else {
            cypher.append("match (C1:COMPANY{COMPANY_NM:'" + ID1 + "'})\n");
        }

        cypher.append("with C1,P1\n" +
                "match P=AllShortestPaths((C1)-[R:" + inDto.relations + "*.." + inDto.layer + "]-(P1))\n");
        cypher.append("with P,[n IN NODES(P)| SIZE([m IN FILTER(f IN NODES(P) WHERE ID(f)=ID(n))])] AS nodeIdCount WHERE ALL(x IN nodeIdCount WHERE x<2)\n" +
                "with P ORDER BY LENGTH(P) LIMIT  " + inDto.maxPath + "\n");
        cypher.append(Constants.returnQuery);

//        logger.debug(cypher);
        StatementResult result = new CypherUtil().execute(cypher.toString());

        return result;
    }


    public StatementResult getReusltFromP2PShortestPath(RelationInDto inDto, List IDlist1, List IDlist2) throws Exception {
        StringBuilder cypher = new StringBuilder();

        if (isNumeric(IDlist1.get(0).toString())){
            cypher.append("match (C1:COMPANY{COMPANY_ID:'" + IDlist1.get(0) + "'})-[]-(P1:PERSON{");
            if (isNumeric(IDlist1.get(1).toString())){
                cypher.append("PERSON_ID:'"+ IDlist1.get(1) + "'})\n");
            } else{
                cypher.append("PERSON_NM:'"+ IDlist1.get(1) + "'})\n");
            }
        } else {
            cypher.append("match (C1:COMPANY{COMPANY_NM:'" + IDlist1.get(0) + "'})-[]-(P1:PERSON{");
            if (isNumeric(IDlist1.get(1).toString())){
                cypher.append("PERSON_ID:'"+ IDlist1.get(1) + "'})\n");
            } else{
                cypher.append("PERSON_NM:'"+ IDlist1.get(1) + "'})\n");
            }
        }
        cypher.append("with distinct P1\n");

        if (isNumeric(IDlist2.get(0).toString())){
            cypher.append("match (C2:COMPANY{COMPANY_ID:'" + IDlist2.get(0) + "'})-[]-(P2:PERSON{");
            if (isNumeric(IDlist2.get(1).toString())){
                cypher.append("PERSON_ID:'"+ IDlist2.get(1) + "'})\n");
            } else{
                cypher.append("PERSON_NM:'"+ IDlist2.get(1) + "'})\n");
            }
        } else {
            cypher.append("match (C2:COMPANY{COMPANY_NM:'" + IDlist2.get(0) + "'})-[]-(P2:PERSON{");
            if (isNumeric(IDlist2.get(1).toString())){
                cypher.append("PERSON_ID:'"+ IDlist2.get(1) + "'})\n");
            } else{
                cypher.append("PERSON_NM:'"+ IDlist2.get(1) + "'})\n");
            }
        }

        cypher.append("with distinct P2,P1\n" +
                "match P=AllShortestPaths((P1)-[R:" + inDto.relations + "*.." + inDto.layer + "]-(P2))\n");
        cypher.append("with P,[n IN NODES(P)| SIZE([m IN FILTER(f IN NODES(P) WHERE ID(f)=ID(n))])] AS nodeIdCount WHERE ALL(x IN nodeIdCount WHERE x<2)\n" +
                "with P ORDER BY LENGTH(P) LIMIT  " + inDto.maxPath + "\n");
        cypher.append(Constants.returnQuery);

//        logger.debug(cypher);
        StatementResult result = new CypherUtil().execute(cypher.toString());

        return result;
    }


    @Override
    public ResultReturnCollection getRelationShortestPath(RelationInDto inDto) throws Exception {
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        StatementResult searchresult = null;

        ArrayList keyWordList = inDto.getKeyWords();

        for (int i = 0; i < keyWordList.size(); i++) {
            for (int j = i; j < keyWordList.size(); j++) {
                if (!keyWordList.get(i).toString().equals(keyWordList.get(j).toString())) {

                    // 公司--公司
                    if (keyWordList.get(i) instanceof String && keyWordList.get(j) instanceof String) {

                        searchresult = getReusltFromC2CShortestPath(inDto, keyWordList.get(i).toString(), keyWordList.get(j).toString());
                    }

                    // 公司--自然人
                    if (keyWordList.get(i) instanceof String && keyWordList.get(j) instanceof java.util.List) {

//                        System.out.println(keyWordList.get(i));
//                        System.out.println(keyWordList.get(j));
//                        System.out.println(keyWordList.get(j).getClass().getName());
                        searchresult = getReusltFromC2PShortestPath(inDto, keyWordList.get(i).toString(), (List) keyWordList.get(j));
                    }

                    // 自然人--公司
                    if (keyWordList.get(i) instanceof java.util.List && keyWordList.get(j) instanceof String) {

                        searchresult = getReusltFromP2CShortestPath(inDto, keyWordList.get(j).toString(), (List) keyWordList.get(i));
                    }

                    // 自然人--自然人
                    if (keyWordList.get(i) instanceof java.util.List && keyWordList.get(j) instanceof java.util.List) {

                        searchresult = getReusltFromP2PShortestPath(inDto, (List) keyWordList.get(i), (List) keyWordList.get(j));
                    }


                    while (searchresult.hasNext()) {
                        Record record = searchresult.next();
                        Map<String, Object> copiedMap = Map2Map.copyMap(record.asMap());

                        ResultReturn resultReturn = new ResultReturn(
                                QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("sourceNodeInfo")),
                                QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) copiedMap.get("relationInfo")),
                                QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("targetNodeInfo")));
                        resultReturnCollection.add(resultReturn);
                    }
                }
            }
        }
        resultReturnCollection.updateElemtList();
        return resultReturnCollection;
    }


    //找关系，之前的老版本。先返回三层内的所有路径，如果为null，则返回七层内的所有最短路径。
    @Override
    public ResultReturnCollection getRelationOld(List inData, String keyword) {
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        QueryResultModel searchresult = null;

        for (int i = 0; i < inData.size(); i++) {
            for (int j = i; j < inData.size(); j++) {
                if (!inData.get(i).equals(inData.get(j))) {
                    String label1 = inData.get(i).toString().substring(0, 1).trim();
                    String para1 = inData.get(i).toString().substring(1);
                    String label2 = inData.get(j).toString().substring(0, 1).trim();
                    String para2 = inData.get(j).toString().substring(1);
                    if (label1.equalsIgnoreCase("C") & label2.equalsIgnoreCase("C")) {
                        if (UseFulFunc.isNumeric(para1) & !UseFulFunc.isNumeric(para2)) {
                            searchresult = repository.getCompanyWithCompanyPathByNameId(para1, para2);
                            if (!searchresult.iterator().hasNext()) {
                                searchresult = repository.getCompanyWithCompanyShortestPathByNameId(para1, para2);
                            }
                        }
                        if (!UseFulFunc.isNumeric(para1) & !UseFulFunc.isNumeric(para2)) {
                            searchresult = repository.getCompanyWithCompanyPathByName(para1, para2);
                            if (!searchresult.iterator().hasNext()) {
                                searchresult = repository.getCompanyWithCompanyShortestPathByName(para1, para2);
                            }
                        }
                        if (!UseFulFunc.isNumeric(para1) & UseFulFunc.isNumeric(para2)) {
                            searchresult = repository.getCompanyWithCompanyPathByNameId(para2, para1);
                            if (!searchresult.iterator().hasNext()) {
                                searchresult = repository.getCompanyWithCompanyShortestPathByNameId(para2, para1);
                            }
                        }
                        if (UseFulFunc.isNumeric(para1) & UseFulFunc.isNumeric(para2)) {
                            searchresult = repository.getCompanyWithCompanyPathId(para1, para2);
                            if (!searchresult.iterator().hasNext()) {
                                searchresult = repository.getCompanyWithCompanyShortestPathId(para1, para2);
                            }
                        }
                    }
                    if (label1.equalsIgnoreCase("C") & label2.equalsIgnoreCase("P")) {
                        if (!UseFulFunc.isNumeric(para1)) {
                            searchresult = repository.getCompanyWithPersonPathByNameId(para1, para2);
                            if (!searchresult.iterator().hasNext()) {
                                searchresult = repository.getCompanyWithPersonShortestPathByNameId(para1, para2);
                            }
                        } else {
                            searchresult = repository.getCompanyWithPersonPathId(para1, para2);
                            if (!searchresult.iterator().hasNext()) {
                                searchresult = repository.getCompanyWithPersonShortestPathId(para1, para2);
                            }
                        }
                    }
                    if (label1.equalsIgnoreCase("P") & label2.equalsIgnoreCase("C")) {
                        if (!UseFulFunc.isNumeric(para2)) {
                            searchresult = repository.getCompanyWithPersonPathByNameId(para2, para1);
                            if (!searchresult.iterator().hasNext()) {
                                searchresult = repository.getCompanyWithPersonShortestPathByNameId(para2, para1);
                            }
                        } else {
                            searchresult = repository.getCompanyWithPersonPathId(para2, para1);
                            if (!searchresult.iterator().hasNext()) {
                                searchresult = repository.getCompanyWithPersonShortestPathId(para2, para1);
                            }
                        }
                    }
                    if (label1.equalsIgnoreCase("P") & label2.equalsIgnoreCase("P")) {
                        searchresult = repository.getPeronWithPersonPathId(para1, para2);
                        if (!searchresult.iterator().hasNext()) {
                            searchresult = repository.getPeronWithPersonShortestPathId(para1, para2);
                        }
                    }
                    if (searchresult != null) {
                        for (Map<String, Object> result : searchresult) {
                            ResultReturn resultReturn = new ResultReturn(
                                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("sourceNodeInfo")),
                                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) result.get("relationInfo")),
                                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("targetNodeInfo")));
                            resultReturnCollection.add(resultReturn);
                        }
                    }
                }
            }
        }
        resultReturnCollection.updateElemtList();
        return resultReturnCollection;
    }


    static boolean isNumeric(String str){
        Pattern pattern = Pattern.compile("[0-9]{1,20}");
        Matcher isNum = pattern.matcher(str);
        if( !isNum.matches() ){
            return false;
        }
        return true;
    }
}

