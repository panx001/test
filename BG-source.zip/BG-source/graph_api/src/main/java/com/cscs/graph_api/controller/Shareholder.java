package com.cscs.graph_api.controller;

import com.cscs.graph_api.Exception.InputException;
import com.cscs.graph_api.Util.HttpUtil;
import com.cscs.graph_api.dto.AsTop1HolderInDto;
import com.cscs.graph_api.dto.BasicInDto;
import com.cscs.graph_api.dto.BasicOutDto;
import com.cscs.graph_api.services.ShareholderServices;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping(value = "/relation")
public class Shareholder {

    private static Logger logger = LogManager.getLogger(Shareholder.class);

    @Value("${hbase.shareholder}")
    private String HBASE_SHAREHOLDER;

    @Autowired
    private ShareholderServices services;

    //top1股东
    @RequestMapping(value = "/top1Shareholder", method = RequestMethod.POST)
    public BasicOutDto top1Shareholder(@RequestBody BasicInDto inDto) throws Exception {
        long startTime = System.currentTimeMillis();

        if (inDto.getCompanyId() == null && Strings.isBlank(inDto.getCompanyNm())) throw new InputException();
        BasicOutDto outDto = new BasicOutDto();

        JSONArray content = services.searchTop1Shareholder(inDto);

        if (content.size() == 0) {
            outDto.setCode(404);
            outDto.setMsg("数据不存在");
        } else {
            outDto.setCode(200);
            outDto.setMsg("成功");
        }

        outDto.setData(content);
        logger.debug(System.currentTimeMillis() - startTime);
        return outDto;
    }


    //作为top1控股企业
    @RequestMapping(value = "/asTop1Holder", method = RequestMethod.POST)
    public BasicOutDto asTop1Holder(@RequestBody AsTop1HolderInDto inDto) throws Exception {
        long startTime = System.currentTimeMillis();

        if (inDto.getCompanyId() == null && Strings.isBlank(inDto.getCompanyNm())) throw new InputException();

        if (inDto.threshold == null) inDto.setThreshold(30D);
        if (inDto.threshold < 0 || inDto.threshold > 100) throw new InputException();
        BasicOutDto outDto = new BasicOutDto();

        JSONArray content = services.searchAsTop1Holder(inDto);

        if (content.size() == 0) {
            outDto.setCode(404);
            outDto.setMsg("数据不存在");
        } else {
            outDto.setCode(200);
            outDto.setMsg("成功");
        }

        outDto.setData(content);
        logger.debug(System.currentTimeMillis() - startTime);
        return outDto;
    }


    //top3股东
    @RequestMapping(value = "/top3Shareholder", method = RequestMethod.POST)
    public BasicOutDto top3Shareholder(@RequestBody AsTop1HolderInDto inDto) throws Exception {
        long startTime = System.currentTimeMillis();

        if (inDto.getCompanyId() == null && Strings.isBlank(inDto.getCompanyNm())) throw new InputException();

        if (inDto.threshold == null) inDto.setThreshold(30D);
        if (inDto.threshold < 0 || inDto.threshold > 100) throw new InputException();
        BasicOutDto outDto = new BasicOutDto();

        JSONArray content = services.searchTop3Shareholder(inDto);

        if (content.size() == 0) {
            outDto.setCode(404);
            outDto.setMsg("数据不存在");
        } else {
            outDto.setCode(200);
            outDto.setMsg("成功");
        }

        outDto.setData(content);
        logger.debug(System.currentTimeMillis() - startTime);
        return outDto;
    }

    //除一致行动人的前十大股东
    @RequestMapping(value = "/excludeYzxdrSharehd", method = RequestMethod.POST)
    public BasicOutDto excludeYzxdrSharehd(@RequestBody BasicInDto inDto) throws Exception {
        long startTime = System.currentTimeMillis();

        if (inDto.getCompanyId() == null && Strings.isBlank(inDto.getCompanyNm())) throw new InputException();
        BasicOutDto outDto = new BasicOutDto();

        if (inDto.getCompanyId() == null) {
            inDto.companyId = services.searchCompanyId(inDto.companyNm);
        }
        if (inDto.companyId == null) {
            outDto.setCode(404);
            outDto.setMsg("数据不存在");
            return outDto;
        }

        //rank<=10的股东信息
        JSONArray content = services.searchTop10Shareholder(inDto);

        //剔除已公示披露的一致行动关系组信息
        String hBaseResponse = HttpUtil.getHBaseResponse(MessageFormat.format(HBASE_SHAREHOLDER, String.valueOf(inDto.companyId)));
        if (hBaseResponse != null) {
            List shareList = new ArrayList();
            JSONArray sharehdList;
            if (hBaseResponse.startsWith("[")) {
                JSONArray itemList = JSONArray.fromObject(hBaseResponse);
                Collections.sort(itemList, new Comparator<JSONObject>() {
                    @Override
                    public int compare(JSONObject o1, JSONObject o2) {
                        return -o1.getString("noticeDt").compareTo(o2.getString("noticeDt"));
                    }
                });
                sharehdList = itemList.getJSONObject(0).getJSONArray("sharehdList");
            } else {
                sharehdList = JSONObject.fromObject(hBaseResponse).getJSONArray("sharehdList");
            }
            for (int i = 0; i < sharehdList.size(); i++) {
                JSONObject sharehd = sharehdList.getJSONObject(i);
                if (!sharehd.containsKey("concertedGroup")) continue;
                if (!sharehd.getString("concertedGroup").equals(""))
                    shareList.add(sharehd.getString("sharehdName"));
            }

            for (int i = 0; i < shareList.size(); i++) {
                for (int j = 0; j < content.size(); j++) {
                    JSONObject item = content.getJSONObject(j);
                    if (item.get("sharehdName").equals(shareList.get(i))) {
                        content.discard(item);
                    }
                }
            }
        }

        // 剔除top1股东的股东信息
        JSONArray top1Shareholderop = services.searchTop1Shareholder(inDto);
        for (int i = 0; i < top1Shareholderop.size(); i++) {
            JSONObject item = (JSONObject) top1Shareholderop.get(i);
            content.discard(item);
        }

        // 剔除top3控股股东的股东信息
        AsTop1HolderInDto asTop1HolderInDto = new AsTop1HolderInDto();
        asTop1HolderInDto.companyId = inDto.companyId;
        asTop1HolderInDto.companyNm = inDto.companyNm;
        asTop1HolderInDto.setThreshold(30D);
        JSONArray top3Shareholder = services.searchTop3Shareholder(asTop1HolderInDto);
        for (int i = 0; i < top3Shareholder.size(); i++) {
            JSONObject item = (JSONObject) top3Shareholder.get(i);
            item.discard("ratioRank");
            content.discard(item);
        }

        if (content.size() == 0) {
            outDto.setCode(404);
            outDto.setMsg("数据不存在");
        } else {
            outDto.setCode(200);
            outDto.setMsg("成功");
        }
        outDto.setData(content);
        logger.debug(System.currentTimeMillis() - startTime);
        return outDto;
    }


}
