package com.cscs.graph_api.domain;

import com.cscs.graph_api.Util.UseFulFunc;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import net.sf.json.JSONObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.stream.Collectors;

/**
 * Created by wuchenglong on 2018/1/7.
 */


@SuppressWarnings("unused")
public class InfoShow {

    private static Logger logger = LogManager.getLogger(InfoShow.class);

    private String id;
    private String name;
    private String controllerType;

    public InfoShow() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getControllerType() {
        return controllerType;
    }

    public void setControllerType(String controllerType) {
        this.controllerType = controllerType;
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public int hashCode() {
        return 123;
    }
}
