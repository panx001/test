package com.cscs.graph_api.dto;

import java.util.ArrayList;

public class RelationInDto {

    public Integer layer;

//    public int layer;
    //INVEST    |WORK     |CONTROLLER  |GUARANTEE |ISSUE    |RELATIVE |SUPPLIER   |CUSTOMER |TRUSTEE        |MANAGER
    //股权投资 |任职关系 |控制人关系   |担保关系  |产品发行 |亲属关系 |主要供应商 |主要客户 |私募产品托管人 |私募产品管理人
    public String relations;
    public Integer maxPath;
    public ArrayList keyWords;


    public Integer getMaxPath() {
        return maxPath;
    }

    public void setMaxPath(Integer maxPath) {
        this.maxPath = maxPath;
    }

    public Integer getLayer() {
        return layer;
    }

    public void setLayer(Integer layer) {
        this.layer = layer;
    }


    public ArrayList getKeyWords() {
        return keyWords;
    }

    public void setKeyWords(ArrayList keyWords) {
        this.keyWords = keyWords;
    }


    public String getRelations() {
        return relations;
    }

    public void setRelations(String relations) {
        this.relations = relations;
    }
}
