package com.cscs.graph_api.mapper;

//import com.cscs.graph_api.domain.FindRelationNodeShow;

import com.cscs.graph_api.domain.NodeQueryResult;
import com.cscs.graph_api.domain.NodeShow;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

/**
 * Created by wuchenglong on 2018/1/8.
 */

@SuppressWarnings("unused")
@Mapper
public interface NodeSecurityMapper {

    NodeSecurityMapper MAPPER = Mappers.getMapper(NodeSecurityMapper.class);

    @Mappings({
            @Mapping(target = "type", constant = "SECURITY"),
            @Mapping(source = "SECURITY_ID", target = "id"),
            @Mapping(source = "SECURITY_NM", target = "name")
    })
    NodeShow QueryResultToNodeShow(NodeQueryResult nodeQueryResult);

    @InheritInverseConfiguration
    NodeQueryResult NodeShowToQueryResult(NodeShow nodeShow);
}
