package com.cscs.graph_api.Util;

import org.neo4j.driver.v1.Driver;

public class Constants {

    public static Driver driver;

    public static final String returnPara = "RETURN distinct {COMPANY_ID:sourceNodeInfo.COMPANY_ID,COMPANY_TYPE:sourceNodeInfo.COMPANY_TYPE_LIST,\n" +
            " RISK_LIST:sourceNodeInfo.RISK_LIST,REG_CAPITAL:sourceNodeInfo.REG_CAPITAL," +
            " ORGNUM:sourceNodeInfo.ORGNUM,STATUS:sourceNodeInfo.STATUS,\n" +
            " COMPANY_NM:sourceNodeInfo.COMPANY_NM,\n" +
            " PERSON_ID:sourceNodeInfo.PERSON_ID,PERSON_NM:sourceNodeInfo.PERSON_NM," +
            " SECURITY_NM:sourceNodeInfo.SECURITY_NM,SECURITY_ID:sourceNodeInfo.SECINNER_ID,\n" +
            " LABELS:Labels(sourceNodeInfo)} AS sourceNodeInfo,\n" +

            "{id:ID(relationInfo),type:TYPE(relationInfo),\n" +
            " investShaRatio:CASE WHEN relationInfo.SHA_RATIO IS NOT NULL THEN tofloat(relationInfo.SHA_RATIO)\n" +
            " ELSE 0 END,\n" +
            " workPosition:relationInfo.POSITION,SC_RELATION_TYPE:relationInfo.RELATION_TYPE,\n" +
            " investNum:relationInfo.NUM," +
            " GUAR_INFO:relationInfo.GUAR_INFO,controllerType:relationInfo.RELATION_TYPE,relativeType:relationInfo.RELATION_TYPE} AS relationInfo,\n" +

            "{COMPANY_ID:targetNodeInfo.COMPANY_ID,COMPANY_TYPE:targetNodeInfo.COMPANY_TYPE_LIST,\n" +
            " RISK_LIST:targetNodeInfo.RISK_LIST,REG_CAPITAL:targetNodeInfo.REG_CAPITAL,\n" +
            " ORGNUM:targetNodeInfo.ORGNUM,STATUS:targetNodeInfo.STATUS,\n" +
            " COMPANY_NM:targetNodeInfo.COMPANY_NM,\n" +
            " PERSON_ID:targetNodeInfo.PERSON_ID,PERSON_NM:targetNodeInfo.PERSON_NM," +
            " SECURITY_NM:targetNodeInfo.SECURITY_NM,SECURITY_ID:targetNodeInfo.SECINNER_ID,\n" +
            " LABELS:Labels(targetNodeInfo)} AS targetNodeInfo;";

    public static final String returnQuery = "UNWIND relationships(P) AS R\n" +
            "WITH startNode(R) AS sourceNodeInfo , R AS relationInfo, endNode(R) AS targetNodeInfo\n" +
            Constants.returnPara;


    public static final String returnParaGF = "return distinct \n" +
            "{COMPANY_ID:sourceNodeInfo.COMPANY_ID,COMPANY_TYPE:sourceNodeInfo.COMPANY_TYPE_LIST,RISK_LIST:sourceNodeInfo.RISK_LIST,REG_CAPITAL:sourceNodeInfo.REG_CAPITAL,ORGNUM:sourceNodeInfo.ORGNUM,STATUS:sourceNodeInfo.STATUS,COMPANY_NM:sourceNodeInfo.COMPANY_NM,PERSON_ID:sourceNodeInfo.PERSON_ID,PERSON_NM:sourceNodeInfo.PERSON_NM,SECURITY_NM:sourceNodeInfo.SECURITY_NM,SECURITY_ID:sourceNodeInfo.SECINNER_ID,LABELS:Labels(sourceNodeInfo),\n" +
            "GROUPPOS: case when id(M)=id(sourceNodeInfo) then '母公司' else '子公司' end} AS sourceNodeInfo,\n" +
            "{id:ID(relationInfo),type:TYPE(relationInfo),investShaRatio:CASE WHEN relationInfo.SHA_RATIO IS NOT NULL THEN tofloat(relationInfo.SHA_RATIO) ELSE 0 END,workPosition:relationInfo.POSITION,SC_RELATION_TYPE:relationInfo.RELATION_TYPE, investNum:relationInfo.NUM, GUAR_INFO:relationInfo.GUAR_INFO,controllerType:relationInfo.RELATION_TYPE,relativeType:relationInfo.RELATION_TYPE} AS relationInfo,\n" +
            "{COMPANY_ID:targetNodeInfo.COMPANY_ID,COMPANY_TYPE:targetNodeInfo.COMPANY_TYPE_LIST,RISK_LIST:targetNodeInfo.RISK_LIST,REG_CAPITAL:targetNodeInfo.REG_CAPITAL,ORGNUM:targetNodeInfo.ORGNUM,STATUS:targetNodeInfo.STATUS,COMPANY_NM:targetNodeInfo.COMPANY_NM,PERSON_ID:targetNodeInfo.PERSON_ID,PERSON_NM:targetNodeInfo.PERSON_NM,SECURITY_NM:targetNodeInfo.SECURITY_NM,SECURITY_ID:targetNodeInfo.SECINNER_ID,LABELS:Labels(targetNodeInfo),\n" +
            "GROUPPOS: case when id(M)=id(targetNodeInfo) then '母公司' else '子公司' end} AS targetNodeInfo";

    public static final String returnParaGFNew = "return distinct \n" +
            "{COMPANY_ID:sourceNodeInfo.COMPANY_ID,COMPANY_TYPE:sourceNodeInfo.COMPANY_TYPE_LIST,RISK_LIST:sourceNodeInfo.RISK_LIST,REG_CAPITAL:sourceNodeInfo.REG_CAPITAL,ORGNUM:sourceNodeInfo.ORGNUM,STATUS:sourceNodeInfo.STATUS,COMPANY_NM:sourceNodeInfo.COMPANY_NM,PERSON_ID:sourceNodeInfo.PERSON_ID,PERSON_NM:sourceNodeInfo.PERSON_NM,SECURITY_NM:sourceNodeInfo.SECURITY_NM,SECURITY_ID:sourceNodeInfo.SECINNER_ID,LABELS:Labels(sourceNodeInfo),GROUPPOS: case when id(sourceNodeInfo)=id(M) then '母公司' when id(sourceNodeInfo) in IDSUB then '子公司' else '其他成员公司' end} AS sourceNodeInfo,\n" +
            "{id:ID(relationInfo),type:TYPE(relationInfo),investShaRatio:CASE WHEN relationInfo.SHA_RATIO IS NOT NULL THEN tofloat(relationInfo.SHA_RATIO) ELSE 0 END,workPosition:relationInfo.POSITION,SC_RELATION_TYPE:relationInfo.RELATION_TYPE, investNum:relationInfo.NUM, GUAR_INFO:relationInfo.GUAR_INFO,controllerType:relationInfo.RELATION_TYPE,relativeType:relationInfo.RELATION_TYPE} AS relationInfo,\n" +
            "{COMPANY_ID:targetNodeInfo.COMPANY_ID,COMPANY_TYPE:targetNodeInfo.COMPANY_TYPE_LIST,RISK_LIST:targetNodeInfo.RISK_LIST,REG_CAPITAL:targetNodeInfo.REG_CAPITAL,ORGNUM:targetNodeInfo.ORGNUM,STATUS:targetNodeInfo.STATUS,COMPANY_NM:targetNodeInfo.COMPANY_NM,PERSON_ID:targetNodeInfo.PERSON_ID,PERSON_NM:targetNodeInfo.PERSON_NM,SECURITY_NM:targetNodeInfo.SECURITY_NM,SECURITY_ID:targetNodeInfo.SECINNER_ID,LABELS:Labels(targetNodeInfo),GROUPPOS: case when id(targetNodeInfo)=id(M) then '母公司' when id(targetNodeInfo) in IDSUB then '子公司' else '其他成员公司' end} AS targetNodeInfo";


//    public static final String returnPara = "RETURN {COMPANY_ID:sourceNodeInfo.COMPANY_ID,COMPANY_TYPE:sourceNodeInfo.COMPANY_TYPE_LIST,\n" +
//            " RISK_LIST:sourceNodeInfo.RISK_LIST,REG_CAPITAL:sourceNodeInfo.REG_CAPITAL," +
//            " ORGNUM:sourceNodeInfo.ORGNUM,STATUS:sourceNodeInfo.STATUS,\n" +
//            " COMPANY_NM:sourceNodeInfo.COMPANY_NM,LINK_ID:CASE WHEN 'PERSON' IN LABELS(sourceNodeInfo) \n" +
//            " THEN targetNodeInfo.COMPANY_NM +\"&&\"+ sourceNodeInfo.PERSON_NM ELSE sourceNodeInfo.COMPANY_NM END,\n" +
//            " PERSON_ID:sourceNodeInfo.PERSON_ID,PERSON_NM:sourceNodeInfo.PERSON_NM," +
//            " SECURITY_NM:sourceNodeInfo.SECURITY_NM,SECURITY_ID:sourceNodeInfo.SECINNER_ID,\n" +
//            " LABELS:Labels(sourceNodeInfo)} AS sourceNodeInfo,\n" +
//            "{type:TYPE(relationInfo),\n" +
//            " investShaRatio:CASE WHEN relationInfo.SHA_RATIO IS NOT NULL THEN tofloat(relationInfo.SHA_RATIO)\n" +
//            " WHEN relationInfo.SHA_RATIO IS NULL AND relationInfo.NUM IS NOT NULL AND apoc.cscs.getRegCapital(relationInfo) <> 0\n" +
//            " THEN tofloat(relationInfo.NUM)/apoc.cscs.getRegCapital(relationInfo)*100 ELSE 0 END,\n" +
//            " workPosition:relationInfo.POSITION,SC_RELATION_TYPE:relationInfo.RELATION_TYPE,\n" +
//            " investNum:relationInfo.NUM,GUAR_INFO:relationInfo.GUAR_INFO} AS relationInfo,\n" +
//            "{COMPANY_ID:targetNodeInfo.COMPANY_ID,COMPANY_TYPE:targetNodeInfo.COMPANY_TYPE_LIST,\n" +
//            " RISK_LIST:targetNodeInfo.RISK_LIST,REG_CAPITAL:targetNodeInfo.REG_CAPITAL,\n" +
//            " ORGNUM:sourceNodeInfo.ORGNUM,STATUS:sourceNodeInfo.STATUS,\n" +
//            " COMPANY_NM:targetNodeInfo.COMPANY_NM,LINK_ID:CASE WHEN 'PERSON' IN LABELS(targetNodeInfo)\n" +
//            " THEN sourceNodeInfo.COMPANY_NM +\"&&\"+ targetNodeInfo.PERSON_NM ELSE targetNodeInfo.COMPANY_NM END,\n" +
//            " PERSON_ID:sourceNodeInfo.PERSON_ID,PERSON_NM:sourceNodeInfo.PERSON_NM," +
//            " SECURITY_NM:sourceNodeInfo.SECURITY_NM,SECURITY_ID:sourceNodeInfo.SECINNER_ID,\n" +
//            " LABELS:Labels(targetNodeInfo)} AS targetNodeInfo;";
//
//    public static final String returnQuery = "UNWIND relationships(P) AS R\n" +
//            "WITH startNode(R) AS sourceNodeInfo , R AS relationInfo, endNode(R) AS targetNodeInfo\n" +
//            "OPTIONAL MATCH (targetNodeInfo)<-[r:INVEST]-()\n" +
//            "WITH sourceNodeInfo,relationInfo,targetNodeInfo,CASE WHEN ALL(x IN collect(r)\n" +
//            "WHERE EXISTS(x.NUM) and x.NUM <> '0') THEN sum(ToFloat(r.NUM))  ELSE targetNodeInfo.REG_CAPITAL END AS REG_CAPITAL\n" +
//            Constants.returnPara;

}
