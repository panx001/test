package com.cscs.graph_api.services;

import com.cscs.graph_api.domain.ResultReturnCollection;
import com.cscs.graph_api.dto.GraphInDto;
import org.springframework.cache.annotation.Cacheable;

public interface GraphServices {
    //图谱取得
    @Cacheable(value = "relation", key = "targetClass.getName()+methodName+#inDto.companyId+#inDto.companyNm+#inDto.layer+#inDto.relations")
    ResultReturnCollection getGraph(GraphInDto inDto) throws Exception;
}
