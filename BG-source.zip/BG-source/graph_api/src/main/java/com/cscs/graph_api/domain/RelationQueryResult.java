package com.cscs.graph_api.domain;

/**
 * Created by wuchenglong on 2018/1/9.
 */

@SuppressWarnings("unused")
public class RelationQueryResult {

    private Long id;
    private String type;  // 关系类型
    private String investNum;  // 投资金额
    private String investShaRatio;  // 投资比例
    private String workPosition;    // 任职职位
    private String controllerType;  //控制人类型
    private String relativeType;    //亲属关系类型


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getInvestNum() {
        return investNum;
    }

    public void setInvestNum(String investNum) {
        this.investNum = investNum;
    }

    public String getInvestShaRatio() {
        return investShaRatio;
    }

    public void setInvestShaRatio(String investShaRatio) {
        this.investShaRatio = investShaRatio;
    }

    public String getWorkPosition() {
        return workPosition;
    }

    public void setWorkPosition(String workPosition) {
        this.workPosition = workPosition;
    }

    public String getControllerType() {
        return controllerType;
    }

    public void setControllerType(String controllerType) {
        this.controllerType = controllerType;
    }

    public String getRelativeType() {
        return relativeType;
    }

    public void setRelativeType(String relativeType) {
        this.relativeType = relativeType;
    }
}
