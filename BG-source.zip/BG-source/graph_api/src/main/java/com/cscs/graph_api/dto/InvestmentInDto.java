package com.cscs.graph_api.dto;

public class InvestmentInDto {
    public String companyNm;
    public Long companyId;
    public int investLayer;
    public int shareholderLayer;

    public String getCompanyNm() {
        return companyNm;
    }

    public void setCompanyNm(String companyNm) {
        this.companyNm = companyNm;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public int getInvestLayer() {
        return investLayer;
    }

    public void setInvestLayer(int investLayer) {
        this.investLayer = investLayer;
    }

    public int getShareholderLayer() {
        return shareholderLayer;
    }

    public void setShareholderLayer(int shareholderLayer) {
        this.shareholderLayer = shareholderLayer;
    }
}
