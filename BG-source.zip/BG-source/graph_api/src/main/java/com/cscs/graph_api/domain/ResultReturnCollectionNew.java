package com.cscs.graph_api.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.collections.list.SetUniqueList;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by wuchenglong on 2018/1/9.
 */

@SuppressWarnings("unused")
public class ResultReturnCollectionNew {

    private static Logger logger = LogManager.getLogger(ResultReturnCollectionNew.class);

    @JsonProperty("info")
    private List<InfoShow> infoShowsUniqueList = SetUniqueList.decorate(new ArrayList<InfoShow>());          //定义InfoShow

    @JsonProperty("nodes")
    private List<NodeShow> nodeShowsUniqueList = SetUniqueList.decorate(new ArrayList<NodeShow>());
    @JsonProperty("links")
    private List<RelationShipShow> relationShipShowUniqueList = SetUniqueList.decorate(new ArrayList<RelationShipShow>());

    @JsonIgnore
    private HashMap<String, InfoShow> infoShowHashMap = new HashMap<>();
    @JsonIgnore
    private HashMap<String, NodeShow> nodeShowHashMap = new HashMap<>();
    @JsonIgnore
    private HashMap<String, RelationShipShow> relationShipShowHashMap = new HashMap<>();


    public ResultReturnCollectionNew() {

    }

    public void setInfoShowHashMap(HashMap<String, InfoShow> infoShowHashMap) {
        this.infoShowHashMap = infoShowHashMap;
    }
    public HashMap<String, InfoShow> getInfoShowHashMap() {
        return infoShowHashMap;
    }

    public void setInfoShowsUniqueList(List<InfoShow> infoShowsUniqueList) {
        this.infoShowsUniqueList = infoShowsUniqueList;
    }

    public List<InfoShow> getInfoShowsUniqueList() {
        return infoShowsUniqueList;
    }

    public void add(InfoShow infoShow) {
        if (!this.infoShowHashMap.containsKey(infoShow.getId())) {
            this.infoShowHashMap.put(infoShow.getId(), infoShow);
        }
    }




    public void setNodeShowHashMap(HashMap<String, NodeShow> nodeShowHashMap) {
        this.nodeShowHashMap = nodeShowHashMap;
    }
    public HashMap<String, NodeShow> getNodeShowHashMap() {
        return nodeShowHashMap;
    }

    public HashMap<String, RelationShipShow> getRelationShipShowHashMap() {
        return relationShipShowHashMap;
    }

    public void setRelationShipShowHashMap(HashMap<String, RelationShipShow> relationShipShowHashMap) {
        this.relationShipShowHashMap = relationShipShowHashMap;
    }

    public void setNodeShowsUniqueList(List<NodeShow> nodeShowsUniqueList) {
        this.nodeShowsUniqueList = nodeShowsUniqueList;
    }

    public List<NodeShow> getNodeShowsUniqueList() {
        return nodeShowsUniqueList;
    }

    public void setRelationShipShowUniqueList(List<RelationShipShow> relationShipShowUniqueList) {
        this.relationShipShowUniqueList = relationShipShowUniqueList;
    }

    public List<RelationShipShow> getRelationShipShowUniqueList() {
        return relationShipShowUniqueList;
    }

    public void add(NodeShow nodeShow) {
        if (!this.nodeShowHashMap.containsKey(nodeShow.getId())) {
            this.nodeShowHashMap.put(nodeShow.getId(), nodeShow);
        }
    }

    public void add(RelationShipShow relationShipShow) {
        if (!this.relationShipShowHashMap.containsKey(relationShipShow.getId())) {
            this.relationShipShowHashMap.put(relationShipShow.getId(), relationShipShow);
        }
    }

    public void add(ResultReturnNew resultReturnNew) {
        this.add(resultReturnNew.getStartNodeShow());
        this.add(resultReturnNew.getEndNodeShow());
        this.add(resultReturnNew.getRelationShipShow());
        this.add(resultReturnNew.getInfoShow());
    }

    public void updateElemtList() {
        for (Object o1 : nodeShowHashMap.entrySet()) {
            Map.Entry entry = (Map.Entry) o1;
            if (entry.getKey() == null) continue;
            nodeShowsUniqueList.add((NodeShow) (entry.getValue()));
        }

        for (Object o : relationShipShowHashMap.entrySet()) {
            Map.Entry entry = (Map.Entry) o;
            if (entry.getKey() == null) continue;
            relationShipShowUniqueList.add((RelationShipShow) entry.getValue());
        }

        for (Object o2 : infoShowHashMap.entrySet()) {
            Map.Entry entry = (Map.Entry) o2;
            if (entry.getKey() == null) continue;
            infoShowsUniqueList.add((InfoShow) entry.getValue());
        }
    }
}
