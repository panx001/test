
package com.cscs.graph_api.services;
import com.cscs.graph_api.domain.ResultReturnCollection;
import com.cscs.graph_api.domain.ResultReturnCollectionNew;
import com.cscs.graph_api.dto.ControllerInDto;
import net.sf.json.JSONArray;
import org.springframework.cache.annotation.Cacheable;


public interface ControllerServices {

    //实际控制人或疑似实际控制人取得
    @Cacheable(value = "relation", key = "targetClass.getName()+methodName+#company")
    ResultReturnCollectionNew getActController(String company);

    //企业股东筛选接口
    @Cacheable(value = "relation", key = "targetClass.getName()+ methodName+#inDto.companyId + #inDto.companyNm + #inDto.sumRatio")
    JSONArray searchControllerThreshold(ControllerInDto inDto) throws Exception;

    //企业股东筛选接口(默认返回3层股东)
    @Cacheable(value = "relation", key = "targetClass.getName()+ methodName+#inDto.companyId + #inDto.companyNm + #inDto.sumRatio")
    JSONArray searchDefaultControllerThreshold(ControllerInDto inDto) throws Exception;
}