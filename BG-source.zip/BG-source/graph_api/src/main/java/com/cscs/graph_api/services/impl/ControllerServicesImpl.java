package com.cscs.graph_api.services.impl;

import com.cscs.graph_api.Util.CypherUtil;
import com.cscs.graph_api.Util.UseFulFunc;
import com.cscs.graph_api.domain.ResultReturnCollectionNew;
import com.cscs.graph_api.domain.ResultReturnNew;
import com.cscs.graph_api.dto.ControllerInDto;
import com.cscs.graph_api.mapper.QueryResultMapper;
import com.cscs.graph_api.repositories.ControllerRepository;
import com.cscs.graph_api.services.ControllerServices;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.neo4j.driver.internal.util.Iterables;
import org.neo4j.driver.v1.Record;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.ogm.response.model.QueryResultModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

//import com.cscs.graph_api.domain.ResultReturn;
//import com.cscs.graph_api.domain.ResultReturnCollection;

@Service
public class ControllerServicesImpl implements ControllerServices {

    @Autowired
    ControllerRepository repository;

    @Override
    public ResultReturnCollectionNew getActController(String company) {

        ResultReturnCollectionNew resultReturnCollectionNew = new ResultReturnCollectionNew();
        QueryResultModel companyNode;
        if (UseFulFunc.isNumeric(company)) {
            QueryResultModel typeflag = repository.JudgeCompanyTpye(company);
            if (Iterables.asList(typeflag.queryResults()).isEmpty()) {
                companyNode = repository.getSuspActControllerByCompanyIdNew(company);
            } else {
                companyNode = repository.getActControllerByCompanyIdNew(company);
            }
        } else {
            QueryResultModel typeflag = repository.JudgeCompanyTpyeByNm(company);
            if (Iterables.asList(typeflag.queryResults()).isEmpty()) {
                companyNode = repository.getSuspActControllerByCompanyNmNew(company);
            } else {
                companyNode = repository.getActControllerByCompanyNmNew(company);
            }
        }
        for (Map<String, Object> result : companyNode) {
            ResultReturnNew resultReturnNew = new ResultReturnNew(
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("sourceNodeInfo")),
                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) result.get("relationInfo")),
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) result.get("targetNodeInfo")),
                    QueryResultMapper.MapInfoShowMapper((Map<String, Object>) result.get("output")));
            resultReturnCollectionNew.add(resultReturnNew);
        }
        resultReturnCollectionNew.updateElemtList();
        return resultReturnCollectionNew;

    }

    @Override
    public JSONArray searchControllerThreshold(ControllerInDto inDto) throws Exception {
        JSONArray contentArray = new JSONArray();
        StringBuilder cypher = new StringBuilder();
        cypher.append("MATCH path = (C:COMPANY{");
        if (inDto.companyId != null) {
            cypher.append("COMPANY_ID:\"" + inDto.companyId + "\"");
        } else {
            cypher.append("COMPANY_NM:\"" + inDto.companyNm + "\"");
        }
        cypher.append("})<-[R:INVEST*..5]-(P)\n");
//            cypher.append("where not (P)<-[:INVEST]-()\n");
        cypher.append("WITH C,P,\n" +
                "COLLECT([p in rels(path)|\n" +
                "  CASE \n" +
                " WHEN p.SHA_RATIO IS NOT NULL \n" +
                " THEN tofloat(p.SHA_RATIO)*0.01 \n" +
                " WHEN p.SHA_RATIO IS NULL AND p.NUM IS NOT NULL AND apoc.cscs.getRegCapital(p) <> 0      //getRegCapital该边指向企业的注册资本\n" +
                " THEN tofloat(p.NUM)/apoc.cscs.getRegCapital(p) \n" +
                " ELSE 0 \n" +
                " END]) AS paths,  //计算每条路径的 持股比例 \n" +
                " COLLECT([p in rels(path)|startNode(p).COMPANY_NM]) AS pathsNm //路径开始节点的name集合 （应该先判断公司/自然人） \n" +
                "\n" +
                "UNWIND  RANGE(0,LENGTH(paths)-1) AS pathsindex  \n" +
                "UNWIND RANGE(0,LENGTH(paths[pathsindex])-1) as valuesIndex\n" +
                "WITH C,P, pathsindex,\n" +
                "paths[pathsindex] AS values,\n" +
                "apoc.agg.product(paths[pathsindex][valuesIndex]) as p,\n" +
                "paths as pathValue,\n" +
                "pathsNm\n" +
                "WITH C,P,pathValue,\n" +
                "COLLECT(p) AS pValues,\n" +
                "pathsNm \n" +
                "WITH C,P, \n" +
                "CASE \n" +
                "WHEN 'COMPANY' IN LABELS(P) \n" +
                "THEN P.COMPANY_NM \n" +
                "ELSE P.PERSON_NM  \n" +
                "END AS CONTROLLER_NM,\n" +
                "CASE \n" +
                "WHEN 'COMPANY' IN LABELS(P) \n" +
                "THEN P.COMPANY_ID \n" +
                "ELSE P.PERSON_ID \n" +
                "END AS CONTROLLER_ID,\n" +
                "pathValue,\n" +
                "pValues,\n" +
                "apoc.coll.sum(pValues) AS totalValue,\n" +
                "pathsNm \n" +
                "WHERE totalValue > " + inDto.sumRatio / 100 + "\n" +
                "\n" +
                "with CONTROLLER_NM,CONTROLLER_ID,C,totalValue\n" +
                "MATCH CP = (C)<-[:INVEST*..5]-(P)\n" +
                "where P.COMPANY_NM = CONTROLLER_NM or P.PERSON_NM = CONTROLLER_NM\n" +
                "with nodes(CP) as coll_name,CONTROLLER_NM,CONTROLLER_ID,totalValue,P,[n IN NODES(CP)| SIZE([m IN FILTER(f IN NODES(CP) WHERE ID(f)=ID(n))])] \n" +
                "    AS nodeIdCount \n" +
                "    WHERE ALL(x IN nodeIdCount WHERE x<2) \n" +
                "unwind coll_name as name_new\n" +
                "with CASE \n" +
                "WHEN 'COMPANY' IN LABELS(name_new) \n" +
                "THEN name_new.COMPANY_NM \n" +
                "ELSE name_new.PERSON_NM  \n" +
                "END AS name,CONTROLLER_NM,CONTROLLER_ID,totalValue,P\n" +
                "with CONTROLLER_ID as sharehdId,CONTROLLER_NM as sharehdName,LABELS(P) as sharehdType,\n" +
                "totalValue as sharehdRatio,collect(name) as sharehdPath,CASE WHEN 'COMPANY' IN LABELS(P) THEN P.REG_CAPITAL END AS regCapital,\n" +
                "CASE WHEN 'COMPANY' IN LABELS(P) THEN P.STATUS END AS status,CASE WHEN 'COMPANY' IN LABELS(P) THEN P.ORGNUM END AS orgnum\n" +
                "return sharehdId,sharehdName,sharehdType,sharehdRatio,sharehdPath,regCapital,status,orgnum");

        StatementResult result = new CypherUtil().execute(cypher.toString());
        while (result.hasNext()) {
            JSONObject content = addSharehd((Record) result.next());
            contentArray.add(content);
        }
        return contentArray;
    }

    @Override
    public JSONArray searchDefaultControllerThreshold(ControllerInDto inDto) throws Exception {
        JSONArray contentArray = new JSONArray();
        StringBuilder cypher = new StringBuilder();
        cypher.append("MATCH path = (C:COMPANY{");
        if (inDto.companyId != null) {
            cypher.append("COMPANY_ID:\"" + inDto.companyId + "\"");
        } else {
            cypher.append("COMPANY_NM:\"" + inDto.companyNm + "\"");
        }
        cypher.append("})<-[:INVEST*..3]-(P)\n");
        cypher.append("WITH CASE WHEN 'COMPANY'IN LABELS(P) THEN P.COMPANY_ID\n");
        cypher.append("WHEN 'SECURITY' IN LABELS(P) THEN P.SECURITY_CD\n");
        cypher.append("ELSE P.PERSON_ID END AS sharehdId,\n");
        cypher.append("CASE WHEN 'COMPANY' IN LABELS(P)THEN P.COMPANY_NM\n");
        cypher.append("WHEN 'SECURITY'IN LABELS(P) THEN P.SECURITY_NM\n");
        cypher.append("ELSE P.PERSON_NM END AS sharehdName,\n");
        cypher.append("Labels(P) AS sharehdType,\n");
        cypher.append("P,\n");
        cypher.append("COLLECT([p in nodes(path)|CASE WHEN 'COMPANY' IN LABELS(p)THEN p.COMPANY_NM");
        cypher.append(" WHEN 'SECURITY'IN LABELS(p) THEN p.SECURITY_NM ELSE p.PERSON_NM END]) AS sharehdPath,");
        cypher.append("COLLECT([p in rels(path)|CASE WHEN p.SHA_RATIO IS NOT NULL\n");
        cypher.append("THEN tofloat(p.SHA_RATIO) * 0.01\n");
        cypher.append("WHEN p.SHA_RATIO IS NULL AND p.NUM IS NOT NULL AND apoc.cscs.getRegCapital(p) <> 0 //getRegCapital该边指向企业的注册资本\n");
        cypher.append("THEN tofloat(p.NUM)/apoc.cscs.getRegCapital(p) ELSE 0 END]) AS pathVaule  //计算每条路径的 持股比例\n");
        cypher.append("UNWIND RANGE(0,LENGTH(pathVaule)-1) AS pathsindex\n");
        cypher.append("UNWIND RANGE(0,LENGTH(pathVaule[pathsindex])-1) as valuesIndex\n");
        cypher.append("WITH sharehdId,sharehdName,sharehdType,P,\n");
        cypher.append("apoc.agg.product(pathVaule[pathsindex][valuesIndex]) as pathsVaule,sharehdPath\n");
        cypher.append("WITH sharehdId,sharehdName,sharehdType,apoc.coll.sum(COLLECT(pathsVaule)) AS sharehdRatio,sharehdPath\n");
        cypher.append(",CASE WHEN 'COMPANY' IN LABELS(P) THEN P.REG_CAPITAL END AS regCapital,\n");
        cypher.append("CASE WHEN 'COMPANY' IN LABELS(P) THEN P.STATUS END AS status,\n");
        cypher.append("CASE WHEN 'COMPANY' IN LABELS(P) THEN P.ORGNUM END AS orgnum\n");
        cypher.append("return sharehdId,sharehdName,sharehdType,sharehdRatio,sharehdPath,regCapital,status,orgnum");

        StatementResult result = new CypherUtil().execute(cypher.toString());
        while (result.hasNext()) {
            JSONObject content = addSharehd(result.next());
            contentArray.add(content);
        }
        return contentArray;
    }

    private JSONObject addSharehd(Record record) {
        JSONObject content = new JSONObject();
        Map item = record.asMap();

        String sharehdName = item.get("sharehdName").toString();
        content.put("sharehdId", item.get("sharehdId"));
        content.put("sharehdName", sharehdName);
        String sharehdType = item.get("sharehdType").toString();
        if (sharehdType.contains("COMPANY")) {
            content.put("sharehdType", "1");
        } else if (sharehdType.contains("PERSON")) {
            content.put("sharehdType", "2");
        } else if (sharehdType.contains("SECURITY")) {
            content.put("sharehdType", "3");
        }
        content.put("sumRatio", (Double) item.get("sharehdRatio") * 100);
        content.put("regCapital",item.get("regCapital"));
        content.put("status",item.get("status"));
        content.put("orgnum",item.get("orgnum"));

        int minLayers = 0, start = 0;
        JSONArray pathArray = new JSONArray();
        String pathContent = "";
        List paths = (List) item.get("sharehdPath");
        List pathNode = new ArrayList();
        if (paths.get(0) instanceof List) {
            for (int i = 0; i < paths.size(); i++) {
                List tmpList = (List) paths.get(i);
                for (int j = 0; j < tmpList.size(); j++) {
                    pathNode.add(tmpList.get(j));
                }
            }
        } else {
            pathNode = paths;
        }
        for (int i = 0; i < pathNode.size(); i++) {
            String path = pathNode.get(i).toString();
            if (!pathContent.equals("")) pathContent += "-";
            pathContent += path;
            if (path.equals(sharehdName)) {
                pathArray.add(pathContent);
                if (minLayers == 0 || minLayers > i - start) {
                    minLayers = i - start;
                }
                if (i == paths.size()) {
                    if (minLayers > i - start)
                        minLayers = i - start;
                }
                start = i + 1;
                pathContent = "";
            }
        }
        content.put("minLayers", minLayers);
        content.put("path", pathArray);
        return content;
    }
}
