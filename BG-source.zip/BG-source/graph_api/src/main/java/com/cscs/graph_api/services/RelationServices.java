package com.cscs.graph_api.services;

import com.cscs.graph_api.domain.ResultReturnCollection;
import com.cscs.graph_api.dto.GraphInDto;
import com.cscs.graph_api.dto.RelationInDto;
import org.springframework.cache.annotation.Cacheable;

import java.util.List;

public interface RelationServices {
    //关系取得
    @Cacheable(value = "relation", key = "targetClass.getName()+methodName+ #keyword")
    ResultReturnCollection getRelationOld(List inData, String keyword);

//    @Cacheable(value = "relation", key = "targetClass.getName()+methodName+#inDto.maxPath+#inDto.keyWords+#inDto.layer+#inDto.relations")
    ResultReturnCollection getRelation(RelationInDto inDto) throws Exception;

//    @Cacheable(value = "relation", key = "targetClass.getName()+methodName+#inDto.maxPath+#inDto.keyWords+#inDto.layer+#inDto.relations")
    ResultReturnCollection getRelationShortestPath(RelationInDto inDto) throws Exception;

}

