package com.cscs.graph_api.services.impl;

import com.cscs.graph_api.Util.Constants;
import com.cscs.graph_api.Util.CypherUtil;
import com.cscs.graph_api.Util.Map2Map;
import com.cscs.graph_api.domain.ResultReturn;
import com.cscs.graph_api.domain.ResultReturnCollection;
import com.cscs.graph_api.dto.GraphInDto;
import com.cscs.graph_api.mapper.QueryResultMapper;
import com.cscs.graph_api.services.GraphServices;
import org.apache.logging.log4j.util.Strings;
import org.neo4j.driver.v1.Record;
import org.neo4j.driver.v1.StatementResult;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class GraphServicesImpl implements GraphServices {

    @Override
    public ResultReturnCollection getGraph(GraphInDto inDto) throws Exception {
        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        StringBuilder cypher = new StringBuilder();
        boolean chkCondetion = false;
        if (inDto.getCompanyId() != null && !Strings.isBlank(inDto.getCompanyNm())) chkCondetion = true;

        // 层数为0 从当前节点出发
        if (inDto.getLayer() == 0) {
            cypher.append("MATCH p1 = (A1:COMPANY{");
            if (inDto.getCompanyId() != null) cypher.append("COMPANY_ID:'" + inDto.getCompanyId() + "'");
            if (chkCondetion) cypher.append(",");
            if (!Strings.isBlank(inDto.getCompanyNm())) cypher.append("COMPANY_NM:'" + inDto.getCompanyNm() + "'");
            cypher.append("})-[r1:" + inDto.getRelations() + "*..1" + "]-(d1) " + "with p1 AS P\n" + Constants.returnQuery);
        }
        // 层数不为0 从当前节点出发 通过对外投资（向下）和股东（向上）向外拓展
        else {
            cypher.append("MATCH p1 = (A1:COMPANY{");
            if (inDto.getCompanyId() != null) cypher.append("COMPANY_ID:'" + inDto.getCompanyId() + "'");
            if (chkCondetion) cypher.append(",");
            if (!Strings.isBlank(inDto.getCompanyNm())) cypher.append("COMPANY_NM:'" + inDto.getCompanyNm() + "'");
            cypher.append("})-[r1:INVEST" + "*.." + inDto.layer + "]->(d1) with collect(p1) AS path1 \n");

            cypher.append("MATCH p2 = (A2:COMPANY{");
            if (inDto.getCompanyId() != null) cypher.append("COMPANY_ID:'" + inDto.getCompanyId() + "'");
            if (chkCondetion) cypher.append(",");
            if (!Strings.isBlank(inDto.getCompanyNm())) cypher.append("COMPANY_NM:'" + inDto.getCompanyNm() + "'");
            cypher.append("})<-[r2:INVEST" + "*.." + inDto.layer + "]-(d2) " +
                    "with path1,collect(p2) AS path2 \n");
            cypher.append("with path1+path2 as path\n" +
                    "unwind path as path_new\n" +
                    "unwind nodes(path_new) as Q\n" +
                    "with distinct Q as N,path\n" +
                    "match p3=(N)-[r3:" + inDto.relations + "]-(M)\n" +
                    "with path,collect(p3) AS path3\n" +
                    "with path+path3 as PATH\n" +
                    "unwind PATH as Path\n" +
                    "with distinct Path as P\n " + Constants.returnQuery);
        }

        StatementResult result = new CypherUtil().execute(cypher.toString());
        while (result.hasNext()) {
            Record record = result.next();
            Map<String, Object> copiedMap = Map2Map.copyMap(record.asMap());

            ResultReturn resultReturn = new ResultReturn(
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("sourceNodeInfo")),
                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) copiedMap.get("relationInfo")),
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("targetNodeInfo")));
            resultReturnCollection.add(resultReturn);
        }
        resultReturnCollection.updateElemtList();
        return resultReturnCollection;
    }
}
