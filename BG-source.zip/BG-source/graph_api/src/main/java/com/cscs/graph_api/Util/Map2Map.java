package com.cscs.graph_api.Util;

import org.neo4j.driver.internal.InternalNode;
import org.neo4j.driver.internal.InternalRelationship;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by wuchenglong on 2018/1/8.
 */

@SuppressWarnings("unused")
public class Map2Map {

    public static Map<String, Object> copyMap(Map<String, Object> sourceMap) {
        Map<String, Object> copiedMap = new HashMap<>();
        for (Map.Entry<String, Object> entry : sourceMap.entrySet()) {
            Object value = entry.getValue();
            if (entry.getValue() instanceof InternalNode) {
                value = copyMap(((InternalNode) value).asMap());
            }
            if (entry.getValue() instanceof InternalRelationship) {
                value = copyMap(((InternalRelationship) value).asMap());
            }
            if (entry.getValue() instanceof Map) {
                value = copyMap((Map) value);
            }
            if (entry.getValue() instanceof List) {
                List targetList = new ArrayList();
                List sourceList = (List) entry.getValue();
                for (Object item : sourceList) targetList.add(item);
                value = targetList;
            }
            copiedMap.put(entry.getKey(), value);
        }
        return copiedMap;
    }
}
