
package com.cscs.graph_api.services;
import com.cscs.graph_api.dto.AsTop1HolderInDto;
import com.cscs.graph_api.dto.BasicInDto;
import com.cscs.graph_api.dto.AsTop1HolderInDto;
import net.sf.json.JSONArray;
import org.springframework.cache.annotation.Cacheable;


public interface ShareholderServices {

    //top1股东
    @Cacheable(value = "relation", key = "targetClass.getName()+ methodName+#inDto.companyId + #inDto.companyNm")
    JSONArray searchTop1Shareholder(BasicInDto inDto) throws Exception;

    //top1控股股东
    @Cacheable(value = "relation", key = "targetClass.getName()+ methodName+#inDto.companyId + #inDto.companyNm + #inDto.threshold")
    JSONArray searchAsTop1Holder(AsTop1HolderInDto inDto) throws Exception;

    //top3股东
    @Cacheable(value = "relation", key = "targetClass.getName()+ methodName+#inDto.companyId + #inDto.companyNm + #inDto.threshold")
    JSONArray searchTop3Shareholder(AsTop1HolderInDto inDto) throws Exception;

    //top10股东
    @Cacheable(value = "relation", key = "targetClass.getName()+ methodName+#inDto.companyId + #inDto.companyNm")
    JSONArray searchTop10Shareholder(BasicInDto inDto) throws Exception;

    //查找企业ID
    @Cacheable(value = "relation", key = "targetClass.getName()+ methodName+#companyNm")
    Long searchCompanyId(String companyNm) throws Exception;
}