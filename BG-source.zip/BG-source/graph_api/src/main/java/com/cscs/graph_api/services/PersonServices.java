package com.cscs.graph_api.services;

import com.cscs.graph_api.domain.ResultReturnCollection;
import com.cscs.graph_api.dto.PersonInDto;
import org.springframework.cache.annotation.Cacheable;

public interface PersonServices {
    //股东 对外投资
    @Cacheable(value = "relation", key = "targetClass.getName()+methodName+#inDto.companyId+#inDto.companyNm+#inDto.personNm+#inDto.relations")
    ResultReturnCollection getPerson(PersonInDto inDto) throws Exception;
}
