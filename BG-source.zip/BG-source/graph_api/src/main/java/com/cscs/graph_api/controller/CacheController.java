package com.cscs.graph_api.controller;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping(value = "/relation")
public class CacheController {

    @CacheEvict(value = "relation", allEntries = true)
    @RequestMapping(value = "/cacheDelete", method = RequestMethod.GET)
    public String cacheDelete() {
        return "缓存删除了！！！";
    }
}
