package com.cscs.graph_api.domain;

import java.util.ArrayList;

/**
 * Created by wuchenglong on 2018/1/8.
 */


@SuppressWarnings("unused")
public class InfoQueryResult {

    private String CONTROLLER_ID;
    private String CONTROLLER_NAME;
    private String CONTROLLER_TYPE;

    public InfoQueryResult() {
    }

    public String getCONTROLLER_ID() {
        return CONTROLLER_ID;
    }

    public void setCONTROLLER_ID(String CONTROLLER_ID) {
        this.CONTROLLER_ID = CONTROLLER_ID;
    }

    public String getCONTROLLER_NAME() {
        return CONTROLLER_NAME;
    }

    public void setCONTROLLER_NAME(String CONTROLLER_NAME) {
        this.CONTROLLER_NAME = CONTROLLER_NAME;
    }

    public String getCONTROLLER_TYPE() {
        return CONTROLLER_TYPE;
    }

    public void setCONTROLLER_TYPE(String CONTROLLER_TYPE) {
        this.CONTROLLER_TYPE = CONTROLLER_TYPE;
    }


}
