package com.cscs.graph_api.domain;

import com.cscs.graph_api.Util.UseFulFunc;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import net.sf.json.JSONObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.stream.Collectors;

/**
 * Created by wuchenglong on 2018/1/7.
 */


@SuppressWarnings("unused")
public class NodeShow {

    private static Logger logger = LogManager.getLogger(NodeShow.class);

    private String id;
    private String name;
    private String type;

    @JsonIgnore
    private ArrayList<String> labels = new ArrayList<>();
    @JsonIgnore
    private String link_id;
    @JsonIgnore
    private String reg_capital;//注册资本
    @JsonIgnore
    private String is_listed;//是否上市企业
    @JsonIgnore
    private String orgnum;//工商注册号
    @JsonIgnore
    private String status;//企业状态
    @JsonIgnore
    private String security_cd; //证券代码
    @JsonIgnore
    private ArrayList<Object> risk_list;  // 风险标签
    @JsonIgnore
    private ArrayList<String> company_type;//企业类型
    @JsonIgnore
    private String groupPos; //集团派系位置

    @JsonProperty("property")
    private JSONObject property = new JSONObject();

    public NodeShow() {
    }

    public void infoUpdate() {
        if (this.type == null) return;
        this.id = id == null ? "0" : id;
        if (this.type.equals("COMPANY")) {
            this.type = "1";
            this.company_type = this.company_type == null ? null : this.company_type.stream().map(x -> UseFulFunc.NODE_TYPE_MAP.getOrDefault(x, "None")).collect(Collectors.toCollection(ArrayList::new));
            if (this.company_type != null && this.company_type.contains("O")) {
                this.company_type.remove("3");
                this.company_type.remove("O");
            }
            if(company_type != null && !this.company_type.isEmpty()) property.put("companyType", company_type);

            if (this.risk_list != null && !this.risk_list.isEmpty()) {  //&& risk_label.contains("RISK")
                ArrayList<Object> risk_list = new ArrayList<>();
                for (Object i : this.risk_list) {
                    if (!i.toString().equals("")) {
                        risk_list.add(Integer.parseInt((i.toString())));
                    }
                }
                this.risk_list = risk_list;
            }
            if (this.risk_list != null && !this.risk_list.isEmpty()) property.put("riskLabel", risk_list);

            property.put("regCapital", reg_capital);
//            property.put("is_listed", is_listed);
//            property.put("security_cd", security_cd);
            property.put("status", status);
            property.put("orgnum", orgnum);
            property.put("groupPos",groupPos);

            if (this.labels != null && !this.labels.isEmpty()) {
                this.labels = this.labels.stream().map(x -> UseFulFunc.NODE_LABEL_MAP.getOrDefault(x, "None")).collect(Collectors.toCollection(ArrayList::new));
            } else {
                this.labels.add("1");
            }
            if(this.labels != null && !this.labels.isEmpty()) property.put("nodeLabel", labels);
        } else if (this.type.equals("PERSON")) {
            this.type = "2";
        } else if (this.type.equals("SECURITY")) {
            this.type = "3";
        }
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public ArrayList<String> getCompany_type() {
        return company_type;
    }

    public void setCompany_type(ArrayList<String> company_type) {
        this.company_type = company_type;
    }

    public ArrayList<Object> getRisk_list() {
        return risk_list;
    }

    public void setRisk_list(ArrayList<Object> risk_list) {
        this.risk_list = risk_list;
    }

    public JSONObject getProperty() {
        return property;
    }

    public void setProperty(JSONObject property) {
        this.property = property;
    }

    public String getReg_capital() {
        return reg_capital;
    }

    public void setReg_capital(String reg_capital) {
        this.reg_capital = reg_capital;
    }

    public String getIs_listed() {
        return is_listed;
    }

    public void setIs_listed(String is_listed) {
        this.is_listed = is_listed;
    }

    public String getOrgnum() {
        return orgnum;
    }

    public void setOrgnum(String orgnum) {
        this.orgnum = orgnum;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSecurity_cd() {
        return security_cd;
    }

    public void setSecurity_cd(String security_cd) {
        this.security_cd = security_cd;
    }


    public static Logger getLogger() {
        return logger;
    }

    public static void setLogger(Logger logger) {
        NodeShow.logger = logger;
    }

    public ArrayList<String> getLabels() {
        return labels;
    }

    public void setLabels(ArrayList<String> labels) {
        this.labels = labels;
    }

    public String getLink_id() {
        return link_id;
    }

    public void setLink_id(String link_id) {
        this.link_id = link_id;
    }

    public String getGroupPos() {
        return groupPos;
    }

    public void setGroupPos(String groupPos) {
        this.groupPos = groupPos;
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public int hashCode() {
        return 123;
    }
}
