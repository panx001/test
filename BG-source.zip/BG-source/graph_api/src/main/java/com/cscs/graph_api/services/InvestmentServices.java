package com.cscs.graph_api.services;

import com.cscs.graph_api.domain.ResultReturnCollection;
import com.cscs.graph_api.dto.InvestFilterInDto;
import com.cscs.graph_api.dto.InvestmentInDto;
import net.sf.json.JSONArray;
import org.springframework.cache.annotation.Cacheable;

public interface InvestmentServices {
    //股东 对外投资
    @Cacheable(value = "relation", key = "targetClass.getName()+methodName+#inDto.companyId+#inDto.companyNm+#inDto.investLayer+#inDto.shareholderLayer")
    ResultReturnCollection getShareholderAndInvest(InvestmentInDto inDto) throws Exception;

    //对外投资筛选接口  不包含右边界
    @Cacheable(value = "relation", key = "targetClass.getName()+methodName+#inDto.companyId+#inDto.companyNm+#inDto.leftBound+#inDto.rightBound+#inDto.containRB")
    JSONArray searchInvestFilterUnContainRB(InvestFilterInDto inDto) throws Exception;

    //对外投资筛选接口  包含右边界
    @Cacheable(value = "relation", key = "targetClass.getName()+methodName+#inDto.companyId+#inDto.companyNm+#inDto.leftBound+#inDto.rightBound+#inDto.containRB")
    JSONArray searchInvestFilterContainRB(InvestFilterInDto inDto) throws Exception;

}
