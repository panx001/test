package com.cscs.graph_api.dto;

public class AsTop1HolderInDto extends BasicInDto {

    //累计持股比例返回阈值
    public Double threshold;

    public Double getThreshold() {
        return threshold;
    }

    public void setThreshold(Double threshold) {
        this.threshold = threshold;
    }
}
