package com.cscs.graph_api.services.impl;

import com.cscs.graph_api.Util.CypherUtil;
import com.cscs.graph_api.dto.AsTop1HolderInDto;
import com.cscs.graph_api.dto.BasicInDto;
import com.cscs.graph_api.services.ShareholderServices;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.neo4j.driver.v1.Record;
import org.neo4j.driver.v1.StatementResult;
import org.springframework.stereotype.Service;

import java.util.Map;


@Service
public class ShareholderServicesImpl implements ShareholderServices {

    private static Logger logger = LogManager.getLogger(ShareholderServicesImpl.class);

    @Override
    public JSONArray searchTop1Shareholder(BasicInDto inDto) throws Exception {
        JSONArray contentArray = new JSONArray();
        StringBuilder cypher = new StringBuilder();
        cypher.append("MATCH (C:COMPANY{");
        if (inDto.companyId != null) {
            cypher.append("COMPANY_ID:\"" + inDto.companyId + "\"");
        } else {
            cypher.append("COMPANY_NM:\"" + inDto.companyNm + "\"");
        }
        cypher.append("})<-[r:INVEST]-()\n");
        cypher.append("//where exists(r.SHA_RATIO) \n" +
                "with C,max(tofloat(r.SHA_RATIO)) as ratio\n" +
                "match (C)<-[R:INVEST]-(D)\n" +
                "where exists(R.SHA_RATIO) and tofloat(R.SHA_RATIO) = ratio     //对于null值进行处理，含有null时，降序则排在最开头\n" +
                "with C,CASE \n" +
                "        WHEN 'COMPANY' IN LABELS(D) \n" +
                "        THEN D.COMPANY_ID \n" +
                "        WHEN 'PERSON' IN LABELS(D) \n" +
                "        THEN D.PERSON_ID\n" +
                "        ELSE D.SECINNER_ID  \n" +
                "        END AS sharehdId,\n" +
                "       CASE \n" +
                "        WHEN 'COMPANY' IN LABELS(D) \n" +
                "        THEN D.COMPANY_NM \n" +
                "        WHEN 'PERSON' IN LABELS(D) \n" +
                "        THEN D.PERSON_NM\n" +
                "        ELSE D.SECURITY_NM  \n" +
                "        END AS sharehdName,\n" +
                "       CASE \n" +
                "        WHEN 'COMPANY' IN LABELS(D) \n" +
                "        THEN '1' \n" +
                "        WHEN 'PERSON' IN LABELS(D) \n" +
                "        THEN '2'\n" +
                "        ELSE '3'  \n" +
                "        END AS sharehdType,R,D\n" +
                "with sharehdName,sharehdId,sharehdType,tofloat(R.SHA_RATIO) as sharehdRatio,\n" +
                "CASE WHEN 'COMPANY' IN LABELS(D) THEN D.REG_CAPITAL END AS regCapital,\n" +
                "CASE WHEN 'COMPANY' IN LABELS(D) THEN D.STATUS END AS status,\n" +
                "CASE WHEN 'COMPANY' IN LABELS(D) THEN D.ORGNUM END AS orgnum\n" +
                "return distinct sharehdName,sharehdId,sharehdType,sharehdRatio,regCapital,status,orgnum");

        StatementResult result = new CypherUtil().execute(cypher.toString());
        while (result.hasNext()) {
            JSONObject content = addTop1Sharehd(result.next());
            contentArray.add(content);
        }
        return contentArray;
    }

    private JSONObject addTop1Sharehd(Record record) {
        JSONObject content = new JSONObject();
        Map item = record.asMap();
        content.put("sharehdName", item.get("sharehdName"));
        content.put("sharehdId", item.get("sharehdId"));
        content.put("sharehdType", item.get("sharehdType"));
        content.put("sharehdRatio", item.get("sharehdRatio"));
        content.put("regCapital", item.get("regCapital"));
        content.put("status", item.get("status"));
        content.put("orgnum", item.get("orgnum"));
        return content;
    }

    @Override
    public JSONArray searchAsTop1Holder(AsTop1HolderInDto inDto) throws Exception {
        JSONArray contentArray = new JSONArray();
        StringBuilder cypher = new StringBuilder();
        cypher.append("MATCH (C:COMPANY{");
        if (inDto.companyId != null) {
            cypher.append("COMPANY_ID:\"" + inDto.companyId + "\"");
        } else {
            cypher.append("COMPANY_NM:\"" + inDto.companyNm + "\"");
        }
        cypher.append("})-[:INVEST]->(D)\n");
        cypher.append("with C,D\n" +
                "match (D)<-[r:INVEST]-()\n" +
                "with C,D,max(tofloat(r.SHA_RATIO)) as ratio\n" +
                "match (D)<-[R:INVEST]-(E)\n" +
                "with C,D,R,E,ratio,collect(E) as col\n" +
                "where exists(R.SHA_RATIO) and tofloat(R.SHA_RATIO) = ratio and C in col\n" +
                "match (C)-[Rel:INVEST]->(D)\n" +
                "where tofloat(Rel.SHA_RATIO)>=" + inDto.threshold + "\n" +
                "with  \n" +
                "   CASE \n" +
                "        WHEN 'COMPANY' IN LABELS(D) \n" +
                "        THEN D.COMPANY_NM \n" +
                "        ELSE D.SECINNER_NM  \n" +
                "        END AS companyName,\n" +
                "   CASE \n" +
                "        WHEN 'COMPANY' IN LABELS(D) \n" +
                "        THEN D.COMPANY_ID \n" +
                "        ELSE D.SECINNER_ID  \n" +
                "        END AS companyId,\n" +
                "        tofloat(Rel.SHA_RATIO) as investRatio, \n" +
                "CASE WHEN 'COMPANY' IN LABELS(D) THEN D.REG_CAPITAL END AS regCapital,\n" +
                "CASE WHEN 'COMPANY' IN LABELS(D) THEN D.STATUS END AS status,\n" +
                "CASE WHEN 'COMPANY' IN LABELS(D) THEN D.ORGNUM END AS orgnum\n" +
                "return distinct companyName,companyId,regCapital,status,orgnum,investRatio order by tofloat(investRatio) desc ");


        StatementResult result = new CypherUtil().execute(cypher.toString());
        while (result.hasNext()) {
            JSONObject content = addAsTop1Holder(result.next());
            contentArray.add(content);
        }
        return contentArray;
    }

    private JSONObject addAsTop1Holder(Record record) {
        JSONObject content = new JSONObject();
        Map item = record.asMap();
        content.put("companyName", item.get("companyName"));
        content.put("companyId", item.get("companyId"));
        content.put("investRatio", item.get("investRatio"));
        content.put("regCapital", item.get("regCapital"));
        content.put("status", item.get("status"));
        content.put("orgnum", item.get("orgnum"));
        return content;
    }

    @Override
    public JSONArray searchTop3Shareholder(AsTop1HolderInDto inDto) throws Exception {
        JSONArray contentArray = new JSONArray();
        StringBuilder cypher = new StringBuilder();
        cypher.append("MATCH (C:COMPANY{");
        if (inDto.companyId != null) {
            cypher.append("COMPANY_ID:\"" + inDto.companyId + "\"");
        } else {
            cypher.append("COMPANY_NM:\"" + inDto.companyNm + "\"");
        }
        cypher.append("})<-[R:INVEST]-()\n");
        cypher.append("with C,tofloat(R.SHA_RATIO) as sharehdRatio order by sharehdRatio desc\n" +
                "with C,collect(distinct sharehdRatio) as list,collect(sharehdRatio) as LIST,length(collect(distinct sharehdRatio)) as LENGTH\n" +
                "with C,list,LIST,case when LENGTH > 3 then list[2] else list[LENGTH-1] end as ratio\n" +
                "match (C)<-[Rel:INVEST]-(D)\n" +
                "where exists(Rel.SHA_RATIO) and tofloat(Rel.SHA_RATIO)>=ratio\n" +
                "with list,LIST,C,D,Rel,size(filter(x in list where x > tofloat(Rel.SHA_RATIO))) as rank,size(filter(x in LIST where x > tofloat(Rel.SHA_RATIO))) as RANK\n" +
                "order by tofloat(Rel.SHA_RATIO) desc\n" +
                "with CASE WHEN 'COMPANY' IN LABELS(D) THEN D.COMPANY_ID WHEN 'PERSON' IN LABELS(D) THEN D.PERSON_ID ELSE D.SECINNER_ID END AS sharehdId,\n" +
                "     CASE WHEN 'COMPANY' IN LABELS(D) THEN D.COMPANY_NM WHEN 'PERSON' IN LABELS(D) THEN D.PERSON_NM ELSE D.SECURITY_NM END AS sharehdName,\n" +
                "     CASE WHEN 'COMPANY' IN LABELS(D) THEN '1' WHEN 'PERSON' IN LABELS(D) THEN '2' ELSE '3' END AS sharehdType,\n" +
                "     CASE WHEN 'COMPANY' IN LABELS(D) THEN D.REG_CAPITAL END AS regCapital,\n" +
                "     CASE WHEN 'COMPANY' IN LABELS(D) THEN D.STATUS END AS status,\n" +
                "     CASE WHEN 'COMPANY' IN LABELS(D) THEN D.ORGNUM END AS orgnum,\n" +
                "     CASE WHEN rank = RANK THEN rank + 1 ELSE RANK + 1 END AS ratioRank,tofloat(Rel.SHA_RATIO) as sharehdRatio " +
                "where sharehdRatio >= " + inDto.threshold + " and ratioRank <=3\n" +
                "return distinct sharehdName,sharehdId,sharehdType,sharehdRatio,ratioRank,regCapital,status,orgnum");

//        logger.debug(cypher);
        StatementResult result = new CypherUtil().execute(cypher.toString());

//        logger.debug(result.next());

        while (result.hasNext()) {
            JSONObject content = addTop3Sharehd(result.next());
            contentArray.add(content);
        }
        return contentArray;
    }

    private JSONObject addTop3Sharehd(Record record) {
        JSONObject content = new JSONObject();
        Map item = record.asMap();
        content.put("sharehdName", item.get("sharehdName"));
        content.put("sharehdId", item.get("sharehdId"));
        content.put("sharehdType", item.get("sharehdType"));
        content.put("sharehdRatio", item.get("sharehdRatio"));
        content.put("ratioRank", item.get("ratioRank"));
        content.put("regCapital", item.get("regCapital"));
        content.put("status", item.get("status"));
        content.put("orgnum", item.get("orgnum"));
        return content;
    }

    @Override
    public JSONArray searchTop10Shareholder(BasicInDto inDto) throws Exception {
        JSONArray contentArray = new JSONArray();
        StringBuilder cypher = new StringBuilder();
        cypher.append("MATCH (C:COMPANY{");
        if (inDto.companyId != null) {
            cypher.append("COMPANY_ID:\"" + inDto.companyId + "\"");
        } else {
            cypher.append("COMPANY_NM:\"" + inDto.companyNm + "\"");
        }
        cypher.append("})<-[R:INVEST]-()\n");
        cypher.append("with C,tofloat(R.SHA_RATIO) as sharehdRatio order by sharehdRatio desc\n" +
                "with C,collect(sharehdRatio) as list,length(collect(sharehdRatio)) as length\n" +
                "with C,list,case when length > 10 then list[9] else list[length-1] end as number\n" +
                "match (C)<-[Rel:INVEST]-(D)\n" +
                "where exists(Rel.SHA_RATIO) and tofloat(Rel.SHA_RATIO)>=number\n" +
                "with CASE WHEN 'COMPANY' IN LABELS(D) THEN D.COMPANY_ID WHEN 'PERSON' IN LABELS(D) THEN D.PERSON_ID ELSE D.SECINNER_ID END AS sharehdId,\n" +
                "     CASE WHEN 'COMPANY' IN LABELS(D) THEN D.COMPANY_NM WHEN 'PERSON' IN LABELS(D) THEN D.PERSON_NM ELSE D.SECURITY_NM END AS sharehdName,\n" +
                "     CASE WHEN 'COMPANY' IN LABELS(D) THEN '1' WHEN 'PERSON' IN LABELS(D) THEN '2'ELSE '3' END AS sharehdType,\n" +
                "     CASE WHEN 'COMPANY' IN LABELS(D) THEN D.REG_CAPITAL END AS regCapital,\n" +
                "     CASE WHEN 'COMPANY' IN LABELS(D) THEN D.STATUS END AS status,\n" +
                "     CASE WHEN 'COMPANY' IN LABELS(D) THEN D.ORGNUM END AS orgnum,\n" +
                "tofloat(Rel.SHA_RATIO) as sharehdRatio\n" +
                "order by tofloat(Rel.SHA_RATIO) desc\n" +
                "return distinct sharehdName,sharehdId,sharehdType,sharehdRatio,regCapital,status,orgnum");

        StatementResult result = new CypherUtil().execute(cypher.toString());
        while (result.hasNext()) {
            JSONObject content = addTop1Sharehd(result.next());
            contentArray.add(content);
        }
        return contentArray;
    }

    @Override
    public Long searchCompanyId(String companyNm) throws Exception {
        StringBuilder cypher = new StringBuilder();
        cypher.append("MATCH (C:COMPANY{COMPANY_NM:\"" + companyNm + "\"})\n");
        cypher.append("return C.COMPANY_ID as companyId");
        StatementResult result = new CypherUtil().execute(cypher.toString());
        while (result.hasNext()) {
            Record record = result.next();
            Map item = record.asMap();
            return Long.parseLong(item.get("companyId").toString());
        }
        return null;
    }
}
