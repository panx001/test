package com.cscs.graph_api.services.impl;

import com.cscs.graph_api.Exception.InputException;
import com.cscs.graph_api.Util.CypherUtil;
import com.cscs.graph_api.Util.HttpUtil;
import com.cscs.graph_api.Util.Map2Map;
import com.cscs.graph_api.config.SqlManager;
import com.cscs.graph_api.domain.ResultReturn;
import com.cscs.graph_api.domain.ResultReturnCollection;
import com.cscs.graph_api.dto.CompanyCustomerDto;
import com.cscs.graph_api.dto.GroupFactionInDto;
import com.cscs.graph_api.mapper.QueryResultMapper;
import com.cscs.graph_api.services.GroupFactionServices;
import net.sf.json.JSONObject;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.neo4j.driver.v1.Record;
import org.neo4j.driver.v1.StatementResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.net.URLEncoder;
import java.text.MessageFormat;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;


@Service
public class GroupFactionServicesImpl implements GroupFactionServices {

    private static Logger logger = LogManager.getLogger(GroupFactionServicesImpl.class);


    @Autowired
    @Qualifier("gdsJdbcTemplate")
    private JdbcTemplate gdsJdbcTemplate;
    @Value("${hbase.cdi.company_identifier.url}")
    private String companyIdentifierUrl;
    @Value("${hbase.portal.company_base}")
    private String companyBaseUrl;
    @Value("${app.group.faction.sharehd.invest.ratio}")
    private String investRatio;

    //母公司
    @Override
    public ResultReturnCollection searchParentCompany(GroupFactionInDto inDto) throws Exception {

        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        StringBuilder cypher = new StringBuilder();
        cypher.append("MATCH (C:COMPANY{");
        if (inDto.companyId != null) {
            cypher.append("COMPANY_ID:\"" + inDto.companyId + "\"");
        } else {
            cypher.append("COMPANY_NM:\"" + inDto.companyNm + "\"");
        }
        cypher.append("}) call apoc.cscs.findGFMotherNode(C, "+ investRatio + ") YIELD node \n" +
                "return {COMPANY_ID:node.COMPANY_ID,COMPANY_TYPE:node.COMPANY_TYPE_LIST,RISK_LIST:node.RISK_LIST,\n" +
                "REG_CAPITAL:node.REG_CAPITAL,ORGNUM:node.ORGNUM,STATUS:node.STATUS,COMPANY_NM:node.COMPANY_NM,PERSON_ID:node.PERSON_ID,\n" +
                "PERSON_NM:node.PERSON_NM,SECURITY_NM:node.SECURITY_NM,SECURITY_ID:node.SECINNER_ID,LABELS:Labels(node),GROUPPOS:'母公司'} AS sourceNodeInfo,\n" +
                "{} as relationInfo,{} as targetNodeInfo;");

        logger.debug(cypher);
        StatementResult result = new CypherUtil().execute(cypher.toString());
        while (result.hasNext()) {
            Record record = result.next();
            Map<String, Object> copiedMap = Map2Map.copyMap(record.asMap());

            ResultReturn resultReturn = new ResultReturn(
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("sourceNodeInfo")),
                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) copiedMap.get("relationInfo")),
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("targetNodeInfo")));
            resultReturnCollection.add(resultReturn);
        }
        resultReturnCollection.updateElemtList();
        return resultReturnCollection;
    }


    //母公司+子公司
    @Override
    public ResultReturnCollection searchSubCompany(GroupFactionInDto inDto) throws Exception {

        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        StringBuilder cypher = new StringBuilder();

        cypher.append("MATCH (C:COMPANY{");
        if (inDto.companyId != null) {
            cypher.append("COMPANY_ID:\"" + inDto.companyId + "\"");
        } else {
            cypher.append("COMPANY_NM:\"" + inDto.companyNm + "\"");
        }
        cypher.append("}) call apoc.cscs.listGFInvestRelations(C," + inDto.layer + ",2, " + investRatio + ") YIELD path unwind path as pathMap\n" +
                "WITH pathMap.startGroupPos as startGroupPos,startNode(pathMap.relation) AS sourceNodeInfo ,\n" +
                "pathMap.relation AS relationInfo, endNode(pathMap.relation) AS targetNodeInfo,pathMap.endGroupPos AS endGroupPos\n" +
                "return {COMPANY_ID:sourceNodeInfo.COMPANY_ID,COMPANY_TYPE:sourceNodeInfo.COMPANY_TYPE_LIST,RISK_LIST:sourceNodeInfo.RISK_LIST,REG_CAPITAL:sourceNodeInfo.REG_CAPITAL,ORGNUM:sourceNodeInfo.ORGNUM,STATUS:sourceNodeInfo.STATUS,COMPANY_NM:sourceNodeInfo.COMPANY_NM,PERSON_ID:sourceNodeInfo.PERSON_ID,PERSON_NM:sourceNodeInfo.PERSON_NM,SECURITY_NM:sourceNodeInfo.SECURITY_NM,SECURITY_ID:sourceNodeInfo.SECINNER_ID,LABELS:Labels(sourceNodeInfo),\n" +
                "GROUPPOS: startGroupPos} AS sourceNodeInfo,\n" +
                "{id:ID(relationInfo),type:TYPE(relationInfo),investShaRatio:CASE WHEN relationInfo.SHA_RATIO IS NOT NULL THEN tofloat(relationInfo.SHA_RATIO) ELSE 0 END,workPosition:relationInfo.POSITION,SC_RELATION_TYPE:relationInfo.RELATION_TYPE, investNum:relationInfo.NUM, GUAR_INFO:relationInfo.GUAR_INFO,controllerType:relationInfo.RELATION_TYPE,relativeType:relationInfo.RELATION_TYPE} AS relationInfo,\n" +
                "{COMPANY_ID:targetNodeInfo.COMPANY_ID,COMPANY_TYPE:targetNodeInfo.COMPANY_TYPE_LIST,RISK_LIST:targetNodeInfo.RISK_LIST,REG_CAPITAL:targetNodeInfo.REG_CAPITAL,ORGNUM:targetNodeInfo.ORGNUM,STATUS:targetNodeInfo.STATUS,COMPANY_NM:targetNodeInfo.COMPANY_NM,PERSON_ID:targetNodeInfo.PERSON_ID,PERSON_NM:targetNodeInfo.PERSON_NM,SECURITY_NM:targetNodeInfo.SECURITY_NM,SECURITY_ID:targetNodeInfo.SECINNER_ID,LABELS:Labels(targetNodeInfo),\n" +
                "GROUPPOS: endGroupPos} AS targetNodeInfo\n");

        logger.debug(cypher);
        StatementResult result = new CypherUtil().execute(cypher.toString());
        while (result.hasNext()) {
            Record record = result.next();
            Map<String, Object> copiedMap = Map2Map.copyMap(record.asMap());

            ResultReturn resultReturn = new ResultReturn(
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("sourceNodeInfo")),
                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) copiedMap.get("relationInfo")),
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("targetNodeInfo")));
            resultReturnCollection.add(resultReturn);
        }
        resultReturnCollection.updateElemtList();
        return resultReturnCollection;
    }


    //集团派系 母公司+子公司+其他公司（母公司参股+高管任职+高管控股）
    @Override
    public ResultReturnCollection searchGroupFactionAll(GroupFactionInDto inDto) throws Exception {

        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
        StringBuilder cypher = new StringBuilder();

        //母公司+子公司
        cypher.append("MATCH (C:COMPANY{");
        if (inDto.companyId != null) {
            cypher.append("COMPANY_ID:\"" + inDto.companyId + "\"");
        } else {
            cypher.append("COMPANY_NM:\"" + inDto.companyNm + "\"");
        }
        cypher.append("}) call apoc.cscs.listGFInvestRelations(C," + inDto.layer + ",3, " + investRatio + ") YIELD path unwind path as pathMap\n" +
                "WITH pathMap.startGroupPos as startGroupPos,startNode(pathMap.relation) AS sourceNodeInfo ,\n" +
                "pathMap.relation AS relationInfo, endNode(pathMap.relation) AS targetNodeInfo,pathMap.endGroupPos AS endGroupPos\n" +
                "return {COMPANY_ID:sourceNodeInfo.COMPANY_ID,COMPANY_TYPE:sourceNodeInfo.COMPANY_TYPE_LIST,RISK_LIST:sourceNodeInfo.RISK_LIST,REG_CAPITAL:sourceNodeInfo.REG_CAPITAL,ORGNUM:sourceNodeInfo.ORGNUM,STATUS:sourceNodeInfo.STATUS,COMPANY_NM:sourceNodeInfo.COMPANY_NM,PERSON_ID:sourceNodeInfo.PERSON_ID,PERSON_NM:sourceNodeInfo.PERSON_NM,SECURITY_NM:sourceNodeInfo.SECURITY_NM,SECURITY_ID:sourceNodeInfo.SECINNER_ID,LABELS:Labels(sourceNodeInfo),\n" +
                "GROUPPOS: startGroupPos} AS sourceNodeInfo,\n" +
                "{id:ID(relationInfo),type:TYPE(relationInfo),investShaRatio:CASE WHEN relationInfo.SHA_RATIO IS NOT NULL THEN tofloat(relationInfo.SHA_RATIO) ELSE 0 END,workPosition:relationInfo.POSITION,SC_RELATION_TYPE:relationInfo.RELATION_TYPE, investNum:relationInfo.NUM, GUAR_INFO:relationInfo.GUAR_INFO,controllerType:relationInfo.RELATION_TYPE,relativeType:relationInfo.RELATION_TYPE} AS relationInfo,\n" +
                "{COMPANY_ID:targetNodeInfo.COMPANY_ID,COMPANY_TYPE:targetNodeInfo.COMPANY_TYPE_LIST,RISK_LIST:targetNodeInfo.RISK_LIST,REG_CAPITAL:targetNodeInfo.REG_CAPITAL,ORGNUM:targetNodeInfo.ORGNUM,STATUS:targetNodeInfo.STATUS,COMPANY_NM:targetNodeInfo.COMPANY_NM,PERSON_ID:targetNodeInfo.PERSON_ID,PERSON_NM:targetNodeInfo.PERSON_NM,SECURITY_NM:targetNodeInfo.SECURITY_NM,SECURITY_ID:targetNodeInfo.SECINNER_ID,LABELS:Labels(targetNodeInfo),\n" +
                "GROUPPOS: endGroupPos} AS targetNodeInfo\n");

        logger.debug(cypher);
        StatementResult result = new CypherUtil().execute(cypher.toString());
        while (result.hasNext()) {
            Record record = result.next();
            Map<String, Object> copiedMap = Map2Map.copyMap(record.asMap());

            ResultReturn resultReturn = new ResultReturn(
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("sourceNodeInfo")),
                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) copiedMap.get("relationInfo")),
                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("targetNodeInfo")));
            resultReturnCollection.add(resultReturn);
        }
        resultReturnCollection.updateElemtList();
        return resultReturnCollection;
    }

    @Override
    public CompanyCustomerDto getCustomerIdentify(CompanyCustomerDto inDto) throws Exception {
        if(inDto == null || (StringUtils.isBlank(inDto.getCompanyName()) && StringUtils.isBlank(inDto.getCreditCode()) &&
                StringUtils.isBlank(inDto.getBlnumb()) && StringUtils.isBlank(inDto.getOrgNumber()))) {
            throw new InputException();
        }
        CompanyCustomerDto companyCustomerDto = null;
        // 从Hbase取companyId
        String companyId = getCompanyIdFromHbase(inDto);
        if(StringUtils.isNotBlank(companyId)) {
            String companyInfoResponse = HttpUtil.getHBaseResponse(MessageFormat.format(companyBaseUrl, companyId));
            if(StringUtils.isNotBlank(companyInfoResponse)) {
                JSONObject jsonObject = JSONObject.fromObject(companyInfoResponse);
                BeanUtils.populate(inDto, jsonObject);
                inDto.setCompanyId(companyId);
                inDto.setCompanyName(jsonObject.get("compyName") != null ? jsonObject.get("compyName").toString() : "");
                inDto.setClensCompanyNm(jsonObject.get("compyName") != null ? jsonObject.get("compyName").toString() : "");
                companyCustomerDto = inDto;
            }
        }
        return companyCustomerDto;
    }



    /**
     * Hbase中取companyId
     * @param inDto
     * @return
     */
    private String getCompanyIdFromHbase(CompanyCustomerDto inDto) throws Exception {
        if(StringUtils.isNotBlank(inDto.getCompanyName())) {
            // 原名称查询
            String companyId = HttpUtil.getHBaseResponse(MessageFormat.format(companyIdentifierUrl, URLEncoder.encode(inDto.getCompanyName(), "UTF-8")));
            if(StringUtils.isNotBlank(companyId)) {
                inDto.setClensCompanyNm(inDto.getCompanyName());
                inDto.setHitParam("companyName:" + inDto.getCompanyName());
                return companyId;
            }

            // 原名历史名称查询
            List<Map<String, Object>> oldNameMapList = gdsJdbcTemplate.queryForList(SqlManager.COMPANY_NAME_MAP_COMPANY_NM_OLD_SELECT, inDto.getCompanyName());
            if(oldNameMapList != null && oldNameMapList.size() > 0) {
                if(oldNameMapList.get(0).get("COMPANY_ID") != null) {
                    inDto.setHitParam("companyName:"+ inDto.getCompanyName());
                    return oldNameMapList.get(0).get("COMPANY_ID").toString();
                }
            }

            //清洗后查询
            // 转换大写
            String cleanName = inDto.getCompanyName().toUpperCase();
            cleanName = stringFiter(cleanName, 0);
            // 替换中文的左括号
            cleanName.replaceAll("（", "(");
            // 替换英文的中括号
            cleanName.replaceAll( "）", ")");
            if(StringUtils.isBlank(cleanName)) throw new InputException();
            companyId = HttpUtil.getHBaseResponse(MessageFormat.format(companyIdentifierUrl, cleanName));
            if(StringUtils.isNotBlank(companyId)){
                // 替换掉过滤后的
                inDto.setClensCompanyNm(cleanName);
                inDto.setHitParam("companyName:clean:" + cleanName);
                return companyId;
            }

            // 清洗后的历史名称查询
            List<Map<String, Object>> cleanOldNameMapList = gdsJdbcTemplate.queryForList(SqlManager.COMPANY_NAME_MAP_COMPANY_NM_OLD_SELECT, cleanName);
            if(cleanOldNameMapList != null && cleanOldNameMapList.size() > 0) {
                if(cleanOldNameMapList.get(0).get("COMPANY_ID") != null) {
                    inDto.setClensCompanyNm(cleanName);
                    inDto.setHitParam("companyName:"+ cleanName);
                    return cleanOldNameMapList.get(0).get("COMPANY_ID").toString();
                }
            }
            // TODO: 2019/6/25  证券简称

            // TODO: 2019/6/25  企业别称
        }
        if(StringUtils.isNotBlank(inDto.getCreditCode())) {
            String creditCode = stringFiter(inDto.getCreditCode(), 1);
            inDto.setCreditCode(creditCode);
            String companyId = HttpUtil.getHBaseResponse(MessageFormat.format(companyIdentifierUrl, creditCode));
            if(StringUtils.isNotBlank(companyId)) {
                inDto.setHitParam("creditCode:" + creditCode);
                return companyId;
            }
        }
        if(StringUtils.isNotBlank(inDto.getBlnumb())) {
            String blnumb = stringFiter(inDto.getBlnumb(), 1);
            inDto.setBlnumb(blnumb);
            String companyId = HttpUtil.getHBaseResponse(MessageFormat.format(companyIdentifierUrl, blnumb));
            if(StringUtils.isNotBlank(companyId)) {
                inDto.setHitParam("blnumb:" + blnumb);
                return companyId;
            }
        }
        if(StringUtils.isNotBlank(inDto.getOrgNumber())) {
            String orgNumber = stringFiter(inDto.getOrgNumber(), 1);
            inDto.setOrgNumber(orgNumber);
            String companyId = HttpUtil.getHBaseResponse(MessageFormat.format(companyIdentifierUrl, orgNumber));
            if(StringUtils.isNotBlank(companyId)) {
                inDto.setHitParam("orgNumber:" + orgNumber);
                return companyId;
            }
        }
        return null;
    }

    /**
     * 过滤特殊字符
     * @param clean 要处理的字符串
     * @param regType 正则类型(0:去掉特殊字符 ; 1: 只保留数字和字母  )
     * @return
     * @throws PatternSyntaxException
     */
    private String stringFiter(String clean, Integer regType) throws PatternSyntaxException {
        String regEx = regType == 1 ? "[^a-zA-Z0-9]" : "[！! %$@#￥&*【】……{}\\[\\]||\\\\,.，\\-。——/？/?<>_\\-+=；：;:''‘“\"{}^]";
        Pattern pattern = Pattern.compile(regEx);
        Matcher matcher = pattern.matcher(clean);
        return matcher.replaceAll("").trim();
    }

//    //母公司
//    @Override
//    public ResultReturnCollection searchParentCompany(GroupFactionInDto inDto) throws Exception {
//
//        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
//        StringBuilder cypher = new StringBuilder();
//        cypher.append("MATCH (C:COMPANY{");
//        if (inDto.companyId != null) {
//            cypher.append("COMPANY_ID:\"" + inDto.companyId + "\"");
//        } else {
//            cypher.append("COMPANY_NM:\"" + inDto.companyNm + "\"");
//        }
//        cypher.append("})<-[:INVEST*0..10{REL_TYPE:'HOLDING'}]-(D)\n" +
//                "where not (D)<-[:INVEST{REL_TYPE:'HOLDING'}]-()\n" +
//                "match path=(D)-[:INVEST*0..10{REL_TYPE:'HOLDING'}]->(C)\n" +
//                "with path order by length(path) \n" +
//                "unwind nodes(path) as NODE\n" +
//                "with case when 'COMPANY' in labels(NODE) then NODE.COMPANY_NM\n" +
//                "\t when 'PERSON' in labels(NODE) then NODE.PERSON_NM\n" +
//                "     else NODE.SECURITY_NM end as NAME \n" +
//                "with collect(distinct NAME) as ListName\n" +
//                "with filter(x in ListName where x =~ '.*国有资产监督管理委员会.*' or x =~ '.*人民政府.*' or x =~ '.*香港中央结算.*' or length(x)<=4) as ListNameOther,ListName\n" +
//                "with filter(x in ListName where  not x in ListNameOther ) as ListNameNew\n" +
//                "match (M:COMPANY)\n" +
//                "where M.COMPANY_NM = ListNameNew[0]\n" +
//                "return distinct {COMPANY_ID:M.COMPANY_ID,COMPANY_TYPE:M.COMPANY_TYPE_LIST,RISK_LIST:M.RISK_LIST,REG_CAPITAL:M.REG_CAPITAL,ORGNUM:M.ORGNUM,STATUS:M.STATUS,\n" +
//                "COMPANY_NM:M.COMPANY_NM,PERSON_ID:M.PERSON_ID,PERSON_NM:M.PERSON_NM,SECURITY_NM:M.SECURITY_NM,SECURITY_ID:M.SECINNER_ID,LABELS:Labels(M),GROUPPOS:'母公司'} AS sourceNodeInfo,{} as relationInfo,{} as targetNodeInfo");
//
////        logger.debug(cypher);
//        StatementResult result = new CypherUtil().execute(cypher.toString());
//        while (result.hasNext()) {
//            Record record = result.next();
//            Map<String, Object> copiedMap = Map2Map.copyMap(record.asMap());
//
//            ResultReturn resultReturn = new ResultReturn(
//                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("sourceNodeInfo")),
//                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) copiedMap.get("relationInfo")),
//                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("targetNodeInfo")));
//            resultReturnCollection.add(resultReturn);
//        }
//        resultReturnCollection.updateElemtList();
//        return resultReturnCollection;
//    }
//
//
//    //母公司+子公司
//    @Override
//    public ResultReturnCollection searchSubCompany(GroupFactionInDto inDto) throws Exception {
//
//        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
//        StringBuilder cypher = new StringBuilder();
//
//        cypher.append("MATCH (C:COMPANY{");
//        if (inDto.companyId != null) {
//            cypher.append("COMPANY_ID:\"" + inDto.companyId + "\"");
//        } else {
//            cypher.append("COMPANY_NM:\"" + inDto.companyNm + "\"");
//        }
//        cypher.append("})<-[:INVEST*0..10{REL_TYPE:'HOLDING'}]-(D)\n" +
//                "where not (D)<-[:INVEST{REL_TYPE:'HOLDING'}]-()\n" +
//                "match path=(D)-[:INVEST*0..10{REL_TYPE:'HOLDING'}]->(C)\n" +
//                "with path order by length(path) \n" +
//                "unwind nodes(path) as NODE\n" +
//                "with case when 'COMPANY' in labels(NODE) then NODE.COMPANY_NM\n" +
//                "\t when 'PERSON' in labels(NODE) then NODE.PERSON_NM\n" +
//                "     else NODE.SECURITY_NM end as NAME \n" +
//                "with collect(distinct NAME) as ListName\n" +
//                "with filter(x in ListName where x =~ '.*国有资产监督管理委员会.*' or x =~ '.*人民政府.*' or x =~ '.*香港中央结算.*' or length(x)<=4) as ListNameOther,ListName\n" +
//                "with filter(x in ListName where  not x in ListNameOther ) as ListNameNew\n" +
//                "match (M:COMPANY)\n" +
//                "where M.COMPANY_NM = ListNameNew[0]\n" +
//                "match pathSub=(M)-[:INVEST*.."+ inDto.layer+ "{REL_TYPE:'HOLDING'}]->()\n" +
//                "unwind nodes(pathSub) as Listnode\n" +
//                "unwind relationships(pathSub) AS R\n" +
//                "with collect(M) as NODEMOT,collect (distinct Listnode) as NODEsub,M,R\n" +
//                "with filter(x in NODEsub where  not x in NODEMOT ) as NODESUB,M,R,startNode(R) AS sourceNodeInfo , R AS relationInfo, endNode(R) AS targetNodeInfo\n" +
//                "unwind NODESUB as S\n" + Constants.returnParaGF);
//
////        logger.debug(cypher);
//        StatementResult result = new CypherUtil().execute(cypher.toString());
//        while (result.hasNext()) {
//            Record record = result.next();
//            Map<String, Object> copiedMap = Map2Map.copyMap(record.asMap());
//
//            ResultReturn resultReturn = new ResultReturn(
//                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("sourceNodeInfo")),
//                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) copiedMap.get("relationInfo")),
//                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("targetNodeInfo")));
//            resultReturnCollection.add(resultReturn);
//        }
//        resultReturnCollection.updateElemtList();
//        return resultReturnCollection;
//    }
//
//
//    //集团派系 母公司+子公司+其他公司（母公司参股+高管任职+高管控股）
//    @Override
//    public ResultReturnCollection searchGroupFactionAll(GroupFactionInDto inDto) throws Exception {
//
//        ResultReturnCollection resultReturnCollection = new ResultReturnCollection();
//        StringBuilder cypher = new StringBuilder();
//
//        //母公司+子公司
//        cypher.append("MATCH (C:COMPANY{");
//        if (inDto.companyId != null) {
//            cypher.append("COMPANY_ID:\"" + inDto.companyId + "\"");
//        } else {
//            cypher.append("COMPANY_NM:\"" + inDto.companyNm + "\"");
//        }
//        cypher.append("})<-[:INVEST*0..10{REL_TYPE:'HOLDING'}]-(D)\n" +
//                "where not (D)<-[:INVEST{REL_TYPE:'HOLDING'}]-()\n" +
//                "match path=(D)-[:INVEST*0..10{REL_TYPE:'HOLDING'}]->(C)\n" +
//                "with path order by length(path) \n" +
//                "unwind nodes(path) as NODE\n" +
//                "with case when 'COMPANY' in labels(NODE) then NODE.COMPANY_NM\n" +
//                "\t when 'PERSON' in labels(NODE) then NODE.PERSON_NM\n" +
//                "     else NODE.SECURITY_NM end as NAME \n" +
//                "with collect(distinct NAME) as ListName\n" +
//                "with filter(x in ListName where x =~ '.*国有资产监督管理委员会.*' or x =~ '.*人民政府.*' or x =~ '.*香港中央结算.*' or length(x)<=4) as ListNameOther,ListName\n" +
//                "with filter(x in ListName where  not x in ListNameOther ) as ListNameNew\n" +
//                "match (M:COMPANY)\n" +
//                "where M.COMPANY_NM = ListNameNew[0]\n" +
//                "match pathSub=(M)-[:INVEST*.."+ inDto.layer+ "{REL_TYPE:'HOLDING'}]->()\n" +
//                "unwind nodes(pathSub) as Listnode\n" +
//                "unwind relationships(pathSub) AS R\n" +
//                "with collect(M) as NODEMOT,collect (distinct Listnode) as NODEsub,M,R\n" +
//                "with filter(x in NODEsub where  not x in NODEMOT ) as NODESUB,M,R,startNode(R) AS sourceNodeInfo , R AS relationInfo, endNode(R) AS targetNodeInfo\n" +
//                "unwind NODESUB as S\n" + Constants.returnParaGF);
//
//
//        //母公司参股
//        cypher.append("\nUNION\n");
//        cypher.append("MATCH (C:COMPANY{");
//        if (inDto.companyId != null) {
//            cypher.append("COMPANY_ID:\"" + inDto.companyId + "\"");
//        } else {
//            cypher.append("COMPANY_NM:\"" + inDto.companyNm + "\"");
//        }
//        cypher.append("})<-[:INVEST*0..10{REL_TYPE:'HOLDING'}]-(D)\n" +
//                "where not (D)<-[:INVEST{REL_TYPE:'HOLDING'}]-()\n" +
//                "match path=(D)-[:INVEST*0..10{REL_TYPE:'HOLDING'}]->(C)\n" +
//                "with path order by length(path) \n" +
//                "unwind nodes(path) as NODE\n" +
//                "with case when 'COMPANY' in labels(NODE) then NODE.COMPANY_NM\n" +
//                "\t when 'PERSON' in labels(NODE) then NODE.PERSON_NM\n" +
//                "     else NODE.SECURITY_NM end as NAME \n" +
//                "with collect(distinct NAME) as ListName\n" +
//                "with filter(x in ListName where x =~ '.*国有资产监督管理委员会.*' or x =~ '.*人民政府.*' or x =~ '.*香港中央结算.*' or length(x)<=4) as ListNameOther,ListName\n" +
//                "with filter(x in ListName where  not x in ListNameOther ) as ListNameNew\n" +
//                "match (M:COMPANY)\n" +
//                "where M.COMPANY_NM = ListNameNew[0]\n" +
//                "match pathSub=(M)-[:INVEST*.."+ inDto.layer+ "{REL_TYPE:'HOLDING'}]->()\n" +
//                "unwind nodes(pathSub) as Listnode\n" +
//                "unwind relationships(pathSub) AS RSub\n" +
//                "with collect(distinct M) as NODEMOT,collect (distinct Listnode) as NODEsub,M,RSub\n" +
//                "with filter(x in NODEsub where not x in NODEMOT ) as NODESUB,M,NODEMOT\n" +
//                "unwind NODESUB as idsub\n" +
//                "with collect(distinct id(idsub)) as IDSUB,M\n" +
//                "match pathOth=(M)-[:INVEST]->(oth)\n" +
//                "unwind relationships(pathOth) AS R\n" +
//                "with startNode(R) AS sourceNodeInfo , R AS relationInfo, endNode(R) AS targetNodeInfo,IDSUB,M\n" +Constants.returnParaGFNew);
//
//
//        //高管任职
//        cypher.append("\nUNION\n");
//        cypher.append("MATCH (C:COMPANY{");
//        if (inDto.companyId != null) {
//            cypher.append("COMPANY_ID:\"" + inDto.companyId + "\"");
//        } else {
//            cypher.append("COMPANY_NM:\"" + inDto.companyNm + "\"");
//        }
//        cypher.append("})<-[:INVEST*0..10{REL_TYPE:'HOLDING'}]-(D)\n" +
//                "where not (D)<-[:INVEST{REL_TYPE:'HOLDING'}]-()\n" +
//                "match path=(D)-[:INVEST*0..10{REL_TYPE:'HOLDING'}]->(C)\n" +
//                "with path order by length(path) \n" +
//                "unwind nodes(path) as NODE\n" +
//                "with case when 'COMPANY' in labels(NODE) then NODE.COMPANY_NM\n" +
//                "\t when 'PERSON' in labels(NODE) then NODE.PERSON_NM\n" +
//                "     else NODE.SECURITY_NM end as NAME \n" +
//                "with collect(distinct NAME) as ListName\n" +
//                "with filter(x in ListName where x =~ '.*国有资产监督管理委员会.*' or x =~ '.*人民政府.*' or x =~ '.*香港中央结算.*' or length(x)<=4) as ListNameOther,ListName\n" +
//                "with filter(x in ListName where  not x in ListNameOther ) as ListNameNew\n" +
//                "match (M:COMPANY)\n" +
//                "where M.COMPANY_NM = ListNameNew[0]\n" +
//                "match pathSub=(M)-[:INVEST*.."+ inDto.layer+ "{REL_TYPE:'HOLDING'}]->()\n" +
//                "unwind nodes(pathSub) as Listnode\n" +
//                "with collect(M) as NODEMOT,collect (distinct Listnode) as NODEsub,M\n" +
//                "with filter(x in NODEsub where  not x in NODEMOT ) as NODESUB,[\"法定代表人\",\"董事长\",\"总经理\",\"执行董事\",\"执行董事兼总经理\",\"董事长兼经理\",\"董事总经理\",\"董事兼总经理\",\"董事长,总经理\",\"执行董事兼经理\"] as POS,M\n" +
//                "unwind NODESUB as S\n" +
//                "with collect(distinct id(S)) as IDSUB,S,M,POS\n" +
//                "match PATH=(S)<-[r:WORK]-(P:PERSON)\n" +
//                "where r.POSITION in POS\n" +
//                "with distinct P as Per,POS,relationships(PATH) AS R1,IDSUB,M\n" +
//                "match pathOth =(Per)-[Rwork:WORK]->(oth)\n" +
//                "where Rwork.POSITION in POS\n" +
//                "with R1,relationships(pathOth) AS R2,IDSUB,M\n" +
//                "with IDSUB,M,R1 + R2 as R3\n" +
//                "unwind R3 as R\n" +
//                "with startNode(R) AS sourceNodeInfo , R AS relationInfo, endNode(R) AS targetNodeInfo,IDSUB,M\n" +Constants.returnParaGFNew);
//
//
//        //高管控股
//        cypher.append("\nUNION\n");
//        cypher.append("MATCH (C:COMPANY{");
//        if (inDto.companyId != null) {
//            cypher.append("COMPANY_ID:\"" + inDto.companyId + "\"");
//        } else {
//            cypher.append("COMPANY_NM:\"" + inDto.companyNm + "\"");
//        }
//        cypher.append("})<-[:INVEST*0..10{REL_TYPE:'HOLDING'}]-(D)\n" +
//                "where not (D)<-[:INVEST{REL_TYPE:'HOLDING'}]-()\n" +
//                "match path=(D)-[:INVEST*0..10{REL_TYPE:'HOLDING'}]->(C)\n" +
//                "with path order by length(path) \n" +
//                "unwind nodes(path) as NODE\n" +
//                "with case when 'COMPANY' in labels(NODE) then NODE.COMPANY_NM\n" +
//                "\t when 'PERSON' in labels(NODE) then NODE.PERSON_NM\n" +
//                "     else NODE.SECURITY_NM end as NAME \n" +
//                "with collect(distinct NAME) as ListName\n" +
//                "with filter(x in ListName where x =~ '.*国有资产监督管理委员会.*' or x =~ '.*人民政府.*' or x =~ '.*香港中央结算.*' or length(x)<=4) as ListNameOther,ListName\n" +
//                "with filter(x in ListName where  not x in ListNameOther ) as ListNameNew\n" +
//                "match (M:COMPANY)\n" +
//                "where M.COMPANY_NM = ListNameNew[0]\n" +
//                "match pathSub=(M)-[:INVEST*.."+ inDto.layer+ "{REL_TYPE:'HOLDING'}]->()\n" +
//                "unwind nodes(pathSub) as Listnode\n" +
//                "with collect(M) as NODEMOT,collect (distinct Listnode) as NODEsub,M\n" +
//                "with filter(x in NODEsub where  not x in NODEMOT ) as NODESUB,[\"法定代表人\",\"董事长\",\"总经理\",\"执行董事\",\"执行董事兼总经理\",\"董事长兼经理\",\"董事总经理\",\"董事兼总经理\",\"董事长,总经理\",\"执行董事兼经理\"] as POS,M\n" +
//                "unwind NODESUB as S\n" +
//                "with collect(distinct id(S)) as IDSUB,S,M,POS\n" +
//                "match PATH=(S)<-[r:WORK]-(P:PERSON)\n" +
//                "where r.POSITION in POS\n" +
//                "with distinct P as Per,POS,relationships(PATH) AS R1,IDSUB,M\n" +
//                "match pathOth =(Per)-[:INVEST{REL_TYPE:'HOLDING'}]->(oth)\n" +
//                "with R1,relationships(pathOth) AS R2,IDSUB,M\n" +
//                "with IDSUB,M,R1 + R2 as R3\n" +
//                "unwind R3 as R\n" +
//                "with startNode(R) AS sourceNodeInfo , R AS relationInfo, endNode(R) AS targetNodeInfo,IDSUB,M\n" +Constants.returnParaGFNew);
//
//
////        logger.debug(cypher);
//        StatementResult result = new CypherUtil().execute(cypher.toString());
//        while (result.hasNext()) {
//            Record record = result.next();
//            Map<String, Object> copiedMap = Map2Map.copyMap(record.asMap());
//
//            ResultReturn resultReturn = new ResultReturn(
//                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("sourceNodeInfo")),
//                    QueryResultMapper.MapRelationShipShowMapper((Map<String, Object>) copiedMap.get("relationInfo")),
//                    QueryResultMapper.MapNodeShowMapper((Map<String, Object>) copiedMap.get("targetNodeInfo")));
//            resultReturnCollection.add(resultReturn);
//        }
//        resultReturnCollection.updateElemtList();
//        return resultReturnCollection;
//    }
}
