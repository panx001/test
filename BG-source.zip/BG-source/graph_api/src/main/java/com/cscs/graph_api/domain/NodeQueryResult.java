package com.cscs.graph_api.domain;

import java.util.ArrayList;

/**
 * Created by wuchenglong on 2018/1/8.
 */


@SuppressWarnings("unused")
public class NodeQueryResult {

    //个人
    private String PERSON_ID;
    private String PERSON_NM;

    //产品
    private String SECURITY_ID;
    private String SECURITY_NM;

    //企业
    private String COMPANY_ID;//企业ID
    private String COMPANY_NM;//企业名称
    private String REG_CAPITAL;//注册资本
    private String IS_LISTED; //是否上市
    private String ORGNUM;//工商注册号
    private String STATUS;//状态
    private String SECURITY_CD; //证券代码
    private ArrayList<String> LABELS; //节点标签
    private String LINK_ID;
    private ArrayList<Object> RISK_LIST;  // 风险标签
    private ArrayList<String> COMPANY_TYPE;//企业类型
    private String GROUPPOS;//集团派系位置

    public NodeQueryResult() {

    }

    public String getPERSON_ID() {
        return PERSON_ID;
    }

    public void setPERSON_ID(String PERSON_ID) {
        this.PERSON_ID = PERSON_ID;
    }

    public String getPERSON_NM() {
        return PERSON_NM;
    }

    public void setPERSON_NM(String PERSON_NM) {
        this.PERSON_NM = PERSON_NM;
    }

    public String getSECURITY_ID() {
        return SECURITY_ID;
    }

    public void setSECURITY_ID(String SECURITY_ID) {
        this.SECURITY_ID = SECURITY_ID;
    }

    public String getSECURITY_NM() {
        return SECURITY_NM;
    }

    public void setSECURITY_NM(String SECURITY_NM) {
        this.SECURITY_NM = SECURITY_NM;
    }

    public String getCOMPANY_ID() {
        return COMPANY_ID;
    }

    public void setCOMPANY_ID(String COMPANY_ID) {
        this.COMPANY_ID = COMPANY_ID;
    }

    public String getCOMPANY_NM() {
        return COMPANY_NM;
    }

    public void setCOMPANY_NM(String COMPANY_NM) {
        this.COMPANY_NM = COMPANY_NM;
    }

    public String getREG_CAPITAL() {
        return REG_CAPITAL;
    }

    public void setREG_CAPITAL(String REG_CAPITAL) {
        this.REG_CAPITAL = REG_CAPITAL;
    }

    public String getIS_LISTED() {
        return IS_LISTED;
    }

    public void setIS_LISTED(String IS_LISTED) {
        this.IS_LISTED = IS_LISTED;
    }

    public String getORGNUM() {
        return ORGNUM;
    }

    public void setORGNUM(String ORGNUM) {
        this.ORGNUM = ORGNUM;
    }

    public String getSTATUS() {
        return STATUS;
    }

    public void setSTATUS(String STATUS) {
        this.STATUS = STATUS;
    }

    public String getSECURITY_CD() {
        return SECURITY_CD;
    }

    public void setSECURITY_CD(String SECURITY_CD) {
        this.SECURITY_CD = SECURITY_CD;
    }

    public ArrayList<Object> getRISK_LIST() {
        return RISK_LIST;
    }

    public void setRISK_LIST(ArrayList<Object> RISK_LIST) {
        this.RISK_LIST = RISK_LIST;
    }

    public ArrayList<String> getLABELS() {
        return LABELS;
    }

    public void setLABELS(ArrayList<String> LABELS) {
        this.LABELS = LABELS;
    }

    public String getLINK_ID() {
        return LINK_ID;
    }

    public void setLINK_ID(String LINK_ID) {
        this.LINK_ID = LINK_ID;
    }

    public ArrayList<String> getCOMPANY_TYPE() {
        return COMPANY_TYPE;
    }

    public void setCOMPANY_TYPE(ArrayList<String> COMPANY_TYPE) {
        this.COMPANY_TYPE = COMPANY_TYPE;
    }

    public String getGROUPPOS() {
        return GROUPPOS;
    }

    public void setGROUPPOS(String GROUPPOS) {
        this.GROUPPOS = GROUPPOS;
    }
}
