package com.cscs.graph_api.config;

/**
 * sql管理的工具类
 */
public class SqlManager {
// 工商基本信息表(COMPANY_BASICINFO)
    // 通过companyId查询
    public static final String COMPANY_BASICINFO_COMPANY_ID_SELECT = "select * from COMPANY_BASICINFO where COMPANY_ID = ? ";
    // 通过公司的companyNm查询
    public static final String COMPANY_BASICINFO_COMPANY_NM_SELECT = "select * from COMPANY_BASICINFO where COMPANY_NM = ? ";
    // 通过公司的fen_nm(英文简称) 查询
    public static final String COMPANY_BASICINFO_FEN_NM_SELECT = "select * from COMPANY_BASICINFO where FEN_NM = ? ";
    // 关联历史名称(compy_name_map)查询
    public static final String COMPANY_BASICINFO_JOIN_NAME_MAP_SELECT = "select b.* from COMPY_BASICINFO b left join  COMPY_NAME_MAP m on b.COMPANY_ID = m.COMPANY_ID where m.COMPANY_NM_OLD = ?";
    // 通过公司统一社会信用代码(组织机构码)orgnum查询
    public static final String COMPANY_BASICINFO_ORGNUM_SELECT = "select * from COMPANY_BASICINFO where ORGNUM = ? ";
    // 通过公司工商注册号BLNUMB查询
    public static final String COMPANY_BASICINFO_BLNUMB_SELECT = "select * from COMPANY_BASICINFO where BLNUMB = ? ";

// 曾用名表(COMPY_NAME_MAP)
    // 通过old_company_nm查询
    public static final String COMPANY_NAME_MAP_COMPANY_NM_OLD_SELECT = "select * from COMPY_NAME_MAP where COMPANY_NM_OLD = ? ";


}
