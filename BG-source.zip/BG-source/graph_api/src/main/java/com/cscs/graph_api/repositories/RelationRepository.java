package com.cscs.graph_api.repositories;

/**
 * Created by wuchenglong on 2018/1/3.
 */
import com.cscs.graph_api.Util.Constants;
import org.neo4j.ogm.response.model.QueryResultModel;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "object", path = "object")
public interface RelationRepository extends Neo4jRepository<Object, Long> {

    String relationTypeRelation = "INVEST|WORK|GUARANTEE|MANAGER|RELATIVE|SUPPLIER|CUSTOMER|BRANCH";//|ISSUE
//    String relationTypeRelationForCompanyPerson = "INVEST|WORK|RELATIVE";//|ISSUE

    //三跳全路径找不到的情况下，查询七跳最短路径
    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_NM:{companyNm1}})-[:" + relationTypeRelation + "*..7]-(B:COMPANY{COMPANY_NM:{companyNm2}})) " + Constants.returnQuery)
    QueryResultModel getCompanyWithCompanyShortestPathByName(@Param("companyNm1") String companyNm1, @Param("companyNm2") String companyNm2);

    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_ID:{companyId}})-[:" + relationTypeRelation + "*..7]-(B:COMPANY{COMPANY_NM:{companyNm}})) " + Constants.returnQuery)
    QueryResultModel getCompanyWithCompanyShortestPathByNameId(@Param("companyId") String companyId, @Param("companyNm") String companyNm);

    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_ID:{companyId1}})-[:" + relationTypeRelation + "*..7]-(B:COMPANY{COMPANY_ID:{companyId2}})) " + Constants.returnQuery)
    QueryResultModel getCompanyWithCompanyShortestPathId(@Param("companyId1") String companyId1, @Param("companyId2") String companyId2);

    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_NM:{companyNm}})-[:" + relationTypeRelation + "*..7]-(B:PERSON{PERSON_NM:{personnm}})) " + Constants.returnQuery)
    QueryResultModel getCompanyWithPersonShortestPathByNameId(@Param("companyNm") String companyNm, @Param("personnm") String personnm);

    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_ID:{companyId}})-[:" + relationTypeRelation + "*..7]-(B:PERSON{PERSON_NM:{personnm}})) " + Constants.returnQuery)
    QueryResultModel getCompanyWithPersonShortestPathId(@Param("companyId") String companyId, @Param("personnm") String personnm);

    @Query("MATCH P = AllShortestPaths((A:COMPANY{COMPANY_ID:{personnm1}})-[:" + relationTypeRelation + "*..7]-(B:PERSON{PERSON_NM:{personnm2}})) " + Constants.returnQuery)
    QueryResultModel getPeronWithPersonShortestPathId(@Param("personnm1") String personnm1, @Param("personnm2") String personnm2);


    @Query("MATCH P = (A:COMPANY{COMPANY_NM:{companyNm1}})-[:" + relationTypeRelation + "*..3]-(B:COMPANY{COMPANY_NM:{companyNm2}}) " + Constants.returnQuery)
    QueryResultModel getCompanyWithCompanyPathByName(@Param("companyNm1") String companyNm1, @Param("companyNm2") String companyNm2);

    @Query("MATCH P = (A:COMPANY{COMPANY_ID:{companyId}})-[:" + relationTypeRelation + "*..3]-(B:COMPANY{COMPANY_NM:{companyNm}}) " + Constants.returnQuery)
    QueryResultModel getCompanyWithCompanyPathByNameId(@Param("companyId") String companyId, @Param("companyNm") String companyNm);

    @Query("MATCH P = (A:COMPANY{COMPANY_ID:{companyId1}})-[:" + relationTypeRelation + "*..3]-(B:COMPANY{COMPANY_ID:{companyId2}}) " + Constants.returnQuery)
    QueryResultModel getCompanyWithCompanyPathId(@Param("companyId1") String companyId1, @Param("companyId2") String companyId2);

    @Query("MATCH (A:COMPANY{COMPANY_NM:{companyNm}}) WITH A MATCH P = (A)-[:" + relationTypeRelation + "*..3]-(B:PERSON{PERSON_NM:{personnm}}) " + Constants.returnQuery)
    QueryResultModel getCompanyWithPersonPathByNameId(@Param("companyNm") String companyNm, @Param("personnm") String personnm);

    @Query("MATCH P = (A:COMPANY{COMPANY_ID:{companyId}})-[:" + relationTypeRelation + "*..3]-(B:PERSON{PERSON_NM:{personnm}}) " + Constants.returnQuery)
    QueryResultModel getCompanyWithPersonPathId(@Param("companyId") String companyId, @Param("personnm") String personnm);

    @Query("MATCH P = (A:PERSON{PERSON_NM:{personnm1}})-[:" + relationTypeRelation + "*..3]-(B:PERSON{PERSON_NM:{personnm2}}) " + Constants.returnQuery)
    QueryResultModel getPeronWithPersonPathId(@Param("personnm1") String personnm1, @Param("personnm2") String personnm2);
}