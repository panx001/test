package com.cscs.graph_api.dto;

public class InvestFilterInDto {
    public String companyNm;
    public Long companyId;
    public Double leftBound;
    public Double rightBound;
    public int containRB;

    public String getCompanyNm() {
        return companyNm;
    }

    public void setCompanyNm(String companyNm) {
        this.companyNm = companyNm;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Double getLeftBound() {
        return leftBound;
    }

    public void setLeftBound(Double leftBound) {
        this.leftBound = leftBound;
    }

    public Double getRightBound() {
        return rightBound;
    }

    public void setRightBound(Double rightBound) {
        this.rightBound = rightBound;
    }

    public int getContainRB() {
        return containRB;
    }

    public void setContainRB(int containRB) {
        this.containRB = containRB;
    }
}
