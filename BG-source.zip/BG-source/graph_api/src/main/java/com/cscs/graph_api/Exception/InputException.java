package com.cscs.graph_api.Exception;

public class InputException extends Exception {
}
