package com.cscs.three.part.repository;

import net.sf.json.JSONObject;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.junit.Test;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * @author jiangqw
 * @date 2019/7/18 13:19
 */
public class TestApi {
    @Test
    public void test() throws IOException {
        HttpPost httpPost = new HttpPost("http://10.100.46.39:7078/relation/searchControllerThreshold");
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("companyId", 239589);
        /*jsonObject.put("leftBound", 10);
        jsonObject.put("rightBound", 80);
        jsonObject.put("containRB", 0);*/
        httpPost.setHeader("Content-Type", "application/json;charset=utf8");
        StringEntity entity = new StringEntity(jsonObject.toString(), StandardCharsets.UTF_8);
        httpPost.setEntity(entity);
        try (CloseableHttpClient httpClient = HttpClientBuilder.create().build();
             CloseableHttpResponse httpResponse = httpClient.execute(httpPost)) {
            System.out.println(httpResponse.getStatusLine());
            System.out.println(EntityUtils.toString(httpResponse.getEntity()));
        }
    }

    @Test
    public void testCypher() {
        StringBuilder cypher = new StringBuilder();
        int companyId = 9059481;
        double leftBound = 10;
        double rightBound = 80;
        cypher.append("MATCH path = (C:COMPANY{");
        cypher.append("COMPANY_ID:\"" + companyId + "\"");
        cypher.append("})-[R:INVEST]->(D)\n");
        cypher.append("where " + leftBound + "\n" +
                "<=tofloat(R.SHA_RATIO)<" + rightBound + "\n" +
                "return distinct \n" +
                "      CASE \n" +
                "        WHEN 'COMPANY' IN LABELS(D) \n" +
                "        THEN D.COMPANY_NM \n" +
                "        ELSE D.SECINNER_NM  \n" +
                "        END AS companyName,\n" +
                "      CASE \n" +
                "        WHEN 'COMPANY' IN LABELS(D) \n" +
                "        THEN D.COMPANY_ID \n" +
                "        ELSE D.SECINNER_ID  \n" +
                "        END AS companyId,\n" +
                "        tofloat(R.SHA_RATIO) as investRatio order by investRatio desc");
        System.out.println(cypher);
    }

    @Test
    public void testCypher2() {
        StringBuilder cypher = new StringBuilder();
        int sumRatio = 50;
        int companyId = 425783;
        cypher.append("MATCH path = (C:COMPANY{");

        cypher.append("COMPANY_ID:\"" + companyId + "\"");
        cypher.append("})<-[R:INVEST*..5]-(P)\n");
//            cypher.append("where not (P)<-[:INVEST]-()\n");
        cypher.append("WITH C,P,\n" +
                "COLLECT([p in rels(path)|\n" +
                "  CASE \n" +
                " WHEN p.SHA_RATIO IS NOT NULL \n" +
                " THEN tofloat(p.SHA_RATIO)*0.01 \n" +
                " WHEN p.SHA_RATIO IS NULL AND p.NUM IS NOT NULL AND apoc.cscs.getRegCapital(p) <> 0      //getRegCapital该边指向企业的注册资本\n" +
                " THEN tofloat(p.NUM)/apoc.cscs.getRegCapital(p) \n" +
                " ELSE 0 \n" +
                " END]) AS paths,  //计算每条路径的 持股比例 \n" +
                " COLLECT([p in rels(path)|startNode(p).COMPANY_NM]) AS pathsNm //路径开始节点的name集合 （应该先判断公司/自然人） \n" +
                "\n" +
                "UNWIND  RANGE(0,LENGTH(paths)-1) AS pathsindex  \n" +
                "UNWIND RANGE(0,LENGTH(paths[pathsindex])-1) as valuesIndex\n" +
                "WITH C,P, pathsindex,\n" +
                "paths[pathsindex] AS values,\n" +
                "apoc.agg.product(paths[pathsindex][valuesIndex]) as p,\n" +
                "paths as pathValue,\n" +
                "pathsNm\n" +
                "WITH C,P,pathValue,\n" +
                "COLLECT(p) AS pValues,\n" +
                "pathsNm \n" +
                "WITH C,P, \n" +
                "CASE \n" +
                "WHEN 'COMPANY' IN LABELS(P) \n" +
                "THEN P.COMPANY_NM \n" +
                "ELSE P.PERSON_NM  \n" +
                "END AS CONTROLLER_NM,\n" +
                "CASE \n" +
                "WHEN 'COMPANY' IN LABELS(P) \n" +
                "THEN P.COMPANY_ID \n" +
                "ELSE P.PERSON_ID \n" +
                "END AS CONTROLLER_ID,\n" +
                "pathValue,\n" +
                "pValues,\n" +
                "apoc.coll.sum(pValues) AS totalValue,\n" +
                "pathsNm \n" +
                "WHERE totalValue > " + sumRatio / 100 + "\n" +
                "\n" +
                "with CONTROLLER_NM,CONTROLLER_ID,C,totalValue\n" +
                "MATCH CP = (C)<-[:INVEST*..5]-(P)\n" +
                "where P.COMPANY_NM = CONTROLLER_NM or P.PERSON_NM = CONTROLLER_NM\n" +
                "with nodes(CP) as coll_name,CONTROLLER_NM,CONTROLLER_ID,totalValue,P,[n IN NODES(CP)| SIZE([m IN FILTER(f IN NODES(CP) WHERE ID(f)=ID(n))])] \n" +
                "    AS nodeIdCount \n" +
                "    WHERE ALL(x IN nodeIdCount WHERE x<2) \n" +
                "unwind coll_name as name_new\n" +
                "with CASE \n" +
                "WHEN 'COMPANY' IN LABELS(name_new) \n" +
                "THEN name_new.COMPANY_NM \n" +
                "ELSE name_new.PERSON_NM  \n" +
                "END AS name,CONTROLLER_NM,CONTROLLER_ID,totalValue,P\n" +
                "with CONTROLLER_ID as sharehdId,CONTROLLER_NM as sharehdName,LABELS(P) as sharehdType,\n" +
                "totalValue as sharehdRatio,collect(name) as sharehdPath,CASE WHEN 'COMPANY' IN LABELS(P) THEN P.REG_CAPITAL END AS regCapital,\n" +
                "CASE WHEN 'COMPANY' IN LABELS(P) THEN P.STATUS END AS status,CASE WHEN 'COMPANY' IN LABELS(P) THEN P.ORGNUM END AS orgnum\n" +
                "return sharehdId,sharehdName,sharehdType,sharehdRatio,sharehdPath,regCapital,status,orgnum");
        System.out.println(cypher);
    }
}
