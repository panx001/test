package com.cscs.three.part.repository;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

/**
 * @author jiangqw
 * @date 2019/7/17 16:05
 */
public class TestJsonArray {
    /**
     * JSONArray clones the JSONObject
     */
    @Test
    public void testDiscard() {
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("name", "john");
        jsonObject.put("age", 12);
        jsonArray.add(jsonObject);
        System.out.println(jsonArray);
        jsonObject.put("job", "java developer");
        System.out.println(jsonArray.discard(jsonObject));
    }

    /**
     * JSONObject discards null values
     */
    @Test
    public void testPutNullValue() {
        Map<String, Object> map = new HashMap<>(2);
        map.put("name", "john");
        map.put("job", null);
        System.out.println(map);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("name", "john");
        jsonObject.put("job", null);
        System.out.println(jsonObject);
    }
}
